## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/188
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 1
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/188
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 118
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Laulu mõju
URL: https://www.opiq.ee/kit/188/chapter/10576
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 1.1
Topics ET: matemaatika, laulu, mõju, eestlased, taevas, tantsib
Topics RU: математика
Topics EN: mathematics
Headings: Laulu mõju; Eestlased; Taevas tantsib
Task examples: Ütle ja kirjuta vihikusse Muusikamaa tegelaste nimed.

## Tere
URL: https://www.opiq.ee/kit/188/chapter/10577
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 1.2
Topics ET: matemaatika, tere
Topics RU: математика
Topics EN: mathematics
Headings: Tere; TERE!

## Kui sul tuju hea
URL: https://www.opiq.ee/kit/188/chapter/10578
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 1.3
Topics ET: matemaatika, tuju
Topics RU: математика
Topics EN: mathematics
Headings: Kui sul tuju hea
Task examples: Kirjuta märkide tähendus.

## Sügistalgud
URL: https://www.opiq.ee/kit/188/chapter/10617
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 10.1
Topics ET: matemaatika, sügistalgud
Topics RU: математика
Topics EN: mathematics
Headings: Sügistalgud
Task examples: Tee ise viis töövihikus, kasutades neljas langevarjus olevat viisilõiku. Värvi.

## Lumehelbeke
URL: https://www.opiq.ee/kit/188/chapter/10618
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 10.2
Topics ET: matemaatika, lumehelbeke
Topics RU: математика
Topics EN: mathematics
Headings: Lumehelbeke

## Saja, saja
URL: https://www.opiq.ee/kit/188/chapter/10619
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 10.3
Topics ET: matemaatika, saja
Topics RU: математика
Topics EN: mathematics
Headings: Saja, saja
Task examples: Paranda punase pliiatsiga vead töövihikus. Mitu viga oli igas ülesandes?

## Hanepojad
URL: https://www.opiq.ee/kit/188/chapter/10620
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 10.4
Topics ET: matemaatika, hanepojad
Topics RU: математика
Topics EN: mathematics
Headings: Hanepojad
Task examples: Täida taktid oma rütmiga töövihikus. Esita harjutused.

## Päkapiku töö
URL: https://www.opiq.ee/kit/188/chapter/10621
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 11.1
Topics ET: matemaatika, päkapiku
Topics RU: математика
Topics EN: mathematics
Headings: Päkapiku töö

## Piiluri laul
URL: https://www.opiq.ee/kit/188/chapter/10622
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 11.2
Topics ET: matemaatika, piiluri, laul
Topics RU: математика
Topics EN: mathematics
Headings: Piiluri laul
Task examples: Leia piltidelt erinevused. Värvi pilt töövihikus.

## Pagari piparkook
URL: https://www.opiq.ee/kit/188/chapter/10623
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 11.3
Topics ET: matemaatika, pagari, piparkook
Topics RU: математика
Topics EN: mathematics
Headings: Pagari piparkook
Task examples: Kaunista kuusk rütmipallidega töövihikus. Värvi.

## Oh, kuusepuu
URL: https://www.opiq.ee/kit/188/chapter/10624
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 11.4
Topics ET: matemaatika, kuusepuu
Topics RU: математика
Topics EN: mathematics
Headings: Oh, kuusepuu
Task examples: Mõtle ja kirjuta viis lõpuni töövihikus. Laula koos käemärkidega.

## Jõululaul
URL: https://www.opiq.ee/kit/188/chapter/10625
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 12.1
Topics ET: matemaatika, jõululaul
Topics RU: математика
Topics EN: mathematics
Headings: Jõululaul
Task examples: Kirjuta Jõuluvanale kiri ja pane see posti. Kuula muusikat ja joonista töövihikusse jõulupilt.

## Haldjate jõuluöö
URL: https://www.opiq.ee/kit/188/chapter/10626
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 12.2
Topics ET: matemaatika, haldjate, jõuluöö
Topics RU: математика
Topics EN: mathematics
Headings: Haldjate jõuluöö
Task examples: Kuula jõulumuusikat ja ühenda pildil töövihikus numbrid joontega. Värvi.

## Ma olen väike karjane
URL: https://www.opiq.ee/kit/188/chapter/10627
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 12.3
Topics ET: matemaatika, olen, väike, karjane
Topics RU: математика
Topics EN: mathematics
Headings: Ma olen väike karjane
Task examples: Kas lause on õige või vale? Kirjuta töövihikusse valed laused nii, et nad oleksid õiged (õpik lk 63).

## Jõulumaal
URL: https://www.opiq.ee/kit/188/chapter/10628
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 12.4
Topics ET: matemaatika, jõulumaal
Topics RU: математика
Topics EN: mathematics
Headings: Jõulumaal
Task examples: Leia ja ühenda riimuvad sõnad joonega töövihikus. Tee jõululuuletus.

## Tiliseb, tiliseb aisakell
URL: https://www.opiq.ee/kit/188/chapter/10629
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 12.5
Topics ET: matemaatika, tiliseb, aisakell
Topics RU: математика
Topics EN: mathematics
Headings: Tiliseb, tiliseb aisakell
Task examples: Leia piltidelt tuttavad laulud. Kirjuta töövihikusse nende pealkirjad ja autorid (abiks õpik lk 5–57). Värvi.

## Radi-ridi-ralla
URL: https://www.opiq.ee/kit/188/chapter/10630
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 13.1
Topics ET: matemaatika, radi, ridi, ralla
Topics RU: математика
Topics EN: mathematics
Headings: Radi-ridi-ralla

## Lumemehest
URL: https://www.opiq.ee/kit/188/chapter/10631
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 13.2
Topics ET: matemaatika, lumemehest
Topics RU: математика
Topics EN: mathematics
Headings: Lumemehest
Task examples: Kuula muusikat ja kirjuta jutuke päikesest ja kuust. Loe oma jutt ette.

## Väravamäng
URL: https://www.opiq.ee/kit/188/chapter/10632
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 14.1
Topics ET: matemaatika, väravamäng
Topics RU: математика
Topics EN: mathematics
Headings: Väravamäng
Task examples: Kaunista riideesemed muusikalistest märkidest mustritega töövihikus. Värvi.

## Veere, päike!
URL: https://www.opiq.ee/kit/188/chapter/10633
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 14.2
Topics ET: matemaatika, veere, päike
Topics RU: математика
Topics EN: mathematics
Headings: Veere, päike!; Päike
Task examples: Kirjuta viis noodijoonestikule töövihikus. Tee ise viisile sõnad. Esita laul.

## Päike ja kuu
URL: https://www.opiq.ee/kit/188/chapter/10634
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 14.3
Topics ET: matemaatika, päike
Topics RU: математика
Topics EN: mathematics
Headings: Päike ja kuu

## Kaera-Jaan
URL: https://www.opiq.ee/kit/188/chapter/10635
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 15.1
Topics ET: matemaatika, kaera, jaan
Topics RU: математика
Topics EN: mathematics
Headings: Kaera-Jaan
Task examples: Värvi ja lõika välja tantsunukud töövihikus.

## Pillerpall
URL: https://www.opiq.ee/kit/188/chapter/10636
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 15.2
Topics ET: matemaatika, pillerpall
Topics RU: математика
Topics EN: mathematics
Headings: Pillerpall

## Laul ja töö
URL: https://www.opiq.ee/kit/188/chapter/10637
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 15.3
Topics ET: matemaatika, laul
Topics RU: математика
Topics EN: mathematics
Headings: Laul ja töö
Task examples: Arva ära mõistatused ja kirjuta nende rütm töövihikus. Esita kehapillil.; Leia tööriistade nimed ja nende rütmid. Täida ülesanne töövihikus.

## Mina ja sina
URL: https://www.opiq.ee/kit/188/chapter/10638
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 16.1
Topics ET: matemaatika, mina, sina
Topics RU: математика
Topics EN: mathematics
Headings: Mina ja sina

## Laul sõprusest
URL: https://www.opiq.ee/kit/188/chapter/10639
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 16.2
Topics ET: matemaatika, laul, sõprusest
Topics RU: математика
Topics EN: mathematics
Headings: Laul sõprusest
Task examples: Ühenda riimuvad sõnad joonega töövihikus. Kirjuta oma sõbrast luuletus ja esita see.; Kirjuta noodid töövihikusse. Laula käemärkidega.

## Rännumees
URL: https://www.opiq.ee/kit/188/chapter/10640
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 16.3
Topics ET: matemaatika, rännumees
Topics RU: математика
Topics EN: mathematics
Headings: Rännumees

## Jõgi
URL: https://www.opiq.ee/kit/188/chapter/10641
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 16.4
Topics ET: matemaatika, jõgi
Topics RU: математика
Topics EN: mathematics
Headings: Jõgi
Task examples: Kirjuta astmenimed töövihikus. Tõmba astmetele RAI ja SOI värviline ring ümber. Laula käemärkidega.

## Mamma Marakas
URL: https://www.opiq.ee/kit/188/chapter/10642
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 16.5
Topics ET: matemaatika, mamma, marakas
Topics RU: математика
Topics EN: mathematics
Headings: Mamma Marakas
Task examples: Kirjuta astmed töövihikus noodijoonestikule. Tõmba astmetele RAI ja SOI värviline ring ümber. Laula käemärkidega.

## Me oleme pillimehed
URL: https://www.opiq.ee/kit/188/chapter/10643
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 16.6
Topics ET: matemaatika, oleme, pillimehed
Topics RU: математика
Topics EN: mathematics
Headings: Me oleme pillimehed
Task examples: Esita rütmiharjutus koos sõbraga. Mõelge välja uus harjutus. Pange see töövihikusse kirja ja esitage.

## Kõige suurem sõber
URL: https://www.opiq.ee/kit/188/chapter/10644
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 16.7
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kõige, sõber
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Kõige suurem sõber

## Mu isamaa, mu õnn ja rõõm
URL: https://www.opiq.ee/kit/188/chapter/10645
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 17.1
Topics ET: matemaatika, isamaa, rõõm
Topics RU: математика
Topics EN: mathematics
Headings: Mu isamaa, mu õnn ja rõõm
Task examples: Lohista kaardile puuduvad linnanimed. Tähista töövihikus ka oma kodukoht. Värvi.

## Üks väike maa
URL: https://www.opiq.ee/kit/188/chapter/10646
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 17.2
Topics ET: matemaatika, väike
Topics RU: математика
Topics EN: mathematics
Headings: Üks väike maa

## Mu koduke
URL: https://www.opiq.ee/kit/188/chapter/10647
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 17.3
Topics ET: matemaatika, koduke
Topics RU: математика
Topics EN: mathematics
Headings: Mu koduke
Task examples: Täida „Eesti hümni” teksti lüngad. Laula hümni peast.

## Iga maa
URL: https://www.opiq.ee/kit/188/chapter/10648
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 17.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Iga maa

## Vastlad
URL: https://www.opiq.ee/kit/188/chapter/10649
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 18.1
Topics ET: matemaatika, vastlad
Topics RU: математика
Topics EN: mathematics
Headings: Vastlad

## Hiiretips
URL: https://www.opiq.ee/kit/188/chapter/10650
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 18.2
Topics ET: matemaatika, hiiretips, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Hiiretips; Tähesegadik
Task examples: Meisterda käepael. Käepaela mustri aluseks võid võtta Eesti Vabariigi lipu värvid või rahvariideseelikute triibu värvid. Võid ka ise mustri välja mõelda. Töövahendid: käärid,auguraud, joonlaud, PVA liim, papitükk ja eri 

## Vastlasõit-pastlasõit
URL: https://www.opiq.ee/kit/188/chapter/10651
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 18.3
Topics ET: matemaatika, vastlasõit, pastlasõit, tempo, väike, rong
Topics RU: математика
Topics EN: mathematics
Headings: Vastlasõit-pastlasõit; Tempo; VÄIKE RONG
Task examples: Kirjuta laulu „Väike rong” viis noodijoonestikule töövihikus (õpik lk 95). Mõtle ja kirjuta sõnu juurde. Laula.

## Riidepanemise laul
URL: https://www.opiq.ee/kit/188/chapter/10652
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 19.1
Topics ET: matemaatika, riidepanemise, laul
Topics RU: математика
Topics EN: mathematics
Headings: Riidepanemise laul
Task examples: Järjesta riideesemed numbritega töövihikus. Alusta sellest, mille selgapanemine võtab kõige vähem aega. Värvi.

## Jänkude saunalaul
URL: https://www.opiq.ee/kit/188/chapter/10653
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 19.2
Topics ET: matemaatika, jänkude, saunalaul
Topics RU: математика
Topics EN: mathematics
Headings: Jänkude saunalaul
Task examples: Jaga rütm taktidesse töövihikus ja esita harjutus häälega.

## Kommilaul
URL: https://www.opiq.ee/kit/188/chapter/10654
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 19.3
Topics ET: matemaatika, kommilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kommilaul

## Tarkus tuleb tasapisi
URL: https://www.opiq.ee/kit/188/chapter/10579
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 2.1
Topics ET: matemaatika, kordamine, korda, harjutan, tarkus, tuleb, tasapisi, tasahilju, tarkuse
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Tarkus tuleb tasapisi; TASAHILJU; Kordamine on tarkuse ema

## Saladuste maja
URL: https://www.opiq.ee/kit/188/chapter/10580
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 2.2
Topics ET: matemaatika, saladuste, maja
Topics RU: математика
Topics EN: mathematics
Headings: Saladuste maja
Task examples: Harjuta rütmivormide kirjutamist töövihikus.; Kirjuta rütmisilbid töövihikus. Esita rütm kehapillil.

## Aabitsalaul
URL: https://www.opiq.ee/kit/188/chapter/10581
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 2.3
Topics ET: matemaatika, aabitsalaul
Topics RU: математика
Topics EN: mathematics
Headings: Aabitsalaul

## Minu veli virvipuu
URL: https://www.opiq.ee/kit/188/chapter/10582
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 2.4
Topics ET: matemaatika, veli, virvipuu
Topics RU: математика
Topics EN: mathematics
Headings: Minu veli virvipuu

## Räästaorel
URL: https://www.opiq.ee/kit/188/chapter/10655
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 20.1
Topics ET: matemaatika, räästaorel
Topics RU: математика
Topics EN: mathematics
Headings: Räästaorel
Task examples: Kirjuta purikatelt rütm töövihikusse, jaga taktidesse ja esita see klaasidel. Klaasides olev vee kogus peab olema erinev.

## Kop-kop-kop
URL: https://www.opiq.ee/kit/188/chapter/10656
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 20.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Kop-kop-kop
Task examples: Kuula kahte muusikapala. Kirjuta töövihikus sarnased omadused keskele ja erinevad külgedele. Näiteks: rahulik, hoogne, pidulik, salapärane, esitasid pillid, esitasid lauljad jne.

## Kummisäärik
URL: https://www.opiq.ee/kit/188/chapter/10657
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 20.3
Topics ET: matemaatika, kummisäärik
Topics RU: математика
Topics EN: mathematics
Headings: Kummisäärik

## Tihane
URL: https://www.opiq.ee/kit/188/chapter/10658
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 20.4
Topics ET: matemaatika, tihane
Topics RU: математика
Topics EN: mathematics
Headings: Tihane

## Kes mida teeb?
URL: https://www.opiq.ee/kit/188/chapter/10659
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 21.1
Topics ET: matemaatika, mida, teeb
Topics RU: математика
Topics EN: mathematics
Headings: Kes mida teeb?

## Õuelaul
URL: https://www.opiq.ee/kit/188/chapter/10660
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 21.2
Topics ET: matemaatika, õuelaul
Topics RU: математика
Topics EN: mathematics
Headings: Õuelaul

## Plaatpillid
URL: https://www.opiq.ee/kit/188/chapter/10661
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 21.3
Topics ET: matemaatika, plaatpillid
Topics RU: математика
Topics EN: mathematics
Headings: Plaatpillid

## Kukeke
URL: https://www.opiq.ee/kit/188/chapter/10662
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 21.4
Topics ET: matemaatika, kukeke
Topics RU: математика
Topics EN: mathematics
Headings: Kukeke

## Pillimehed pilliroos
URL: https://www.opiq.ee/kit/188/chapter/10663
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 21.5
Topics ET: matemaatika, pillimehed, pilliroos
Topics RU: математика
Topics EN: mathematics
Headings: Pillimehed pilliroos
Task examples: Kirjuta taktimõõt ja astmenimed töövihikus. Esita harjutus plaatpilli saatega.

## Musta kassi tango
URL: https://www.opiq.ee/kit/188/chapter/10664
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 21.6
Topics ET: matemaatika, musta, kassi, tango
Topics RU: математика
Topics EN: mathematics
Headings: Musta kassi tango

## Pajupõõsa hällilaul
URL: https://www.opiq.ee/kit/188/chapter/10665
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 22.1
Topics ET: matemaatika, pajupõõsa, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Pajupõõsa hällilaul

## Kiik kaunil kohal
URL: https://www.opiq.ee/kit/188/chapter/10666
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 22.2
Topics ET: matemaatika, kiik, kaunil, kohal
Topics RU: математика
Topics EN: mathematics
Headings: Kiik kaunil kohal
Task examples: Moodusta omavahel sobivatest lõikudest laused. Värvi laused töövihikus erinevate värvidega.

## Jänku-jenka
URL: https://www.opiq.ee/kit/188/chapter/10667
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 22.3
Topics ET: matemaatika, jänku, jenka
Topics RU: математика
Topics EN: mathematics
Headings: Jänku-jenka

## Tibukene
URL: https://www.opiq.ee/kit/188/chapter/10668
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 22.4
Topics ET: matemaatika, tibukene
Topics RU: математика
Topics EN: mathematics
Headings: Tibukene
Task examples: Värvi munad ja kaunista medal töövihikus.

## Töömang
URL: https://www.opiq.ee/kit/188/chapter/10669
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 23.1
Topics ET: matemaatika, töömang, töömäng
Topics RU: математика
Topics EN: mathematics
Headings: Töömang; TÖÖMÄNG

## Karjapoiss
URL: https://www.opiq.ee/kit/188/chapter/10670
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 23.2
Topics ET: matemaatika, karjapoiss
Topics RU: математика
Topics EN: mathematics
Headings: Karjapoiss
Task examples: Tõmba taktijooned ja kirjuta viis noodijoonestikule töövihikus. Esita kaanon koos klassikaaslasega.

## Buratino laul
URL: https://www.opiq.ee/kit/188/chapter/10671
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 24.1
Topics ET: matemaatika, buratino, laul
Topics RU: математика
Topics EN: mathematics
Headings: Buratino laul
Task examples: Aita Buratinol laulu teha. Moodusta neljataktiline rütmirida ja kirjuta sobivad astmed alla töövihikus. Laula. Värvi pilt.

## Nõiapoisid
URL: https://www.opiq.ee/kit/188/chapter/10672
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 24.2
Topics ET: matemaatika, nõiapoisid
Topics RU: математика
Topics EN: mathematics
Headings: Nõiapoisid
Task examples: Kirjuta noodijoonestikule töövihikus nõidade kõrvarõngastelt leitud viis. Lisa nootidele rütm. Pane nõidadele nimed. Laula.

## Väike meremees
URL: https://www.opiq.ee/kit/188/chapter/10673
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 24.3
Topics ET: matemaatika, väike, meremees
Topics RU: математика
Topics EN: mathematics
Headings: Väike meremees

## Krõll kotis
URL: https://www.opiq.ee/kit/188/chapter/10674
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 24.4
Topics ET: matemaatika, krõll, kotis
Topics RU: математика
Topics EN: mathematics
Headings: Krõll kotis
Task examples: Mõtle ja kirjuta viisidele lõpud töövihikus. Esita need.

## Sipsik
URL: https://www.opiq.ee/kit/188/chapter/10675
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 24.5
Topics ET: matemaatika, sipsik
Topics RU: математика
Topics EN: mathematics
Headings: Sipsik
Task examples: Leia igale raamatule õige autor.; Moodusta pingerida oma lemmikraamatutest.

## Linnupere
URL: https://www.opiq.ee/kit/188/chapter/10676
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 25.1
Topics ET: matemaatika, linnupere
Topics RU: математика
Topics EN: mathematics
Headings: Linnupere

## Kevadpidu
URL: https://www.opiq.ee/kit/188/chapter/10677
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 25.2
Topics ET: matemaatika, kevadpidu
Topics RU: математика
Topics EN: mathematics
Headings: Kevadpidu
Task examples: Leia laulust „Kevadpidu” (õpik lk 125) lilleõie rütmidele sobivad linnunimed. Kirjuta lindude nimed lillele töövihikus. Värvi.

## Pääsuke
URL: https://www.opiq.ee/kit/188/chapter/10678
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 25.3
Topics ET: matemaatika, pääsuke
Topics RU: математика
Topics EN: mathematics
Headings: Pääsuke

## Paduvihm
URL: https://www.opiq.ee/kit/188/chapter/10679
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 25.4
Topics ET: matemaatika, paduvihm
Topics RU: математика
Topics EN: mathematics
Headings: Paduvihm
Task examples: Kirjuta astmenimed töövihikus ja laula. Kirjuta tuttavate laulude pealkirjad.

## Sulle, emake
URL: https://www.opiq.ee/kit/188/chapter/10680
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 26.1
Topics ET: matemaatika, sulle, emake
Topics RU: математика
Topics EN: mathematics
Headings: Sulle, emake
Task examples: Tõmba taktijooned ja kirjuta viis noodijoonestikule töövihikus. Mõtle juurde sõnad oma emast. Kingi laul emale.

## Uni, tule silma peale
URL: https://www.opiq.ee/kit/188/chapter/10681
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 26.2
Topics ET: matemaatika, tule, silma, peale
Topics RU: математика
Topics EN: mathematics
Headings: Uni, tule silma peale

## Ema teeb köögis süüa
URL: https://www.opiq.ee/kit/188/chapter/10682
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 26.3
Topics ET: matemaatika, teeb, köögis, süüa
Topics RU: математика
Topics EN: mathematics
Headings: Ema teeb köögis süüa
Task examples: Leia rütmid ja kirjuta töövihikusse. Esita harjutused topsipillil. Värvi.

## Laul vanaemast
URL: https://www.opiq.ee/kit/188/chapter/10683
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 26.4
Topics ET: matemaatika, laul, vanaemast
Topics RU: математика
Topics EN: mathematics
Headings: Laul vanaemast
Task examples: Tõmba taktijooned ja kirjuta astmenimed töövihikus. Laula käemärkidega.; Tee ise unelaul töövihikusse. Võid kasutada pildil olevaid sõnu. Värvi.

## Laula, laula, suukene
URL: https://www.opiq.ee/kit/188/chapter/10684
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 27.1
Topics ET: matemaatika, laula, suukene
Topics RU: математика
Topics EN: mathematics
Headings: Laula, laula, suukene
Task examples: Leia piltidelt erinevused. Tõmba töövihikus ring ümber tegelastele, kes esinevad laulupeol. Värvi.

## Seitse sokku
URL: https://www.opiq.ee/kit/188/chapter/10685
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 27.2
Topics ET: matemaatika, seitse, sokku, gustav, ernesaks
Topics RU: математика
Topics EN: mathematics
Headings: Seitse sokku; Gustav Ernesaks
Task examples: Esita rütmiharjutus kehapillil mõlema käega koos. Mõelge koos sõbraga uus harjutus ja esitage see.

## Hoolimise laul
URL: https://www.opiq.ee/kit/188/chapter/10686
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 27.3
Topics ET: matemaatika, hoolimise, laul
Topics RU: математика
Topics EN: mathematics
Headings: Hoolimise laul
Task examples: Kirjuta töövihikusse astmenimed ja laula käemärkidega. Kirjuta laulu pealkiri ja autorid (abiks õpik lk 48–53).; Leia ja tõmba jooned ümber töövihikus sõnadele, mis on seotud laulupeoga.

## Poiste bugi
URL: https://www.opiq.ee/kit/188/chapter/10687
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 27.4
Topics ET: matemaatika, poiste, bugi
Topics RU: математика
Topics EN: mathematics
Headings: Poiste bugi

## Päikesejänku
URL: https://www.opiq.ee/kit/188/chapter/10688
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 27.5
Topics ET: matemaatika, päikesejänku
Topics RU: математика
Topics EN: mathematics
Headings: Päikesejänku
Task examples: Leia ja kirjuta piltidelt rütm töövihikusse. Mõtle ise uued rütmiread ja esita need klassikaaslastele.

## Lepatriinu, lenda ära
URL: https://www.opiq.ee/kit/188/chapter/10689
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 28.1
Topics ET: matemaatika, lepatriinu, lenda
Topics RU: математика
Topics EN: mathematics
Headings: Lepatriinu, lenda ära
Task examples: Tõmba taktijooned ja kirjuta astmenimed töövihikus. Tee laulule rütmisaade. Esita laul koos kehapilli saatega.

## Suvi
URL: https://www.opiq.ee/kit/188/chapter/10690
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 28.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Suvi

## Jaan läeb jaanitulele
URL: https://www.opiq.ee/kit/188/chapter/10691
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 28.3
Topics ET: matemaatika, jaan, läeb, jaanitulele
Topics RU: математика
Topics EN: mathematics
Headings: Jaan läeb jaanitulele

## Sügislauluke
URL: https://www.opiq.ee/kit/188/chapter/10583
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 3.1
Topics ET: matemaatika, sügislauluke
Topics RU: математика
Topics EN: mathematics
Headings: Sügislauluke
Task examples: Lohista pildi alla sõna. Kirjuta sõna rütm töövihikusse. Värvi pilt.

## Vihmakene, vellekene
URL: https://www.opiq.ee/kit/188/chapter/10584
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 3.2
Topics ET: matemaatika, vihmakene, vellekene
Topics RU: математика
Topics EN: mathematics
Headings: Vihmakene, vellekene
Task examples: Kirjuta luuletuse rütm töövihikusse. Loe luuletust ja mängi selle rütmi kehapillil.

## Mehikene metsas
URL: https://www.opiq.ee/kit/188/chapter/10585
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 3.3
Topics ET: matemaatika, mehikene, metsas
Topics RU: математика
Topics EN: mathematics
Headings: Mehikene metsas
Task examples: Kirjuta puuduvad tähed töövihikusse. Täida tühjad taktid rütmidega. Plaksuta.

## Seenemiku tegemised
URL: https://www.opiq.ee/kit/188/chapter/10586
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 3.4
Topics ET: matemaatika, seenemiku, tegemised, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Seenemiku tegemised; Tähesegadik
Task examples: Tõmba taktijooned töövihikus. Esita rütmiharjutus.

## Igaühel oma pill
URL: https://www.opiq.ee/kit/188/chapter/10587
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 4.1
Topics ET: matemaatika, igaühel, pill, kandlelood
Topics RU: математика
Topics EN: mathematics
Headings: Igaühel oma pill; KANDLELOOD
Task examples: Tõmba taktijooned ja lõpujooned töövihikus. Esita harjutused kehapillil. Värvi vaip.; Kirjuta taktimõõt ja täida taktid oma rütmidega töövihikus. Koputa harjutusi edasi-tagasi.

## Tantsuhoos
URL: https://www.opiq.ee/kit/188/chapter/10588
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 4.2
Topics ET: matemaatika, tantsuhoos
Topics RU: математика
Topics EN: mathematics
Headings: Tantsuhoos

## Pajupill
URL: https://www.opiq.ee/kit/188/chapter/10589
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 4.3
Topics ET: matemaatika, pajupill
Topics RU: математика
Topics EN: mathematics
Headings: Pajupill
Task examples: Tõmba taktijooned töövihikus ja koputa rütmiharjutusi kahe käega korraga.

## Mutionu pidu
URL: https://www.opiq.ee/kit/188/chapter/10590
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.1
Topics ET: matemaatika, mutionu, pidu
Topics RU: математика
Topics EN: mathematics
Headings: Mutionu pidu

## Teele, teele, kurekesed!
URL: https://www.opiq.ee/kit/188/chapter/10591
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.2
Topics ET: matemaatika, teele, kurekesed
Topics RU: математика
Topics EN: mathematics
Headings: Teele, teele, kurekesed!
Task examples: Lahenda ristsõna. Vastuseks saad eesti rahvapilli.; Leia ja kirjuta pilvedelt sõnarütm ning joonista pilt töövihikusse. Esita rütmid.

## Jänkupoju
URL: https://www.opiq.ee/kit/188/chapter/10592
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.3
Topics ET: matemaatika, jänkupoju
Topics RU: математика
Topics EN: mathematics
Headings: Jänkupoju

## Kus on kulli pesake
URL: https://www.opiq.ee/kit/188/chapter/10593
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.4
Topics ET: matemaatika, kulli, pesake
Topics RU: математика
Topics EN: mathematics
Headings: Kus on kulli pesake
Task examples: Täida lüngad ja harjuta noodikirja töövihikus.

## Tehke järele!
URL: https://www.opiq.ee/kit/188/chapter/10594
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.5
Topics ET: matemaatika, tehke, järele
Topics RU: математика
Topics EN: mathematics
Headings: Tehke järele!
Task examples: Kirjuta JO-aste noodijoonestikule töövihikus.

## Nõõ, las käia!
URL: https://www.opiq.ee/kit/188/chapter/10595
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.6
Topics ET: matemaatika, käia
Topics RU: математика
Topics EN: mathematics
Headings: Nõõ, las käia!

## Lenda, pääsulind
URL: https://www.opiq.ee/kit/188/chapter/10596
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.7
Topics ET: matemaatika, lenda, pääsulind
Topics RU: математика
Topics EN: mathematics
Headings: Lenda, pääsulind

## Karupoja hällilaul
URL: https://www.opiq.ee/kit/188/chapter/10597
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.8
Topics ET: matemaatika, karupoja, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Karupoja hällilaul
Task examples: Pane taktimõõt. Kirjuta astmenimed nootide alla ja astmed noodijoonestikule töövihikus. Laula astmenimede ja käemärkidega.

## Vares
URL: https://www.opiq.ee/kit/188/chapter/10598
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 5.9
Topics ET: matemaatika, vares
Topics RU: математика
Topics EN: mathematics
Headings: Vares
Task examples: Jaga rütm taktidesse töövihikus ja esita harjutused kahe käega korraga.

## Kodulaul
URL: https://www.opiq.ee/kit/188/chapter/10599
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 6.1
Topics ET: matemaatika, kodulaul
Topics RU: математика
Topics EN: mathematics
Headings: Kodulaul
Task examples: Kirjuta LE-aste värviliselt noodijoonestikule töövihikus. Laula.; Kirjuta taktimõõt ja astmenimed töövihikus. Laula koos käemärkidega.

## Vennad on mul suured mehed
URL: https://www.opiq.ee/kit/188/chapter/10600
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 6.2
Topics ET: matemaatika, vennad, suured, mehed
Topics RU: математика
Topics EN: mathematics
Headings: Vennad on mul suured mehed

## Sünnipäevalaul
URL: https://www.opiq.ee/kit/188/chapter/10601
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 6.3
Topics ET: matemaatika, sünnipäevalaul
Topics RU: математика
Topics EN: mathematics
Headings: Sünnipäevalaul

## Minu paps
URL: https://www.opiq.ee/kit/188/chapter/10602
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 6.4
Topics ET: matemaatika, paps
Topics RU: математика
Topics EN: mathematics
Headings: Minu paps
Task examples: Kuula muusikat ja joonista pilt oma perest töövihikusse.

## Jorupill Jonn
URL: https://www.opiq.ee/kit/188/chapter/10603
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 6.5
Topics ET: matemaatika, jorupill, jonn
Topics RU: математика
Topics EN: mathematics
Headings: Jorupill Jonn
Task examples: Iseloomusta oma perekonnaliikmeid. Leia ja ühenda joonega töövihikus igaühele sobivad omadussõnad.

## Kui mind keegi ei sunniks
URL: https://www.opiq.ee/kit/188/chapter/10604
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 6.6
Topics ET: matemaatika, mind, keegi, sunniks
Topics RU: математика
Topics EN: mathematics
Headings: Kui mind keegi ei sunniks

## Mardilaul
URL: https://www.opiq.ee/kit/188/chapter/10605
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 7.1
Topics ET: matemaatika, mardilaul
Topics RU: математика
Topics EN: mathematics
Headings: Mardilaul

## Poistelaul
URL: https://www.opiq.ee/kit/188/chapter/10606
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 7.2
Topics ET: matemaatika, poistelaul
Topics RU: математика
Topics EN: mathematics
Headings: Poistelaul

## Tondimäng
URL: https://www.opiq.ee/kit/188/chapter/10607
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 7.3
Topics ET: matemaatika, tondimäng
Topics RU: математика
Topics EN: mathematics
Headings: Tondimäng

## Altmäe rebane
URL: https://www.opiq.ee/kit/188/chapter/10608
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 7.4
Topics ET: matemaatika, altmäe, rebane
Topics RU: математика
Topics EN: mathematics
Headings: Altmäe rebane

## Talurahva mäng
URL: https://www.opiq.ee/kit/188/chapter/10609
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 7.5
Topics ET: matemaatika, talurahva, mäng
Topics RU: математика
Topics EN: mathematics
Headings: Talurahva mäng

## Kadrilaul
URL: https://www.opiq.ee/kit/188/chapter/10610
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 8.1
Topics ET: matemaatika, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kadrilaul

## Kivikasukas
URL: https://www.opiq.ee/kit/188/chapter/10611
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 8.2
Topics ET: matemaatika, kivikasukas
Topics RU: математика
Topics EN: mathematics
Headings: Kivikasukas

## Laula, laula, lapsuke
URL: https://www.opiq.ee/kit/188/chapter/10612
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 8.3
Topics ET: matemaatika, laula, lapsuke, kõnekaanon
Topics RU: математика
Topics EN: mathematics
Headings: Laula, laula, lapsuke; KÕNEKAANON

## Rongisõit
URL: https://www.opiq.ee/kit/188/chapter/10613
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 9.1
Topics ET: matemaatika, rongisõit, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Rongisõit; Tähesegadik
Task examples: Tõmba taktijooned töövihikus ja esita rütmikaanon koos klassikaaslasega.; Kirjuta viis noodijoonestikule töövihikus. Täida lüngad ja esita laul koos sõbraga (küsija, vastaja). Värvi valgusfooris õige tuli.

## Paadilaul
URL: https://www.opiq.ee/kit/188/chapter/10614
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 9.2
Topics ET: matemaatika, paadilaul
Topics RU: математика
Topics EN: mathematics
Headings: Paadilaul
Task examples: Täida taktid oma rütmiga töövihikus. Esita harjutused.; Kuula muusikat ja joonista mereteemaline pilt töövihikusse. Pane pildile pealkiri.

## Laevuke läks merele
URL: https://www.opiq.ee/kit/188/chapter/10615
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 9.3
Topics ET: matemaatika, laevuke, läks, merele, harjutused
Topics RU: математика
Topics EN: mathematics
Headings: Laevuke läks merele; Harjutused

## Muti metroo
URL: https://www.opiq.ee/kit/188/chapter/10616
Book: Muusikamaa – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 2._klassi_muusika­õpetus
Chapter ID: 9.4
Topics ET: matemaatika, muti, metroo
Topics RU: математика
Topics EN: mathematics
Headings: Muti metroo
Task examples: Kirjuta taktimõõt ja astmenimed töövihikus. Laula ja dirigeeri kaasa.

## Eesti Pärimus­muusika Keskuse õppevideod – Opiq
URL: https://www.opiq.ee/Kit/Details/465
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 182
Topics ET: matemaatika, eesti, pärimus, muusika, keskuse, õppevideod, opiq
Topics RU: математика
Topics EN: mathematics

## Eesti Pärimus­muusika Keskuse õppevideod – Opiq
URL: https://www.opiq.ee/Kit/Details/465
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 216
Topics ET: matemaatika, eesti, pärimus, muusika, keskuse, õppevideod, opiq
Topics RU: математика
Topics EN: mathematics

## Väikekannel
URL: https://www.opiq.ee/kit/465/chapter/25281
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.1
Topics ET: matemaatika, väikekannel, väikekandle, mängutehnikad, sissejuhatus, katmistehnika, noppimistehnika, sõrmitsemine, segatehnika, koos
Topics RU: математика
Topics EN: mathematics
Headings: Väikekannel; Väikekannel ja väikekandle mängutehnikad; Sissejuhatus; Katmistehnika; Noppimistehnika ehk sõrmitsemine; Segatehnika; Segatehnika koos sõrme tõstmisega; Flažolett; Ümberhäälestamine

## Karmoška
URL: https://www.opiq.ee/kit/465/chapter/25289
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.10
Topics ET: matemaatika, karmoška
Topics RU: математика
Topics EN: mathematics
Headings: Karmoška

## Mandoliin
URL: https://www.opiq.ee/kit/465/chapter/25287
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.11
Topics ET: matemaatika, mandoliin
Topics RU: математика
Topics EN: mathematics
Headings: Mandoliin

## Viled
URL: https://www.opiq.ee/kit/465/chapter/25285
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.2
Topics ET: matemaatika, viled, vilepill
Topics RU: математика
Topics EN: mathematics
Headings: Viled; Vilepill

## Sarved
URL: https://www.opiq.ee/kit/465/chapter/25291
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.3
Topics ET: matemaatika, sarved
Topics RU: математика
Topics EN: mathematics
Headings: Sarved

## Parmupill
URL: https://www.opiq.ee/kit/465/chapter/25283
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.4
Topics ET: matemaatika, parmupill
Topics RU: математика
Topics EN: mathematics
Headings: Parmupill

## Torupill
URL: https://www.opiq.ee/kit/465/chapter/25282
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.5
Topics ET: matemaatika, torupill
Topics RU: математика
Topics EN: mathematics
Headings: Torupill

## Hiiu kannel
URL: https://www.opiq.ee/kit/465/chapter/25284
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.6
Topics ET: matemaatika, hiiu, kannel
Topics RU: математика
Topics EN: mathematics
Headings: Hiiu kannel

## Viiul
URL: https://www.opiq.ee/kit/465/chapter/25288
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.7
Topics ET: matemaatika, viiul
Topics RU: математика
Topics EN: mathematics
Headings: Viiul

## Uuemad kandled
URL: https://www.opiq.ee/kit/465/chapter/25290
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.8
Topics ET: matemaatika, uuemad, kandled, sissejuhatus, mängutehnikad
Topics RU: математика
Topics EN: mathematics
Headings: Uuemad kandled; Sissejuhatus; Uuemad kandled ja mängutehnikad

## Lõõtspill
URL: https://www.opiq.ee/kit/465/chapter/25286
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 1.9
Topics ET: matemaatika, lõõtspill
Topics RU: математика
Topics EN: mathematics
Headings: Lõõtspill

## Vanem rahvalaul ehk regilaul
URL: https://www.opiq.ee/kit/465/chapter/25292
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 2.1
Topics ET: matemaatika, aeg, kell, kalender, vanem, rahvalaul, regilaul, lüroeepilised, laulud, loomislaul, kandle, tegemine, lüürilised
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Vanem rahvalaul ehk regilaul; Regilaul; Lüroeepilised laulud; "Loomislaul"; "Kandle tegemine"; Lüürilised laulud; "Laula, laula, suukene"; Loitsud; "Koerasõnad", "Valuvõtusõnad", "Ussisõnad"; "Mine üle, vihmakene", "Mustlase tants"; Itkud; Töölaulud; "Helletus"; "Seto karjaselaul"; "Lõikuslaul"; Kalendrilaulud; Kiigelaulud; "Kiik tahab kindaid" (Kolga-Jaani); "Kiik tahab kindaid" (Jõelähtme); Mardipäev; "Mardid tänavad"; "Mardiaja ootamine" ja "Martide tulemine"; "Mardid ukse taga"; "Mardiandide palumine"; Kadripäev; "Õnne soovimine"; "Kadrid ukse taga"; "Kadriandide palumine"; Jõulud; "Jõululaul"; "Kuningamäng" (Tori); "Kuningamäng" (Mustjala); "Vastlalaul"; Vastlad; Vastlavurr; "Vurri sõnad"; Vurri sõnad; Lastelaulud; Rütmiline lugemine; "So-so-so-so soorimoori"; "Kits kile karja"; "Sõmeralt Sõrmikule"; Liisusalmid; "Vares vaga, saba taga", "Ein, zwei, drei", "Endel-tendel trikatrai"; Rütmilised lugemised; "Nädalapäevad" ja "Sõrmede nimetused"; "Kell üks"; "Nädalapäevad"; Lõputa lugu "Jänesel olid pikad jäljed"; Lõputa lugu; "Roti pulmad"

## Uuem rahvalaul
URL: https://www.opiq.ee/kit/465/chapter/25293
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 2.2
Topics ET: matemaatika, uuem, rahvalaul, kakskümmend, aastat, olen, lõõtspill, pandiks, terve, küla
Topics RU: математика
Topics EN: mathematics
Headings: Uuem rahvalaul; Rahvalaul; "Kakskümmend aastat olen ma"; "Lõõtspill pandiks"; "Terve no küla seda näeb"; "Lenda, lenda, lepalind"; "Kui lauba õhtu jõudis"

## Laulumängud
URL: https://www.opiq.ee/kit/465/chapter/25294
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 2.3
Topics ET: matemaatika, taim, taimed, puu, lill, laulumängud, vanemad, rikka, vaesemäng, till, lippu, linnaksed, kuningamäng
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Laulumängud; Vanemad laulumängud; "Rikka- ja vaesemäng"; "Till-lill-lippu linnaksed"; "Kuningamäng" (Tori); "Kuningamäng" (Mustjala); Uuemad laulumängud; "Aadamal oli seitse poega"; "Oh sa kena tammekene"

## Labajalg
URL: https://www.opiq.ee/kit/465/chapter/25295
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 3.1
Topics ET: matemaatika, labajalg, voortants, kolonntants
Topics RU: математика
Topics EN: mathematics
Headings: Labajalg; Labajalg. Voortants; Labajalg. Kolonntants

## Reinlender
URL: https://www.opiq.ee/kit/465/chapter/25296
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 3.2
Topics ET: matemaatika, reinlender, reinlenderi, õpetus
Topics RU: математика
Topics EN: mathematics
Headings: Reinlender; Reinlenderi õpetus

## Lepaseree
URL: https://www.opiq.ee/kit/465/chapter/25297
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 4.1
Topics ET: matemaatika, lepaseree
Topics RU: математика
Topics EN: mathematics
Headings: Lepaseree

## Zene
URL: https://www.opiq.ee/kit/465/chapter/25298
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 4.2
Topics ET: matemaatika, zene
Topics RU: математика
Topics EN: mathematics
Headings: Zene

## Tintura
URL: https://www.opiq.ee/kit/465/chapter/25299
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 4.3
Topics ET: matemaatika, tintura
Topics RU: математика
Topics EN: mathematics
Headings: Tintura

## Tradimus
URL: https://www.opiq.ee/kit/465/chapter/25300
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 4.4
Topics ET: matemaatika, tradimus, koosmäng
Topics RU: математика
Topics EN: mathematics
Headings: Tradimus; Koosmäng. Tradimus

## RandmarMihkelThomas
URL: https://www.opiq.ee/kit/465/chapter/25301
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 4.5
Topics ET: matemaatika, randmarmihkelthomas
Topics RU: математика
Topics EN: mathematics
Headings: RandmarMihkelThomas

## Duo Mann ja Juula
URL: https://www.opiq.ee/kit/465/chapter/25302
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 4.6
Topics ET: matemaatika, mann, juula
Topics RU: математика
Topics EN: mathematics
Headings: Duo Mann ja Juula

## Mardipäev
URL: https://www.opiq.ee/kit/465/chapter/25303
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 5.1
Topics ET: matemaatika, mardipäev, kadripäev, mardiaja, ootamine, martide, tulemine, mardid, ukse, taga
Topics RU: математика
Topics EN: mathematics
Headings: Mardipäev; Mardipäev ja kadripäev; "Mardiaja ootamine" ja "Martide tulemine"; "Mardid ukse taga"; "Mardiandide palumine"; "Mardid tänavad"

## Kadripäev
URL: https://www.opiq.ee/kit/465/chapter/25304
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 5.2
Topics ET: matemaatika, kadripäev, kadrid, ukse, taga, kadriandide, palumine, õnne, soovimine
Topics RU: математика
Topics EN: mathematics
Headings: Kadripäev; "Kadrid ukse taga"; "Kadriandide palumine"; "Õnne soovimine"

## Jõulud
URL: https://www.opiq.ee/kit/465/chapter/25305
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 5.3
Topics ET: matemaatika, jõulud, jõululaul, kuningamäng
Topics RU: математика
Topics EN: mathematics
Headings: Jõulud; "Jõululaul"; "Kuningamäng"

## Vastlad
URL: https://www.opiq.ee/kit/465/chapter/25306
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 5.4
Topics ET: matemaatika, vastlad, vastlalaul, vastlavurr, vurrisõnad
Topics RU: математика
Topics EN: mathematics
Headings: Vastlad; "Vastlalaul"; Vastlavurr; "Vurrisõnad"

## Petetud härra
URL: https://www.opiq.ee/kit/465/chapter/25922
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 6.1
Topics ET: matemaatika, petetud, härra
Topics RU: математика
Topics EN: mathematics
Headings: Petetud härra

## Ahne hunt
URL: https://www.opiq.ee/kit/465/chapter/25923
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 6.2
Topics ET: matemaatika, ahne, hunt
Topics RU: математика
Topics EN: mathematics
Headings: Ahne hunt

## Surnupealuu
URL: https://www.opiq.ee/kit/465/chapter/25924
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 6.3
Topics ET: matemaatika, surnupealuu
Topics RU: математика
Topics EN: mathematics
Headings: Surnupealuu

## Elektrooniline pärimusmuusika
URL: https://www.opiq.ee/kit/465/chapter/25311
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 7.1
Topics ET: matemaatika, elektrooniline, pärimusmuusika
Topics RU: математика
Topics EN: mathematics
Headings: Elektrooniline pärimusmuusika

## Sinasõprus pärimusmuusikaga
URL: https://www.opiq.ee/kit/465/chapter/25312
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 7.2
Topics ET: matemaatika, sinasõprus, pärimusmuusikaga
Topics RU: математика
Topics EN: mathematics
Headings: Sinasõprus pärimusmuusikaga

## Sõnaseletused
URL: https://www.opiq.ee/kit/465/chapter/25308
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 8.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Allikaviited
URL: https://www.opiq.ee/kit/465/chapter/25921
Book: Eesti Pärimus­muusika Keskuse õppevideod – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_pärimus­muusika_keskuse_õppevideod
Chapter ID: 8.2
Topics ET: matemaatika, allikaviited, rahvapillid, väikekannel, uuemad, kandled, rahvalaul, regilaul, uuem, laulumängud
Topics RU: математика
Topics EN: mathematics
Headings: Allikaviited; Rahvapillid; Väikekannel; Uuemad kandled; Rahvalaul; Regilaul; Uuem rahvalaul; Laulumängud; Pärimustants; Labajalg; Reinlender; Koosmäng; Lepaseree; Zene; Tintura; Tradimus; RandmarMihkelThomas; Duo Mann ja Juula; Rahvakalendri tähtpäevad; Mardipäev; Kadripäev; Jõulud; Vastlad; Rahvajutud ja pärimusmuusika; Petetud härra; Ahne hunt; Surnupealuu; Koolikontserdid; Elektrooniline pärimusmuusika; Sinasõprus pärimusmuusikaga

## Muusikaõpik 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/193
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 119
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikaõpik 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/193
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 150
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Rütm
URL: https://www.opiq.ee/kit/193/chapter/10970
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, rütm, sammude, korrastaja, kordame, rütme, kellel, neli, kaunist
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Rütm; Sammude korrastaja; Kordame rütme; Kellel neli kaunist kleiti?; Kuulamiskool; Kirju sügis, tere!
Task examples: Kirjuta oma sõnadega.

## Eesti rahvapillid
URL: https://www.opiq.ee/kit/193/chapter/10979
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.10
Topics ET: matemaatika, eesti, rahvapillid, igaühel, pill, hüüud, helinad, kandle, tegemine
Topics RU: математика
Topics EN: mathematics
Headings: Eesti rahvapillid; Igaühel oma pill; Hüüud ja helinad; Kandle tegemine; Torupill
Task examples: Uuri laulusõnu. Märgi õiged vastused ja kirjuta oma arvamus.; Lohista pilliosade nimetused pildile.

## LE-aste
URL: https://www.opiq.ee/kit/193/chapter/10980
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.11
Topics ET: matemaatika, aste, vahel, lipp, lipi, peal, altmäe, rebane, lapitekk
Topics RU: математика
Topics EN: mathematics
Headings: LE-aste; JO ja MI vahel; Lipp lipi peal; Altmäe rebane; Lapitekk; Köha pere
Task examples: Otsusta, kas väide on tõene või väär. Märgi õige vastus.; Otsusta, kas väide on tõene või väär. Märgi õige vastus.

## Koosseisud
URL: https://www.opiq.ee/kit/193/chapter/10981
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.12
Topics ET: matemaatika, koosseisud, üksi, üheskoos, solist, ansambel, koor, lauljate, pidu
Topics RU: математика
Topics EN: mathematics
Headings: Koosseisud; Üksi ja üheskoos; Solist; Ansambel; Koor; Lauljate pidu; Kõnekoor
Task examples: Jaota nimed ja nimetused kolme rühma.; Märgi õiged vastused.

## Jõulud
URL: https://www.opiq.ee/kit/193/chapter/10982
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.13
Topics ET: matemaatika, aeg, kell, kalender, jõulud, harras, päikese, austamise, püha, uued, vanad, jõulukombed
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Jõulud; Harras aeg; Päikese austamise püha; Uued ja vanad jõulukombed; Jõudke, jõulud!; Jõulud jõudvad; Kiire aeg; Jõuluõhtul; Kuulamiskool; Kui armsast jõulupuu nüüd hiilgab; Tiliseb, tiliseb aisakell; Haldjate soovilaul
Task examples: Märgi õiged vastused.; Märgi vastused. Kirjuta oma pere jõulukommetest.

## Noodipikkused
URL: https://www.opiq.ee/kit/193/chapter/10971
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.2
Topics ET: matemaatika, noodipikkused, nooti, mõõda, lauluga, meetrum, tempo, kaks, kolm
Topics RU: математика
Topics EN: mathematics
Headings: Noodipikkused; Nooti mõõda lauluga; Meetrum ja tempo; Üks, kaks ja kolm lööki; Rongi hädapiduri lauluke; Kuulamiskool; Sääsesaks
Task examples: Märgi õiged vastused.; Kirjuta lünka õige arv lööke.

## Takt ja taktimõõt
URL: https://www.opiq.ee/kit/193/chapter/10972
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.3
Topics ET: matemaatika, takt, taktimõõt, rütmide, raamid, rõhulisest, rõhuliseni, kaks, alati
Topics RU: математика
Topics EN: mathematics
Headings: Takt ja taktimõõt; Rütmide raamid; Rõhulisest rõhuliseni; Üks, kaks, alati!; Õpetajale; Vara tõusen ma; Pausi laul; Vihmapiiskade tants
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## SO- ja MI-aste
URL: https://www.opiq.ee/kit/193/chapter/10973
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.4
Topics ET: matemaatika, aste, laulukaaslased, joonel, vahes, kuku, kuulamiskool, mary
Topics RU: математика
Topics EN: mathematics
Headings: SO- ja MI-aste; Laulukaaslased; Joonel ja vahes; Kuku; Kuulamiskool; Mary
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## RA-aste
URL: https://www.opiq.ee/kit/193/chapter/10974
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.5
Topics ET: matemaatika, aste, ülemine, naaber, kõrvuti, kõrgemal, tihane, kuulamiskool
Topics RU: математика
Topics EN: mathematics
Headings: RA-aste; Ülemine naaber; Kõrvuti ja kõrgemal; Tihane; Kuulamiskool
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Plaatpillid
URL: https://www.opiq.ee/kit/193/chapter/10975
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.6
Topics ET: matemaatika, plaatpillid, laulule, kaasa, peamised, saatepillid, kellamäng, kellatorn
Topics RU: математика
Topics EN: mathematics
Headings: Plaatpillid; Laulule kaasa; Peamised saatepillid; Kellamäng; Kellatorn

## Aastaajad muusikas
URL: https://www.opiq.ee/kit/193/chapter/10976
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.7
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, aastaajad, kevad, suvi, sügis, talv, muusikas, ilma, meeleolud, helis, pildis, loomingus
Topics RU: математика, природа, природоведение, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: mathematics, nature, science, environment, seasons, spring, summer, autumn, winter
Headings: Aastaajad muusikas; Ilma meeleolud helis ja pildis; Loodus loomingus; Antonio Vivaldi; Aastaajad; Kuulamiskool
Task examples: Lohista aastaaegade nimetused pildile.; Vaata Richard Uutmaa maali ja märgi pildiga sobivad helid. Kirjuta veel teisigi südasuviseid hääli ja helisid.

## Sügis
URL: https://www.opiq.ee/kit/193/chapter/10977
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.8
Topics ET: matemaatika, aeg, kell, kalender, aastaajad, kevad, suvi, sügis, talv, värvide, vaikselt, valjult, tuuled, nüüd, puhuvad, seenelaul
Topics RU: математика, время, часы, календарь, времена года, весна, лето, осень, зима
Topics EN: mathematics, time, clock, calendar, seasons, spring, summer, autumn, winter
Headings: Sügis; Värvide aeg; Vaikselt ja valjult; Tuuled nüüd puhuvad; Seenelaul; Mehikene metsas; Oi, oi õunu ilusaid
Task examples: Jaota sügishääled kahte rühma.

## Mardi- ja kadripäev
URL: https://www.opiq.ee/kit/193/chapter/10978
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 1.9
Topics ET: matemaatika, mardi, kadripäev, õnne, hoidjad, rahvakalender, tantsulaul, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Mardi- ja kadripäev; Õnne hoidjad; Rahvakalender; Mardi tantsulaul; Kadrilaul
Task examples: Märgi õiged vastused.; Lohista märksõnad õigesse veergu.

## Talv
URL: https://www.opiq.ee/kit/193/chapter/10983
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.1
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, aastaajad, kevad, suvi, sügis, talv, lumised, lood, puhkab, head, aastat, jälle
Topics RU: математика, природа, природоведение, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: mathematics, nature, science, environment, seasons, spring, summer, autumn, winter
Headings: Talv; Lumised lood; Loodus puhkab; Head uut aastat!; Talv on jälle tulnud; Talvetaat on meie maal; Külma ilma õuelaul; Uisutamas; Kelgusõit; Suusaretk metsa; Kuulamiskool; Saanisõit; Lumesõda; Lumesadu; Kü-kü-kü-kü-külm
Task examples: Vaata Anton Agu Särgava maali ja märgi sellega sobivad helid. Kirjuta veel teisigi talviseid hääli ja helisid.

## Rahvatants
URL: https://www.opiq.ee/kit/193/chapter/10992
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.10
Topics ET: matemaatika, rahvatants, oige, vasemba, rõõmu, väljendus, labajalg, kuulamiskool, peened
Topics RU: математика
Topics EN: mathematics
Headings: Rahvatants; Oige ja vasemba; Rõõmu väljendus; Labajalg; Kuulamiskool; Peened sörmed; Kaks sammu sissepoole; Kiiguri-kaaguri; Kaera-Jaan
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Rütmiorkester
URL: https://www.opiq.ee/kit/193/chapter/10993
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.11
Topics ET: matemaatika, rütmiorkester, igaühel, pill, tombi, toomas, kõlatoru, kuljused, marakas, laste
Topics RU: математика
Topics EN: mathematics
Headings: Rütmiorkester; Igaühel oma pill; Tombi-Toomas; Kõlatoru, kuljused ja marakas; Laste marss

## Suvi
URL: https://www.opiq.ee/kit/193/chapter/10994
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.12
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, vaba, tuul, kõik, maailma, värvid, mina, olen
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Suvi; Vaba kui tuul; Kõik maailma värvid; Mina olen rikas mees; Linavästrik; Kuulamiskool; Lõoke; Mesilind
Task examples: Vaata Johann Köhleri maali ja märgi sellega sobivad helid ja värvid. Kirjuta veel teisigi südasuviseid helisid ja värve.

## JO-aste
URL: https://www.opiq.ee/kit/193/chapter/10984
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.2
Topics ET: matemaatika, aste, lõbus, rändur, võtmega, isik, kuulamiskool, vana, toomas
Topics RU: математика
Topics EN: mathematics
Headings: JO-aste; Lõbus rändur; Võtmega isik; Kop-kop-kop; Kuulamiskool; Vana Toomas; Rätsepmeister kakaduu; Lõbus talvelaul
Task examples: Kus on MI ja SO, kui JO on vahes?; Märgi õiged vastused.

## Riho Päts
URL: https://www.opiq.ee/kit/193/chapter/10985
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.3
Topics ET: matemaatika, riho, päts, õpetajate, kuulamiskool, muti, metroo
Topics RU: математика
Topics EN: mathematics
Headings: Riho Päts; Õpetajate õpetaja; Kuulamiskool; Muti metroo
Task examples: Märgi õiged vastused.; Märgi kõik laulus nimetatud metrooreisijad.

## Vastlapäev ehk lihaheitepäev
URL: https://www.opiq.ee/kit/193/chapter/10986
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.4
Topics ET: matemaatika, vastlapäev, lihaheitepäev, kelguga, liumäel, tuleb, vastlalaul, kelguta
Topics RU: математика
Topics EN: mathematics
Headings: Vastlapäev ehk lihaheitepäev; Kelguga liumäel; Vastlapäev tuleb; Vastlalaul; Kelguga ja kelguta
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Eesti
URL: https://www.opiq.ee/kit/193/chapter/10987
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.5
Topics ET: matemaatika, eesti, meie, kodu, isamaa, õitse, müha, meri, rõõm
Topics RU: математика
Topics EN: mathematics
Headings: Eesti; Meie kodu; Meie isamaa; Õitse, maa, ja müha, meri; Mu isamaa, mu õnn ja rõõm; Järve taga haljad aasad; Ristik
Task examples: Märgi õiged vastused.

## Rahvalaul
URL: https://www.opiq.ee/kit/193/chapter/10988
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.6
Topics ET: matemaatika, rahvalaul, lugu, sõnajalaõiest, teisi, muistendeid, esivanemate, pärand, kits
Topics RU: математика
Topics EN: mathematics
Headings: Rahvalaul; Lugu sõnajalaõiest ja teisi muistendeid; Esivanemate pärand; Kits karja; Kui mina hakkan laulemaie; Nekrutilaul; Andke maada; Heeringalaul
Task examples: Vali lausesse õiged sõnad.; Märgi õiged vastused.

## René Eespere
URL: https://www.opiq.ee/kit/193/chapter/10989
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.7
Topics ET: matemaatika, eespere, viisid, nukurahvale, seitsme, mere, taga, tuttavaid, lastelaule
Topics RU: математика
Topics EN: mathematics
Headings: René Eespere; Viisid nukurahvale; Seitsme maa ja mere taga; Tuttavaid lastelaule
Task examples: Märgi õiged vastused.

## Kevad
URL: https://www.opiq.ee/kit/193/chapter/10990
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.8
Topics ET: matemaatika, aeg, kell, kalender, loodus, loodusõpetus, keskkond, aastaajad, kevad, suvi, sügis, talv, laulab, kollase, valguse, kevadekuulutajad, kevadpühad, lumememme
Topics RU: математика, время, часы, календарь, природа, природоведение, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: mathematics, time, clock, calendar, nature, science, environment, seasons, spring, summer, autumn, winter
Headings: Kevad; Loodus laulab; Kollase valguse aeg; Kevadekuulutajad; Kevadpühad; Lumememme kevad; Kevadekell; Kiigelaul; Vihmaussi kevad
Task examples: Vaata Paul Gerhard Roseni maali ja märgi kõik sellega sobivad helid. Kirjuta veel teisigi kevadhääli ja -helisid.; Vali lausele sobiv lõpp.

## RA,- ja SO,-aste
URL: https://www.opiq.ee/kit/193/chapter/10991
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 2.9
Topics ET: matemaatika, aste, alumised, naabrid, teisiti, tähistatud, trilla, tralla, tantsulaul
Topics RU: математика
Topics EN: mathematics
Headings: RA,- ja SO,-aste; JO alumised naabrid; Teisiti tähistatud; Trilla-tralla tantsulaul; Kuulamiskool
Task examples: Kui JO on joonel, siis kus asub alumine RA?; Märgi õiged vastused.

## Lauluvara
URL: https://www.opiq.ee/kit/193/chapter/10995
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 3.1
Topics ET: matemaatika, lauluvara, kogu, hingest, metsa, laulma, kaks, väikest, lindu, sünnipäevalaul
Topics RU: математика
Topics EN: mathematics
Headings: Lauluvara; Kogu hingest; Metsa laulma; Kaks väikest lindu; Sünnipäevalaul; Tingel-tangel; Kõrv lukus; Tudu, tudule; Kuulamiskool; Kullimäng; Karupoeg Puhhi lauluke; Laulumäng; Meistrimehed; Mul on hobu; Nõõ, las käia!; Küpse, küpse, kakuke; Liisutus; Lapimaa ja Kapimaa; Ma olen väike karjane; Jänku jenka; Kaks Otti; Mäeküla taadi talu; Emadepäeva laul; Mida tuleb autos teha?; Valgusfoor; Koogitegu; Lauluga me lähme metsa; Vanaema; Kahekõne; Hülgeviga

## Laulude tähestikuline loetelu
URL: https://www.opiq.ee/kit/193/chapter/19530
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 3.2
Topics ET: matemaatika, laulude, tähestikuline, loetelu
Topics RU: математика
Topics EN: mathematics
Headings: Laulude tähestikuline loetelu; A–K; L–P; R–Ü

## Kuuekeelne väikekannel
URL: https://www.opiq.ee/kit/193/chapter/10996
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 3.3
Topics ET: matemaatika, kuuekeelne, väikekannel, muistne, pill, mänguvõtted, rätsepmeister, kakaduu, käia, tigu
Topics RU: математика
Topics EN: mathematics
Headings: Kuuekeelne väikekannel; Muistne pill; Mänguvõtted; Rätsepmeister kakaduu; Nõõ, las käia!; Tigu-ligu

## Mõisted
URL: https://www.opiq.ee/kit/193/chapter/10997
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 3.4
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/193/chapter/19529
Book: Muusikaõpik 2. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile
Chapter ID: 3.5
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Muusikaõpik 2. klassile 2024 – Opiq
URL: https://www.opiq.ee/Kit/Details/556
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 151
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikaõpik 2. klassile 2024 – Opiq
URL: https://www.opiq.ee/Kit/Details/556
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 181
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Rütm
URL: https://www.opiq.ee/kit/556/chapter/31279
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.1
Topics ET: matemaatika, rütm, sammude, korrastaja, mina, hakkan, laulemaie, haldjate, laul, läks
Topics RU: математика
Topics EN: mathematics
Headings: Rütm; Sammude korrastaja; Kui mina hakkan laulemaie; Haldjate laul; Läks lahti; Kordame rütme

## Eesti rahvapillid
URL: https://www.opiq.ee/kit/556/chapter/31288
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.10
Topics ET: matemaatika, eesti, rahvapillid, igaühel, pill, hüüud, helinad, kandle, tegemine
Topics RU: математика
Topics EN: mathematics
Headings: Eesti rahvapillid; Igaühel oma pill; Hüüud ja helinad; Kandle tegemine; Torupill
Task examples: Uuri laulusõnu. Märgi õiged vastused ja kirjuta oma arvamus.; Lohista pilliosade nimetused pildile.

## LE-aste
URL: https://www.opiq.ee/kit/556/chapter/31289
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.11
Topics ET: matemaatika, aste, vahel, lipp, lipi, peal, kõnekoor, altmäe, rebane
Topics RU: математика
Topics EN: mathematics
Headings: LE-aste; JO ja MI vahel; Lipp lipi peal; Kõnekoor; Altmäe rebane; Leidsin muusika
Task examples: Otsusta, kas väide on tõene või väär. Märgi õige vastus.; Otsusta, kas väide on tõene või väär. Märgi õige vastus.

## Koosseisud
URL: https://www.opiq.ee/kit/556/chapter/31290
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.12
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, koosseisud, üksi, üheskoos, solist, ansambel, koor, lauljate, pidu
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Koosseisud; Üksi ja üheskoos; Solist; Ansambel; Koor; Lauljate pidu; Talvetaat on meie maal; Külma ilma õuelaul; Karupoeg Puhhi lauluke; Kuulamiskool; Talv on jälle tulnud
Task examples: Jaota nimed ja nimetused kolme rühma.; Märgi õiged vastused.

## Jõulud
URL: https://www.opiq.ee/kit/556/chapter/31291
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.13
Topics ET: matemaatika, aeg, kell, kalender, jõulud, harras, jõudvad, päikese, austamise, püha, uued, vanad
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Jõulud; Harras aeg; Jõulud jõudvad; Päikese austamise püha; Uued ja vanad jõulukombed; Jõudke, jõulud!; Kullimäng; Talveilma rõõmulaul; Jõuluõhtul; Kuulamiskool; Kui armsast jõulupuu nüüd hiilgab; Haldjate soovilaul; Tiliseb, tiliseb aisakell; Head uut aastat!; Uisutamas
Task examples: Märgi õiged vastused.; Märgi vastused. Kirjuta oma pere jõulukommetest.

## Noodipikkused
URL: https://www.opiq.ee/kit/556/chapter/31280
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.2
Topics ET: matemaatika, noodipikkused, nooti, mõõda, lauluga, meetrum, tempo, kaks, kolm
Topics RU: математика
Topics EN: mathematics
Headings: Noodipikkused; Nooti mõõda lauluga; Meetrum ja tempo; Üks, kaks ja kolm lööki; Rongi hädapiduri lauluke; Kuulamiskool; Sääsesaks
Task examples: Märgi õiged vastused.; Kirjuta lünka õige arv lööke.

## Takt ja taktimõõt
URL: https://www.opiq.ee/kit/556/chapter/31281
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.3
Topics ET: matemaatika, takt, taktimõõt, rütmide, raamid, vihmaballett, kaks, alati, rõhulisest
Topics RU: математика
Topics EN: mathematics
Headings: Takt ja taktimõõt; Rütmide raamid; Vihmaballett; Üks, kaks, alati!; Rõhulisest rõhuliseni; Õpetajale; Meie kiisul kriimud silmad; Vara tõusen ma; Pausi laul
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## SO- ja MI-aste
URL: https://www.opiq.ee/kit/556/chapter/31282
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.4
Topics ET: matemaatika, aste, laulukaaslased, kuku, kuulamiskool, joonel, vahes
Topics RU: математика
Topics EN: mathematics
Headings: SO- ja MI-aste; Laulukaaslased; Kuku; Kuulamiskool; Joonel ja vahes
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## RA-aste
URL: https://www.opiq.ee/kit/556/chapter/31283
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.5
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, aste, ülemine, naaber, tihane, kõrvuti, kõrgemal, kaks, väikest
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: RA-aste; Ülemine naaber; Tihane; Kõrvuti ja kõrgemal; Kaks väikest lindu; Sügis; Kured läinud; Vihmapiiskade tants; Mary; Tingel-tangel; Kõrv lukus; Kellamäng
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Plaatpillid
URL: https://www.opiq.ee/kit/556/chapter/31284
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.6
Topics ET: matemaatika, plaatpillid, laulule, kaasa, peamised, saatepillid, kellatorn, mina, päike
Topics RU: математика
Topics EN: mathematics
Headings: Plaatpillid; Laulule kaasa; Peamised saatepillid; Kellatorn; Mina ja päike; Paista, päävakene; Seenelaul; Mehikene metsas; Oi-oi õunu ilusaid

## Aastaajad muusikas
URL: https://www.opiq.ee/kit/556/chapter/31285
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.7
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, aastaajad, kevad, suvi, sügis, talv, muusikas, ilma, meeleolud, helis, pildis, kuulamiskool, loomingus
Topics RU: математика, природа, природоведение, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: mathematics, nature, science, environment, seasons, spring, summer, autumn, winter
Headings: Aastaajad muusikas; Ilma meeleolud helis ja pildis; Aastaajad; Kuulamiskool; Loodus loomingus; Antonio Vivaldi
Task examples: Lohista aastaaegade nimetused pildile.; Vaata Richard Uutmaa maali ja märgi pildiga sobivad helid. Kirjuta veel teisigi südasuviseid hääli ja helisid.

## Sügis
URL: https://www.opiq.ee/kit/556/chapter/31286
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.8
Topics ET: matemaatika, aeg, kell, kalender, aastaajad, kevad, suvi, sügis, talv, värvide, tuuled, nüüd, puhuvad, vaikselt, valjult
Topics RU: математика, время, часы, календарь, времена года, весна, лето, осень, зима
Topics EN: mathematics, time, clock, calendar, seasons, spring, summer, autumn, winter
Headings: Sügis; Värvide aeg; Tuuled nüüd puhuvad; Vaikselt ja valjult
Task examples: Jaota sügishääled kahte rühma.

## Mardi- ja kadripäev
URL: https://www.opiq.ee/kit/556/chapter/31287
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 1.9
Topics ET: matemaatika, mardi, kadripäev, õnne, hoidjad, rahvakalender, tantsulaul, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Mardi- ja kadripäev; Õnne hoidjad; Rahvakalender; Mardi tantsulaul; Kadrilaul
Task examples: Märgi õiged vastused.; Lohista märksõnad õigesse veergu.

## Talv
URL: https://www.opiq.ee/kit/556/chapter/31292
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.1
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, aastaajad, kevad, suvi, sügis, talv, lumised, lood, puhkab, tere, valged, liblikad
Topics RU: математика, природа, природоведение, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: mathematics, nature, science, environment, seasons, spring, summer, autumn, winter
Headings: Talv; Lumised lood; Loodus puhkab; Tere, valged liblikad; Tii-tii-tihane; Kuulamiskool; Lumesadu; Kü-kü-kü-kü-külm
Task examples: Vaata Anton Agu Särgava maali ja märgi sellega sobivad helid. Kirjuta veel teisigi talviseid hääli ja helisid.

## Rahvatants
URL: https://www.opiq.ee/kit/556/chapter/31301
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.10
Topics ET: matemaatika, rahvatants, oige, vasemba, kaera, jaan, kuulamiskool, rõõmu, väljendus, labajalg
Topics RU: математика
Topics EN: mathematics
Headings: Rahvatants; Oige ja vasemba; Kaera-Jaan; Kuulamiskool; Rõõmu väljendus; Labajalg; Peened sörmed; Kaks sammu sissepoole; Kiiguri-kaaguri
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Rütmiorkester
URL: https://www.opiq.ee/kit/556/chapter/31302
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.11
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, rütmiorkester, igaühel, pill, tombi, toomas, laste, marss, emadepäeva, laul
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Rütmiorkester; Igaühel oma pill; Tombi-Toomas; Laste marss; Emadepäeva laul; Kelleks saada; Mida tuleb autos teha?; Valgusfoor; Koogitegu; Vanaema; Kahekõne; Vihmaussi kevad; Mesilind; Kuulamiskool; Metsakool; Mina olen rikas mees; Linavästrik

## Suvi
URL: https://www.opiq.ee/kit/556/chapter/31303
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.12
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, vaba, tuul, kõik, maailma, värvid, lõoke
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Suvi; Vaba kui tuul; Kõik maailma värvid; Lõoke
Task examples: Vaata Johann Köhleri maali ja märgi sellega sobivad helid ja värvid. Kirjuta veel teisigi südasuviseid helisid ja värve.

## JO-aste
URL: https://www.opiq.ee/kit/556/chapter/31293
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.2
Topics ET: matemaatika, aste, lõbus, rändur, kuulamiskool, võtmega, isik, vana, toomas
Topics RU: математика
Topics EN: mathematics
Headings: JO-aste; Lõbus rändur; Kop-kop-kop; Kuulamiskool; Võtmega isik; Vana Toomas; Kelgusõit; Lõbus talvelaul; Hommikulaul; Porikärbse porin; Rätsepmeister kakaduu; Meistrimehed
Task examples: Kus on MI ja SO, kui JO on vahes?; Märgi õiged vastused.

## Riho Päts
URL: https://www.opiq.ee/kit/556/chapter/31294
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.3
Topics ET: matemaatika, riho, päts, õpetajate, muti, metroo, kuulamiskool, hobu, ämbliku
Topics RU: математика
Topics EN: mathematics
Headings: Riho Päts; Õpetajate õpetaja; Muti metroo; Kuulamiskool; Mul on hobu; Ämbliku Boogie; Rütmimäng; Kelguga ja kelguta; Talvetrall
Task examples: Märgi kõik laulus nimetatud metrooreisijad.; Uuri laulusõnu. Märgi õiged vastused.

## Vastlapäev ehk lihaheitepäev
URL: https://www.opiq.ee/kit/556/chapter/31295
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.4
Topics ET: matemaatika, vastlapäev, lihaheitepäev, kelguga, liumäel, vastlalaul, küpse, kakuke, saanisõit
Topics RU: математика
Topics EN: mathematics
Headings: Vastlapäev ehk lihaheitepäev; Kelguga liumäel; Vastlalaul; Küpse, küpse, kakuke; Saanisõit; Liisutus
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Eesti
URL: https://www.opiq.ee/kit/556/chapter/31296
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.5
Topics ET: matemaatika, eesti, meie, kodu, isamaa, õitse, müha, meri, rõõm
Topics RU: математика
Topics EN: mathematics
Headings: Eesti; Meie kodu; Meie isamaa; Õitse, maa, ja müha, meri; Mu isamaa, mu õnn ja rõõm; Sünnipäevalaul; Aja sees; Rongisõit
Task examples: Märgi õiged vastused.

## Rahvalaul
URL: https://www.opiq.ee/kit/556/chapter/31297
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.6
Topics ET: matemaatika, rahvalaul, lugu, sõnajalaõiest, teisi, muistendeid, esivanemate, pärand, kits
Topics RU: математика
Topics EN: mathematics
Headings: Rahvalaul; Lugu sõnajalaõiest ja teisi muistendeid; Esivanemate pärand; Kits karja; Kui mina hakkan laulemaie; Roti pulmad; Veere, päike; Heeringas; Lapimaa ja Kapimaa
Task examples: Vali lausesse õiged sõnad.; Märgi õiged vastused.

## René Eespere
URL: https://www.opiq.ee/kit/556/chapter/31298
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.7
Topics ET: matemaatika, eespere, viisid, nukurahvale, seitsme, mere, taga, tuttavaid, lastelaule
Topics RU: математика
Topics EN: mathematics
Headings: René Eespere; Viisid nukurahvale; Seitsme maa ja mere taga; Tuttavaid lastelaule
Task examples: Märgi õiged vastused.

## Kevad
URL: https://www.opiq.ee/kit/556/chapter/31299
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.8
Topics ET: matemaatika, aeg, kell, kalender, loodus, loodusõpetus, keskkond, aastaajad, kevad, suvi, sügis, talv, laulab, kollase, valguse, kevadekuulutajad, kevadekell, kevadpühad
Topics RU: математика, время, часы, календарь, природа, природоведение, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: mathematics, time, clock, calendar, nature, science, environment, seasons, spring, summer, autumn, winter
Headings: Kevad; Loodus laulab; Kollase valguse aeg; Kevadekuulutajad; Kevadekell; Kevadpühad; Kiigelaul; Jänku jenka
Task examples: Vaata Paul Gerhard Roseni maali ja märgi kõik sellega sobivad helid. Kirjuta veel teisigi kevadhääli ja -helisid.; Vali lausele sobiv lõpp.

## RAı- ja SOı-aste
URL: https://www.opiq.ee/kit/556/chapter/31300
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 2.9
Topics ET: matemaatika, aste, alumised, naabrid, trilla, tralla, tantsulaul, kuulamiskool, teisiti, tähistatud
Topics RU: математика
Topics EN: mathematics
Headings: RAı- ja SOı-aste; JO alumised naabrid; Trilla-tralla tantsulaul; Kuulamiskool; Teisiti tähistatud; Kaks Otti; Mäeküla taadi talu
Task examples: Kui JO on joonel, siis kus asub alumine RA?; Märgi õiged vastused.

## Laulude tähestikuline loetelu
URL: https://www.opiq.ee/kit/556/chapter/31304
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 3.1
Topics ET: matemaatika, laulude, tähestikuline, loetelu
Topics RU: математика
Topics EN: mathematics
Headings: Laulude tähestikuline loetelu; A–K; L–P; R–Ü

## Kuuekeelne väikekannel
URL: https://www.opiq.ee/kit/556/chapter/31305
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 3.2
Topics ET: matemaatika, kuuekeelne, väikekannel, muistne, pill, mänguvõtted, rätsepmeister, kakaduu, käia, tigu
Topics RU: математика
Topics EN: mathematics
Headings: Kuuekeelne väikekannel; Muistne pill; Mänguvõtted; Rätsepmeister kakaduu; Nõõ, las käia!; Tigu-ligu

## Mõisted
URL: https://www.opiq.ee/kit/556/chapter/31306
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 3.3
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/556/chapter/31307
Book: Muusikaõpik 2. klassile 2024 – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_2._klassile_2024
Chapter ID: 3.4
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Музыка – волшебная страна. 2 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/238
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 217
Topics ET: matemaatika, opiq
Topics RU: математика, музыка, волшебная, страна, класс
Topics EN: mathematics

## Музыка – волшебная страна. 2 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/238
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 329
Topics ET: matemaatika, opiq
Topics RU: математика, музыка, волшебная, страна, класс
Topics EN: mathematics

## Добрый день!
URL: https://www.opiq.ee/kit/238/chapter/13449
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, добрый, день
Topics EN: mathematics
Headings: Добрый день!

## Песенка о песенке.
URL: https://www.opiq.ee/kit/238/chapter/13450
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, песенка, песенке
Topics EN: mathematics
Headings: Песенка о песенке.; ПЕСЕНКА О ПЕСЕНКЕ
Task examples: Выполни задание в рабочей тетради. Нарисуй своё самое яркое музыкальное впечатление лета.

## Всё отлично
URL: https://www.opiq.ee/kit/238/chapter/13451
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, отлично
Topics EN: mathematics
Headings: Всё отлично; ВСЁ ОТЛИЧНО!
Task examples: Выполни задание в рабочей тетради. Вспомни и расставь знаки равенства (для записи используй простой карандаш).

## Лесная песенка
URL: https://www.opiq.ee/kit/238/chapter/13452
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, лесная, песенка
Topics EN: mathematics
Headings: Лесная песенка
Task examples: Выполни задание в рабочей тетради.

## Tipa kooliteel
URL: https://www.opiq.ee/kit/238/chapter/13453
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 1.5
Topics ET: matemaatika, tipa, kooliteel
Topics RU: математика
Topics EN: mathematics
Headings: Tipa kooliteel
Task examples: Выполни задание в рабочей тетради. Найди повторяющийся ритм стихотворения со с. 4 учебника. Запиши его и простучи на тамбурине.

## Улыбка
URL: https://www.opiq.ee/kit/238/chapter/13454
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, улыбка
Topics EN: mathematics
Headings: Улыбка
Task examples: Выполни задание в рабочей тетради. Запиши на лестнице названия известных тебе ступеней. Спой их.

## Meeril on talleke
URL: https://www.opiq.ee/kit/238/chapter/13455
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 1.7
Topics ET: matemaatika, meeril, talleke
Topics RU: математика
Topics EN: mathematics
Headings: Meeril on talleke; MEERIL OLI TALLEKE
Task examples: Выполни задание в рабочей тетради. Найди названия ступеней и прочитай стихотворение. Впиши ступени. Запиши повторяющиеся ритмы. Придумай ступени и спой песенку.

## Sügislinnuke
URL: https://www.opiq.ee/kit/238/chapter/13485
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 10.1
Topics ET: matemaatika, sügislinnuke
Topics RU: математика
Topics EN: mathematics
Headings: Sügislinnuke
Task examples: Выполни задание в рабочей тетради. Впиши названия ступеней и прочитай стихотворение. Запиши повторяющиеся ритмы и раздели их на такты. Исполни ритм на треугольнике.

## Laula, laula, lapseke
URL: https://www.opiq.ee/kit/238/chapter/13486
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 11.1
Topics ET: matemaatika, laula, lapseke
Topics RU: математика
Topics EN: mathematics
Headings: Laula, laula, lapseke
Task examples: Выполни задание в рабочей тетради. Сосчитай и запиши ответ.

## Мой гусёнок
URL: https://www.opiq.ee/kit/238/chapter/13487
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 11.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Мой гусёнок
Task examples: Выполни задание в рабочей тетради. Сочини и запиши две мелодии. Спой и сравни их по характеру.

## Вежливый хвост
URL: https://www.opiq.ee/kit/238/chapter/13488
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 12.1
Topics ET: matemaatika
Topics RU: математика, вежливый, хвост
Topics EN: mathematics
Headings: Вежливый хвост
Task examples: Выполни задание в рабочей тетради. Запиши мелодию на нотоносце. Спой её, показывая рукой ступени.

## Братец Яков
URL: https://www.opiq.ee/kit/238/chapter/13489
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 12.2
Topics ET: matemaatika
Topics RU: математика, братец, яков
Topics EN: mathematics
Headings: Братец Яков
Task examples: Выполни задание в рабочей тетради. Раздели мелодию на такты. Спой песню по ступеням и со словами.

## Здравствуй
URL: https://www.opiq.ee/kit/238/chapter/13490
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.1
Topics ET: matemaatika
Topics RU: математика, здравствуй
Topics EN: mathematics
Headings: Здравствуй; ЗДРАВСТВУЙ!
Task examples: Выполни задание в рабочей тетради. Досочини ритм и исполни его на музыкальном инструменте.; Выполни задание в рабочей тетради. Раздели ритм на такты. Одну строчку стучи, другую – щёлкай языком.

## Утро в деревне
URL: https://www.opiq.ee/kit/238/chapter/13499
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.10
Topics ET: matemaatika
Topics RU: математика, утро, деревне
Topics EN: mathematics
Headings: Утро в деревне
Task examples: Выполни задание в рабочей тетради.

## Rongisõit
URL: https://www.opiq.ee/kit/238/chapter/13500
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.11
Topics ET: matemaatika, rongisõit
Topics RU: математика
Topics EN: mathematics
Headings: Rongisõit
Task examples: Выполни задание в рабочей тетради. Продолжи беседу.

## Усатая наседка
URL: https://www.opiq.ee/kit/238/chapter/13501
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.12
Topics ET: matemaatika
Topics RU: математика, усатая, наседка
Topics EN: mathematics
Headings: Усатая наседка
Task examples: Выполни задание в рабочей тетради. Выбери и запиши слова, передающие настроение прослушанной музыки.

## Поздравляем тебя!
URL: https://www.opiq.ee/kit/238/chapter/13491
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.2
Topics ET: matemaatika
Topics RU: математика, поздравляем, тебя
Topics EN: mathematics
Headings: Поздравляем тебя!
Task examples: Выполни задание в рабочей тетради. Запиши ступени. Спой песню со словами.

## Sünnipäevaks
URL: https://www.opiq.ee/kit/238/chapter/13492
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.3
Topics ET: matemaatika, sünnipäevaks
Topics RU: математика
Topics EN: mathematics
Headings: Sünnipäevaks
Task examples: Выполни задание в рабочей тетради. Запиши повторяющийся ритм стихотворения и сочини к нему ступени.

## Песенка крокодила Гены
URL: https://www.opiq.ee/kit/238/chapter/13493
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.4
Topics ET: matemaatika
Topics RU: математика, песенка, крокодила, гены
Topics EN: mathematics
Headings: Песенка крокодила Гены
Task examples: Выполни задание в рабочей тетради. Запиши мелодию на нотоносце. Придумай к ней слова и спой песню.

## Mul on üks tore tädi
URL: https://www.opiq.ee/kit/238/chapter/13494
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.5
Topics ET: matemaatika, tore, tädi
Topics RU: математика
Topics EN: mathematics
Headings: Mul on üks tore tädi
Task examples: Выполни задание в рабочей тетради. Раздели ритм на такты и исполни с соседом по парте.

## Мишка с куклой пляшут полечку
URL: https://www.opiq.ee/kit/238/chapter/13495
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.6
Topics ET: matemaatika
Topics RU: математика, мишка, куклой, пляшут, полечку
Topics EN: mathematics
Headings: Мишка с куклой пляшут полечку
Task examples: Выполни задание в рабочей тетради. Раздели мелодию на такты. Спой песню, покажи движениями, о чём в ней поётся.; Выполни задание в рабочей тетради. Запиши мелодию на нотоносце. Спой её с остинатным ритмом, исполненным на музыкальном инструменте.

## Teiste laste mänguasjad
URL: https://www.opiq.ee/kit/238/chapter/13496
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.7
Topics ET: matemaatika, teiste, laste, mänguasjad
Topics RU: математика, чужие, игрушки
Topics EN: mathematics
Headings: Teiste laste mänguasjad; Чужие игрушки
Task examples: Выполни задание в рабочей тетради. Спойте в каноне (повторение от начала до слова Конец).; Выполни задание в рабочей тетради.

## Vaikne, kena kohakene
URL: https://www.opiq.ee/kit/238/chapter/13497
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.8
Topics ET: matemaatika, vaikne, kena, kohakene
Topics RU: математика
Topics EN: mathematics
Headings: Vaikne, kena kohakene; VAIKNE KENA KOHAKENE
Task examples: Выполни задание в рабочей тетради. Исполни одновременно задания 49 и 50 (пой и стучи).; Выполни задание в рабочей тетради. Выполни задание со с. 69 учебника.

## Петушок
URL: https://www.opiq.ee/kit/238/chapter/13498
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 13.9
Topics ET: matemaatika
Topics RU: математика, петушок
Topics EN: mathematics
Headings: Петушок
Task examples: Выполни задание в рабочей тетради. К каким строчкам стихотворения подходит ритм?; Выполни задание в рабочей тетради. Нарисуй картину родного дома (к песне со с. 74).

## Jänku
URL: https://www.opiq.ee/kit/238/chapter/13502
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.1
Topics ET: matemaatika, jänku
Topics RU: математика, дорогой, друг
Topics EN: mathematics
Headings: Jänku; Дорогой друг!
Task examples: Выполни задание в рабочей тетради. Выучи обе строчки, спойте двухголосно в группах.

## Настала зима
URL: https://www.opiq.ee/kit/238/chapter/13511
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.10
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, настала
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Настала зима
Task examples: Выполни задание в рабочей тетради. Проведём беседу:

## Sokukene
URL: https://www.opiq.ee/kit/238/chapter/13503
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.2
Topics ET: matemaatika, sokukene
Topics RU: математика
Topics EN: mathematics
Headings: Sokukene
Task examples: Выполни задание в рабочей тетради. Допиши мелодию со с. 83 и спой её.

## Семеро козлят
URL: https://www.opiq.ee/kit/238/chapter/13504
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.3
Topics ET: matemaatika
Topics RU: математика, семеро, козлят
Topics EN: mathematics
Headings: Семеро козлят
Task examples: Выполни задание в рабочей тетради. Раздели ритм на такты. Запиши мелодию в ключе и спой.

## Где ты был так долго?
URL: https://www.opiq.ee/kit/238/chapter/13505
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.4
Topics ET: matemaatika
Topics RU: математика, долго
Topics EN: mathematics
Headings: Где ты был так долго?

## Tore laps
URL: https://www.opiq.ee/kit/238/chapter/13506
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.5
Topics ET: matemaatika, tore, laps
Topics RU: математика
Topics EN: mathematics
Headings: Tore laps

## Kuud
URL: https://www.opiq.ee/kit/238/chapter/13507
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.6
Topics ET: matemaatika, kuud
Topics RU: математика
Topics EN: mathematics
Headings: Kuud

## Гусята
URL: https://www.opiq.ee/kit/238/chapter/13508
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.7
Topics ET: matemaatika
Topics RU: математика, гусята
Topics EN: mathematics
Headings: Гусята

## Lapsed, tuppa!
URL: https://www.opiq.ee/kit/238/chapter/13509
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.8
Topics ET: matemaatika, lapsed, tuppa
Topics RU: математика
Topics EN: mathematics
Headings: Lapsed, tuppa!

## Зимняя песенка
URL: https://www.opiq.ee/kit/238/chapter/13510
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 14.9
Topics ET: matemaatika
Topics RU: математика, зимняя, песенка, детская
Topics EN: mathematics
Headings: Зимняя песенка; ДЕТСКАЯ ПЕСЕНКА
Task examples: Выполни задание в рабочей тетради. Запиши мелодию «Зимней песенки» со с. 92 и спой её.; Выполни задание в рабочей тетради. Запиши размер такта. Выучи мелодию по ступеням. Придумай слова и спой песню.

## Päkapikk
URL: https://www.opiq.ee/kit/238/chapter/13512
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 15.1
Topics ET: matemaatika, päkapikk
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikk

## Päkapikk
URL: https://www.opiq.ee/kit/238/chapter/13513
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 15.2
Topics ET: matemaatika, päkapikk
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikk

## Идём вместе
URL: https://www.opiq.ee/kit/238/chapter/13514
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.1
Topics ET: matemaatika
Topics RU: математика, вместе
Topics EN: mathematics
Headings: Идём вместе
Task examples: Выполни задание в рабочей тетради. Сочини к мелодии ритм, раздели на такты (количество тактов должно быть чётным (6, 8, 10, …).

## Это будет здорово!
URL: https://www.opiq.ee/kit/238/chapter/13523
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.10
Topics ET: matemaatika
Topics RU: математика, будет, здорово
Topics EN: mathematics
Headings: Это будет здорово!
Task examples: Выполни задание в рабочей тетради. Прочитай. Запиши слова ракоходом. Что означают эти слова?

## Все идут, спешат на праздник
URL: https://www.opiq.ee/kit/238/chapter/13515
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.2
Topics ET: matemaatika
Topics RU: математика, идут, спешат, праздник
Topics EN: mathematics
Headings: Все идут, спешат на праздник
Task examples: Выполни задание в рабочей тетради.

## Зимний вечер
URL: https://www.opiq.ee/kit/238/chapter/13516
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.3
Topics ET: matemaatika
Topics RU: математика, зимний, вечер
Topics EN: mathematics
Headings: Зимний вечер
Task examples: Выполни задание в рабочей тетради. Выполни задание со с. 99.

## Новогодняя сказка
URL: https://www.opiq.ee/kit/238/chapter/13517
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.4
Topics ET: matemaatika
Topics RU: математика, новогодняя, сказка
Topics EN: mathematics
Headings: Новогодняя сказка
Task examples: Выполни задание в рабочей тетради. Прочитай ракоходом слова и запиши их. Ракоход – движение наоборот, т. е. от конца к началу, встречается как в словах, так и в музыке.

## Мы маленькие свечи
URL: https://www.opiq.ee/kit/238/chapter/13518
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.5
Topics ET: matemaatika
Topics RU: математика, маленькие, свечи
Topics EN: mathematics
Headings: Мы маленькие свечи

## Sulle laulan, Jõulutaat
URL: https://www.opiq.ee/kit/238/chapter/13519
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.6
Topics ET: matemaatika, sulle, laulan, jõulutaat
Topics RU: математика
Topics EN: mathematics
Headings: Sulle laulan, Jõulutaat
Task examples: Выполни задание в рабочей тетради. Простучи ритм забора. Исполни ритм ракоходом. Запиши оба ритма, раздели их на такты. Придумай к ним слова.; Выполни задание в рабочей тетради. Сочини мелодию к ритму коляды со с. 102. Спой коляду.

## Kelgusõit
URL: https://www.opiq.ee/kit/238/chapter/13520
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.7
Topics ET: matemaatika, kelgusõit
Topics RU: математика
Topics EN: mathematics
Headings: Kelgusõit

## Ёлочка
URL: https://www.opiq.ee/kit/238/chapter/13521
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.8
Topics ET: matemaatika
Topics RU: математика, лочка
Topics EN: mathematics
Headings: Ёлочка
Task examples: Выполни задание в рабочей тетради.

## Добрый жук
URL: https://www.opiq.ee/kit/238/chapter/13522
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 16.9
Topics ET: matemaatika
Topics RU: математика, добрый
Topics EN: mathematics
Headings: Добрый жук

## Tulge meie tantsuringi
URL: https://www.opiq.ee/kit/238/chapter/13524
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 17.1
Topics ET: matemaatika, tulge, meie, tantsuringi
Topics RU: математика
Topics EN: mathematics
Headings: Tulge meie tantsuringi
Task examples: Выполни задание в рабочей тетради. Выполни задание со с. 107. Сочини к ритму ступени и спой их.

## Всё наоборот
URL: https://www.opiq.ee/kit/238/chapter/13525
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 17.2
Topics ET: matemaatika
Topics RU: математика, наоборот, путаница, небылица, давай, вспомним
Topics EN: mathematics
Headings: Всё наоборот; ПУТАНИЦА-НЕБЫЛИЦА; Давай вспомним!
Task examples: Выполни задание в рабочей тетради. Раздели ритм на такты. Исполните его с другом на ритмических инструментах.

## Ай-я, жу-жу
URL: https://www.opiq.ee/kit/238/chapter/13526
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 18.1
Topics ET: matemaatika
Topics RU: математика, давай, повторим, пройденное
Topics EN: mathematics
Headings: Ай-я, жу-жу; Давай повторим пройденное!
Task examples: Выполни задание в рабочей тетради. Подпиши ступени. Выучи обе строчки, спойте двухголосно в группах.; Выполни задание в рабочей тетради. Впиши подходящие длительности и простучи ритмы.

## Моется цапля
URL: https://www.opiq.ee/kit/238/chapter/13527
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 18.2
Topics ET: matemaatika
Topics RU: математика, моется, цапля
Topics EN: mathematics
Headings: Моется цапля
Task examples: Выполни задание в рабочей тетради. Спой с названием ступеней. Подпиши ритмическое сопровождение и исполни с ним мелодию.

## Ой, бежит ручьём вода
URL: https://www.opiq.ee/kit/238/chapter/13528
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 19.1
Topics ET: matemaatika, vesi, veeohutus, veekogu
Topics RU: математика, вода, безопасность на воде, водоём, бежит, ручь
Topics EN: mathematics, water, water safety, body of water
Headings: Ой, бежит ручьём вода
Task examples: Выполни задание в рабочей тетради. Запиши ступени со с. 109 и спой их со словами стихотворения.

## Перед весной
URL: https://www.opiq.ee/kit/238/chapter/13529
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 19.2
Topics ET: matemaatika
Topics RU: математика, перед, весной
Topics EN: mathematics
Headings: Перед весной
Task examples: Выполни задание в рабочей тетради.

## Kevadel
URL: https://www.opiq.ee/kit/238/chapter/13530
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 19.3
Topics ET: matemaatika, kevadel
Topics RU: математика
Topics EN: mathematics
Headings: Kevadel
Task examples: Выполни задание в рабочей тетради. Нарисуй картинку к песням «Перед весной» (с. 116) и «Kevadel» (с. 117).

## Кисель
URL: https://www.opiq.ee/kit/238/chapter/13456
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, кисель, фольклор
Topics EN: mathematics
Headings: Кисель; Фольклор
Task examples: Выполни задание в рабочей тетради. Запиши мелодию на нотоносце и спой её.; Выполни задание в рабочей тетради. Сочини и запиши мелодию к стихотворению со с. 16 учебника.

## Laula, laula, suukene
URL: https://www.opiq.ee/kit/238/chapter/13457
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.2
Topics ET: matemaatika, laula, suukene
Topics RU: математика
Topics EN: mathematics
Headings: Laula, laula, suukene

## Ходила младёшенька по борочку
URL: https://www.opiq.ee/kit/238/chapter/13458
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, ходила, млад, шенька, борочку
Topics EN: mathematics
Headings: Ходила младёшенька по борочку

## Дудочка
URL: https://www.opiq.ee/kit/238/chapter/13459
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, дудочка
Topics EN: mathematics
Headings: Дудочка

## Рыбка-окунёчек
URL: https://www.opiq.ee/kit/238/chapter/13460
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, рыбка, окун
Topics EN: mathematics
Headings: Рыбка-окунёчек
Task examples: Выполни задание в рабочей тетради. Соедини разноцветными стрелками рифмующиеся слова.

## Весёлые лягушки
URL: https://www.opiq.ee/kit/238/chapter/13461
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, лягушки
Topics EN: mathematics
Headings: Весёлые лягушки
Task examples: Выполни задание в рабочей тетради. Спой мелодию. Придумай к ней слова.

## Ой, сапожки хороши!
URL: https://www.opiq.ee/kit/238/chapter/13462
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, сапожки, хороши
Topics EN: mathematics
Headings: Ой, сапожки хороши!

## Комарочек
URL: https://www.opiq.ee/kit/238/chapter/13463
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, комарочек
Topics EN: mathematics
Headings: Комарочек
Task examples: Выполни задание в рабочей тетради. Запиши упражнение со с. 25 в новом ключе и спой его.

## Блины
URL: https://www.opiq.ee/kit/238/chapter/13531
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 20.1
Topics ET: matemaatika
Topics RU: математика, блины
Topics EN: mathematics
Headings: Блины
Task examples: Выполни задание в рабочей тетради. Найди и обведи цветными карандашами знакомые слова, связанные с народным творчеством.

## Песня солнышка
URL: https://www.opiq.ee/kit/238/chapter/13532
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 20.2
Topics ET: matemaatika
Topics RU: математика, песня, солнышка
Topics EN: mathematics
Headings: Песня солнышка
Task examples: Выполни задание в рабочей тетради. Исполни верхнюю строчку, щелкая языком, нижнюю простучи по коленям.

## Kiigu, kiigu, kiigekene
URL: https://www.opiq.ee/kit/238/chapter/13533
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 20.3
Topics ET: matemaatika, kiigu, kiigekene
Topics RU: математика
Topics EN: mathematics
Headings: Kiigu, kiigu, kiigekene
Task examples: Выполни задание в рабочей тетради. Придумай и запиши ритм мелодии. Спой её с названием ступеней.

## Кукушка и воробей
URL: https://www.opiq.ee/kit/238/chapter/13534
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 20.4
Topics ET: matemaatika
Topics RU: математика, кукушка, воробей
Topics EN: mathematics
Headings: Кукушка и воробей
Task examples: Выполни задание в рабочей тетради. Продолжи беседу.

## Пение птиц
URL: https://www.opiq.ee/kit/238/chapter/13535
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 20.5
Topics ET: matemaatika
Topics RU: математика, пение, птиц
Topics EN: mathematics
Headings: Пение птиц
Task examples: Выполни задание в рабочей тетради. Подпиши ступени и выучи мелодию. Спой и простучи ритм.

## Lindude kevad
URL: https://www.opiq.ee/kit/238/chapter/13536
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 20.6
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, lindude
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Lindude kevad
Task examples: Выполни задание в рабочей тетради. Запиши повторяющиеся ритмы стихотворения, подпиши к ним ступени и спой песенку.; Выполни задание в рабочей тетради. Раздели мелодию на такты и запиши на нотоносце. Исполни.

## Легенда
URL: https://www.opiq.ee/kit/238/chapter/13537
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 21.1
Topics ET: matemaatika
Topics RU: математика, легенда
Topics EN: mathematics
Headings: Легенда
Task examples: Выполни задание в рабочей тетради. Запиши ритм стихотворения и придумай к нему ступени. Спой песенку.

## Молитва
URL: https://www.opiq.ee/kit/238/chapter/13538
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 21.2
Topics ET: matemaatika
Topics RU: математика, молитва, красное, яичко
Topics EN: mathematics
Headings: Молитва; КРАСНОЕ ЯИЧКО

## Тень-тень
URL: https://www.opiq.ee/kit/238/chapter/13539
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.1
Topics ET: matemaatika
Topics RU: математика, тень
Topics EN: mathematics
Headings: Тень-тень

## Лён
URL: https://www.opiq.ee/kit/238/chapter/13548
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.10
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Лён

## Vihma sajab
URL: https://www.opiq.ee/kit/238/chapter/13549
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.11
Topics ET: matemaatika, vihma, sajab
Topics RU: математика
Topics EN: mathematics
Headings: Vihma sajab

## Как под наши ворота
URL: https://www.opiq.ee/kit/238/chapter/13550
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.12
Topics ET: matemaatika
Topics RU: математика, наши, ворота
Topics EN: mathematics
Headings: Как под наши ворота

## Спать пора
URL: https://www.opiq.ee/kit/238/chapter/13551
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.13
Topics ET: matemaatika
Topics RU: математика, спать, пора
Topics EN: mathematics
Headings: Спать пора

## Колыбельная
URL: https://www.opiq.ee/kit/238/chapter/13552
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.14
Topics ET: matemaatika
Topics RU: математика, колыбельная
Topics EN: mathematics
Headings: Колыбельная

## Колыбельная медведицы
URL: https://www.opiq.ee/kit/238/chapter/13553
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.15
Topics ET: matemaatika
Topics RU: математика, колыбельная, медведицы
Topics EN: mathematics
Headings: Колыбельная медведицы; Колыбельная

## Meie kiisul kriimud silmad
URL: https://www.opiq.ee/kit/238/chapter/13540
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.2
Topics ET: matemaatika, meie, kiisul, kriimud, silmad
Topics RU: математика
Topics EN: mathematics
Headings: Meie kiisul kriimud silmad

## Песенка лисички
URL: https://www.opiq.ee/kit/238/chapter/13541
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.3
Topics ET: matemaatika
Topics RU: математика, песенка, лисички
Topics EN: mathematics
Headings: Песенка лисички

## Kõrvenõges
URL: https://www.opiq.ee/kit/238/chapter/13542
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.4
Topics ET: matemaatika, kõrvenõges
Topics RU: математика
Topics EN: mathematics
Headings: Kõrvenõges

## От носика до хвостика
URL: https://www.opiq.ee/kit/238/chapter/13543
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.5
Topics ET: matemaatika
Topics RU: математика, носика, хвостика
Topics EN: mathematics
Headings: От носика до хвостика
Task examples: Выполни задание в рабочей тетради. Нарисуй картинку к песням со с. 134–135.

## Koer Muki
URL: https://www.opiq.ee/kit/238/chapter/13544
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.6
Topics ET: matemaatika, koer, muki
Topics RU: математика
Topics EN: mathematics
Headings: Koer Muki
Task examples: Выполни задание в рабочей тетради. Спой с сопровождением на ритмическом инструменте.

## Вишенка
URL: https://www.opiq.ee/kit/238/chapter/13545
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.7
Topics ET: matemaatika
Topics RU: математика, вишенка
Topics EN: mathematics
Headings: Вишенка
Task examples: Выполни задание в рабочей тетради. Сочини ритмическое сопровождение. Спой песню вместе с ним.

## Maias marjuline
URL: https://www.opiq.ee/kit/238/chapter/13546
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.8
Topics ET: matemaatika, maias, marjuline
Topics RU: математика
Topics EN: mathematics
Headings: Maias marjuline
Task examples: Выполни задание в рабочей тетради. Досочини слова 2-го куплета. Спойте в каноне.; Выполни задание в рабочей тетради. Выполни задание со с. 137.

## Маки, маки, маковочки
URL: https://www.opiq.ee/kit/238/chapter/13547
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 22.9
Topics ET: matemaatika
Topics RU: математика, маки, маковочки
Topics EN: mathematics
Headings: Маки, маки, маковочки

## Tiiu, talutütrekene
URL: https://www.opiq.ee/kit/238/chapter/13554
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 23.1
Topics ET: matemaatika, tiiu, talutütrekene
Topics RU: математика
Topics EN: mathematics
Headings: Tiiu, talutütrekene

## Мамин праздник
URL: https://www.opiq.ee/kit/238/chapter/13555
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 23.2
Topics ET: matemaatika
Topics RU: математика, мамин, праздник
Topics EN: mathematics
Headings: Мамин праздник

## Emale
URL: https://www.opiq.ee/kit/238/chapter/13556
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 23.3
Topics ET: matemaatika, emale
Topics RU: математика
Topics EN: mathematics
Headings: Emale
Task examples: Выполни задание в рабочей тетради. Сочини мелодию к стихотворению со с. 148. Спой песенку.

## Светлячок
URL: https://www.opiq.ee/kit/238/chapter/13557
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 24.1
Topics ET: matemaatika
Topics RU: математика, светлячок
Topics EN: mathematics
Headings: Светлячок
Task examples: Выполни задание в рабочей тетради. Напиши, каким был характер прослушанных тобой музыкальных пьес.

## Голубой вагон
URL: https://www.opiq.ee/kit/238/chapter/13558
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 24.2
Topics ET: matemaatika
Topics RU: математика, голубой, вагон
Topics EN: mathematics
Headings: Голубой вагон
Task examples: Выполни задание в рабочей тетради.; Выполни задание в рабочей тетради. Из выученных песен назови 4, в которых встречаются слова «весело» («весёлый»), «солнце» («солнечный») или «пою» («песня»).

## Сказки гуляют по свету
URL: https://www.opiq.ee/kit/238/chapter/13559
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 24.3
Topics ET: matemaatika
Topics RU: математика, сказки, гуляют, свету, сказка, дорогой, друг
Topics EN: mathematics
Headings: Сказки гуляют по свету; Сказка; Дорогой друг!
Task examples: Выполни задание в рабочей тетради. Нарисуй самую радостную песню этого года.

## Сел комарик на дубочек
URL: https://www.opiq.ee/kit/238/chapter/13464
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, комарик, дубочек
Topics EN: mathematics
Headings: Сел комарик на дубочек
Task examples: Выполни задание в рабочей тетради. Запиши ступени со с. 26 на нотоносце. Раздели мелодию на такты и спой со словами. Для рифмы можешь использовать слова из задания 9.

## Часы
URL: https://www.opiq.ee/kit/238/chapter/13465
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 4.1
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Часы
Task examples: Выполни задание в рабочей тетради. Найди и запиши новые ступени на нотоносце и спой их (с. 37).

## Тук-тук-тук
URL: https://www.opiq.ee/kit/238/chapter/13466
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Тук-тук-тук
Task examples: Выполни задание в рабочей тетради.

## Väike ehitaja
URL: https://www.opiq.ee/kit/238/chapter/13467
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 4.3
Topics ET: matemaatika, väike, ehitaja
Topics RU: математика
Topics EN: mathematics
Headings: Väike ehitaja
Task examples: Выполни задание в рабочей тетради. Спой и простучи (одновременно).

## Песенка о точном времени
URL: https://www.opiq.ee/kit/238/chapter/13468
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, песенка, точном, времени
Topics EN: mathematics
Headings: Песенка о точном времени
Task examples: Выполни задание в рабочей тетради. Раздели мелодию на такты. Спой по ступеням и со словами.

## Meistrimehed
URL: https://www.opiq.ee/kit/238/chapter/13469
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 5.1
Topics ET: matemaatika, meistrimehed
Topics RU: математика
Topics EN: mathematics
Headings: Meistrimehed
Task examples: Выполни задание в рабочей тетради. Исполни ритм рисунка на маракасах (вместе с предыдущей песней).

## Походная песенка
URL: https://www.opiq.ee/kit/238/chapter/13470
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, походная, песенка
Topics EN: mathematics
Headings: Походная песенка
Task examples: Выполни задание в рабочей тетради.

## Вот какие чудеса!
URL: https://www.opiq.ee/kit/238/chapter/13471
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 5.3
Topics ET: matemaatika, trilla, tralla, tantsulaul
Topics RU: математика, какие, чудеса, розы
Topics EN: mathematics
Headings: Вот какие чудеса!; SO1 и RA1; TRILLA-TRALLA TANTSULAUL; РОЗЫ
Task examples: Выполни задание в рабочей тетради. Запиши ступени на нотоносце и спой их. Исполни песню.

## Tibukene, tillukene
URL: https://www.opiq.ee/kit/238/chapter/13472
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 5.4
Topics ET: matemaatika, tibukene, tillukene
Topics RU: математика
Topics EN: mathematics
Headings: Tibukene, tillukene
Task examples: Выполни задание в рабочей тетради.

## Noodilugeja
URL: https://www.opiq.ee/kit/238/chapter/13473
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 6.1
Topics ET: matemaatika, noodilugeja
Topics RU: математика
Topics EN: mathematics
Headings: Noodilugeja
Task examples: Выполни задание в рабочей тетради. Подпиши ступени и спой их. Исполните канон.

## Песенка о зарядке
URL: https://www.opiq.ee/kit/238/chapter/13474
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, песенка, зарядке
Topics EN: mathematics
Headings: Песенка о зарядке
Task examples: Выполни задание в рабочей тетради. Запиши мелодию в новом ключе и спой её.

## Мальчик-замарашка
URL: https://www.opiq.ee/kit/238/chapter/13475
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, мальчик, замарашка
Topics EN: mathematics
Headings: Мальчик-замарашка
Task examples: Выполни задание в рабочей тетради. Раздели ритм на такты. Простучи одной рукой ритм, а другой – метр (первую долю такта).

## Неприятность эту мы переживём
URL: https://www.opiq.ee/kit/238/chapter/13476
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 6.4
Topics ET: matemaatika
Topics RU: математика, неприятность, пережив
Topics EN: mathematics
Headings: Неприятность эту мы переживём

## Стоит стар человечек
URL: https://www.opiq.ee/kit/238/chapter/13477
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 6.5
Topics ET: matemaatika
Topics RU: математика, стоит, стар, человечек
Topics EN: mathematics
Headings: Стоит стар человечек
Task examples: Выполни задание в рабочей тетради. Запиши названия ступеней и прочитай стихотворение. Спой его песенкой.

## Листопад
URL: https://www.opiq.ee/kit/238/chapter/13478
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 7.1
Topics ET: matemaatika
Topics RU: математика, листопад
Topics EN: mathematics
Headings: Листопад
Task examples: Выполни задание в рабочей тетради. Нарисуй картину золотой осени к стихотворению или песне со с. 48–49.; Выполни задание в рабочей тетради. Раздели ритм на такты и и исполни его на агого-гуйро.

## Дождик, братик
URL: https://www.opiq.ee/kit/238/chapter/13479
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 8.1
Topics ET: matemaatika
Topics RU: математика, дождик, братик
Topics EN: mathematics
Headings: Дождик, братик
Task examples: Выполни задание в рабочей тетради. Допиши мелодию и спой её.

## Saja, saja, vihmakene
URL: https://www.opiq.ee/kit/238/chapter/13480
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 8.2
Topics ET: matemaatika, saja, vihmakene
Topics RU: математика
Topics EN: mathematics
Headings: Saja, saja, vihmakene; SAJA, SAJA, VIHMAKENE!
Task examples: Выполни задание в рабочей тетради. Простучи на разных инструментах.; Выполни задание в рабочей тетради. Раздели мелодию на такты. Спой её по ступеням и со словами.

## Осень
URL: https://www.opiq.ee/kit/238/chapter/13481
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 8.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Осень
Task examples: Выполни задание в рабочей тетради. Нарисуй своё самое яркое музыкальное впечатление лета.

## Улитка
URL: https://www.opiq.ee/kit/238/chapter/13482
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 9.1
Topics ET: matemaatika, tigu, ligu
Topics RU: математика, улитка
Topics EN: mathematics
Headings: Улитка; Tigu; УЛИТКА. TIGU-LIGU
Task examples: Выполни задание в рабочей тетради. Спой с названиями ступеней. Сочини слова и придумай название песне. Исполни её.

## Кукушка
URL: https://www.opiq.ee/kit/238/chapter/13483
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 9.2
Topics ET: matemaatika
Topics RU: математика, кукушка
Topics EN: mathematics
Headings: Кукушка
Task examples: Выполни задание в рабочей тетради. Запиши первую строчку песни «Кукушка» (с. 55) в одном ключе ||=, а вторую в другом. Спой песню со словами.

## Скворушка прощается
URL: https://www.opiq.ee/kit/238/chapter/13484
Book: Музыка – волшебная страна. 2 класс – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._2_класс
Chapter ID: 9.3
Topics ET: matemaatika
Topics RU: математика, скворушка, прощается
Topics EN: mathematics
Headings: Скворушка прощается
Task examples: Выполни задание в рабочей тетради. Раздели ритм на такты и простучи его двумя руками: на верхней – правой, на нижней – левой.
