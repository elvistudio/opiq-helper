## Loodusõpetus 7. klassile (2024) – Opiq
URL: https://www.opiq.ee/Kit/Details/546
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 98
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusteadused
URL: https://www.opiq.ee/kit/546/chapter/30107
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.1
Topics ET: loodusõpetus, loodusteadused, uudishimu, paneb, küsimusi, esitama, teadus, tehnoloogia, jäta
Topics RU: природоведение
Topics EN: science
Headings: Loodusteadused; Uudishimu paneb küsimusi esitama; Teadus ja tehnoloogia; Jäta meelde!; Mõtle!
Task examples: Lohista loodusteadus õige selgituse juurde.

## Pindala ja ruum­ala mõõtmine
URL: https://www.opiq.ee/kit/546/chapter/30116
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.10
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, pindala, ruum, mitmemõõtmeline, maailm, ruumala, jäta, meelde
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Pindala ja ruum­ala mõõtmine; Mitmemõõtmeline maailm; Pindala; Ruumala; Jäta meelde!; Mõtle!
Task examples: Vali lünka õige sõna ja lahenda ülesanne.

## Lisalugemine. Avastused ja leiutised 20. sajandil
URL: https://www.opiq.ee/kit/546/chapter/30108
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.2
Topics ET: loodusõpetus, lisalugemine, avastused, leiutised, sajandil, olulised
Topics RU: природоведение
Topics EN: science
Headings: Lisalugemine. Avastused ja leiutised 20. sajandil; Olulised avastused ja leiutised; 1900–1950; 1960–2000

## Loodusteaduslik uurimismeetod
URL: https://www.opiq.ee/kit/546/chapter/30109
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.3
Topics ET: loodusõpetus, loodus, keskkond, loodusteaduslik, uurimismeetod, probleemide, lahendaja, kuidas, tehakse, teadust, loodusteadusliku
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Loodusteaduslik uurimismeetod; Probleemide lahendaja; Kuidas tehakse teadust?; Loodusteadusliku uurimis­meetodi etapid; Teadustöö tulemuste avaldamine; Miks kasutada loodus­teaduslikku uurimis­meetodit?; Pseudoteadus; Jäta meelde!; Mõtle!
Task examples: Ühenda loodusteadusliku uurimismeetodi etapp ja selle kirjeldus.; Paiguta loodusteadusliku uurimis­meetodi etapid õigesse järjekorda.

## Vaatlus ja katse
URL: https://www.opiq.ee/kit/546/chapter/30110
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.4
Topics ET: loodusõpetus, vaatlus, katse, tähelepanelik, vaatleja, muutujad, labori, ohutusnõuded, jäta
Topics RU: природоведение
Topics EN: science
Headings: Vaatlus ja katse; Tähelepanelik vaatleja; Muutujad; Labori ohutusnõuded; Jäta meelde!; Mõtle!
Task examples: Kas nimetatud tunnused käivad vaatluse või katse kohta? Lohista tunnused õigesse lahtrisse.; Ühenda mõiste sobiva seletusega.

## Andmete kogumine ja esitamine
URL: https://www.opiq.ee/kit/546/chapter/30111
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.5
Topics ET: loodusõpetus, andmete, kogumine, esitamine, võitja, kirja, panek, analüüs, diagrammid
Topics RU: природоведение
Topics EN: science
Headings: Andmete kogumine ja esitamine; Kes on võitja?; Andmete kogumine; Andmete kirja­panek ja analüüs; Diagrammid; Jäta meelde!; Mõtle!
Task examples: Märgi tõesed väided.; Märgi õiged lauselõpud.

## Mudel, keha ja nähtus
URL: https://www.opiq.ee/kit/546/chapter/30112
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.6
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, mudel, nähtus, auto, automudel, füüsiline, abstraktne, jäta
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Mudel, keha ja nähtus; Auto ja automudel; Mudel; Füüsiline ja abstraktne mudel; Keha ja nähtus; Jäta meelde!; Mõtle!
Task examples: Märgi, kas väide on õige või vale.; Märgi füüsilised mudelid.

## Mõõtmine ja mõõteriistad
URL: https://www.opiq.ee/kit/546/chapter/30113
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.7
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, mõõteriistad, olulised, mõõtmised, mõõteriista, kasutamine, mõõtmisviga, jäta
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mõõtmine ja mõõteriistad; Olulised mõõtmised; Mõõtmine; Mõõteriista kasutamine; Mõõtmisviga; Jäta meelde!; Mõtle!
Task examples: Ühenda mõõteriist ja sellega mõõdetav füüsikaline suurus.; Vali lünka sobiv variant.

## Füüsikalised suurused ja mõõt­ühikud
URL: https://www.opiq.ee/kit/546/chapter/30114
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.8
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, füüsikalised, suurused, mõõt, ühikud, magusad, tähised, mõõtühikud
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Füüsikalised suurused ja mõõt­ühikud; Magusad numbrid; Füüsikalised suurused ja tähised; Mõõtühikud; SI; Lisalugemine; Kümnendeesliited; Etalon; Jäta meelde!; Mõtle!
Task examples: Kirjuta lünka õige sõna.; Inimkeha oli esimene mõõteriist. Lohista mõõt­ühik selle seletuse juurde.

## Otsene ja kaudne mõõtmine
URL: https://www.opiq.ee/kit/546/chapter/30115
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 1.9
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, taim, taimed, puu, lill, otsene, kaudne, mõõte, riistaga, kõrguse, määramine, sammu
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, растение, растения, дерево, цветок
Topics EN: science, measurement, unit, length, mass, volume, plant, plants, tree, flower
Headings: Otsene ja kaudne mõõtmine; Mõõtmine mõõte­riistaga; Puu kõrguse määramine; Sammu pikkus; Kiiruse arvutamine; Jäta meelde!; Mõtle!

## Ainete ja kehade koostis
URL: https://www.opiq.ee/kit/546/chapter/30441
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.1
Topics ET: loodusõpetus, ainete, kehade, koostis, väikeseks, saab, paberi, tükeldada, aineosakeste
Topics RU: природоведение
Topics EN: science
Headings: Ainete ja kehade koostis; Kui väikeseks saab paberi tükeldada?; Kehade koostis; Ainete koostis; Aineosakeste kujutamine; Jäta meelde!; Mõtle!
Task examples: Märgi tõesed väited.; Vali lünka sobiv variant.

## Aine füüsikalised omadused
URL: https://www.opiq.ee/kit/546/chapter/30781
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.10
Topics ET: loodusõpetus, aine, füüsikalised, omadused, erinevate, omadus, tega, materjalid, puhtal, ainel
Topics RU: природоведение
Topics EN: science
Headings: Aine füüsikalised omadused; Erinevate omadus­tega materjalid; Puhtal ainel on kindlad omadused; Aine olek, sulamis- ja keemis­temperatuur; Elektri- ja soojus­juhtivus; Tihedus; Jäta meelde!; Mõtle!

## Segude lahutamine koostis­osadeks
URL: https://www.opiq.ee/kit/546/chapter/30782
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.11
Topics ET: loodusõpetus, lahutamine, lahuta, vahe, segude, koostis, osadeks, spagettide, filtreerimine, lahustumatu, aine
Topics RU: природоведение, вычитание, вычти, разность
Topics EN: science, subtraction, subtract, difference
Headings: Segude lahutamine koostis­osadeks; Spagettide filtreerimine; Segude lahutamine; Lahustumatu aine eraldamine; Lahustunud aine eraldamine; Jäta meelde!; Mõtle!
Task examples: Vali sobiv lauselõpp.; Ühenda segu ja selle lahutamiseks sobiv meetod.

## Aatomi ehitus
URL: https://www.opiq.ee/kit/546/chapter/30442
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, aatomi, ehitus, aatomid, klaaskuulid, koostisosad, aatomimudelid, mõõtmed, jäta
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Aatomi ehitus; Aatomid ja klaaskuulid; Aatomi koostisosad; Aatomimudelid; Aatomi mõõtmed; Aatomi mass; Jäta meelde!; Mõtle!

## Keemiline element ja perioodilisustabel
URL: https://www.opiq.ee/kit/546/chapter/30443
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.3
Topics ET: loodusõpetus, keemiline, element, perioodilisustabel, aatomeid, täis, maailm, elementide, nimetused
Topics RU: природоведение
Topics EN: science
Headings: Keemiline element ja perioodilisustabel; Aatomeid täis maailm; Keemiline element; Elementide nimetused ja tähised; Keemiliste elementide perioodilisustabel; Keemiliste elementide levik; Jäta meelde!; Mõtle!
Task examples: Vali sobiv lauselõpp.; Kirjuta mõne tuntuma elemendi tähised.

## Liht- ja liitained
URL: https://www.opiq.ee/kit/546/chapter/30444
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.4
Topics ET: loodusõpetus, liht, liitained, mõistatuslikud, kristallid, aine, koostise, kirjeldamine, liitaine
Topics RU: природоведение
Topics EN: science
Headings: Liht- ja liitained; Mõistatuslikud kristallid; Aine koostise kirjeldamine; Liht- ja liitaine; Jäta meelde!; Mõtle!
Task examples: Märgi aine valemi õige kirjedus.; Märgi aine valemi õige kirjedus.

## Mass ja massi mõõtmine
URL: https://www.opiq.ee/kit/546/chapter/30445
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, massi, kaaluta, kaaluga, olek, aatomi, molekuli
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mass ja massi mõõtmine; Kaaluta ja kaaluga olek; Aatomi mass; Molekuli mass; Mass ja kaal; Massi mõõtmine; Jäta meelde!; Mõtle!
Task examples: Leia elemendi ligikaudne aatommass selle koostise põhjal. Kirjuta aatommass täisarvuga.; Leia molekuli molekulmass perioodilisustabeli põhjal.

## Aine olekud
URL: https://www.opiq.ee/kit/546/chapter/30777
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.6
Topics ET: loodusõpetus, aine, olekud, olekute, keskel, kolm, olekut, igapäevaelus, jäta
Topics RU: природоведение
Topics EN: science
Headings: Aine olekud; Aine olekute keskel; Aine kolm olekut; Vee kolm olekut; Aine kolm olekut igapäevaelus; Jäta meelde!; Mõtle!
Task examples: Lohista omadus sobiva aine oleku juurde.; Vee kolme olekut nimetatakse erinevalt. Ühenda aine olek ja vastav vee nimetus.

## Aine olekute muutused
URL: https://www.opiq.ee/kit/546/chapter/30778
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.7
Topics ET: loodusõpetus, aine, olekute, muutused, jäätunud, kosk, keset, linna, millest, sõltub
Topics RU: природоведение
Topics EN: science
Headings: Aine olekute muutused; Jäätunud kosk keset linna; Millest sõltub aine olek?; Sulamine ja tahkumine; Keemine ja kondenseerumine; Sublimeerumine ja härmatumine; Energia aine olekute muutumisel; Vee oleku muutused looduses; Jäta meelde!; Mõtle!
Task examples: Vali rippmenüüst lünka õige variant.; Ühenda mõiste ja aine oleku üleminek.

## Tihedus
URL: https://www.opiq.ee/kit/546/chapter/30779
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.8
Topics ET: loodusõpetus, tihedus, erineva, suuruse, raskusega, kehad, millest, sõltub, ujub, upub
Topics RU: природоведение
Topics EN: science
Headings: Tihedus; Erineva suuruse ja raskusega kehad; Millest sõltub tihedus?; Ujub või upub; Tiheduse leidmine; Vee tihedus; Jäta meelde!; Mõtle!

## Puhas aine ja segu
URL: https://www.opiq.ee/kit/546/chapter/30780
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 2.9
Topics ET: loodusõpetus, puhas, aine, segu, joogivesi, ainete, kivimid, mineraalid, lahus, jäta
Topics RU: природоведение
Topics EN: science
Headings: Puhas aine ja segu; Joogivesi on ainete segu; Kivimid ja mineraalid; Materjal; Lahus; Jäta meelde!; Mõtle!

## Loodusnähtused
URL: https://www.opiq.ee/kit/546/chapter/30943
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 3.1
Topics ET: loodusõpetus, loodusnähtused, nähtavad, nähtamatud, nähtused, keemiline, nähtus, füüsikaline, bioloogiline
Topics RU: природоведение
Topics EN: science
Headings: Loodusnähtused; Nähtavad ja nähtamatud nähtused; Keemiline nähtus; Füüsikaline nähtus; Bioloogiline nähtus; Jäta meelde!; Mõtle!
Task examples: Vali sobiv lauselõpp.; Vali sobiv lauselõpp.

## Liikumine ja kiirus
URL: https://www.opiq.ee/kit/546/chapter/30944
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 3.2
Topics ET: loodusõpetus, liikumine, kiirus, erinevad, liikumis, võimalused, kiirusepiirangud, keskmine, kiiruse, mõõtühikud
Topics RU: природоведение
Topics EN: science
Headings: Liikumine ja kiirus; Erinevad liikumis­võimalused; Kiirusepiirangud; Kiirus; Keskmine kiirus; Kiiruse mõõtühikud; Jäta meelde!; Mõtle!

## Energia
URL: https://www.opiq.ee/kit/546/chapter/30945
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 3.3
Topics ET: loodusõpetus, energia, liikumine, energialiigid, mehaaniline, jäävuse, seadus, lisalugemine, jäta
Topics RU: природоведение
Topics EN: science
Headings: Energia; Liikumine ja energia; Energialiigid; Mehaaniline energia; Energia jäävuse seadus; Lisalugemine; Jäta meelde!; Mõtle!
Task examples: Vali õige lauselõpp.; Vali rippmenüüst olukorda kirjeldav energialiik.

## Soojusenergia ja soojusülekanne
URL: https://www.opiq.ee/kit/546/chapter/30946
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 3.4
Topics ET: loodusõpetus, soojusenergia, soojusülekanne, kiik, võngu, igavesti, soojusjuhtivus, soojuskiirgus, konvektsioon
Topics RU: природоведение
Topics EN: science
Headings: Soojusenergia ja soojusülekanne; Kiik ei võngu igavesti; Soojusenergia; Soojusjuhtivus; Soojuskiirgus; Konvektsioon; Jäta meelde!; Mõtle!
Task examples: Vali lünka õige sõna.; Jaga (lohista) näited tabelisse vastavalt sellele, kas nad on head või halvad soojusjuhid.

## Keemiline reaktsioon
URL: https://www.opiq.ee/kit/546/chapter/30947
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 3.5
Topics ET: loodusõpetus, keemiline, reaktsioon, eluks, olulised, keemilised, reaktsioonid, keemilise, reaktsiooni, tunnused
Topics RU: природоведение
Topics EN: science
Headings: Keemiline reaktsioon; Eluks olulised keemilised reaktsioonid; Keemilise reaktsiooni tunnused; Keemilise reaktsiooni võrrand; Energia keemilistes reaktsioonides; Jäta meelde!; Mõtle!
Task examples: Milline või millised tunnused esinevad nimetatud keemilistel reaktsioonidel? Märgi kõik sobivad tunnused.; Lohista nimetus joonisel õigesse kohta.

## Elus- ja eluta looduse seosed
URL: https://www.opiq.ee/kit/546/chapter/31308
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 4.1
Topics ET: loodusõpetus, elus, eluta, looduse, seosed, maapõue, mattunud, süsinik, alus
Topics RU: природоведение
Topics EN: science
Headings: Elus- ja eluta looduse seosed; Maapõue mattunud süsinik; Süsinik on elu alus; Süsinikuringe; Fossiilsed kütused; Jäta meelde!; Mõtle!
Task examples: Märgi tõesed väited.; Vali rippmenüüst lünka õige variant.

## Keskkond kujundab organisme
URL: https://www.opiq.ee/kit/546/chapter/31309
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 4.2
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, kujundab, organisme, jääkaru, väljakutsed, elusolendid, kohas, tunud, kesk
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Keskkond kujundab organisme; Jääkaru väljakutsed; Elusolendid on kohas­tunud oma elu­kesk­konnaga; Inimene mõjutab looduslikku tasa­kaalu; Elu jooksul toimuvad muutused on pöörduvad; Jäta meelde!; Mõtle!
Task examples: Ühenda keskkonna­tingimus ja organismi vastav kohastumus.; Märgi õiged lauselõpud.

## Kasvuhoone­efekt ja kliima­muutused
URL: https://www.opiq.ee/kit/546/chapter/31310
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 4.3
Topics ET: loodusõpetus, kasvuhoone, efekt, kliima, muutused, kasvuhoones, kasvuhooneefekt, kliimamuutused, jäta
Topics RU: природоведение
Topics EN: science
Headings: Kasvuhoone­efekt ja kliima­muutused; Elu kasvuhoones; Kasvuhooneefekt; Kliimamuutused; Jäta meelde!; Mõtle!
Task examples: Märgi õige lauselõpp.; Vali rippmenüüst lünka sobiv variant.

## Ökoloogiline jalajälg
URL: https://www.opiq.ee/kit/546/chapter/31311
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 4.4
Topics ET: loodusõpetus, ökoloogiline, jalajälg, jälg, keskkonnale, biokandevõime, jäta, meelde, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Ökoloogiline jalajälg; Jälg keskkonnale; Biokandevõime; Jäta meelde!; Mõtle!
Task examples: Uuri maailma riikide keskmise ökoloogilise jala­jälje kaarti ning märgi õiged vastused.

## Säästev eluviis ja materjalide taaskasutus
URL: https://www.opiq.ee/kit/546/chapter/31312
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 4.5
Topics ET: loodusõpetus, säästev, eluviis, materjalide, taaskasutus, ületarbimise, päev, ökoloogilise, jalajälje, vähendamine
Topics RU: природоведение
Topics EN: science
Headings: Säästev eluviis ja materjalide taaskasutus; Ületarbimise päev; Ökoloogilise jalajälje vähendamine; Kokkuhoidlik tarbimine; Jäta meelde!; Mõtle!
Task examples: Jaota tegevused selle järgi, kas need on kokkuhoidlikud või mitte.

## Mõisted
URL: https://www.opiq.ee/kit/546/chapter/30117
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 5.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/546/chapter/30118
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 5.2
Topics ET: loodusõpetus, sõnaseletused
Topics RU: природоведение
Topics EN: science
Headings: Sõnaseletused

## Keemiliste elementide perioodilisustabel
URL: https://www.opiq.ee/kit/546/chapter/30440
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 5.3
Topics ET: loodusõpetus, keemiliste, elementide, perioodilisustabel
Topics RU: природоведение
Topics EN: science
Headings: Keemiliste elementide perioodilisustabel

## Impressum
URL: https://www.opiq.ee/kit/546/chapter/32440
Book: Loodusteadused
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_2024_est
Chapter ID: 5.4
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Loodusõpetus 7. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/44
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 1
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 7. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/44
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 62
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusteadused
URL: https://www.opiq.ee/kit/44/chapter/2059
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 1.1
Topics ET: loodusõpetus, loodusteadused, mida, uurivad, mõtle, loodusteaduslik, uurimismeetod, milline, loodusteadusliku, uurimismeetodi
Topics RU: природоведение
Topics EN: science
Headings: Loodusteadused; Mida uurivad loodusteadused?; Mõtle!; Loodusteaduslik uurimismeetod; Milline on loodusteadusliku uurimismeetodi etappide õige järjestus?; Loodusnähtuste klassifitseerimine; Kopsuhingamine on nähtus, millel on nii füüsikalised, keemilised kui ka bioloogilised tunnused. Millise tunnusega on tegu?; Kuidas rakendada loodusteaduslikku uurimismeetodit igapäevaelus?; Millise loodusteadusliku uurimismeetodi etapiga on tegu?; Olulised mõisted

## Füüsikalised kehad ja mõõtmine
URL: https://www.opiq.ee/kit/44/chapter/2060
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 1.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, inimene, keha, meeled, tervis, füüsikalised, kehad, millised, õiged, väited, füüsikalise, kohta
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, человек, тело, чувства, здоровье
Topics EN: science, measurement, unit, length, mass, volume, human, body, senses, health
Headings: Füüsikalised kehad ja mõõtmine; Füüsikalised kehad; Millised on õiged väited füüsikalise keha kohta?; Mõtle!; Miks on vaja midagi mõõta?; Millised tulemused on saadud mõõtmise teel?; Näiteid füüsikaliste suuruste ja vastavate mõõtühikute kohta; Loodusteaduslik uurimine; Rahvapärased mõõtühikud; Olulised mõisted

## Mudelid ja sümbolid
URL: https://www.opiq.ee/kit/44/chapter/2061
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 1.3
Topics ET: loodusõpetus, mudelid, sümbolid, mudel, sümbol, mõtle, keemias, elementide, tähised, olulised
Topics RU: природоведение
Topics EN: science
Headings: Mudelid ja sümbolid; Mudel ja sümbol; Mõtle!; Mudelid ja sümbolid keemias; Elementide tähised on olulised keemiasümbolid; Keemiliste elementide sümbolid; Olulised mõisted

## Tähised ja mõõtühikud I
URL: https://www.opiq.ee/kit/44/chapter/2062
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 1.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, tähised, mõõtühikud, füüsikaliste, suuruste, ühikute, tähistamine, mõtle, sümbolitest, moodustatakse
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Tähised ja mõõtühikud I; Füüsikaliste suuruste ja ühikute tähistamine; Mõtle!; Sümbolitest moodustatakse valemeid; Põhiühikud ja tuletatud ühikud; Mõõtühik toll; Tuletatud ühikud lihtsustatakse; Olulised mõisted

## Tähised ja mõõtühikud II
URL: https://www.opiq.ee/kit/44/chapter/2063
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 1.5
Topics ET: loodusõpetus, tähised, mõõtühikud, eesliiteid, kasutatakse, ühikute, kordsete, väljendamiseks, mõtle, enne
Topics RU: природоведение
Topics EN: science
Headings: Tähised ja mõõtühikud II; Eesliiteid kasutatakse ühikute kordsete väljendamiseks; Mõtle!; Enne arvutamist tuleb erinevad ühikud ühesuguseks teisendada; Kümnendsüsteem pole ainuke oluline süsteem; Kahendsüsteem; Konstandid – muutumatud suurused; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2064
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 1.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, lühikokkuvõte, mõisted, tabelid, joonised, põhiühikud, olulisemad, eesliited, nende
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Tabelid ja joonised; SI põhiühikud; Olulisemad eesliited ja nende tähised; Loodusteadusliku uurimismeetodi etapid; Kordamis­küsimused

## Lisalugemine. Teadussaavutused ja mobiiltelefon
URL: https://www.opiq.ee/kit/44/chapter/2113
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 10.1
Topics ET: loodusõpetus, lisalugemine, teadussaavutused, mobiiltelefon, taaslaetav, patarei, elektrimootor, transistor, teleskoop, puutetundlik
Topics RU: природоведение
Topics EN: science
Headings: Lisalugemine. Teadussaavutused ja mobiiltelefon; Taaslaetav patarei; Elektrimootor; Transistor; Teleskoop; Puutetundlik ekraan; Mobiiltelefoni ekraane valmistatakse kahe tehnoloogia järgi; Mobiiltelefonide taaskasutamine

## Lisalugemine. Laboris tuleb olla ettevaatlik
URL: https://www.opiq.ee/kit/44/chapter/2114
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 10.2
Topics ET: loodusõpetus, lisalugemine, laboris, tuleb, olla, ettevaatlik, ohutusnõuded, ohutusvahendid, ohumärgid
Topics RU: природоведение
Topics EN: science
Headings: Lisalugemine. Laboris tuleb olla ettevaatlik; Ohutusnõuded; Ohutusvahendid; Ohumärgid; Ülesanded

## Lisalugemine. Laborivahendid
URL: https://www.opiq.ee/kit/44/chapter/2115
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 10.3
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, lisalugemine, laborivahendid, ainete, segamine, hoidmine, kuumutamine, valamine, kuivatamine
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Lisalugemine. Laborivahendid; Ainete segamine, hoidmine ja kuumutamine; Ainete mõõtmine ja valamine; Ainete kuivatamine ja bakterite kasvatamine; Pipetid; Portselanist vahendid ja piirituslamp

## Lisalugemine. Perioodilisustabel
URL: https://www.opiq.ee/kit/44/chapter/2116
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 10.4
Topics ET: loodusõpetus, lisalugemine, perioodilisustabel
Topics RU: природоведение
Topics EN: science
Headings: Lisalugemine. Perioodilisustabel; Perioodilisustabel

## Mõisted
URL: https://www.opiq.ee/kit/44/chapter/2117
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 10.5
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/44/chapter/2118
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 10.6
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Mõõteriistad
URL: https://www.opiq.ee/kit/44/chapter/2065
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 2.1
Topics ET: loodusõpetus, mõõteriistad, mõõdetakse, mõõteriistadega, miks, eelistada, mõõteriistaga, mõõtmist, mõne, käepärase
Topics RU: природоведение
Topics EN: science
Headings: Mõõteriistad; Mõõdetakse mõõteriistadega; Miks eelistada mõõteriistaga mõõtmist mõne käepärase vahendiga mõõtmisele?; Mõtle!; Täpsus ja mõõtepiirkond; Mõõteriist ja mõõtepiirkond (3); Mõõteriist ja mõõtepiirkond (1); Mõõteriist ja mõõtepiirkond (2); Mõõteriista skaala; Kui täpne on see mõõteriist? (3); Kui täpne on see mõõteriist? (1); Kui täpne on see mõõteriist? (2); Nooniuse skaala; Kalibreerimine ja taatlemine; Olulised mõisted

## Otsesed ja kaudsed mõõtmised. Mõõtmistulemuste keskmistamine
URL: https://www.opiq.ee/kit/44/chapter/2066
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 2.2
Topics ET: loodusõpetus, otsesed, kaudsed, mõõtmised, mõõtmistulemuste, keskmistamine, millistel, juhtudel, saadakse, tulemus
Topics RU: природоведение
Topics EN: science
Headings: Otsesed ja kaudsed mõõtmised. Mõõtmistulemuste keskmistamine; Otsesed ja kaudsed mõõtmised; Millistel juhtudel saadakse tulemus otsesel mõõtmisel?; Mõtle!; Mõõtmistulemuste keskmistamine; Aritmeetiline keskmine; Miks leiutati arvuti?; Olulised mõisted

## Mõõtmise määramatus. Mõõtmistulemuste esitamine
URL: https://www.opiq.ee/kit/44/chapter/2067
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 2.3
Topics ET: loodusõpetus, mõõtmise, määramatus, mõõtmistulemuste, esitamine, täpsusklass, mõõtemääramatus, mõtle, olulised, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõõtmise määramatus. Mõõtmistulemuste esitamine; Täpsusklass ja mõõtemääramatus; Mõtle!; Mõõtmistulemuste esitamine; Olulised mõisted

## Mõõtmismeetodid I
URL: https://www.opiq.ee/kit/44/chapter/2068
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 2.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, mõõtmismeetodid, mõtle, pindala, ruumala, sukeldusmeetod, kantmeeter, olulised, mõisted
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mõõtmismeetodid I; Mõõtmismeetodid; Mõtle!; Pindala mõõtmine; Ruumala mõõtmine; Sukeldusmeetod; Mõtle; Kantmeeter; Olulised mõisted

## Mõõtmismeetodid II
URL: https://www.opiq.ee/kit/44/chapter/2069
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 2.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, inimene, keha, meeled, tervis, mõõtmismeetodid, kaal, mõtle, kaalumine, tiheduse, olulised
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, человек, тело, чувства, здоровье
Topics EN: science, measurement, unit, length, mass, volume, human, body, senses, health
Headings: Mõõtmismeetodid II; Keha mass ja kaal; Mõtle!; Kaalumine; Tiheduse mõõtmine; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2070
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 2.6
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, lühikokkuvõte, mõisted, joonised, graafikud, valemid, mõõtemääramatus, täpsusklass
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка
Topics EN: science, measurement, unit, length, mass, volume, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Joonised, graafikud ja valemid; Mõõtemääramatus, mõõtühik ja täpsusklass; Aritmeetilise keskmise arvutamine; Tiheduse arvutamine; Mõõtmistulemuste esitamine graafikul ja mõõtemääramatuse märkimine; Kordamisküsimused

## Mis on liikumine?
URL: https://www.opiq.ee/kit/44/chapter/2071
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 3.1
Topics ET: loodusõpetus, aeg, kell, kalender, liikumine, mehaaniline, mõtle, mehaanilise, liikumise, liigid, liikumisel, olulised, teepikkus
Topics RU: природоведение, время, часы, календарь
Topics EN: science, time, clock, calendar
Headings: Mis on liikumine?; Mehaaniline liikumine; Mõtle!; Mehaanilise liikumise liigid; Liikumisel on olulised aeg ja teepikkus; Olulised mõisted

## Liikumise kujutamine graafikul. Ühtlane ja mitteühtlane liikumine
URL: https://www.opiq.ee/kit/44/chapter/2072
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 3.2
Topics ET: loodusõpetus, liikumise, kujutamine, graafikul, ühtlane, mitteühtlane, liikumine, ühtlase, graafik, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Liikumise kujutamine graafikul. Ühtlane ja mitteühtlane liikumine; Ühtlase liikumise graafik; Mõtle!; Mitteühtlase liikumise graafik; Keskmine kiirus; Olulised mõisted

## Mis on jõud?
URL: https://www.opiq.ee/kit/44/chapter/2073
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 3.3
Topics ET: loodusõpetus, jõud, selle, rakendamine, mõtle, dünamomeeter, olulised, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mis on jõud?; Jõud ja selle rakendamine; Mõtle!; Dünamomeeter; Olulised mõisted

## Raskusjõud
URL: https://www.opiq.ee/kit/44/chapter/2074
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 3.4
Topics ET: loodusõpetus, raskusjõud, newton, kirjeldas, gravitatsioonijõudu, mõtle, raskusjõu, tegur, pole, muutumatu
Topics RU: природоведение
Topics EN: science
Headings: Raskusjõud; Newton kirjeldas gravitatsioonijõudu; Mõtle!; Raskusjõu tegur pole muutumatu; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2075
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 3.5
Topics ET: loodusõpetus, kordamine, korda, harjutan, lühikokkuvõte, mõisted, graafikud, valemid, kiiruse, arvutamine, ühtlase, liikumise
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Graafikud, valemid; Kiiruse arvutamine; Ühtlase liikumise graafik; Mitteühtlase liikumise graafik; Jõu ühik ja tähis; Raskusjõu arvutamine; Kordamisküsimused

## Mehaaniline töö
URL: https://www.opiq.ee/kit/44/chapter/2076
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 4.1
Topics ET: loodusõpetus, mehaaniline, mõtle, õuna, kukkumisel, koer, teeb, tööd, olulised, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mehaaniline töö; Mis on mehaaniline töö?; Mõtle!; Töö õuna kukkumisel; Koer teeb tööd; Olulised mõisted

## Mis on energia?
URL: https://www.opiq.ee/kit/44/chapter/2077
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 4.2
Topics ET: loodusõpetus, energia, omavahel, mõtle, energial, kindlad, tunnused, muundumine, ülekandumine, looduses
Topics RU: природоведение
Topics EN: science
Headings: Mis on energia?; Energia ja töö on omavahel seotud; Mõtle!; Energial on kindlad tunnused; Energia muundumine ja ülekandumine looduses; Millised väited energia kohta on õiged?; Energia salvestumine maavarades; Nafta on energiarikas, sest; Olulised mõisted

## Potentsiaalne ja kineetiline energia
URL: https://www.opiq.ee/kit/44/chapter/2078
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 4.3
Topics ET: loodusõpetus, potentsiaalne, kineetiline, energia, seisuenergia, mõtle, liikumisenergia, muundumine, olulised, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Potentsiaalne ja kineetiline energia; Potentsiaalne ehk seisuenergia; Mõtle!; Kineetiline ehk liikumisenergia; Energia muundumine; Olulised mõisted

## Energia tarbimine
URL: https://www.opiq.ee/kit/44/chapter/2079
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 4.4
Topics ET: loodusõpetus, energia, tarbimine, oskus, energiat, muundada, inimese, saladus, mõtle, energiaallikad
Topics RU: природоведение
Topics EN: science
Headings: Energia tarbimine; Oskus energiat muundada on inimese edu saladus; Mõtle!; Energiaallikad; Energia kokkuhoid ja materjali taaskasutus; Ökoloogiline jalajälg; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2080
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 4.5
Topics ET: loodusõpetus, kordamine, korda, harjutan, inimene, keha, meeled, tervis, lühikokkuvõte, mõisted, ristsõna, valemid, mehaaniline, ühik, džaul, maapinnast
Topics RU: природоведение, повторение, повтори, тренировка, человек, тело, чувства, здоровье
Topics EN: science, revision, review, practice, human, body, senses, health
Headings: Kordamine; Lühikokkuvõte; Mõisted; Ristsõna; Valemid; Mehaaniline töö; Töö ühik on džaul (1 J); Maapinnast kõrgemal asuva keha potentsiaalne energia; Kineetiline energia; Kordamisküsimused

## Mis on aatom?
URL: https://www.opiq.ee/kit/44/chapter/2081
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 5.1
Topics ET: loodusõpetus, aatom, aatomi, ehitus, tervikuna, laenguta, olulised, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mis on aatom?; Aatomi ehitus; Aatom on tervikuna laenguta; Olulised mõisted

## Aatomi tuum ja mass
URL: https://www.opiq.ee/kit/44/chapter/2082
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 5.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, aatomi, tuum, aatomituuma, ehitus, piirkonnad, aatomis, millistest, osakestest
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Aatomi tuum ja mass; Aatomituuma ehitus; Eri piirkonnad aatomis; Millistest osakestest koosneb aatom?; Mis annavad aatomile massi?; Mõtle!; Aatomi mass on 96 amü ja prootoneid on 42. Mitu neutronit on aatomis?; Aatomis on 4 prootonit ja 5 neutronit. Mis on selle aatomi mass?; Olulised mõisted

## Keemilised elemendid
URL: https://www.opiq.ee/kit/44/chapter/2083
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 5.3
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, keemilised, elemendid, prootonite, määrab, aatomi, liigi, keemilise, elemendi, esimesed
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Keemilised elemendid; Prootonite arv määrab aatomi liigi ehk keemilise elemendi; Esimesed 18 elementi; Mõtle!; Keemiline element ja lihtaine; Olulised mõisted

## Tähtsamad elemendid
URL: https://www.opiq.ee/kit/44/chapter/2084
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 5.4
Topics ET: loodusõpetus, tähtsamad, elemendid, vesinik, vesiniku, aatomeid, leidub, lihtainena, süsinik, süsiniku
Topics RU: природоведение
Topics EN: science
Headings: Tähtsamad elemendid; Vesinik (H); Vesiniku aatomeid leidub; Vesinik lihtainena on; Süsinik (C); Süsiniku aatomeid leidub; Süsinik lihtainena on; Hapnik (O); Mõtle!; Hapniku aatomeid leidub; Hapnik lihtainena on; Osoonikiht; Lämmastik (N); Lämmastiku aatomeid leidub; Lämmastik lihtainena on; Olulised mõisted

## Perioodilisustabel
URL: https://www.opiq.ee/kit/44/chapter/2085
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 5.5
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, perioodilisustabel, prootonite, justkui, elemendi, järjenumber, millega, võrdub, elektronide, süsiniku
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Perioodilisustabel; Prootonite arv on justkui elemendi järjenumber; Millega võrdub prootonite arv?; Elektronide arv; Süsiniku aatomi ehitus; Hapniku aatomi ehitus; Elektronkate; Liitiumi aatomi järjenumber on 3. Mitu elektronkihti on liitiumi aatomis?; Periood ehk rida; Pildil on hõbeda aatom. Mitmendas perioodis hõbe asub?; Pildil on argooni aatom. Mitmendas perioodis argoon asub?; Perioodilisustabeli tulp ehk rühm; Mitu siirdemetallide rühma on perioodilisustabelis?; Mitu põhirühma on perioodilisustabelis?; Mitu elektroni on väävli väliskihil?; Mitu elektroni on boori väliskihil?; Olulised mõisted

## Elektronskeem
URL: https://www.opiq.ee/kit/44/chapter/2086
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 5.6
Topics ET: loodusõpetus, elektronskeem, elektronkatte, ehitus, perioodilisustabeli, põhjal, elektronskeemi, koostamine, mõtle, olulised
Topics RU: природоведение
Topics EN: science
Headings: Elektronskeem; Elektronkatte ehitus perioodilisustabeli põhjal; Elektronskeemi koostamine; Mõtle!; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2087
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 5.7
Topics ET: loodusõpetus, kordamine, korda, harjutan, lühikokkuvõte, mõisted, keemia, ajaloost, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Keemia ajaloost; Kordamisküsimused

## Mis on molekul, mis aine ja mis aineosake?
URL: https://www.opiq.ee/kit/44/chapter/2088
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 6.1
Topics ET: loodusõpetus, molekul, aine, aineosake, osake, molekulaarsed, ained, metaan, molekuli, koostist
Topics RU: природоведение
Topics EN: science
Headings: Mis on molekul, mis aine ja mis aineosake?; Aine ja osake; Molekulaarsed ained; Metaan; Molekuli koostist väljendab molekulvalem; Kuidas leida molekuli massi?; Mõtle!; Mis on lämmastiku (N2) molekulmass?; Mis on osooni (O3) molekulmass?; Mittemolekulaarsed ained; Ristsõna; Kuld ja toiduõli; Olulised mõisted

## Keemiline reaktsioon. Põlemine
URL: https://www.opiq.ee/kit/44/chapter/2089
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 6.2
Topics ET: loodusõpetus, keemiline, reaktsioon, põlemine, keemilise, reaktsiooni, tunnused, mõtle, keemilisi, reaktsioone
Topics RU: природоведение
Topics EN: science
Headings: Keemiline reaktsioon. Põlemine; Põlemine kui keemiline reaktsioon; Keemilise reaktsiooni tunnused; Mõtle!; Keemilisi reaktsioone on võimalik kiirendada; Reaktsioonivõrrand; Reaktsioonivõrrand võib vajada tasakaalustamist; Olulised mõisted

## Keemilised reaktsioonid organismides
URL: https://www.opiq.ee/kit/44/chapter/2090
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 6.3
Topics ET: loodusõpetus, keemilised, reaktsioonid, organismides, lahutamatu, vajab, energiat, mõtle, hapnik, aitab
Topics RU: природоведение
Topics EN: science
Headings: Keemilised reaktsioonid organismides; Keemilised reaktsioonid on elu lahutamatu osa; Elu vajab energiat; Mõtle!; Hapnik aitab glükoosist energia kätte saada; Surnud organismi energia läheb keskkonda tagasi; Olulised mõisted

## Süsinik ringleb
URL: https://www.opiq.ee/kit/44/chapter/2091
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 6.4
Topics ET: loodusõpetus, süsinik, ringleb, alus, süsinikuringe, mõtle, milliste, protsesside, käigus, süsihappegaasi
Topics RU: природоведение
Topics EN: science
Headings: Süsinik ringleb; Süsinik on elu alus; Süsinikuringe; Mõtle!; Milliste protsesside käigus õhu süsihappegaasi sisaldus suureneb, milliste protsesside käigus väheneb?; Fossiilsed kütused; Kasvuhooneefekt; Millised väited kasvuhooneefekti kohta on õiged?; Olulised mõisted

## Perioodilisustabel on töövahend
URL: https://www.opiq.ee/kit/44/chapter/2092
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 6.5
Topics ET: loodusõpetus, perioodilisustabel, töövahend, väline, elektronkiht, määrab, elemendile, vastava, lihtaine, omadused
Topics RU: природоведение
Topics EN: science
Headings: Perioodilisustabel on töövahend; Väline elektronkiht määrab elemendile vastava lihtaine omadused; Elemendid liidavad ja loovutavad elektrone; Metallid, poolmetallid, mittemetallid; Mõtle!; Olulised mõisted

## Lisalugemine. Perioodilisustabeli rühmad
URL: https://www.opiq.ee/kit/44/chapter/2094
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 6.6
Topics ET: loodusõpetus, lisalugemine, perioodilisustabeli, rühmad, leelis, leelismuldmetallid, reageerivad, kergesti, rühmades, siirdemetallid
Topics RU: природоведение
Topics EN: science
Headings: Lisalugemine. Perioodilisustabeli rühmad; Leelis- ja leelismuldmetallid reageerivad kergesti; B-rühmades on siirdemetallid; IIIA–VIA rühmas elementide omadused rühma piires muutuvad; Halogeenidel on elektronoktetist puudu üks elektron; Tabeli viimane rühm on väärisgaasid

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2093
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 6.7
Topics ET: loodusõpetus, kordamine, korda, harjutan, lühikokkuvõte, mõisted, reaktsioonivõrrandi, selgitus, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Reaktsioonivõrrandi selgitus; Kordamisküsimused

## Mis on ioon?
URL: https://www.opiq.ee/kit/44/chapter/2095
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 7.1
Topics ET: loodusõpetus, ioon, miks, kuidas, saavad, aatomitest, ioonid, mõtle, metallide, aatomid
Topics RU: природоведение
Topics EN: science
Headings: Mis on ioon?; Miks ja kuidas saavad aatomitest ioonid?; Mõtle!; Metallide aatomid moodustavad positiivse laenguga ioone; Mittemetallid moodustavad sageli negatiivse laenguga ioone; Olulised mõisted

## Ioonilised ained
URL: https://www.opiq.ee/kit/44/chapter/2096
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 7.2
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, ioonilised, ained, keedusool, iooniline, aine, keedusoola, tekkimine, mõtle, saavad
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Ioonilised ained; Keedusool on iooniline aine; Keedusoola tekkimine; Mõtle!; Ioonilised ained saavad nimetuse neid moodustavate ioonide järgi; Ioonilise aine valem näitab iooni liiki ja arvu aineosakeses; Olulised mõisted

## Keemilised sidemed
URL: https://www.opiq.ee/kit/44/chapter/2097
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 7.3
Topics ET: loodusõpetus, keemilised, sidemed, keemiliste, sidemete, tüübid, molekulis, kovalentne, side, vesiniku
Topics RU: природоведение
Topics EN: science
Headings: Keemilised sidemed; Keemiliste sidemete tüübid; Molekulis on kovalentne side; Vesiniku molekulis on üks kovalentne side; Vee molekulis on kaks kovalentset sidet; Mõtle!; Ioonilises aines on iooniline side; Metallides on metalliline side; Olulised mõisted

## Liht- ja liitained
URL: https://www.opiq.ee/kit/44/chapter/2098
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 7.4
Topics ET: loodusõpetus, liht, liitained, lihtained, ainerühmadesse, jaotamine, toimub, aine, ehituse, järgi
Topics RU: природоведение
Topics EN: science
Headings: Liht- ja liitained; Lihtained; Liitained; Ainerühmadesse jaotamine toimub aine ehituse järgi; Mõtle!; Olulised mõisted

## Lisalugemine. Aine, aineosakeste ja keemiliste sidemete kokkuvõte
URL: https://www.opiq.ee/kit/44/chapter/2101
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 7.5
Topics ET: loodusõpetus, lisalugemine, aine, aineosakeste, keemiliste, sidemete, kokkuvõte, aineosakesed, keemilised, sidemed
Topics RU: природоведение
Topics EN: science
Headings: Lisalugemine. Aine, aineosakeste ja keemiliste sidemete kokkuvõte; Aineosakesed ja keemilised sidemed; Mõtle!; Ainete jagunemine; Aine ja aineosakeste kokkuvõtlik skeem

## Ainete omadused
URL: https://www.opiq.ee/kit/44/chapter/2099
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 7.6
Topics ET: loodusõpetus, ainete, omadused, füüsikalised, keemilised, millised, neist, aine, olek, need
Topics RU: природоведение
Topics EN: science
Headings: Ainete omadused; Ainete füüsikalised ja keemilised omadused; Millised neist on keemilised omadused?; Aine olek; Kas need ained/ainete segud on toatemperatuuril tahked, vedelad või gaasilised?; Elektri- ja soojusjuhtivus; Kas aine või ainete segu on hea soojusjuht?; Kas aine või ainete segu juhib elektrit?; Mõtle!; Aine tugevus ja kõvadus on erinevad omadused; Millisel juhul on olulisem materjali kõvadus, millisel tugevus?; Keemilised omadused; Milliseid keemilisi omadusi need laused iseloomustavad?; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2100
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 7.7
Topics ET: loodusõpetus, kordamine, korda, harjutan, lühikokkuvõte, mõisted, ristsõna, aine, ainet, moodustavad, aineosakesed, ning
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Ristsõna; Aine ja ainet moodustavad aineosakesed ning keemilised sidemed; Kordamisküsimused

## Mis on temperatuur?
URL: https://www.opiq.ee/kit/44/chapter/2102
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 8.1
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, temperatuur, mõtle, milline, tundub, aine, kiiresti, liiguvad, aines, molekulid
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mis on temperatuur?; Temperatuur; Mõtle!; Milline tundub aine temperatuur?; Kui kiiresti liiguvad aines molekulid?; Milline on aine temperatuur?; Soojusliikumine; Millised väited soojusliikumise kohta on õiged?; Temperatuuri skaala; Temperatuuri mõõtmine; Celsiuse ja Kelvini skaala temperatuuri mõõtmiseks; Teisendamine; Olulised mõisted

## Soojuspaisumine
URL: https://www.opiq.ee/kit/44/chapter/2103
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 8.2
Topics ET: loodusõpetus, soojuspaisumine, gaasid, vedelikud, paisuvad, tahketest, kehadest, rohkem, mõtle, tahkete
Topics RU: природоведение
Topics EN: science
Headings: Soojuspaisumine; Gaasid ja vedelikud paisuvad tahketest kehadest rohkem; Mõtle!; Tahkete ainete paisumine; Materjalid paisuvad erinevalt; Olulised mõisted

## Soojusenergia kui üks energia liik
URL: https://www.opiq.ee/kit/44/chapter/2104
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 8.3
Topics ET: loodusõpetus, liitmine, liida, summa, kokku, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis, soojusenergia, energia, liik, temperatuur, tõuseb, aine, saab, lisaenergiat
Topics RU: природоведение, сложение, сложи, сумма, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье
Topics EN: science, addition, add, sum, comparison, compare, greater, less, human, body, senses, health
Headings: Soojusenergia kui üks energia liik; Keha temperatuur tõuseb, kui aine saab lisaenergiat; Mõtle!; Soojusenergia; Soojuslik tasakaal; Milline on vee temperatuur pärast mõlemas anumas oleva vee kokkuvalamist, kui segada kokku kaks erinevas koguses ja erineva temperatuuriga vett?; Milline on vee temperatuur pärast mõlemas anumas oleva vee kokkuvalamist?; Temperatuuri tõus sõltub aine massist ja lisaenergia hulgast; Mitme kraadi võrra tõuseb vee temperatuur?; Ained salvestavad soojusenergiat erinevalt; Kumma keha soojusenergia on suurem? (2); Kumma keha soojusenergia on suurem? (1); Olulised mõisted

## Soojusülekanne
URL: https://www.opiq.ee/kit/44/chapter/2105
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 8.4
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, soojusülekanne, energia, pidevas, liikumises, mõtle, soojusjuhtivus, oleneb, materjalist
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Soojusülekanne; Energia on pidevas liikumises; Mõtle!; Keha soojusjuhtivus oleneb keha materjalist; Soojusenergia võib üle kanduda liikuva ainega; Energia võib üle kanduda ka soojuskiirgusega; Olulised mõisted

## Aine olekute muutumine
URL: https://www.opiq.ee/kit/44/chapter/2106
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 8.5
Topics ET: loodusõpetus, aine, olekute, muutumine, üleminek, teise, olekusse, mõtle, millise, oleku
Topics RU: природоведение
Topics EN: science
Headings: Aine olekute muutumine; Aine üleminek teise olekusse; Mõtle!; Millise aine oleku muutusega on tegemist?; Aine olek sõltub temperatuurist; Oleku muutumise korral energia vabaneb või salvestub aines; Kas energia vabaneb või salvestub?; Aine oleku muutumisel on looduses oluline roll; Jäätumine; Aine oleku kirjeldamine aineosakeste mudeliga; Millises olekus liiguvad aineosakesed kiiremini?; Millises olekus on aine tihedam?; Olulised mõisted

## Keskkond kujundab organisme
URL: https://www.opiq.ee/kit/44/chapter/2107
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 8.6
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, kujundab, organisme, mõjutab, looduslikku, tasakaalu, mõtle, organismide
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Keskkond kujundab organisme; Inimene mõjutab looduslikku tasakaalu; Mõtle!; Keskkond mõjutab organismide kasvu ja arengut; Elusolendid on kohastunud oma elukeskkonnaga; Elu jooksul toimuvad muutused on pöörduvad; Kas tegemist on kohastumuse või kohanemisega?; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2108
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 8.7
Topics ET: loodusõpetus, kordamine, korda, harjutan, lühikokkuvõte, mõisted, ristsõna, joonised, tabelid, celsiuse, kelvini, temperatuuriskaala
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Ristsõna; Joonised ja tabelid; Celsiuse ja Kelvini temperatuuriskaala; Aine oleku üleminek vee näitel; Kohastumine ja kohanemine; Kordamisküsimused

## Ainete segud
URL: https://www.opiq.ee/kit/44/chapter/2109
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 9.1
Topics ET: loodusõpetus, ainete, segud, puhas, aine, segu, millised, pildil, huulepulk, teras
Topics RU: природоведение
Topics EN: science
Headings: Ainete segud; Puhas aine ja ainete segu; Millised on ainete segud?; Kas pildil on puhas aine või segu? (1); Kas pildil on puhas aine või segu? (2); Aine ja materjal; Huulepulk; Teras; Betoon; Mõtle!; Olulised mõisted

## Mis on lahus?
URL: https://www.opiq.ee/kit/44/chapter/2110
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 9.2
Topics ET: loodusõpetus, lahus, ainete, ühtlane, segu, puljong, puljongis, lahusti, morsi, tegemiseks
Topics RU: природоведение
Topics EN: science
Headings: Mis on lahus?; Lahus on ainete ühtlane segu; Puljong on lahus. Mis on puljongis lahusti?; Morsi tegemiseks kasutati 1 osa siirupit ja 8 osa vett. Mis on lahustiks?; Lahustumise kiirendamine; Lahustumise kiirendamise viisid; Millist lahustumise kiirendamise viisi kasutaksid?; Ioonilised ained lahustuvad vees; Iooniliste ainete lahused; Gaasiliste ainete lahustumine on samuti oluline; Mõtle!; Akvaariumites on oluline õhku vette pumbata, sest; Olulised mõisted

## Segudest ainete lahutamine
URL: https://www.opiq.ee/kit/44/chapter/2111
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 9.3
Topics ET: loodusõpetus, lahutamine, lahuta, vahe, vesi, veeohutus, veekogu, segudest, ainete, aineid, saab, segust, eraldada, sest, neil
Topics RU: природоведение, вычитание, вычти, разность, вода, безопасность на воде, водоём
Topics EN: science, subtraction, subtract, difference, water, water safety, body of water
Headings: Segudest ainete lahutamine; Aineid saab segust eraldada, sest neil on erinevad omadused; Ainete eraldamine osakeste suuruse või raskuse järgi; Sõelumine; Nõrutamine; Filtrimine; Millist meetodit kasutaksid ainete eraldamiseks?; Ainete eraldamine magnetiga; Sahtel oli väga segamini läinud. Milliseid asju saaks teistest magnetiga eraldada?; Ainete eraldamine keemistemperatuuri järgi; Aurustamine; Destilleerimine; Mõtle!; Millisel juhul sobib paremini aurustamine, millisel juhul destilleerimine?; Kumb hakkab varem keema, kas etanool või vesi?; Destilleerimise kasutusalad; Olulised mõisted

## Kordamine
URL: https://www.opiq.ee/kit/44/chapter/2112
Book: Loodusõpetus 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k_loodusõpetus_avita_est
Chapter ID: 9.4
Topics ET: loodusõpetus, kordamine, korda, harjutan, lühikokkuvõte, mõisted, ainete, segude, ajaloost, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Lühikokkuvõte; Mõisted; Ainete ja segude ajaloost; Kordamisküsimused

## Природо­ведение для 7 класса – Opiq
URL: https://www.opiq.ee/Kit/Details/64
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 238
Topics ET: loodusõpetus, opiq
Topics RU: природоведение, природо, ведение, класса
Topics EN: science

## Естественные науки
URL: https://www.opiq.ee/kit/64/chapter/3052
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 1.1
Topics ET: loodusõpetus
Topics RU: природоведение, естественные, науки, изучают, естественнонаучный, метод, исследования, этапы, естественнонаучного, метода
Topics EN: science
Headings: Естественные науки; Что изучают естественные науки?; Естественнонаучный метод исследования; Этапы естественнонаучного метода исследования; Классификация природных явлений; Вдыхание воздуха характеризуется физическими, химическими и биологическими признаками. К каким признакам относятся следующие процессы?; Как применять естественнонаучный метод исследования в повседневной жизни?; К какому этапу естественнонаучного метода исследования относится следующее утверждение?; Основные понятия

## Физические тела и измерение
URL: https://www.opiq.ee/kit/64/chapter/3053
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 1.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, inimene, keha, meeled, tervis
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, человек, тело, чувства, здоровье, физические, тела, физическое, чего, необходимо, проводить, измерения
Topics EN: science, measurement, unit, length, mass, volume, human, body, senses, health
Headings: Физические тела и измерение; Физические тела; Физическое тело; Для чего необходимо проводить измерения?; Какие результаты можно получить в ходе измерения?; Примеры физических величин и соответствующих единиц измерения; Естественнонаучный метод исследования; Старинные единицы измерения; Основные понятия

## Модели и символы
URL: https://www.opiq.ee/kit/64/chapter/3054
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 1.3
Topics ET: loodusõpetus
Topics RU: природоведение, модели, символы, модель, символ, химии, обозначения, элементов, являются, важными
Topics EN: science
Headings: Модели и символы; Модель и символ; Модели и символы в химии; Обозначения элементов являются важными химическими символами; Символы химических элементов; Основные понятия

## Обозначения и единицы измерения I
URL: https://www.opiq.ee/kit/64/chapter/3055
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 1.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, обозначения, единицы, измерения, обозначение, физических, величин, единиц, какие, символы
Topics EN: science, measurement, unit, length, mass, volume
Headings: Обозначения и единицы измерения I; Обозначение физических величин и единиц; Какие символы обозначают физические величины?; Из символов составляют формулы; Составление формулы; Основные и производные единицы; Какие единицы являются основными, а какие – производными?; Единица измерения дюйм; Основные понятия

## Обозначения и единицы измерения II
URL: https://www.opiq.ee/kit/64/chapter/3056
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 1.5
Topics ET: loodusõpetus
Topics RU: природоведение, обозначения, единицы, измерения, приставки, используются, записи, кратных, единиц, перед
Topics EN: science
Headings: Обозначения и единицы измерения II; Приставки используются для записи кратных единиц; Приставки единиц измерения; Перед проведением вычислений нужно выразить величины в одинаковых единицах; Вычисление; Десятичная система счисления – не единственная важная система; Единицы измерения времени; Двоичная система; Постоянные, или неменяющиеся величины; Константа; Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3057
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 1.6
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, краткое, содержание, основные, понятия, таблицы, рисунки, этапы, естественнонаучного
Topics EN: science, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Таблицы и рисунки; Этапы естественнонаучного метода исследования​; Основные единицы СИ​; Важнейшие приставки и их обозначения​; Вопросы для повторения

## Научные достижения и мобильный телефон
URL: https://www.opiq.ee/kit/64/chapter/3106
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 10.1
Topics ET: loodusõpetus
Topics RU: природоведение, научные, достижения, мобильный, телефон, заряжаемая, батарейка, электромотор, транзистор, телескоп
Topics EN: science
Headings: Научные достижения и мобильный телефон; Заряжаемая батарейка; Электромотор; Транзистор; Телескоп; Сенсорный экран; Экраны для мобильных телефонов изготавливаются по двум технологиям; Повторное использование мобильных телефонов

## В лаборатории следует проявлять осторожность
URL: https://www.opiq.ee/kit/64/chapter/3107
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 10.2
Topics ET: loodusõpetus
Topics RU: природоведение, лаборатории, следует, проявлять, осторожность, правила, техники, безопасности, средства, защиты
Topics EN: science
Headings: В лаборатории следует проявлять осторожность; Правила техники безопасности; Средства защиты и безопасности; Символы опасности

## Лабораторная посуда и оборудование
URL: https://www.opiq.ee/kit/64/chapter/3108
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 10.3
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, лабораторная, посуда, оборудование, смешивание, хранение, нагревание, веществ, переливание
Topics EN: science, measurement, unit, length, mass, volume
Headings: Лабораторная посуда и оборудование; Смешивание, хранение и нагревание веществ; Измерение и переливание веществ; Высушивание веществ и выращивание бактерий; Пипетки; Фарфоровая посуда и спиртовка

## Таблица периодической системы химических элементов
URL: https://www.opiq.ee/kit/64/chapter/3109
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 10.4
Topics ET: loodusõpetus
Topics RU: природоведение, таблица, периодической, системы, химических, элементов
Topics EN: science
Headings: Таблица периодической системы химических элементов

## Импрессум
URL: https://www.opiq.ee/kit/64/chapter/3110
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 11.1
Topics ET: loodusõpetus
Topics RU: природоведение, импрессум
Topics EN: science
Headings: Импрессум

## Авторы использованных рисунков, фотографий, иллюстраций и видео
URL: https://www.opiq.ee/kit/64/chapter/3111
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 11.2
Topics ET: loodusõpetus
Topics RU: природоведение, авторы, использованных, рисунков, фотографий, иллюстраций, видео
Topics EN: science
Headings: Авторы использованных рисунков, фотографий, иллюстраций и видео

## Понятия
URL: https://www.opiq.ee/kit/64/chapter/3112
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 12.1
Topics ET: loodusõpetus
Topics RU: природоведение, понятия
Topics EN: science
Headings: Понятия

## Измерительные приборы
URL: https://www.opiq.ee/kit/64/chapter/3058
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 2.1
Topics ET: loodusõpetus
Topics RU: природоведение, измерительные, приборы, измерения, используются, почему, измерении, предпочитают, использовать, современные
Topics EN: science
Headings: Измерительные приборы; Для измерения используются измерительные приборы; Почему при измерении предпочитают использовать современные измерительные приборы?; Точность и диапазон измерений; Измерительный прибор и диапазон измерений (3); Измерительный прибор и диапазон измерений (1); Измерительный прибор и диапазон измерений (2); Шкала измерительного прибора; Какова точность измерительного прибора? (3); Какова точность измерительного прибора? (1); Какова точность измерительного прибора? (2); Шкала-нониус; Калибровка и поверка; Что происходит в процессе калибровки и поверки?; Основные понятия

## Прямые и косвенные измерения. Усреднение результатов измерений
URL: https://www.opiq.ee/kit/64/chapter/3059
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 2.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, прямые, косвенные, измерения, усреднение, результатов, измерений, прямое, среднее
Topics EN: science, measurement, unit, length, mass, volume
Headings: Прямые и косвенные измерения. Усреднение результатов измерений; Прямые и косвенные измерения; Прямое измерение; Усреднение результатов измерений; Среднее арифметическое; Для чего изобрели компьютер?; Основные понятия

## Неопределенность измерений. Представление результатов измерений
URL: https://www.opiq.ee/kit/64/chapter/3060
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 2.3
Topics ET: loodusõpetus
Topics RU: природоведение, неопределенность, измерений, представление, результатов, класс, точности, каком, виде, следует
Topics EN: science
Headings: Неопределенность измерений. Представление результатов измерений; Класс точности и неопределенность измерений; Класс точности и неопределенность измерений (2); Класс точности и неопределенность измерений (1); Представление результатов измерений; В каком виде следует представить данные?; Основные понятия

## Методы измерений I
URL: https://www.opiq.ee/kit/64/chapter/3061
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 2.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, методы, измерений, измерения, площади, объема, метод, погружения, кубометр
Topics EN: science, measurement, unit, length, mass, volume
Headings: Методы измерений I; Методы измерения; Измерение площади; Измерение объема; Метод погружения; Кубометр; Основные понятия

## Методы измерений II
URL: https://www.opiq.ee/kit/64/chapter/3062
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 2.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, методы, измерений, тела, взвешивание, плотности, основные, понятия
Topics EN: science, measurement, unit, length, mass, volume
Headings: Методы измерений II; Масса и вес тела; Взвешивание; Измерение плотности; Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3063
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 2.6
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка, краткое, содержание, основные, понятия, рисунки, графики, формулы, неопределенность
Topics EN: science, measurement, unit, length, mass, volume, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Рисунки, графики и формулы; Неопределенность измерений, единица измерения и класс точности; Вычисление среднего арифметического; Вычисление плотности; Представление результатов измерений в виде графика с указанием неопределенности измерений; Вопросы для повторения

## Что такое движение?
URL: https://www.opiq.ee/kit/64/chapter/3064
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 3.1
Topics ET: loodusõpetus, aeg, kell, kalender
Topics RU: природоведение, время, часы, календарь, такое, движение, механическое, виды, механического, движения, важную, роль, движении
Topics EN: science, time, clock, calendar
Headings: Что такое движение?; Механическое движение; Виды механического движения; Важную роль при движении играют время и расстояние; Основные понятия

## Изображение движения на графике. Равномерное и неравномерное движение
URL: https://www.opiq.ee/kit/64/chapter/3065
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 3.2
Topics ET: loodusõpetus
Topics RU: природоведение, изображение, движения, графике, равномерное, неравномерное, движение, график, равномерного, неравномерного
Topics EN: science
Headings: Изображение движения на графике. Равномерное и неравномерное движение; График равномерного движения; График неравномерного движения; Средняя скорость; Основные понятия

## Что такое сила?
URL: https://www.opiq.ee/kit/64/chapter/3066
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 3.3
Topics ET: loodusõpetus
Topics RU: природоведение, такое, сила, приложение, чего, прикладывается, динамометр, точность, диапазон, измерений
Topics EN: science
Headings: Что такое сила?; Сила и ее приложение; Для чего прикладывается сила? (3); Для чего прикладывается сила? (1); Для чего прикладывается сила? (2); Динамометр; Точность и диапазон измерений динамометра; Основные понятия

## Сила тяжести
URL: https://www.opiq.ee/kit/64/chapter/3067
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 3.4
Topics ET: loodusõpetus
Topics RU: природоведение, сила, тяжести, ньютон, описал, силу, гравитационного, притяжения, коэффициент, силы
Topics EN: science
Headings: Сила тяжести; Ньютон описал силу гравитационного притяжения; Коэффициент силы тяжести – величина непостоянная; Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3068
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 3.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка, краткое, содержание, основные, понятия, графики, формулы, вычисление, скорости
Topics EN: science, measurement, unit, length, mass, volume, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Графики и формулы; Вычисление скорости; График равномерного​​движения​; График неравномерного​движения; Сила и ее единица измерения; Вычисление силы тяжести; Вопросы для повторения

## Механическая работа
URL: https://www.opiq.ee/kit/64/chapter/3069
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение, механическая, работа, такое, падении, яблока, собака, выполняет, работу, основные
Topics EN: science
Headings: Механическая работа; Что такое механическая работа?; Работа при падении яблока; Собака выполняет работу; Основные понятия

## Что такое энергия?
URL: https://www.opiq.ee/kit/64/chapter/3070
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 4.2
Topics ET: loodusõpetus
Topics RU: природоведение, такое, энергия, работа, связаны, друг, другом, имеет, определенные, признаки
Topics EN: science
Headings: Что такое энергия?; Энергия и работа связаны друг с другом; Энергия имеет определенные признаки; Преобразование и перенос энергии в природе; Энергия; Накопление энергии в полезных ископаемых; Нефть богата энергией, потому что...; Основные понятия

## Потенциальная и кинетическая энергия
URL: https://www.opiq.ee/kit/64/chapter/3071
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 4.3
Topics ET: loodusõpetus
Topics RU: природоведение, потенциальная, кинетическая, энергия, покоя, движения, преобразование, энергии, основные, понятия
Topics EN: science
Headings: Потенциальная и кинетическая энергия; Потенциальная энергия, или энергия покоя; Кинетическая энергия, или энергия движения; Преобразование энергии; Основные понятия

## Энергопотребление
URL: https://www.opiq.ee/kit/64/chapter/3072
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 4.4
Topics ET: loodusõpetus
Topics RU: природоведение, энергопотребление, преобразование, энергии, ключ, успехам, человечества, источники, сбережение, вторичное
Topics EN: science
Headings: Энергопотребление; Преобразование энергии – ключ к успехам человечества; Источники энергии; Сбережение энергии и вторичное использование материалов; Экологический след; Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3073
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 4.5
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, краткое, содержание, основные, понятия, таблицы, механическая, работа, потенциальная
Topics EN: science, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Таблицы; Механическая работа; Потенциальная энергия тела, которое находится над поверхностью Земли; Кинетическая энергия; Вопросы для повторения

## Что такое атом?
URL: https://www.opiq.ee/kit/64/chapter/3074
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 5.1
Topics ET: loodusõpetus
Topics RU: природоведение, такое, атом, строение, атома, целом, имеет, заряда, сколько, электронов
Topics EN: science
Headings: Что такое атом?; Строение атома; Атом в целом не имеет заряда; Сколько электронов в атоме, если его заряд равен 6?; Атом...; Основные понятия

## Атомное ядро и его масса
URL: https://www.opiq.ee/kit/64/chapter/3075
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 5.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, атомное, ядро, строение, атомного, ядра, атома, основные, понятия
Topics EN: science, measurement, unit, length, mass, volume
Headings: Атомное ядро и его масса; Строение атомного ядра; Масса атома; Основные понятия

## Химические элементы
URL: https://www.opiq.ee/kit/64/chapter/3076
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 5.3
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid
Topics RU: природоведение, число, числа, цифры, химические, элементы, протонов, определяет, атома, химический, элемент, чему
Topics EN: science, number, numbers, digits
Headings: Химические элементы; Число протонов определяет вид атома, или химический элемент; Чему равен атомный номер?; 18 первых элементов; Химический элемент и простое вещество; Из чего состоит простое вещество?; Основные понятия

## Важнейшие элементы
URL: https://www.opiq.ee/kit/64/chapter/3077
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 5.4
Topics ET: loodusõpetus
Topics RU: природоведение, важнейшие, элементы, водород, атомы, водорода, входят, состав, простое, вещество
Topics EN: science
Headings: Важнейшие элементы; Водород H; Атомы водорода входят в состав...; Простое вещество водород – ...; Углерод C; Атомы углерода входят в состав...; Простое вещество углерод – ...; Кислород O; Атомы кислорода входят в состав...; Простое вещество кислород – ...; Озоновый слой; Азот N; Атомы азота входят в состав...; Простое вещество азот – ...; Основные понятия

## Периодическая система химических элементов
URL: https://www.opiq.ee/kit/64/chapter/3078
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 5.5
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid
Topics RU: природоведение, число, числа, цифры, периодическая, система, химических, элементов, протонов, определяет, порядковый, номер
Topics EN: science, number, numbers, digits
Headings: Периодическая система химических элементов; Число протонов определяет порядковый номер элемента; Количество протонов в атомном ядре соответствует...; Количество электронов; Строение атома углерода; Строение атома кислорода; Электронная оболочка; Порядковый номер лития – 3. Сколько электронных слоев у атома лития?; Периоды (ряды) в таблице периодической системы; Атом серебра; Атом аргона; Группы (столбцы) в таблице периодической системы; Сколько групп переходных металлов в таблице периодической системы?; Сколько основных групп в таблице периодической системы?; Внешний электронный слой атома серы; Внешний электронный слой атома бора; Основные понятия

## Электронная схема
URL: https://www.opiq.ee/kit/64/chapter/3079
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 5.6
Topics ET: loodusõpetus
Topics RU: природоведение, электронная, схема, строение, электронной, оболочки, составление, схемы, аргона, основные
Topics EN: science
Headings: Электронная схема; Строение электронной оболочки; Строение электронной оболочки (2); Строение электронной оболочки (1); Составление электронной схемы; Составление электронной схемы аргона (шаг 3); Составление электронной схемы аргона (шаг 1); Составление электронной схемы аргона (шаг 2); Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3080
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 5.7
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, краткое, содержание, основные, понятия, истории, химии, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Из истории химии; Вопросы для повторения

## Что такое молекула, вещество и частица?
URL: https://www.opiq.ee/kit/64/chapter/3081
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 6.1
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, такое, молекула, вещество, частица, молекулярные, вещества, метан, молекулярная
Topics EN: science, measurement, unit, length, mass, volume
Headings: Что такое молекула, вещество и частица?; Вещество и частица; Молекулярные вещества; Метан; Молекулярная масса (2); Молекулярная масса (1); Немолекулярные вещества; Золото и пищевое масло; Основные понятия

## Химическая реакция. Горение
URL: https://www.opiq.ee/kit/64/chapter/3082
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 6.2
Topics ET: loodusõpetus
Topics RU: природоведение, химическая, реакция, горение, каких, случаях, результате, реакции, горения, образуется
Topics EN: science
Headings: Химическая реакция. Горение; Горение как химическая реакция; В каких случаях в результате реакции горения образуется ядовитый угарный газ?; Какие продукты образуются при сжигании древесины?; Признаки химической реакции; В каких случаях происходят химические реакции?; Химические реакции можно ускорить; Уравнение химической реакции; Уравнивание уравнения химической реакции; Основные понятия

## Химические реакции, протекающие в организмах
URL: https://www.opiq.ee/kit/64/chapter/3083
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 6.3
Topics ET: loodusõpetus
Topics RU: природоведение, химические, реакции, протекающие, организмах, неотъемлемая, часть, жизни, земле, нужна
Topics EN: science
Headings: Химические реакции, протекающие в организмах; Химические реакции как неотъемлемая часть жизни на Земле; Для жизни нужна энергия; Кислород способствует получению энергии из глюкозы; Энергия отмерших организмов возвращается в окружающую среду; Основные понятия

## Круговорот углерода в природе
URL: https://www.opiq.ee/kit/64/chapter/3084
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 6.4
Topics ET: loodusõpetus
Topics RU: природоведение, круговорот, углерода, природе, углерод, является, основой, жизни, углеродный, цикл
Topics EN: science
Headings: Круговорот углерода в природе; Углерод является основой жизни; Углеродный цикл; В результате каких процессов содержание углекислого газа в воздухе увеличивается, а в результате каких – уменьшается?; Ископаемое топливо; Парниковый эффект; Основные понятия

## Периодическая система химических элементов – это рабочий инструмент
URL: https://www.opiq.ee/kit/64/chapter/3085
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 6.5
Topics ET: loodusõpetus
Topics RU: природоведение, периодическая, система, химических, элементов, рабочий, инструмент, внешний, электронный, слой
Topics EN: science
Headings: Периодическая система химических элементов – это рабочий инструмент; Внешний электронный слой определяет свойства простого вещества элемента; Октет электронов; Элементы присоединяют и отдают электроны; Свойства элементов; Металлы, полуметаллы, неметаллы; Металлы, неметаллы и полуметаллы; Основные понятия

## Дополнительный материал. Группы периодической системы
URL: https://www.opiq.ee/kit/64/chapter/3087
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 6.6
Topics ET: loodusõpetus
Topics RU: природоведение, дополнительный, материал, группы, периодической, системы, щелочные, щелочноземельные, металлы, легко
Topics EN: science
Headings: Дополнительный материал. Группы периодической системы; Щелочные и щелочноземельные металлы легко вступают в реакцию; В группах B находятся переходные металлы; В группах IIIA–VIA свойства элементов одной группы отличаются; Галогенам не хватает одного электрона до октета электронов; Последняя группа системы – благородные газы

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3086
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 6.7
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, краткое, содержание, основные, понятия, уравнение, химической, реакции, вопросы
Topics EN: science, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Уравнение химической реакции; Вопросы для повторения

## Что такое ион?
URL: https://www.opiq.ee/kit/64/chapter/3088
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 7.1
Topics ET: loodusõpetus
Topics RU: природоведение, такое, почему, атомов, получаются, ионы, благородные, газы, атомы, металлов
Topics EN: science
Headings: Что такое ион?; Почему и как из атомов получаются ионы?; Благородные газы, атомы и ионы; Атомы металлов образуют положительно заряженные ионы; Образование ионов (1); Неметаллы часто образуют отрицательно заряженные ионы; Образование ионов (2); Основные понятия

## Ионные вещества
URL: https://www.opiq.ee/kit/64/chapter/3089
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 7.2
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid
Topics RU: природоведение, число, числа, цифры, ионные, вещества, поваренная, соль, ионное, вещество, образование, поваренной, соли
Topics EN: science, number, numbers, digits
Headings: Ионные вещества; Поваренная соль – ионное вещество; Образование поваренной соли; Ионные вещества называют по образующим их ионам; Формула ионного вещества показывает вид и число ионов в частице; Основные понятия

## Химические связи
URL: https://www.opiq.ee/kit/64/chapter/3090
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 7.3
Topics ET: loodusõpetus
Topics RU: природоведение, химические, связи, типы, химических, связей, молекуле, ковалентная, связь, какие
Topics EN: science
Headings: Химические связи; Типы химических связей; В молекуле – ковалентная связь; Какие из этих веществ обладают ковалентной связью?; В ионных веществах – ионная связь; Какие из этих веществ обладают ионной связью?; В металлах – металлическая связь; Какие из этих веществ обладают металлической связью?; Основные понятия

## Простые и сложные вещества
URL: https://www.opiq.ee/kit/64/chapter/3091
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 7.4
Topics ET: loodusõpetus
Topics RU: природоведение, простые, сложные, вещества, какие, химические, связи, могут, быть, простых
Topics EN: science
Headings: Простые и сложные вещества; Простые вещества; Какие химические связи могут быть в простых веществах?; Какие вещества являются простыми?; Сложные вещества; Химические связи, сложные вещества; Какие вещества являются сложными?; Классификация веществ по их строению; Простое или сложное, молекулярное или немолекулярное вещество?; Основные понятия

## Дополнительный материал. Вещество, частица вещества и химические связи. Краткие итоги
URL: https://www.opiq.ee/kit/64/chapter/3094
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 7.5
Topics ET: loodusõpetus
Topics RU: природоведение, дополнительный, материал, вещество, частица, вещества, химические, связи, краткие, итоги
Topics EN: science
Headings: Дополнительный материал. Вещество, частица вещества и химические связи. Краткие итоги; Частицы вещества и химические связи; Классификация веществ; Вещество и частицы вещества. Сводная схема

## Свойства веществ
URL: https://www.opiq.ee/kit/64/chapter/3092
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 7.6
Topics ET: loodusõpetus
Topics RU: природоведение, свойства, веществ, физические, какое, агрегатное, состояние, следующих, обладает, вещество
Topics EN: science
Headings: Свойства веществ; Физические свойства веществ; Какое агрегатное состояние у следующих веществ?; Обладает ли вещество (или смесь веществ) электропроводностью?; Обладает ли вещество (или смесь веществ) хорошей теплопроводностью?; В каких случаях важнее твердость, а в каких – прочность?; Химические свойства; Какое химическое свойство показывает знак?; Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3093
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 7.7
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, краткое, содержание, основные, понятия, вещество, частицы, вещества, химические
Topics EN: science, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Вещество, частицы вещества и химические связи; Вопросы для повторения

## Что такое температура?
URL: https://www.opiq.ee/kit/64/chapter/3095
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 8.1
Topics ET: loodusõpetus
Topics RU: природоведение, такое, температура, тепловое, движение, температурная, шкала, температурные, шкалы, цельсия
Topics EN: science
Headings: Что такое температура?; Температура; Тепловое движение; Температурная шкала; Температурные шкалы Цельсия и Кельвина; Основные понятия

## Тепловое расширение
URL: https://www.opiq.ee/kit/64/chapter/3096
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 8.2
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem
Topics RU: природоведение, сравнение, сравни, больше, меньше, тепловое, расширение, газы, жидкости, расширяются, твердые, тела, твердых
Topics EN: science, comparison, compare, greater, less
Headings: Тепловое расширение; Газы и жидкости расширяются больше, чем твердые тела; Расширение твердых веществ; Материалы расширяются по-разному; Основные понятия

## Тепловая энергия как один из видов энергии
URL: https://www.opiq.ee/kit/64/chapter/3097
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 8.3
Topics ET: loodusõpetus
Topics RU: природоведение, тепловая, энергия, один, видов, энергии, температура, тела, повышается, когда
Topics EN: science
Headings: Тепловая энергия как один из видов энергии; Температура тела повышается, когда вещество получает дополнительную энергию; Тепловое равновесие; Повышение температуры зависит от массы вещества и количества дополнительной энергии; Вещества накапливают тепловую энергию по-разному; Основные понятия

## Теплопередача
URL: https://www.opiq.ee/kit/64/chapter/3098
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 8.4
Topics ET: loodusõpetus
Topics RU: природоведение, теплопередача, энергия, находится, постоянном, движении, теплопроводность, тела, зависит, материала
Topics EN: science
Headings: Теплопередача; Энергия находится в постоянном движении; Теплопроводность тела зависит от его материала; Движущееся вещество может переносить энергию; Тепловое излучение может переносить энергию; Основные понятия

## Изменение агрегатного состояния
URL: https://www.opiq.ee/kit/64/chapter/3099
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 8.5
Topics ET: loodusõpetus
Topics RU: природоведение, изменение, агрегатного, состояния, переход, иное, агрегатное, состояние, зависит, температуры
Topics EN: science
Headings: Изменение агрегатного состояния; Переход в иное агрегатное состояние; Агрегатное состояние зависит от температуры; При изменении агрегатного состояния энергия высвобождается или накапливается в веществе; Изменение агрегатного состояния играет важную роль в природе; Агрегатное состояние и частицы вещества; Основные понятия

## Влияние окружающей среды на формирование живых организмов
URL: https://www.opiq.ee/kit/64/chapter/3100
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 8.6
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье, влияние, окружающей, среды, формирование, живых, организмов, влияет, природный
Topics EN: science, nature, environment, human, body, senses, health
Headings: Влияние окружающей среды на формирование живых организмов; Человек влияет на природный баланс; Окружающая среда влияет на рост и развитие живых организмов; Живые организмы приспособились к своей среде обитания; В течение жизни происходят обратимые изменения; Адаптация или акклиматизация?; Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3101
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 8.7
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, краткое, содержание, основные, понятия, рисунки, таблицы, температурные, шкалы
Topics EN: science, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Рисунки и таблицы; Температурные шкалы Цельсия и Кельвина; Изменения агрегатного состояния на примере воды; Адаптация и акклиматизация; Вопросы для повторения

## Смеси веществ
URL: https://www.opiq.ee/kit/64/chapter/3102
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 9.1
Topics ET: loodusõpetus
Topics RU: природоведение, смеси, веществ, чистое, вещество, смесь, материал, смесях, улучшаются, свойства
Topics EN: science
Headings: Смеси веществ; Чистое вещество и смесь веществ; Вещество и материал; В смесях улучшаются свойства материалов; Бетон; Губная помада; Основные понятия

## Что такое раствор?
URL: https://www.opiq.ee/kit/64/chapter/3103
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 9.2
Topics ET: loodusõpetus
Topics RU: природоведение, такое, раствор, однородная, смесь, веществ, бульон, является, раствором, растворителем
Topics EN: science
Headings: Что такое раствор?; Раствор – однородная смесь веществ; Бульон является раствором. Что является растворителем в бульоне?; При приготовлении морса смешивают 1 часть сиропа и 8 частей воды. Что является растворителем?; Ускорение растворения; Какой способ ускорения растворения ты бы использовал?; Ионные вещества растворяются в воде; Растворение ионных веществ; Растворение газообразных веществ также важно; В аквариумы очень важно закачивать воздух, поскольку...; Основные понятия

## Отделение веществ от смесей
URL: https://www.opiq.ee/kit/64/chapter/3104
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 9.3
Topics ET: loodusõpetus
Topics RU: природоведение, отделение, веществ, смесей, разные, свойства, позволяют, отделять, вещества, смеси
Topics EN: science
Headings: Отделение веществ от смесей; Разные свойства веществ позволяют отделять вещества от смеси; Отделение веществ в зависимости от размера частиц или их тяжести; Просеивание; Сцеживание; Фильтрация; Отделение веществ с помощью магнита; Отделение веществ в зависимости от их температуры кипения; Выпаривание; Дистилляция; Области применения дистилляции; Основные понятия

## Повторение
URL: https://www.opiq.ee/kit/64/chapter/3105
Book: Естественные науки
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 7k_loodusõpetus_avita_rus
Chapter ID: 9.4
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, краткое, содержание, основные, понятия, истории, веществ, смесей, вопросы
Topics EN: science, revision, review, practice
Headings: Повторение; Краткое содержание; Основные понятия; Из истории веществ и смесей; Вопросы для повторения

## Loodusõpetus 7. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/100
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 325
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Õppurile
URL: https://www.opiq.ee/kit/100/chapter/4874
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 1.1
Topics ET: loodusõpetus, õppurile
Topics RU: природоведение
Topics EN: science
Headings: Õppurile

## Mida uurivad loodusteadlased
URL: https://www.opiq.ee/kit/100/chapter/4875
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 1.2
Topics ET: loodusõpetus, mida, uurivad, loodusteadlased, kuidas, nähtusi
Topics RU: природоведение
Topics EN: science
Headings: Mida uurivad loodusteadlased; Kuidas uurivad loodusteadlased nähtusi

## Aritmeetilise keskmise arvutamine
URL: https://www.opiq.ee/kit/100/chapter/4938
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.1
Topics ET: loodusõpetus, aritmeetilise, keskmise, arvutamine
Topics RU: природоведение
Topics EN: science
Headings: Aritmeetilise keskmise arvutamine

## Suurim võimalik veeauru hulk õhus
URL: https://www.opiq.ee/kit/100/chapter/4947
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.10
Topics ET: loodusõpetus, suurim, võimalik, veeauru, hulk, õhus
Topics RU: природоведение
Topics EN: science
Headings: Suurim võimalik veeauru hulk õhus

## Keemiliste elementide perioodilisustabel
URL: https://www.opiq.ee/kit/100/chapter/4948
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.11
Topics ET: loodusõpetus, keemiliste, elementide, perioodilisustabel
Topics RU: природоведение
Topics EN: science
Headings: Keemiliste elementide perioodilisustabel

## Pindala arvutamine
URL: https://www.opiq.ee/kit/100/chapter/4939
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.2
Topics ET: loodusõpetus, pindala, arvutamine
Topics RU: природоведение
Topics EN: science
Headings: Pindala arvutamine

## Ruumala arvutamine
URL: https://www.opiq.ee/kit/100/chapter/4940
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.3
Topics ET: loodusõpetus, ruumala, arvutamine
Topics RU: природоведение
Topics EN: science
Headings: Ruumala arvutamine

## Vedeliku ruumala mõõtmine mõõtesilindriga
URL: https://www.opiq.ee/kit/100/chapter/4941
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, vedeliku, ruumala, mõõtesilindriga, enne, mõõtmist, etteantud, vedelikukoguse
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Vedeliku ruumala mõõtmine mõõtesilindriga; Enne mõõtmist; Vedeliku ruumala mõõtmine; Etteantud vedelikukoguse mõõtmine

## Temperatuuri mõõtmine vedeliktermomeetriga
URL: https://www.opiq.ee/kit/100/chapter/4942
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, temperatuuri, vedeliktermomeetriga, enne, mõõtmist
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Temperatuuri mõõtmine vedeliktermomeetriga; Enne mõõtmist; Temperatuuri mõõtmine

## Mõõtühikute eesliiteid
URL: https://www.opiq.ee/kit/100/chapter/4943
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.6
Topics ET: loodusõpetus, mõõtühikute, eesliiteid
Topics RU: природоведение
Topics EN: science
Headings: Mõõtühikute eesliiteid

## Füüsikalisi suurusi
URL: https://www.opiq.ee/kit/100/chapter/4944
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.7
Topics ET: loodusõpetus, füüsikalisi, suurusi
Topics RU: природоведение
Topics EN: science
Headings: Füüsikalisi suurusi

## Kuidas koostada graafikut
URL: https://www.opiq.ee/kit/100/chapter/4945
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.8
Topics ET: loodusõpetus, kuidas, koostada, graafikut, sõltumatu, sõltuv, muutuja
Topics RU: природоведение
Topics EN: science
Headings: Kuidas koostada graafikut; Sõltumatu ja sõltuv muutuja

## Ainete tihedusi
URL: https://www.opiq.ee/kit/100/chapter/4946
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 10.9
Topics ET: loodusõpetus, ainete, tihedusi
Topics RU: природоведение
Topics EN: science
Headings: Ainete tihedusi

## Mõisted
URL: https://www.opiq.ee/kit/100/chapter/4949
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 11.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Sissejuhatus
URL: https://www.opiq.ee/kit/100/chapter/4885
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Loendamine
URL: https://www.opiq.ee/kit/100/chapter/4884
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.10
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, mõõtmine, mõõtühik, pikkus, mass, maht, loendamine, küsitlus, liiklustiheduse, kuidas, loendada, loendamatut, lindude, parves
Topics RU: природоведение, число, числа, цифры, измерение, единица измерения, длина, масса, объём
Topics EN: science, number, numbers, digits, measurement, unit, length, mass, volume
Headings: Loendamine; Küsitlus; Liiklustiheduse mõõtmine; Kuidas loendada „loendamatut”; Lindude arv parves; Puukide arvukus; Pean meeles; Küsimusi ja ülesandeid; Linnuloendus

## Kokkuvõte ja üldistus
URL: https://www.opiq.ee/kit/100/chapter/4886
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.11
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, kokkuvõte, üldistus, tiheduse, ühikute, teisendamine, arvutusülesande, vormistamine, olulised
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Kokkuvõte ja üldistus; Mõõtmine; Tiheduse ühikute teisendamine; Arvutusülesande vormistamine; Olulised oskused

## Uurimis­ülesandeid
URL: https://www.opiq.ee/kit/100/chapter/4887
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.12
Topics ET: loodusõpetus, uurimis, ülesandeid, lapse, kasvamise, graafik, pikkuse, muutumine, päeva, jooksul
Topics RU: природоведение
Topics EN: science
Headings: Uurimis­ülesandeid; Lapse kasvamise graafik; Pikkuse muutumine päeva jooksul; Müntide loendamine

## Mõõtmiseks on vaja mõõtühikut
URL: https://www.opiq.ee/kit/100/chapter/4876
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.2
Topics ET: loodusõpetus, mõõtmiseks, vaja, mõõtühikut, meetermõõdustik, kuidas, saadi, pikkusühik, meeter, kordsete
Topics RU: природоведение
Topics EN: science
Headings: Mõõtmiseks on vaja mõõtühikut; Meetermõõdustik; Kuidas saadi pikkusühik 1 meeter; Kordsete ühikute moodustamine; Pean meeles; Küsimusi ja ülesandeid

## Mõõtmiseks on vaja mõõteriista
URL: https://www.opiq.ee/kit/100/chapter/4877
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.3
Topics ET: loodusõpetus, mõõtmiseks, vaja, mõõteriista, mõõteriistad, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Mõõtmiseks on vaja mõõteriista; Mõõteriistad; Pean meeles; Küsimusi ja ülesandeid

## Pikkus ja selle mõõtmine
URL: https://www.opiq.ee/kit/100/chapter/4878
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, selle, teepikkuse, hodomeetriga, laserkaugusmõõtja, pole, kunagi, täiesti
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Pikkus ja selle mõõtmine; Pikkus; Teepikkuse mõõtmine hodomeetriga; Laserkaugusmõõtja; Mõõtmine pole kunagi täiesti täpne; Pean meeles; Küsimusi ja ülesandeid

## Plaani koostamine
URL: https://www.opiq.ee/kit/100/chapter/4879
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.5
Topics ET: loodusõpetus, plaani, koostamine, eeltööd, kompassi, kasutamine, mõõtmised, joonestamine, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Plaani koostamine; Eeltööd; Kompassi kasutamine; Mõõtmised; Plaani joonestamine; Küsimusi ja ülesandeid; Kompass

## Pindala ja selle mõõtmine
URL: https://www.opiq.ee/kit/100/chapter/4880
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.6
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, pindala, selle, otsene, kaudne, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Pindala ja selle mõõtmine; Pindala; Pindala otsene ja kaudne mõõtmine; Pindala kaudne mõõtmine; Pean meeles; Küsimusi ja ülesandeid; Pindala otsene mõõtmine; Pindalaühikute teisendamine

## Ruumala ja selle mõõtmine
URL: https://www.opiq.ee/kit/100/chapter/4881
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.7
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, ruumala, selle, pean, meeles, küsimusi, ülesandeid, ruumalaühikute, teisendamine
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Ruumala ja selle mõõtmine; Ruumala; Ruumala mõõtmine; Pean meeles; Küsimusi ja ülesandeid; Ruumalaühikute teisendamine; Anu uus peenar

## Mass ja selle mõõtmine
URL: https://www.opiq.ee/kit/100/chapter/4882
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.8
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, selle, massiühikud, massi, kangkaaludega, digikaaluga, pean, meeles
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mass ja selle mõõtmine; Mass; Massiühikud; Massi mõõtmine kangkaaludega; Massi mõõtmine digikaaluga; Pean meeles; Küsimusi ja ülesandeid; Kangkaalud; Massiühikute teisendamine

## Aine tihedus
URL: https://www.opiq.ee/kit/100/chapter/4883
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 2.9
Topics ET: loodusõpetus, aine, tihedus, tiheduse, määramine, ruumala, kaudu, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Aine tihedus; Tihedus; Aine tiheduse määramine; Ruumala määramine tiheduse kaudu; Pean meeles; Küsimusi ja ülesandeid.

## Sissejuhatus
URL: https://www.opiq.ee/kit/100/chapter/4891
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 3.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Mehaaniline liikumine
URL: https://www.opiq.ee/kit/100/chapter/4888
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 3.2
Topics ET: loodusõpetus, mehaaniline, liikumine, liikumise, liigitamine, sirgjooneline, kõverjooneline, kulgemine, pöörlemine, kulgliikumine
Topics RU: природоведение
Topics EN: science
Headings: Mehaaniline liikumine; Liikumine; Liikumise liigitamine; Sirgjooneline liikumine; Kõverjooneline liikumine; Kulgemine ja pöörlemine; Kulgliikumine; Pöörlemine ehk pöördliikumine; Võnkumine; Pean meeles; Küsimusi ja ülesandeid; Liikumise trajektoor

## Aeg ja selle mõõtmine
URL: https://www.opiq.ee/kit/100/chapter/4889
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 3.3
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, aeg, kell, kalender, selle, reaktsiooniaeg, reaktsiooniaja, hindamine, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, время, часы, календарь
Topics EN: science, measurement, unit, length, mass, volume, time, clock, calendar
Headings: Aeg ja selle mõõtmine; Aeg; Reaktsiooniaeg; Reaktsiooniaja hindamine; Pean meeles; Küsimusi ja ülesandeid; Ajaühikud

## Kehade liikumise kiirus
URL: https://www.opiq.ee/kit/100/chapter/4890
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 3.4
Topics ET: loodusõpetus, kehade, liikumise, kiirus, ühtlane, liikumine, keskmine, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Kehade liikumise kiirus; Ühtlane liikumine; Keskmine kiirus; Pean meeles; Küsimusi ja ülesandeid

## Kiiruse määramine
URL: https://www.opiq.ee/kit/100/chapter/4892
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 3.5
Topics ET: loodusõpetus, kiiruse, määramine, aruanne, voolamine, kraavis, vaatlus, mõõtmise, kavandamine, läbiviimine
Topics RU: природоведение
Topics EN: science
Headings: Kiiruse määramine; Aruanne. Vee voolamine kraavis; 1. Vaatlus; 2. Mõõtmise kavandamine; 3. Mõõtmise läbiviimine; 4. Mõõtmise tulemused ja tulemuste töötlemine; 5. Järeldus; 6. Kuidas me graafiku tegime?

## Kokkuvõte ja üldistus
URL: https://www.opiq.ee/kit/100/chapter/4893
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 3.6
Topics ET: loodusõpetus, kokkuvõte, üldistus, kehade, liikumine, olulised, oskused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte ja üldistus; Kehade liikumine; Olulised oskused

## Sissejuhatus
URL: https://www.opiq.ee/kit/100/chapter/4901
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Kokkuvõte ja üldistus
URL: https://www.opiq.ee/kit/100/chapter/4903
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.10
Topics ET: loodusõpetus, kokkuvõte, üldistus, ained, nende, segud, olulised, oskused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte ja üldistus; Ained ja nende segud; Olulised oskused

## Kehad, ained, nähtused ja mudelid
URL: https://www.opiq.ee/kit/100/chapter/4894
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.2
Topics ET: loodusõpetus, kehad, ained, nähtused, mudelid, pean, meeles, küsimusi, ülesandeid, faasid
Topics RU: природоведение
Topics EN: science
Headings: Kehad, ained, nähtused ja mudelid; Ained; Nähtused; Mudelid; Pean meeles; Küsimusi ja ülesandeid; Kuu faasid; Nähtused ja mudelid

## Aatomid
URL: https://www.opiq.ee/kit/100/chapter/4895
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.3
Topics ET: loodusõpetus, aatomid, aatomi, mudel, teadmised, aatomitest, keemilised, elemendid, kuidas, keemilisi
Topics RU: природоведение
Topics EN: science
Headings: Aatomid; Aatomi mudel; Teadmised aatomitest; Keemilised elemendid; Kuidas keemilisi elemente tähistatakse; Keemiliste elementide tabel; Mis element?; Pean meeles; Küsimusi ja ülesandeid; Keemilisi elemente

## Molekulid ja rakud
URL: https://www.opiq.ee/kit/100/chapter/4896
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.4
Topics ET: loodusõpetus, molekulid, rakud, aatomid, moodustavad, molekule, molekuli, mudel, koosnevad, molekulidest
Topics RU: природоведение
Topics EN: science
Headings: Molekulid ja rakud; Aatomid moodustavad molekule; Molekuli mudel; Rakud koosnevad molekulidest; Pean meeles; Küsimusi ja ülesandeid; Liht- ja liitained

## Aineid
URL: https://www.opiq.ee/kit/100/chapter/4897
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.5
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, aineid, vesinik, hapnik, süsinik, süsihappegaas, ainete, segu, kuiva
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Aineid; Vesinik H₂; Hapnik O₂; Vesi H₂O; Süsinik C; Süsihappegaas CO₂; Õhk on ainete segu; Kuiva õhu koostise mudel; Küsimusi ja ülesandeid

## Puhtad ained ja ainete segud
URL: https://www.opiq.ee/kit/100/chapter/4898
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.6
Topics ET: loodusõpetus, puhtad, ained, ainete, segud, puhas, aine, kivimid, mineraalid, pean
Topics RU: природоведение
Topics EN: science
Headings: Puhtad ained ja ainete segud; Puhas aine; Kivimid ja mineraalid; Pean meeles; Küsimusi ja ülesandeid

## Lahused
URL: https://www.opiq.ee/kit/100/chapter/4899
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.7
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, lahused, lahuse, koostis, sool, gaaside, lahustumine, vees, sulam
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Lahused; Lahuse koostis; Vesi ja sool; Gaaside lahustumine vees; Sulam; Miks puistatakse talvel teedele soola; Lahuste tähtsus ainevahetuses; Pean meeles; Küsimusi ja ülesandeid

## Soolalahuse tiheduse määramine
URL: https://www.opiq.ee/kit/100/chapter/4902
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.8
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, soolalahuse, tiheduse, määramine, hüpoteesi, püstitamine, töövahendid, valmistamine, uurimuse
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Soolalahuse tiheduse määramine; Hüpoteesi püstitamine; Töövahendid; Vee tiheduse mõõtmine; Soolalahuse valmistamine; Uurimuse järeldused

## Kuidas lahutada segu koostis­osadeks
URL: https://www.opiq.ee/kit/100/chapter/4900
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 4.9
Topics ET: loodusõpetus, kuidas, lahutada, segu, koostis, osadeks, puhastamine, destilleerimine, koostisosadeks, soola
Topics RU: природоведение
Topics EN: science
Headings: Kuidas lahutada segu koostis­osadeks; Vee puhastamine; Destilleerimine; Kuidas lahutada koostisosadeks soola ja liiva segu?; Sõelumine; Filter; Pean meeles; Küsimusi ja ülesandeid; Ainete omadused

## Sissejuhatus
URL: https://www.opiq.ee/kit/100/chapter/4911
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Tahke, vedel ja gaasiline olek
URL: https://www.opiq.ee/kit/100/chapter/4904
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.2
Topics ET: loodusõpetus, tahke, vedel, gaasiline, olek, ainete, erinevad, olekud, juhuslik, avastus
Topics RU: природоведение
Topics EN: science
Headings: Tahke, vedel ja gaasiline olek; Ainete erinevad olekud; Tahke olek; Vedel olek; Anu juhuslik avastus; Gaasiline olek; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?

## Sulamine ja tahkumine
URL: https://www.opiq.ee/kit/100/chapter/4905
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.3
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, sulamine, tahkumine, sulamistemperatuur, erandlik, aine, pean, meeles, küsimusi
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Sulamine ja tahkumine; Sulamistemperatuur; Vesi on erandlik aine; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?

## Aurumine ja kondenseerumine
URL: https://www.opiq.ee/kit/100/chapter/4906
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.4
Topics ET: loodusõpetus, aurumine, kondenseerumine, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Aurumine ja kondenseerumine; Pean meeles; Küsimusi ja ülesandeid

## Sublimeeru­mine ja härmatumine
URL: https://www.opiq.ee/kit/100/chapter/4907
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.5
Topics ET: loodusõpetus, sublimeeru, mine, härmatumine, sublimeerumine, pean, meeles, kokkuvõttev, skeem, aine
Topics RU: природоведение
Topics EN: science
Headings: Sublimeeru­mine ja härmatumine; Sublimeerumine; Härmatumine; Pean meeles; Kokkuvõttev skeem aine oleku muutustest

## Keemine
URL: https://www.opiq.ee/kit/100/chapter/4908
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.6
Topics ET: loodusõpetus, keemine, pean, meeles, küsimusi, ülesandeid, miks, tekivad, soojendamisel, vette
Topics RU: природоведение
Topics EN: science
Headings: Keemine; Pean meeles; Küsimusi ja ülesandeid; Miks tekivad vee soojendamisel vette mullid?

## Sademed
URL: https://www.opiq.ee/kit/100/chapter/4909
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.7
Topics ET: loodusõpetus, sademed, õhuniiskus, sõltub, temperatuurist, pilved, kaste, hall, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Sademed; Õhuniiskus sõltub temperatuurist; Udu; Pilved ja sademed; Kaste ja hall; Pean meeles; Küsimusi ja ülesandeid; Vee ringkäik

## Kokkuvõte ja üldistus
URL: https://www.opiq.ee/kit/100/chapter/4910
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.8
Topics ET: loodusõpetus, kokkuvõte, üldistus, aine, olekud, olulised, oskused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte ja üldistus; Aine olekud; Olulised oskused

## Uurimisülesandeid
URL: https://www.opiq.ee/kit/100/chapter/4912
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 5.9
Topics ET: loodusõpetus, uurimisülesandeid, purgis, härmatise, teke
Topics RU: природоведение
Topics EN: science
Headings: Uurimisülesandeid; Udu purgis; Härmatise teke

## Sissejuhatus
URL: https://www.opiq.ee/kit/100/chapter/4919
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Kineetiline energia
URL: https://www.opiq.ee/kit/100/chapter/4913
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.2
Topics ET: loodusõpetus, kineetiline, energia, tuule, kuidas, hakkavad, kehad, liikuma, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Kineetiline energia; Energia; Tuule- ja vee-energia; Kuidas hakkavad kehad liikuma; Pean meeles; Küsimusi ja ülesandeid

## Potentsiaalne energia
URL: https://www.opiq.ee/kit/100/chapter/4914
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.3
Topics ET: loodusõpetus, potentsiaalne, energia, muundumine, rattasõidul, pean, meeles, küsimusi, ülesandeid, mäest
Topics RU: природоведение
Topics EN: science
Headings: Potentsiaalne energia; Mis on potentsiaalne energia?; Energia muundumine rattasõidul; Pean meeles; Küsimusi ja ülesandeid; Mäest alla; Energia muundumine

## Soojus ja temperatuur
URL: https://www.opiq.ee/kit/100/chapter/4915
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.4
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, soojus, temperatuur, inimese, temperatuuritaju, miks, mõni, külm, teine
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Soojus ja temperatuur; Inimese temperatuuritaju; Miks on mõni keha külm ja teine kuum; Soojenemine ja jahtumine; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?

## Soojus­juhtivus
URL: https://www.opiq.ee/kit/100/chapter/4916
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.5
Topics ET: loodusõpetus, soojus, juhtivus, katseid, soojusjuhtivusega, head, halvad, soojusjuhid, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Soojus­juhtivus; Katseid soojusjuhtivusega; Head ja halvad soojusjuhid; Pean meeles; Küsimusi ja ülesandeid; Soojusjuhid

## Soojuse kandumine liikuva ainega
URL: https://www.opiq.ee/kit/100/chapter/4917
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.6
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, soojuse, kandumine, liikuva, ainega, katse, miks, ringleb, konvektsiooni
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Soojuse kandumine liikuva ainega; Katse; Miks vesi ringleb?; Konvektsiooni kasutatakse majade kütmisel; Konvektsioon ja Maa kliima; Konvektsioon Maa sees ja selle tagajärjed; Kuidas tekib briis?; Pean meeles; Küsimusi ja ülesandeid

## Kehad kiirgavad ja neelavad soojust
URL: https://www.opiq.ee/kit/100/chapter/4918
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.7
Topics ET: loodusõpetus, kehad, kiirgavad, neelavad, soojust, kiirgus, kuidas, kehasid, soojendab, näiteid
Topics RU: природоведение
Topics EN: science
Headings: Kehad kiirgavad ja neelavad soojust; Kiirgus; Kehad kiirgavad; Kuidas kiirgus kehasid soojendab?; Näiteid soojuskiirgusest; Pean meeles; Küsimusi ja ülesandeid; Kiirguse mõju inimesele

## Kokkuvõte ja üldistus
URL: https://www.opiq.ee/kit/100/chapter/4920
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.8
Topics ET: loodusõpetus, kokkuvõte, üldistus, energia, olulised, oskused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte ja üldistus; Energia; Olulised oskused

## Uurimisülesanne
URL: https://www.opiq.ee/kit/100/chapter/4921
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 6.9
Topics ET: loodusõpetus, uurimisülesanne, liiva, soojenemine
Topics RU: природоведение
Topics EN: science
Headings: Uurimisülesanne; Vee ja liiva soojenemine

## Sissejuhatus
URL: https://www.opiq.ee/kit/100/chapter/4926
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 7.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Mis on keemiline reaktsioon
URL: https://www.opiq.ee/kit/100/chapter/4922
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 7.2
Topics ET: loodusõpetus, keemiline, reaktsioon, keemilise, reaktsiooni, mõiste, tunnused, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Mis on keemiline reaktsioon; Keemilise reaktsiooni mõiste; Keemilise reaktsiooni tunnused; Pean meeles; Küsimusi ja ülesandeid; Keemilised reaktsioonid

## Põlemine
URL: https://www.opiq.ee/kit/100/chapter/4923
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 7.3
Topics ET: loodusõpetus, põlemine, põlemise, mõiste, põlemiseks, vaja, põlevat, ainet, kütust, hapnikku
Topics RU: природоведение
Topics EN: science
Headings: Põlemine; Põlemise mõiste; Põlemiseks on vaja põlevat ainet ehk kütust; Põlemiseks on vaja hapnikku; Ainete süttimiseks on vaja soojust; Pean meeles; Küsimusi ja ülesandeid; Söe põlemine

## Keemilise energia muundamine elektri­energiaks
URL: https://www.opiq.ee/kit/100/chapter/4924
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 7.4
Topics ET: loodusõpetus, keemilise, energia, muundamine, elektri, energiaks, elektrivoolu, tekkimine, sidrunipatarei, käik
Topics RU: природоведение
Topics EN: science
Headings: Keemilise energia muundamine elektri­energiaks; Elektrivoolu tekkimine; Sidrunipatarei; Töö käik; Kuidas sidrunipatarei töötab?; Pean meeles; Küsimusi ja ülesandeid

## Fotosüntees ja hingamine
URL: https://www.opiq.ee/kit/100/chapter/4925
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 7.5
Topics ET: loodusõpetus, fotosüntees, hingamine, rakkude, energiaallikas, energia, salvestamine, kasutamine, rakuhingamine, fotosünteesi
Topics RU: природоведение
Topics EN: science
Headings: Fotosüntees ja hingamine; Rakkude energiaallikas; Energia salvestamine: fotosüntees; Energia kasutamine: rakuhingamine; Fotosünteesi uurimine; Pean meeles; Küsimusi ja ülesandeid; Rakuhingamine; Fotosüntees

## Kokkuvõte ja üldistus
URL: https://www.opiq.ee/kit/100/chapter/4927
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 7.6
Topics ET: loodusõpetus, kokkuvõte, üldistus, ained, reageerivad, olulised, oskused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte ja üldistus; Ained reageerivad; Olulised oskused

## Keemilisi katseid
URL: https://www.opiq.ee/kit/100/chapter/4928
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 7.7
Topics ET: loodusõpetus, keemilisi, katseid, ainete, jahtumine, keemilisel, reaktsioonil, kuidas, süüdata, suhkrutükki
Topics RU: природоведение
Topics EN: science
Headings: Keemilisi katseid; Ainete jahtumine keemilisel reaktsioonil; Kuidas süüdata suhkrutükki?

## Sissejuhatus
URL: https://www.opiq.ee/kit/100/chapter/4935
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Kohastumine elukesk­konnaga
URL: https://www.opiq.ee/kit/100/chapter/4929
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.2
Topics ET: loodusõpetus, kohastumine, elukesk, konnaga, kõrbetaimede, kohastumusi, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Kohastumine elukesk­konnaga; Kohastumine; Kõrbetaimede kohastumusi; Pean meeles; Küsimusi ja ülesandeid

## Uurime ökosüsteeme kosmosest
URL: https://www.opiq.ee/kit/100/chapter/4930
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.3
Topics ET: loodusõpetus, uurime, ökosüsteeme, kosmosest, pääsküla, raba, põleng, satelliidid, satelliidipildid, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Uurime ökosüsteeme kosmosest; Pääsküla raba põleng; Satelliidid ja satelliidipildid; Küsimusi ja ülesandeid

## Süsiniku­ringe ökosüsteemi­des
URL: https://www.opiq.ee/kit/100/chapter/4931
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, süsiniku, ringe, ökosüsteemi, süsinikuringe, fossiilsed, kütused, aastarõngad, pean, meeles
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Süsiniku­ringe ökosüsteemi­des; Süsinikuringe; Fossiilsed kütused; Puu aastarõngad; Pean meeles; Küsimusi ja ülesandeid

## Kasvuhooneefekt
URL: https://www.opiq.ee/kit/100/chapter/4932
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.5
Topics ET: loodusõpetus, kasvuhooneefekt, atmosfäär, kuidas, toimib, inimtegevuse, mõju, kasvuhooneefektile, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Kasvuhooneefekt; Atmosfäär; Kuidas kasvuhooneefekt toimib; Inimtegevuse mõju kasvuhooneefektile; Pean meeles; Küsimusi ja ülesandeid

## Ökoloogiline jalajälg
URL: https://www.opiq.ee/kit/100/chapter/4933
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.6
Topics ET: loodusõpetus, ökoloogiline, jalajälg, mida, näitab, mitut, maad, inimkond, vajaks, pean
Topics RU: природоведение
Topics EN: science
Headings: Ökoloogiline jalajälg; Mida näitab ökoloogiline jalajälg?; Mitut Maad inimkond vajaks?; Pean meeles; Küsimusi ja ülesandeid; Minu ökoloogiline jalajälg; Taastumatud ja taastuvad loodusvarad; Kütusekulu sõitja kohta

## Toodete ja materjalide elutsükkel
URL: https://www.opiq.ee/kit/100/chapter/4934
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.7
Topics ET: loodusõpetus, toodete, materjalide, elutsükkel, toote, puuvillase, särgi, taaskasutamine, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Toodete ja materjalide elutsükkel; Toote elutsükkel; Puuvillase T-särgi elutsükkel; Materjalide taaskasutamine; Tee ise piñata; Pean meeles; Küsimusi ja ülesandeid; Prügi kogus

## Kokkuvõte ja üldistus
URL: https://www.opiq.ee/kit/100/chapter/4936
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.8
Topics ET: loodusõpetus, kokkuvõte, üldistus, elusa, eluta, looduse, seoseid, olulised, oskused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte ja üldistus; Elusa ja eluta looduse seoseid; Olulised oskused

## Uurimisülesanne
URL: https://www.opiq.ee/kit/100/chapter/4937
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 8.9
Topics ET: loodusõpetus, uurimisülesanne, linnastumine, tallinna, ümbruses
Topics RU: природоведение
Topics EN: science
Headings: Uurimisülesanne; Linnastumine Tallinna ümbruses

## Sammudega mõõtmine
URL: https://www.opiq.ee/kit/100/chapter/6922
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.1
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, sammudega, sammu, pikkuse, määramine, ülesandeid
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Sammudega mõõtmine; Sammu pikkuse määramine; Ülesandeid

## Kasvuhooneefekti mudel
URL: https://www.opiq.ee/kit/100/chapter/6931
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.10
Topics ET: loodusõpetus, kasvuhooneefekti, mudel, arvutimudeliga, tutvumine, atmosfääris, puuduvad, kasvuhoonegaasid, atmosfäär, sisaldab
Topics RU: природоведение
Topics EN: science
Headings: Kasvuhooneefekti mudel; Arvutimudeliga tutvumine; Atmosfääris puuduvad kasvuhoonegaasid; Atmosfäär sisaldab kasvuhoonegaase; Uurimisülesanded; Maapinna jahtumine öösel; Maapinna soojenemine päeval; Lisaideid uurimiseks

## Ruumala mõõtmine
URL: https://www.opiq.ee/kit/100/chapter/6923
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, inimene, keha, meeled, tervis, ruumala, kaudne, risttahukakujulise, mõõtesilindriga, tutvumine, sukeldamismeetod, sukeldamismeetodiga
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, человек, тело, чувства, здоровье
Topics EN: science, measurement, unit, length, mass, volume, human, body, senses, health
Headings: Ruumala mõõtmine; Ruumala kaudne mõõtmine; Risttahukakujulise keha ruumala mõõtmine; Vee ruumala mõõtmine; Mõõtesilindriga tutvumine; Mõõtesilindriga mõõtmine; Sukeldamismeetod; Tutvumine sukeldamismeetodiga; Ebakorrapärase kujuga keha ruumala

## Reaktsiooniaja määramine
URL: https://www.opiq.ee/kit/100/chapter/6924
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.3
Topics ET: loodusõpetus, reaktsiooniaja, määramine, reaktsiooniaeg, mõõtmised, arvutused
Topics RU: природоведение
Topics EN: science
Headings: Reaktsiooniaja määramine; Minu reaktsiooniaeg; Mõõtmised ja arvutused

## Müntide koostis
URL: https://www.opiq.ee/kit/100/chapter/6925
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.4
Topics ET: loodusõpetus, müntide, koostis, katse, magnetiga, rühmita, metallid
Topics RU: природоведение
Topics EN: science
Headings: Müntide koostis; Katse magnetiga; Rühmita metallid.

## Läänemere ja Surnumere vee tihedus
URL: https://www.opiq.ee/kit/100/chapter/6926
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.5
Topics ET: loodusõpetus, läänemere, surnumere, tihedus, käik
Topics RU: природоведение
Topics EN: science
Headings: Läänemere ja Surnumere vee tihedus; Töö käik

## Aine ruumala muutumine vee jäätumisel
URL: https://www.opiq.ee/kit/100/chapter/6927
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.6
Topics ET: loodusõpetus, aine, ruumala, muutumine, jäätumisel, käik, vasta, küsimustele
Topics RU: природоведение
Topics EN: science
Headings: Aine ruumala muutumine vee jäätumisel; Töö käik; Vasta küsimustele.

## Võrdleme soojustusmaterjale
URL: https://www.opiq.ee/kit/100/chapter/6928
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.7
Topics ET: loodusõpetus, võrdleme, soojustusmaterjale, rühmatöö, mõõtmistulemused
Topics RU: природоведение
Topics EN: science
Headings: Võrdleme soojustusmaterjale; Rühmatöö; Mõõtmistulemused

## Küünla põlemine
URL: https://www.opiq.ee/kit/100/chapter/6929
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.8
Topics ET: loodusõpetus, küünla, põlemine, käik, soojus, kütus, põlemisel, eralduvad, gaasid, kokkuvõte
Topics RU: природоведение
Topics EN: science
Headings: Küünla põlemine; Töö käik; Soojus; Kütus; Põlemisel eralduvad gaasid; Kokkuvõte; Lisaideid uurimusteks

## Hingamine ja õhu koostis
URL: https://www.opiq.ee/kit/100/chapter/6930
Book: Õppurile
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 7k_loodusõpetus_koolibri_est
Chapter ID: 9.9
Topics ET: loodusõpetus, hingamine, koostis, koostise, muutumine, hingamisel, käik
Topics RU: природоведение
Topics EN: science
Headings: Hingamine ja õhu koostis; Õhu koostise muutumine hingamisel; Töö käik

## Естество­знание 7 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/336
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 99
Topics ET: loodusõpetus, opiq
Topics RU: природоведение, естество, знание, класс
Topics EN: science

## Естество­знание 7 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/336
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 176
Topics ET: loodusõpetus, opiq
Topics RU: природоведение, естество, знание, класс
Topics EN: science

## Дорогой ученик!
URL: https://www.opiq.ee/kit/336/chapter/18883
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 1.1
Topics ET: loodusõpetus
Topics RU: природоведение, дорогой, ученик
Topics EN: science
Headings: Дорогой ученик!

## Что исследуют естественные науки
URL: https://www.opiq.ee/kit/336/chapter/18884
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 1.2
Topics ET: loodusõpetus
Topics RU: природоведение, исследуют, естественные, науки, ученые, явления
Topics EN: science
Headings: Что исследуют естественные науки; Как ученые исследуют явления

## Словарь терминов и понятий
URL: https://www.opiq.ee/kit/336/chapter/18958
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 10.1
Topics ET: loodusõpetus
Topics RU: природоведение, словарь, терминов, понятий
Topics EN: science
Headings: Словарь терминов и понятий

## Измерение
URL: https://www.opiq.ee/kit/336/chapter/18895
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.1
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Измерение

## Подсчет
URL: https://www.opiq.ee/kit/336/chapter/18893
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.10
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, число, числа, цифры, измерение, единица измерения, длина, масса, объём, подсчет, опрос, плотности, движения, посчитать, неисчисляемое, птиц
Topics EN: science, number, numbers, digits, measurement, unit, length, mass, volume
Headings: Подсчет; Опрос; Измерение плотности движения; Как посчитать «неисчисляемое»; Число птиц в стае; Численность клещей; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Подсчет птиц

## Итоги и обобщение
URL: https://www.opiq.ee/kit/336/chapter/18894
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.11
Topics ET: loodusõpetus
Topics RU: природоведение, итоги, обобщение, преобразование, единиц, плотности, оформление, вычисление, важные
Topics EN: science
Headings: Итоги и обобщение; Преобразование единиц плотности; Оформление задания на вычисление; Важные умения

## Исследовательские задания
URL: https://www.opiq.ee/kit/336/chapter/18896
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.12
Topics ET: loodusõpetus
Topics RU: природоведение, исследовательские, график, роста, ребенка, изменение, течение, подсчет, монет
Topics EN: science
Headings: Исследовательские задания; График роста ребенка; Изменение роста в течение дня; Подсчет монет

## Для измерения нужна единица измерения
URL: https://www.opiq.ee/kit/336/chapter/18885
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, измерения, нужна, единица, метрическая, система, была, получена, длины, метр
Topics EN: science, measurement, unit, length, mass, volume
Headings: Для измерения нужна единица измерения; Метрическая система; Как была получена единица длины 1 метр; Образование кратных единиц; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Для измерения нужен измерительный прибор
URL: https://www.opiq.ee/kit/336/chapter/18886
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.3
Topics ET: loodusõpetus
Topics RU: природоведение, измерения, нужен, измерительный, прибор, измерительные, приборы, следует, запомнить, вопросы
Topics EN: science
Headings: Для измерения нужен измерительный прибор; Измерительные приборы; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Длина и ее измерение
URL: https://www.opiq.ee/kit/336/chapter/18887
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, длины, пути, одометром, лазерный, дальномер, никогда, бывает
Topics EN: science, measurement, unit, length, mass, volume
Headings: Длина и ее измерение; Длина; Измерение длины пути одометром; Лазерный дальномер; Измерение никогда не бывает абсолютно точным; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Составление плана
URL: https://www.opiq.ee/kit/336/chapter/18888
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.5
Topics ET: loodusõpetus
Topics RU: природоведение, составление, плана, подготовка, пользоваться, компасом, измерения, вопросы, компас
Topics EN: science
Headings: Составление плана; Подготовка; Как пользоваться компасом; Измерения; Вопросы и задания; Компас

## Площадь и ее измерение
URL: https://www.opiq.ee/kit/336/chapter/18889
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.6
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, площадь, прямое, косвенное, площади, следует, запомнить, вопросы
Topics EN: science, measurement, unit, length, mass, volume
Headings: Площадь и ее измерение; Площадь; Прямое и косвенное измерение площади; Косвенное измерение площади; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Прямое измерение площади; Преобразование единиц площади

## Объем и его измерение
URL: https://www.opiq.ee/kit/336/chapter/18890
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.7
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, объем, объема, следует, запомнить, вопросы, преобразование, единиц
Topics EN: science, measurement, unit, length, mass, volume
Headings: Объем и его измерение; Объем; Измерение объема; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Преобразование единиц объема; Новая клумба Ану

## Масса и ее измерение
URL: https://www.opiq.ee/kit/336/chapter/18891
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.8
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, единицы, массы, рычажными, весами, цифровыми, следует, запомнить
Topics EN: science, measurement, unit, length, mass, volume
Headings: Масса и ее измерение; Масса; Единицы массы; Измерение массы рычажными весами; Измерение массы цифровыми весами; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Рычажные весы; Преобразование единиц массы

## Плотность вещества
URL: https://www.opiq.ee/kit/336/chapter/18892
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 2.9
Topics ET: loodusõpetus
Topics RU: природоведение, плотность, вещества, определение, плотности, объема, следует, запомнить, вопросы
Topics EN: science
Headings: Плотность вещества; Плотность; Определение плотности вещества; Определение объема по плотности; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Движение тел
URL: https://www.opiq.ee/kit/336/chapter/18901
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 3.1
Topics ET: loodusõpetus
Topics RU: природоведение, движение
Topics EN: science
Headings: Движение тел

## Механическое движение
URL: https://www.opiq.ee/kit/336/chapter/18897
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 3.2
Topics ET: loodusõpetus
Topics RU: природоведение, механическое, движение, классификация, движения, прямолинейное, криволинейное, поступательное, вращение, вращательное
Topics EN: science
Headings: Механическое движение; Движение; Классификация движения; Прямолинейное движение; Криволинейное движение; Поступательное движение и вращение; Поступательное движение; Вращение, или вращательное движение; Колебание; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Траектория движения

## Время и его измерение
URL: https://www.opiq.ee/kit/336/chapter/18898
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 3.3
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, aeg, kell, kalender
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, время, часы, календарь, реакции, определение, времени, следует, запомнить, вопросы
Topics EN: science, measurement, unit, length, mass, volume, time, clock, calendar
Headings: Время и его измерение; Время; Время реакции; Определение времени реакции; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Единицы измерения времени

## Скорость движения тел
URL: https://www.opiq.ee/kit/336/chapter/18899
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 3.4
Topics ET: loodusõpetus
Topics RU: природоведение, скорость, движения, равномерное, движение, средняя, следует, запомнить, вопросы
Topics EN: science
Headings: Скорость движения тел; Равномерное движение; Средняя скорость; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Определение скорости
URL: https://www.opiq.ee/kit/336/chapter/18902
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 3.5
Topics ET: loodusõpetus
Topics RU: природоведение, определение, скорости, отчет, течение, воды, канаве, наблюдение, планирование, измерения
Topics EN: science
Headings: Определение скорости; Отчет. Течение воды в канаве; 1. Наблюдение.; 2. Планирование измерения.; 3. Проведение измерений.; 4. Результаты измерения и обработка результатов; 5. Выводы; 6. Как мы строили график

## Итоги и обобщение
URL: https://www.opiq.ee/kit/336/chapter/18900
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 3.6
Topics ET: loodusõpetus
Topics RU: природоведение, итоги, обобщение, важные, умения
Topics EN: science
Headings: Итоги и обобщение; Важные умения

## Вещества и их смеси
URL: https://www.opiq.ee/kit/336/chapter/18911
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение, вещества, смеси
Topics EN: science
Headings: Вещества и их смеси

## Итоги и обобщение
URL: https://www.opiq.ee/kit/336/chapter/18910
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.10
Topics ET: loodusõpetus
Topics RU: природоведение, итоги, обобщение, важные, умения, знаешь, значения, следующих, терминов
Topics EN: science
Headings: Итоги и обобщение; Важные умения.; Ты знаешь значения следующих терминов:

## Тела, вещества, явления и модели
URL: https://www.opiq.ee/kit/336/chapter/18903
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.2
Topics ET: loodusõpetus
Topics RU: природоведение, тела, вещества, явления, модели, следует, запомнить, вопросы, фазы
Topics EN: science
Headings: Тела, вещества, явления и модели; Вещества; Явления; Модели; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Фазы Луны; Явления и модели

## Атомы
URL: https://www.opiq.ee/kit/336/chapter/18904
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.3
Topics ET: loodusõpetus
Topics RU: природоведение, атомы, модель, атома, знания, атомах, химические, элементы, обозначаются, таблица
Topics EN: science
Headings: Атомы; Модель атома; Знания об атомах; Химические элементы; Как обозначаются химические элементы; Таблица химических элементов; Назови элемент; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Молекулы и клетки
URL: https://www.opiq.ee/kit/336/chapter/18905
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.4
Topics ET: loodusõpetus
Topics RU: природоведение, молекулы, клетки, атомы, образуют, модель, состоят, молекул, следует, запомнить
Topics EN: science
Headings: Молекулы и клетки; Атомы образуют молекулы; Модель молекулы; Клетки состоят из молекул; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Простые и сложные вещества

## Вещества
URL: https://www.opiq.ee/kit/336/chapter/18906
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.5
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, вещества, водород, кислород, углерод, углекислый, вычисли, воздух, смесь
Topics EN: science, water, water safety, body of water
Headings: Вещества; Водород H2; Кислород O2; Вода H2O; Углерод C; Углекислый газ CO2; Вычисли.; Воздух – это смесь веществ; Модель сухого воздуха; Вопросы и задания; Изученные вещества. Итоги

## Чистые вещества и смеси веществ
URL: https://www.opiq.ee/kit/336/chapter/18907
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.6
Topics ET: loodusõpetus
Topics RU: природоведение, чистые, вещества, смеси, веществ, чистое, вещество, горные, породы, минералы
Topics EN: science
Headings: Чистые вещества и смеси веществ; Чистое вещество; Горные породы и минералы; Твердость минералов; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Твердость

## Растворы
URL: https://www.opiq.ee/kit/336/chapter/18908
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.7
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, растворы, состав, раствора, соль, растворение, газов, воде, сплав
Topics EN: science, water, water safety, body of water
Headings: Растворы; Состав раствора; Вода и соль; Растворение газов в воде; Сплав; Почему зимой дороги посыпают солью; Значение растворов в обмене веществ; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Определение плот­ности соляно­го раствора
URL: https://www.opiq.ee/kit/336/chapter/18912
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.8
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, определение, плот, ности, соляно, раствора, выдвижение, гипо, тезы, оборудование
Topics EN: science, measurement, unit, length, mass, volume
Headings: Определение плот­ности соляно­го раствора; Выдвижение гипо­тезы; Оборудование; Измерение плотности воды; Приготовление соля­ного раствора; Выводы исследо­вания

## Как разделить смесь на составные части
URL: https://www.opiq.ee/kit/336/chapter/18909
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 4.9
Topics ET: loodusõpetus
Topics RU: природоведение, разделить, смесь, составные, части, очистка, воды, дистилляция, соли, песка
Topics EN: science
Headings: Как разделить смесь на составные части; Очистка воды; Дистилляция; Как разделить на составные части смесь соли и песка?; Просеивание; Фильтр; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Свойства веществ

## Агрегатные состояния вещества
URL: https://www.opiq.ee/kit/336/chapter/18920
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.1
Topics ET: loodusõpetus
Topics RU: природоведение, агрегатные, состояния, вещества
Topics EN: science
Headings: Агрегатные состояния вещества

## Твердое, жидкое и газообразное состояние
URL: https://www.opiq.ee/kit/336/chapter/18913
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.2
Topics ET: loodusõpetus
Topics RU: природоведение, твердое, жидкое, газообразное, состояние, различные, состояния, веществ, случайное, открытие
Topics EN: science
Headings: Твердое, жидкое и газообразное состояние; Различные состояния веществ; Твердое состояние; Жидкое состояние; Случайное открытие Ану; Газообразное состояние; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Верно или неверно?

## Плавление и отвердевание
URL: https://www.opiq.ee/kit/336/chapter/18914
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.3
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, плавление, отвердевание, температура, плавления, особенное, вещество, следует, запомнить
Topics EN: science, water, water safety, body of water
Headings: Плавление и отвердевание; Температура плавления; Вода – особенное вещество; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Верно или неверно?

## Испарение и конденсация
URL: https://www.opiq.ee/kit/336/chapter/18915
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.4
Topics ET: loodusõpetus
Topics RU: природоведение, испарение, конденсация, следует, запомнить, вопросы
Topics EN: science
Headings: Испарение и конденсация; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Сублимация и заиндевение
URL: https://www.opiq.ee/kit/336/chapter/18916
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.5
Topics ET: loodusõpetus
Topics RU: природоведение, сублимация, заиндевение, следует, запомнить, схема, изменения, состояния, вещества
Topics EN: science
Headings: Сублимация и заиндевение; Сублимация; Заиндевение; СЛЕДУЕТ ЗАПОМНИТЬ; Схема изменения состояния вещества

## Кипение
URL: https://www.opiq.ee/kit/336/chapter/18917
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.6
Topics ET: loodusõpetus
Topics RU: природоведение, кипение, следует, запомнить, вопросы, почему, нагревании, воды, образуются
Topics EN: science
Headings: Кипение; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Почему при нагревании воды в ней образуются пузырьки?

## Осадки
URL: https://www.opiq.ee/kit/336/chapter/18918
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.7
Topics ET: loodusõpetus
Topics RU: природоведение, осадки, влажность, воздуха, зависит, температуры, туман, облака, роса, заморозок
Topics EN: science
Headings: Осадки; Влажность воздуха зависит от температуры; Туман; Облака и осадки; Роса и заморозок; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Круговорот воды

## Итоги и обобщение
URL: https://www.opiq.ee/kit/336/chapter/18919
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.8
Topics ET: loodusõpetus
Topics RU: природоведение, итоги, обобщение, важные, умения
Topics EN: science
Headings: Итоги и обобщение; Важные умения

## Исследовательские задания
URL: https://www.opiq.ee/kit/336/chapter/18921
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 5.9
Topics ET: loodusõpetus
Topics RU: природоведение, исследовательские, туман, банке, образование, инея
Topics EN: science
Headings: Исследовательские задания; ТУМАН В БАНКЕ; ОБРАЗОВАНИЕ ИНЕЯ

## Энергия
URL: https://www.opiq.ee/kit/336/chapter/18929
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.1
Topics ET: loodusõpetus
Topics RU: природоведение, энергия
Topics EN: science
Headings: Энергия

## Кинетическая энергия
URL: https://www.opiq.ee/kit/336/chapter/18922
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.2
Topics ET: loodusõpetus
Topics RU: природоведение, кинетическая, энергия, ветра, воды, тела, приходят, движение, следует, запомнить
Topics EN: science
Headings: Кинетическая энергия; Энергия; Энергия ветра и воды; Как тела приходят в движение; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Потенциаль­ная энергия
URL: https://www.opiq.ee/kit/336/chapter/18923
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.3
Topics ET: loodusõpetus
Topics RU: природоведение, потенциаль, энергия, такое, потен, циальная, преобразование, энергии, езде, велосипеде
Topics EN: science
Headings: Потенциаль­ная энергия; Что такое потен­циальная энергия?; Преобразование энергии при езде на велосипеде; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Спуск с горы; Преобразование энергии

## Теплота и температура
URL: https://www.opiq.ee/kit/336/chapter/18924
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.4
Topics ET: loodusõpetus, inimene, keha, meeled, tervis
Topics RU: природоведение, человек, тело, чувства, здоровье, теплота, температура, восприятие, температуры, человеком, почему, одно, холодное
Topics EN: science, human, body, senses, health
Headings: Теплота и температура; Восприятие температуры человеком; Почему одно тело холодное, а другое теплое; Нагревание и охлаждение; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Верно или неверно?

## Теплопровод­­ность
URL: https://www.opiq.ee/kit/336/chapter/18925
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.5
Topics ET: loodusõpetus
Topics RU: природоведение, теплопровод, ность, опыт, тепло, водность, учет, ности, выборе, материала
Topics EN: science
Headings: Теплопровод­­ность; Опыт на тепло­про­­водность; Учет теплопровод­­ности при выборе материала; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Проводник тепла

## Перенос теплоты движущимся веществом
URL: https://www.opiq.ee/kit/336/chapter/18926
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.6
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, перенос, теплоты, движущимся, веществом, опыт, почему, циркулирует, конвекция
Topics EN: science, water, water safety, body of water
Headings: Перенос теплоты движущимся веществом; Опыт; Почему вода циркулирует?; Конвекция используется в отоплении домов; Конвекция и климат Земли; Конвекция внутри Земли и ее последствия; Как образуется бриз?; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Тела излучают и поглощают теплоту
URL: https://www.opiq.ee/kit/336/chapter/18927
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.7
Topics ET: loodusõpetus
Topics RU: природоведение, тела, излучают, поглощают, теплоту, излучения, излучение, нагревает, примеры, теплового
Topics EN: science
Headings: Тела излучают и поглощают теплоту; Излучения; Излучение тел; Как излучение нагревает тела?; Примеры теплового излучения; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Воздействие излучения на человека

## Итоги и обобщение
URL: https://www.opiq.ee/kit/336/chapter/18928
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.8
Topics ET: loodusõpetus
Topics RU: природоведение, итоги, обобщение, энергия, важные, умения
Topics EN: science
Headings: Итоги и обобщение; ЭНЕРГИЯ; Важные умения

## Исследовательское задание
URL: https://www.opiq.ee/kit/336/chapter/18930
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 6.9
Topics ET: loodusõpetus
Topics RU: природоведение, исследовательское, нагревание, воды, песка
Topics EN: science
Headings: Исследовательское задание; НАГРЕВАНИЕ ВОДЫ И ПЕСКА

## Вещества реагируют
URL: https://www.opiq.ee/kit/336/chapter/18936
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 7.1
Topics ET: loodusõpetus
Topics RU: природоведение, вещества, реагируют
Topics EN: science
Headings: Вещества реагируют

## Что такое химическая реакция
URL: https://www.opiq.ee/kit/336/chapter/18931
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 7.2
Topics ET: loodusõpetus
Topics RU: природоведение, такое, химическая, реакция, признаки, химической, реакции, следует, запомнить, вопросы
Topics EN: science
Headings: Что такое химическая реакция; Химическая реакция; Признаки химической реакции; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Химические реакции

## Горение
URL: https://www.opiq.ee/kit/336/chapter/18932
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 7.3
Topics ET: loodusõpetus
Topics RU: природоведение, горение, такое, горения, нужно, горючее, вещество, топливо, нужен, кислород
Topics EN: science
Headings: Горение; Что такое горение?; Для горения нужно горючее вещество, или топливо; Для горения нужен кислород; Для воспламенения вещества нужна теплота; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Горение угля

## Преобразование химичес­кой энергии в электрическую
URL: https://www.opiq.ee/kit/336/chapter/18933
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 7.4
Topics ET: loodusõpetus
Topics RU: природоведение, преобразование, химичес, энергии, электрическую, возникновение, электри, ческого, тока, лимонная
Topics EN: science
Headings: Преобразование химичес­кой энергии в электрическую; Возникновение электри­ческого тока; Лимонная батарея; Ход работы; Как работает лимонная батарея?; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Фотосинтез и дыхание
URL: https://www.opiq.ee/kit/336/chapter/18934
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 7.5
Topics ET: loodusõpetus
Topics RU: природоведение, фотосинтез, дыхание, источник, энергии, клеток, накопление, использование, клеточное, исследование
Topics EN: science
Headings: Фотосинтез и дыхание; Источник энергии для клеток; Накопление энергии: фотосинтез; Использование энергии: клеточное дыхание; Исследование фотосинтеза; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Клеточное дыхание; Фотосинтез

## Итоги и обобщение
URL: https://www.opiq.ee/kit/336/chapter/18935
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 7.6
Topics ET: loodusõpetus
Topics RU: природоведение, итоги, обобщение, вещества, реагируют, важные, умения, знаешь, значения, следующих
Topics EN: science
Headings: Итоги и обобщение; ВЕЩЕСТВА РЕАГИРУЮТ; Важные умения; Ты знаешь значения следующих терминов:

## Химические опыты
URL: https://www.opiq.ee/kit/336/chapter/18937
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 7.7
Topics ET: loodusõpetus
Topics RU: природоведение, химические, опыты, охлаждение, веществ, химической, реакции, поджечь, кусок, сахара
Topics EN: science
Headings: Химические опыты; ОХЛАЖДЕНИЕ ВЕЩЕСТВ ПРИ ХИМИЧЕСКОЙ РЕАКЦИИ; КАК ПОДЖЕЧЬ КУСОК САХАРА?

## Связи живой и неживой природы
URL: https://www.opiq.ee/kit/336/chapter/18945
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.1
Topics ET: loodusõpetus
Topics RU: природоведение, связи, живой, неживой, природы
Topics EN: science
Headings: Связи живой и неживой природы

## Приспособление к среде обитания
URL: https://www.opiq.ee/kit/336/chapter/18938
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.2
Topics ET: loodusõpetus
Topics RU: природоведение, приспособление, среде, обитания, адаптация, адаптации, пустынных, растений, следует, запомнить
Topics EN: science
Headings: Приспособление к среде обитания; Адаптация; Адаптации пустынных растений; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Примеры адаптации

## Исследование экосистемы из космоса
URL: https://www.opiq.ee/kit/336/chapter/18939
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.3
Topics ET: loodusõpetus
Topics RU: природоведение, исследование, экосистемы, космоса, пожары, болоте, пяэскюла, спутники, спутниковые, снимки
Topics EN: science
Headings: Исследование экосистемы из космоса; Пожары на болоте Пяэскюла; Спутники и спутниковые снимки; Вопросы и задания

## Круговорот углерода в экосистемах
URL: https://www.opiq.ee/kit/336/chapter/18940
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.4
Topics ET: loodusõpetus
Topics RU: природоведение, круговорот, углерода, экосистемах, фоссильное, топливо, годичные, кольца, деревьев, следует
Topics EN: science
Headings: Круговорот углерода в экосистемах; Круговорот углерода; Фоссильное топливо; Годичные кольца деревьев; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Парниковый эффект
URL: https://www.opiq.ee/kit/336/chapter/18941
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.5
Topics ET: loodusõpetus
Topics RU: природоведение, парниковый, эффект, атмосфера, работает, влияние, человеческой, деятельности, следует, запомнить
Topics EN: science
Headings: Парниковый эффект; Атмосфера; Как работает парниковый эффект; Влияние человеческой деятельности на парниковый эффект; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания

## Экологический след
URL: https://www.opiq.ee/kit/336/chapter/18942
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.6
Topics ET: loodusõpetus
Topics RU: природоведение, экологический, след, показывает, сколько, земли, надо, человечеству, следует, запомнить
Topics EN: science
Headings: Экологический след; Что показывает экологический след?; Сколько земли надо человечеству?; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Мой экологический след; Возобновляемые и невозобновляемые природные ресурсы; Расход топлива на человека

## Жизненный цикл продукции и материалов
URL: https://www.opiq.ee/kit/336/chapter/18943
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.7
Topics ET: loodusõpetus
Topics RU: природоведение, жизненный, цикл, продукции, материалов, футболки, вторичное, использование, следует, запомнить
Topics EN: science
Headings: Жизненный цикл продукции и материалов; Жизненный цикл продукции; Жизненный цикл футболки; Вторичное использование материалов; Piñata; СЛЕДУЕТ ЗАПОМНИТЬ; Вопросы и задания; Мусор в доме

## Итоги и обобщение
URL: https://www.opiq.ee/kit/336/chapter/18944
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.8
Topics ET: loodusõpetus
Topics RU: природоведение, итоги, обобщение, связи, живой, неживой, природы, важные, умения
Topics EN: science
Headings: Итоги и обобщение; СВЯЗИ ЖИВОЙ И НЕЖИВОЙ ПРИРОДЫ; Важные умения

## Исследова­­­­­тельское задание
URL: https://www.opiq.ee/kit/336/chapter/18946
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 8.9
Topics ET: loodusõpetus
Topics RU: природоведение, исследова, тельское, урбанизация, окрестностей, таллинна
Topics EN: science
Headings: Исследова­­­­­тельское задание; УРБАНИЗАЦИЯ ОКРЕСТНОСТЕЙ ТАЛЛИННА

## Вычисление среднего арифметического
URL: https://www.opiq.ee/kit/336/chapter/18947
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.1
Topics ET: loodusõpetus
Topics RU: природоведение, вычисление, среднего, арифметического
Topics EN: science
Headings: Вычисление среднего арифметического

## Абсолютная влаж­ность воздуха
URL: https://www.opiq.ee/kit/336/chapter/18956
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.10
Topics ET: loodusõpetus
Topics RU: природоведение, абсолютная, влаж, ность, воздуха
Topics EN: science
Headings: Абсолютная влаж­ность воздуха

## Периодическая таблица химических элементов
URL: https://www.opiq.ee/kit/336/chapter/18957
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.11
Topics ET: loodusõpetus
Topics RU: природоведение, периодическая, таблица, химических, элементов
Topics EN: science
Headings: Периодическая таблица химических элементов

## Вычисление площади
URL: https://www.opiq.ee/kit/336/chapter/18948
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.2
Topics ET: loodusõpetus
Topics RU: природоведение, вычисление, площади
Topics EN: science
Headings: Вычисление площади

## Вычисление объема
URL: https://www.opiq.ee/kit/336/chapter/18949
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.3
Topics ET: loodusõpetus
Topics RU: природоведение, вычисление, объема
Topics EN: science
Headings: Вычисление объема

## Измере­ние объема жидкости мерным цилиндром
URL: https://www.opiq.ee/kit/336/chapter/18950
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, измере, объема, жидкости, мерным, цилиндром, перед, измерением, заданного
Topics EN: science, measurement, unit, length, mass, volume
Headings: Измере­ние объема жидкости мерным цилиндром; Перед измерением; Измерение объема жидкости; Измерение заданного объема жидкости

## Измерение темпера­туры жидкостным термо­метром
URL: https://www.opiq.ee/kit/336/chapter/18951
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, темпера, туры, жидкостным, термо, метром, перед, измерением, температуры
Topics EN: science, measurement, unit, length, mass, volume
Headings: Измерение темпера­туры жидкостным термо­метром; Перед измерением; Измерение температуры

## Приставки единиц измерения
URL: https://www.opiq.ee/kit/336/chapter/18952
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.6
Topics ET: loodusõpetus
Topics RU: природоведение, приставки, единиц, измерения
Topics EN: science
Headings: Приставки единиц измерения

## Физические величины
URL: https://www.opiq.ee/kit/336/chapter/18953
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.7
Topics ET: loodusõpetus
Topics RU: природоведение, физические, величины
Topics EN: science
Headings: Физические величины

## Как построить график
URL: https://www.opiq.ee/kit/336/chapter/18954
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.8
Topics ET: loodusõpetus
Topics RU: природоведение, построить, график, независимые, зависимые, переменные
Topics EN: science
Headings: Как построить график; Независимые и зависимые переменные

## Плотность веществ
URL: https://www.opiq.ee/kit/336/chapter/18955
Book: Естество­знание 7 класс – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 7k_loodusõpetus_koolibri_rus
Chapter ID: 9.9
Topics ET: loodusõpetus
Topics RU: природоведение, плотность, веществ
Topics EN: science
Headings: Плотность веществ
