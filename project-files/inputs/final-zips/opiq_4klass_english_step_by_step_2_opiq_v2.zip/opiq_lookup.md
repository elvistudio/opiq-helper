## English step by step 2 – Opiq
URL: https://www.opiq.ee/Kit/Details/332
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 98
Topics ET: matemaatika, english, step, opiq
Topics RU: математика
Topics EN: mathematics

## English step by step 2 – Opiq
URL: https://www.opiq.ee/Kit/Details/332
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 168
Topics ET: matemaatika, english, step, opiq
Topics RU: математика
Topics EN: mathematics

## The first of September.
URL: https://www.opiq.ee/kit/332/chapter/18601
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 1.1
Topics ET: matemaatika, first, september, lesson, remember, these, expressions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: The first of September.; LESSON ONE.; THE FIRST OF SEPTEMBER; Remember these expressions:; Grammar

## Twelve months I.
URL: https://www.opiq.ee/kit/332/chapter/18610
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 10.1
Topics ET: matemaatika, twelve, months, lesson, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Twelve months I.; LESSON TEN.; TWELVE MONTHS I; Remember these expressions:; Answer the questions.

## Twelve months II.
URL: https://www.opiq.ee/kit/332/chapter/18611
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 11.1
Topics ET: matemaatika, twelve, months, lesson, eleven, remember, these, expressions, find, correct
Topics RU: математика
Topics EN: mathematics
Headings: Twelve months II.; LESSON ELEVEN.; TWELVE MONTHS II; Remember these expressions:; Find and correct the mistakes.; Look at the pictures and tell the story.; Grammar

## Months and seasons.
URL: https://www.opiq.ee/kit/332/chapter/18612
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 12.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, months, lesson, twelve, remember, these, expressions, answer, questions
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Months and seasons.; LESSON TWELVE.; MONTHS AND SEASONS; Remember these expressions:; Answer the questions.; Read the dialogue.; Grammar

## Holidays.
URL: https://www.opiq.ee/kit/332/chapter/18613
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 13.1
Topics ET: matemaatika, holidays, lesson, thirteen, remember, these, expressions, finish, sentences, grammar
Topics RU: математика
Topics EN: mathematics
Headings: Holidays.; LESSON THIRTEEN.; HOLIDAYS; Remember these expressions:; Finish the sentences.; Grammar; MY FAVOURITE DAY; PROJECT WORK 2; MODEL

## Krista’s letter to Sander.
URL: https://www.opiq.ee/kit/332/chapter/18614
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 14.1
Topics ET: matemaatika, krista, letter, sander, lesson, fourteen, remember, these, expressions, read
Topics RU: математика
Topics EN: mathematics
Headings: Krista’s letter to Sander.; LESSON FOURTEEN.; KRISTA’S LETTER TO SANDER; Remember these expressions:; Read the dialogue.

## A bus trip.
URL: https://www.opiq.ee/kit/332/chapter/18615
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 15.1
Topics ET: matemaatika, trip, lesson, fifteen, remember, these, expressions, answer, questions, complete
Topics RU: математика
Topics EN: mathematics
Headings: A bus trip.; LESSON FIFTEEN.; A BUS TRIP; Remember these expressions:; Answer the questions.; Complete the sentences and read the dialogue.; Listen and chant!

## In the forest.
URL: https://www.opiq.ee/kit/332/chapter/18616
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 16.1
Topics ET: matemaatika, forest, lesson, sixteen, remember, these, expressions, look, pictures, tell
Topics RU: математика
Topics EN: mathematics
Headings: In the forest.; LESSON SIXTEEN.; IN THE FOREST; Remember these expressions:; Look at the pictures and tell the story.; Make sentences.; Grammar

## Tourists in Tallinn.
URL: https://www.opiq.ee/kit/332/chapter/18617
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 17.1
Topics ET: matemaatika, tourists, tallinn, lesson, seventeen, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Tourists in Tallinn.; LESSON SEVENTEEN.; TOURISTS IN TALLINN; Remember these expressions:; Answer the questions.; Grammar

## Gary’s project.
URL: https://www.opiq.ee/kit/332/chapter/18618
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 18.1
Topics ET: matemaatika, gary, project, lesson, eighteen, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Gary’s project.; LESSON EIGHTEEN.; GARY’S PROJECT; Remember these expressions:; Ask and answer the questions.; Grammar; PROJECT WORK 3; MODEL

## A doctor’s family.
URL: https://www.opiq.ee/kit/332/chapter/18619
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 19.1
Topics ET: matemaatika, doctor, family, lesson, nineteen, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: A doctor’s family.; LESSON NINETEEN.; A DOCTOR’S FAMILY; Remember these expressions:; Answer the questions.

## Back at school.
URL: https://www.opiq.ee/kit/332/chapter/18602
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 2.1
Topics ET: matemaatika, back, school, lesson, remember, these, expressions, answer, questions, talk
Topics RU: математика
Topics EN: mathematics
Headings: Back at school.; LESSON TWO.; BACK AT SCHOOL; Remember these expressions:; Answer the questions.; Talk about your schoolhouse.; Make sentences.; Grammar

## Visiting grandparents.
URL: https://www.opiq.ee/kit/332/chapter/18620
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 20.1
Topics ET: matemaatika, visiting, grandparents, lesson, twenty, remember, these, expressions, sentences, true
Topics RU: математика
Topics EN: mathematics
Headings: Visiting grandparents.; LESSON TWENTY.; VISITING GRANDPARENTS; Remember these expressions:; Are the sentences true or false?; Read the dialogues.

## Erik is ill.
URL: https://www.opiq.ee/kit/332/chapter/18621
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 21.1
Topics ET: matemaatika, erik, lesson, twenty, remember, these, expressions, answer, questions, listen
Topics RU: математика
Topics EN: mathematics
Headings: Erik is ill.; LESSON TWENTY-ONE.; ERIK IS ILL; Remember these expressions:; Answer the questions.; Listen and chant!

## Who is taller?
URL: https://www.opiq.ee/kit/332/chapter/18622
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 22.1
Topics ET: matemaatika, taller, lesson, twenty, remember, these, expressions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: Who is taller?; LESSON TWENTY-TWO.; Remember these expressions:; Grammar

## At the zoo.
URL: https://www.opiq.ee/kit/332/chapter/18623
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 23.1
Topics ET: matemaatika, lesson, twenty, three, remember, these, expressions, answer, questions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: At the zoo.; LESSON TWENTY-THREE.; AT THE ZOO; Remember these expressions:; Answer the questions.; Grammar

## The shortest girl in the class. I
URL: https://www.opiq.ee/kit/332/chapter/18624
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 24.1
Topics ET: matemaatika, shortest, girl, class, lesson, twenty, four, remember, these, expressions
Topics RU: математика
Topics EN: mathematics
Headings: The shortest girl in the class. I; LESSON TWENTY-FOUR.; THE SHORTEST GIRL IN THE CLASS I; Remember these expressions:; Answer the questions.; Grammar; Make sentences.; Listen and chant!

## The shortest girl in the class. II
URL: https://www.opiq.ee/kit/332/chapter/18625
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 25.1
Topics ET: matemaatika, shortest, girl, class, lesson, twenty, five, remember, these, expressions
Topics RU: математика
Topics EN: mathematics
Headings: The shortest girl in the class. II; LESSON TWENTY-FIVE.; THE SHORTEST GIRL IN THE CLASS II; Remember these expressions:; Look at the pictures and tell the story.; PROJECT WORK 4; MODEL

## Krista’s home.
URL: https://www.opiq.ee/kit/332/chapter/18626
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 26.1
Topics ET: matemaatika, krista, home, lesson, twenty, house, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: Krista’s home.; LESSON TWENTY-SIX.; KRISTA’S HOUSE; Remember these expressions:; Answer the questions.; Grammar

## Gary’s home.
URL: https://www.opiq.ee/kit/332/chapter/18627
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 27.1
Topics ET: matemaatika, gary, home, lesson, twenty, seven, find, mistakes, correct, them
Topics RU: математика
Topics EN: mathematics
Headings: Gary’s home.; LESSON TWENTY-SEVEN.; GARY’S HOME; Find the mistakes and correct them.; Complete the sentences.

## Sander’s home.
URL: https://www.opiq.ee/kit/332/chapter/18628
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 28.1
Topics ET: matemaatika, sander, home, lesson, twenty, eight, house, remember, these, expressions
Topics RU: математика
Topics EN: mathematics
Headings: Sander’s home.; LESSON TWENTY-EIGHT.; SANDER’ S HOUSE; Remember these expressions:; Answer the questions.; Listen and chant!; PROJECT WORK 5; MODEL

## Asking the way.
URL: https://www.opiq.ee/kit/332/chapter/18629
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 29.1
Topics ET: matemaatika, asking, lesson, twenty, nine, remember, these, expressions, read, this
Topics RU: математика
Topics EN: mathematics
Headings: Asking the way.; LESSON TWENTY-NINE.; ASKING THE WAY; Remember these expressions:; Read and act out this dialogue:; Look at the map.

## Gary’s first day at school.
URL: https://www.opiq.ee/kit/332/chapter/18603
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 3.1
Topics ET: matemaatika, gary, first, school, lesson, three, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: Gary’s first day at school.; LESSON THREE.; GARY ’S FIRST DAY AT SCHOOL; Remember these expressions:; Answer the questions.; Grammar; DO YOU STUDY ENGLISH?

## In a toy shop.
URL: https://www.opiq.ee/kit/332/chapter/18630
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 30.1
Topics ET: matemaatika, shop, lesson, thirty, remember, these, expressions, answer, questions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: In a toy shop.; LESSON THIRTY.; IN A TOY SHOP; Remember these expressions:; Answer the questions.; Grammar; Listen and chant!

## Caps for sale.
URL: https://www.opiq.ee/kit/332/chapter/18631
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 31.1
Topics ET: matemaatika, caps, sale, lesson, thirty, remember, these, expressions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: Caps for sale.; LESSON THIRTY-ONE.; CAPS FOR SALE; Remember these expressions:; Grammar

## When I was a baby.
URL: https://www.opiq.ee/kit/332/chapter/18632
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 32.1
Topics ET: matemaatika, when, baby, lesson, thirty, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: When I was a baby.; LESSON THIRTY-TWO.; WHEN I WAS A BABY; Remember these expressions:; Answer the questions.; Grammar

## Yesterday.
URL: https://www.opiq.ee/kit/332/chapter/18633
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 33.1
Topics ET: matemaatika, yesterday, lesson, thirty, three, remember, these, expressions
Topics RU: математика
Topics EN: mathematics
Headings: Yesterday.; LESSON THIRTY-THREE.; YESTERDAY; Remember these expressions:

## Pets day.
URL: https://www.opiq.ee/kit/332/chapter/18634
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 34.1
Topics ET: matemaatika, pets, lesson, thirty, four, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Pets day.; LESSON THIRTY-FOUR.; PETS DAY; Remember these expressions:; Answer the questions.; Grammar; PROJECT WORK 6; MODEL; SPECIAL DAYS AT SCHOOL

## Basketball practice.
URL: https://www.opiq.ee/kit/332/chapter/18635
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 35.1
Topics ET: matemaatika, kordamine, korda, harjutan, basketball, lesson, thirty, five, remember, these, expressions, grammar
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Basketball practice.; LESSON THIRTY-FIVE.; BASKETBALL PRACTICE; Remember these expressions:; Grammar

## What did you do yesterday?
URL: https://www.opiq.ee/kit/332/chapter/18636
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 36.1
Topics ET: matemaatika, what, yesterday, lesson, thirty, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: What did you do yesterday?; LESSON THIRTY-SIX.; Remember these expressions:; Answer the questions.; Grammar; Listen and chant!

## A birthday party.
URL: https://www.opiq.ee/kit/332/chapter/18637
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 37.1
Topics ET: matemaatika, birthday, party, lesson, thirty, seven, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: A birthday party.; LESSON THIRTY-SEVEN.; A BIRTHDAY PARTY; Remember these expressions:; Answer the questions.

## Last weekend.
URL: https://www.opiq.ee/kit/332/chapter/18638
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 38.1
Topics ET: matemaatika, last, weekend, lesson, thirty, eight, remember, these, expressions
Topics RU: математика
Topics EN: mathematics
Headings: Last weekend.; LESSON THIRTY-EIGHT.; LAST WEEKEND; Remember these expressions:

## Gary’s day.
URL: https://www.opiq.ee/kit/332/chapter/18639
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 39.1
Topics ET: matemaatika, gary, lesson, thirty, nine, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Gary’s day.; LESSON THIRTY-NINE.; GARY ’S DAY; Remember these expressions:; Answer the questions.; PROJECT WORK 7

## Our summer holidays.
URL: https://www.opiq.ee/kit/332/chapter/18604
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 4.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, holidays, lesson, four
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Our summer holidays.; LESSON FOUR.; OUR SUMMER HOLIDAYS

## The three bears. I
URL: https://www.opiq.ee/kit/332/chapter/18640
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 40.1
Topics ET: matemaatika, three, bears, lesson, forty, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: The three bears. I; LESSON FORTY.; THE THREE BEARS I; Remember these expressions:; Answer the questions.; Grammar

## The three bears. II
URL: https://www.opiq.ee/kit/332/chapter/18641
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 41.1
Topics ET: matemaatika, three, bears, lesson, forty, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: The three bears. II; LESSON FORTY-ONE.; THE THREE BEARS II; Remember these expressions:; Answer the questions.; Grammar

## The babysitter.
URL: https://www.opiq.ee/kit/332/chapter/18642
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 42.1
Topics ET: matemaatika, babysitter, lesson, forty, remember, these, expressions, answer, questions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: The babysitter.; LESSON FORTY-TWO.; THE BABYSITTER; Remember these expressions:; Answer the questions.; Grammar; Listen and chant!

## The fisherman and his wife. I
URL: https://www.opiq.ee/kit/332/chapter/18643
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 43.1
Topics ET: matemaatika, fisherman, wife, lesson, forty, three, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: The fisherman and his wife. I; LESSON FORTY-THREE.; THE FISHERMAN AN D HIS WIFE I; Remember these expressions:; Answer the questions.

## The fisherman and his wife. II
URL: https://www.opiq.ee/kit/332/chapter/18644
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 44.1
Topics ET: matemaatika, fisherman, wife, lesson, forty, four, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: The fisherman and his wife. II; LESSON FORTY-FOUR.; THE FISHERMAN AND HIS WIFE II; Remember these expressions:; Answer the questions.

## Let’s go to the cinema.
URL: https://www.opiq.ee/kit/332/chapter/18645
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 45.1
Topics ET: matemaatika, cinema, lesson, forty, five, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Let’s go to the cinema.; LESSON FORTY-FIVE.; LET’S GO TO THE CINEMA; Remember these expressions:; Answer the questions.; PROJECT WORK 8

## Shopping.
URL: https://www.opiq.ee/kit/332/chapter/18646
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 46.1
Topics ET: matemaatika, shopping, lesson, forty, remember, these, expressions, answer, questions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: Shopping.; LESSON FORTY-SIX.; SHOPPING; Remember these expressions:; Answer the questions.; Grammar

## Ski trip.
URL: https://www.opiq.ee/kit/332/chapter/18647
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 47.1
Topics ET: matemaatika, trip, lesson, forty, seven, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Ski trip.; LESSON FORTY-SEVEN.; THE SKI TRIP; Remember these expressions:; Answer the questions.; Grammar

## Snow White and the seven dwarfs. I
URL: https://www.opiq.ee/kit/332/chapter/18648
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 48.1
Topics ET: matemaatika, snow, white, seven, dwarfs, lesson, forty, eight, remember, these
Topics RU: математика
Topics EN: mathematics
Headings: Snow White and the seven dwarfs. I; LESSON FORTY-EIGHT.; SNOW WHITE AND THE SEVEN DWARFS I; Remember these expressions:; Answer the questions.

## Snow White and the seven dwarfs. II
URL: https://www.opiq.ee/kit/332/chapter/18649
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 49.1
Topics ET: matemaatika, snow, white, seven, dwarfs, lesson, forty, nine, remember, these
Topics RU: математика
Topics EN: mathematics
Headings: Snow White and the seven dwarfs. II; LESSON FORTY-NINE.; SNOW WHITE AND THE SEVEN DWARFS II; Remember these expressions:; Answer the questions.

## The week.
URL: https://www.opiq.ee/kit/332/chapter/18605
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 5.1
Topics ET: matemaatika, aeg, kell, kalender, week, lesson, five, krista, diary, remember, these, expressions, answer
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: The week.; LESSON FIVE.; THE WEEK; Krista’s diary.; Remember these expressions:; Answer the questions.; Telling the time

## The town mouse and the country mouse. I
URL: https://www.opiq.ee/kit/332/chapter/18650
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 50.1
Topics ET: matemaatika, town, mouse, country, lesson, fifty, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: The town mouse and the country mouse. I; LESSON FIFTY.; THE TOWN MOUSE A ND THE COUNTRY MOUSE I; Remember these expressions:; Answer the questions.; Listen and chant!

## The town mouse and the country mouse. II
URL: https://www.opiq.ee/kit/332/chapter/18651
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 51.1
Topics ET: matemaatika, town, mouse, country, lesson, fifty, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: The town mouse and the country mouse. II; LESSON FIFTY-ONE.; THE TOWN MOUSE AND THE COUNTRY MOUSE II; Remember these expressions:; Answer the questions.; Grammar; Listen and chant!

## Meals of the day.
URL: https://www.opiq.ee/kit/332/chapter/18652
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 52.1
Topics ET: matemaatika, meals, lesson, fifty, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Meals of the day.; LESSON FIFTY-TWO.; MEALS OF THE DAY; Remember these expressions:; Answer the questions.

## Cooking lesson.
URL: https://www.opiq.ee/kit/332/chapter/18653
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 53.1
Topics ET: matemaatika, cooking, lesson, fifty, three, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Cooking lesson.; LESSON FIFTY-THREE.; THE COOKING LESSON; Remember these expressions:; Answer the questions.

## In a restaurant.
URL: https://www.opiq.ee/kit/332/chapter/18654
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 54.1
Topics ET: matemaatika, restaurant, lesson, fifty, four, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: In a restaurant.; LESSON FIFTY-FOUR.; AT A RESTAURANT; Remember these expressions:; Answer the questions.; Grammar; Listen and chant!; PROJECT WORK 9; MODEL

## A lie. I
URL: https://www.opiq.ee/kit/332/chapter/18655
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 55.1
Topics ET: matemaatika, lesson, fifty, five, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: A lie. I; LESSON FIFTY-FIVE.; THE LIE I; Remember these expressions:; Answer the questions.

## A lie. II
URL: https://www.opiq.ee/kit/332/chapter/18656
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 56.1
Topics ET: matemaatika, lesson, fifty, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: A lie. II; LESSON FIFTY-SIX.; THE LIE II; Remember these expressions:; Answer the questions.

## The talkative frog.
URL: https://www.opiq.ee/kit/332/chapter/18657
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 57.1
Topics ET: matemaatika, talkative, frog, lesson, fifty, seven, remember, these, expressions, answer
Topics RU: математика
Topics EN: mathematics
Headings: The talkative frog.; LESSON FIFTY-SEVEN.; THE TALKATIVE FROG; Remember these expressions:; Answer the questions.

## The school year is over.
URL: https://www.opiq.ee/kit/332/chapter/18658
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 58.1
Topics ET: matemaatika, school, year, over, lesson, fifty, eight, grammar
Topics RU: математика
Topics EN: mathematics
Headings: The school year is over.; LESSON FIFTY-EIGHT.; THE SCHOOL YEAR IS OVER!; Grammar

## Articles.
URL: https://www.opiq.ee/kit/332/chapter/18659
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.1
Topics ET: matemaatika, articles
Topics RU: математика
Topics EN: mathematics
Headings: Articles.

## Numerals.
URL: https://www.opiq.ee/kit/332/chapter/18660
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.2
Topics ET: matemaatika, numerals
Topics RU: математика
Topics EN: mathematics
Headings: Numerals.

## Pronouns.
URL: https://www.opiq.ee/kit/332/chapter/18661
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.3
Topics ET: matemaatika, pronouns
Topics RU: математика
Topics EN: mathematics
Headings: Pronouns.

## Comparison of adjectives.
URL: https://www.opiq.ee/kit/332/chapter/18662
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, adjectives
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Comparison of adjectives.

## Present simple.
URL: https://www.opiq.ee/kit/332/chapter/18663
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.5
Topics ET: matemaatika, present, simple
Topics RU: математика
Topics EN: mathematics
Headings: Present simple.

## Present continuous.
URL: https://www.opiq.ee/kit/332/chapter/18664
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.6
Topics ET: matemaatika, present, continuous
Topics RU: математика
Topics EN: mathematics
Headings: Present continuous.

## Past simple.
URL: https://www.opiq.ee/kit/332/chapter/18665
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.7
Topics ET: matemaatika, past, simple
Topics RU: математика
Topics EN: mathematics
Headings: Past simple.

## Modal verbs.
URL: https://www.opiq.ee/kit/332/chapter/18666
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.8
Topics ET: matemaatika, modal, verbs
Topics RU: математика
Topics EN: mathematics
Headings: Modal verbs.

## Irregular verbs.
URL: https://www.opiq.ee/kit/332/chapter/18667
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 59.9
Topics ET: matemaatika, irregular, verbs
Topics RU: математика
Topics EN: mathematics
Headings: Irregular verbs.

## Our second week at school.
URL: https://www.opiq.ee/kit/332/chapter/18606
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 6.1
Topics ET: matemaatika, second, week, school, lesson, remember, these, expressions, answer, questions
Topics RU: математика
Topics EN: mathematics
Headings: Our second week at school.; LESSON SIX.; OUR SECOND WEEK AT SCHOOL; Remember these expressions:; Answer the questions.; Grammar

## Mõisted
URL: https://www.opiq.ee/kit/332/chapter/18668
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 60.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/332/chapter/18669
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 60.2
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Sports day.
URL: https://www.opiq.ee/kit/332/chapter/18607
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 7.1
Topics ET: matemaatika, sports, lesson, seven, remember, these, expressions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: Sports day.; LESSON SEVEN.; SPORTS DAY; Remember these expressions:; Grammar

## The weekend.
URL: https://www.opiq.ee/kit/332/chapter/18608
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 8.1
Topics ET: matemaatika, weekend, lesson, eight, remember, these, expressions, grammar, project, work
Topics RU: математика
Topics EN: mathematics
Headings: The weekend.; LESSON EIGHT.; THE WEEKEND; Remember these expressions:; Grammar; PROJECT WORK 1; MODEL; MY WEEK

## The months of the year.
URL: https://www.opiq.ee/kit/332/chapter/18609
Book: English step by step 2 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_2
Chapter ID: 9.1
Topics ET: matemaatika, months, year, lesson, nine, remember, these, expressions, grammar
Topics RU: математика
Topics EN: mathematics
Headings: The months of the year.; LESSON NINE.; THE MONTHS OF THE YEAR; Remember these expressions:; Grammar

## High Five! 4 – Opiq
URL: https://www.opiq.ee/Kit/Details/451
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 1
Topics ET: matemaatika, high, five, opiq
Topics RU: математика
Topics EN: mathematics

## High Five! 4 – Opiq
URL: https://www.opiq.ee/Kit/Details/451
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 97
Topics ET: matemaatika, high, five, opiq
Topics RU: математика
Topics EN: mathematics

## Welcome Back!
URL: https://www.opiq.ee/kit/451/chapter/24497
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 1.1
Topics ET: matemaatika, welcome, back, hello, high, five, characters, tuttavaks, peategelastega, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Welcome Back!; Hello, we’re back!; High Five! characters; Saa tuttavaks peategelastega; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; I’m back from holiday!; Harjutus 4; Harjutus 3; 3B; 3A; Harjutus 5; 5B; 5A

## The United Kingdom of Great Britain
URL: https://www.opiq.ee/kit/451/chapter/24498
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 1.2
Topics ET: matemaatika, united, kingdom, great, britain, suurbritannia, ühendkuningriigi, osad, riigid, pealinnad
Topics RU: математика
Topics EN: mathematics
Headings: The United Kingdom of Great Britain; Suurbritannia Ühendkuningriigi osad; Riigid, pealinnad ja lipud; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; Harjutus 4; 4F; 4A; 4B; 4C; 4D; 4E; Harjutus 5; 5D; 5A; 5B; 5C; Summary; Harjutus 6; Harjutus7

## Definitions
URL: https://www.opiq.ee/kit/451/chapter/24534
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 10.1
Topics ET: matemaatika, definitions
Topics RU: математика
Topics EN: mathematics
Headings: Definitions

## Glossary
URL: https://www.opiq.ee/kit/451/chapter/24535
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 10.2
Topics ET: matemaatika, glossary
Topics RU: математика
Topics EN: mathematics
Headings: Glossary

## Impressum
URL: https://www.opiq.ee/kit/451/chapter/28160
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 10.3
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Chapter 1. My School Bag
URL: https://www.opiq.ee/kit/451/chapter/24499
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.1
Topics ET: matemaatika, chapter, school, where, supplies, harjutus, practise, mäletad, pencil, kontrolli
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 1. My School Bag; Where, oh where?; School supplies; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Let’s practise!; Harjutus 3; Harjutus 4; 4C; 4A; 4B; Harjutus 5; Harjutus 6; 6C; 6A; 6B; Harjutus 7; 7C; 7A; 7B; Kas mäletad?; Harjutus 8; 8B; 8A; Where’s my pencil?; Kontrolli ennast!; Harjutus 9; Harjutus 10; 10F; 10A; 10B; 10C; 10D; 10E

## Action! One Tooth, Ten Teeth
URL: https://www.opiq.ee/kit/451/chapter/24508
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.10
Topics ET: matemaatika, action, tooth, teeth, child, children, practise, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! One Tooth, Ten Teeth; One tooth, two teeth; One child, ten children; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; 3D; 3A; 3B; 3C; Harjutus 4; Go ahead!; Harjutus 5; Harjutus 6; 6D; 6A; 6B; 6C

## Chapter 3. Pass Me the Ketchup, Please
URL: https://www.opiq.ee/kit/451/chapter/24509
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.11
Topics ET: matemaatika, chapter, pass, ketchup, please, brother, likes, bread, butter, practise
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 3. Pass Me the Ketchup, Please; My brother likes ketchup; Bread and butter; Let’s practise!; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2E; 2A; 2B; 2C; 2D; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; At the table; Harjutus 7; Harjutus 6; Harjutus 8; 8E; 8A; 8B; 8C; 8D; Harjutus 9; 9D; 9A; 9B; 9C

## Go Ahead! Can I Have a Napkin, Please?
URL: https://www.opiq.ee/kit/451/chapter/24510
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.12
Topics ET: matemaatika, ahead, have, napkin, please, mayonnaise, mustard, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Can I Have a Napkin, Please?; Mayonnaise or mustard?; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 4; 4B; 4A; Harjutus 3; 3C; 3A; 3B; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A

## Ketchup?
URL: https://www.opiq.ee/kit/451/chapter/24511
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.13
Topics ET: matemaatika, ketchup, reading, what, lunch, ütleb, kuidas, eesti, keeles, õige
Topics RU: математика
Topics EN: mathematics
Headings: Ketchup?; Reading; Let’s see what’s for lunch; Kes nii ütleb?; Kuidas on eesti keeles?; Kas õige või vale?; Millest tekstis räägiti?; Õige järjekord; Mis sõna sobib lausesse?

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/24512
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.14
Topics ET: matemaatika, practise, ketchup, words, harjutus, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Ketchup?; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A; Discover with Simon and Tom

## Action! My Friend Has a Kiwi
URL: https://www.opiq.ee/kit/451/chapter/24513
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.15
Topics ET: matemaatika, action, friend, kiwi, articles, practise, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! My Friend Has a Kiwi; My friend has a kiwi; Articles: a/an and the; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Go ahead! New or old?; Harjutus 4; Harjutus 5; Harjutus 6; Harjutus 7

## Chapter 4. Down by the River
URL: https://www.opiq.ee/kit/451/chapter/24514
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.16
Topics ET: matemaatika, liitmine, liida, summa, kokku, chapter, down, river, take, tour, kuidas, eesti, keeles, ütleb
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Chapter 4. Down by the River; Hop on!; Let’s take a tour!; Kuidas on eesti keeles?; Kes nii ütleb?; Mis väljendi saad kokku?; Kuidas said tekstist aru?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/24515
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.17
Topics ET: matemaatika, practise, down, river, words, harjutus, speak, find, oxford
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Down by the river; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A; Find out!; Oxford; Harjutus 7; 7B; 7A

## Module 2 Review
URL: https://www.opiq.ee/kit/451/chapter/24516
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.18
Topics ET: matemaatika, kordamine, korda, harjutan, module, simon, says, seda, ütleb, check, yourself, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Module 2 Review; Simon says, Tom says; Kes seda ütleb?; Check yourself!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Where’s that? Where’s he?; Harjutus 4; 4D; 4A; 4B; 4C; Harjutus 5; Harjutus 6; A tooth – ten teeth; Harjutus 7; Harjutus 8; 8B; 8A; Let’s speak!; Harjutus 10; 10B; 10A; Harjutus 9; 9B; 9A; Harjutus 11; 11B; 11A

## Go Ahead! Where’s the Notebook?
URL: https://www.opiq.ee/kit/451/chapter/24500
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.2
Topics ET: matemaatika, ahead, where, notebook, school, supplies, harjutus, practise
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Where’s the Notebook?; School supplies; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Let’s practise!; Harjutus 3; Harjutus 4; Harjutus 5; 5B; 5A; Harjutus 6; 6E; 6A; 6B; 6C; 6D; Where’s the notebook?; Harjutus 7; Harjutus 8; 8D; 8A; 8B; 8C

## Back to School!
URL: https://www.opiq.ee/kit/451/chapter/24501
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.3
Topics ET: matemaatika, back, school, reading, ready, ütleb, õige, lause, lõpp, milliseid
Topics RU: математика
Topics EN: mathematics
Headings: Back to School!; Reading; I’m ready for school; Kes nii ütleb?; Õige lause lõpp; Milliseid kooliasju raamatust tuli?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/24502
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.4
Topics ET: matemaatika, practise, back, school, words, harjutus, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Back to school!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; 5D; 5A; 5B; 5C; Harjutus 6; 6C; 6A; 6B; Discover with Simon and Tom; Go ahead! My school bag; Harjutus 7; 7D; 7A; 7B; 7C

## Sounds Good! [s], [z] and [ʃ]
URL: https://www.opiq.ee/kit/451/chapter/24503
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.5
Topics ET: matemaatika, sounds, good, häälik, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [s], [z] and [ʃ]; [s], [z] and [ʃ]; Mis häälik?; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Let’s pronounce!; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; 5C; 5A; 5B

## Chapter 2. At School
URL: https://www.opiq.ee/kit/451/chapter/24504
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.6
Topics ET: matemaatika, chapter, school, boys, girls, come, play, places, people, ruumid
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 2. At School; Boys and girls come out to play; Places and people at school; Places (ruumid) at school; People (inimesed) at school; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Let’s practise!; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; Harjutus 6; 6B; 6A; Harjutus 7; 7F; 7A; 7B; 7C; 7D; 7E; What’s that? Who is she?; Harjutus 8; Harjutus 9; Harjutus 10; 10B; 10A; Harjutus 11; 11B; 11A

## Go Ahead! What’s That? Who Is She?
URL: https://www.opiq.ee/kit/451/chapter/24505
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.7
Topics ET: matemaatika, ahead, what, that, people, places, school, practise, harjutus, tegusõna
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! What’s That? Who Is She?; People and places at school; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2C; 2A; 2B; Harjutus 3; 3B; 3A; Tegusõna be; Harjutus 4; Harjutus 5; Harjutus 6; 6F; 6A; 6B; 6C; 6D; 6E; Harjutus 7; 7B; 7A; Summary; Harjutus 8; 8F; 8A; 8B; 8C; 8D; 8E; Harjutus 9

## Peek-a-boo!
URL: https://www.opiq.ee/kit/451/chapter/24506
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.8
Topics ET: matemaatika, peek, reading, said, that, millistest, ruumidest, inimestest, tekstis, räägitakse
Topics RU: математика
Topics EN: mathematics
Headings: Peek-a-boo!; Reading; Who said that?; Millistest ruumidest ja inimestest tekstis räägitakse?; Kuidas on inglise keeles?; Kes nii ütleb?; Kumb lause on tekstis?

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/24507
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 2.9
Topics ET: matemaatika, practise, peek, words, harjutus, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Peek-a-boo!; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A; Harjutus 7; 7B; 7A; Discover with Simon and Tom

## Chapter 5. Where Is the Bus Station?
URL: https://www.opiq.ee/kit/451/chapter/24517
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.1
Topics ET: matemaatika, chapter, where, station, wheels, through, town, places, place, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 5. Where Is the Bus Station?; The wheels on the bus; All through the town; Places in a town; How to get to the place; Harjutus 1; 1B; 1A; Harjutus 2; Let’s practise!; Harjutus 3; Harjutus 4; 4C; 4A; 4B; Harjutus 5; Harjutus 6; Harjutus 7; 7C; 7A; 7B; Where is the restaurant?; Kontrolli ennast!; Harjutus 8; Harjutus 9; Harjutus 10

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/24526
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.10
Topics ET: matemaatika, practise, words, harjutus, speak, discover, simon, ahead, musical
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; Let’s speak!; Harjutus 4; Harjutus 5; Discover with Simon and Tom; Harjutus 6; Go ahead! Musical instruments; Harjutus 7

## Sounds Good! [v], [f] and [w]
URL: https://www.opiq.ee/kit/451/chapter/24527
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.11
Topics ET: matemaatika, sounds, good, wish, kumb, häälik, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [v], [f] and [w]; I wish; [v], [f] and [w]; Kumb häälik?; Harjutus 1; 1B; 1A; Let’s pronounce!; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5

## Chapter 7. Months and Seasons
URL: https://www.opiq.ee/kit/451/chapter/24528
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.12
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, chapter, months, january, february, march, year, round, practise
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Chapter 7. Months and Seasons; January, February, March; All year round; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Harjutus 4; 4D; 4A; 4B; 4C; Harjutus 5

## Go Ahead! What Can You Do in the Summer?
URL: https://www.opiq.ee/kit/451/chapter/24529
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.13
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, ahead, what, build, snowman, harjutus, practise
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Go Ahead! What Can You Do in the Summer?; Seasons; I can build a snowman; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; 3C; 3A; 3B; Let’s practise!; Harjutus 5; 5B; 5A; Harjutus 4; 4B; 4A; Harjutus 6; 6D; 6A; 6B; 6C; What can you do in the summer?; Harjutus 7; 7B; 7A; Harjutus 8

## Silly Seasons
URL: https://www.opiq.ee/kit/451/chapter/24961
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.14
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, silly, reading, build, snowman, lausest, puudub, kelle, sünnipäevaga
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Silly Seasons; Reading; Let’s build a snowman!; Mis lausest puudub?; Kelle sünnipäevaga need sõnad seotud on?; Kuidas said tekstist aru?; Kumb lause?

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/24962
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.15
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, practise, words, harjutus, speak, discover, simon, ahead, months
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2C; 2A; 2B; Harjutus 3; Let’s speak!; Harjutus 4; Harjutus 5; Discover with Simon and Tom; Go ahead! Months and seasons; Harjutus 6; 6D; 6A; 6B; 6C

## Action! Our Drum
URL: https://www.opiq.ee/kit/451/chapter/25432
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.16
Topics ET: matemaatika, action, drum, whose, practise, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Action! Our Drum; Our drum; Who? Whose?; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4

## Chapter 8. Lads and Lassies
URL: https://www.opiq.ee/kit/451/chapter/25433
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.17
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, chapter, lads, lassies, edinburgh, lovely, where, ütleb, kust
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Chapter 8. Lads and Lassies; Edinburgh is lovely in the autumn; Where are we now?; Kes nii ütleb?; Kust saad teada?; Kumb lause on tekstis?

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/25431
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.18
Topics ET: matemaatika, practise, words, harjutus, find, scotland, edinburgh
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; Find out!; Scotland. Edinburgh; Harjutus 6

## Module 3 Review
URL: https://www.opiq.ee/kit/451/chapter/25453
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.19
Topics ET: matemaatika, kordamine, korda, harjutan, module, simon, says, seda, ütleb, check, yourself, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Module 3 Review; Simon says, Tom says; Kes seda ütleb?; Check yourself!; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5; Harjutus 6; When is your birthday?; Harjutus 7; Harjutus 8; Let’s speak!; Harjutus 9; Harjutus 10; 10B; 10A

## Go Ahead! How Can I Get to the Museum?
URL: https://www.opiq.ee/kit/451/chapter/24518
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.2
Topics ET: matemaatika, ahead, museum, tram, places, town, place, harjutus, practise, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! How Can I Get to the Museum?; Let’s go by tram!; Places in a town; How to get to the place; Harjutus 1; 1B; 1A; Harjutus 2; Let’s practise!; Harjutus 3; Harjutus 4; Harjutus 5; Harjutus 6; 6C; 6A; 6B; Harjutus 7; Let’s speak!; Harjutus 8; Harjutus 9

## Take the Bus!
URL: https://www.opiq.ee/kit/451/chapter/24519
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.3
Topics ET: matemaatika, arv, arvud, arvu, numbrid, take, reading, what, lausest, puudub, millised, sõnad, tekstis
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Take the Bus!; Reading; What number is our bus?; Mis lausest puudub?; Millised sõnad on tekstis?; Kas õige või vale?; Õige järjekord; Küsimused ja vastused

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/24520
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.4
Topics ET: matemaatika, practise, words, harjutus, listen, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Words in use; Harjutus 1; Harjutus 2; Harjutus 3; Let’s listen and speak!; Harjutus 4; Harjutus 5; Harjutus 6; Harjutus 7; Discover with Simon and Tom

## Action! Who, When, Where, How?
URL: https://www.opiq.ee/kit/451/chapter/24521
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.5
Topics ET: matemaatika, action, when, where, questions, practise, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! Who, When, Where, How?; Who, when, where, how?; Questions; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 4; Harjutus 3; Go ahead! New or old?; Harjutus 5; Harjutus 6; Harjutus 7

## Chapter 6. Numbers (43, 65, 98, ...)
URL: https://www.opiq.ee/kit/451/chapter/24522
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.6
Topics ET: matemaatika, arv, arvud, arvu, numbrid, chapter, count, practise, harjutus
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Chapter 6. Numbers (43, 65, 98, ...); Let’s count!; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5

## How Much Is the Guitar?
URL: https://www.opiq.ee/kit/451/chapter/24523
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.7
Topics ET: matemaatika, much, guitar, that, tuba, window, musical, instruments, harjutus, practise
Topics RU: математика
Topics EN: mathematics
Headings: How Much Is the Guitar?; How much is that tuba in the window?; Musical instruments; Harjutus 1; 1B; 1A; Let’s practise!; Harjutus 2; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; 5D; 5A; 5B; 5С; How can I help you?; Harjutus 6; Harjutus 7; Harjutus 8; Harjutus 9

## Go Ahead! How Much Are the Drums?
URL: https://www.opiq.ee/kit/451/chapter/24524
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.8
Topics ET: matemaatika, ahead, much, drums, play, cello, practise, harjutus, listen, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! How Much Are the Drums?; Do you play the cello?; Let’s practise!; Harjutus 1; 1E; 1A; 1B; 1C; 1D; Harjutus 2; Harjutus 3; 3B; 3A; Let’s listen and speak!; Harjutus 4; 4B; 4A; Harjutus 5; Harjutus 6; Harjutus 7

## At the Music Shop
URL: https://www.opiq.ee/kit/451/chapter/24525
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 3.9
Topics ET: matemaatika, music, shop, reading, look, instruments, ütleb, millest, tekstis, räägiti
Topics RU: математика
Topics EN: mathematics
Headings: At the Music Shop; Reading; Look at all the instruments!; Kes nii ütleb?; Millest tekstis räägiti?; Kas õige või vale?; Õige järjekord; Õige lauselõpp

## Chapter 9. Ready, Steady, Go!
URL: https://www.opiq.ee/kit/451/chapter/25434
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.1
Topics ET: matemaatika, chapter, ready, steady, bounce, ball, exciting, harjutus, practise, think
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 9. Ready, Steady, Go!; Bounce the ball; It’s exciting!; Harjutus 1; 1B; 1A; Harjutus 2; Let’s practise!; Harjutus 3; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Harjutus 5; Harjutus 6; 6B; 6A; I think basketball is easy; Kontrolli ennast; Harjutus 7; Harjutus 8

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/25667
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.10
Topics ET: matemaatika, practise, words, harjutus, speak, discover, simon, ahead, hobbies
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Old or new words?; Harjutus 3; 3B; 3A; Harjutus 4; 4C; 4A; 4B; Harjutus 5; Let’s speak!; Harjutus 6; Discover with Simon and Tom; Go ahead! Hobbies; Harjutus 7; 7E; 7A; 7B; 7C; 7D

## Sounds Good! [tʃ] and [dʒ]
URL: https://www.opiq.ee/kit/451/chapter/25664
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.11
Topics ET: matemaatika, sounds, good, jack, likes, häälik, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [tʃ] and [dʒ]; Jack likes ...; [tʃ] and [dʒ]; Mis häälik?; Harjutus 1; 1B; 1A; [dʒ]; [tʃ]; Let’s pronounce!; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4

## Chapter 11. Download Games
URL: https://www.opiq.ee/kit/451/chapter/25855
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.12
Topics ET: matemaatika, chapter, download, games, granny, likes, drag, drop, practise, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 11. Download Games; Granny likes to download games; Drag and drop; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; You just click this icon; Harjutus 4; Harjutus 5; Harjutus 6; Harjutus 7

## Go Ahead! How Can I Make a Video?
URL: https://www.opiq.ee/kit/451/chapter/25856
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.13
Topics ET: matemaatika, ahead, make, video, programme, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! How Can I Make a Video?; Run a programme; Let’s practise!; Harjutus 1; Harjutus 2; 2B; 2A; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Let’s speak!; Harjutus 5

## Super Granny
URL: https://www.opiq.ee/kit/451/chapter/26308
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.14
Topics ET: matemaatika, super, granny, reading, does, work, ütleb, kumb, lause, õige
Topics RU: математика
Topics EN: mathematics
Headings: Super Granny; Reading; How does it work?; Kes nii ütleb?; Kumb lause on õige?; Õige vastus; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/26309
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.15
Topics ET: matemaatika, practise, words, harjutus, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Let’s speak!; Harjutus 3; Harjutus 4; 4D; 4A; 4B; 4C; Harjutus 5; 5B; 5A; Discover with Simon and Tom

## Action! What Does the Baby Do?
URL: https://www.opiq.ee/kit/451/chapter/26310
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.16
Topics ET: matemaatika, action, what, does, baby, talks, doesn, talk, practise, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Action! What Does the Baby Do?; What does the baby do?; She talks, she doesn’t talk; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Go ahead!; Harjutus 4; 4B; 4A; Harjutus 5; 5B; 5A

## Chapter 12. Red, Red Everywhere!
URL: https://www.opiq.ee/kit/451/chapter/26328
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.17
Topics ET: matemaatika, chapter, everywhere, ready, match, ütleb, kuidas, said, tekstist, õige
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 12. Red, Red Everywhere!; Red, red everywhere!; Now I’m ready for the match; Kes nii ütleb?; Kuidas said tekstist aru?; Õige järjekord; Go ahead!; Harjutus 1; 1B; 1A; Harjutus 2

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/26327
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.18
Topics ET: matemaatika, practise, words, harjutus, find
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; Find out!; Harjutus 6; 6D; 6A; 6B; 6C; Harjutus 7; 7B; 7A

## Module 4 Review
URL: https://www.opiq.ee/kit/451/chapter/26332
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.19
Topics ET: matemaatika, kordamine, korda, harjutan, module, mäletad, simon, says, õige, vale, seda, ütleb
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Module 4 Review; Kas sa mäletad?; Simon says, Tom says; Õige või vale; Kes seda ütleb?; Check yourself!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Does he like ice hockey?; Harjutus 4; 4B; 4A; Harjutus 5; Harjutus 6; Fast, faster, the fastest; Harjutus 7; Harjutus 8; 8B; 8A; Let’s speak!; Harjutus 9; Harjutus 10; Paaristöö

## Go Ahead! Hard or Easy?
URL: https://www.opiq.ee/kit/451/chapter/25435
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.2
Topics ET: matemaatika, ahead, hard, easy, sport, games, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Hard or Easy?; Sport and games; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3B; 3A; Let’s speak!; Harjutus 4; Harjutus 5

## Action! Hard, Harder, the Hardest
URL: https://www.opiq.ee/kit/451/chapter/25454
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.3
Topics ET: matemaatika, action, hard, harder, hardest, more, interesting, practise, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Action! Hard, Harder, the Hardest; More interesting; Let’s practise!; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Нarjutus 3; 3C; 3A; 3B; Harjutus 4; Harjutus 5; 5B; 5A; Go ahead!; Harjutus 6

## Fun and Games
URL: https://www.opiq.ee/kit/451/chapter/25436
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.4
Topics ET: matemaatika, games, reading, want, play, volleyball, ütleb, lausesse, sobiv, sõna
Topics RU: математика
Topics EN: mathematics
Headings: Fun and Games; Reading; Do you want to play volleyball?; Kes nii ütleb?; Lausesse sobiv sõna; Õige vastus; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/25437
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.5
Topics ET: matemaatika, practise, words, harjutus, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; Discover with Simon and Tom

## Action! Does She Play Badminton?
URL: https://www.opiq.ee/kit/451/chapter/25466
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.6
Topics ET: matemaatika, action, does, play, badminton, practise, harjutus, ahead, words
Topics RU: математика
Topics EN: mathematics
Headings: Action! Does She Play Badminton?; Does she play badminton?; Do or does?; Let’s practise!; Harjutus 1; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4B; 4A; Go ahead! New or old words?; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A

## Chapter 10. It’s Time to Go to School
URL: https://www.opiq.ee/kit/451/chapter/25467
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.7
Topics ET: matemaatika, aeg, kell, kalender, chapter, school, what, says, harjutus, dance, class
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Chapter 10. It’s Time to Go to School; What time is it?; What the clock says; Harjutus 1; Harjutus 2; 2C; 2A; 2B; Harjutus 3; It’s time for dance class; Harjutus 4; 4B; 4A; Harjutus 5; Harjutus 6; Let’s practise!; Harjutus 7; Harjutus 8; 8B; 8A

## Go Ahead! What Time Is It?
URL: https://www.opiq.ee/kit/451/chapter/25468
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.8
Topics ET: matemaatika, aeg, kell, kalender, ahead, what, clubs, lessons, harjutus, practise, speak
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Go Ahead! What Time Is It?; Clubs and lessons; Harjutus 1; Let’s practise!; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; 5C; 5A; 5B; Let’s speak!; Harjutus 6

## Who’s First?
URL: https://www.opiq.ee/kit/451/chapter/25666
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 4.9
Topics ET: matemaatika, first, reading, have, lots, hobbies, ütleb, kelle, hobi, millest
Topics RU: математика
Topics EN: mathematics
Headings: Who’s First?; Reading; I have lots of hobbies; Kes nii ütleb?; Kelle hobi see on?; Millest on jutt?; Õige vastus

## Chapter 13. Farm Animals
URL: https://www.opiq.ee/kit/451/chapter/26414
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.1
Topics ET: matemaatika, loom, loomad, linnud, putukad, chapter, farm, macdonald, hens, chicks, harjutus, practise, look
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Chapter 13. Farm Animals; Old MacDonald; Hens and chicks; Harjutus 1; 1B; 1A; Harjutus 2; Let’s practise!; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; Look at the ponies!; Harjutus 6; Harjutus 7; Harjutus 8

## Sounds Good! [t], [θ] and [ð]
URL: https://www.opiq.ee/kit/451/chapter/28246
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.10
Topics ET: matemaatika, taim, taimed, puu, lill, sounds, good, tomato, kumb, häälik, harjutus, pronounce
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Sounds Good! [t], [θ] and [ð]; Tomato tree; [t], [θ] and [ð]; Kumb häälik?; Harjutus 1; 1B; 1A; Let’s pronounce!; Harjutus 2; Harjutus 3; Harjutus 4; 4B; 4A

## Chapter 15. It’s Sunny
URL: https://www.opiq.ee/kit/451/chapter/27210
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.11
Topics ET: matemaatika, chapter, sunny, skye, boat, song, spain, harjutus, practise, what
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 15. It’s Sunny; Skye boat song; It’s hot in Spain; Harjutus 1; Harjutus 2; 2B; 2A; Let’s practise!; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; 5B; 5A; What’s the weather like in Finland?; Kontrolli ennast!; Harjutus 6

## Go Ahead! What’s the Weather Like?
URL: https://www.opiq.ee/kit/451/chapter/27211
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.12
Topics ET: matemaatika, ahead, what, weather, like, foggy, ireland, harjutus, practise, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! What’s the Weather Like?; It’s foggy in Ireland; Harjutus 1; 1B; 1A; Let’s practise!; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4D; 4A; 4B; 4C; Let’s speak!; Harjutus 5

## Near and Far
URL: https://www.opiq.ee/kit/451/chapter/27212
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.13
Topics ET: matemaatika, near, reading, where, going, next, ütleb, õige, vale, milliseid
Topics RU: математика
Topics EN: mathematics
Headings: Near and Far; Reading; Where are we going next?; Kes nii ütleb?; Kas õige või vale?; Milliseid riike tekstis nimetati?; Õige sõnavorm; Kuidas said tekstist aru?

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/27213
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.14
Topics ET: matemaatika, practise, words, harjutus, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3B; 3A; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; Discover with Simon and Tom

## Action! It was amazing!
URL: https://www.opiq.ee/kit/451/chapter/27214
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.15
Topics ET: matemaatika, action, amazing, were, harjutus, played, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! It was amazing!; I was, you were ...; Harjutus 1; Harjutus 2; I played, you played ...; Harjutus 3; Harjutus 4; Harjutus 5; 5D; 5A; 5B; 5C; Go ahead!; Harjutus 6

## Sounds Good! [p] – [b], [k] – [g] and [t] – [d]
URL: https://www.opiq.ee/kit/451/chapter/28247
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.16
Topics ET: matemaatika, sounds, good, pigs, häälik, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [p] – [b], [k] – [g] and [t] – [d]; Big pigs; [p] – [b], [k] –[g] and [t] –[d]; Mis häälik?; Harjutus 1; Harjutus 2; Let’s pronounce!; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Harjutus 5

## Chapter 16. No Snow in Snowdonia
URL: https://www.opiq.ee/kit/451/chapter/27215
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.17
Topics ET: matemaatika, liitmine, liida, summa, kokku, chapter, snow, snowdonia, fine, hike, ütleb, milline, kahekõne, sobib
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Chapter 16. No Snow in Snowdonia; No snow in Snowdonia; It’s a fine day for a hike; Kes nii ütleb?; Milline kahekõne sobib pildiga?; Mis küsimuse saad kokku?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/27216
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.18
Topics ET: matemaatika, practise, words, harjutus, find, welsh, language
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Harjutus 5; Find out!; The Welsh language; Harjutus 6

## Module 5 Review
URL: https://www.opiq.ee/kit/451/chapter/27458
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.19
Topics ET: matemaatika, kordamine, korda, harjutan, module, mäletad, seda, ütleb, check, yourself, harjutus, speak
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Module 5 Review; Kas sa mäletad?; Kes seda ütleb?; Check yourself!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5; 5F; 5A; 5B; 5C; 5D; 5E; Let’s speak!; Harjutus 6; Harjutus 7; 7B; 7A; Harjutus 8; 8B; 8A; Harjutus 9; 9C; 9A; 9B

## Go Ahead! Look at the Ponies!
URL: https://www.opiq.ee/kit/451/chapter/26415
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.2
Topics ET: matemaatika, ahead, look, ponies, huge, bulls, harjutus, practise, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Look at the Ponies!; Huge bulls; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Let’s practise!; Harjutus 3; Harjutus 4; Harjutus 5; Harjutus 6; Let’s speak!; Harjutus 7; Harjutus 8

## High Five Farmers
URL: https://www.opiq.ee/kit/451/chapter/26416
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.3
Topics ET: matemaatika, high, five, farmers, reading, nice, farm, ütleb, õige, sõna
Topics RU: математика
Topics EN: mathematics
Headings: High Five Farmers; Reading; It’s a nice day at the farm; Kes nii ütleb?; Õige sõna lausesse; Millest tekstis räägiti?

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/26417
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.4
Topics ET: matemaatika, loom, loomad, linnud, putukad, practise, words, harjutus, speak, discover, simon, ebatavalised
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Let’s speak!; Harjutus 4; 4C; 4A; 4B; Harjutus 5; Discover with Simon and Tom; Ebatavalised loomad Eesti taludes

## Action! I Am Riding
URL: https://www.opiq.ee/kit/451/chapter/26418
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.5
Topics ET: matemaatika, action, riding, watching, kontrolli, ennast, practise, harjutus, ahead, words
Topics RU: математика
Topics EN: mathematics
Headings: Action! I Am Riding; I am riding; Are you watching TV?; Kontrolli ennast!; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Go ahead! New or old words?; Harjutus 5; 5B; 5A; Harjutus 6; Let’s speak!

## Chapter 14. Apples and Bananas
URL: https://www.opiq.ee/kit/451/chapter/26419
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.6
Topics ET: matemaatika, chapter, apples, bananas, song, berries, fruit, vegetables, harjutus, practise
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 14. Apples and Bananas; The apples and bananas song; Berries, fruit(s) and vegetables; Harjutus 1; 1B; 1A; Harjutus 2; 2C; 2A; 2B; Let’s practise!; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; 5B; 5A; Guess my favourite fruit!; Harjutus 6; 6B; 6A; Harjutus 7; Harjutus 8; 8B; 8A

## Go Ahead! Guess My Favourite Fruit!
URL: https://www.opiq.ee/kit/451/chapter/26420
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.7
Topics ET: matemaatika, ahead, guess, favourite, fruit, plum, harjutus, practise, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Guess My Favourite Fruit!; P is for plum; Harjutus 1; Let’s practise!; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Harjutus 5; 5B; 5A; Let’s speak!

## The Alphabet Game
URL: https://www.opiq.ee/kit/451/chapter/26421
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.8
Topics ET: matemaatika, alphabet, game, reading, grow, tropical, fruit, ütleb, kuidas, said
Topics RU: математика
Topics EN: mathematics
Headings: The Alphabet Game; Reading; Can you grow tropical fruit?; Kes nii ütleb?; Kuidas said tekstist aru?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/451/chapter/26422
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 5.9
Topics ET: matemaatika, practise, words, harjutus, speak, discover, simon
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; Discover with Simon and Tom; Harjutus 6

## Extra Texts. London and Scotland
URL: https://www.opiq.ee/kit/451/chapter/27459
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 6.1
Topics ET: matemaatika, extra, texts, london, scotland, calling, tower, bridge, madame, tussaud
Topics RU: математика
Topics EN: mathematics
Headings: Extra Texts. London and Scotland; London calling; The Tower of London and Tower Bridge; Madame Tussaud’s; Buckingham Palace; The British Museum; Piccadilly Circus; The London Eye; London sights; Harjutus 1; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Bonnie Scotland; The Highland Games; Loch Ness; Edinburgh Castle; And who am I?; Harjutus 4; Harjutus 5; 5C; 5A; 5B; Harjutus 6; London or Scotland?; Harjutus 7; Harjutus 8

## Extra Texts. Liverpool and Wales
URL: https://www.opiq.ee/kit/451/chapter/27460
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 6.2
Topics ET: matemaatika, extra, texts, liverpool, wales, never, play, alone, spaceport, mersey
Topics RU: математика
Topics EN: mathematics
Headings: Extra Texts. Liverpool and Wales; Liverpool – you’ll never play alone; Spaceport; Mersey Ferry River Explorer Cruise; The Beatles Story; Awesome Walls Liverpool; Anfield Stadium; Amazing views; Harjutus 1; Harjutus 2; 2B; 2A; Harjutus 3; 3C; 3A; 3B; Wales and the Welsh; Castles and sheep; Harjutus 4; Harjutus 5; Liverpool or Wales?; Harjutus 6; Harjutus 7

## High Five! Characters
URL: https://www.opiq.ee/kit/451/chapter/24530
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 6.3
Topics ET: matemaatika, high, five, characters, tuttavaks, peategelastega
Topics RU: математика
Topics EN: mathematics
Headings: High Five! Characters; Saa tuttavaks peategelastega

## Halloween Party
URL: https://www.opiq.ee/kit/451/chapter/24963
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 7.1
Topics ET: matemaatika, halloween, party, happy, symbols, harjutus, welcome
Topics RU: математика
Topics EN: mathematics
Headings: Halloween Party; Happy Halloween!; Halloween symbols; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Welcome to a Halloween party!; Harjutus 3; Harjutus 4; Harjutus 5; Harjutus 6

## Merry Christmas!
URL: https://www.opiq.ee/kit/451/chapter/27765
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 7.2
Topics ET: matemaatika, merry, christmas, jingle, bells, kuidas, mäletad, laulu, sõnu, symbols
Topics RU: математика
Topics EN: mathematics
Headings: Merry Christmas!; Jingle bells; Kuidas mäletad laulu sõnu?; Christmas symbols; Harjutus 1; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Harjutus 4; 4B; 4A; Christmas around the world; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A

## Be My Valentine
URL: https://www.opiq.ee/kit/451/chapter/27766
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 7.3
Topics ET: matemaatika, valentine, poems, harjutus, symbols, what, know, about
Topics RU: математика
Topics EN: mathematics
Headings: Be My Valentine; Poems; Harjutus 1; 1C; 1A; 1B; Valentine’s Day symbols; Harjutus 2; Harjutus 3; Harjutus 4; 4C; 4A; 4B; Harjutus 5; 5D; 5A; 5B; 5C; What do you know about Valentine’s Day?; Harjutus 6; 6B; 6A; Harjutus 7

## Saint Patrick’s Day Parade
URL: https://www.opiq.ee/kit/451/chapter/27767
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 7.4
Topics ET: matemaatika, saint, patrick, parade, symbols, harjutus, bring, your, green
Topics RU: математика
Topics EN: mathematics
Headings: Saint Patrick’s Day Parade; Saint Patrick’s Day Symbols; Harjutus 1; Harjutus 2; 2C; 2A; 2B; Harjutus 3; Bring out your green!; Harjutus 4; Harjutus 5; 5B; 5A

## Happy Easter!
URL: https://www.opiq.ee/kit/451/chapter/27768
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 7.5
Topics ET: matemaatika, happy, easter, poem, harjutus, chicks, bunnies, hunt, lihavõttekombed
Topics RU: математика
Topics EN: mathematics
Headings: Happy Easter!; Easter poem; Harjutus 1; Chicks and bunnies; Harjutus 2; Harjutus 3; Harjutus 4; 4C; 4A; 4B; Easter egg hunt; Harjutus 5; Harjutus 6; Lihavõttekombed; Harjutus 7

## Fingertips 1. At School
URL: https://www.opiq.ee/kit/451/chapter/24531
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 8.1
Topics ET: matemaatika, fingertips, school, british, english, american, artikkel, this, that, these
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips 1. At School; British English – American English; Artikkel: a/an – the; This/That – These/Those; Tegusõna be; Nimisõnade mitmus; There is ... / There are ...; Kelle? Mille? (Omastav); Minul on, minul ei ole… (Olema, omama)

## Fingertips 2. Out and About
URL: https://www.opiq.ee/kit/451/chapter/25465
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 8.2
Topics ET: matemaatika, fingertips, about, küsisõnad, soovitan, palun, käsin, keelan, mina, isikulised
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips 2. Out and About; Küsisõnad; Soovitan, palun, käsin või keelan; Mina, minu (Isikulised asesõnad); Mina oskan, ei oska; mina saan, ei saa …

## Fingertips 3. Hobbies and Activities
URL: https://www.opiq.ee/kit/451/chapter/25665
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 8.3
Topics ET: matemaatika, fingertips, hobbies, activities, omadussõnad, missugune, mina, teen, üldolevik, somebody
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips 3. Hobbies and Activities; Omadussõnad (Missugune?); Mina teen, mina ei tee … (Üldolevik); Somebody, anybody, nobody ...

## Fingertips 4. Near and Far
URL: https://www.opiq.ee/kit/451/chapter/26325
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 8.4
Topics ET: matemaatika, fingertips, near, mina, teen, kestev, olevik, kavatsen, kavatse, were
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips 4. Near and Far; Mina teen, mina ei tee … (Kestev olevik); Mina kavatsen, mina ei kavatse …; I was, you were ...; I played, you played ...; Reeglipärased ja ebareeglipärased tegusõnad

## Sounds Good!
URL: https://www.opiq.ee/kit/451/chapter/26326
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 8.5
Topics ET: matemaatika, sounds, good, transcription, häälduse, kirjapanek, märkimine, kirjas, inglise, häälikud
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good!; Transcription (häälduse kirjapanek); Häälduse märkimine kirjas; Inglise häälikud

## Inglise–eesti sõnastik
URL: https://www.opiq.ee/kit/451/chapter/24532
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 9.1
Topics ET: matemaatika, inglise, eesti, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Inglise–eesti sõnastik; Inglise-eesti sõnastik

## Eesti–inglise sõnastik
URL: https://www.opiq.ee/kit/451/chapter/24533
Book: High Five! 4 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_4._klassile
Chapter ID: 9.2
Topics ET: matemaatika, eesti, inglise, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Eesti–inglise sõnastik; Eesti-inglise sõnastik
