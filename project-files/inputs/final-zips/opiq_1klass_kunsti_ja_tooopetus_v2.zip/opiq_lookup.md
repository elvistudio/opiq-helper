## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/185
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 1
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/185
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 92
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## KÄSI AVAB MÕISTUSE
URL: https://www.opiq.ee/kit/185/chapter/10343
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 1.1
Topics ET: matemaatika, käsi, avab, mõistuse
Topics RU: математика
Topics EN: mathematics
Headings: KÄSI AVAB MÕISTUSE

## Järjehoidjad (rebimine)
URL: https://www.opiq.ee/kit/185/chapter/10344
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.1
Topics ET: matemaatika, järjehoidjad, rebimine
Topics RU: математика
Topics EN: mathematics
Headings: Järjehoidjad (rebimine); 1.; 2.

## Puuviljad kausis (ühistöö, rebimine)
URL: https://www.opiq.ee/kit/185/chapter/10353
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.10
Topics ET: matemaatika, puuviljad, kausis, ühistöö, rebimine
Topics RU: математика
Topics EN: mathematics
Headings: Puuviljad kausis (ühistöö, rebimine)

## Müts
URL: https://www.opiq.ee/kit/185/chapter/10354
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.11
Topics ET: matemaatika, müts
Topics RU: математика
Topics EN: mathematics
Headings: Müts

## Lind oksal (rebimine)
URL: https://www.opiq.ee/kit/185/chapter/10355
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.12
Topics ET: matemaatika, lind, oksal, rebimine
Topics RU: математика
Topics EN: mathematics
Headings: Lind oksal (rebimine)

## Suur lumehelvestest lumememm (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10356
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.13
Topics ET: matemaatika, suur, lumehelvestest, lumememm, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Suur lumehelvestest lumememm (ühistöö)

## Jõululatern
URL: https://www.opiq.ee/kit/185/chapter/10357
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.14
Topics ET: matemaatika, jõululatern
Topics RU: математика
Topics EN: mathematics
Headings: Jõululatern

## Kett
URL: https://www.opiq.ee/kit/185/chapter/10358
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.15
Topics ET: matemaatika, kett
Topics RU: математика
Topics EN: mathematics
Headings: Kett

## Lumememm (kortsutamine)
URL: https://www.opiq.ee/kit/185/chapter/10359
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.16
Topics ET: matemaatika, lumememm, kortsutamine
Topics RU: математика
Topics EN: mathematics
Headings: Lumememm (kortsutamine)

## Talvepilt
URL: https://www.opiq.ee/kit/185/chapter/10360
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.17
Topics ET: matemaatika, talvepilt
Topics RU: математика
Topics EN: mathematics
Headings: Talvepilt

## Pika Hermanni torn (rebimine)
URL: https://www.opiq.ee/kit/185/chapter/10361
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.18
Topics ET: matemaatika, pika, hermanni, torn, rebimine
Topics RU: математика
Topics EN: mathematics
Headings: Pika Hermanni torn (rebimine)

## Ruumilised lumikellukesed
URL: https://www.opiq.ee/kit/185/chapter/10362
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.19
Topics ET: matemaatika, ruumilised, lumikellukesed
Topics RU: математика
Topics EN: mathematics
Headings: Ruumilised lumikellukesed

## Lill
URL: https://www.opiq.ee/kit/185/chapter/10345
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.2
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill

## Hoidiste purgid
URL: https://www.opiq.ee/kit/185/chapter/10363
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.20
Topics ET: matemaatika, hoidiste, purgid
Topics RU: математика
Topics EN: mathematics
Headings: Hoidiste purgid

## Kujundiriba
URL: https://www.opiq.ee/kit/185/chapter/10364
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.21
Topics ET: matemaatika, kujundiriba
Topics RU: математика
Topics EN: mathematics
Headings: Kujundiriba

## Ruumiline muna
URL: https://www.opiq.ee/kit/185/chapter/10365
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.22
Topics ET: matemaatika, ruumiline, muna
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline muna

## Kalendrid
URL: https://www.opiq.ee/kit/185/chapter/10366
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.23
Topics ET: matemaatika, kalendrid
Topics RU: математика
Topics EN: mathematics
Headings: Kalendrid

## Kevadine maastik (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10367
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.24
Topics ET: matemaatika, kevadine, maastik, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Kevadine maastik (ühistöö)

## Kevadlilled (rühmatöö)
URL: https://www.opiq.ee/kit/185/chapter/10368
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.25
Topics ET: matemaatika, kevadlilled, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Kevadlilled (rühmatöö)

## Kuused
URL: https://www.opiq.ee/kit/185/chapter/10369
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.26
Topics ET: matemaatika, kuused
Topics RU: математика
Topics EN: mathematics
Headings: Kuused

## Lillevaas
URL: https://www.opiq.ee/kit/185/chapter/10346
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.3
Topics ET: matemaatika, lillevaas
Topics RU: математика
Topics EN: mathematics
Headings: Lillevaas

## Seen
URL: https://www.opiq.ee/kit/185/chapter/10347
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.4
Topics ET: matemaatika, seen
Topics RU: математика
Topics EN: mathematics
Headings: Seen

## Ruumilised õunad (kortsutamine)
URL: https://www.opiq.ee/kit/185/chapter/10348
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.5
Topics ET: matemaatika, ruumilised, õunad, kortsutamine
Topics RU: математика
Topics EN: mathematics
Headings: Ruumilised õunad (kortsutamine); 1.; 2.

## Lill ja liblikas (rebimine)
URL: https://www.opiq.ee/kit/185/chapter/10349
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.6
Topics ET: matemaatika, taim, taimed, puu, lill, liblikas, rebimine
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill ja liblikas (rebimine)

## Sadajalgne (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10350
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.7
Topics ET: matemaatika, sadajalgne, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Sadajalgne (ühistöö)

## Jaaniussike (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10351
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.8
Topics ET: matemaatika, jaaniussike, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Jaaniussike (ühistöö)

## Öökull (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10352
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 2.9
Topics ET: matemaatika, öökull, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Öökull (ühistöö)

## Seened
URL: https://www.opiq.ee/kit/185/chapter/10370
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.1
Topics ET: matemaatika, seened
Topics RU: математика
Topics EN: mathematics
Headings: Seened

## Värvilaigud
URL: https://www.opiq.ee/kit/185/chapter/10379
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.10
Topics ET: matemaatika, värvilaigud
Topics RU: математика
Topics EN: mathematics
Headings: Värvilaigud

## Lumikellukesed
URL: https://www.opiq.ee/kit/185/chapter/10380
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.11
Topics ET: matemaatika, lumikellukesed
Topics RU: математика
Topics EN: mathematics
Headings: Lumikellukesed

## Sipsik
URL: https://www.opiq.ee/kit/185/chapter/10381
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.12
Topics ET: matemaatika, sipsik
Topics RU: математика
Topics EN: mathematics
Headings: Sipsik

## Muna, öökull ja liblikas (pintslitrükk)
URL: https://www.opiq.ee/kit/185/chapter/10382
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.13
Topics ET: matemaatika, muna, öökull, liblikas, pintslitrükk
Topics RU: математика
Topics EN: mathematics
Headings: Muna, öökull ja liblikas (pintslitrükk)

## Lilled vaasis (pintslitrükk)
URL: https://www.opiq.ee/kit/185/chapter/10383
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.14
Topics ET: matemaatika, lilled, vaasis, pintslitrükk
Topics RU: математика
Topics EN: mathematics
Headings: Lilled vaasis (pintslitrükk)

## Liblikas (vajutustehnika)
URL: https://www.opiq.ee/kit/185/chapter/10384
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.15
Topics ET: matemaatika, liblikas, vajutustehnika
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas (vajutustehnika)

## Tibu ja jänes (svammitrükk)
URL: https://www.opiq.ee/kit/185/chapter/10385
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.16
Topics ET: matemaatika, tibu, jänes, svammitrükk
Topics RU: математика
Topics EN: mathematics
Headings: Tibu ja jänes (svammitrükk)

## Sinililled I (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10386
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.17
Topics ET: matemaatika, sinililled, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Sinililled I (ühistöö)

## Sinililled II
URL: https://www.opiq.ee/kit/185/chapter/10387
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.18
Topics ET: matemaatika, sinililled
Topics RU: математика
Topics EN: mathematics
Headings: Sinililled II

## Rütm
URL: https://www.opiq.ee/kit/185/chapter/10388
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.19
Topics ET: matemaatika, rütm
Topics RU: математика
Topics EN: mathematics
Headings: Rütm

## Lumised mäed (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10371
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.2
Topics ET: matemaatika, lumised, mäed, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Lumised mäed (ühistöö)

## Ilutulestik
URL: https://www.opiq.ee/kit/185/chapter/10389
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.20
Topics ET: matemaatika, ilutulestik
Topics RU: математика
Topics EN: mathematics
Headings: Ilutulestik

## Muster (rühmatöö)
URL: https://www.opiq.ee/kit/185/chapter/10390
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.21
Topics ET: matemaatika, muster, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Muster (rühmatöö)

## Suur pühademuna (ühistöö)
URL: https://www.opiq.ee/kit/185/chapter/10391
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.22
Topics ET: matemaatika, suur, pühademuna, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Suur pühademuna (ühistöö)

## Liblikas
URL: https://www.opiq.ee/kit/185/chapter/10372
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.3
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas

## Ema portree
URL: https://www.opiq.ee/kit/185/chapter/10373
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.4
Topics ET: matemaatika, portree
Topics RU: математика
Topics EN: mathematics
Headings: Ema portree

## Lemmiksoeng
URL: https://www.opiq.ee/kit/185/chapter/10374
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.5
Topics ET: matemaatika, lemmiksoeng
Topics RU: математика
Topics EN: mathematics
Headings: Lemmiksoeng

## Trükitud pilt
URL: https://www.opiq.ee/kit/185/chapter/10375
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.6
Topics ET: matemaatika, trükitud, pilt
Topics RU: математика
Topics EN: mathematics
Headings: Trükitud pilt

## Vihmavari
URL: https://www.opiq.ee/kit/185/chapter/10376
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.7
Topics ET: matemaatika, vihmavari
Topics RU: математика
Topics EN: mathematics
Headings: Vihmavari

## Sügisene puu (svammitrükk)
URL: https://www.opiq.ee/kit/185/chapter/10377
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.8
Topics ET: matemaatika, taim, taimed, puu, lill, sügisene, svammitrükk
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Sügisene puu (svammitrükk)

## Lumehelves ja lumememm (küünlatehnika)
URL: https://www.opiq.ee/kit/185/chapter/10378
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 3.9
Topics ET: matemaatika, lumehelves, lumememm, küünlatehnika
Topics RU: математика
Topics EN: mathematics
Headings: Lumehelves ja lumememm (küünlatehnika)

## Seened
URL: https://www.opiq.ee/kit/185/chapter/10392
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.1
Topics ET: matemaatika, seened
Topics RU: математика
Topics EN: mathematics
Headings: Seened

## Jõulukaardid
URL: https://www.opiq.ee/kit/185/chapter/10401
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.10
Topics ET: matemaatika, jõulukaardid
Topics RU: математика
Topics EN: mathematics
Headings: Jõulukaardid

## Kukk munatopsiks
URL: https://www.opiq.ee/kit/185/chapter/10402
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.11
Topics ET: matemaatika, kukk, munatopsiks
Topics RU: математика
Topics EN: mathematics
Headings: Kukk munatopsiks

## Päkapikk
URL: https://www.opiq.ee/kit/185/chapter/10403
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.12
Topics ET: matemaatika, päkapikk
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikk

## Liivapilt
URL: https://www.opiq.ee/kit/185/chapter/10404
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.13
Topics ET: matemaatika, liivapilt
Topics RU: математика
Topics EN: mathematics
Headings: Liivapilt

## Kass
URL: https://www.opiq.ee/kit/185/chapter/10405
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.14
Topics ET: matemaatika, kass
Topics RU: математика
Topics EN: mathematics
Headings: Kass

## Karbiloom
URL: https://www.opiq.ee/kit/185/chapter/10406
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.15
Topics ET: matemaatika, karbiloom
Topics RU: математика
Topics EN: mathematics
Headings: Karbiloom

## Kilekotist kala
URL: https://www.opiq.ee/kit/185/chapter/10407
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.16
Topics ET: matemaatika, kilekotist, kala
Topics RU: математика
Topics EN: mathematics
Headings: Kilekotist kala

## Nõelapadi
URL: https://www.opiq.ee/kit/185/chapter/10408
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.17
Topics ET: matemaatika, nõelapadi
Topics RU: математика
Topics EN: mathematics
Headings: Nõelapadi

## Linn
URL: https://www.opiq.ee/kit/185/chapter/10409
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.18
Topics ET: matemaatika, linn
Topics RU: математика
Topics EN: mathematics
Headings: Linn

## Kala
URL: https://www.opiq.ee/kit/185/chapter/10410
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.19
Topics ET: matemaatika, kala
Topics RU: математика
Topics EN: mathematics
Headings: Kala

## Ussike
URL: https://www.opiq.ee/kit/185/chapter/10393
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.2
Topics ET: matemaatika, ussike
Topics RU: математика
Topics EN: mathematics
Headings: Ussike

## Vest
URL: https://www.opiq.ee/kit/185/chapter/10411
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.20
Topics ET: matemaatika, vest
Topics RU: математика
Topics EN: mathematics
Headings: Vest

## Koer
URL: https://www.opiq.ee/kit/185/chapter/10412
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.21
Topics ET: matemaatika, koer
Topics RU: математика
Topics EN: mathematics
Headings: Koer

## Kass
URL: https://www.opiq.ee/kit/185/chapter/10413
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.22
Topics ET: matemaatika, kass
Topics RU: математика
Topics EN: mathematics
Headings: Kass

## Pildiraam I
URL: https://www.opiq.ee/kit/185/chapter/10414
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.23
Topics ET: matemaatika, pildiraam
Topics RU: математика
Topics EN: mathematics
Headings: Pildiraam I

## Pildiraam II
URL: https://www.opiq.ee/kit/185/chapter/10415
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.24
Topics ET: matemaatika, pildiraam
Topics RU: математика
Topics EN: mathematics
Headings: Pildiraam II

## Visketops
URL: https://www.opiq.ee/kit/185/chapter/10416
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.25
Topics ET: matemaatika, visketops
Topics RU: математика
Topics EN: mathematics
Headings: Visketops

## Lillega kaart
URL: https://www.opiq.ee/kit/185/chapter/10417
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.26
Topics ET: matemaatika, lillega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Lillega kaart

## Karp
URL: https://www.opiq.ee/kit/185/chapter/10418
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.27
Topics ET: matemaatika, karp
Topics RU: математика
Topics EN: mathematics
Headings: Karp

## Öökull
URL: https://www.opiq.ee/kit/185/chapter/10419
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.28
Topics ET: matemaatika, öökull
Topics RU: математика
Topics EN: mathematics
Headings: Öökull

## Purjekas
URL: https://www.opiq.ee/kit/185/chapter/10420
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.29
Topics ET: matemaatika, purjekas
Topics RU: математика
Topics EN: mathematics
Headings: Purjekas

## Tigu
URL: https://www.opiq.ee/kit/185/chapter/10394
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.3
Topics ET: matemaatika, tigu
Topics RU: математика
Topics EN: mathematics
Headings: Tigu

## Õunad
URL: https://www.opiq.ee/kit/185/chapter/10395
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.4
Topics ET: matemaatika, õunad
Topics RU: математика
Topics EN: mathematics
Headings: Õunad

## Pirnid
URL: https://www.opiq.ee/kit/185/chapter/10396
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.5
Topics ET: matemaatika, pirnid
Topics RU: математика
Topics EN: mathematics
Headings: Pirnid

## Juurviljad
URL: https://www.opiq.ee/kit/185/chapter/10397
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.6
Topics ET: matemaatika, juurviljad
Topics RU: математика
Topics EN: mathematics
Headings: Juurviljad

## Linnud
URL: https://www.opiq.ee/kit/185/chapter/10398
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.7
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Linnud

## Lumememmed
URL: https://www.opiq.ee/kit/185/chapter/10399
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.8
Topics ET: matemaatika, lumememmed
Topics RU: математика
Topics EN: mathematics
Headings: Lumememmed; 1.; 2.

## Sipsik
URL: https://www.opiq.ee/kit/185/chapter/10400
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 4.9
Topics ET: matemaatika, sipsik
Topics RU: математика
Topics EN: mathematics
Headings: Sipsik

## Kala
URL: https://www.opiq.ee/kit/185/chapter/10421
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.1
Topics ET: matemaatika, kala
Topics RU: математика
Topics EN: mathematics
Headings: Kala

## Liblikas II
URL: https://www.opiq.ee/kit/185/chapter/10430
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.10
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas II

## Liblikas III
URL: https://www.opiq.ee/kit/185/chapter/10431
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.11
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas III

## Jänes
URL: https://www.opiq.ee/kit/185/chapter/10432
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.12
Topics ET: matemaatika, jänes
Topics RU: математика
Topics EN: mathematics
Headings: Jänes

## Lumememm
URL: https://www.opiq.ee/kit/185/chapter/10422
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.2
Topics ET: matemaatika, lumememm
Topics RU: математика
Topics EN: mathematics
Headings: Lumememm

## Õun
URL: https://www.opiq.ee/kit/185/chapter/10423
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Õun

## Jänes
URL: https://www.opiq.ee/kit/185/chapter/10424
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.4
Topics ET: matemaatika, jänes
Topics RU: математика
Topics EN: mathematics
Headings: Jänes

## Akvaarium
URL: https://www.opiq.ee/kit/185/chapter/10425
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.5
Topics ET: matemaatika, akvaarium
Topics RU: математика
Topics EN: mathematics
Headings: Akvaarium

## Kass
URL: https://www.opiq.ee/kit/185/chapter/10426
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.6
Topics ET: matemaatika, kass
Topics RU: математика
Topics EN: mathematics
Headings: Kass

## Kilpkonn I
URL: https://www.opiq.ee/kit/185/chapter/10427
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.7
Topics ET: matemaatika, kilpkonn
Topics RU: математика
Topics EN: mathematics
Headings: Kilpkonn I

## Kilpkonn II
URL: https://www.opiq.ee/kit/185/chapter/10428
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.8
Topics ET: matemaatika, kilpkonn
Topics RU: математика
Topics EN: mathematics
Headings: Kilpkonn II

## Liblikas I
URL: https://www.opiq.ee/kit/185/chapter/10429
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._1._osa
Chapter ID: 5.9
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas I

## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/200
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 93
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/200
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 179
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Tööks vajalikud materjalid
URL: https://www.opiq.ee/kit/200/chapter/11374
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.1
Topics ET: matemaatika, tööks, vajalikud, materjalid
Topics RU: математика
Topics EN: mathematics
Headings: Tööks vajalikud materjalid

## Kuidas teha kaardile raami
URL: https://www.opiq.ee/kit/200/chapter/11375
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.2
Topics ET: matemaatika, kuidas, teha, kaardile, raami, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha kaardile raami; 1. võimalus; 2. võimalus

## Kuidas teha kaardile lehti
URL: https://www.opiq.ee/kit/200/chapter/11376
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.3
Topics ET: matemaatika, kuidas, teha, kaardile, lehti, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha kaardile lehti; 1. võimalus; 2. võimalus; 3. võimalus; 4. võimalus; 5. võimalus

## Volditud lips
URL: https://www.opiq.ee/kit/200/chapter/11377
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.1
Topics ET: matemaatika, volditud, lips
Topics RU: математика
Topics EN: mathematics
Headings: Volditud lips

## Volditud vest
URL: https://www.opiq.ee/kit/200/chapter/11378
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.2
Topics ET: matemaatika, volditud, vest
Topics RU: математика
Topics EN: mathematics
Headings: Volditud vest

## Lihtne volditud särk
URL: https://www.opiq.ee/kit/200/chapter/11379
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.3
Topics ET: matemaatika, lihtne, volditud, särk
Topics RU: математика
Topics EN: mathematics
Headings: Lihtne volditud särk

## Volditud särk
URL: https://www.opiq.ee/kit/200/chapter/11380
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.4
Topics ET: matemaatika, volditud, särk
Topics RU: математика
Topics EN: mathematics
Headings: Volditud särk

## Kikilipsuga kaart
URL: https://www.opiq.ee/kit/200/chapter/11381
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.5
Topics ET: matemaatika, kikilipsuga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kikilipsuga kaart

## Purjekaga kaart
URL: https://www.opiq.ee/kit/200/chapter/11382
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.6
Topics ET: matemaatika, purjekaga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Purjekaga kaart

## Autodega kaart
URL: https://www.opiq.ee/kit/200/chapter/11383
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.7
Topics ET: matemaatika, autodega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Autodega kaart

## Õmmeldud kaart
URL: https://www.opiq.ee/kit/200/chapter/11384
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.8
Topics ET: matemaatika, õmmeldud, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Õmmeldud kaart

## Joonistatud lipsud
URL: https://www.opiq.ee/kit/200/chapter/11385
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.9
Topics ET: matemaatika, joonistatud, lipsud
Topics RU: математика
Topics EN: mathematics
Headings: Joonistatud lipsud

## Võrguga kaart
URL: https://www.opiq.ee/kit/200/chapter/11386
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.1
Topics ET: matemaatika, võrguga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Võrguga kaart

## Erineva suurusega küünlad
URL: https://www.opiq.ee/kit/200/chapter/11395
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.10
Topics ET: matemaatika, erineva, suurusega, küünlad
Topics RU: математика
Topics EN: mathematics
Headings: Erineva suurusega küünlad

## Lainepapist küünlad
URL: https://www.opiq.ee/kit/200/chapter/11396
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.11
Topics ET: matemaatika, lainepapist, küünlad
Topics RU: математика
Topics EN: mathematics
Headings: Lainepapist küünlad

## Pabernöörist küünal
URL: https://www.opiq.ee/kit/200/chapter/11397
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.12
Topics ET: matemaatika, pabernöörist, küünal, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Pabernöörist küünal; 1. võimalus; 2. võimalus

## Pop-up-tehnikas kollaaž
URL: https://www.opiq.ee/kit/200/chapter/11398
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.13
Topics ET: matemaatika, tehnikas, kollaaž
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kollaaž

## Pop-up-tehnikas kaart
URL: https://www.opiq.ee/kit/200/chapter/11399
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.14
Topics ET: matemaatika, tehnikas, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kaart

## Pop-up-tehnikas kera
URL: https://www.opiq.ee/kit/200/chapter/11400
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.15
Topics ET: matemaatika, tehnikas, kera
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kera

## Kalkapaberist jõuluehted
URL: https://www.opiq.ee/kit/200/chapter/11401
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.16
Topics ET: matemaatika, kalkapaberist, jõuluehted
Topics RU: математика
Topics EN: mathematics
Headings: Kalkapaberist jõuluehted

## Joonistatud kuusk
URL: https://www.opiq.ee/kit/200/chapter/11402
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.17
Topics ET: matemaatika, joonistatud, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Joonistatud kuusk

## Kahekordse kolmnurgaga kuusk
URL: https://www.opiq.ee/kit/200/chapter/11403
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.18
Topics ET: matemaatika, kahekordse, kolmnurgaga, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Kahekordse kolmnurgaga kuusk

## Kihiline kuusk
URL: https://www.opiq.ee/kit/200/chapter/11404
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.19
Topics ET: matemaatika, kihiline, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Kihiline kuusk

## Sinepituubist kaart
URL: https://www.opiq.ee/kit/200/chapter/11387
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.2
Topics ET: matemaatika, sinepituubist, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Sinepituubist kaart

## Pooleks volditud ringidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11405
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.20
Topics ET: matemaatika, pooleks, volditud, ringidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pooleks volditud ringidest kuusk

## Ribastatud paberist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11406
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.21
Topics ET: matemaatika, ribastatud, paberist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ribastatud paberist kuusk

## Nöörist või traadist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11407
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.22
Topics ET: matemaatika, nöörist, traadist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Nöörist või traadist kuusk

## Risti punutud paela või traadiga kuusk
URL: https://www.opiq.ee/kit/200/chapter/11408
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.23
Topics ET: matemaatika, risti, punutud, paela, traadiga, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Risti punutud paela või traadiga kuusk

## Pitsilisest paberist, paberiribadest või paeltest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11409
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.24
Topics ET: matemaatika, pitsilisest, paberist, paberiribadest, paeltest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilisest paberist, paberiribadest või paeltest kuusk

## Punutud kuusk
URL: https://www.opiq.ee/kit/200/chapter/11410
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.25
Topics ET: matemaatika, punutud, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Punutud kuusk

## Tikkimisriidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11411
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.26
Topics ET: matemaatika, tikkimisriidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Tikkimisriidest kuusk

## Erinevat värvi kuused
URL: https://www.opiq.ee/kit/200/chapter/11412
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.27
Topics ET: matemaatika, erinevat, värvi, kuused
Topics RU: математика
Topics EN: mathematics
Headings: Erinevat värvi kuused

## Nööpidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11413
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.28
Topics ET: matemaatika, nööpidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Nööpidest kuusk

## Ruumiline kuusk
URL: https://www.opiq.ee/kit/200/chapter/11414
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.29
Topics ET: matemaatika, ruumiline, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline kuusk

## Teeküünlatopsist kaart
URL: https://www.opiq.ee/kit/200/chapter/11388
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.3
Topics ET: matemaatika, teeküünlatopsist, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Teeküünlatopsist kaart

## Ribadest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11415
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.30
Topics ET: matemaatika, ribadest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ribadest kuusk

## PVA liimi, metallipuru ja tähekestega kaart
URL: https://www.opiq.ee/kit/200/chapter/11416
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.31
Topics ET: matemaatika, liimi, metallipuru, tähekestega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: PVA liimi, metallipuru ja tähekestega kaart

## Traadi või pärlitega ja PVA liimiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11417
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.32
Topics ET: matemaatika, traadi, pärlitega, liimiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Traadi või pärlitega ja PVA liimiga kaart

## Paberiribadest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11418
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.33
Topics ET: matemaatika, paberiribadest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Paberiribadest kuusk

## Siksak-tehnikas kuusk
URL: https://www.opiq.ee/kit/200/chapter/11419
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.34
Topics ET: matemaatika, siksak, tehnikas, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Siksak-tehnikas kuusk

## Pitsilisest koogipaberist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11420
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.35
Topics ET: matemaatika, pitsilisest, koogipaberist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilisest koogipaberist kuusk

## Elupuuoksast kuusk
URL: https://www.opiq.ee/kit/200/chapter/11421
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.36
Topics ET: matemaatika, elupuuoksast, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Elupuuoksast kuusk

## Samblikuga kaart
URL: https://www.opiq.ee/kit/200/chapter/11389
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.4
Topics ET: matemaatika, samblikuga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Samblikuga kaart

## Kingipakkidega kaart
URL: https://www.opiq.ee/kit/200/chapter/11390
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.5
Topics ET: matemaatika, kingipakkidega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kingipakkidega kaart

## Kahepoolse teibiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11391
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.6
Topics ET: matemaatika, kahepoolse, teibiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kahepoolse teibiga kaart

## Tagasipööratud äärega kaart
URL: https://www.opiq.ee/kit/200/chapter/11392
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.7
Topics ET: matemaatika, tagasipööratud, äärega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Tagasipööratud äärega kaart

## Pabernöörist jõulupärg
URL: https://www.opiq.ee/kit/200/chapter/11393
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.8
Topics ET: matemaatika, pabernöörist, jõulupärg
Topics RU: математика
Topics EN: mathematics
Headings: Pabernöörist jõulupärg

## Ringidest jõulupärg ja kuusk
URL: https://www.opiq.ee/kit/200/chapter/11394
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.9
Topics ET: matemaatika, ringidest, jõulupärg, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ringidest jõulupärg ja kuusk

## Erikujulised südamed
URL: https://www.opiq.ee/kit/200/chapter/11422
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.1
Topics ET: matemaatika, erikujulised, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Erikujulised südamed

## Ruumiline süda
URL: https://www.opiq.ee/kit/200/chapter/11423
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.2
Topics ET: matemaatika, ruumiline, süda
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline süda

## Rullitud paberiribadest südamed
URL: https://www.opiq.ee/kit/200/chapter/11424
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.3
Topics ET: matemaatika, rullitud, paberiribadest, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Rullitud paberiribadest südamed

## Pitsiga südamed
URL: https://www.opiq.ee/kit/200/chapter/11425
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.4
Topics ET: matemaatika, pitsiga, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Pitsiga südamed

## Lahtikäiv kaart
URL: https://www.opiq.ee/kit/200/chapter/11426
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.1
Topics ET: matemaatika, lahtikäiv, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Lahtikäiv kaart

## Üllatuskaart
URL: https://www.opiq.ee/kit/200/chapter/11427
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.2
Topics ET: matemaatika, üllatuskaart
Topics RU: математика
Topics EN: mathematics
Headings: Üllatuskaart

## Valik kevadpühade kaarte
URL: https://www.opiq.ee/kit/200/chapter/11428
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.3
Topics ET: matemaatika, valik, kevadpühade, kaarte
Topics RU: математика
Topics EN: mathematics
Headings: Valik kevadpühade kaarte

## Pop-up-tehnikas kaart
URL: https://www.opiq.ee/kit/200/chapter/11429
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.4
Topics ET: matemaatika, tehnikas, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kaart

## Lehvikust lill
URL: https://www.opiq.ee/kit/200/chapter/11430
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.1
Topics ET: matemaatika, taim, taimed, puu, lill, lehvikust
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lehvikust lill

## Muffinivormidest kaart
URL: https://www.opiq.ee/kit/200/chapter/11439
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.10
Topics ET: matemaatika, muffinivormidest, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Muffinivormidest kaart

## Tagasipööratud äärtega lill
URL: https://www.opiq.ee/kit/200/chapter/11440
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.11
Topics ET: matemaatika, taim, taimed, puu, lill, tagasipööratud, äärtega
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Tagasipööratud äärtega lill

## Pop-up-tehnikas lilledega kaardid
URL: https://www.opiq.ee/kit/200/chapter/11441
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.12
Topics ET: matemaatika, tehnikas, lilledega, kaardid
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas lilledega kaardid

## Pop-up-tehnikas lillepotid
URL: https://www.opiq.ee/kit/200/chapter/11442
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.13
Topics ET: matemaatika, tehnikas, lillepotid
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas lillepotid

## Tulbikaart
URL: https://www.opiq.ee/kit/200/chapter/11443
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.14
Topics ET: matemaatika, tulbikaart
Topics RU: математика
Topics EN: mathematics
Headings: Tulbikaart

## Lumikellukesed
URL: https://www.opiq.ee/kit/200/chapter/11444
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.15
Topics ET: matemaatika, lumikellukesed
Topics RU: математика
Topics EN: mathematics
Headings: Lumikellukesed

## Volditud lill
URL: https://www.opiq.ee/kit/200/chapter/11445
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.16
Topics ET: matemaatika, taim, taimed, puu, lill, volditud
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Volditud lill

## Volditud lill
URL: https://www.opiq.ee/kit/200/chapter/11446
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.17
Topics ET: matemaatika, taim, taimed, puu, lill, volditud
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Volditud lill

## Paberiribadest lill
URL: https://www.opiq.ee/kit/200/chapter/11447
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.18
Topics ET: matemaatika, taim, taimed, puu, lill, paberiribadest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Paberiribadest lill

## Venivast krepp-paberist lilled
URL: https://www.opiq.ee/kit/200/chapter/11448
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.19
Topics ET: matemaatika, venivast, krepp, paberist, lilled
Topics RU: математика
Topics EN: mathematics
Headings: Venivast krepp-paberist lilled

## Pabernöörist lill
URL: https://www.opiq.ee/kit/200/chapter/11431
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.2
Topics ET: matemaatika, taim, taimed, puu, lill, pabernöörist
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pabernöörist lill

## Rullitud paberiribadest lilled
URL: https://www.opiq.ee/kit/200/chapter/11432
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.3
Topics ET: matemaatika, rullitud, paberiribadest, lilled
Topics RU: математика
Topics EN: mathematics
Headings: Rullitud paberiribadest lilled

## Pooleks volditud ringidest lill
URL: https://www.opiq.ee/kit/200/chapter/11433
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.4
Topics ET: matemaatika, taim, taimed, puu, lill, pooleks, volditud, ringidest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pooleks volditud ringidest lill

## Lainepapist lill
URL: https://www.opiq.ee/kit/200/chapter/11434
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.5
Topics ET: matemaatika, taim, taimed, puu, lill, lainepapist
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lainepapist lill

## Pooleks volditud südametest lill
URL: https://www.opiq.ee/kit/200/chapter/11435
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.6
Topics ET: matemaatika, taim, taimed, puu, lill, pooleks, volditud, südametest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pooleks volditud südametest lill

## Ringidest lill
URL: https://www.opiq.ee/kit/200/chapter/11436
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.7
Topics ET: matemaatika, taim, taimed, puu, lill, ringidest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Ringidest lill

## Tulbid
URL: https://www.opiq.ee/kit/200/chapter/11437
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.8
Topics ET: matemaatika, tulbid
Topics RU: математика
Topics EN: mathematics
Headings: Tulbid

## Tulbid potis
URL: https://www.opiq.ee/kit/200/chapter/11438
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.9
Topics ET: matemaatika, tulbid, potis
Topics RU: математика
Topics EN: mathematics
Headings: Tulbid potis

## Liivakaart
URL: https://www.opiq.ee/kit/200/chapter/11449
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.1
Topics ET: matemaatika, liivakaart
Topics RU: математика
Topics EN: mathematics
Headings: Liivakaart

## Volditud liblikaga kaart
URL: https://www.opiq.ee/kit/200/chapter/11458
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.10
Topics ET: matemaatika, volditud, liblikaga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Volditud liblikaga kaart

## Nööbikaart
URL: https://www.opiq.ee/kit/200/chapter/11450
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.2
Topics ET: matemaatika, nööbikaart
Topics RU: математика
Topics EN: mathematics
Headings: Nööbikaart

## Punutud kaart
URL: https://www.opiq.ee/kit/200/chapter/11451
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.3
Topics ET: matemaatika, punutud, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Punutud kaart

## Pitsilise koogipaberiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11452
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.4
Topics ET: matemaatika, pitsilise, koogipaberiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilise koogipaberiga kaart

## Pildiraamid
URL: https://www.opiq.ee/kit/200/chapter/11453
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.5
Topics ET: matemaatika, pildiraamid
Topics RU: математика
Topics EN: mathematics
Headings: Pildiraamid

## Pitsilise paberiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11454
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.6
Topics ET: matemaatika, pitsilise, paberiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilise paberiga kaart

## Värvilaikudega kaart
URL: https://www.opiq.ee/kit/200/chapter/11455
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.7
Topics ET: matemaatika, värvilaikudega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Värvilaikudega kaart

## Täpikaart
URL: https://www.opiq.ee/kit/200/chapter/11456
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.8
Topics ET: matemaatika, täpikaart
Topics RU: математика
Topics EN: mathematics
Headings: Täpikaart

## Kujundirauaga tehtud kaardid
URL: https://www.opiq.ee/kit/200/chapter/11457
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.9
Topics ET: matemaatika, kujundirauaga, tehtud, kaardid
Topics RU: математика
Topics EN: mathematics
Headings: Kujundirauaga tehtud kaardid

## Творческая мастерская – Opiq
URL: https://www.opiq.ee/Kit/Details/368
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 180
Topics ET: matemaatika, opiq
Topics RU: математика, творческая, мастерская
Topics EN: mathematics

## Творческая мастерская – Opiq
URL: https://www.opiq.ee/Kit/Details/368
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 271
Topics ET: matemaatika, opiq
Topics RU: математика, творческая, мастерская
Topics EN: mathematics

## РУКА РАЗВИВАЕТ МОЗГ
URL: https://www.opiq.ee/kit/368/chapter/20111
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, рука, развивает, мозг
Topics EN: mathematics
Headings: РУКА РАЗВИВАЕТ МОЗГ

## Закладки (работа с рваной бумагой)
URL: https://www.opiq.ee/kit/368/chapter/20112
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, закладки, работа, рваной, бумагой
Topics EN: mathematics
Headings: Закладки (работа с рваной бумагой); 1.; 2.

## Фрукты в вазе (совместная работа, работа с рваной бумагой)
URL: https://www.opiq.ee/kit/368/chapter/20121
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.10
Topics ET: matemaatika
Topics RU: математика, фрукты, вазе, совместная, работа, рваной, бумагой
Topics EN: mathematics
Headings: Фрукты в вазе (совместная работа, работа с рваной бумагой)

## Шапка
URL: https://www.opiq.ee/kit/368/chapter/20122
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.11
Topics ET: matemaatika
Topics RU: математика, шапка
Topics EN: mathematics
Headings: Шапка

## Птица на ветке (работа с рваной бумагой)
URL: https://www.opiq.ee/kit/368/chapter/20123
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.12
Topics ET: matemaatika
Topics RU: математика, птица, ветке, работа, рваной, бумагой
Topics EN: mathematics
Headings: Птица на ветке (работа с рваной бумагой)

## Большой снеговик из снежинок (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20124
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.13
Topics ET: matemaatika
Topics RU: математика, большой, снеговик, снежинок, совместная, работа
Topics EN: mathematics
Headings: Большой снеговик из снежинок (совместная работа)

## Рождественский фонарик
URL: https://www.opiq.ee/kit/368/chapter/20125
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.14
Topics ET: matemaatika
Topics RU: математика, рождественский, фонарик
Topics EN: mathematics
Headings: Рождественский фонарик

## Цепочка
URL: https://www.opiq.ee/kit/368/chapter/20126
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.15
Topics ET: matemaatika
Topics RU: математика, цепочка
Topics EN: mathematics
Headings: Цепочка

## Снеговик (работа с мятой бумагой)
URL: https://www.opiq.ee/kit/368/chapter/20127
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.16
Topics ET: matemaatika
Topics RU: математика, снеговик, работа, мятой, бумагой
Topics EN: mathematics
Headings: Снеговик (работа с мятой бумагой)

## Зимняя картинка
URL: https://www.opiq.ee/kit/368/chapter/20128
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.17
Topics ET: matemaatika
Topics RU: математика, зимняя, картинка
Topics EN: mathematics
Headings: Зимняя картинка

## Башня Длинный Герман (работа с рваной бумагой)
URL: https://www.opiq.ee/kit/368/chapter/20129
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.18
Topics ET: matemaatika
Topics RU: математика, башня, длинный, герман, работа, рваной, бумагой
Topics EN: mathematics
Headings: Башня Длинный Герман (работа с рваной бумагой)

## Объемные подснежники
URL: https://www.opiq.ee/kit/368/chapter/20130
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.19
Topics ET: matemaatika
Topics RU: математика, объемные, подснежники
Topics EN: mathematics
Headings: Объемные подснежники

## Цветок
URL: https://www.opiq.ee/kit/368/chapter/20113
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.2
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Цветок

## Банки с заготовками
URL: https://www.opiq.ee/kit/368/chapter/20131
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.20
Topics ET: matemaatika
Topics RU: математика, банки, заготовками
Topics EN: mathematics
Headings: Банки с заготовками

## Полоска из фигурок
URL: https://www.opiq.ee/kit/368/chapter/20132
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.21
Topics ET: matemaatika
Topics RU: математика, полоска, фигурок
Topics EN: mathematics
Headings: Полоска из фигурок

## Объемное яйцо
URL: https://www.opiq.ee/kit/368/chapter/20133
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.22
Topics ET: matemaatika
Topics RU: математика, объемное, яйцо
Topics EN: mathematics
Headings: Объемное яйцо

## Календари
URL: https://www.opiq.ee/kit/368/chapter/20134
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.23
Topics ET: matemaatika
Topics RU: математика, календари
Topics EN: mathematics
Headings: Календари

## Весенний пейзаж (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20135
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.24
Topics ET: matemaatika
Topics RU: математика, весенний, пейзаж, совместная, работа
Topics EN: mathematics
Headings: Весенний пейзаж (совместная работа)

## Весенние цветы (групповая работа)
URL: https://www.opiq.ee/kit/368/chapter/20136
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.25
Topics ET: matemaatika
Topics RU: математика, весенние, цветы, групповая, работа
Topics EN: mathematics
Headings: Весенние цветы (групповая работа)

## Елочки
URL: https://www.opiq.ee/kit/368/chapter/20137
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.26
Topics ET: matemaatika
Topics RU: математика, елочки
Topics EN: mathematics
Headings: Елочки

## Ваза с цветами
URL: https://www.opiq.ee/kit/368/chapter/20114
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, ваза, цветами
Topics EN: mathematics
Headings: Ваза с цветами

## Гриб
URL: https://www.opiq.ee/kit/368/chapter/20115
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, гриб
Topics EN: mathematics
Headings: Гриб

## Объемные яблоки (работа с мятой бумагой)
URL: https://www.opiq.ee/kit/368/chapter/20116
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, объемные, яблоки, работа, мятой, бумагой
Topics EN: mathematics
Headings: Объемные яблоки (работа с мятой бумагой); 1.; 2.

## Цветок и бабочка (работа с рваной бумагой)
URL: https://www.opiq.ee/kit/368/chapter/20117
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.6
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, бабочка, работа, рваной, бумагой
Topics EN: mathematics, plant, plants, tree, flower
Headings: Цветок и бабочка (работа с рваной бумагой)

## Сороконожка (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20118
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, сороконожка, совместная, работа
Topics EN: mathematics
Headings: Сороконожка (совместная работа)

## Светлячок (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20119
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, светлячок, совместная, работа
Topics EN: mathematics
Headings: Светлячок (совместная работа)

## Сова (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20120
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика, сова, совместная, работа
Topics EN: mathematics
Headings: Сова (совместная работа)

## Грибы
URL: https://www.opiq.ee/kit/368/chapter/20138
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, грибы
Topics EN: mathematics
Headings: Грибы

## Цветные пятна
URL: https://www.opiq.ee/kit/368/chapter/20147
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.10
Topics ET: matemaatika
Topics RU: математика, цветные, пятна
Topics EN: mathematics
Headings: Цветные пятна

## Подснежники
URL: https://www.opiq.ee/kit/368/chapter/20148
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.11
Topics ET: matemaatika
Topics RU: математика, подснежники
Topics EN: mathematics
Headings: Подснежники

## Сипсик
URL: https://www.opiq.ee/kit/368/chapter/20149
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.12
Topics ET: matemaatika
Topics RU: математика, сипсик
Topics EN: mathematics
Headings: Сипсик

## Яйцо, бабочка и сова (оттиски кистью)
URL: https://www.opiq.ee/kit/368/chapter/20150
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.13
Topics ET: matemaatika
Topics RU: математика, яйцо, бабочка, сова, оттиски, кистью
Topics EN: mathematics
Headings: Яйцо, бабочка и сова (оттиски кистью)

## Цветы в вазе (оттиски кистью)
URL: https://www.opiq.ee/kit/368/chapter/20151
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.14
Topics ET: matemaatika
Topics RU: математика, цветы, вазе, оттиски, кистью
Topics EN: mathematics
Headings: Цветы в вазе (оттиски кистью)

## Бабочка (техника симметричного рисунка)
URL: https://www.opiq.ee/kit/368/chapter/20152
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.15
Topics ET: matemaatika
Topics RU: математика, бабочка, техника, симметричного, рисунка
Topics EN: mathematics
Headings: Бабочка (техника симметричного рисунка)

## Цыпленок и заяц (оттиски губкой)
URL: https://www.opiq.ee/kit/368/chapter/20153
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.16
Topics ET: matemaatika
Topics RU: математика, цыпленок, заяц, оттиски, губкой
Topics EN: mathematics
Headings: Цыпленок и заяц (оттиски губкой)

## Перелески I (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20154
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.17
Topics ET: matemaatika
Topics RU: математика, перелески, совместная, работа
Topics EN: mathematics
Headings: Перелески I (совместная работа)

## Перелески II
URL: https://www.opiq.ee/kit/368/chapter/20155
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.18
Topics ET: matemaatika
Topics RU: математика, перелески
Topics EN: mathematics
Headings: Перелески II

## Ритм
URL: https://www.opiq.ee/kit/368/chapter/20156
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.19
Topics ET: matemaatika
Topics RU: математика, ритм
Topics EN: mathematics
Headings: Ритм

## Заснеженные горы (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20139
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, заснеженные, горы, совместная, работа
Topics EN: mathematics
Headings: Заснеженные горы (совместная работа)

## Салют
URL: https://www.opiq.ee/kit/368/chapter/20157
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.20
Topics ET: matemaatika
Topics RU: математика, салют
Topics EN: mathematics
Headings: Салют

## Узор (групповая работа)
URL: https://www.opiq.ee/kit/368/chapter/20158
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.21
Topics ET: matemaatika
Topics RU: математика, узор, групповая, работа
Topics EN: mathematics
Headings: Узор (групповая работа)

## Большое пасхальное яйцо (совместная работа)
URL: https://www.opiq.ee/kit/368/chapter/20159
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.22
Topics ET: matemaatika
Topics RU: математика, большое, пасхальное, яйцо, совместная, работа
Topics EN: mathematics
Headings: Большое пасхальное яйцо (совместная работа)

## Бабочка
URL: https://www.opiq.ee/kit/368/chapter/20140
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, бабочка
Topics EN: mathematics
Headings: Бабочка

## Мамин портрет
URL: https://www.opiq.ee/kit/368/chapter/20141
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, мамин, портрет
Topics EN: mathematics
Headings: Мамин портрет

## Любимая прическа
URL: https://www.opiq.ee/kit/368/chapter/20142
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, любимая, прическа
Topics EN: mathematics
Headings: Любимая прическа

## Напечатанная картинка
URL: https://www.opiq.ee/kit/368/chapter/20143
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика, напечатанная, картинка
Topics EN: mathematics
Headings: Напечатанная картинка

## Зонтик
URL: https://www.opiq.ee/kit/368/chapter/20144
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.7
Topics ET: matemaatika
Topics RU: математика, зонтик
Topics EN: mathematics
Headings: Зонтик

## Осеннее дерево (оттиски губкой)
URL: https://www.opiq.ee/kit/368/chapter/20145
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.8
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, осеннее, оттиски, губкой
Topics EN: mathematics, plant, plants, tree, flower
Headings: Осеннее дерево (оттиски губкой)

## Снежные хлопья и снеговик (рисование свечой)
URL: https://www.opiq.ee/kit/368/chapter/20146
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 3.9
Topics ET: matemaatika
Topics RU: математика, снежные, хлопья, снеговик, рисование, свечой
Topics EN: mathematics
Headings: Снежные хлопья и снеговик (рисование свечой)

## Грибы
URL: https://www.opiq.ee/kit/368/chapter/20160
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, грибы
Topics EN: mathematics
Headings: Грибы

## Рождественские открытки
URL: https://www.opiq.ee/kit/368/chapter/20169
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.10
Topics ET: matemaatika
Topics RU: математика, рождественские, открытки
Topics EN: mathematics
Headings: Рождественские открытки

## Петушок-подставка для яиц
URL: https://www.opiq.ee/kit/368/chapter/20170
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика, петушок, подставка
Topics EN: mathematics
Headings: Петушок-подставка для яиц

## Гномик
URL: https://www.opiq.ee/kit/368/chapter/20171
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.12
Topics ET: matemaatika
Topics RU: математика, гномик
Topics EN: mathematics
Headings: Гномик

## Картинка из песка
URL: https://www.opiq.ee/kit/368/chapter/20172
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.13
Topics ET: matemaatika
Topics RU: математика, картинка, песка
Topics EN: mathematics
Headings: Картинка из песка

## Кошка
URL: https://www.opiq.ee/kit/368/chapter/20173
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.14
Topics ET: matemaatika
Topics RU: математика, кошка
Topics EN: mathematics
Headings: Кошка

## Животное из коробки
URL: https://www.opiq.ee/kit/368/chapter/20174
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.15
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, коробки
Topics EN: mathematics, animal, animals, birds, insects
Headings: Животное из коробки

## Рыба из пакета
URL: https://www.opiq.ee/kit/368/chapter/20175
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.16
Topics ET: matemaatika
Topics RU: математика, рыба, пакета
Topics EN: mathematics
Headings: Рыба из пакета

## Подушечка для иголок
URL: https://www.opiq.ee/kit/368/chapter/20176
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.17
Topics ET: matemaatika
Topics RU: математика, подушечка, иголок
Topics EN: mathematics
Headings: Подушечка для иголок

## Город
URL: https://www.opiq.ee/kit/368/chapter/20177
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.18
Topics ET: matemaatika
Topics RU: математика, город
Topics EN: mathematics
Headings: Город

## Рыбка
URL: https://www.opiq.ee/kit/368/chapter/20178
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.19
Topics ET: matemaatika
Topics RU: математика, рыбка
Topics EN: mathematics
Headings: Рыбка

## Червячок
URL: https://www.opiq.ee/kit/368/chapter/20161
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, червячок
Topics EN: mathematics
Headings: Червячок

## Жилет
URL: https://www.opiq.ee/kit/368/chapter/20179
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.20
Topics ET: matemaatika
Topics RU: математика, жилет
Topics EN: mathematics
Headings: Жилет

## Собака
URL: https://www.opiq.ee/kit/368/chapter/20180
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.21
Topics ET: matemaatika
Topics RU: математика, собака
Topics EN: mathematics
Headings: Собака

## Кошка
URL: https://www.opiq.ee/kit/368/chapter/20181
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.22
Topics ET: matemaatika
Topics RU: математика, кошка
Topics EN: mathematics
Headings: Кошка

## Рама для картинки I
URL: https://www.opiq.ee/kit/368/chapter/20182
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.23
Topics ET: matemaatika
Topics RU: математика, рама, картинки
Topics EN: mathematics
Headings: Рама для картинки I

## Рама для картинки II
URL: https://www.opiq.ee/kit/368/chapter/20183
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.24
Topics ET: matemaatika
Topics RU: математика, рама, картинки
Topics EN: mathematics
Headings: Рама для картинки II

## Бильбоке
URL: https://www.opiq.ee/kit/368/chapter/20184
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.25
Topics ET: matemaatika
Topics RU: математика, бильбоке
Topics EN: mathematics
Headings: Бильбоке

## Открытка с цветком
URL: https://www.opiq.ee/kit/368/chapter/20185
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.26
Topics ET: matemaatika
Topics RU: математика, открытка, цветком
Topics EN: mathematics
Headings: Открытка с цветком

## Коробочка
URL: https://www.opiq.ee/kit/368/chapter/20186
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.27
Topics ET: matemaatika
Topics RU: математика, коробочка
Topics EN: mathematics
Headings: Коробочка

## Сова
URL: https://www.opiq.ee/kit/368/chapter/20187
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.28
Topics ET: matemaatika
Topics RU: математика, сова
Topics EN: mathematics
Headings: Сова

## Парусник
URL: https://www.opiq.ee/kit/368/chapter/20188
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.29
Topics ET: matemaatika
Topics RU: математика, парусник
Topics EN: mathematics
Headings: Парусник

## Улитка
URL: https://www.opiq.ee/kit/368/chapter/20162
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, улитка
Topics EN: mathematics
Headings: Улитка

## Яблоки
URL: https://www.opiq.ee/kit/368/chapter/20163
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, яблоки
Topics EN: mathematics
Headings: Яблоки

## Груши
URL: https://www.opiq.ee/kit/368/chapter/20164
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, груши
Topics EN: mathematics
Headings: Груши

## Овощи
URL: https://www.opiq.ee/kit/368/chapter/20165
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, овощи
Topics EN: mathematics
Headings: Овощи

## Птицы
URL: https://www.opiq.ee/kit/368/chapter/20166
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.7
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Птицы

## Снеговики
URL: https://www.opiq.ee/kit/368/chapter/20167
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика, снеговики
Topics EN: mathematics
Headings: Снеговики; 1.; 2.

## Сипсик
URL: https://www.opiq.ee/kit/368/chapter/20168
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 4.9
Topics ET: matemaatika
Topics RU: математика, сипсик
Topics EN: mathematics
Headings: Сипсик

## Рыба
URL: https://www.opiq.ee/kit/368/chapter/20189
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, рыба
Topics EN: mathematics
Headings: Рыба

## Бабочка II
URL: https://www.opiq.ee/kit/368/chapter/20198
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.10
Topics ET: matemaatika
Topics RU: математика, бабочка
Topics EN: mathematics
Headings: Бабочка II

## Бабочка III
URL: https://www.opiq.ee/kit/368/chapter/20199
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.11
Topics ET: matemaatika
Topics RU: математика, бабочка
Topics EN: mathematics
Headings: Бабочка III

## Заяц
URL: https://www.opiq.ee/kit/368/chapter/20200
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.12
Topics ET: matemaatika
Topics RU: математика, заяц
Topics EN: mathematics
Headings: Заяц

## Снеговик
URL: https://www.opiq.ee/kit/368/chapter/20190
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, снеговик
Topics EN: mathematics
Headings: Снеговик

## Яблоко
URL: https://www.opiq.ee/kit/368/chapter/20191
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, яблоко
Topics EN: mathematics
Headings: Яблоко

## Заяц
URL: https://www.opiq.ee/kit/368/chapter/20192
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, заяц
Topics EN: mathematics
Headings: Заяц

## Аквариум
URL: https://www.opiq.ee/kit/368/chapter/20193
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.5
Topics ET: matemaatika
Topics RU: математика, аквариум
Topics EN: mathematics
Headings: Аквариум

## Кошка
URL: https://www.opiq.ee/kit/368/chapter/20194
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.6
Topics ET: matemaatika
Topics RU: математика, кошка
Topics EN: mathematics
Headings: Кошка

## Черепаха I
URL: https://www.opiq.ee/kit/368/chapter/20195
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.7
Topics ET: matemaatika
Topics RU: математика, черепаха
Topics EN: mathematics
Headings: Черепаха I

## Черепаха II
URL: https://www.opiq.ee/kit/368/chapter/20196
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.8
Topics ET: matemaatika
Topics RU: математика, черепаха
Topics EN: mathematics
Headings: Черепаха II

## Бабочка I
URL: https://www.opiq.ee/kit/368/chapter/20197
Book: Kunsti- ja tööõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._1_часть
Chapter ID: 5.9
Topics ET: matemaatika
Topics RU: математика, бабочка
Topics EN: mathematics
Headings: Бабочка I
