## СВЕТЛЯЧОК . Чтение для 1 клacca – Opiq
URL: https://www.opiq.ee/Kit/Details/257
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 1
Topics ET: matemaatika, opiq
Topics RU: математика, светлячок, чтение
Topics EN: mathematics

## СВЕТЛЯЧОК . Чтение для 1 клacca – Opiq
URL: https://www.opiq.ee/Kit/Details/257
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 79
Topics ET: matemaatika, opiq
Topics RU: математика, светлячок, чтение
Topics EN: mathematics

## Дорогой первоклассник!
URL: https://www.opiq.ee/kit/257/chapter/14469
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, дорогой, первоклассник
Topics EN: mathematics
Headings: Дорогой первоклассник!

## Толкование слов
URL: https://www.opiq.ee/kit/257/chapter/14545
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 10.1
Topics ET: matemaatika
Topics RU: математика, толкование, слов
Topics EN: mathematics
Headings: Толкование слов

## ЧИТАТЕЛЮ
URL: https://www.opiq.ee/kit/257/chapter/14472
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, читателю
Topics EN: mathematics
Headings: ЧИТАТЕЛЮ

## ЖИЛИ-БЫЛИ БУКВЫ
URL: https://www.opiq.ee/kit/257/chapter/14473
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, жили, были, буквы, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ЖИЛИ-БЫЛИ БУКВЫ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 1; Э-ЗАДАНИЕ 2; Пословица

## АИСТ И ЕГО УЧЕНИКИ
URL: https://www.opiq.ee/kit/257/chapter/14474
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, аист, ученики, словарная, разминка, вопросы
Topics EN: mathematics
Headings: АИСТ И ЕГО УЧЕНИКИ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 3; Э-ЗАДАНИЕ 4

## ПОЧЕМУ СОРОКОНОЖКИ ОПОЗДАЛИ НА УРОК
URL: https://www.opiq.ee/kit/257/chapter/14470
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, почему, сороконожки, опоздали, урок, вопросы
Topics EN: mathematics
Headings: ПОЧЕМУ СОРОКОНОЖКИ ОПОЗДАЛИ НА УРОК; Вопросы и задания

## ЗАГАДКИ
URL: https://www.opiq.ee/kit/257/chapter/14475
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, загадки, загадка
Topics EN: mathematics
Headings: ЗАГАДКИ; загадка 1; загадка 2; загадка 3; загадка 4

## КОТ И ЛОДЫРИ
URL: https://www.opiq.ee/kit/257/chapter/14476
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, лодыри, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: КОТ И ЛОДЫРИ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 5; Э-ЗАДАНИЕ 6; Пословица

## РАССКАЗ НА ОДНУ БУКВУ
URL: https://www.opiq.ee/kit/257/chapter/14477
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, рассказ, одну, букву, звери, забавного, зоопарка, словарная, разминка, вопросы
Topics EN: mathematics
Headings: РАССКАЗ НА ОДНУ БУКВУ; Звери из забавного зоопарка; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 7; Пословица

## ЧТО В ЛЕСУ НА БУКВУ Ш?
URL: https://www.opiq.ee/kit/257/chapter/14471
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, лесу, букву
Topics EN: mathematics
Headings: ЧТО В ЛЕСУ НА БУКВУ Ш?

## ЧЕТЫРЕ ЖЕЛАНИЯ
URL: https://www.opiq.ee/kit/257/chapter/14478
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, четыре, желания, словарная, разминка, вопросы
Topics EN: mathematics
Headings: ЧЕТЫРЕ ЖЕЛАНИЯ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 8

## СЁМКА И МОРОЗ
URL: https://www.opiq.ee/kit/257/chapter/14487
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.10
Topics ET: matemaatika
Topics RU: математика, мороз, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: СЁМКА И МОРОЗ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 16; Пословица

## ВРЕМЕНА ГОДА
URL: https://www.opiq.ee/kit/257/chapter/14479
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, времена, года, вопросы, пословица
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: ВРЕМЕНА ГОДА; Вопросы и задания; Э-ЗАДАНИЕ 9; Пословица

## ЗАГАДКА
URL: https://www.opiq.ee/kit/257/chapter/14480
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, загадка
Topics EN: mathematics
Headings: ЗАГАДКА; загадка 5

## НАЗОВИ ЗИМНИЕ МЕСЯЦЫ!
URL: https://www.opiq.ee/kit/257/chapter/14481
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, назови, зимние, месяцы, загадка
Topics EN: mathematics
Headings: НАЗОВИ ЗИМНИЕ МЕСЯЦЫ!; загадка 6; загадка 7; загадка 8

## ЧЕТЫРЕ ХУДОЖНИКА. ЗИМА
URL: https://www.opiq.ee/kit/257/chapter/14482
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.5
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, четыре, художника, словарная, разминка, вопросы, пословица
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: ЧЕТЫРЕ ХУДОЖНИКА. ЗИМА; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 10; Э-ЗАДАНИЕ 11; Пословица

## БЕЛЫЙ СНЕГ ПУШИСТЫЙ
URL: https://www.opiq.ee/kit/257/chapter/14483
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика, белый, снег, пушистый, словарная, разминка, вопросы, пословицы
Topics EN: mathematics
Headings: БЕЛЫЙ СНЕГ ПУШИСТЫЙ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 12; Э-ЗАДАНИЕ 13; Пословицы

## ЛЕСНОЙ ВОРОБЕЙ
URL: https://www.opiq.ee/kit/257/chapter/14484
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.7
Topics ET: matemaatika
Topics RU: математика, лесной, воробей, словарная, разминка, вопросы
Topics EN: mathematics
Headings: ЛЕСНОЙ ВОРОБЕЙ; Словарная разминка; Вопросы и задания

## ЕЁ ПИТОМЦЫ
URL: https://www.opiq.ee/kit/257/chapter/14485
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика, питомцы, вопросы, пословица
Topics EN: mathematics
Headings: ЕЁ ПИТОМЦЫ; Вопросы и задания; Э-ЗАДАНИЕ 14; Пословица

## ВЕРИШЬ – НЕ ВЕРИШЬ
URL: https://www.opiq.ee/kit/257/chapter/14486
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 3.9
Topics ET: matemaatika
Topics RU: математика, веришь, вопросы
Topics EN: mathematics
Headings: ВЕРИШЬ – НЕ ВЕРИШЬ; Вопросы и задания; Э-ЗАДАНИЕ 15

## РОДНЯ
URL: https://www.opiq.ee/kit/257/chapter/14490
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, родня
Topics EN: mathematics
Headings: РОДНЯ

## ПИЛЛЕ-РИЙН
URL: https://www.opiq.ee/kit/257/chapter/14491
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, пилле, рийн, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ПИЛЛЕ-РИЙН; Словарная разминка; Вопросы и задания; Пословица

## ТВОЯ РАБОТА
URL: https://www.opiq.ee/kit/257/chapter/14492
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, твоя, работа, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ТВОЯ РАБОТА; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 17; Пословица

## ЕМЕЛИНА НЕДЕЛЯ
URL: https://www.opiq.ee/kit/257/chapter/14488
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, емелина, неделя, словарная, разминка, вопросы, пословицы
Topics EN: mathematics
Headings: ЕМЕЛИНА НЕДЕЛЯ; Словарная разминка; Вопросы и задания; Пословицы

## СКАЗКА О ТОМ, ЧТО НАДО ДАРИТЬ
URL: https://www.opiq.ee/kit/257/chapter/14493
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, сказка, надо, дарить, словарная, разминка, вопросы
Topics EN: mathematics
Headings: СКАЗКА О ТОМ, ЧТО НАДО ДАРИТЬ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 18; Э-ЗАДАНИЕ 19

## ПОДАРОК
URL: https://www.opiq.ee/kit/257/chapter/14489
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, подарок, вопросы, пословица
Topics EN: mathematics
Headings: ПОДАРОК; Вопросы и задания; Пословица

## УРОК ДРУЖБЫ
URL: https://www.opiq.ee/kit/257/chapter/14494
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика, урок, дружбы, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: УРОК ДРУЖБЫ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 20; Э-ЗАДАНИЕ 21; Пословица

## К НАМ ВЕСНА ШАГАЕТ...
URL: https://www.opiq.ee/kit/257/chapter/14496
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, шагает, вопросы
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: К НАМ ВЕСНА ШАГАЕТ...; Вопросы и задания

## ЖУК НА НИТОЧКЕ
URL: https://www.opiq.ee/kit/257/chapter/14504
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.10
Topics ET: matemaatika
Topics RU: математика, ниточке, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ЖУК НА НИТОЧКЕ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 25; Пословица

## НАЗОВИ ВЕСЕННИЕ МЕСЯЦЫ
URL: https://www.opiq.ee/kit/257/chapter/14497
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, назови, весенние, месяцы, загадка
Topics EN: mathematics
Headings: НАЗОВИ ВЕСЕННИЕ МЕСЯЦЫ; загадка 9; загадка 10; загадка 11

## ВЕСНА КРАСНА
URL: https://www.opiq.ee/kit/257/chapter/14498
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, красна, словарная, разминка, вопросы, пословица
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: ВЕСНА КРАСНА; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 22; Пословица

## УТРЕННИЕ ЛУЧИ
URL: https://www.opiq.ee/kit/257/chapter/14495
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, утренние, лучи, словарная, разминка, вопросы
Topics EN: mathematics
Headings: УТРЕННИЕ ЛУЧИ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 23

## ЗАГАДКА
URL: https://www.opiq.ee/kit/257/chapter/14499
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.5
Topics ET: matemaatika
Topics RU: математика, загадка, пословица
Topics EN: mathematics
Headings: ЗАГАДКА; загадка 12; Пословица

## АПРЕЛЬ
URL: https://www.opiq.ee/kit/257/chapter/14500
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.6
Topics ET: matemaatika
Topics RU: математика, апрель, вопросы
Topics EN: mathematics
Headings: АПРЕЛЬ; Вопросы и задания

## ЗАГАДКА
URL: https://www.opiq.ee/kit/257/chapter/14501
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.7
Topics ET: matemaatika
Topics RU: математика, загадка
Topics EN: mathematics
Headings: ЗАГАДКА; загадка 13

## МЕДВЕДЬ И СОЛНЦЕ
URL: https://www.opiq.ee/kit/257/chapter/14502
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.8
Topics ET: matemaatika
Topics RU: математика, медведь, солнце, словарная, разминка, вопросы, пословицы
Topics EN: mathematics
Headings: МЕДВЕДЬ И СОЛНЦЕ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 24; Пословицы

## ЗАГАДКА
URL: https://www.opiq.ee/kit/257/chapter/14503
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 5.9
Topics ET: matemaatika
Topics RU: математика, загадка
Topics EN: mathematics
Headings: ЗАГАДКА; загадка 14

## Я УЧУ СТИХОТВОРЕНЬЕ…
URL: https://www.opiq.ee/kit/257/chapter/14505
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, стихотворенье, пословица
Topics EN: mathematics
Headings: Я УЧУ СТИХОТВОРЕНЬЕ…; Пословица

## ЦИРК ШАПИТО
URL: https://www.opiq.ee/kit/257/chapter/14514
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.10
Topics ET: matemaatika
Topics RU: математика, цирк, шапито, словарная, разминка, вопросы
Topics EN: mathematics
Headings: ЦИРК ШАПИТО; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 29

## БОЛЬШИЕ УШИ
URL: https://www.opiq.ee/kit/257/chapter/14515
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.11
Topics ET: matemaatika
Topics RU: математика, большие, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: БОЛЬШИЕ УШИ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 30; Пословица

## ПЕТУШКИ
URL: https://www.opiq.ee/kit/257/chapter/14506
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, петушки
Topics EN: mathematics
Headings: ПЕТУШКИ

## МЫ ДЕЖУРИМ
URL: https://www.opiq.ee/kit/257/chapter/14507
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, дежурим
Topics EN: mathematics
Headings: МЫ ДЕЖУРИМ

## КАНИКУЛЫ
URL: https://www.opiq.ee/kit/257/chapter/14508
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.4
Topics ET: matemaatika
Topics RU: математика, каникулы
Topics EN: mathematics
Headings: КАНИКУЛЫ

## КИСЛЫЕ СТИХИ
URL: https://www.opiq.ee/kit/257/chapter/14509
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.5
Topics ET: matemaatika
Topics RU: математика, кислые, стихи, вопросы, пословица
Topics EN: mathematics
Headings: КИСЛЫЕ СТИХИ; Вопросы и задания; Пословица

## МУХА-ЧИСТЮХА
URL: https://www.opiq.ee/kit/257/chapter/14510
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.6
Topics ET: matemaatika
Topics RU: математика, муха, чистюха
Topics EN: mathematics
Headings: МУХА-ЧИСТЮХА

## КТО НА КОГО ПОХОЖ
URL: https://www.opiq.ee/kit/257/chapter/14511
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.7
Topics ET: matemaatika
Topics RU: математика, кого, похож, словарная, разминка, вопросы
Topics EN: mathematics
Headings: КТО НА КОГО ПОХОЖ; Словарная разминка; Вопросы и задания

## ГРЕЦКИЕ СТИХИ
URL: https://www.opiq.ee/kit/257/chapter/14512
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.8
Topics ET: matemaatika
Topics RU: математика, грецкие, стихи, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ГРЕЦКИЕ СТИХИ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 26; Пословица

## КЛОУН
URL: https://www.opiq.ee/kit/257/chapter/14513
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 6.9
Topics ET: matemaatika
Topics RU: математика, клоун, словарная, разминка, вопросы
Topics EN: mathematics
Headings: КЛОУН; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 27; Э-ЗАДАНИЕ 28

## СОЛНЫШКО
URL: https://www.opiq.ee/kit/257/chapter/14516
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.1
Topics ET: matemaatika
Topics RU: математика, солнышко, вопросы
Topics EN: mathematics
Headings: СОЛНЫШКО; Вопросы и задания

## ЗАГАДКА
URL: https://www.opiq.ee/kit/257/chapter/14525
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.10
Topics ET: matemaatika
Topics RU: математика, загадка
Topics EN: mathematics
Headings: ЗАГАДКА; загадка 15

## СТРЕКОЗА И ЗЕРКАЛО
URL: https://www.opiq.ee/kit/257/chapter/14526
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.11
Topics ET: matemaatika
Topics RU: математика, стрекоза, зеркало, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: СТРЕКОЗА И ЗЕРКАЛО; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 37; Пословица

## РАДУГА
URL: https://www.opiq.ee/kit/257/chapter/14517
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.2
Topics ET: matemaatika
Topics RU: математика, радуга, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: РАДУГА; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 31; Пословица

## ЗОНТИКИ
URL: https://www.opiq.ee/kit/257/chapter/14518
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.3
Topics ET: matemaatika
Topics RU: математика, зонтики, вопросы
Topics EN: mathematics
Headings: ЗОНТИКИ; Вопросы и задания

## ОДУВАНЧИК
URL: https://www.opiq.ee/kit/257/chapter/14519
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.4
Topics ET: matemaatika
Topics RU: математика, одуванчик, вопросы
Topics EN: mathematics
Headings: ОДУВАНЧИК; Вопросы и задания; Э-ЗАДАНИЕ 32

## ОДУВАНЧИК И ДОЖДЬ
URL: https://www.opiq.ee/kit/257/chapter/14520
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.5
Topics ET: matemaatika
Topics RU: математика, одуванчик, дождь, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ОДУВАНЧИК И ДОЖДЬ; Словарная разминка; Вопросы и задания; Пословица

## ИЗ ЧЕГО ПЕЧЁТСЯ ХЛЕБ…
URL: https://www.opiq.ee/kit/257/chapter/14521
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.6
Topics ET: matemaatika
Topics RU: математика, чего, хлеб
Topics EN: mathematics
Headings: ИЗ ЧЕГО ПЕЧЁТСЯ ХЛЕБ…

## ВСЁ ЗДЕСЬ
URL: https://www.opiq.ee/kit/257/chapter/14522
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.7
Topics ET: matemaatika
Topics RU: математика, здесь, вопросы
Topics EN: mathematics
Headings: ВСЁ ЗДЕСЬ; Вопросы и задания; Э-ЗАДАНИЕ 33

## ЖИВОТ-ЖИВОТОК
URL: https://www.opiq.ee/kit/257/chapter/14523
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.8
Topics ET: matemaatika
Topics RU: математика, живот, животок, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ЖИВОТ-ЖИВОТОК; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 34; Э-ЗАДАНИЕ 35; Пословица

## САМЫЕ, САМЫЕ…
URL: https://www.opiq.ee/kit/257/chapter/14524
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 7.9
Topics ET: matemaatika
Topics RU: математика, самые, словарная, разминка, вопросы
Topics EN: mathematics
Headings: САМЫЕ, САМЫЕ…; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 36

## ПЕТУШОК И БОБОВОЕ ЗЁРНЫШКО
URL: https://www.opiq.ee/kit/257/chapter/14527
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 8.1
Topics ET: matemaatika
Topics RU: математика, петушок, бобовое, рнышко, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ПЕТУШОК И БОБОВОЕ ЗЁРНЫШКО; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 38; Пословица

## ВОЛК И ОЛЕНЬ
URL: https://www.opiq.ee/kit/257/chapter/14528
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 8.2
Topics ET: matemaatika
Topics RU: математика, волк, олень, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ВОЛК И ОЛЕНЬ; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 39; Пословица

## АБРИКОС В ЛЕСУ
URL: https://www.opiq.ee/kit/257/chapter/14529
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 8.3
Topics ET: matemaatika
Topics RU: математика, абрикос, лесу, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: АБРИКОС В ЛЕСУ; Словарная разминка; Вопросы и задания; Пословица

## ДРАКОН КОМОДО
URL: https://www.opiq.ee/kit/257/chapter/14530
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 8.4
Topics ET: matemaatika
Topics RU: математика, дракон, комодо, словарная, разминка, вопросы, пословица
Topics EN: mathematics
Headings: ДРАКОН КОМОДО; Словарная разминка; Вопросы и задания; Э-ЗАДАНИЕ 40; Э-ЗАДАНИЕ 41; Пословица

## В РЮКЗАЧКЕ У СВЕТЛЯЧКА
URL: https://www.opiq.ee/kit/257/chapter/14531
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.1
Topics ET: matemaatika
Topics RU: математика, рюкзачке, светлячка
Topics EN: mathematics
Headings: В РЮКЗАЧКЕ У СВЕТЛЯЧКА

## СКУЧАТЬ НЕКОГДА
URL: https://www.opiq.ee/kit/257/chapter/14540
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.10
Topics ET: matemaatika
Topics RU: математика, скучать, некогда
Topics EN: mathematics
Headings: СКУЧАТЬ НЕКОГДА

## ОДИН ЗА ВСЕХ, А ВСЕ ЗА ОДНОГО
URL: https://www.opiq.ee/kit/257/chapter/14541
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.11
Topics ET: matemaatika
Topics RU: математика, один, всех, одного
Topics EN: mathematics
Headings: ОДИН ЗА ВСЕХ, А ВСЕ ЗА ОДНОГО

## НЕ ДРАЗНИТЕ СОБАК
URL: https://www.opiq.ee/kit/257/chapter/14542
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.12
Topics ET: matemaatika
Topics RU: математика, дразните, собак
Topics EN: mathematics
Headings: НЕ ДРАЗНИТЕ СОБАК

## ВЕТБОЛ
URL: https://www.opiq.ee/kit/257/chapter/14543
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.13
Topics ET: matemaatika
Topics RU: математика, ветбол
Topics EN: mathematics
Headings: ВЕТБОЛ

## КАЧЕЛИ
URL: https://www.opiq.ee/kit/257/chapter/14544
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.14
Topics ET: matemaatika
Topics RU: математика, качели
Topics EN: mathematics
Headings: КАЧЕЛИ

## ПРО ВСЁ НА СВЕТЕ
URL: https://www.opiq.ee/kit/257/chapter/14532
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.2
Topics ET: matemaatika
Topics RU: математика, свете
Topics EN: mathematics
Headings: ПРО ВСЁ НА СВЕТЕ

## РОМАШКИ В ЯНВАРЕ
URL: https://www.opiq.ee/kit/257/chapter/14533
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.3
Topics ET: matemaatika
Topics RU: математика, ромашки, январе
Topics EN: mathematics
Headings: РОМАШКИ В ЯНВАРЕ

## БЕЛЁК
URL: https://www.opiq.ee/kit/257/chapter/14534
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: БЕЛЁК

## НА ОДНОМ БРЕВНЕ
URL: https://www.opiq.ee/kit/257/chapter/14535
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.5
Topics ET: matemaatika
Topics RU: математика, одном, бревне
Topics EN: mathematics
Headings: НА ОДНОМ БРЕВНЕ

## УЛИТКА И ЕЁ ДРУГ ПАУЧОК
URL: https://www.opiq.ee/kit/257/chapter/14536
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.6
Topics ET: matemaatika
Topics RU: математика, улитка, друг, паучок
Topics EN: mathematics
Headings: УЛИТКА И ЕЁ ДРУГ ПАУЧОК

## ВОЛШЕБНАЯ ТРАВКА ЗВЕРОБОЙ
URL: https://www.opiq.ee/kit/257/chapter/14537
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.7
Topics ET: matemaatika
Topics RU: математика, волшебная, травка, зверобой
Topics EN: mathematics
Headings: ВОЛШЕБНАЯ ТРАВКА ЗВЕРОБОЙ

## ЗАБЫВЧИВЫЙ ВОРОБЫШЕК
URL: https://www.opiq.ee/kit/257/chapter/14538
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.8
Topics ET: matemaatika
Topics RU: математика, забывчивый, воробышек
Topics EN: mathematics
Headings: ЗАБЫВЧИВЫЙ ВОРОБЫШЕК

## ЖИЛ НА СВЕТЕ СЛОНЁНОК
URL: https://www.opiq.ee/kit/257/chapter/14539
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: светлячок_._чтение_для_1_клacca
Chapter ID: 9.9
Topics ET: matemaatika
Topics RU: математика, свете, слон
Topics EN: mathematics
Headings: ЖИЛ НА СВЕТЕ СЛОНЁНОК
