## Eesti keele õpik 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/232
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 1
Topics ET: matemaatika, eesti, keele, õpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Eesti keele õpik 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/232
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 152
Topics ET: matemaatika, eesti, keele, õpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Laura ja Siimu suvi
URL: https://www.opiq.ee/kit/232/chapter/15698
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 1.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, laura, siimu, suvepuhkus, leia, jutusta, mida, sina, suvel
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Laura ja Siimu suvi; Suvepuhkus; Siimu suvi; Laura suvi; Leia; Jutusta; Mida sina suvel tegid?

## Plaanid uueks õppeaastaks
URL: https://www.opiq.ee/kit/232/chapter/15699
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 1.2
Topics ET: matemaatika, plaanid, uueks, õppeaastaks, lähme, reisima, arutle, jutusta, harjutus, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Plaanid uueks õppeaastaks; Kas lähme reisima?; Arutle; Jutusta; Harjutus 1; Harjutus 2; Rühmatöö

## Loeme tähti ja raamatuid
URL: https://www.opiq.ee/kit/232/chapter/15700
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 1.3
Topics ET: matemaatika, loeme, tähti, raamatuid, raamatul, tühi, arutle, erinevad, raamatud, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Loeme tähti ja raamatuid; Raamatul on aku tühi; Arutle; Erinevad raamatud; Harjutus 1; Tähed ja häälikud; Harjutus 2; Harjutus 3; Uuri ja jutusta

## Arutlustund. Sõprus
URL: https://www.opiq.ee/kit/232/chapter/15701
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 1.4
Topics ET: matemaatika, arutlustund, sõprus, sõpra, tunned, hädas
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Sõprus; Mis on sõprus?; Sõpra tunned hädas

## Üle piiri!
URL: https://www.opiq.ee/kit/232/chapter/16885
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 10.1
Topics ET: matemaatika, piiri, juhtus, lauraga, arutle, kirjuta, lätimaa, vaata, pilti, teadsid
Topics RU: математика
Topics EN: mathematics
Headings: Üle piiri!; Mis juhtus Lauraga?; Arutle; Kirjuta; Lätimaa; Vaata pilti ja arutle; Kas teadsid?; Harjutus 1

## Kirju muinasjutt
URL: https://www.opiq.ee/kit/232/chapter/16886
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 10.2
Topics ET: matemaatika, kirju, muinasjutt, harjutus, arutle, omadussõna, pane, tähele
Topics RU: математика
Topics EN: mathematics
Headings: Kirju muinasjutt; Harjutus 1c; Harjutus 1a; Harjutus 1b; Elu on kirju; Harjutus 2c; Harjutus 2a; Harjutus 2b; Arutle; Loe; Omadussõna; Pane tähele!; Harjutus 3; Harjutus 4; Harjutus 5

## Jänesekapsad
URL: https://www.opiq.ee/kit/232/chapter/16887
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 10.3
Topics ET: matemaatika, jänesekapsad, harjutus, söögu, mind, hunt, need, pole, mitte, hapukapsad
Topics RU: математика
Topics EN: mathematics
Headings: Jänesekapsad; Harjutus 1c; Harjutus 1a; Harjutus 1b; Söögu mind hunt, kui need pole mitte hapukapsad!; Harjutus 2c; Harjutus 2a; Harjutus 2b; Arutle; Jutusta; Kirjuta

## Arutlustund. Miks on vahel hea olla üksi?
URL: https://www.opiq.ee/kit/232/chapter/16888
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 10.4
Topics ET: matemaatika, arutlustund, miks, vahel, olla, üksi, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Miks on vahel hea olla üksi?; Miks on vahel hea olla üksi?; Mis sa arvad?

## Ilon Wikland
URL: https://www.opiq.ee/kit/232/chapter/17225
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 11.1
Topics ET: matemaatika, ilon, wikland, iloni, imedemaal, jutusta, harjutus, wiklandi, elulugu, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Ilon Wikland; Mis on Iloni Imedemaal?; Jutusta; Harjutus 1b; Harjutus 1a; Ilon Wiklandi elulugu; Kirjuta

## Kartulilapsed
URL: https://www.opiq.ee/kit/232/chapter/17226
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 11.2
Topics ET: matemaatika, kartulilapsed, jutusta, harjutus, arutle, asesõna, mõtle, tegutse, edasi, mängi
Topics RU: математика
Topics EN: mathematics
Headings: Kartulilapsed; Jutusta; Harjutus 1b; Harjutus 1a; Harjutus 2b; Harjutus 2a; Arutle; Asesõna; Harjutus 3; Harjutus 4; Harjutus 5; Mõtle ja tegutse edasi; Harjutus 6; Mängi

## Liisbet topib hernetera ninna
URL: https://www.opiq.ee/kit/232/chapter/17227
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 11.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, liisbet, topib, hernetera, ninna, harjutus, võta, välja, arutle, asesõnad
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Liisbet topib hernetera ninna; Harjutus 1d; Harjutus 1a; Harjutus 1b; Harjutus 1c; Võta ta välja!; Harjutus 2c; Harjutus 2a; Harjutus 2b; Arutle; Loe; Asesõnad; Loe ja võrdle; Harjutus 3; Mõtle ja tegutse edasi

## Arutlustund. Uudishimu
URL: https://www.opiq.ee/kit/232/chapter/17228
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 11.4
Topics ET: matemaatika, arutlustund, uudishimu, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Uudishimu; Mis on uudishimu?; Mis sa arvad?

## Nii tehakse Soomet
URL: https://www.opiq.ee/kit/232/chapter/17229
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 12.1
Topics ET: matemaatika, tehakse, soomet, soomemaal, teadsid, arutle, kuula, vasta, küsimustele, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Nii tehakse Soomet; Mis on Soomemaal?; Kas teadsid?; Arutle; Kuula ja vasta küsimustele; Harjutus 1f; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Harjutus 1e; Jutusta; Teedu ja Peedu trikinurk. Nii tehakse Soomet; Kirjuta

## Kohutav palavus
URL: https://www.opiq.ee/kit/232/chapter/17230
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 12.2
Topics ET: matemaatika, kohutav, palavus, harjutus, arutle, tegusõna, pane, tähele, jutusta
Topics RU: математика
Topics EN: mathematics
Headings: Kohutav palavus; Harjutus 1c; Harjutus 1a; Harjutus 1b; Harjutus 2; Arutle; Tegusõna; Pane tähele!; Harjutus 3; Harjutus 4; Jutusta

## Muumioru elanikud
URL: https://www.opiq.ee/kit/232/chapter/17231
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 12.3
Topics ET: matemaatika, muumioru, elanikud, muumipere, arutle, sõbrad, mõtle, tegutse, edasi, joonista
Topics RU: математика
Topics EN: mathematics
Headings: Muumioru elanikud; Muumipere; Arutle; Muumipere sõbrad; Mõtle ja tegutse edasi; Joonista

## Arutlustund. Poiste ja tüdrukute tööd
URL: https://www.opiq.ee/kit/232/chapter/17232
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 12.4
Topics ET: matemaatika, arutlustund, poiste, tüdrukute, tööd, olemas, harrastused, ning, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Poiste ja tüdrukute tööd; Kas on olemas poiste tööd ja harrastused ning tüdrukute tööd ja harrastused?; Mis sa arvad?

## Lapsesuu ei valeta
URL: https://www.opiq.ee/kit/232/chapter/17400
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 13.1
Topics ET: matemaatika, lapsesuu, valeta, milline, lapsepõlvemaa, jutusta, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Lapsesuu ei valeta; Milline on lapsepõlvemaa?; Jutusta; Arutle

## Vanade aegade lapsed
URL: https://www.opiq.ee/kit/232/chapter/17401
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 13.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, vanade, aegade, lapsed, jube, harjutus, parem, arutle, jutusta, olevik
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Vanade aegade lapsed; Jube elu; Harjutus 1c; Harjutus 1a; Harjutus 1b; Parem elu; Arutle; Jutusta; Olevik ja minevik; Pane tähele!; Loe ja võrdle; Harjutus 2b; Harjutus 2a

## Ahvipoeg, kes ei tahtnud areneda
URL: https://www.opiq.ee/kit/232/chapter/17402
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 13.3
Topics ET: matemaatika, ahvipoeg, tahtnud, areneda, harjutus, arutle, ahvi, trahvimine, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Ahvipoeg, kes ei tahtnud areneda; Harjutus 1b; Harjutus 1a; Arutle; Ahvi trahvimine; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3; Kirjuta

## Arutlustund. Miks on hea olla laps?
URL: https://www.opiq.ee/kit/232/chapter/17403
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 13.4
Topics ET: matemaatika, arutlustund, miks, olla, laps, täiskasvanu, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Miks on hea olla laps?; Miks on hea olla laps?; Miks on hea olla täiskasvanu?; Mis sa arvad?

## Päkapikumaa
URL: https://www.opiq.ee/kit/232/chapter/17404
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 14.1
Topics ET: matemaatika, päkapikumaa, päkapikumaal, harjutus, jutusta, arutle, jõulusoovid, joonista
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikumaa; Mis on Päkapikumaal?; Harjutus 1b; Harjutus 1a; Jutusta; Arutle; Jõulusoovid; Harjutus 2; Joonista

## Päkapikk ja merisiga I
URL: https://www.opiq.ee/kit/232/chapter/17405
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 14.2
Topics ET: matemaatika, päkapikk, merisiga, esimene, kohtumine, harjutus, arutle, kirjuta, uued, sõbrad
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikk ja merisiga I; Esimene kohtumine; Harjutus 1b; Harjutus 1a; Arutle; Kirjuta; Uued sõbrad; Harjutus 2; Liitsõna; Tuleta meelde!; Harjutus 3; Harjutus 4; Harjutus 4b; Harjutus 4a; Harjutus 5; Leia

## Päkapikk ja merisiga II
URL: https://www.opiq.ee/kit/232/chapter/17406
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 14.3
Topics ET: matemaatika, päkapikk, merisiga, puhkus, harjutus, arutle, leia, hommikune, avastus
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikk ja merisiga II; Puhkus; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Leia; Hommikune avastus

## Arutlustund. Mis on traditsioon?
URL: https://www.opiq.ee/kit/232/chapter/17407
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 14.4
Topics ET: matemaatika, arutlustund, traditsioon, millised, tähtpäevad, traditsioonid, sinu, jaoks, tähtsad, miks
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Mis on traditsioon?; Mis on traditsioon?; Millised tähtpäevad ja traditsioonid on sinu jaoks tähtsad? Miks?

## Jõulutrall
URL: https://www.opiq.ee/kit/232/chapter/17408
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 15.1
Topics ET: matemaatika, jõulutrall, jõuluvana, lapsed, arutle, harjutus, luuletuste, lugemise, võistlus
Topics RU: математика
Topics EN: mathematics
Headings: Jõulutrall; Jõuluvana lapsed; Arutle; Harjutus 1; Luuletuste lugemise võistlus

## Kiri vanaemale
URL: https://www.opiq.ee/kit/232/chapter/17409
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 15.2
Topics ET: matemaatika, kiri, vanaemale, kallis, vanaema, harjutus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kiri vanaemale; Kallis vanaema!; Harjutus 1b; Harjutus 1a; Arutle

## Varese jõulud
URL: https://www.opiq.ee/kit/232/chapter/17410
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 15.3
Topics ET: matemaatika, varese, jõulud, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Varese jõulud; Rühmatöö

## Spordimees või tordimees?
URL: https://www.opiq.ee/kit/232/chapter/17411
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 15.4
Topics ET: matemaatika, spordimees, tordimees, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Spordimees või tordimees?; Arutle

## Klassi tuleb uus õpilane
URL: https://www.opiq.ee/kit/232/chapter/18198
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 16.1
Topics ET: matemaatika, klassi, tuleb, õpilane, pärast, vaheaega, harjutus, arutle, jutusta
Topics RU: математика
Topics EN: mathematics
Headings: Klassi tuleb uus õpilane; Pärast vaheaega; Harjutus 1c; Harjutus 1a; Harjutus 1b; Harjutus 2c; Harjutus 2a; Harjutus 2b; Arutle; Jutusta

## Teise poolaasta reisiplaanid
URL: https://www.opiq.ee/kit/232/chapter/18199
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 16.2
Topics ET: matemaatika, teise, poolaasta, reisiplaanid, esimese, sihtkohad, jutusta, kuhu, poolaastal, reisida
Topics RU: математика
Topics EN: mathematics
Headings: Teise poolaasta reisiplaanid; Esimese poolaasta sihtkohad; Jutusta; Kuhu sel poolaastal reisida?; Arutle

## Kamapallimaa
URL: https://www.opiq.ee/kit/232/chapter/18200
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 16.3
Topics ET: matemaatika, kamapallimaa, harjutus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kamapallimaa; Harjutus 1; Arutle; Loe

## Arutlustund. Võõrad inimesed
URL: https://www.opiq.ee/kit/232/chapter/18201
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 16.4
Topics ET: matemaatika, arutlustund, võõrad, inimesed, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Võõrad inimesed; Võõrad inimesed; Mis sa arvad?

## Et head haldjad sind hoiaksid I
URL: https://www.opiq.ee/kit/232/chapter/18202
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 17.1
Topics ET: matemaatika, head, haldjad, sind, hoiaksid, harjutus, arutle, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Et head haldjad sind hoiaksid I; Et head haldjad sind hoiaksid; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Mõtle ja tegutse edasi; Harjutus 2

## Et head haldjad sind hoiaksid II
URL: https://www.opiq.ee/kit/232/chapter/18203
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 17.2
Topics ET: matemaatika, head, haldjad, sind, hoiaksid, haige, harjutus, arutle, kuum, meega
Topics RU: математика
Topics EN: mathematics
Headings: Et head haldjad sind hoiaksid II; Haige isa; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Kuum tee meega; Harjutus 2b; Harjutus 2a; Harjutus 3d; Harjutus 3a; Harjutus 3b; Harjutus 3c; Sõnaliigid; Uuri; Harjutus 5; Harjutus 4; Harjutus 6

## Et head haldjad sind hoiaksid III
URL: https://www.opiq.ee/kit/232/chapter/18204
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 17.3
Topics ET: matemaatika, head, haldjad, sind, hoiaksid, mitu, tabletti, harjutus, arutle, võimas
Topics RU: математика
Topics EN: mathematics
Headings: Et head haldjad sind hoiaksid III; Mitu tabletti?; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Võimas möire; Harjutus 2b; Harjutus 2a; Pisut nurinat ja oigamist; Jutusta; Mõtle ja tegutse edasi; Harjutus 3

## Arutlustund. Kodutunne
URL: https://www.opiq.ee/kit/232/chapter/18205
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 17.4
Topics ET: matemaatika, arutlustund, kodutunne, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Kodutunne; Kodutunne; Mis sa arvad?

## Vana mõis
URL: https://www.opiq.ee/kit/232/chapter/18461
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 18.1
Topics ET: matemaatika, vana, mõis, koolimälestus, harjutus, arutle, mõisad, eestimaal, saare, mõisa
Topics RU: математика
Topics EN: mathematics
Headings: Vana mõis; Koolimälestus; Harjutus 1; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Mõisad Eestimaal; Saare mõisa legend; Uuri. Rühmatöö; Mõisakool

## Mina küll ei karda! I
URL: https://www.opiq.ee/kit/232/chapter/18462
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 18.2
Topics ET: matemaatika, mina, küll, karda, tõeliselt, õudne, võistlus, harjutus, kokkulepe, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Mina küll ei karda! I; Tõeliselt õudne võistlus; Harjutus 1b; Harjutus 1a; Kokkulepe; Harjutus 2b; Harjutus 2a; Arutle; H-täht sõna alguses; Tuleta meelde!; Leia; Harjutus 3

## Mina küll ei karda! II
URL: https://www.opiq.ee/kit/232/chapter/18463
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 18.3
Topics ET: matemaatika, mina, küll, karda, kohtumine, mõisapargis, harjutus, sissepääs, õudsesse, mõisa
Topics RU: математика
Topics EN: mathematics
Headings: Mina küll ei karda! II; Kohtumine mõisapargis; Harjutus 1c; Harjutus 1a; Harjutus 1b; Sissepääs õudsesse mõisa; Arutle; Mõtle ja tegutse edasi; Harjutus 2; Kirjuta

## Arutlustund. Julgus
URL: https://www.opiq.ee/kit/232/chapter/18464
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 18.4
Topics ET: matemaatika, arutlustund, julgus, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Julgus; Mis on julgus?; Mis sa arvad?

## Uus õpilane
URL: https://www.opiq.ee/kit/232/chapter/18465
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 19.1
Topics ET: matemaatika, õpilane, nukk, peeter, uues, klassis, ennusta, harjutus, arutle, teisi
Topics RU: математика
Topics EN: mathematics
Headings: Uus õpilane; Nukk Peeter uues klassis; Ennusta; Harjutus 1b; Harjutus 1a; Harjutus 2; Arutle; Teisi ei tohi halvustada; Harjutus 3c; Harjutus 3a; Harjutus 3b; Harjutus 4; Harjutus 5; Kus saab veel õppida?; Loe ja uuri

## Nunnukonkurss I
URL: https://www.opiq.ee/kit/232/chapter/18466
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 19.2
Topics ET: matemaatika, nunnukonkurss, sobib, nunnukonkursile, harjutus, võõrsõnad, pane, tähele
Topics RU: математика
Topics EN: mathematics
Headings: Nunnukonkurss I; Mis sobib nunnukonkursile?; Harjutus 1b; Harjutus 1a; Harjutus 2d; Harjutus 2a; Harjutus 2b; Harjutus 2c; Võõrsõnad; Pane tähele!; Harjutus 3; Harjutus 4

## Nunnukonkurss II
URL: https://www.opiq.ee/kit/232/chapter/18467
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 19.3
Topics ET: matemaatika, nunnukonkurss, tühjad, kõhud, harjutus, arutle, vaimukas, eksponaat, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Nunnukonkurss II; Tühjad kõhud; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Vaimukas eksponaat; Harjutus 2c; Harjutus 2a; Harjutus 2b; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 3b; Harjutus 3a

## Arutlustund. Mõtted
URL: https://www.opiq.ee/kit/232/chapter/18468
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 19.4
Topics ET: matemaatika, arutlustund, mõtted, kust, tulevad, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Mõtted; Kust mõtted tulevad?; Mis sa arvad?

## Väike Prints I
URL: https://www.opiq.ee/kit/232/chapter/15702
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 2.1
Topics ET: matemaatika, väike, prints, sahara, kõrbes, harjutus, päris, pisike, planeet
Topics RU: математика
Topics EN: mathematics
Headings: Väike Prints I; Sahara kõrbes; Harjutus 1b; Harjutus 1a; Üks päris pisike planeet; Harjutus 2b; Harjutus 2a; Harjutus 3

## Väike prints II
URL: https://www.opiq.ee/kit/232/chapter/15703
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 2.2
Topics ET: matemaatika, väike, prints, taltsutamata, rebane, harjutus, arutle, ainult, südamega, näed
Topics RU: математика
Topics EN: mathematics
Headings: Väike prints II; Taltsutamata rebane; Harjutus 1b; Harjutus 1a; Arutle; Ainult südamega näed hästi; Harjutus 2b; Harjutus 2a; Harjutus 3c; Harjutus 3a; Harjutus 3b

## Häälikurühmad
URL: https://www.opiq.ee/kit/232/chapter/15704
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 2.3
Topics ET: matemaatika, häälikurühmad, süda, harjutus, täis, kaashäälikud, tuleta, meelde, harjuta, leia
Topics RU: математика
Topics EN: mathematics
Headings: Häälikurühmad; Süda; Harjutus 1; Harjutus 2; Täis- ja kaashäälikud; Tuleta meelde!; Harjuta; Harjutus 3; Harjutus 4; Harjutus 5b; Harjutus 5a; Leia

## Arutlustund. Miks on vaja mõelda?
URL: https://www.opiq.ee/kit/232/chapter/15705
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 2.4
Topics ET: matemaatika, arutlustund, miks, vaja, mõelda
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Miks on vaja mõelda?; Miks on vaja mõelda?

## Üks küsimus filmitegijale
URL: https://www.opiq.ee/kit/232/chapter/18859
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 20.1
Topics ET: matemaatika, küsimus, filmitegijale, intervjuu, pärtel, talliga, harjutus, arutle, lauselõpumärk, tuleta
Topics RU: математика
Topics EN: mathematics
Headings: Üks küsimus filmitegijale; Intervjuu Pärtel Talliga; Harjutus 1c; Harjutus 1a; Harjutus 1b; Harjutus 2; Harjutus 2d; Harjutus 2a; Harjutus 2b; Harjutus 2c; Arutle; Lauselõpumärk; Tuleta meelde!; Leia; Harjutus 3b; Harjutus 3a; Mõtle ja tegutse edasi; Multifilm „Porgand!“; Meisterda; Harjutus 4

## Siil praeb sitikat
URL: https://www.opiq.ee/kit/232/chapter/18860
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 20.2
Topics ET: matemaatika, siil, praeb, sitikat, näljane, harjutus, arutle, kuidas, praadida, kõrbenud
Topics RU: математика
Topics EN: mathematics
Headings: Siil praeb sitikat; Näljane siil; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Kuidas praadida sitikat?; Harjutus 2c; Harjutus 2a; Harjutus 2b; Kõrbenud sitikas; Harjutus 3b; Harjutus 3a; Mõtle ja tegutse edasi; Harjutus 4; Rühmatöö

## Kirp tuleb kinost
URL: https://www.opiq.ee/kit/232/chapter/18861
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 20.3
Topics ET: matemaatika, kirp, tuleb, kinost, kingi, mulle, arutle, jutusta
Topics RU: математика
Topics EN: mathematics
Headings: Kirp tuleb kinost; Kingi mulle; Arutle; Jutusta

## Arutlustund. Tarkus
URL: https://www.opiq.ee/kit/232/chapter/18862
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 20.4
Topics ET: matemaatika, arutlustund, tarkus, elutarkus, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Tarkus; Mis on tarkus?; Mis on elutarkus?; Mis sa arvad?

## Raeapteek
URL: https://www.opiq.ee/kit/232/chapter/18863
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 21.1
Topics ET: matemaatika, raeapteek, eesti, vanim, apteek, arutle, leia
Topics RU: математика
Topics EN: mathematics
Headings: Raeapteek; Eesti vanim apteek; Arutle; Leia; Loe

## Apteek I
URL: https://www.opiq.ee/kit/232/chapter/18864
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 21.2
Topics ET: matemaatika, apteek, tõeliselt, vahva, ravim, harjutus, arutle, leia, loetelu, lauses
Topics RU: математика
Topics EN: mathematics
Headings: Apteek I; Tõeliselt vahva ravim; Harjutus 1b; Harjutus 1a; Arutle; Leia; Loetelu lauses; Pane tähele!; Harjutus 2; Jutusta; Harjutus 3

## Apteek II
URL: https://www.opiq.ee/kit/232/chapter/18865
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 21.3
Topics ET: matemaatika, apteek, parim, kõhuvalurohi, harjutus, arutle, mürgine, mitte, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Apteek II; Parim kõhuvalurohi; Harjutus 1b; Harjutus 1a; Arutle; Mürgine või mitte?; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3

## Arutlustund. Tervis
URL: https://www.opiq.ee/kit/232/chapter/18866
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 21.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, arutlustund, miks, tervist, vaja, arvad
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Arutlustund. Tervis; Miks on tervist vaja?; Mis sa arvad?

## Kuidas maailm tekkis?
URL: https://www.opiq.ee/kit/232/chapter/18969
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 22.1
Topics ET: matemaatika, kuidas, maailm, tekkis, maailma, loomine, teadlased, arvavad, harjutus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas maailm tekkis?; Maailma loomine; Teadlased arvavad; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Vanad rahvad räägivad; Harjutus 2; Sumerite uskumus; Harjutus 3c; Harjutus 3a; Harjutus 3b; Kirjuta; Mõtle ja tegutse edasi; Unistustel on imeline võime teoks saada!

## Kiigelaud I
URL: https://www.opiq.ee/kit/232/chapter/18970
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 22.2
Topics ET: matemaatika, kiigelaud, tühi, kiik, harjutus, arutle, ootamatu, kiikuja, kirjuta, leia
Topics RU: математика
Topics EN: mathematics
Headings: Kiigelaud I; Tühi kiik; Harjutus 1b; Harjutus 1a; Arutle; Harjutus 2; Ootamatu kiikuja; Harjutus 3; Harjutus 4; Kirjuta; Leia; Koma; Pane tähele!; Jutusta; Harjutus 5; Harjutus 6

## Kiigelaud II
URL: https://www.opiq.ee/kit/232/chapter/18971
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 22.3
Topics ET: matemaatika, kiigelaud, kiigepaariline, harjutus, arutle, kirjuta, leia, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Kiigelaud II; Kiigepaariline; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Kirjuta; Leia; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Arutlustund. Maailm
URL: https://www.opiq.ee/kit/232/chapter/18972
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 22.4
Topics ET: matemaatika, arutlustund, maailm, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Maailm; Maailm; Mis sa arvad?

## Eesti suurkujud
URL: https://www.opiq.ee/kit/232/chapter/18973
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 23.1
Topics ET: matemaatika, eesti, suurkujud, meie, kangelased, arutle, konstantin, päts, johan, laidoner
Topics RU: математика
Topics EN: mathematics
Headings: Eesti suurkujud; Meie kangelased; Loe ja arutle; Konstantin Päts; Johan Laidoner; Lennart Meri; Lydia Koidula

## Eesti lipp tõuseb koos päikesega
URL: https://www.opiq.ee/kit/232/chapter/18974
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 23.2
Topics ET: matemaatika, eesti, lipp, tõuseb, koos, päikesega, pika, hermanni, tornis, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Eesti lipp tõuseb koos päikesega; Eesti lipp Pika Hermanni tornis; Harjutus 1b; Harjutus 1a; Arutle; Leia; Komata; Pane tähele!; Harjutus 2; Harjutus 3b; Harjutus 3a; Jutusta; Kirjuta

## Laul Eestimaast
URL: https://www.opiq.ee/kit/232/chapter/18975
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 23.3
Topics ET: matemaatika, laul, eestimaast, harjutus, arutle, joonista, rühmatöö, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Laul Eestimaast; Harjutus 1b; Harjutus 1a; Arutle; Joonista; Rühmatöö; Mõtle ja tegutse edasi; Harjutus 2b; Harjutus 2a; Harjutus 3

## Arutlustund. Riik
URL: https://www.opiq.ee/kit/232/chapter/18976
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 23.4
Topics ET: matemaatika, arutlustund, riik, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Riik; Riik; Mis sa arvad?

## Kuidas käituda tulekahju korral?
URL: https://www.opiq.ee/kit/232/chapter/19106
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 24.1
Topics ET: matemaatika, kuidas, käituda, tulekahju, korral, tuleohutus, meeles, päästja, varustus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas käituda tulekahju korral?; Tuleohutus; Pea meeles!; Päästja varustus; Arutle; Tuletõrje ajalugu Eestis; Pane tähele!; Harjutus 1c; Harjutus 1a; Harjutus 1b; Buratino ja tulekahju; Harjutus 2e; Harjutus 2a; Harjutus 2b; Harjutus 2c; Harjutus 2d

## Teos, mis räägib teo teost
URL: https://www.opiq.ee/kit/232/chapter/19107
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 24.2
Topics ET: matemaatika, teos, räägib, teost, pane, tähele, arutle, leia, noor, elupäästja
Topics RU: математика
Topics EN: mathematics
Headings: Teos, mis räägib teo teost; Pane tähele!; Arutle; Leia; Noor elupäästja; Noor elupäästja sai tunnustuse nii riigilt kui ka turvafirmalt; Jutusta; Liht- ja liitlause; Harjutus 1; Harjutus 2; Harjutus 3

## Nublu
URL: https://www.opiq.ee/kit/232/chapter/19108
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 24.3
Topics ET: matemaatika, nublu, tuletõrjuja, pane, tähele, harjutus, lapsed, põlevas, majas, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Nublu; Tuletõrjuja Nublu; Pane tähele!; Harjutus 1; Lapsed põlevas majas; Harjutus 2c; Harjutus 2a; Harjutus 2b; Arutle

## Arutlustund. Abi kutsumine
URL: https://www.opiq.ee/kit/232/chapter/19109
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 24.4
Topics ET: matemaatika, arutlustund, kutsumine, millal, kutsuda
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Abi kutsumine; Abi kutsumine; Millal kutsuda abi?

## Hambaarsti juures
URL: https://www.opiq.ee/kit/232/chapter/13198
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 25.1
Topics ET: matemaatika, hambaarsti, juures, poiss, porgand, harjutus, arutle, hambad, kirjuta, miks
Topics RU: математика
Topics EN: mathematics
Headings: Hambaarsti juures; Poiss ja porgand; Harjutus 1b; Harjutus 1a; Arutle; Minu hambad; Kirjuta; Miks tulevad hammastesse augud?; Kellega? Millega? Kelleta? Milleta?; Jäta meelde!; Harjutus 2; Harjutus 3

## Naeratav printsess
URL: https://www.opiq.ee/kit/232/chapter/13199
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 25.2
Topics ET: matemaatika, naeratav, printsess, harjutus, valutavad, hambad, arutle, kirjuta, miks, magus
Topics RU: математика
Topics EN: mathematics
Headings: Naeratav printsess; Harjutus 1c; Harjutus 1a; Harjutus 1b; Harjutus 2; Valutavad hambad; Harjutus 3b; Harjutus 3a; Arutle; Kirjuta; Miks on magus hammastele halb?; Jutusta

## Pille piimahammas
URL: https://www.opiq.ee/kit/232/chapter/13200
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 25.3
Topics ET: matemaatika, pille, piimahammas, kangekaelne, hammas, hambahaldjas, jutusta, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Pille piimahammas; Kangekaelne hammas; Hambahaldjas; Jutusta; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 2

## Arutlustund. Hirm tundmatu ees
URL: https://www.opiq.ee/kit/232/chapter/13201
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 25.4
Topics ET: matemaatika, arutlustund, hirm, tundmatu, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Hirm tundmatu ees; Hirm tundmatu ees; Mis sa arvad?

## Politsei
URL: https://www.opiq.ee/kit/232/chapter/13221
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 26.1
Topics ET: matemaatika, politsei, millal, kutsuda, arutle, harjutus, politseinik, kalle, näita, pille
Topics RU: математика
Topics EN: mathematics
Headings: Politsei; Millal kutsuda abi?; Arutle; Harjutus 1; Harjutus 2; Harjutus 3; Politseinik onu Kalle; Harjutus 4; Näita ...; Pille kiri sulle; Harjutus 5

## Ville I
URL: https://www.opiq.ee/kit/232/chapter/13222
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 26.2
Topics ET: matemaatika, ville, janar, helistab, harjutus, arutle, mõtle, tegutse, edasi, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Ville I; Janar helistab; Harjutus 1c; Harjutus 1a; Harjutus 1b; Ville helistab; Harjutus 2; Arutle; Mõtle ja tegutse edasi; Harjutus 3; Rühmatöö

## Ville II
URL: https://www.opiq.ee/kit/232/chapter/13223
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 26.3
Topics ET: matemaatika, ville, kellani, politsei, töötab, arutle, harjutus, tuleta, meelde, leia
Topics RU: математика
Topics EN: mathematics
Headings: Ville II; Mis kellani politsei töötab?; Arutle; Harjutus 1c; Harjutus 1a; Harjutus 1b; Tuleta meelde!; Leia; Harjuta; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5; Pudrulaua luuletus

## Arutlustund. Süüdi või süütu?
URL: https://www.opiq.ee/kit/232/chapter/13224
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 26.4
Topics ET: matemaatika, arutlustund, süüdi, süütu, mida, teha, oled, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Süüdi või süütu?; Süüdi või süütu?; Mida teha, kui oled süüdi?; Mis sa arvad?

## Kollane Volvo I
URL: https://www.opiq.ee/kit/232/chapter/13730
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 27.1
Topics ET: matemaatika, kollane, volvo, luuletus, lähme, poodi, harjutus, enne, lugemist, ennusta
Topics RU: математика
Topics EN: mathematics
Headings: Kollane Volvo I; Luuletus „Lähme poodi“; Harjutus 1a; Harjutus 1b; Enne lugemist; Ennusta; Üksi poodi; Harjutus 2b; Harjutus 2a; Harjutus 3b; Harjutus 3a; Arutle; Lühendid; Pane tähele!; Harjutus 4; Harjutus 5

## Kollane Volvo II
URL: https://www.opiq.ee/kit/232/chapter/13749
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 27.2
Topics ET: matemaatika, kollane, volvo, janne, harjutus, arutle, silbitamine, tuleta, meelde, pane
Topics RU: математика
Topics EN: mathematics
Headings: Kollane Volvo II; Onu Janne; Harjutus 1b; Harjutus 1a; Arutle; Silbitamine; Tuleta meelde!; Pane tähele!; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3b; Harjutus 3a; Harjutus 4

## Kollane Volvo III
URL: https://www.opiq.ee/kit/232/chapter/13750
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 27.3
Topics ET: matemaatika, kollane, volvo, kakskümmend, krooni, harjutus, arutle, jutusta, liitsõna, silbitamine
Topics RU: математика
Topics EN: mathematics
Headings: Kollane Volvo III; Kakskümmend krooni; Harjutus 1b; Harjutus 1a; Harjutus 2b; Harjutus 2a; Harjutus 3; Arutle; Jutusta; Liitsõna silbitamine; Pane tähele!; Harjutus 4; Harjutus 5b; Harjutus 5a; Kordame varem õpitut; Harjuta etteütluseks

## Arutlustund. Varastamine
URL: https://www.opiq.ee/kit/232/chapter/13751
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 27.4
Topics ET: matemaatika, arutlustund, varastamine, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Varastamine; Varastamine; Mis sa arvad?

## Kääbusekivi I
URL: https://www.opiq.ee/kit/232/chapter/13940
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 28.1
Topics ET: matemaatika, kääbusekivi, rändrahn, luuremäng, arutle, harjutus, leia, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Kääbusekivi I; Rändrahn; Luuremäng; Arutle; Harjutus 1; Leia; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Kääbusekivi II
URL: https://www.opiq.ee/kit/232/chapter/13941
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 28.2
Topics ET: matemaatika, kääbusekivi, pääsu, räägib, saladuse, arutle, harjutus, õigekiri, pane, tähele
Topics RU: математика
Topics EN: mathematics
Headings: Kääbusekivi II; Pääsu räägib saladuse; Arutle; Harjutus 1d; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 2; I ja j-i õigekiri; Pane tähele!; Loe ja uuri; Harjutus 3; Harjutus 4b; Harjutus 4a

## Kääbusekivi III
URL: https://www.opiq.ee/kit/232/chapter/13942
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 28.3
Topics ET: matemaatika, kääbusekivi, särakivi, arutle, harjutus, kauri, ausõna, leia, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kääbusekivi III; Särakivi; Arutle; Harjutus 1; Kauri ausõna; Harjutus 2; Leia; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Arutlustund. Töölkäimine
URL: https://www.opiq.ee/kit/232/chapter/13943
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 28.4
Topics ET: matemaatika, arutlustund, töölkäimine, miks, inimesed, tööl, käivad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Töölkäimine; Miks inimesed tööl käivad?

## Kribu ja Krabu Viineripirukad I
URL: https://www.opiq.ee/kit/232/chapter/13944
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 29.1
Topics ET: matemaatika, kribu, krabu, viineripirukad, arutle, leia, harjutus, äriidee, jutusta, kolm
Topics RU: математика
Topics EN: mathematics
Headings: Kribu ja Krabu Viineripirukad I; Äri; Arutle; Leia; Harjutus 1; Äriidee; Harjutus 2b; Harjutus 2a; Jutusta; Kolm Põrsakest; Harjutus 3; Harjutus 3b; Harjutus 3a; Rühmatöö

## Kribu ja Krabu Viineripirukad II
URL: https://www.opiq.ee/kit/232/chapter/13945
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 29.2
Topics ET: matemaatika, kribu, krabu, viineripirukad, harjutus, jutusta, poolitamine, pane, tähele
Topics RU: математика
Topics EN: mathematics
Headings: Kribu ja Krabu Viineripirukad II; Kribu ja Krabu; Harjutus 1c; Harjutus 1a; Harjutus 1b; Jutusta; Poolitamine; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3; Pane tähele!; Harjutus 4; Harjutus 5

## Kribu ja Krabu Viineripirukad III
URL: https://www.opiq.ee/kit/232/chapter/14032
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 29.3
Topics ET: matemaatika, kribu, krabu, viineripirukad, äriplaan, harjutus, arutle, jutusta, harjuta, salakeeles
Topics RU: математика
Topics EN: mathematics
Headings: Kribu ja Krabu Viineripirukad III; Äriplaan; Harjutus 1b; Harjutus 1a; Arutle; Jutusta; Harjuta; Harjutus 2; Harjutus 3; Jutusta salakeeles; Eriline herilane; Harjutus 4c; Harjutus 4a; Harjutus 4b; Mäng „Käed üles!“; Leia; Kirjuta

## Arutlustund. Edukus
URL: https://www.opiq.ee/kit/232/chapter/14033
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 29.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, arutlustund, edukus, milline, edukas, peame, olema, edukad, arvad
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Arutlustund. Edukus; Milline inimene on edukas?; Kas me peame olema edukad?; Mis sa arvad?

## Saar + maa = Saaremaa
URL: https://www.opiq.ee/kit/232/chapter/15706
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 3.1
Topics ET: matemaatika, saar, saaremaa, harjutus, arutle, vaata, pilti, teadsid
Topics RU: математика
Topics EN: mathematics
Headings: Saar + maa = Saaremaa; Saar + maa; Harjutus 1d; Harjutus 1a; Harjutus 1b; Harjutus 1c; Arutle; Mis maa see on?; Vaata pilti ja arutle; Kas teadsid?

## Häälikuühendid
URL: https://www.opiq.ee/kit/232/chapter/15707
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 3.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, häälikuühendid, kassi, kaubamaja, jutusta, harjutus, täis, kaashäälikuühend, pane, tähele
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Häälikuühendid; Kassi kaubamaja; Jutusta; Harjutus 1; Harjutus 2; Täis- ja kaashäälikuühend; Pane tähele!; Loe ja võrdle; Leia; Harjutus 3b; Harjutus 3a; Harjutus 4

## Tutvustus
URL: https://www.opiq.ee/kit/232/chapter/15708
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 3.3
Topics ET: matemaatika, tutvustus, rannaküla, arutle, joonista, jutusta, film, ruudi, vaata, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Tutvustus; Rannaküla; Arutle; Joonista ja jutusta; Film „Ruudi“; Loe, vaata ja arutle; Mõtle ja tegutse edasi; Harjutus 2b; Harjutus 2a; Harjutus 1

## Arutlustund. Hobid
URL: https://www.opiq.ee/kit/232/chapter/15709
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 3.4
Topics ET: matemaatika, arutlustund, hobid, hobi, kohustus, meelelahutus, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Hobid; Mis on hobi?; Kohustus või meelelahutus?; Mis sa arvad?

## Televisioon
URL: https://www.opiq.ee/kit/232/chapter/14140
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 30.1
Topics ET: matemaatika, televisioon, laupäeval, harjutus, arutle, leia, suur, algustäht, nimedes, tuleta
Topics RU: математика
Topics EN: mathematics
Headings: Televisioon; Laupäeval; Harjutus 1; Arutle; Leia; Suur algustäht nimedes; Tuleta meelde!; Pane tähele!; Harjutus 2

## Roosaliisa prillid
URL: https://www.opiq.ee/kit/232/chapter/14141
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 30.2
Topics ET: matemaatika, roosaliisa, prillid, saigi, harjutus, arutle, mõtle, tegutse, edasi, punastavad
Topics RU: математика
Topics EN: mathematics
Headings: Roosaliisa prillid; Ja Roosaliisa saigi prillid; Harjutus 1b; Harjutus 1a; Arutle; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3; Harjutus 4; Punastavad prillid; Harjutus 5; Jutusta

## Kuidas issi telekat remontis
URL: https://www.opiq.ee/kit/232/chapter/14142
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 30.3
Topics ET: matemaatika, kuidas, issi, telekat, remontis, tugitoolitrenn, jutusta, harjutus, kodukino, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas issi telekat remontis; Tugitoolitrenn; Jutusta; Harjutus 1; Kodukino; Arutle; Harjutus 2; Harjutus 3; Tele-ekskursioon; Harjutus 4; Harjutus 4b; Harjutus 4a

## Arutlustund. Mis on õnn?
URL: https://www.opiq.ee/kit/232/chapter/14143
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 30.4
Topics ET: matemaatika, arutlustund
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Mis on õnn?; Mis on õnn?

## Kalleby kingsepp I
URL: https://www.opiq.ee/kit/232/chapter/14144
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 31.1
Topics ET: matemaatika, kalleby, kingsepp, küla, arutle, jutusta, redised, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kalleby kingsepp I; Kalleby küla; Arutle; Jutusta; Redised; Harjutus 1c; Harjutus 1a; Harjutus 1b; Mõtle ja tegutse edasi; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3

## Kalleby kingsepp II
URL: https://www.opiq.ee/kit/232/chapter/14145
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 31.2
Topics ET: matemaatika, kalleby, kingsepp, albert, pirnipuu, harjutus, kanakuut, arutle, leia, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Kalleby kingsepp II; Albert ja pirnipuu; Harjutus 1; Kanakuut; Arutle; Harjutus 2; Leia; Mõtle ja tegutse edasi; Harjutus 3; Tuleta meelde!; Harjutus 4

## Kalleby kingsepp III
URL: https://www.opiq.ee/kit/232/chapter/14146
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 31.3
Topics ET: matemaatika, kalleby, kingsepp, kanakuut, ennusta, nuputa, arutle, leia, kõrge, plank
Topics RU: математика
Topics EN: mathematics
Headings: Kalleby kingsepp III; Kanakuut; Ennusta; Nuputa; Arutle; Leia; Kõrge plank; Harjutus 1; Mis saab edasi?; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3; Harjutus 4

## Arutlustund. Austus
URL: https://www.opiq.ee/kit/232/chapter/14147
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 31.4
Topics ET: matemaatika, arutlustund, austus, kõiki, inimesi, tuleb, austada, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Austus; Mis on austus?; Kas kõiki inimesi tuleb austada?; Mis sa arvad?

## Aga nüüd hoidke alt!
URL: https://www.opiq.ee/kit/232/chapter/14218
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 32.1
Topics ET: matemaatika, nüüd, hoidke, harjutus, arutle, mäletad, lõvi, lõvilõug, näita, mitmetähenduslikud
Topics RU: математика
Topics EN: mathematics
Headings: Aga nüüd hoidke alt!; Harjutus 1; Arutle; Harjutus 2; Kas mäletad?; Lõvi ja lõvilõug; Näita ...; Harjutus 3; Harjutus 4b; Harjutus 4a; Mitmetähenduslikud sõnad; Pane tähele!; Harjutus 5

## Siil ja siisike
URL: https://www.opiq.ee/kit/232/chapter/14219
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 32.2
Topics ET: matemaatika, siil, siisike, loomaaias, oled, käinud, arutle, harjutus, jutusta, joonista
Topics RU: математика
Topics EN: mathematics
Headings: Siil ja siisike; Kas sa loomaaias oled käinud?; Arutle; Harjutus 1; Jutusta ja joonista; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3; Harjutus 4

## Loomade karneval
URL: https://www.opiq.ee/kit/232/chapter/14220
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 32.3
Topics ET: matemaatika, loomade, karneval, harjutus, arutle, kirjuta, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Loomade karneval; Harjutus 1; Arutle; Harjutus 2; Kirjuta; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4; Harjutus 5

## Arutlustund. Vabadus
URL: https://www.opiq.ee/kit/232/chapter/14221
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 32.4
Topics ET: matemaatika, arutlustund, vabadus, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Vabadus; Vabadus; Mis sa arvad?

## Suveks maale!
URL: https://www.opiq.ee/kit/232/chapter/14222
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 33.1
Topics ET: matemaatika, suveks, maale, laagrielu, harjutus, leia, arutle, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Suveks maale!; Laagrielu; Harjutus 1; Leia; Arutle; Mõtle ja tegutse edasi; Kirjuta; Loe; Harjutus 2; Harjutus 3

## Kontvõõrad grillipeol
URL: https://www.opiq.ee/kit/232/chapter/14223
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 33.2
Topics ET: matemaatika, kontvõõrad, grillipeol, koomiks, kirjuta, harjutus, jutusta, võõrsõnad, arutle, tuleta
Topics RU: математика
Topics EN: mathematics
Headings: Kontvõõrad grillipeol; Koomiks; Kirjuta; Harjutus 1; Jutusta; Võõrsõnad; Arutle; Tuleta meelde!; Harjutus 2; Harjutus 3; Harjutus 4

## Kooliaasta saab läbi
URL: https://www.opiq.ee/kit/232/chapter/14224
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 33.3
Topics ET: matemaatika, kordamine, korda, harjutan, kooliaasta, saab, läbi, varsti, algab, vaheaeg, harjutus, laste, soovitused
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kooliaasta saab läbi; Varsti algab vaheaeg!; Harjutus 1; Laste soovitused suveks; Ärka vara!; Maali looduses!; Saada kirju!; Tee herbaarium!; Arutle; Rühmatöö; Kordamine; Harjutus 2; Harjutus 3

## Arutlustund. Saladused
URL: https://www.opiq.ee/kit/232/chapter/14225
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 33.4
Topics ET: matemaatika, arutlustund, saladused, saladus, räägin, sulle, saladuse
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Saladused; Mis on saladus?; Ma räägin sulle ühe saladuse ...

## Kordamine I
URL: https://www.opiq.ee/kit/232/chapter/14226
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 34.1
Topics ET: matemaatika, kordamine, korda, harjutan, tähestik, häälikurühmad, harjutus, häälikupikkused, häälikuühendid, sidesõnad, koma, nõuavad
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine I; Tähestik ja häälikurühmad; Harjutus 1; Harjutus 2; Harjutus 3; Häälikupikkused ja häälikuühendid; Harjutus 4; Harjutus 5; Harjutus 6; Sidesõnad ja koma; Harjutus 7; Sidesõnad, mis nõuavad koma; Sidesõnad, mis koma ei vaja; Harjutus 8

## Kordamine II
URL: https://www.opiq.ee/kit/232/chapter/14227
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 34.2
Topics ET: matemaatika, kordamine, korda, harjutan, nimisõnad, omadussõnad, harjutus, jutusta, tegusõnad, tuleta, meelde, asesõnad
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine II; Nimisõnad ja omadussõnad; Harjutus 1; Harjutus 2; Harjutus 3; Jutusta; Tegusõnad; Harjutus 4; Harjutus 5; Tuleta meelde!; Asesõnad; Harjutus 6; Harjutus 7; Harjutus 8

## Kordamine III
URL: https://www.opiq.ee/kit/232/chapter/14228
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 34.3
Topics ET: matemaatika, kordamine, korda, harjutan, sõnad, laused, harjutus, tuleta, meelde, tekstid, arutle, toredat
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine III; Sõnad ja laused; Harjutus 1; Tuleta meelde!; Harjutus 2; Harjutus 3; Tekstid; Harjutus 4e; Harjutus 4a; Harjutus 4b; Harjutus 4c; Harjutus 4d; Arutle; Toredat suvevaheaega!

## Riigipiiri laul
URL: https://www.opiq.ee/kit/232/chapter/14128
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.1
Topics ET: matemaatika, riigipiiri, laul, leia
Topics RU: математика
Topics EN: mathematics
Headings: Riigipiiri laul; Leia

## Nublu
URL: https://www.opiq.ee/kit/232/chapter/14137
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.10
Topics ET: matemaatika, nublu
Topics RU: математика
Topics EN: mathematics
Headings: Nublu

## Kollane Volvo
URL: https://www.opiq.ee/kit/232/chapter/13752
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.11
Topics ET: matemaatika, kollane, volvo
Topics RU: математика
Topics EN: mathematics
Headings: Kollane Volvo; VII

## Kanakuut
URL: https://www.opiq.ee/kit/232/chapter/14138
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.12
Topics ET: matemaatika, kanakuut
Topics RU: математика
Topics EN: mathematics
Headings: Kanakuut; II; III; IV

## Pätu
URL: https://www.opiq.ee/kit/232/chapter/14139
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.13
Topics ET: matemaatika, pätu
Topics RU: математика
Topics EN: mathematics
Headings: Pätu; II

## Tutvus võõraga
URL: https://www.opiq.ee/kit/232/chapter/14129
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.2
Topics ET: matemaatika, tutvus, võõraga
Topics RU: математика
Topics EN: mathematics
Headings: Tutvus võõraga

## Volli läheb magama
URL: https://www.opiq.ee/kit/232/chapter/14130
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.3
Topics ET: matemaatika, volli, läheb, magama
Topics RU: математика
Topics EN: mathematics
Headings: Volli läheb magama

## Öö imed
URL: https://www.opiq.ee/kit/232/chapter/14131
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.4
Topics ET: matemaatika, imed
Topics RU: математика
Topics EN: mathematics
Headings: Öö imed

## Kummaline kuju
URL: https://www.opiq.ee/kit/232/chapter/14132
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.5
Topics ET: matemaatika, kummaline, kuju
Topics RU: математика
Topics EN: mathematics
Headings: Kummaline kuju

## Tädi Fantaasia
URL: https://www.opiq.ee/kit/232/chapter/14133
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.6
Topics ET: matemaatika, tädi, fantaasia
Topics RU: математика
Topics EN: mathematics
Headings: Tädi Fantaasia; II

## Mina küll ei karda!
URL: https://www.opiq.ee/kit/232/chapter/14134
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.7
Topics ET: matemaatika, mina, küll, karda
Topics RU: математика
Topics EN: mathematics
Headings: Mina küll ei karda!

## Naksitrallid
URL: https://www.opiq.ee/kit/232/chapter/14135
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.8
Topics ET: matemaatika, naksitrallid, liiklusummik
Topics RU: математика
Topics EN: mathematics
Headings: Naksitrallid; Liiklusummik

## Madal taevas
URL: https://www.opiq.ee/kit/232/chapter/14136
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 35.9
Topics ET: matemaatika, madal, taevas
Topics RU: математика
Topics EN: mathematics
Headings: Madal taevas

## Sõnaseletused
URL: https://www.opiq.ee/kit/232/chapter/13202
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 36.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/232/chapter/21866
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 36.2
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Kas internet on ohtlik?
URL: https://www.opiq.ee/kit/232/chapter/15710
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 4.1
Topics ET: matemaatika, internet, ohtlik, nähtamatu, võrk, arutle, harjutus, internetimaa, jutusta
Topics RU: математика
Topics EN: mathematics
Headings: Kas internet on ohtlik?; Nähtamatu võrk; Arutle; Harjutus 1; Internetimaa; Jutusta

## Kuidas saada vingeks arvutikasutajaks?
URL: https://www.opiq.ee/kit/232/chapter/15711
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 4.2
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, kuidas, saada, vingeks, arvutikasutajaks, vinge, arvutikasutaja, harjutus, arutle, internet
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Kuidas saada vingeks arvutikasutajaks?; Vinge arvutikasutaja; Harjutus 1; Arutle; Harjutus 2; Mis see internet õigupoolest on?; Harjutus 3; Harjutus 4a; H1; H2; Harjutus 4b; H3; H4; Harjutus 4c; H5; H6; Harjutus 4d; H7; H8; Täishääliku pikkus; Tuleta meelde!; Harjutus 5; Harjutus 6

## Volli arvuti
URL: https://www.opiq.ee/kit/232/chapter/15712
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 4.3
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, volli, arvuti, kust, saab, kõvakettaid, harjutus, arutle, tahtsin, teada
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Volli arvuti; Kust saab kõvakettaid; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Ma tahtsin teada, mis seal sees on; Harjutus 2b; Harjutus 2a; Kuula. „Volli isa ostis jäätist“; Harjutus 3c; Harjutus 3a; Harjutus 3b; Kuula ja joonista; Suluta kaashääliku pikkus; Tuleta meelde!; Harjutus 4; Harjutus 5

## Arutlustund. Arvutiga või ilma?
URL: https://www.opiq.ee/kit/232/chapter/15713
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 4.4
Topics ET: matemaatika, arutlustund, arvutiga, ilma, juhtuks, kõik, arvutid, ühel, päeval, katki
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Arvutiga või ilma?; Mis juhtuks, kui kõik arvutid ühel päeval katki läheksid?; Kuidas arvutid meile kasulikud on?; Mis sa arvad?

## Välismaa
URL: https://www.opiq.ee/kit/232/chapter/15714
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 5.1
Topics ET: matemaatika, välismaa, milliseid, põnevaid, paiku, maailmas, jutusta, teadsid, reisime, välismaale
Topics RU: математика
Topics EN: mathematics
Headings: Välismaa; Milliseid põnevaid paiku on maailmas?; Jutusta; Kas teadsid?; Reisime välismaale; Harjutus 1a; Harjutus 1b; Harjutus 1c; Kuula ja vasta küsimustele; Reisil vajalikud asjad; Kirjuta; Harjutus 2a; Harjutus 2b

## Krokodill Gena ja tema sõbrad
URL: https://www.opiq.ee/kit/232/chapter/15715
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 5.2
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, krokodill, gena, tema, sõbrad, sulghääliku, tuleta, meelde, häälda
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Krokodill Gena ja tema sõbrad; Sulghääliku pikkus; Tuleta meelde!; Häälda; Harjutus 1; Krokodill Gena; Harjutus 2c; Harjutus 2a; Harjutus 2b; Gena ja sõbrad; Harjutus 3; Arutle; Gena tahaks reisida; Kuula ja vasta küsimustele; Harjutus 4c; Harjutus 4a; Harjutus 4b

## Kahjulikud nõuanded
URL: https://www.opiq.ee/kit/232/chapter/15716
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 5.3
Topics ET: matemaatika, kahjulikud, nõuanded, vastikud, nipid, harjutus, arutle, vastandliku, tähendusega, sõnad
Topics RU: математика
Topics EN: mathematics
Headings: Kahjulikud nõuanded; Vastikud nipid; Harjutus 1b; Harjutus 1a; Arutle; Vastandliku tähendusega sõnad; Harjutus 2; Jutusta; Harjutus 3b; Harjutus 3a; Kirjuta ja joonista

## Arutlustund. Mis on nali?
URL: https://www.opiq.ee/kit/232/chapter/15717
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 5.4
Topics ET: matemaatika, arutlustund, nali, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Mis on nali?; Mis on nali?; Mis sa arvad?

## Muinasjutumaa
URL: https://www.opiq.ee/kit/232/chapter/15718
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 6.1
Topics ET: matemaatika, muinasjutumaa, milline, arutle, jutusta, kuula, joonista, siimu, lugemispäevik
Topics RU: математика
Topics EN: mathematics
Headings: Muinasjutumaa; Milline on muinasjutumaa?; Arutle; Jutusta; Kuula ja joonista B; Kuula ja joonista A; Siimu lugemispäevik

## Või-inimesed
URL: https://www.opiq.ee/kit/232/chapter/15719
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 6.2
Topics ET: matemaatika, inimesed, päevavaras, külmkapis, harjutus, arutle, küsisõnad, pane, tähele, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Või-inimesed; Päevavaras külmkapis; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Küsisõnad; Harjutus 2; Pane tähele!; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5

## Lumeeit
URL: https://www.opiq.ee/kit/232/chapter/15720
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 6.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, lumeeit, jutusta, harjutus, laisk, tütar, õnne, otsimas, arutle, kirjuta
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Lumeeit; Jutusta; Harjutus 1c; Harjutus 1a; Harjutus 1b; Harjutus 2; Laisk tütar õnne otsimas; Harjutus 3c; Harjutus 3a; Harjutus 3b; Arutle; Kirjuta; Asesõna õigekiri; Loe ja võrdle; Harjutus 4b; Harjutus 4a

## Arutlustund. Valetamine
URL: https://www.opiq.ee/kit/232/chapter/15721
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 6.4
Topics ET: matemaatika, arutlustund, valetamine, miks, inimesed, valetavad, mitterääkimine, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Valetamine; Miks inimesed valetavad?; Kas mitterääkimine on ka valetamine?; Mis sa arvad?

## Unenäomaa
URL: https://www.opiq.ee/kit/232/chapter/15722
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 7.1
Topics ET: matemaatika, unenäomaa, milline, arutle, joonista, jutusta, siimu, laura, küsimustele, vastab
Topics RU: математика
Topics EN: mathematics
Headings: Unenäomaa; Milline on unenäomaa?; Arutle; Joonista ja jutusta; Siimu ja Laura küsimustele vastab doktor Mati Uni; Mõtle; Harjutus 1b; Harjutus 1a

## Ema ja isa unenägu
URL: https://www.opiq.ee/kit/232/chapter/15723
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 7.2
Topics ET: matemaatika, unenägu, rongilugu, harjutus, arutle, kaashäälikuühend, tuleta, meelde, autobussilugu, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Ema ja isa unenägu; Ema rongilugu; Harjutus 1; Arutle; Kaashäälikuühend; Tuleta meelde!; Harjutus 2; Harjutus 3; Isa autobussilugu; Harjutus 4; Mõtle ja tegutse edasi; Jutusta ja kuula; Kirjuta; Reis unenäomaale; Vestle

## Samueli võlupadi
URL: https://www.opiq.ee/kit/232/chapter/15724
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 7.3
Topics ET: matemaatika, samueli, võlupadi, harjutus, arutle, unemetsades, kirjuta, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Samueli võlupadi; Harjutus 1; Arutle; Unemetsades; Harjutus 2; Kirjuta; Mõtle ja tegutse edasi; Jutusta

## Arutlustund. Mis on unenägu?
URL: https://www.opiq.ee/kit/232/chapter/15725
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 7.4
Topics ET: matemaatika, arutlustund, unenägu, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Mis on unenägu?; Mis on unenägu?; Mis sa arvad?

## Võrumaa
URL: https://www.opiq.ee/kit/232/chapter/15726
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 8.1
Topics ET: matemaatika, võrumaa, võrumaal, arutle, jutusta, teadsid, sulle, meeldib, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Võrumaa; Mis on Võrumaal?; Arutle; Jutusta; Kas teadsid?; Mis sulle Võrumaal meeldib?; Kirjuta

## Munamägi
URL: https://www.opiq.ee/kit/232/chapter/15727
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 8.2
Topics ET: matemaatika, munamägi, harjutus, arutle, jutusta, nimede, õigekiri, meeles, võrukaelad, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Munamägi; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Jutusta; Nimede õigekiri; Pea meeles!; Harjutus 2; Harjutus 3b; Harjutus 3a; Harjutus 4; Võrukaelad; Harjutus 5; Mõtle ja tegutse edasi; Meisterda

## Ummamuudu puhkus
URL: https://www.opiq.ee/kit/232/chapter/15728
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 8.3
Topics ET: matemaatika, ummamuudu, puhkus, harjutus, jutusta, kirjuta, arutle, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Ummamuudu puhkus; Ummamuudu puhkus I; Harjutus 1b; Harjutus 1a; Ummamuudu puhkus II; Harjutus 2b; Harjutus 2a; Jutusta; Kirjuta; Arutle; Mõtle ja tegutse edasi; Harjutus 3b; Harjutus 3a

## Arutlustund. Mis on tõde?
URL: https://www.opiq.ee/kit/232/chapter/15729
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 8.4
Topics ET: matemaatika, arutlustund, tõde, olemas, ainult, arvad
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Mis on tõde?; Mis on tõde?; Kas on olemas ainult üks tõde?; Mis sa arvad?

## Pokumaa
URL: https://www.opiq.ee/kit/232/chapter/16881
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 9.1
Topics ET: matemaatika, pokumaa, teadsid, arutle, pokumaal, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Pokumaa; Mis on Pokumaa?; Kas teadsid?; Arutle; Mis on Pokumaal?; Harjutus 1

## Pokuraamat
URL: https://www.opiq.ee/kit/232/chapter/16882
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 9.2
Topics ET: matemaatika, pokuraamat, elusolendite, toidulaud, harjutus, looduse, enda, seadus, arutle, nimisõna
Topics RU: математика
Topics EN: mathematics
Headings: Pokuraamat; Elusolendite toidulaud; Harjutus 1c; Harjutus 1a; Harjutus 1b; Looduse enda seadus; Harjutus 2c; Harjutus 2a; Harjutus 2b; Arutle; Nimisõna mitmus; Harjutus 3b; Harjutus 3a; Harjutus 4; Harjutus 5; Mõtle ja tegutse edasi; Pokud Tallinnas

## Et poleks vaja pärida, mida ei või närida
URL: https://www.opiq.ee/kit/232/chapter/16883
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 9.3
Topics ET: matemaatika, poleks, vaja, pärida, mida, närida, arutle, jutusta, väänkael, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Et poleks vaja pärida, mida ei või närida; Arutle; Jutusta; Väänkael; Mõtle ja tegutse edasi; Kuula ja vasta küsimustele; Harjutus 1e; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d

## Arutlustund. Roheline eluviis
URL: https://www.opiq.ee/kit/232/chapter/16884
Book: Eesti keele õpik 2. klassile 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_eesti_keel_2_et
Chapter ID: 9.4
Topics ET: matemaatika, arutlustund, roheline, eluviis, milline, loodussõbralik, mida, sina, saaksid, teha
Topics RU: математика
Topics EN: mathematics
Headings: Arutlustund. Roheline eluviis; Milline on roheline ehk loodussõbralik eluviis?; Mida sina saaksid teha, et loodust hoida?

## ILUS EMAKEEL – Opiq
URL: https://www.opiq.ee/Kit/Details/118
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 153
Topics ET: matemaatika, ilus, emakeel, opiq
Topics RU: математика
Topics EN: mathematics

## ILUS EMAKEEL – Opiq
URL: https://www.opiq.ee/Kit/Details/118
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 154
Topics ET: matemaatika, ilus, emakeel, opiq
Topics RU: математика
Topics EN: mathematics

## ILUS EMAKEEL – Opiq
URL: https://www.opiq.ee/Kit/Details/118
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 337
Topics ET: matemaatika, ilus, emakeel, opiq
Topics RU: математика
Topics EN: mathematics

## KOOLI
URL: https://www.opiq.ee/kit/118/chapter/5863
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 1.1
Topics ET: matemaatika, kooli
Topics RU: математика
Topics EN: mathematics
Headings: KOOLI

## KÄTLIN TAHAB KOOLI MINNA
URL: https://www.opiq.ee/kit/118/chapter/5864
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 1.2
Topics ET: matemaatika, kätlin, tahab, kooli, minna
Topics RU: математика
Topics EN: mathematics
Headings: KÄTLIN TAHAB KOOLI MINNA

## PAULA ÕPIB EMAKEELT
URL: https://www.opiq.ee/kit/118/chapter/5865
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 1.3
Topics ET: matemaatika, paula, õpib, emakeelt
Topics RU: математика
Topics EN: mathematics
Headings: PAULA ÕPIB EMAKEELT

## SUNE LÄHEB TEISE KLASSI
URL: https://www.opiq.ee/kit/118/chapter/5866
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 1.4
Topics ET: matemaatika, sune, läheb, teise, klassi
Topics RU: математика
Topics EN: mathematics
Headings: SUNE LÄHEB TEISE KLASSI

## KÕIGIL JUHTUB ÄPARDUSI
URL: https://www.opiq.ee/kit/118/chapter/5905
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 10.1
Topics ET: matemaatika, kõigil, juhtub, äpardusi
Topics RU: математика
Topics EN: mathematics
Headings: KÕIGIL JUHTUB ÄPARDUSI

## K, p, t ja g, b, d
URL: https://www.opiq.ee/kit/118/chapter/5906
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 10.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: K, p, t ja g, b, d

## VANAEMA ON ÄREVIL
URL: https://www.opiq.ee/kit/118/chapter/5907
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 10.3
Topics ET: matemaatika, vanaema, ärevil
Topics RU: математика
Topics EN: mathematics
Headings: VANAEMA ON ÄREVIL

## PAULA PANEB TEE KEEMA
URL: https://www.opiq.ee/kit/118/chapter/5908
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 10.4
Topics ET: matemaatika, paula, paneb, keema
Topics RU: математика
Topics EN: mathematics
Headings: PAULA PANEB TEE KEEMA

## KUIDAS BUUTS SEENT SÕI
URL: https://www.opiq.ee/kit/118/chapter/5910
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 10.5
Topics ET: matemaatika, kuidas, buuts, seent
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS BUUTS SEENT SÕI

## KADRID TULEVAD
URL: https://www.opiq.ee/kit/118/chapter/5909
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 10.6
Topics ET: matemaatika, kadrid, tulevad
Topics RU: математика
Topics EN: mathematics
Headings: KADRID TULEVAD

## KUI MA ÜKSKORD JUUA TAHTSIN
URL: https://www.opiq.ee/kit/118/chapter/5916
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 11.1
Topics ET: matemaatika, ükskord, juua, tahtsin
Topics RU: математика
Topics EN: mathematics
Headings: KUI MA ÜKSKORD JUUA TAHTSIN

## S ja h
URL: https://www.opiq.ee/kit/118/chapter/5911
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 11.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: S ja h

## PERETÜTAR JA VAENELAPS
URL: https://www.opiq.ee/kit/118/chapter/5912
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 11.3
Topics ET: matemaatika, peretütar, vaenelaps
Topics RU: математика
Topics EN: mathematics
Headings: PERETÜTAR JA VAENELAPS

## VIISAKUSEST
URL: https://www.opiq.ee/kit/118/chapter/5913
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 11.4
Topics ET: matemaatika, viisakusest
Topics RU: математика
Topics EN: mathematics
Headings: VIISAKUSEST

## KÄRARIKAS MIHKEL
URL: https://www.opiq.ee/kit/118/chapter/5914
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 11.5
Topics ET: matemaatika, kärarikas, mihkel
Topics RU: математика
Topics EN: mathematics
Headings: KÄRARIKAS MIHKEL

## HEA MÕTE
URL: https://www.opiq.ee/kit/118/chapter/5915
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 11.6
Topics ET: matemaatika, mõte
Topics RU: математика
Topics EN: mathematics
Headings: HEA MÕTE

## KAKS PILTI
URL: https://www.opiq.ee/kit/118/chapter/5917
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 12.1
Topics ET: matemaatika, kaks, pilti
Topics RU: математика
Topics EN: mathematics
Headings: KAKS PILTI

## KUIDAS PAULA ENDALE VENNA SAI
URL: https://www.opiq.ee/kit/118/chapter/5918
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 12.2
Topics ET: matemaatika, kuidas, paula, endale, venna
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS PAULA ENDALE VENNA SAI

## ELLEN JA TEMA KASUISA
URL: https://www.opiq.ee/kit/118/chapter/5920
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 12.3
Topics ET: matemaatika, ellen, tema, kasuisa
Topics RU: математика
Topics EN: mathematics
Headings: ELLEN JA TEMA KASUISA

## ELLEN JA TEMA PÄRISISA
URL: https://www.opiq.ee/kit/118/chapter/5919
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 12.4
Topics ET: matemaatika, ellen, tema, pärisisa
Topics RU: математика
Topics EN: mathematics
Headings: ELLEN JA TEMA PÄRISISA

## Kontrolltöö 3
URL: https://www.opiq.ee/kit/118/chapter/20797
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 12.5
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 3

## LÄBI ÖÖ
URL: https://www.opiq.ee/kit/118/chapter/5921
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.1
Topics ET: matemaatika, läbi
Topics RU: математика
Topics EN: mathematics
Headings: LÄBI ÖÖ

## VARESE JÕULUD
URL: https://www.opiq.ee/kit/118/chapter/5932
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.10
Topics ET: matemaatika, varese, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: VARESE JÕULUD

## JÕULUVANA
URL: https://www.opiq.ee/kit/118/chapter/5927
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.11
Topics ET: matemaatika, jõuluvana
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUVANA

## JÕULUVANA LAPSELAPSED
URL: https://www.opiq.ee/kit/118/chapter/5933
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.12
Topics ET: matemaatika, jõuluvana, lapselapsed
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUVANA LAPSELAPSED

## JÕULUÕHTUL
URL: https://www.opiq.ee/kit/118/chapter/5934
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.13
Topics ET: matemaatika, jõuluõhtul
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUÕHTUL

## JÕUAKS, JÕUAKS JÕULUD TULLA
URL: https://www.opiq.ee/kit/118/chapter/5935
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.14
Topics ET: matemaatika, jõuaks, jõulud, tulla
Topics RU: математика
Topics EN: mathematics
Headings: JÕUAKS, JÕUAKS JÕULUD TULLA

## HÜLJATUD NUKUD
URL: https://www.opiq.ee/kit/118/chapter/5936
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.15
Topics ET: matemaatika, hüljatud, nukud
Topics RU: математика
Topics EN: mathematics
Headings: HÜLJATUD NUKUD

## Kordamis- ja lisaharjutusi
URL: https://www.opiq.ee/kit/118/chapter/5928
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.16
Topics ET: matemaatika, kordamis, lisaharjutusi
Topics RU: математика
Topics EN: mathematics
Headings: Kordamis- ja lisaharjutusi

## Kontrolltöö 4
URL: https://www.opiq.ee/kit/118/chapter/20798
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.17
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 4

## LIBE KÕNNITEE
URL: https://www.opiq.ee/kit/118/chapter/5922
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.2
Topics ET: matemaatika, libe, kõnnitee
Topics RU: математика
Topics EN: mathematics
Headings: LIBE KÕNNITEE

## h sõna alguses
URL: https://www.opiq.ee/kit/118/chapter/5923
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.3
Topics ET: matemaatika, sõna, alguses
Topics RU: математика
Topics EN: mathematics
Headings: h sõna alguses

## PAULA MÕTLEB
URL: https://www.opiq.ee/kit/118/chapter/5929
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.4
Topics ET: matemaatika, paula, mõtleb
Topics RU: математика
Topics EN: mathematics
Headings: PAULA MÕTLEB

## VAESE MEHE JÕULUD
URL: https://www.opiq.ee/kit/118/chapter/5924
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.5
Topics ET: matemaatika, vaese, mehe, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: VAESE MEHE JÕULUD

## KUIDAS ME BULLERBYS JÕULE PÜHITSEME
URL: https://www.opiq.ee/kit/118/chapter/5930
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.6
Topics ET: matemaatika, kuidas, bullerbys, jõule, pühitseme
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS ME BULLERBYS JÕULE PÜHITSEME

## MÄNGIME
URL: https://www.opiq.ee/kit/118/chapter/5931
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.7
Topics ET: matemaatika, mängime
Topics RU: математика
Topics EN: mathematics
Headings: MÄNGIME

## LINNUKESTE JÕULULAUL
URL: https://www.opiq.ee/kit/118/chapter/5925
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.8
Topics ET: matemaatika, linnukeste, jõululaul
Topics RU: математика
Topics EN: mathematics
Headings: LINNUKESTE JÕULULAUL

## PÄKAPIKK PIRTSU JÕULUD
URL: https://www.opiq.ee/kit/118/chapter/5926
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 13.9
Topics ET: matemaatika, päkapikk, pirtsu, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: PÄKAPIKK PIRTSU JÕULUD

## MINEVIK JA TULEVIK
URL: https://www.opiq.ee/kit/118/chapter/5941
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 14.1
Topics ET: matemaatika, minevik, tulevik
Topics RU: математика
Topics EN: mathematics
Headings: MINEVIK JA TULEVIK

## NELI SOOVI
URL: https://www.opiq.ee/kit/118/chapter/5937
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 14.2
Topics ET: matemaatika, neli, soovi
Topics RU: математика
Topics EN: mathematics
Headings: NELI SOOVI

## LAUL KUUDEST
URL: https://www.opiq.ee/kit/118/chapter/5938
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 14.3
Topics ET: matemaatika, laul, kuudest
Topics RU: математика
Topics EN: mathematics
Headings: LAUL KUUDEST

## ÖÖ JA PÄEV
URL: https://www.opiq.ee/kit/118/chapter/5939
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 14.4
Topics ET: matemaatika, päev
Topics RU: математика
Topics EN: mathematics
Headings: ÖÖ JA PÄEV

## AEG
URL: https://www.opiq.ee/kit/118/chapter/5942
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 14.5
Topics ET: matemaatika, aeg, kell, kalender, meile, antud, kuidas, vanasti, aega, mõõdeti
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: AEG; MEILE ANTUD AEG; KUIDAS VANASTI AEGA MÕÕDETI?

## VANAÕELUSE SILM
URL: https://www.opiq.ee/kit/118/chapter/5940
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 14.6
Topics ET: matemaatika, vanaõeluse, silm
Topics RU: математика
Topics EN: mathematics
Headings: VANAÕELUSE SILM

## MÕNI RIDA RAAMATUST
URL: https://www.opiq.ee/kit/118/chapter/5943
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 15.1
Topics ET: matemaatika, mõni, rida, raamatust
Topics RU: математика
Topics EN: mathematics
Headings: MÕNI RIDA RAAMATUST

## HIRMUS LUGU
URL: https://www.opiq.ee/kit/118/chapter/5944
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 15.2
Topics ET: matemaatika, hirmus, lugu
Topics RU: математика
Topics EN: mathematics
Headings: HIRMUS LUGU

## PÄEVAPLAAN
URL: https://www.opiq.ee/kit/118/chapter/5945
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 15.3
Topics ET: matemaatika, päevaplaan, karu, kusti
Topics RU: математика
Topics EN: mathematics
Headings: PÄEVAPLAAN; KARU-KUSTI PÄEVAPLAAN

## PLAANID-PLAANID
URL: https://www.opiq.ee/kit/118/chapter/5946
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 15.4
Topics ET: matemaatika, plaanid
Topics RU: математика
Topics EN: mathematics
Headings: PLAANID-PLAANID

## KÜLMAPÜHA
URL: https://www.opiq.ee/kit/118/chapter/5947
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 16.1
Topics ET: matemaatika, külmapüha
Topics RU: математика
Topics EN: mathematics
Headings: KÜLMAPÜHA

## ISSIGA KELGUTAMAS
URL: https://www.opiq.ee/kit/118/chapter/5948
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 16.2
Topics ET: matemaatika, issiga, kelgutamas
Topics RU: математика
Topics EN: mathematics
Headings: ISSIGA KELGUTAMAS

## ANDEKSPALUMISE LILLED
URL: https://www.opiq.ee/kit/118/chapter/5949
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 16.3
Topics ET: matemaatika, andekspalumise, lilled
Topics RU: математика
Topics EN: mathematics
Headings: ANDEKSPALUMISE LILLED

## LUGU LUMEMEMMEST JA LUMETAADIST
URL: https://www.opiq.ee/kit/118/chapter/5950
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 16.4
Topics ET: matemaatika, lugu, lumememmest, lumetaadist
Topics RU: математика
Topics EN: mathematics
Headings: LUGU LUMEMEMMEST JA LUMETAADIST

## TEED
URL: https://www.opiq.ee/kit/118/chapter/5951
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 17.1
Topics ET: matemaatika, teed
Topics RU: математика
Topics EN: mathematics
Headings: TEED

## Suur algustäht
URL: https://www.opiq.ee/kit/118/chapter/5952
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 17.2
Topics ET: matemaatika, suur, algustäht
Topics RU: математика
Topics EN: mathematics
Headings: Suur algustäht

## LUGU PISI-PISIKESEST EIDERIBULAST
URL: https://www.opiq.ee/kit/118/chapter/5953
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 17.3
Topics ET: matemaatika, lugu, pisi, pisikesest, eideribulast
Topics RU: математика
Topics EN: mathematics
Headings: LUGU PISI-PISIKESEST EIDERIBULAST

## HENNO KÄO
URL: https://www.opiq.ee/kit/118/chapter/5954
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 17.4
Topics ET: matemaatika, henno
Topics RU: математика
Topics EN: mathematics
Headings: HENNO KÄO

## INIMESE PESA
URL: https://www.opiq.ee/kit/118/chapter/20799
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 17.5
Topics ET: matemaatika, inimese, pesa
Topics RU: математика
Topics EN: mathematics
Headings: INIMESE PESA

## VANA JA UUS
URL: https://www.opiq.ee/kit/118/chapter/20800
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 17.6
Topics ET: matemaatika, vana
Topics RU: математика
Topics EN: mathematics
Headings: VANA JA UUS

## LÄHEKS LINNA!
URL: https://www.opiq.ee/kit/118/chapter/5959
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 18.1
Topics ET: matemaatika, läheks, linna
Topics RU: математика
Topics EN: mathematics
Headings: LÄHEKS LINNA!

## KIRP JA KÄRBES
URL: https://www.opiq.ee/kit/118/chapter/5955
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 18.2
Topics ET: matemaatika, kirp, kärbes
Topics RU: математика
Topics EN: mathematics
Headings: KIRP JA KÄRBES

## ÜKS LINNAOSA, TUULEMÄGI NIMEKS
URL: https://www.opiq.ee/kit/118/chapter/5956
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 18.3
Topics ET: matemaatika, linnaosa, tuulemägi, nimeks
Topics RU: математика
Topics EN: mathematics
Headings: ÜKS LINNAOSA, TUULEMÄGI NIMEKS

## AUTOPÕRNIKA SALAUNISTUS
URL: https://www.opiq.ee/kit/118/chapter/5957
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 18.4
Topics ET: matemaatika, autopõrnika, salaunistus
Topics RU: математика
Topics EN: mathematics
Headings: AUTOPÕRNIKA SALAUNISTUS

## KES ON KASSIPOEG
URL: https://www.opiq.ee/kit/118/chapter/5958
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 18.5
Topics ET: matemaatika, kassipoeg
Topics RU: математика
Topics EN: mathematics
Headings: KES ON KASSIPOEG

## Kontrolltöö 5
URL: https://www.opiq.ee/kit/118/chapter/20801
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 18.6
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 5

## MEELESPEA
URL: https://www.opiq.ee/kit/118/chapter/5960
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 19.1
Topics ET: matemaatika, meelespea
Topics RU: математика
Topics EN: mathematics
Headings: MEELESPEA

## Kuulutus
URL: https://www.opiq.ee/kit/118/chapter/5961
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 19.2
Topics ET: matemaatika, kuulutus
Topics RU: математика
Topics EN: mathematics
Headings: Kuulutus

## SININE VABADUS
URL: https://www.opiq.ee/kit/118/chapter/5965
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 19.3
Topics ET: matemaatika, sinine, vabadus
Topics RU: математика
Topics EN: mathematics
Headings: SININE VABADUS

## PUUDE ISTUTAMINE
URL: https://www.opiq.ee/kit/118/chapter/5962
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 19.4
Topics ET: matemaatika, puude, istutamine
Topics RU: математика
Topics EN: mathematics
Headings: PUUDE ISTUTAMINE

## ÜHE PUU ELULUGU
URL: https://www.opiq.ee/kit/118/chapter/5963
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 19.5
Topics ET: matemaatika, taim, taimed, puu, lill, elulugu
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: ÜHE PUU ELULUGU

## LÄBI METSA
URL: https://www.opiq.ee/kit/118/chapter/5964
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 19.6
Topics ET: matemaatika, läbi, metsa
Topics RU: математика
Topics EN: mathematics
Headings: LÄBI METSA

## LAISK POISS
URL: https://www.opiq.ee/kit/118/chapter/5871
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 2.1
Topics ET: matemaatika, laisk, poiss
Topics RU: математика
Topics EN: mathematics
Headings: LAISK POISS

## KAKS KÕRVITSAKASVATAJAT
URL: https://www.opiq.ee/kit/118/chapter/5867
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 2.2
Topics ET: matemaatika, kaks, kõrvitsakasvatajat
Topics RU: математика
Topics EN: mathematics
Headings: KAKS KÕRVITSAKASVATAJAT

## KUIDAS ONU ÖÖBIK ÕUNU SÖÖB
URL: https://www.opiq.ee/kit/118/chapter/5868
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 2.3
Topics ET: matemaatika, kuidas, ööbik, õunu, sööb
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS ONU ÖÖBIK ÕUNU SÖÖB

## HÄÄLIKUD JA TÄHED
URL: https://www.opiq.ee/kit/118/chapter/5869
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 2.4
Topics ET: matemaatika, häälikud, tähed
Topics RU: математика
Topics EN: mathematics
Headings: HÄÄLIKUD JA TÄHED

## PAREM KÄSI, VASAK KÄSI
URL: https://www.opiq.ee/kit/118/chapter/5870
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 2.5
Topics ET: matemaatika, parem, käsi, vasak
Topics RU: математика
Topics EN: mathematics
Headings: PAREM KÄSI, VASAK KÄSI

## JETI LÄHEB LINNA VAATAMA
URL: https://www.opiq.ee/kit/118/chapter/5872
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 2.6
Topics ET: matemaatika, jeti, läheb, linna, vaatama
Topics RU: математика
Topics EN: mathematics
Headings: JETI LÄHEB LINNA VAATAMA

## TÖÖD
URL: https://www.opiq.ee/kit/118/chapter/5966
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 20.1
Topics ET: matemaatika, tööd, kaarel, kõhkleja
Topics RU: математика
Topics EN: mathematics
Headings: TÖÖD; Kaarel Kõhkleja

## TOHTRI TASU
URL: https://www.opiq.ee/kit/118/chapter/5967
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 20.2
Topics ET: matemaatika, tohtri, tasu
Topics RU: математика
Topics EN: mathematics
Headings: TOHTRI TASU

## HIIR, VÄHK JA SITIKAS
URL: https://www.opiq.ee/kit/118/chapter/5968
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 20.3
Topics ET: matemaatika, hiir, vähk, sitikas
Topics RU: математика
Topics EN: mathematics
Headings: HIIR, VÄHK JA SITIKAS

## MERERÖÖVEL LUSIKAS
URL: https://www.opiq.ee/kit/118/chapter/5969
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 20.4
Topics ET: matemaatika, mereröövel, lusikas
Topics RU: математика
Topics EN: mathematics
Headings: MERERÖÖVEL LUSIKAS

## LIIGA KALLIS
URL: https://www.opiq.ee/kit/118/chapter/5970
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 20.5
Topics ET: matemaatika, liiga, kallis
Topics RU: математика
Topics EN: mathematics
Headings: LIIGA KALLIS

## KULDNE PEREKOND
URL: https://www.opiq.ee/kit/118/chapter/5971
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 20.6
Topics ET: matemaatika, kuldne, perekond
Topics RU: математика
Topics EN: mathematics
Headings: KULDNE PEREKOND

## MINU KODUMAA
URL: https://www.opiq.ee/kit/118/chapter/5972
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.1
Topics ET: matemaatika, kodumaa
Topics RU: математика
Topics EN: mathematics
Headings: MINU KODUMAA

## PIDUPÄEV
URL: https://www.opiq.ee/kit/118/chapter/5973
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.2
Topics ET: matemaatika, pidupäev
Topics RU: математика
Topics EN: mathematics
Headings: PIDUPÄEV

## AJALUGU
URL: https://www.opiq.ee/kit/118/chapter/5974
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.3
Topics ET: matemaatika, ajalugu
Topics RU: математика
Topics EN: mathematics
Headings: AJALUGU

## LIPU HEISKAMINE
URL: https://www.opiq.ee/kit/118/chapter/5975
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.4
Topics ET: matemaatika, lipu, heiskamine, pikk, hermann, kõrge
Topics RU: математика
Topics EN: mathematics
Headings: LIPU HEISKAMINE; Pikk Hermann; Kui kõrge on Pikk Hermann?

## MIKS TALLINN IIAL VALMIS EI TOHI SAADA
URL: https://www.opiq.ee/kit/118/chapter/5976
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.5
Topics ET: matemaatika, miks, tallinn, iial, valmis, tohi, saada
Topics RU: математика
Topics EN: mathematics
Headings: MIKS TALLINN IIAL VALMIS EI TOHI SAADA

## KÖRDIKIRJA LAENAMAS
URL: https://www.opiq.ee/kit/118/chapter/5977
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.6
Topics ET: matemaatika, kördikirja, laenamas
Topics RU: математика
Topics EN: mathematics
Headings: KÖRDIKIRJA LAENAMAS

## LAULUPEOL
URL: https://www.opiq.ee/kit/118/chapter/5978
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.7
Topics ET: matemaatika, laulupeol
Topics RU: математика
Topics EN: mathematics
Headings: LAULUPEOL

## PÄÄSUKE
URL: https://www.opiq.ee/kit/118/chapter/5979
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 21.8
Topics ET: matemaatika, pääsuke
Topics RU: математика
Topics EN: mathematics
Headings: PÄÄSUKE

## TULEN, TULEN
URL: https://www.opiq.ee/kit/118/chapter/5980
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 22.1
Topics ET: matemaatika, tulen
Topics RU: математика
Topics EN: mathematics
Headings: TULEN, TULEN

## RONGISÕIT. RATASTE LAUL
URL: https://www.opiq.ee/kit/118/chapter/5981
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 22.2
Topics ET: matemaatika, rongisõit, rataste, laul
Topics RU: математика
Topics EN: mathematics
Headings: RONGISÕIT. RATASTE LAUL

## MINEK
URL: https://www.opiq.ee/kit/118/chapter/5982
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 22.3
Topics ET: matemaatika, minek
Topics RU: математика
Topics EN: mathematics
Headings: MINEK

## KEVAD KARUKÜLAS
URL: https://www.opiq.ee/kit/118/chapter/5985
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 22.4
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, karukülas
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: KEVAD KARUKÜLAS

## NÕGESELIBLIKAS JA KÄRBES
URL: https://www.opiq.ee/kit/118/chapter/5983
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 22.5
Topics ET: matemaatika, nõgeseliblikas, kärbes
Topics RU: математика
Topics EN: mathematics
Headings: NÕGESELIBLIKAS JA KÄRBES

## LINDUDE LAULUD
URL: https://www.opiq.ee/kit/118/chapter/5984
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 22.6
Topics ET: matemaatika, lindude, laulud, jutusta, kevadest
Topics RU: математика
Topics EN: mathematics
Headings: LINDUDE LAULUD; Jutusta kevadest

## Kontrolltöö 6
URL: https://www.opiq.ee/kit/118/chapter/20802
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 22.7
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 6

## PÜHADE OOTEL
URL: https://www.opiq.ee/kit/118/chapter/5986
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 23.1
Topics ET: matemaatika, pühade, ootel, asesõnad
Topics RU: математика
Topics EN: mathematics
Headings: PÜHADE OOTEL; Asesõnad

## JÄNES TRAMMIS
URL: https://www.opiq.ee/kit/118/chapter/5987
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 23.2
Topics ET: matemaatika, jänes, trammis
Topics RU: математика
Topics EN: mathematics
Headings: JÄNES TRAMMIS

## LIHAVÕTTED BULLERBYS
URL: https://www.opiq.ee/kit/118/chapter/5988
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 23.3
Topics ET: matemaatika, lihavõtted, bullerbys, tulbikett
Topics RU: математика
Topics EN: mathematics
Headings: LIHAVÕTTED BULLERBYS; Tulbikett

## ISA SOKID
URL: https://www.opiq.ee/kit/118/chapter/5989
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 23.4
Topics ET: matemaatika, sokid
Topics RU: математика
Topics EN: mathematics
Headings: ISA SOKID

## ...
URL: https://www.opiq.ee/kit/118/chapter/5990
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 24.1
Topics ET: matemaatika, lõbus, lausemäng
Topics RU: математика
Topics EN: mathematics
Headings: ...; Lõbus lausemäng

## LUISKAJA
URL: https://www.opiq.ee/kit/118/chapter/5991
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 24.2
Topics ET: matemaatika, luiskaja
Topics RU: математика
Topics EN: mathematics
Headings: LUISKAJA

## VÄIKESTE POISTE PESEMISÕPETUS
URL: https://www.opiq.ee/kit/118/chapter/5992
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 24.3
Topics ET: matemaatika, väikeste, poiste, pesemisõpetus
Topics RU: математика
Topics EN: mathematics
Headings: VÄIKESTE POISTE PESEMISÕPETUS

## SIUKE PÕIS
URL: https://www.opiq.ee/kit/118/chapter/5994
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 24.4
Topics ET: matemaatika, siuke, põis
Topics RU: математика
Topics EN: mathematics
Headings: SIUKE PÕIS

## KIIRJOOKSJAD
URL: https://www.opiq.ee/kit/118/chapter/5993
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 24.5
Topics ET: matemaatika, kiirjooksjad
Topics RU: математика
Topics EN: mathematics
Headings: KIIRJOOKSJAD

## KEHA VAJAB VITAMIINE
URL: https://www.opiq.ee/kit/118/chapter/5995
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, vajab, vitamiine
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: KEHA VAJAB VITAMIINE

## Kuidas tekivad sõnad
URL: https://www.opiq.ee/kit/118/chapter/5996
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.2
Topics ET: matemaatika, kuidas, tekivad, sõnad
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas tekivad sõnad

## KARUPOJA KOOGITEGU
URL: https://www.opiq.ee/kit/118/chapter/5997
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.3
Topics ET: matemaatika, karupoja, koogitegu
Topics RU: математика
Topics EN: mathematics
Headings: KARUPOJA KOOGITEGU

## TOONEKURE TOIDUVAHELDUS
URL: https://www.opiq.ee/kit/118/chapter/5998
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.4
Topics ET: matemaatika, toonekure, toiduvaheldus
Topics RU: математика
Topics EN: mathematics
Headings: TOONEKURE TOIDUVAHELDUS

## SAMMELI, EPP JA MINA
URL: https://www.opiq.ee/kit/118/chapter/5999
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.5
Topics ET: matemaatika, sammeli, mina
Topics RU: математика
Topics EN: mathematics
Headings: SAMMELI, EPP JA MINA

## PUDER
URL: https://www.opiq.ee/kit/118/chapter/6000
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.6
Topics ET: matemaatika, puder
Topics RU: математика
Topics EN: mathematics
Headings: PUDER

## ERNST ENNO
URL: https://www.opiq.ee/kit/118/chapter/6001
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.7
Topics ET: matemaatika, ernst, enno
Topics RU: математика
Topics EN: mathematics
Headings: ERNST ENNO

## Kontrolltöö 7
URL: https://www.opiq.ee/kit/118/chapter/20803
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 25.8
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 7

## PALAVIK
URL: https://www.opiq.ee/kit/118/chapter/6002
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 26.1
Topics ET: matemaatika, palavik
Topics RU: математика
Topics EN: mathematics
Headings: PALAVIK

## Sõnade liitmise mäng
URL: https://www.opiq.ee/kit/118/chapter/6006
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 26.2
Topics ET: matemaatika, sõnade, liitmise, mäng
Topics RU: математика
Topics EN: mathematics
Headings: Sõnade liitmise mäng

## HAIGLAS
URL: https://www.opiq.ee/kit/118/chapter/6003
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 26.3
Topics ET: matemaatika, haiglas
Topics RU: математика
Topics EN: mathematics
Headings: HAIGLAS

## OPERATSIOON
URL: https://www.opiq.ee/kit/118/chapter/6004
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 26.4
Topics ET: matemaatika, operatsioon
Topics RU: математика
Topics EN: mathematics
Headings: OPERATSIOON

## VAENE VÄIKE HAMBAARST
URL: https://www.opiq.ee/kit/118/chapter/6005
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 26.5
Topics ET: matemaatika, vaene, väike, hambaarst
Topics RU: математика
Topics EN: mathematics
Headings: VAENE VÄIKE HAMBAARST

## KUI MA ÜKSKORD HAIGE OLIN
URL: https://www.opiq.ee/kit/118/chapter/6007
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 27.1
Topics ET: matemaatika, ükskord, haige, olin
Topics RU: математика
Topics EN: mathematics
Headings: KUI MA ÜKSKORD HAIGE OLIN

## KAAREL TEAB
URL: https://www.opiq.ee/kit/118/chapter/6008
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 27.2
Topics ET: matemaatika, kaarel, teab
Topics RU: математика
Topics EN: mathematics
Headings: KAAREL TEAB

## LEPPIMINE
URL: https://www.opiq.ee/kit/118/chapter/6009
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 27.3
Topics ET: matemaatika, leppimine
Topics RU: математика
Topics EN: mathematics
Headings: LEPPIMINE

## JÄNESE MÄNGUTOOS
URL: https://www.opiq.ee/kit/118/chapter/6010
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 27.4
Topics ET: matemaatika, jänese, mängutoos
Topics RU: математика
Topics EN: mathematics
Headings: JÄNESE MÄNGUTOOS

## Millal sõnu poolitada?
URL: https://www.opiq.ee/kit/118/chapter/6011
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 27.5
Topics ET: matemaatika, millal, sõnu, poolitada
Topics RU: математика
Topics EN: mathematics
Headings: Millal sõnu poolitada?

## HAIGEVOODIS
URL: https://www.opiq.ee/kit/118/chapter/6012
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 27.6
Topics ET: matemaatika, haigevoodis
Topics RU: математика
Topics EN: mathematics
Headings: HAIGEVOODIS

## MILLIST LAULU VAJAVAD EMAD?
URL: https://www.opiq.ee/kit/118/chapter/6013
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.1
Topics ET: matemaatika, millist, laulu, vajavad, emad, lilled, emale
Topics RU: математика
Topics EN: mathematics
Headings: MILLIST LAULU VAJAVAD EMAD?; Lilled emale

## MÕNIKORD MA MÕTLEN
URL: https://www.opiq.ee/kit/118/chapter/6014
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.2
Topics ET: matemaatika, mõnikord, mõtlen
Topics RU: математика
Topics EN: mathematics
Headings: MÕNIKORD MA MÕTLEN

## TRIINU JA TAAVI EMA
URL: https://www.opiq.ee/kit/118/chapter/6015
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.3
Topics ET: matemaatika, triinu, taavi
Topics RU: математика
Topics EN: mathematics
Headings: TRIINU JA TAAVI EMA

## LAURI EMADEPÄEVA KINGITUS
URL: https://www.opiq.ee/kit/118/chapter/6016
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.4
Topics ET: matemaatika, lauri, emadepäeva, kingitus
Topics RU: математика
Topics EN: mathematics
Headings: LAURI EMADEPÄEVA KINGITUS

## OMATEHTUD KOTLET
URL: https://www.opiq.ee/kit/118/chapter/6017
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.5
Topics ET: matemaatika, omatehtud, kotlet
Topics RU: математика
Topics EN: mathematics
Headings: OMATEHTUD KOTLET

## AASAL ÕITSEB MAHLAKANN
URL: https://www.opiq.ee/kit/118/chapter/6019
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.6
Topics ET: matemaatika, aasal, õitseb, mahlakann
Topics RU: математика
Topics EN: mathematics
Headings: AASAL ÕITSEB MAHLAKANN

## TÄPILINE KLEIT
URL: https://www.opiq.ee/kit/118/chapter/6020
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.7
Topics ET: matemaatika, täpiline, kleit
Topics RU: математика
Topics EN: mathematics
Headings: TÄPILINE KLEIT

## KUIDAS KONN SAI HÜPPAMISE SELGEKS
URL: https://www.opiq.ee/kit/118/chapter/6018
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.8
Topics ET: matemaatika, kuidas, konn, hüppamise, selgeks, väit, küsi, hüüdlause
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS KONN SAI HÜPPAMISE SELGEKS; Väit-, küsi- ja hüüdlause

## Kontrolltöö 8
URL: https://www.opiq.ee/kit/118/chapter/20804
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 28.9
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 8

## LÕBUS SUVI
URL: https://www.opiq.ee/kit/118/chapter/6029
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, lõbus
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: LÕBUS SUVI

## SUVI
URL: https://www.opiq.ee/kit/118/chapter/6031
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.10
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: SUVI

## Kordamis- ja lisaharjutusi
URL: https://www.opiq.ee/kit/118/chapter/6028
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.11
Topics ET: matemaatika, kordamis, lisaharjutusi
Topics RU: математика
Topics EN: mathematics
Headings: Kordamis- ja lisaharjutusi

## Kontrolltöö 9
URL: https://www.opiq.ee/kit/118/chapter/20805
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.12
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 9

## Koolitund õues
URL: https://www.opiq.ee/kit/118/chapter/6021
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.2
Topics ET: matemaatika, koolitund, õues
Topics RU: математика
Topics EN: mathematics
Headings: Koolitund õues

## MATKAL
URL: https://www.opiq.ee/kit/118/chapter/6022
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.3
Topics ET: matemaatika, matkal
Topics RU: математика
Topics EN: mathematics
Headings: MATKAL

## PIPI KORRALDAB VÄLJASÕIDU
URL: https://www.opiq.ee/kit/118/chapter/6023
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.4
Topics ET: matemaatika, pipi, korraldab, väljasõidu
Topics RU: математика
Topics EN: mathematics
Headings: PIPI KORRALDAB VÄLJASÕIDU

## LINNUPESA
URL: https://www.opiq.ee/kit/118/chapter/6024
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.5
Topics ET: matemaatika, linnupesa
Topics RU: математика
Topics EN: mathematics
Headings: LINNUPESA

## KINGPOOL JA RÄSTIK
URL: https://www.opiq.ee/kit/118/chapter/6025
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.6
Topics ET: matemaatika, kingpool, rästik
Topics RU: математика
Topics EN: mathematics
Headings: KINGPOOL JA RÄSTIK

## AJALEHT LAANE ELU
URL: https://www.opiq.ee/kit/118/chapter/6026
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.7
Topics ET: matemaatika, ajaleht, laane
Topics RU: математика
Topics EN: mathematics
Headings: AJALEHT LAANE ELU

## LEGEND VALGEST DAAMIST
URL: https://www.opiq.ee/kit/118/chapter/6030
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.8
Topics ET: matemaatika, legend, valgest, daamist
Topics RU: математика
Topics EN: mathematics
Headings: LEGEND VALGEST DAAMIST

## VAESE POISI ÕNN
URL: https://www.opiq.ee/kit/118/chapter/6027
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 29.9
Topics ET: matemaatika, vaese, poisi
Topics RU: математика
Topics EN: mathematics
Headings: VAESE POISI ÕNN

## TALISMAN
URL: https://www.opiq.ee/kit/118/chapter/5877
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 3.1
Topics ET: matemaatika, talisman
Topics RU: математика
Topics EN: mathematics
Headings: TALISMAN

## MAAL
URL: https://www.opiq.ee/kit/118/chapter/5873
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 3.2
Topics ET: matemaatika, maal
Topics RU: математика
Topics EN: mathematics
Headings: MAAL

## IMERANITS
URL: https://www.opiq.ee/kit/118/chapter/5878
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 3.3
Topics ET: matemaatika, imeranits
Topics RU: математика
Topics EN: mathematics
Headings: IMERANITS

## SEGADUS TUNNIS
URL: https://www.opiq.ee/kit/118/chapter/5874
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 3.4
Topics ET: matemaatika, segadus, tunnis, tunni, ajal, vaja, taskutelefoni, kasutada
Topics RU: математика
Topics EN: mathematics
Headings: SEGADUS TUNNIS; Kas tunni ajal on vaja taskutelefoni kasutada?

## MAIDU JA LAURI PLASTILIIN
URL: https://www.opiq.ee/kit/118/chapter/5875
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 3.5
Topics ET: matemaatika, maidu, lauri, plastiliin
Topics RU: математика
Topics EN: mathematics
Headings: MAIDU JA LAURI PLASTILIIN

## KUIDAS ONU ÖÖBIK SEENEL KÄIB
URL: https://www.opiq.ee/kit/118/chapter/5876
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 3.6
Topics ET: matemaatika, kuidas, ööbik, seenel, käib, jutusta, sügisest, pildi, küsimuste, abil
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS ONU ÖÖBIK SEENEL KÄIB; Jutusta sügisest pildi ja küsimuste abil

## Sõnaseletused
URL: https://www.opiq.ee/kit/118/chapter/6032
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 30.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## TERE, KOOL
URL: https://www.opiq.ee/kit/118/chapter/5883
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 4.1
Topics ET: matemaatika, tere, kool
Topics RU: математика
Topics EN: mathematics
Headings: TERE, KOOL

## KUIDAS PAULA LUULETUST ÕPPIS
URL: https://www.opiq.ee/kit/118/chapter/5879
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 4.2
Topics ET: matemaatika, kuidas, paula, luuletust, õppis
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS PAULA LUULETUST ÕPPIS

## AINO PERVIK
URL: https://www.opiq.ee/kit/118/chapter/5880
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 4.3
Topics ET: matemaatika, aino, pervik
Topics RU: математика
Topics EN: mathematics
Headings: AINO PERVIK

## MISTER X TULEB KLASSI
URL: https://www.opiq.ee/kit/118/chapter/5881
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 4.4
Topics ET: matemaatika, mister, tuleb, klassi
Topics RU: математика
Topics EN: mathematics
Headings: MISTER X TULEB KLASSI

## ARGENTIINA KOOL
URL: https://www.opiq.ee/kit/118/chapter/5882
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 4.5
Topics ET: matemaatika, argentiina, kool
Topics RU: математика
Topics EN: mathematics
Headings: ARGENTIINA KOOL

## Kontrolltöö 1
URL: https://www.opiq.ee/kit/118/chapter/20794
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 4.6
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 1

## SÕBER
URL: https://www.opiq.ee/kit/118/chapter/5884
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 5.1
Topics ET: matemaatika, sõber, pinginaaber, täishäälikuühend
Topics RU: математика
Topics EN: mathematics
Headings: SÕBER; PINGINAABER; Täishäälikuühend

## USS JA VANAKURAT
URL: https://www.opiq.ee/kit/118/chapter/5885
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 5.2
Topics ET: matemaatika, vanakurat
Topics RU: математика
Topics EN: mathematics
Headings: USS JA VANAKURAT

## KADUNUD MUDELAUTO
URL: https://www.opiq.ee/kit/118/chapter/5886
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 5.3
Topics ET: matemaatika, kadunud, mudelauto
Topics RU: математика
Topics EN: mathematics
Headings: KADUNUD MUDELAUTO

## KAKLUS
URL: https://www.opiq.ee/kit/118/chapter/5887
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 5.4
Topics ET: matemaatika, kaklus
Topics RU: математика
Topics EN: mathematics
Headings: KAKLUS

## ÕNN
URL: https://www.opiq.ee/kit/118/chapter/5888
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: ÕNN

## KUIDAS VÄIKE PAPA TÜDRUKUGA SÕBRUSTAS
URL: https://www.opiq.ee/kit/118/chapter/5889
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 6.2
Topics ET: matemaatika, kuidas, väike, papa, tüdrukuga, sõbrustas
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS VÄIKE PAPA TÜDRUKUGA SÕBRUSTAS

## ÜKS NÄIDE SELLEST, KUIDAS VANAL AJAL TÜLITSETI
URL: https://www.opiq.ee/kit/118/chapter/5890
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 6.3
Topics ET: matemaatika, näide, sellest, kuidas, vanal, ajal, tülitseti
Topics RU: математика
Topics EN: mathematics
Headings: ÜKS NÄIDE SELLEST, KUIDAS VANAL AJAL TÜLITSETI

## KUIDAS VANAL AJAL VALETATI JA MIS SIIS SAI, KUI SEE VÄLJA TULI
URL: https://www.opiq.ee/kit/118/chapter/5891
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 6.4
Topics ET: matemaatika, kuidas, vanal, ajal, valetati, siis, välja, tuli
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS VANAL AJAL VALETATI JA MIS SIIS SAI, KUI SEE VÄLJA TULI

## HUNDITUBAKAS
URL: https://www.opiq.ee/kit/118/chapter/5892
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 7.1
Topics ET: matemaatika, hunditubakas
Topics RU: математика
Topics EN: mathematics
Headings: HUNDITUBAKAS

## METSATULEKAHJU
URL: https://www.opiq.ee/kit/118/chapter/5893
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 7.2
Topics ET: matemaatika, metsatulekahju
Topics RU: математика
Topics EN: mathematics
Headings: METSATULEKAHJU

## MIS ON KÕIGE KOLEDAM?
URL: https://www.opiq.ee/kit/118/chapter/5894
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 7.3
Topics ET: matemaatika, kõige, koledam
Topics RU: математика
Topics EN: mathematics
Headings: MIS ON KÕIGE KOLEDAM?

## TORMI KÄES
URL: https://www.opiq.ee/kit/118/chapter/5895
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 7.4
Topics ET: matemaatika, tormi, käes
Topics RU: математика
Topics EN: mathematics
Headings: TORMI KÄES

## Kontrolltöö 2
URL: https://www.opiq.ee/kit/118/chapter/20795
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 7.5
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 2

## KODU
URL: https://www.opiq.ee/kit/118/chapter/5896
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 8.1
Topics ET: matemaatika, kodu, kirilli
Topics RU: математика
Topics EN: mathematics
Headings: KODU; Kirilli kodu

## LEELO TUNGAL
URL: https://www.opiq.ee/kit/118/chapter/20796
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 8.2
Topics ET: matemaatika, leelo, tungal
Topics RU: математика
Topics EN: mathematics
Headings: LEELO TUNGAL

## HINGEDEPÄEV
URL: https://www.opiq.ee/kit/118/chapter/5897
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 8.3
Topics ET: matemaatika, hingedepäev
Topics RU: математика
Topics EN: mathematics
Headings: HINGEDEPÄEV

## KURBUSEST VANAL AJAL
URL: https://www.opiq.ee/kit/118/chapter/5898
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 8.4
Topics ET: matemaatika, kurbusest, vanal, ajal
Topics RU: математика
Topics EN: mathematics
Headings: KURBUSEST VANAL AJAL

## SUURTE INIMESTE JUTUD
URL: https://www.opiq.ee/kit/118/chapter/5899
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 8.5
Topics ET: matemaatika, suurte, inimeste, jutud
Topics RU: математика
Topics EN: mathematics
Headings: SUURTE INIMESTE JUTUD

## VÄIKEVENNA PARIM SÜNNIPÄEVAKINK
URL: https://www.opiq.ee/kit/118/chapter/5900
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 8.6
Topics ET: matemaatika, väikevenna, parim, sünnipäevakink
Topics RU: математика
Topics EN: mathematics
Headings: VÄIKEVENNA PARIM SÜNNIPÄEVAKINK

## KODUKATSIKUD
URL: https://www.opiq.ee/kit/118/chapter/5901
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 9.1
Topics ET: matemaatika, kodukatsikud, õnnitlus, teade, kutse
Topics RU: математика
Topics EN: mathematics
Headings: KODUKATSIKUD; Õnnitlus, teade või kutse?

## TRIINU JA TAAVI ISA
URL: https://www.opiq.ee/kit/118/chapter/5902
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 9.2
Topics ET: matemaatika, triinu, taavi
Topics RU: математика
Topics EN: mathematics
Headings: TRIINU JA TAAVI ISA

## PÄRIS ÕIGE MARDILAUPÄEV
URL: https://www.opiq.ee/kit/118/chapter/5903
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 9.3
Topics ET: matemaatika, päris, õige, mardilaupäev
Topics RU: математика
Topics EN: mathematics
Headings: PÄRIS ÕIGE MARDILAUPÄEV

## VÄIKESED MÄRDISANDID
URL: https://www.opiq.ee/kit/118/chapter/5904
Book: ILUS EMAKEEL 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_ilus_emake_2_et
Chapter ID: 9.4
Topics ET: matemaatika, väikesed, märdisandid
Topics RU: математика
Topics EN: mathematics
Headings: VÄIKESED MÄRDISANDID

## KOOS ON LÕBUS. Janno jutud – Opiq
URL: https://www.opiq.ee/Kit/Details/129
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 338
Topics ET: matemaatika, koos, lõbus, janno, jutud, opiq
Topics RU: математика
Topics EN: mathematics

## KOOS ON LÕBUS. Janno jutud – Opiq
URL: https://www.opiq.ee/Kit/Details/129
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 411
Topics ET: matemaatika, koos, lõbus, janno, jutud, opiq
Topics RU: математика
Topics EN: mathematics

## Sissejuhatus
URL: https://www.opiq.ee/kit/129/chapter/6944
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.1
Topics ET: matemaatika, sissejuhatus
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus

## Tere!
URL: https://www.opiq.ee/kit/129/chapter/6937
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.2
Topics ET: matemaatika, tere, vasta, küsimustele, loeme, koos, september, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Tere!; 1. VASTA KÜSIMUSTELE!; 2. E-ÜLESANNE; E-ül; 3. LOEME KOOS!; 1. september; 4. RÄÄGI!

## Suvevaheaeg
URL: https://www.opiq.ee/kit/129/chapter/6938
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.3
Topics ET: matemaatika, suvevaheaeg, sõnad, puudu, loeme, koos, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Suvevaheaeg; 1. MIS SÕNAD ON PUUDU?; E-ül; 2. LOEME KOOS!; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## Uus klassikaaslane
URL: https://www.opiq.ee/kit/129/chapter/6939
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.4
Topics ET: matemaatika, klassikaaslane, õige, vale, loeme, koos, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Uus klassikaaslane; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; 3. RÄÄGI!; LISAÜLESANNE 1

## Uus õpetaja
URL: https://www.opiq.ee/kit/129/chapter/6940
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.5
Topics ET: matemaatika, lõpeta, laused, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Uus õpetaja; 1. LÕPETA LAUSED!; E-ül; 2. RÄÄGI SÕBRAGA!

## Minu klass
URL: https://www.opiq.ee/kit/129/chapter/6941
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.6
Topics ET: matemaatika, klass, vasta, küsimustele, vaata, pilte, räägi, jutusta, sinu, klassis
Topics RU: математика
Topics EN: mathematics
Headings: Minu klass; 1. VASTA KÜSIMUSTELE!; 2. VAATA PILTE JA RÄÄGI!; 3. JUTUSTA, MIS ON SINU KLASSIS!; 4. E-ÜLESANNE; E-ül

## Mis on koolikotis?
URL: https://www.opiq.ee/kit/129/chapter/6942
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.7
Topics ET: matemaatika, koolikotis, valesti, vaata, ütle, loeme, koos, seljakott, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Mis on koolikotis?; 1. MIS ON VALESTI?; E-ül; 2. VAATA JA ÜTLE, MIS ON KOOLIKOTIS!; 3. LOEME KOOS!; Ott ja seljakott; 4. RÄÄGI SÕBRAGA!; 5. E-ÜLESANNE; LISAÜLESANNE 1

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/6943
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 1.8
Topics ET: matemaatika, nüüd, oskan, räägi, loeme, koos, mida, teeb
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. LOEME KOOS!; 3. KES MIDA TEEB? RÄÄGI!; 4. RÄÄGI!; 5. E-ÜLESANNE; E-ül

## Mänguväljak
URL: https://www.opiq.ee/kit/129/chapter/6945
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 2.1
Topics ET: matemaatika, mänguväljak, õige, vale, kordame, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Mänguväljak; 1. ÕIGE VÕI VALE?; E-ül; 2. KORDAME!; 3. RÄÄGI!; 4. E-ÜLESANNE; LISAÜLESANNE 1

## Lähme turule!
URL: https://www.opiq.ee/kit/129/chapter/6946
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 2.2
Topics ET: matemaatika, lähme, turule, mõelge, jutu, kohta, kolm, küsimust, loeme, koos
Topics RU: математика
Topics EN: mathematics
Headings: Lähme turule!; 1. MÕELGE JUTU KOHTA KOLM KÜSIMUST!; 2. LOEME KOOS!; 3. VAATA JA LOE!; 4. RÄÄGI SÕBRAGA!; 5. E-ÜLESANNE; E-ül

## Põnev tund
URL: https://www.opiq.ee/kit/129/chapter/6947
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 2.3
Topics ET: matemaatika, põnev, tund, mõelge, jutu, kohta, kolm, küsimust, vaata, loeme
Topics RU: математика
Topics EN: mathematics
Headings: Põnev tund; 1. MÕELGE JUTU KOHTA KOLM KÜSIMUST!; 2. VAATA JA LOE!; 3. LOEME KOOS!; Õnnelik porgand; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Kui õues sajab vihma
URL: https://www.opiq.ee/kit/129/chapter/6948
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 2.4
Topics ET: matemaatika, õues, sajab, vihma, vasta, küsimustele, loeme, koos, naeris, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Kui õues sajab vihma; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; Naeris naeris; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Sõidame rongiga
URL: https://www.opiq.ee/kit/129/chapter/6949
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 2.5
Topics ET: matemaatika, sõidame, rongiga, lõpeta, laused, laulame, koos, rongisõit, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Sõidame rongiga; 1. LÕPETA LAUSED!; 2. LAULAME KOOS!; Rongisõit; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Vanaema ja vanaisa juures
URL: https://www.opiq.ee/kit/129/chapter/6950
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 2.6
Topics ET: matemaatika, vanaema, vanaisa, juures, vali, õige, vastus, kirjuta, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Vanaema ja vanaisa juures; 1. VALI ÕIGE VASTUS!; E-ül; 2. KIRJUTA!; LISAÜLESANNE 1

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/6951
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 2.7
Topics ET: matemaatika, nüüd, oskan, räägi, loeme, koos, saunas, sobib, lünka
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. LOEME KOOS!; Saunas; 3. MIS SOBIB LÜNKA?; E-ül; 4. RÄÄGI!; 5. E-ÜLESANNE

## Minu pere
URL: https://www.opiq.ee/kit/129/chapter/6952
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.1
Topics ET: matemaatika, loom, loomad, linnud, putukad, pere, mõelge, jutu, kohta, kolm, küsimust, vaata, loomaaias
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Minu pere; 1. MÕELGE JUTU KOHTA KOLM KÜSIMUST!; 2. VAATA JA LOE, MIS LOOMAD ON LOOMAAIAS!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Kassipoeg
URL: https://www.opiq.ee/kit/129/chapter/6953
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.2
Topics ET: matemaatika, kassipoeg, vasta, küsimustele, loeme, koos, tass, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Kassipoeg; 1. VASTA KÜSIMUSTELE!; 2. E-ÜLESANNE; E-ül; 3. LOEME KOOS!; Tass; 4. KIRJUTA!

## Ma hoolitsen Miisu eest
URL: https://www.opiq.ee/kit/129/chapter/6954
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.3
Topics ET: matemaatika, hoolitsen, miisu, eest, jutusta, vaata, pilti, räägi, kelle, hoolitsed
Topics RU: математика
Topics EN: mathematics
Headings: Ma hoolitsen Miisu eest; 1. JUTUSTA!; 2. VAATA PILTI! RÄÄGI, KELLE EEST SA HOOLITSED!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Miisu teeb pahandust
URL: https://www.opiq.ee/kit/129/chapter/6955
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.4
Topics ET: matemaatika, miisu, teeb, pahandust, lõpeta, laused, loeme, koos, kass, küsib
Topics RU: математика
Topics EN: mathematics
Headings: Miisu teeb pahandust; 1. LÕPETA LAUSED!; 2. LOEME KOOS!; Kass küsib piima; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Enne mardipäeva
URL: https://www.opiq.ee/kit/129/chapter/6956
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.5
Topics ET: matemaatika, enne, mardipäeva, mõelge, teksti, kohta, kolm, küsimust, laulame, koos
Topics RU: математика
Topics EN: mathematics
Headings: Enne mardipäeva; 1. MÕELGE TEKSTI KOHTA KOLM KÜSIMUST!; 2. LAULAME KOOS!; Mardilaul; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Me jookseme marti
URL: https://www.opiq.ee/kit/129/chapter/6957
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.6
Topics ET: matemaatika, jookseme, marti, vasta, küsimustele, ütle, mida, mardisandid, kingiks, saavad
Topics RU: математика
Topics EN: mathematics
Headings: Me jookseme marti; 1. VASTA KÜSIMUSTELE!; 2. ÜTLE, MIDA MARDISANDID KINGIKS SAAVAD.; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Ametid
URL: https://www.opiq.ee/kit/129/chapter/6958
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.7
Topics ET: matemaatika, ametid, õige, vale, vaata, pilti, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Ametid; 1. ÕIGE VÕI VALE?; E-ül; 2. VAATA PILTI, LOE JA RÄÄGI!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/6959
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 3.8
Topics ET: matemaatika, nüüd, oskan, räägi, lõpeta, laused, laulame, koos, väiksed, kalad
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. LÕPETA LAUSED! RÄÄGI!; 3. LAULAME KOOS!; Väiksed kalad; 4. RÄÄGI!; 5. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Ma aitan ema
URL: https://www.opiq.ee/kit/129/chapter/6960
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.1
Topics ET: matemaatika, aitan, loeme, koos, räägi, mida, tegi, kirjuta, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Ma aitan ema; 1. LOEME KOOS!; 2. RÄÄGI, KES MIDA TEGI!; 3. KIRJUTA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Ma aitan isa
URL: https://www.opiq.ee/kit/129/chapter/6961
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.2
Topics ET: matemaatika, aitan, vasta, küsimustele, loeme, koos, naerulind, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Ma aitan isa; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; Naerulind; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Mulle meeldib uisutada
URL: https://www.opiq.ee/kit/129/chapter/6962
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.3
Topics ET: matemaatika, mulle, meeldib, uisutada, lõpeta, laused, loeme, koos, jõulusoov, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Mulle meeldib uisutada; 1. LÕPETA LAUSED!; 2. LOEME KOOS!; Jõulusoov; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Teeme lumememme
URL: https://www.opiq.ee/kit/129/chapter/6963
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.4
Topics ET: matemaatika, teeme, lumememme, õige, vale, loeme, koos, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Teeme lumememme; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; Kes see on?; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## Laat
URL: https://www.opiq.ee/kit/129/chapter/6964
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.5
Topics ET: matemaatika, laat, jutusta, palju, maksab, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Laat; 1. JUTUSTA!; 2. KUI PALJU MAKSAB?; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Teeme koertele kingituse
URL: https://www.opiq.ee/kit/129/chapter/6965
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.6
Topics ET: matemaatika, teeme, koertele, kingituse, mõelge, kolm, küsimust, lõpeta, laused, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Teeme koertele kingituse; 1. MÕELGE KOLM KÜSIMUST!; 2. LÕPETA LAUSED!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Jõulud
URL: https://www.opiq.ee/kit/129/chapter/6966
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.7
Topics ET: matemaatika, jõulud, õige, vale, laulame, koos, jõulupiparkook, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Jõulud; 1. ÕIGE VÕI VALE?; E-ül; 2. LAULAME KOOS!; Jõulupiparkook; 3. KIRJUTA!

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/6967
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 4.8
Topics ET: matemaatika, nüüd, oskan, räägi, sõnad, puudu, loeme, koos, väike, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. MIS SÕNAD ON PUUDU?; E-ül; 3. LOEME KOOS!; Väike kuusk; 4. RÄÄGI!; 5. E-ÜLESANNE

## Vaheajal käis jõuluvana
URL: https://www.opiq.ee/kit/129/chapter/6968
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.1
Topics ET: matemaatika, vaheajal, käis, jõuluvana, vasta, küsimustele, mida, tegid, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Vaheajal käis jõuluvana; 1. VASTA KÜSIMUSTELE!; 2. MIDA SA TEGID? RÄÄGI!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/6977
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.10
Topics ET: matemaatika, nüüd, oskan, räägi, sõnad, puudu, mida, sina, teha, oskad
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. MIS SÕNAD ON PUUDU?; E-ül; 3. MIDA SINA TEHA OSKAD?; 4. RÄÄGI!; 5. E-ÜLESANNE; LISAÜLESANNE 1

## Ehitame lumelinna
URL: https://www.opiq.ee/kit/129/chapter/6969
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.2
Topics ET: matemaatika, ehitame, lumelinna, räägi, mida, keegi, tegi, loeme, koos, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Ehitame lumelinna; 1. RÄÄGI, MIDA KEEGI TEGI!; 2. LOEME KOOS!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Lumelinn
URL: https://www.opiq.ee/kit/129/chapter/6970
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.3
Topics ET: matemaatika, lumelinn, küsi, sõbralt, vaata, pilti, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Lumelinn; 1. KÜSI SÕBRALT!; 2. VAATA PILTI!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Piial on hääl ära
URL: https://www.opiq.ee/kit/129/chapter/6971
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.4
Topics ET: matemaatika, piial, hääl, õige, vale, loeme, koos, laulutunnis, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Piial on hääl ära; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; Laulutunnis; 3. RÄÄGI!

## Terve nagu purikas
URL: https://www.opiq.ee/kit/129/chapter/6972
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.5
Topics ET: matemaatika, terve, nagu, purikas, lõpeta, laused, loeme, koos, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Terve nagu purikas; 1. LÕPETA LAUSED!; 2. LOEME KOOS!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Koome salli
URL: https://www.opiq.ee/kit/129/chapter/6973
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.6
Topics ET: matemaatika, koome, salli, küsi, sõbralt, loeme, koos, lõngakerad, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Koome salli; 1. KÜSI SÕBRALT!; 2. LOEME KOOS!; Lõngakerad; 3. KIRJUTA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Sall
URL: https://www.opiq.ee/kit/129/chapter/6974
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.7
Topics ET: matemaatika, sall, vasta, küsimustele, mida, sina, teha, oskad, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Sall; 1. VASTA KÜSIMUSTELE!; 2. MIDA SINA TEHA OSKAD?; E-ül; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## Teeme ise liuvälja
URL: https://www.opiq.ee/kit/129/chapter/6975
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.8
Topics ET: matemaatika, teeme, liuvälja, vasta, küsimustele, loeme, koos, jänese, jõulud, lõpeta
Topics RU: математика
Topics EN: mathematics
Headings: Teeme ise liuvälja; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; Jänese jõulud; 3. LÕPETA LAUSED!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Õpetaja saab haiget
URL: https://www.opiq.ee/kit/129/chapter/6976
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 5.9
Topics ET: matemaatika, saab, haiget, õige, vale, joonista, pilt, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Õpetaja saab haiget; 1. ÕIGE VÕI VALE?; E-ül; 2. JOONISTA PILT!; 3. RÄÄGI!; LISAÜLESANNE 1

## Ženja käis Peterburis
URL: https://www.opiq.ee/kit/129/chapter/6978
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.1
Topics ET: matemaatika, ženja, käis, peterburis, mõelge, teksti, kohta, kolm, küsimust, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Ženja käis Peterburis; 1. MÕELGE TEKSTI KOHTA KOLM KÜSIMUST!; 2. VAATA PILTI PEATÜKI ALGUSES. VASTA KÜSIMUSTELE!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/6987
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.10
Topics ET: matemaatika, nüüd, oskan, räägi, lõpeta, laused, tähed, sobivad, lünka, sulle
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. LÕPETA LAUSED! RÄÄGI!; 3. MIS TÄHED SOBIVAD LÜNKA?; E-ül; 4. MIS SULLE MAITSEB? MIS SULLE EI MAITSE?; 5. RÄÄGI SÕBRAGA!; 6. E-ÜLESANNE

## Onu Arvo
URL: https://www.opiq.ee/kit/129/chapter/6979
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.2
Topics ET: matemaatika, arvo, vasta, küsimustele, vaata, pilte, loeme, koos, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Onu Arvo; 1. VASTA KÜSIMUSTELE!; 2. VAATA PILTE!; E-ül; 3. LOEME KOOS!; 4. RÄÄGI!; 5. E-ÜLESANNE

## Teeme ise Eesti kaardi
URL: https://www.opiq.ee/kit/129/chapter/6980
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.3
Topics ET: matemaatika, teeme, eesti, kaardi, küsi, sõbralt, loeme, koos, vaadake, kaarti
Topics RU: математика
Topics EN: mathematics
Headings: Teeme ise Eesti kaardi; 1. KÜSI SÕBRALT!; 2. LOEME KOOS!; 3. VAADAKE KAARTI JA RÄÄKIGE!; 4. E-ÜLESANNE; E-ül

## Eesti linnad
URL: https://www.opiq.ee/kit/129/chapter/6981
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.4
Topics ET: matemaatika, eesti, linnad, loeme, koos, eestimaa, lõpeta, laused, vaata, kaarti
Topics RU: математика
Topics EN: mathematics
Headings: Eesti linnad; 1. LOEME KOOS!; Eestimaa; 2. LÕPETA LAUSED!; 3. VAATA KAARTI. RÄÄGI!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Külla tuleb Eesti president
URL: https://www.opiq.ee/kit/129/chapter/6982
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.5
Topics ET: matemaatika, külla, tuleb, eesti, president, õige, vale, loeme, koos, vabariigi
Topics RU: математика
Topics EN: mathematics
Headings: Külla tuleb Eesti president; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; Eesti vabariigi sünnipäev; 3. RÄÄGI SÕBRAGA!

## Põnev Saaremaa
URL: https://www.opiq.ee/kit/129/chapter/6983
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.6
Topics ET: matemaatika, põnev, saaremaa, vasta, küsimustele, millega, sõidad, kirjuta, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Põnev Saaremaa; 1. VASTA KÜSIMUSTELE!; 2. MILLEGA SA SÕIDAD?; E-ül; 3. KIRJUTA!; LISAÜLESANNE 1

## Vahva Tartu
URL: https://www.opiq.ee/kit/129/chapter/6984
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.7
Topics ET: matemaatika, vahva, tartu, lõpeta, laused, millega, keegi, sõidab, lause, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Vahva Tartu; 1. LÕPETA LAUSED!; 2. MILLEGA KEEGI SÕIDAB? LÕPETA LAUSE!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Soolased toidud
URL: https://www.opiq.ee/kit/129/chapter/6985
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.8
Topics ET: matemaatika, soolased, toidud, valesti, ütle, õigesti, toitu, sinu, teevad, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Soolased toidud; 1. MIS ON VALESTI? ÜTLE ÕIGESTI!; 2. MIS TOITU SINU EMA JA ISA TEEVAD?; E-ül; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## Magustoidud
URL: https://www.opiq.ee/kit/129/chapter/6986
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 6.9
Topics ET: matemaatika, magustoidud, mõelge, kolm, küsimust, toit, sulle, maitseb, loeme, koos
Topics RU: математика
Topics EN: mathematics
Headings: Magustoidud; 1. MÕELGE KOLM KÜSIMUST!; 2. MIS TOIT SULLE MAITSEB?; E-ül; 3. LOEME KOOS!; 4. RÄÄGI SÕBRAGA!

## Ma käin joonistamisringis
URL: https://www.opiq.ee/kit/129/chapter/6988
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.1
Topics ET: matemaatika, käin, joonistamisringis, vasta, küsimustele, loeme, koos, keda, mida, sulle
Topics RU: математика
Topics EN: mathematics
Headings: Ma käin joonistamisringis; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; 3. KEDA VÕI MIDA SULLE JOONISTADA MEELDIB?; 4. RÄÄGI!; 5. E-ÜLESANNE; E-ül

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/6997
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.10
Topics ET: matemaatika, aeg, kell, kalender, nüüd, oskan, räägi, vasta, küsimustele, ringis, trennis, sina
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. VASTA KÜSIMUSTELE!; 3. MIS KELL ON?; 4. MIS RINGIS/TRENNIS SINA KÄID?; 5. RÄÄGI SÕBRAGA!; 6. E-ÜLESANNE; E-ül

## Ma lähen trenni
URL: https://www.opiq.ee/kit/129/chapter/6989
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.2
Topics ET: matemaatika, lähen, trenni, valesti, ütle, õigesti, loeme, koos, käies, kord
Topics RU: математика
Topics EN: mathematics
Headings: Ma lähen trenni; 1. MIS ON VALESTI? ÜTLE ÕIGESTI!; 2. LOEME KOOS!; Käies kord köiel, kord kaarel; 3. MIS RINGIS/TRENNIS SINA KÄID?; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Me läheme teatrisse
URL: https://www.opiq.ee/kit/129/chapter/6990
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.3
Topics ET: matemaatika, läheme, teatrisse, lõpeta, laused, sina, oled, käinud, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Me läheme teatrisse; 1. LÕPETA LAUSED!; 2. KUS SINA OLED KÄINUD?; E-ül; 3. RÄÄGI SÕBRAGA!

## Ballett
URL: https://www.opiq.ee/kit/129/chapter/6991
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.4
Topics ET: matemaatika, ballett, küsi, sõbralt, loeme, koos, teater, tuli, külla, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Ballett; 1. KÜSI SÕBRALT!; 2. LOEME KOOS!; Teater tuli külla; 3. VAATA MENÜÜD!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Pükstes on auk
URL: https://www.opiq.ee/kit/129/chapter/6992
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.5
Topics ET: matemaatika, pükstes, õige, vale, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Pükstes on auk; 1. ÕIGE VÕI VALE?; E-ül; 2. TEE NII!; 3. KIRJUTA!

## Mis päev on?
URL: https://www.opiq.ee/kit/129/chapter/6993
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.6
Topics ET: matemaatika, päev, jutusta, loeme, koos, vasta, küsimustele
Topics RU: математика
Topics EN: mathematics
Headings: Mis päev on?; 1. JUTUSTA!; 2. LOEME KOOS!; 3. VASTA KÜSIMUSTELE!; 4. E-ÜLESANNE; E-ül

## Mis kell on?
URL: https://www.opiq.ee/kit/129/chapter/6994
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.7
Topics ET: matemaatika, aeg, kell, kalender, mõelge, kolm, küsimust, tuleta, meelde, räägi, sõbraga
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Mis kell on?; 1. MÕELGE KOLM KÜSIMUST!; 2. MIS KELL ON?; 3. TULETA MEELDE!; 4. RÄÄGI SÕBRAGA!; 5. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Sõbrad tulevad külla
URL: https://www.opiq.ee/kit/129/chapter/6995
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.8
Topics ET: matemaatika, sõbrad, tulevad, külla, vasta, küsimustele, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Sõbrad tulevad külla; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI SÕBRAGA!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Teeme näidendit
URL: https://www.opiq.ee/kit/129/chapter/6996
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 7.9
Topics ET: matemaatika, teeme, näidendit, õige, vale, loeme, koos, koer, poiss, plika
Topics RU: математика
Topics EN: mathematics
Headings: Teeme näidendit; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; Koer poiss ja plika

## Sõidame rattaga
URL: https://www.opiq.ee/kit/129/chapter/6998
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.1
Topics ET: matemaatika, sõidame, rattaga, vasta, küsimustele, kirjuta, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Sõidame rattaga; 1. VASTA KÜSIMUSTELE!; 2. KIRJUTA!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/129/chapter/7007
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.10
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, nüüd, oskan, räägi, loeme, koos, lõbus
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. LOEME KOOS!; Lõbus suvi; 3. E-ÜLESANNE; E-ül

## Ratas on katki
URL: https://www.opiq.ee/kit/129/chapter/6999
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.2
Topics ET: matemaatika, ratas, katki, lõpeta, laused, loeme, koos, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Ratas on katki; 1. LÕPETA LAUSED!; 2. LOEME KOOS!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Kes võidab?
URL: https://www.opiq.ee/kit/129/chapter/7000
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.3
Topics ET: matemaatika, võidab, küsi, sõbralt, loeme, koos, väike, salm, emale, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Kes võidab?; 1. KÜSI SÕBRALT!; 2. LOEME KOOS!; Väike salm emale; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Piknik
URL: https://www.opiq.ee/kit/129/chapter/7001
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.4
Topics ET: matemaatika, piknik, vasta, küsimustele, mida, sina, piknikul, sööd, jood, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Piknik; 1. VASTA KÜSIMUSTELE!; 2. MIDA SINA PIKNIKUL SÖÖD JA JOOD?; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Hakkame leiutama
URL: https://www.opiq.ee/kit/129/chapter/7002
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.5
Topics ET: matemaatika, hakkame, leiutama, õige, vale, kirjuta, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Hakkame leiutama; 1. ÕIGE VÕI VALE?; E-ül; 2. KIRJUTA!; 3. RÄÄGI SÕBRAGA!

## Leiutised
URL: https://www.opiq.ee/kit/129/chapter/7003
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.6
Topics ET: matemaatika, leiutised, jutusta, mida, kooli, kaasa, võtad, kirjuta, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Leiutised; 1. JUTUSTA!; 2. MIDA SA KOOLI KAASA VÕTAD?; E-ül; 3. KIRJUTA!; LISAÜLESANNE 1

## Tuulelohe
URL: https://www.opiq.ee/kit/129/chapter/7004
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.7
Topics ET: matemaatika, tuulelohe, mõelge, välja, kolm, küsimust, loeme, koos, lohepäev, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Tuulelohe; 1. MÕELGE VÄLJA KOLM KÜSIMUST!; 2. LOEME KOOS!; Lohepäev; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Lähme tuulelohet lennutama!
URL: https://www.opiq.ee/kit/129/chapter/7005
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.8
Topics ET: matemaatika, lähme, tuulelohet, lennutama, vasta, küsimustele, mida, lapsed, järve, ääres
Topics RU: математика
Topics EN: mathematics
Headings: Lähme tuulelohet lennutama!; 1. VASTA KÜSIMUSTELE!; 2. MIDA LAPSED JÄRVE ÄÄRES TEEVAD?; E-ül; 3. RÄÄGI SÕBRAGA!

## Suveplaanid
URL: https://www.opiq.ee/kit/129/chapter/7006
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 8.9
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, suveplaanid, küsi, sõbralt, loeme, koos, räägi, lisaülesanne
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Suveplaanid; 1. KÜSI SÕBRALT!; 2. LOEME KOOS!; Suvi; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Sõnastik
URL: https://www.opiq.ee/kit/129/chapter/7008
Book: KOOS ON LÕBUS 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_koos_on_lõ_2_et
Chapter ID: 9.1
Topics ET: matemaatika, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Sõnastik

## Mina loen ja kirjutan 2 – Opiq
URL: https://www.opiq.ee/Kit/Details/458
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 412
Topics ET: matemaatika, mina, loen, kirjutan, opiq
Topics RU: математика
Topics EN: mathematics

## Mina loen ja kirjutan 2 – Opiq
URL: https://www.opiq.ee/Kit/Details/458
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 454
Topics ET: matemaatika, mina, loen, kirjutan, opiq
Topics RU: математика
Topics EN: mathematics

## HÄÄLIKUD JA TÄHED
URL: https://www.opiq.ee/kit/458/chapter/24985
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 1.1
Topics ET: matemaatika, häälikud, tähed
Topics RU: математика
Topics EN: mathematics
Headings: HÄÄLIKUD JA TÄHED

## TÄHESTIK
URL: https://www.opiq.ee/kit/458/chapter/24984
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 1.2
Topics ET: matemaatika, tähestik
Topics RU: математика
Topics EN: mathematics
Headings: TÄHESTIK; 1.

## a, aa
URL: https://www.opiq.ee/kit/458/chapter/24986
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: a, aa; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## TÄISHÄÄLIKUD
URL: https://www.opiq.ee/kit/458/chapter/24995
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.10
Topics ET: matemaatika, täishäälikud
Topics RU: математика
Topics EN: mathematics
Headings: TÄISHÄÄLIKUD; 1.; 2.; 3.

## TÄISHÄÄLIKUÜHEND
URL: https://www.opiq.ee/kit/458/chapter/24996
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.11
Topics ET: matemaatika, täishäälikuühend
Topics RU: математика
Topics EN: mathematics
Headings: TÄISHÄÄLIKUÜHEND; 1.; 2.; 3.

## KORDAMINE
URL: https://www.opiq.ee/kit/458/chapter/24997
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.12
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.; 4.

## e, ee
URL: https://www.opiq.ee/kit/458/chapter/24987
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: e, ee; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## i, ii
URL: https://www.opiq.ee/kit/458/chapter/24988
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: i, ii; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.; 13.; 14.

## o, oo
URL: https://www.opiq.ee/kit/458/chapter/24989
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: o, oo; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.; 13.

## u, uu
URL: https://www.opiq.ee/kit/458/chapter/24990
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: u, uu; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.

## õ, õõ
URL: https://www.opiq.ee/kit/458/chapter/24991
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: õ, õõ; 1.; 2.; 3.; 4.; 5.

## ä, ää
URL: https://www.opiq.ee/kit/458/chapter/24992
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: ä, ää; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## ö, öö
URL: https://www.opiq.ee/kit/458/chapter/24993
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: ö, öö; 1.; 2.; 3.; 4.; 5.; 6.

## ü, üü
URL: https://www.opiq.ee/kit/458/chapter/24994
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: ü, üü; 1.; 2.; 3.; 4.; 5.

## l, ll
URL: https://www.opiq.ee/kit/458/chapter/24998
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: l, ll; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.; 13.

## KAASHÄÄLIKUÜHEND
URL: https://www.opiq.ee/kit/458/chapter/25007
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.10
Topics ET: matemaatika, kaashäälikuühend
Topics RU: математика
Topics EN: mathematics
Headings: KAASHÄÄLIKUÜHEND; 1.; 2.; 3.

## KORDAMINE
URL: https://www.opiq.ee/kit/458/chapter/25008
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.11
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.

## m, mm
URL: https://www.opiq.ee/kit/458/chapter/24999
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: m, mm; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.; 13.

## n, nn
URL: https://www.opiq.ee/kit/458/chapter/25000
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: n, nn; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## r, rr
URL: https://www.opiq.ee/kit/458/chapter/25001
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: r, rr; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## s, ss
URL: https://www.opiq.ee/kit/458/chapter/25002
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: s, ss; 1.; 2.; 3.; 4.; 5.; 6.

## v, vv
URL: https://www.opiq.ee/kit/458/chapter/25003
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: v, vv; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## h
URL: https://www.opiq.ee/kit/458/chapter/25004
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: 1.; 2.; 3.; 4.; 5.; 6.

## j
URL: https://www.opiq.ee/kit/458/chapter/25005
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: 1.; 2.; 3.; 4.; 5.; 6.

## KAASHÄÄLIKUD
URL: https://www.opiq.ee/kit/458/chapter/25006
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 3.9
Topics ET: matemaatika, kaashäälikud
Topics RU: математика
Topics EN: mathematics
Headings: KAASHÄÄLIKUD; 1.; 2.; 3.

## g, k, kk
URL: https://www.opiq.ee/kit/458/chapter/25009
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: g, k, kk; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.

## KORDAMINE: b, p, pp
URL: https://www.opiq.ee/kit/458/chapter/25018
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.10
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: b, p, pp; 1.; 2.; 3.; 4.

## d, t, tt
URL: https://www.opiq.ee/kit/458/chapter/25019
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: d, t, tt; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## d, tt
URL: https://www.opiq.ee/kit/458/chapter/25020
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.12
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: d, tt; 1.; 2.; 3.; 4.; 5.; 6.

## d, t
URL: https://www.opiq.ee/kit/458/chapter/25021
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.13
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: d, t; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## t, tt
URL: https://www.opiq.ee/kit/458/chapter/25022
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.14
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: t, tt; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## KORDAMINE: d, t, tt
URL: https://www.opiq.ee/kit/458/chapter/25023
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.15
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: d, t, tt; 1.; 2.; 3.; 4.; 5.; 6.

## KORDAMINE
URL: https://www.opiq.ee/kit/458/chapter/25024
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.16
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## g, kk
URL: https://www.opiq.ee/kit/458/chapter/25010
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: g, kk; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## g, k
URL: https://www.opiq.ee/kit/458/chapter/25011
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: g, k; 1.; 2.; 3.; 4.; 5.; 6.

## k, kk
URL: https://www.opiq.ee/kit/458/chapter/25012
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: k, kk; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## KORDAMINE: g, k, kk
URL: https://www.opiq.ee/kit/458/chapter/25013
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.5
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: g, k, kk; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## b, p, pp
URL: https://www.opiq.ee/kit/458/chapter/25014
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: b, p, pp; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## b, pp
URL: https://www.opiq.ee/kit/458/chapter/25015
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: b, pp; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## b, p
URL: https://www.opiq.ee/kit/458/chapter/25016
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: b, p; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## p, pp
URL: https://www.opiq.ee/kit/458/chapter/25017
Book: Mina loen ja kirjutan 2 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_mina_loen__2_et
Chapter ID: 4.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: p, pp; 1.; 2.; 3.; 4.; 5.; 6.
