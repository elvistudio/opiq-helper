## Loodusõpetus 6. klassile (2025) – Opiq
URL: https://www.opiq.ee/Kit/Details/572
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 213
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Elutingimused soos
URL: https://www.opiq.ee/kit/572/chapter/31885
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.1
Topics ET: loodusõpetus, aeg, kell, kalender, elutingimused, soos, kogu, märg, tekib, turvas, väga, pika
Topics RU: природоведение, время, часы, календарь
Topics EN: science, time, clock, calendar
Headings: Elutingimused soos; Soos on maa kogu aeg märg; Soos tekib turvas; Soo tekib väga pika aja jooksul; Turbasamblad on veerikkad; Soos on eriline kasvukeskkond; Mõisted; Ma tean, et ...
Task examples: Millised on soo tunnused?; Millised on soo tunnused?

## Kuidas soo tekib?
URL: https://www.opiq.ee/kit/572/chapter/31886
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.2
Topics ET: loodusõpetus, kuidas, tekib, madalate, maade, soostumine, järve, kinnikasvamine, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Kuidas soo tekib?; Madalate maade soostumine; Järve kinnikasvamine; Mõisted; Ma tean, et...
Task examples: Märgi laused, mis kirjeldavad madalate maade soostumist.; Kuidas saab järvest soo? Lohista laused õigesse järjekorda.

## Soo areng
URL: https://www.opiq.ee/kit/572/chapter/31887
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.3
Topics ET: loodusõpetus, areng, sood, erineva, vanusega, kõigepealt, tekib, madalsoo, madalsoost
Topics RU: природоведение
Topics EN: science
Headings: Soo areng; Sood on erineva vanusega; Kõigepealt tekib madalsoo; Madalsoost kujuneb siirdesoo; Siirdesoost areneb raba; Raba on eripalgeline; Mõisted; Ma tean, et ...
Task examples: Märgi madalsoos kasvavad taimed.; Millised on madalsoole iseloomulikud tunnused?

## Rabataimed
URL: https://www.opiq.ee/kit/572/chapter/31888
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, rabataimed, rabataimestik, sõltub, turbasammaldest, taimedel, aitavad, rabas, toitaineid
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Rabataimed; Rabataimestik sõltub turbasammaldest; Taimedel aitavad rabas toitaineid kätte saada seened; Huulheinad on putuktoidulised taimed; Rabataimede lehed on tihti väikesed ja nahkjad; Rabamurakal on maitsvad viljad; Kääbuskasvulised männid; Ma tean, et ...
Task examples: Mis taimedest sõltub kogu raba taimestik?; Kuidas on seened seotud rabamuraka, jõhvika ja sookailuga?

## Raba loomastik
URL: https://www.opiq.ee/kit/572/chapter/31889
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, raba, loomastik, elab, rabas, verd, imevad, konnad
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Raba loomastik; Kes elab rabas?; Verd imevad putukad; Konnad, sisalikud ja rästikud; Imetajaid elab rabas vähe; Soo pakub lindudele varje- ja pesitsuspaiku, kuid vähe toitu; Soos käivad ka mujal pesitsevad linnud; Mõisted; Ma tean, et ...
Task examples: Miks elab rabas vähe suuri loomi?; Miks elab rabas vähe suuri loomi?

## Soode tähtsus ja kasutamine
URL: https://www.opiq.ee/kit/572/chapter/31890
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.6
Topics ET: loodusõpetus, soode, tähtsus, kasutamine, tähtis, elupaik, sood, puhastavad, vett, seovad
Topics RU: природоведение
Topics EN: science
Headings: Soode tähtsus ja kasutamine; Soo on tähtis elupaik; Sood puhastavad vett ja seovad süsihappe­gaasi; Soos saab puhata ja loodusande korjata; Soost saab turvast; Kaevandatud turba taastumiseks kuluks aastatuhandeid; Ma tean, et ...
Task examples: Miks on sood vajalikud?; Mida saavad inimesed soos teha?

## Soode taastamine
URL: https://www.opiq.ee/kit/572/chapter/31891
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.7
Topics ET: loodusõpetus, soode, taastamine, paljud, sood, kuivendamisega, rikutud, soid, tuleb
Topics RU: природоведение
Topics EN: science
Headings: Soode taastamine; Paljud sood on kuivendamisega rikutud; Soid tuleb taastada; Ma tean, et ...
Task examples: Milliste tegevustega võib inimene sood kahjustada?; Miks on Eestis soid kuivendatud?

## Sood ja soo­kaitsealad Eestis
URL: https://www.opiq.ee/kit/572/chapter/31892
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 1.8
Topics ET: loodusõpetus, sood, kaitsealad, eestis, palju, soiseid, alasid, soode, teket
Topics RU: природоведение
Topics EN: science
Headings: Sood ja soo­kaitsealad Eestis; Eestis on palju soiseid alasid; Soode teket soodustab tasane maa ja sademete­rohke jahe kliima; Paljud sood on looduskaitse all; Uuri kaarti!; Soomaa rahvuspark; Alutaguse rahvuspark; Alam-Pedja looduskaitseala; Näpunäiteid soos liikumiseks; Mõisted; Ma tean, et ...
Task examples: Miks on Eestis palju soid?; Kus on vähe soid? Vasta kaardi põhjal.

## Mulla teke ja areng
URL: https://www.opiq.ee/kit/572/chapter/32041
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 2.1
Topics ET: loodusõpetus, mulla, teke, areng, muld, mõjutab, kõike, elavat, algab
Topics RU: природоведение
Topics EN: science
Headings: Mulla teke ja areng; Muld mõjutab kõike elavat; Mulla teke algab kivimite murenemisest; Mullale annab tumeda värvi huumus; Huumus tekib elusaine lagunemisel mullas; Elusolendid on oluline osa mullast; Mis mulda ohustab?; Mõisted; Ma tean, et ...
Task examples: Mis tegurid põhjustavad kivimite murenemist?; Mille tagajärjena tekib huumus? Vali kaks vastust.

## Mulla koostis
URL: https://www.opiq.ee/kit/572/chapter/32042
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 2.2
Topics ET: loodusõpetus, taim, taimed, puu, lill, mulla, koostis, mullad, erinevad, üksteisest, mullas, tahkeid, aineid, vett
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Mulla koostis; Mullad erinevad üksteisest; Mullas on tahkeid aineid, vett ja õhku; Vee liikumine mullas sõltub mulla koostisest; Taimed saavad vett mullasõmerate vahelt; Muld on kihiline; Mulla koostis muutub; Mulla viljakus; Mõisted; Ma tean, et ...
Task examples: Mis on mullasõmerate vahel?; Märgi mulla koostisosad.

## Muld taimede elu­keskkonnana
URL: https://www.opiq.ee/kit/572/chapter/32043
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 2.3
Topics ET: loodusõpetus, muld, taimede, keskkonnana, miks, taimedel, mulda, vaja, talvel
Topics RU: природоведение
Topics EN: science
Headings: Muld taimede elu­keskkonnana; Miks on taimedel mulda vaja?; Talvel on mullas soojem kui väljas; Ma tean, et ...
Task examples: Kuidas liigub vesi taimes? Märgi kõik õiged väited.; Mis on taimejuurte ülesanded?

## Mulda loov elustik
URL: https://www.opiq.ee/kit/572/chapter/32044
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 2.4
Topics ET: loodusõpetus, mulda, loov, elustik, elusolendid, tähtis, mullast, mullas, elab
Topics RU: природоведение
Topics EN: science
Headings: Mulda loov elustik; Elusolendid on tähtis osa mullast; Mullas elab tohutu hulk baktereid ja seeni; Mulla arvukas pisiloomastik; Lagundajad mullas; Vihmaussid on väga olulised mullaloomad; Uuri skeemi!; Mõisted; Ma tean, et ...
Task examples: Bakterid ja seened on mullas vajalikud, sest nad ...; Uuri jooniseid. Täida lüngad.

## Muld loomade elu­paigana
URL: https://www.opiq.ee/kit/572/chapter/32045
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 2.5
Topics ET: loodusõpetus, muld, loomade, paigana, mutt, veedab, terve, mullas, varjupaik
Topics RU: природоведение
Topics EN: science
Headings: Muld loomade elu­paigana; Mutt veedab terve elu mullas; Muld on hea varjupaik; Mullaelustik talvel; Ma tean, et ...
Task examples: Mis otstarbel kasutavad suuremad loomad mulda uuristatud urge ja koopaid?; Mõtle ja tuleta meelde. Milline on elukeskkond mullas?

## Põld ja aed elu­keskkonnana
URL: https://www.opiq.ee/kit/572/chapter/32142
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.1
Topics ET: loodusõpetus, põld, keskkonnana, elutingimused, põllul, aias, kasvatatakse, kultuurtaimi, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Põld ja aed elu­keskkonnana; Elutingimused põllul; Elutingimused aias; Põllul ja aias kasvatatakse kultuurtaimi; Mõisted; Ma tean, et ...
Task examples: Võrdle elutingimusi põllul ja metsas. Lohista vastused õige pealkirja alla.; Vali lünka õige sõna.

## Põllud ja mullaviljakus
URL: https://www.opiq.ee/kit/572/chapter/32143
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.2
Topics ET: loodusõpetus, taim, taimed, puu, lill, põllud, mullaviljakus, muldade, viljakus, piirkonniti, erinev, uuri, kaarti
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Põllud ja mullaviljakus; Muldade viljakus on piirkonniti erinev; Uuri kaarti!; Väetiste kasu ja kahju; Liiga tihedast mullast kaob elu; Liigne väetamine on kahjulik; Mahepõllundus säästab keskkonda; Viljavaheldus; Liblikõielised taimed teevad koostööd bakteritega; Mõisted; Ma tean, et...
Task examples: Millistes Eesti piirkondades on suured viljakate muldadega alad? Märgi kaardi põhjal kaks piirkonda.; Miks väetisi tarvitatakse?

## Põllutaimed
URL: https://www.opiq.ee/kit/572/chapter/32144
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.3
Topics ET: loodusõpetus, põllutaimed, põllul, kasvatatakse, kultuurtaimi, teraviljad, uuri, teravilju, mais
Topics RU: природоведение
Topics EN: science
Headings: Põllutaimed; Põllul kasvatatakse kultuurtaimi; Teraviljad; Uuri teravilju!; Mais ja tatar; Kartul ja teised köögiviljad; Muud kultuurtaimed meie põldudel; Ma tean, et ...
Task examples: Mida millest tehakse? Ühenda paarid.; Mis teravili on pildil?

## Põlluloomad
URL: https://www.opiq.ee/kit/572/chapter/32145
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.4
Topics ET: loodusõpetus, põlluloomad, püsivalt, elab, põllul, vähe, loomaliike, käivad, paljud
Topics RU: природоведение
Topics EN: science
Headings: Põlluloomad; Püsivalt elab põllul vähe loomaliike; Põllul käivad paljud loomaliigid toitu otsimas; Põllutööd segavad pesitsemist; Vähesed imetajad saavad põllul elada; Ma tean, et ...
Task examples: Tuleta meelde, millised on elutingimused põllul.; Millist toitu leiavad linnud ja imetajad põllult järgmiste põllutööde ajal? Ühenda paarid.

## Viljapuu- ja köögivilja­aed
URL: https://www.opiq.ee/kit/572/chapter/32146
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.5
Topics ET: loodusõpetus, viljapuu, köögivilja, sõna, tähendus, muutunud, puuvilja, marjaaed, köögiviljaaed
Topics RU: природоведение
Topics EN: science
Headings: Viljapuu- ja köögivilja­aed; Sõna „aed“ tähendus on muutunud; Puuvilja- ja marjaaed; Köögiviljaaed; Uuri joonist!; Maitse- ja ravimtaimede aed; Mõisted; Ma tean, et ...
Task examples: Meenuta, mille poolest erinevad elutingimused aias ja põllul. Vali lünka õige sõna.; Lohista vastused õige pealkirja alla.

## Iluaed
URL: https://www.opiq.ee/kit/572/chapter/32147
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, iluaed, läbi, aegade, ilupuud, põõsad, suvelilled, talve, püsikutel
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Iluaed; Iluaed läbi aegade; Ilupuud ja -põõsad; Suvelilled ei ela talve üle; Püsikutel elavad maa-alused osad talve üle; Looduslikud taimed iluaias; Mõisted; Ma tean, et ...
Task examples: Mis võib iluaias asuda?; Mis kasu on tänavaäärsest hekist?

## Aialoomad
URL: https://www.opiq.ee/kit/572/chapter/32148
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, aialoomad, loomastik, erineb, põllu, omast, aias, soodsad, elutingimused
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Aialoomad; Aia loomastik erineb põllu omast; Aias on soodsad elutingimused tigudele ja nälkjatele; Linnud leiavad aiast toitu; Uuri pilte!; Aedades elab ka imetajaid; Ma tean, et ...
Task examples: Mille poolest erineb aia elustik põllu omast?; Miks ei ole kuldnokad ja rästad marjade valmimise ajal aias teretulnud?

## Umbrohud ja kahjurid
URL: https://www.opiq.ee/kit/572/chapter/32149
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 3.8
Topics ET: loodusõpetus, umbrohud, kahjurid, kultuurtaimed, võistlevad, umbrohtudega, raske, võidelda, taimi
Topics RU: природоведение
Topics EN: science
Headings: Umbrohud ja kahjurid; Kultuurtaimed võistlevad umbrohtudega; Umbrohtudega on raske võidelda; Taimi kahjustavad kahjurid ja taimehaigused; Tõrjuda saab nii kemikaalide kui ka looduslike vahenditega; Mõisted; Ma tean, et ...
Task examples: Miks proovivad inimesed umbrohtudest põllul ja aias lahti saada?; Kas umbrohi on kõikjal aias vaja hävitada?

## Eesti loodusvarad
URL: https://www.opiq.ee/kit/572/chapter/32523
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 4.1
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, eesti, loodusvarad, kasutab, loodusvarasid, põllumees, hindab, väärtust
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Eesti loodusvarad; Inimene kasutab loodusvarasid; Põllumees hindab maa väärtust mulla põhjal; Eestis on vett piisavalt; Mets on Eesti olulisemaid loodusvarasid; Metsa tuleb hooldada ja kaitsta; Loodusvarasid tuleb kasutada säästlikult; Mõisted; Ma tean, et ...
Task examples: Millistel aladel on asustustihedus suurim?; Kust saavad eestlased oma joogivee?

## Eesti maavarad
URL: https://www.opiq.ee/kit/572/chapter/32524
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 4.2
Topics ET: loodusõpetus, eesti, maavarad, pole, maavarade, poolest, rikas, maapõuest, saab
Topics RU: природоведение
Topics EN: science
Headings: Eesti maavarad; Eesti pole maavarade poolest rikas; Maapõuest saab ehitusmaterjali; Põlevkivist toodetakse elektrit ja õli; Turvas on väärtuslik maavara; Maavarade paiknemine Eestis; Uuri kaarti!; Mõisted; Ma tean, et ...
Task examples: Milliseid maavarasid Eestis kaevandatakse?; Milleks kasutatakse põlevkivi?

## Maavarade kaevandamise mõju loodusele
URL: https://www.opiq.ee/kit/572/chapter/32525
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 4.3
Topics ET: loodusõpetus, maavarade, kaevandamise, mõju, loodusele, kaevandamine, mõjutab, alati, loodust
Topics RU: природоведение
Topics EN: science
Headings: Maavarade kaevandamise mõju loodusele; Kaevandamine mõjutab alati loodust; Avatud kaevanduste mõju; Maa-aluste kaevanduste mõju; Fosforiit; Kaevandusala tuleb pärast kasutamist korrastada; Ma tean, et ...
Task examples: Mis võib juhtuda maavarade kaevandamise käigus?; Mida kaevandatakse Eestis karjäärides?

## Taastuvad ja taastumatud loodusvarad
URL: https://www.opiq.ee/kit/572/chapter/32526
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 4.4
Topics ET: loodusõpetus, taastuvad, taastumatud, loodusvarad, loodusvarasid, taastub, mitte, majandus, peab
Topics RU: природоведение
Topics EN: science
Headings: Taastuvad ja taastumatud loodusvarad; Osa loodusvarasid taastub, osa mitte; Majandus peab muutuma säästlikumaks; Uuri skeemi!; Inimesed sõltuvad liiga palju naftast; Mõisted; Ma tean, et ...
Task examples: Lohista loodusvarad õige pealkirja alla.; Mis iseloomustab säästlikumat majandust?

## Loodusvarad energia­allikana
URL: https://www.opiq.ee/kit/572/chapter/32527
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 4.5
Topics ET: loodusõpetus, loodusvarad, energia, allikana, põlevkivist, elektri, tootmine, keskkonnavaenulik, energiat
Topics RU: природоведение
Topics EN: science
Headings: Loodusvarad energia­allikana; Mis on energia?; Põlevkivist elektri tootmine on keskkonnavaenulik; Energiat saab toota ka voolava vee abil; Tuuleenergiat püütakse tuulise ilmaga; Päikeseenergia on kõige aluseks; Tuumaelektrijaamad on kõige võimsamad; Mõisted; Ma tean, et ...
Task examples: Milleks on inimestel energiat vaja?; Miks plaanitakse põlevkivist elektri tootmine lõpetada?

## Elutingimused metsas
URL: https://www.opiq.ee/kit/572/chapter/32972
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.1
Topics ET: loodusõpetus, elutingimused, metsas, mets, ökosüsteem, uuri, pilti, laguahel, tingimused
Topics RU: природоведение
Topics EN: science
Headings: Elutingimused metsas; Mis on mets?; Mets on ökosüsteem; Uuri pilti!; Mis on laguahel?; Tingimused metsas ja lagedal on erinevad; Loomadel on metsas varjepaiku ja mitme­kesist toitu; Mõisted; Ma tean, et ...
Task examples: Mis moodustavad mingi piirkonna ökosüsteemi?; Kuidas jõuavad maha langenud puulehtedest pärit ained tagasi taimedesse? Vaata vastamiseks videot. Lohista laused õigesse järjekorda.

## Metsa saab mitmeti kasutada
URL: https://www.opiq.ee/kit/572/chapter/32981
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.10
Topics ET: loodusõpetus, metsa, saab, mitmeti, kasutada, metsast, mitmekülgset, kasu, jahti
Topics RU: природоведение
Topics EN: science
Headings: Metsa saab mitmeti kasutada; Metsast saab mitmekülgset kasu; Jahti on vaja metsloomade arvukuse piiramiseks; Metsas kasvab maitsvaid marju; Osa seeni on söödavad, osa surmavalt mürgised; Mets oli esivanemate ainuke apteek; Metsas peetakse mesilasi; Puhkus metsas on tervislik; Metsades on pühapaiku; Mõisted; Ma tean, et ...
Task examples: Milleks kasutavad inimesed metsa?; Miks tänapäeval metsloomadele jahti peetakse?

## Eesti metsad
URL: https://www.opiq.ee/kit/572/chapter/32973
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.2
Topics ET: loodusõpetus, eesti, metsad, metsarikas, metsa, võib, liigitada, seal, kasvavate
Topics RU: природоведение
Topics EN: science
Headings: Eesti metsad; Eesti on metsarikas maa; Metsa võib liigitada ka seal kasvavate puuliikide järgi; Loodusmets ja majandusmets; Metsa uuenemine; Uuri joonist!; Metsad on eri vanusega; Mõisted; Ma tean, et ...
Task examples: Millised on tavalisemad puud Eesti metsades? Märgi kaks okaspuud ja kolm lehtpuud.; Mille järgi saab metsi rühmitada?

## Metsarinded
URL: https://www.opiq.ee/kit/572/chapter/32974
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, metsarinded, puurinde, põõsarinde, saavad, rohkem, valgust, puhma
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Metsarinded; Puurinde ja põõsarinde taimed saavad rohkem valgust; Puhma- ja rohurinde taimed kasvavad puude ja põõsaste varjus; Samblad ja samblikud lepivad vähese valgusega; Metsas elab rohkem liike kui teistes elu­kooslustes; Uuri pilti!; Mõisted; Ma tean, et ...
Task examples: Järjesta metsarinded selle järgi, kui palju need valgust saavad. Esimeseks lohista rinne, kuhu jõuab kõige rohkem valgust, ja viimaseks rinne, kuhu jõuab kõige vähem valgust.; Millisesse rindesse taim kuulub?

## Metsatüübid. Nõmme- ja palumets
URL: https://www.opiq.ee/kit/572/chapter/32975
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.4
Topics ET: loodusõpetus, metsatüübid, nõmme, palumets, mänd, eestis, kõige, tavalisem, metsapuu
Topics RU: природоведение
Topics EN: science
Headings: Metsatüübid. Nõmme- ja palumets; Mis on metsatüübid?; Mänd on Eestis kõige tavalisem metsapuu; Nõmmemets; Palumets; Mõisted; Ma tean, et ...
Task examples: Mille alusel eristatakse metsatüüpe?; Millised on taimede kasvutingimused nõmmemetsas? Vali lünka õige sõna.

## Metsatüübid. Laane- ja salumets
URL: https://www.opiq.ee/kit/572/chapter/32976
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.5
Topics ET: loodusõpetus, metsatüübid, laane, salumets, kuusk, kasvab, toitaine, rikkal, parajalt, niiskel
Topics RU: природоведение
Topics EN: science
Headings: Metsatüübid. Laane- ja salumets; Kuusk kasvab toitaine­rikkal parajalt niiskel pinnasel; Laanemets; Uuri pilte!; Salumets; Mõisted; Ma tean, et ...
Task examples: Mille poolest erineb kuusk männist?; Millised on taimede kasvutingimused laanemetsas? Vali lünka õige sõna.

## Selgrootud ja linnud metsas
URL: https://www.opiq.ee/kit/572/chapter/32977
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgrootud, metsas, kuklased, metsa, koosluses, asendamatud, kuuse
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgrootud ja linnud metsas; Kuklased on metsa­koosluses asendamatud; Kuuse-kooreürask kahjustab puid; Linde elab metsas väga palju; Uuri pilte!; Metsvindile sobivad igasugused metsad; Suur-kirjurähn on kõige arvukam rähniliik; Ma tean, et ...
Task examples: Vali lünka õige sõna.; Miks metsameestele kuuse-kooreüraskid ei meeldi?

## Imetajad metsas
URL: https://www.opiq.ee/kit/572/chapter/32978
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.7
Topics ET: loodusõpetus, imetajad, metsas, mets, suurte, väikeste, imetajate, elupaik, põder
Topics RU: природоведение
Topics EN: science
Headings: Imetajad metsas; Mets on nii suurte kui ka väikeste imetajate elupaik; Põder on Eesti suurim metsloom; Metskits elab väiksemates metsades; Hundil ei ole looduslikke vaenlasi; Pruunkaru on sega­toiduline; Mõisted; Ma tean, et ...
Task examples: Märgi kõik sõralised. Kui ei tea, kontrolli internetist.; Märgi kõik kiskjad. Kui ei tea, kontrolli internetist.

## Metsa majanduslik tähtsus
URL: https://www.opiq.ee/kit/572/chapter/32979
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.8
Topics ET: loodusõpetus, metsa, majanduslik, tähtsus, puitu, kasutatakse, väga, mitmel, viisil
Topics RU: природоведение
Topics EN: science
Headings: Metsa majanduslik tähtsus; Puitu kasutatakse väga mitmel viisil; Puidukeemia on võimaluste­rikas; Uuri joonist!; Puidu saamiseks tuleb metsa majandada; Metsa tuleks raiuda ühtlaselt; Mets annab paljudele tööd; Mõisted; Ma tean, et ...
Task examples: Milleks kasutatakse puitu?; Millest koosnevad puidukiud?

## Mets kui elukeskkond
URL: https://www.opiq.ee/kit/572/chapter/32980
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 5.9
Topics ET: loodusõpetus, mets, elukeskkond, metsad, kujundavad, kliimat, pehmendab, äärmuslikke, ilmaolusid
Topics RU: природоведение
Topics EN: science
Headings: Mets kui elukeskkond; Metsad kujundavad Maa kliimat; Mets pehmendab äärmuslikke ilmaolusid; Mets ühtlustab vee ringkäiku; Mets kujundab mulda; Metsas elab palju liike; Majandusmetsas tuleb kaitsta vääris­elupaiku; Mõisted; Ma tean, et...
Task examples: Kuidas on metsad seotud õhkkonna koostisega?; Vali lünka õige sõna.

## Niit kui Eesti kõige liigi­rikkam kooslus
URL: https://www.opiq.ee/kit/572/chapter/33294
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.1
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, niit, eesti, kõige, liigi, rikkam, kooslus, püsib, vaid, siis
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Niit kui Eesti kõige liigi­rikkam kooslus; Niit püsib vaid siis, kui seda niidetakse; Kasvutingimused niidul; Puisniidud on kõige liigi­rikkamad kooslused Eestis; Niidul elab palju putukaid; Linnud ja imetajad niidul; Mõisted; Ma tean, et ...
Task examples: Mille poolest on liblikõielised taimed erilised? Tuleta meelde põllutundides õpitut.; Millised taimed neist on põhilised niidutaimed?

## Pärand­kooslused ja nende kaitse
URL: https://www.opiq.ee/kit/572/chapter/33295
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.2
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, pärand, kooslused, nende, kaitse, niidud, looduslikel, niitudel, leidub
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Pärand­kooslused ja nende kaitse; Niidud on pärand­kooslused; Looduslikel niitudel leidub haruldasi taimi ja loomi; Käpalised on looduskaitse all; Loomad aitavad niitudel säilida; Maaomanikud saavad maastiku­hoolduseks toetust; Mõisted; Ma tean, et ...
Task examples: Milliseid töid on inimesed põlvkondade jooksul pärandkooslustel teinud?; Miks tuleb väärtuslikke looduslikke niite kaitsta?

## Loodus- ja keskkonna­kaitse Eestis
URL: https://www.opiq.ee/kit/572/chapter/33296
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.3
Topics ET: loodusõpetus, loodus, keskkond, keskkonna, kaitse, eestis, liikide, elukoosluste, rahvuspargis, kaitstakse
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Loodus- ja keskkonna­kaitse Eestis; Loodus- ja keskkonna­kaitse; Liikide ja elukoosluste kaitse; Rahvuspargis kaitstakse nii loodust kui ka kultuuri­pärandit; Looduskaitsealad ja maastiku­kaitsealad; Uuri kaarti!; Mõisted; Ma tean, et ...
Task examples: Milliste teemadega tegeleb keskkonnakaitse, millistega looduskaitse? Lohista sõnad õige pealkirja alla.

## Eesti rahvuspargid (1)
URL: https://www.opiq.ee/kit/572/chapter/33297
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.4
Topics ET: loodusõpetus, eesti, rahvuspargid, vilsandi, rahvuspark, lahemaa, matsalu, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Eesti rahvuspargid (1); Vilsandi rahvuspark; Lahemaa rahvuspark; Matsalu rahvuspark; Mõisted; Ma tean, et ...
Task examples: Märgi laused, mis käivad Vilsandi rahvuspargi kohta.; Märgi laused, mis käivad Lahemaa rahvuspargi kohta.

## Eesti rahvuspargid (2)
URL: https://www.opiq.ee/kit/572/chapter/33298
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.5
Topics ET: loodusõpetus, eesti, rahvuspargid, soomaa, rahvuspark, alutaguse, karula, tean
Topics RU: природоведение
Topics EN: science
Headings: Eesti rahvuspargid (2); Soomaa rahvuspark; Alutaguse rahvuspark; Karula rahvuspark; Ma tean, et ...
Task examples: Märgi laused, mis käivad Soomaa rahvuspargi kohta.; Märgi laused, mis käivad Alutaguse rahvuspargi kohta.

## Inimese mõju loodusele
URL: https://www.opiq.ee/kit/572/chapter/33299
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.6
Topics ET: loodusõpetus, loodus, keskkond, inimese, mõju, loodusele, maailma, rahvastik, kiiresti, kasvanud, uuri, joonist
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Inimese mõju loodusele; Maailma rahvastik on kiiresti kasvanud; Uuri joonist!; Kõiki loodusvarasid ei jätku kõigile; Inimesel on suur ökoloogiline jalajälg; Keskkond reostub üha enam; Viljakat mulda jääb vähemaks; Mõisted; Ma tean, et ...
Task examples: Mis põhjustel hakkas maailma rahvaarv 20. sajandil kiiresti suurenema?; Uuri joonist ja täida lüngad.

## Inimese mõju elurikkusele
URL: https://www.opiq.ee/kit/572/chapter/33300
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.7
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, inimese, mõju, elurikkusele, muudab, kahjustab, loodust, rohkem
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimese mõju elurikkusele; Inimene muudab ja kahjustab loodust üha rohkem; Inimene mõjutab kogu planeeti; Elurikkus on oluline; Liikide väljasuremine kiireneb; Mõisted; Ma tean, et ...
Task examples: Uuri joonist ja vasta küsimustele.; Uuri joonist ja vasta küsimustele.

## Igaühe looduskaitse
URL: https://www.opiq.ee/kit/572/chapter/33301
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 6.8
Topics ET: loodusõpetus, loodus, keskkond, igaühe, looduskaitse, loodust, tuleb, kaitsta, kõikjal, uuri, teksti, pilte
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Igaühe looduskaitse; Loodust tuleb kaitsta kõikjal; Uuri teksti ja pilte!; Märka ja toeta loodust koduaias; Koduümbrust saab elu­rikkamaks muuta mitmel moel; Vabatahtlik loodus­kaitsetöö; Mõisted; Ma tean, et ...
Task examples: Millised on pöetud muru miinused?; Mis kasu on pöetud murust?

## Eesti asustus
URL: https://www.opiq.ee/kit/572/chapter/33394
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.1
Topics ET: loodusõpetus, eesti, asustus, jagatud, konnaks, uuri, kaarti, eestis, linna
Topics RU: природоведение
Topics EN: science
Headings: Eesti asustus; Eesti on jagatud 15 maa­konnaks; Uuri kaarti!; Eestis on linna- ja maa-asulaid; Miks on linnas rohkem teenuseid?; Ma tean, et ...
Task examples: Uuri kaarti. Märgi Tartumaa naabermaakonnad.; Uuri kaarti. Mis on nende maakondade keskused? Vali õige vastus.

## Kuidas linn toimib?
URL: https://www.opiq.ee/kit/572/chapter/33395
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.2
Topics ET: loodusõpetus, kuidas, linn, toimib, linnaelanikel, vaja, vett, toitu, elektrit, kütust
Topics RU: природоведение
Topics EN: science
Headings: Kuidas linn toimib?; Linnaelanikel on vaja vett, toitu, elektrit ja kütust; Linnas tekib reovett ja jäätmeid; Maa-alused võrgud – nähtamatu linn; Kes linna töös hoiab?; Iga linlane vastutab heakorra eest; Mõisted; Ma tean, et ...
Task examples: Mis linnaelanike eluks vajalik on suuremas osas pärit väljastpoolt linna?; Mida tehakse linnas tekkinud jäätmetega?

## Elutingimused linnas. Õhk ja vesi
URL: https://www.opiq.ee/kit/572/chapter/33396
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.3
Topics ET: loodusõpetus, loodus, keskkond, vesi, veeohutus, veekogu, elutingimused, linnas, linn, tehis, väikeasulad
Topics RU: природоведение, природа, окружающая среда, вода, безопасность на воде, водоём
Topics EN: science, nature, environment, water, water safety, body of water
Headings: Elutingimused linnas. Õhk ja vesi; Linn on tehis­keskkond; Väikeasulad on loodus­lähedasemad; Linnas on soojem kui lähi­ümbruses; Linna õhk on saastatud; Linnas tekivad tuule­koridorid; Linna veekogudel on oht saastuda; Mõisted; Ma tean, et ...
Task examples: Märgi kõik tõesed väited.; Mis iseloomustab elukooslusi linnas?

## Elutingimused linnas. Valgus ja müra
URL: https://www.opiq.ee/kit/572/chapter/33397
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.4
Topics ET: loodusõpetus, elutingimused, linnas, valgus, müra, palju, tehis, valgust, sageli
Topics RU: природоведение
Topics EN: science
Headings: Elutingimused linnas. Valgus ja müra; Linnas on palju tehis­valgust; Linnas on sageli liiga lärmakas; Linnas on vaiksemaid ja lärmakamaid kohti; Kuidas müra linnas vähendada?; Uuri Põhja-Tallinna mürakaarti!; Mõisted; Ma tean, et ...
Task examples: Milliseid probleeme võib valgusreostus tekitada?; Uuri joonist. Märgi, millised helid võivad kuulmist kahjustada.

## Taimed ja samblikud linnas
URL: https://www.opiq.ee/kit/572/chapter/33398
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, samblikud, linnas, leidub, kivisemaid, rohelisemaid, alasid, saavad
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed ja samblikud linnas; Linnas leidub kivisemaid ja rohelisemaid alasid; Linnas saavad hästi hakkama taimed, mis kannatavad tallamist; Samblike järgi saab otsustada õhu puhtuse üle; Uuri pilte!; Ma tean, et ...
Task examples: Mis kasu on linnas puudest?; Milliste tingimuste tõttu kasvab linnas vähe taimi?

## Linnaloomad (1)
URL: https://www.opiq.ee/kit/572/chapter/33399
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, linnaloomad, inimkaaslejad, elavad, inimese, läheduses, linnadesse, tuleb
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnaloomad (1); Inimkaaslejad loomad elavad inimese läheduses; Linnadesse tuleb üha enam loomaliike; Pargis elavad siilid ja oravad; Inimeste toit võib olla loomadele kahjulik; Mõisted; Ma tean, et ...
Task examples: Kes neist loomadest on parasiidid?; Kes on inimkaasleja?

## Linnaloomad (2)
URL: https://www.opiq.ee/kit/572/chapter/33400
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, linnaloomad, paljud, pesitsevad, hoonetel, kolooniates, elavad, linnalinnud
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnaloomad (2); Paljud linnud pesitsevad hoonetel; Kolooniates elavad linnalinnud võivad olla tülikad; Lindude toitmine ei ole alati hea; Ma tean, et ...
Task examples: Miks elab linnas rohkem linnu- kui imetajaliike?; Märgi linnas tavalised linnud.

## Linna rohealad
URL: https://www.opiq.ee/kit/572/chapter/33401
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.8
Topics ET: loodusõpetus, linna, rohealad, linnas, vajalikud, park, liigirikas, parkides, kasvab
Topics RU: природоведение
Topics EN: science
Headings: Linna rohealad; Rohealad on linnas vajalikud; Park on liigirikas ala; Parkides kasvab nii kodu­maiseid kui ka võõraid puuliike; Rohealad on olulised linlaste tervisele; Rohealad loovad ja tugevdavad kogukonna­tunnet; Rohealadega on seotud ka mõned ohud; Mõisted; Ma tean, et ...
Task examples: Mis võiks olla pargis, et seal elaks palju linnuliike?; Märgi kodumaised puuliigid, mida näeb sageli pargis kasvamas.

## Tulevikulinn
URL: https://www.opiq.ee/kit/572/chapter/33402
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 7.9
Topics ET: loodusõpetus, tulevikulinn, linnad, muutuvad, jooksul, linn, inimestele, mitte, autodele
Topics RU: природоведение
Topics EN: science
Headings: Tulevikulinn; Linnad muutuvad aja jooksul; Linn on inimestele, mitte autodele; Linn peab olema rohelisem; Vett saab kasutada targemalt; Linn peab säästma energiat; Linn peab tekitama vähem jäätmeid; Mõisted; Ma tean, et ...
Task examples: Mida on vaja, et tulevikulinnas kuumalaineid või üleujutusi vältida või leevendada?; Kellel peab olema linnas mugav liigelda?

## Looduspäevik
URL: https://www.opiq.ee/kit/572/chapter/33393
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 8.1
Topics ET: loodusõpetus, looduspäevik, looduspäeviku, pidamise, juhend
Topics RU: природоведение
Topics EN: science
Headings: Looduspäevik; Looduspäeviku pidamise juhend

## Mõisted
URL: https://www.opiq.ee/kit/572/chapter/31893
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 8.2
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/572/chapter/32522
Book: Elutingimused soos
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_2025_est
Chapter ID: 8.3
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Loodusõpetus 6. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/8
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 156
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Maakoor koosneb kivimitest
URL: https://www.opiq.ee/kit/8/chapter/295
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 1.1
Topics ET: loodusõpetus, maakoor, koosneb, kivimitest, kivimite, teke, mõtle, settekivim, kasvab
Topics RU: природоведение
Topics EN: science
Headings: Maakoor koosneb kivimitest; Kivimite teke; Mõtle!; Settekivim kasvab tera tera haaval; Kus näeb erinevaid kivimikihte?; Kui väärtuslikud on kivimid?; Mõisted; Ma tean, et …
Task examples: Lohista mõiste alla seletus ja näited.; Kuidas paljandeid veel nimetatakse? Uuri vastamiseks ka kaarti.

## Pinnamood ja pinnavormid kaardil
URL: https://www.opiq.ee/kit/8/chapter/296
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 1.2
Topics ET: loodusõpetus, pinnamood, pinnavormid, kaardil, absoluutset, kõrgust, arvestatakse, merepinna, tasemest
Topics RU: природоведение
Topics EN: science
Headings: Pinnamood ja pinnavormid kaardil; Pinnamood ja pinnavormid; Absoluutset kõrgust arvestatakse merepinna tasemest; Mõtle!; Suhteline kõrgus aitab võrrelda eri kohtade kõrgust; Mõisted; Ma tean, et …
Task examples: Vaata joonist. Kummalt poolt oleks kergem künka B laele ronida?; Vali lünka õige sõna.

## Eesti suuremad pinnavormid
URL: https://www.opiq.ee/kit/8/chapter/297
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 1.3
Topics ET: loodusõpetus, eesti, suuremad, pinnavormid, kõrg, madal, mõtle, põhja, pankrannik
Topics RU: природоведение
Topics EN: science
Headings: Eesti suuremad pinnavormid; Kõrg- ja Madal-Eesti; Mõtle!; Põhja-Eesti pankrannik; Lisa. Klindi kõrgus; Madal-Eesti on kunagine merepõhi; Kõrg-Eesti pinnamood on mitmekesine; Maapinna läbilõige; Mõisted; Ma tean, et …
Task examples: Lohista pinnavorm õige pealkirja alla.; Kus võib Eestis näha klinti? Vasta kaardi põhjal.

## Mandrijää kujundas pinnamoe
URL: https://www.opiq.ee/kit/8/chapter/298
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 1.4
Topics ET: loodusõpetus, mandrijää, kujundas, pinnamoe, liustik, liikuv, mõtle, kuhjas, setteid
Topics RU: природоведение
Topics EN: science
Headings: Mandrijää kujundas pinnamoe; Liustik on liikuv jää; Mõtle!; Mandrijää kuhjas setteid; Eesti maastikke ilmestavad mandrijäätumise jäljed; Mõisted; Ma tean, et …
Task examples: Uuri kaarti. Leia, milliseid Euroopa riike kattis viimasel jääajal mandrijää.; Kuidas on rändrahnud Eestisse jõudnud?

## Pinnamoe mõju inim­tegevusele ja inimese kujundatud pinnavormid
URL: https://www.opiq.ee/kit/8/chapter/299
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 1.5
Topics ET: loodusõpetus, pinnamoe, mõju, inim, tegevusele, inimese, kujundatud, pinnavormid, loodusele, kasvab
Topics RU: природоведение
Topics EN: science
Headings: Pinnamoe mõju inim­tegevusele ja inimese kujundatud pinnavormid; Inimese mõju loodusele kasvab; Kuidas mõjutab pinnamood inimeste tegevust Eesti eri osades?; Mõtle!; Lisa. Vooremaa; Maavarade kaevandamine muudab pinnamoodi; Mõisted; Ma tean, et …
Task examples: Märgi tegurid, mis on kujundanud Eesti pinnamoodi.; Millest on tekkinud Ida-Virumaa tehismäed?

## Kordamine. Pinnamood ja pinnavormid
URL: https://www.opiq.ee/kit/8/chapter/300
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 1.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, pinnamood, pinnavormid, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Pinnamood ja pinnavormid; Kordamisküsimused

## Mulla teke ja areng
URL: https://www.opiq.ee/kit/8/chapter/301
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 2.1
Topics ET: loodusõpetus, mulla, teke, areng, muld, hinnaline, loodusvara, kivimite, murenemisel
Topics RU: природоведение
Topics EN: science
Headings: Mulla teke ja areng; Muld on hinnaline loodusvara; Kivimite murenemisel tekivad liiv, savi ja kruus; Mullale annab tumeda värvi huumus; Lisa. Huumus ja hummus; Lisa. Muld areneb pidevalt; Mõisted; Ma tean, et …
Task examples: Kuidas nimetatakse kivimite murenemise käigus tekkinud setteid (liiv, savi, kruus)?; Mis tegurid põhjustavad kivimite murenemist?

## Mulla koostis
URL: https://www.opiq.ee/kit/8/chapter/302
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 2.2
Topics ET: loodusõpetus, mulla, koostis, mullas, tahkeid, aineid, vett, õhku, muld
Topics RU: природоведение
Topics EN: science
Headings: Mulla koostis; Mullas on tahkeid aineid, vett ja õhku; Muld on kihiline; Mõtle!; Mulla koostis muutub; Mulla viljakus; Lisa. Maailma mullad; Mõisted; Ma tean, et …
Task examples: Mis on mullasõmerate vahel?; Märgi mulla koostisosad.

## Muld elu­keskkonnana
URL: https://www.opiq.ee/kit/8/chapter/303
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 2.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, muld, keskkonnana, saavad, mullast, vett, toitaineid, mõtle
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Muld elu­keskkonnana; Taimed saavad mullast vett ja toitaineid; Mõtle!; Muld organismide elupaigana; Ma tean, et …
Task examples: Umbrohtu kitkudes on oluline eemaldada umbrohutaim koos maa-aluse osaga. Miks?; Miks on muld taimede jaoks tähtis?

## Mulla­organismid
URL: https://www.opiq.ee/kit/8/chapter/304
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 2.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, mulla, organismid, mullas, elab, palju, organisme, ussid
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Mulla­organismid; Mullas elab palju organisme; Ussid, putukad ja ämblike sugulased; Lisa. Kas teadsid, et ...; Mullas elavad ka suuremad loomad; Mullaorganismid parandavad mulla omadusi; Mõisted; Ma tean, et …
Task examples: Millised mullas elavad organismid võivad olla nii väikesed, et neid näeb ainult mikroskoobiga?; Bakterid ja seened on mullas vajalikud, sest nad ...

## Mullaelustik talvel
URL: https://www.opiq.ee/kit/8/chapter/305
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 2.5
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, taim, taimed, puu, lill, mullaelustik, talvel, mullaelustikku, puhkab, mitmeaastased, tean
Topics RU: природоведение, сравнение, сравни, больше, меньше, растение, растения, дерево, цветок
Topics EN: science, comparison, compare, greater, less, plant, plants, tree, flower
Headings: Mullaelustik talvel; Suurem osa mullaelustikku puhkab talvel; Ühe- ja mitmeaastased taimed; Ma tean, et …
Task examples: Vali lünka õige sõna.; Miks on lumevaene talv mitmeaastastele taimedele ohtlik?

## Vee liikumine mullas
URL: https://www.opiq.ee/kit/8/chapter/306
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 2.6
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, liikumine, mullas, tõuseb, tänu, kapillaarsusele, mõtle, sõltub
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Vee liikumine mullas; Vesi tõuseb mullas tänu kapillaarsusele; Mõtle!; Vee liikumine mullas sõltub mulla koostisest; Lisa. Turvas lillepotis; Vesi kantakse taimes laiali; Ma tean, et …
Task examples: Mis on kapillaarsus?; Mis nähtus võimaldab veel mullas alt ülespoole liikuda?

## Kordamine. Muld
URL: https://www.opiq.ee/kit/8/chapter/307
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 2.7
Topics ET: loodusõpetus, kordamine, korda, harjutan, muld, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Muld; Kordamisküsimused

## Aed ja põld elu­keskkonnana
URL: https://www.opiq.ee/kit/8/chapter/308
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.1
Topics ET: loodusõpetus, põld, keskkonnana, kultuurtaimed, võistlevad, umbrohtudega, elutingimused, põllul, aias
Topics RU: природоведение
Topics EN: science
Headings: Aed ja põld elu­keskkonnana; Kultuurtaimed võistlevad umbrohtudega; Elutingimused põllul; Aias on elutingimused mitmekesisemad kui põllul; Mõisted; Ma tean, et …
Task examples: Keda nimetatakse kahjuriteks?; Mis on kultuurtaimed?

## Kordamine. Aed ja põld
URL: https://www.opiq.ee/kit/8/chapter/317
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.10
Topics ET: loodusõpetus, kordamine, korda, harjutan, põld, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Aed ja põld; Kordamisküsimused

## Kuidas sündisid põllud?
URL: https://www.opiq.ee/kit/8/chapter/309
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.2
Topics ET: loodusõpetus, kuidas, sündisid, põllud, alepõld, põlispõld, mõtle, viljavaheldus, liblikõielised
Topics RU: природоведение
Topics EN: science
Headings: Kuidas sündisid põllud?; Alepõld ja põlispõld; Mõtle!; Viljavaheldus; Liblikõielised; Lisa. Rauast tööriistad võimaldasid harida suuremaid põlde; Mõisted; Ma tean, et …
Task examples: Mis on peamine põhjus, miks jäetakse põld sööti?; Ühel ja samal põllul kasvatatakse palju aastaid järjest ühte ja sama kultuurtaime. Mis juhtub ...

## Põllud ja mullaviljakus
URL: https://www.opiq.ee/kit/8/chapter/310
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.3
Topics ET: loodusõpetus, põllud, mullaviljakus, eestis, erinevaid, muldi, põldu, harides, tuleb
Topics RU: природоведение
Topics EN: science
Headings: Põllud ja mullaviljakus; Eestis on erinevaid muldi; Põldu harides tuleb arvestada mulla omadustega; Väetisi ja taimekaitsevahendeid tuleb kasutada mõistlikult; Muldade kaitse ja mahepõllundus; Mõtle!; Mõisted; Ma tean, et …
Task examples: Millistes Eesti piirkondades on suured viljakate muldadega alad? Märgi kaardi põhjal kaks piirkonda.; Mida teha, et põllud oleksid elurikkamad? Vaata vastamiseks ka videot.

## Põllutaimed
URL: https://www.opiq.ee/kit/8/chapter/311
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.4
Topics ET: loodusõpetus, põllutaimed, teraviljad, kartul, juurviljad, lisa, värvilised, raps, lina
Topics RU: природоведение
Topics EN: science
Headings: Põllutaimed; Teraviljad; Kartul ja juurviljad; Lisa. Värvilised juurviljad; Raps ja lina; Lisa. Kuidas kasvab tatar?; Ma tean, et …
Task examples: Mida millest tehakse? Ühenda paarid.; Mis teravili on pildil?

## Põlluloomad
URL: https://www.opiq.ee/kit/8/chapter/312
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, põlluloomad, põllul, leidub, vähe, loomaliike, põllutööd, segavad, lindude
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Põlluloomad; Põllul leidub vähe loomaliike; Põllutööd segavad lindude pesitsemist; Põllul käivad söömas paljud linnud ja mõned imetajad; Vähesed imetajad saavad põllul elada; Ma tean, et …
Task examples: Tuleta meelde, millised on elutingimused põllul.; Mis ohustab kevadel kündmata põllule pesitsema asunud kiivitajaid ja lõokesi? Mis on sageli selle tagajärg?

## Viljapuu- ja köögiviljaaed
URL: https://www.opiq.ee/kit/8/chapter/313
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.6
Topics ET: loodusõpetus, viljapuu, köögiviljaaed, aedade, mitmekesisus, puuvilja, marjaaed, mõtle, lisa
Topics RU: природоведение
Topics EN: science
Headings: Viljapuu- ja köögiviljaaed; Aedade mitmekesisus; Puuvilja- ja marjaaed; Mõtle!; Lisa. Viljapuude ja marjapõõsaste paljundamine; Köögiviljaaed; Lisa. Naeris; Maitse- ja ravimtaimede aed; Mõisted; Ma tean, et …
Task examples: Meenuta, mille poolest erinevad elutingimused aias ja põllul. Vali lünka õige sõna.; Lohista vastused õige pealkirja alla.

## Iluaed
URL: https://www.opiq.ee/kit/8/chapter/314
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.7
Topics ET: loodusõpetus, taim, taimed, puu, lill, iluaed, iluaia, mõtle, ilupuud, põõsad, lisa, bonsai
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Iluaed; Iluaia taimed; Mõtle!; Ilupuud ja -põõsad; Lisa. Bonsai; Suvikud ja püsikud; Mõisted; Ma tean, et …
Task examples: Mis võib iluaias asuda?; Mis kasu on tänavaäärsest hekist?

## Aialoomad
URL: https://www.opiq.ee/kit/8/chapter/315
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.8
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, aialoomad, aias, elab, rohkem, loomaliike, põllul, leiavad
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Aialoomad; Aias elab rohkem loomaliike kui põllul; Linnud leiavad aiast eri aastaaegadel erinevat toitu; Lisa. Inimeste suhe lindudega; Aedades elab mitmesuguseid imetajaid; Mõtle!; Ma tean, et …
Task examples: Millised elutingimused sobivad kiriteole ja nälkjatele ning meelitavad neid aeda?; Miks ei ole kuldnokad ja rästad marjade valmimise ajal aias teretulnud?

## Umbrohud ja kahjurid
URL: https://www.opiq.ee/kit/8/chapter/316
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 3.9
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, umbrohud, kahjurid, umbrohtudega, raske, võidelda, kultuurtaimedest, toituvad
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Umbrohud ja kahjurid; Umbrohtudega on raske võidelda; Kultuurtaimedest toituvad loomad on inimese silmis kahjurid; Kahjureid saab tõrjuda röövputukatega; Mõtle!; Ma tean, et …
Task examples: Tuleta meelde, milliste elutingimuste pärast peavad kultuurtaimed umbrohtudega võistlema.; Millised umbrohtude omadused teevad võitluse nendega raskeks?

## Asula kujutamine kaardil
URL: https://www.opiq.ee/kit/8/chapter/318
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.1
Topics ET: loodusõpetus, asula, kujutamine, kaardil, kaart, tehakse, foto, järgi, fotode, kaardiga
Topics RU: природоведение
Topics EN: science
Headings: Asula kujutamine kaardil; Kaart tehakse foto järgi; Töö fotode ja kaardiga; Erinevad kaardid; Eesti halduskaart; Töö kaardi ja vappidega; Arvandmeid kujutatakse diagrammil ja tabelis; Eesti suuremad külad 2011. aastal; Ma tean, et …
Task examples: Vali lünka õige sõna.; Kujutle, et oled turismireisil võõras linnas. Millised objektid võiksid sulle kaardil vajalikud olla?

## Asustuse kujunemine
URL: https://www.opiq.ee/kit/8/chapter/319
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.2
Topics ET: loodusõpetus, asustuse, kujunemine, eesti, asustamine, mõtle, külade, areng, asulad
Topics RU: природоведение
Topics EN: science
Headings: Asustuse kujunemine; Eesti ala asustamine; Mõtle!; Külade areng; Asulad kasvavad ja hääbuvad; Ma tean, et …
Task examples: Milline tegur muutus asula kohta valides oluliseks, kui hakati tegelema maaviljelusega?; Milline tegur oli määrav esimeste asulate rajamisel Eesti alal?

## Linna areng
URL: https://www.opiq.ee/kit/8/chapter/320
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.3
Topics ET: loodusõpetus, linna, areng, linnade, teke, kasv, jätkub, linn, omanäoline
Topics RU: природоведение
Topics EN: science
Headings: Linna areng; Linnade teke; Linnade kasv jätkub; Iga linn on omanäoline; Linna arengut suunavad linnaplaneerijad; Mõtle!; Ma tean, et …
Task examples: Kuidas on Tartu arengut mõjutanud linna läbiv raudtee? Vasta kaardi põhjal.; Võrdle Tartu kaarte. Mis näitab, et asustus on nihkunud veepiirini?

## Elutingimused linnas
URL: https://www.opiq.ee/kit/8/chapter/321
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.4
Topics ET: loodusõpetus, elutingimused, linnas, linna, elukooslusi, mõjutab, inimese, tegevus, linn
Topics RU: природоведение
Topics EN: science
Headings: Elutingimused linnas; Linna elukooslusi mõjutab inimese tegevus; Linn sõltub teistest elukooslustest; Linnas on soojem kui lähiümbruses; Mõtle!; Linna õhk on saastatud; Kaetud pinnad jätavad taimedele vähe kasvuruumi; Mõisted; Ma tean, et …
Task examples: Mis iseloomustab elukooslusi linnas?; Mida tähendab, et linna kohal on nn soojussaar?

## Taimed linnas
URL: https://www.opiq.ee/kit/8/chapter/322
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, linnas, kasvavad, vähenõudlikud, saavad, hästi, hakkama, kannatavad
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed linnas; Linnas kasvavad taimed on vähenõudlikud; Linnas saavad hästi hakkama taimed, mis kannatavad tallamist; Mõtle!; Samblike järgi saab otsustada õhu puhtuse üle; Mõisted; Ma tean, et …
Task examples: Mis kasu on linnas puudest?; Milliste elutingimustega peavad olema kohastunud linnas kasvavad taimed?

## Linnaloomad
URL: https://www.opiq.ee/kit/8/chapter/323
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, linnaloomad, linnas, pesitseb, palju, linde, mõtle, imetajad
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnaloomad; Linnas pesitseb palju linde; Mõtle!; Linnud ja imetajad maa-asulates; Osa loomi on leidnud elupaiga hoonetes; Mõisted; Ma tean, et …
Task examples: Märgi linnas tavalised linnud.; Miks kohtab linnas vähe imetajaid?

## Park on linna kõige elusam osa
URL: https://www.opiq.ee/kit/8/chapter/324
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.7
Topics ET: loodusõpetus, park, linna, kõige, elusam, parkides, kasvab, kodumaiseid, võõraid, puuliike
Topics RU: природоведение
Topics EN: science
Headings: Park on linna kõige elusam osa; Parkides kasvab nii kodumaiseid kui ka võõraid puuliike; Lisa. Suurelehine pärn; Lisa. Prantsuse ja inglise stiilis pargid; Pargid on olulised linlaste tervisele; Parkides on vähe imetajaid, kuid palju linde; Mõtle!; Lisa. Surnuaed võib olla isegi linna kõige elusam osa; Mõisted; Ma tean, et …
Task examples: Märgi pargipuud, mis on Eestisse sisse toodud.; Miks on linnapargid inimeste tervisele olulised?

## Kordamine. Asula
URL: https://www.opiq.ee/kit/8/chapter/325
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 4.8
Topics ET: loodusõpetus, kordamine, korda, harjutan, asula, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Asula; Kordamisküsimused

## Elutingimused metsas
URL: https://www.opiq.ee/kit/8/chapter/326
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.1
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, elutingimused, metsas, mõjutavad, puud, üksteist, mets, ökosüsteem, mõtle
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Elutingimused metsas; Metsas mõjutavad puud üksteist; Mets on ökosüsteem; Mõtle!; Lisa. Ökosüsteemid maailmas; Metsas on vähem valgust ning temperatuuri kõikumine väiksem kui lagedal; Loomadel on metsas palju varjepaiku ja mitmekesist toitu; Mõisted; Ma tean, et …
Task examples: Kuidas jõuavad maha langenud puulehtedest pärit ained tagasi taimedesse? Vaata vastamiseks videot. Lohista laused õigesse järjekorda.; Mis iseloomustab elutingimusi metsa all, mis avatud maastikul (põllul või niidul)? Lohista vastused õige pealkirja alla.

## Kordamine. Mets II
URL: https://www.opiq.ee/kit/8/chapter/335
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.10
Topics ET: loodusõpetus, kordamine, korda, harjutan, mets, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Mets II; Kordamisküsimused

## Eesti metsad
URL: https://www.opiq.ee/kit/8/chapter/327
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.2
Topics ET: loodusõpetus, eesti, metsad, millised, metsi, võib, liigitada, seal, kasvavate
Topics RU: природоведение
Topics EN: science
Headings: Eesti metsad; Millised on Eesti metsad?; Metsi võib liigitada ka seal kasvavate puuliikide järgi; Loodusmets ja majandusmets; Metsa uuenemine; Metsad on eri vanusega; Mõtle!; Mõisted; Ma tean, et …
Task examples: Milline on valdav puuliik Saaremaal? Vasta kaardi põhjal.; Millised on tavalisemad puuliigid Eesti metsades?

## Metsarinded
URL: https://www.opiq.ee/kit/8/chapter/328
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, metsarinded, põõsarinne, mõtle, lisa, sarapuu, puhma, rohurinne, sambla
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Metsarinded; Puu- ja põõsarinne; Mõtle!; Lisa. Sarapuu; Puhma- ja rohurinne; Sambla- ja samblikurinne; Lisa. Samblike kasutusviisid; Mõisted; Ma tean, et …
Task examples: Lohista metsarinded õigesse järjekorda.; Mis rindesse taim kuulub?

## Metsatüübid. Nõmme- ja palumets
URL: https://www.opiq.ee/kit/8/chapter/329
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.4
Topics ET: loodusõpetus, metsatüübid, nõmme, palumets, metsatüübi, määravad, mulla, omadused, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Metsatüübid. Nõmme- ja palumets; Metsatüübi määravad mulla omadused; Mõtle!; Mänd on Eestis kõige tavalisem metsapuu; Nõmmemets; Palumets; Lisa. Pohl ja leesikas; Mõisted; Ma tean, et …
Task examples: Mille alusel eristatakse metsatüüpe?; Millised on taimede kasvutingimused nõmmemetsas? Vali lünka õige sõna.

## Metsatüübid. Laane- ja salumets
URL: https://www.opiq.ee/kit/8/chapter/330
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.5
Topics ET: loodusõpetus, metsatüübid, laane, salumets, eestis, kasvab, palju, kuuski, laanemets
Topics RU: природоведение
Topics EN: science
Headings: Metsatüübid. Laane- ja salumets; Eestis kasvab palju kuuski; Laanemets; Salumets; Mõtle!; Mõisted; Ma tean, et …
Task examples: Mille poolest erineb kuusk männist?; Millised on taimede kasvutingimused laanemetsas? Vali lünka õige sõna.

## Kordamine. Mets I
URL: https://www.opiq.ee/kit/8/chapter/331
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, mets, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Mets I; Kordamisküsimused

## Selgrootud ja linnud metsas
URL: https://www.opiq.ee/kit/8/chapter/332
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgrootud, metsas, kuklased, ehitavad, pesi, kuuse, kooreürask
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgrootud ja linnud metsas; Kuklased ehitavad pesi; Kuuse-kooreürask kahjustab puid; Metsade kõige silmatorkavamad asukad on linnud; Mõtle!; Suur-kirjurähn on kõige arvukam rähniliik; Ma tean, et …
Task examples: Vali lünka õige sõna.; Miks metsameestele kuuse-kooreüraskid ei meeldi?

## Imetajad metsas
URL: https://www.opiq.ee/kit/8/chapter/333
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.8
Topics ET: loodusõpetus, imetajad, metsas, mets, paljude, imetajate, elupaik, mõtle, põder
Topics RU: природоведение
Topics EN: science
Headings: Imetajad metsas; Mets on paljude imetajate elupaik; Mõtle!; Põder on suurim sõraline Eestis; Metskits elab väiksemates metsades; Hundil ei ole looduslikke vaenlasi; Pruunkaru on segatoiduline; Mitmekesine metsaelustik; Mõisted; Ma tean, et …
Task examples: Märgi kõik sõralised.; Märgi kõik sõralised.

## Metsade tähtsus ja kasutamine
URL: https://www.opiq.ee/kit/8/chapter/334
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 5.9
Topics ET: loodusõpetus, metsade, tähtsus, kasutamine, mets, kallis, vara, metsad, aitavad
Topics RU: природоведение
Topics EN: science
Headings: Metsade tähtsus ja kasutamine; Mets on kallis vara; Metsad aitavad hoida õhu koostise püsivana ning kaitsevad mulda; Metsandus koos puidutööstusega on Eesti olulisemaid majandusharusid; Metsa tuleb kasutada säästlikult ja mitmekülgselt; Metsades elab palju haruldasi ja ohustatud liike; Metsades on hea puhata; Lisa. Era- ja riigimets; Metsi tuleb kaitsta tule, haiguste ja kahjurite eest; Ma tean, et …
Task examples: Milleks kasutavad inimesed metsa?; Miks on metsad tähtsad sinu, kõigi inimeste ja kogu maailma jaoks? Vaata vastamiseks ka videot.

## Elutingimused soos
URL: https://www.opiq.ee/kit/8/chapter/336
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.1
Topics ET: loodusõpetus, elutingimused, soos, pidevalt, märg, mõtle, turbasamblad, veerikkad, turvas
Topics RU: природоведение
Topics EN: science
Headings: Elutingimused soos; Soos on maa pidevalt märg; Mõtle!; Turbasamblad on veerikkad; Turvas loob taimedele erilise kasvukeskkonna; Lisa. Ajalugu turbas; Lisa. Salapärane soo; Mõisted; Ma tean, et …
Task examples: Märgi väited, mis käivad turbasammalde kohta.; Milline on taimede kasvukeskkond soos?

## Kuidas soo tekib?
URL: https://www.opiq.ee/kit/8/chapter/337
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.2
Topics ET: loodusõpetus, kuidas, tekib, sood, tekivad, väga, pika, jooksul, madalate
Topics RU: природоведение
Topics EN: science
Headings: Kuidas soo tekib?; Sood tekivad väga pika aja jooksul; Madalate maade soostumine; Järve kinnikasvamine; Ma tean, et …
Task examples: Miks võtab soo tekkimine väga kaua aega?; Märgi laused, mis kirjeldavad madalate maade soostumist.

## Soo areng. Madalsoo, siirdesoo ja raba
URL: https://www.opiq.ee/kit/8/chapter/338
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.3
Topics ET: loodusõpetus, areng, madalsoo, siirdesoo, raba, tekkimine, madalsoost, saab, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Soo areng. Madalsoo, siirdesoo ja raba; Madalsoo tekkimine; Madalsoost saab siirdesoo; Mõtle!; Siirdesoost areneb raba; Raba on eripalgeline; Mõisted; Ma tean, et …
Task examples: Märgi madalsoos kasvavad taimed.; Miks ei saa madalsoo taimed kõikjal siirdesoos kasvada?

## Rabataimed
URL: https://www.opiq.ee/kit/8/chapter/339
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, rabataimed, rabataimestik, liigivaene, puhmastel, aitavad, toitaineid, kätte, saada
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Rabataimed; Rabataimestik on liigivaene; Puhmastel aitavad toitaineid kätte saada seened; Huulhein on putuktoiduline taim; Rabataimede lehed on tihti väiksed ja nahkjad; Mõtle!; Rabamurakas; Kääbuskasvulised männid; Mõisted; Ma tean, et …
Task examples: Mis taimedest sõltub kogu raba taimestik?; Kuidas on seened seotud rabamuraka, jõhvika ja sookailuga?

## Raba loomastik
URL: https://www.opiq.ee/kit/8/chapter/340
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, raba, loomastik, ämblikud, konnad, sisalikud, rästikud, lisa
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Raba loomastik; Putukad ja ämblikud; Konnad, sisalikud ja rästikud; Lisa. Rästik; Soo pakub lindudele varje- ja pesitsuspaiku, kuid vähe toitu; Lisa. Hallõgija ja kaljukotkas; Hallõgija; Kaljukotkas; Soos käivad ka mujal pesitsevad linnud; Alaliselt elab rabas vähe imetajaid; Ma tean, et …
Task examples: Miks on soos palju verd imevaid putukaid?; Märgi roomajad, keda võib rabas kohata.

## Soode tähtsus ja kasutamine
URL: https://www.opiq.ee/kit/8/chapter/341
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.6
Topics ET: loodusõpetus, soode, tähtsus, kasutamine, elustiku, jaoks, soos, peituvad, loodusvarad
Topics RU: природоведение
Topics EN: science
Headings: Soode tähtsus ja kasutamine; Soode tähtsus elustiku jaoks; Soos peituvad loodusvarad; Turvast tuleb kasutada säästlikult; Paljudest soodest ei saa head metsa- ega põllumaad; Soid ohustavad kuivendamine, õhusaaste ja kaevandused; Soode taastamine; Ma tean, et …
Task examples: Miks on sood tähtsad?; Milleks turvast kasutatakse?

## Sood ja soo­kaitsealad Eestis
URL: https://www.opiq.ee/kit/8/chapter/342
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.7
Topics ET: loodusõpetus, sood, kaitsealad, eestis, suured, paiknevad, tasastel, aladel, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Sood ja soo­kaitsealad Eestis; Suured sood paiknevad tasastel aladel; Mõtle!; Soode teket soodustab tasane maa ja sademeterohke jahe kliima; Eestis on palju sookaitsealasid; Soomaa viies aastaaeg; Alam-Pedja looduskaitseala; Soos käiakse matkamas; Lisa. Näpunäiteid soos liikumiseks; Ma tean, et …
Task examples: Võrdle soode kaarti Eesti looduskaardiga. Kas sood asuvad pigem kõrgemates või madalamates piirkondades?; Millistes Eesti osades on suuri soid rohkem? Vasta kaardi põhjal.

## Kordamine. Soo
URL: https://www.opiq.ee/kit/8/chapter/343
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 6.8
Topics ET: loodusõpetus, kordamine, korda, harjutan, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Soo; Kordamisküsimused

## Taastuvad ja taastumatud loodusvarad
URL: https://www.opiq.ee/kit/8/chapter/344
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 7.1
Topics ET: loodusõpetus, taastuvad, taastumatud, loodusvarad, lisa, kasulik, kahjulik, loodusvarasid, taastub
Topics RU: природоведение
Topics EN: science
Headings: Taastuvad ja taastumatud loodusvarad; Mis on loodusvarad?; Lisa. Kasulik või kahjulik?; Osa loodusvarasid taastub; Taastumatuid loodusvarasid tuleb tarbida säästlikult; Mõtle!; Lisa. Naftal on palju kasutusviise; Mõisted; Ma tean, et …
Task examples: Kas taastuvaid loodusvarasid võib kasutada piiramatult (nt püüda merest välja kõik kalad)?; Vali lünka õige sõna.

## Loodusvarad energia­allikana
URL: https://www.opiq.ee/kit/8/chapter/345
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 7.2
Topics ET: loodusõpetus, loodusvarad, energia, allikana, mõtle, soojusest, saab, toota, elektrienergiat
Topics RU: природоведение
Topics EN: science
Headings: Loodusvarad energia­allikana; Mis on energia?; Mõtle!; Soojusest saab toota elektrienergiat; Lisa. Kas turvas on taastuv või taastumatu loodusvara?; Energiat saab toota ka voolavast veest ja tuulest; Päikeseenergia on kõige aluseks; Tuumaelektrijaamad on kõige võimsamad; Mõisted; Ma tean, et …
Task examples: Milleks on inimestel energiat vaja?; Vali lünka õige sõna.

## Eesti loodusvarad, nende kasutamine ja kaitse
URL: https://www.opiq.ee/kit/8/chapter/346
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 7.3
Topics ET: loodusõpetus, eesti, loodusvarad, nende, kasutamine, kaitse, loodusvara, lisa, hõredalt
Topics RU: природоведение
Topics EN: science
Headings: Eesti loodusvarad, nende kasutamine ja kaitse; Maa on loodusvara; Lisa. Eesti on hõredalt asustatud; Põllumees hindab maa väärtust mulla põhjal; Mets on Eesti olulisemaid loodusvarasid; Mõtle!; Mets on taastuv loodusvara, mida tuleb hooldada ja kaitsta; Eestis on piisavalt vett; Loodusvarasid tuleb säästlikult kasutada; Ma tean, et …
Task examples: Milleks inimesed maad vajavad? Kirjuta võimalikult palju vastusevariante ja võrdle neid pinginaabri omadega.; Millistel aladel on asustustihedus suurim?

## Eesti maavarad
URL: https://www.opiq.ee/kit/8/chapter/347
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 7.4
Topics ET: loodusõpetus, eesti, maavarad, paiknevad, eestis, ebaühtlaselt, mõtle, ehituses, kasutatakse
Topics RU: природоведение
Topics EN: science
Headings: Eesti maavarad; Maavarad paiknevad Eestis ebaühtlaselt; Mõtle!; Ehituses kasutatakse kohalikke materjale; Eestis kaevandatakse kütuseid; Lisa. Eestis on maavarasid, mille kaevandamine on keskkonnale väga ohtlik; Mõisted; Ma tean, et …
Task examples: Lohista maavarad õige pealkirja alla.; Kus leidub Eestis ravimuda? Vasta kaardi põhjal.

## Kordamine. Eesti loodusvarad
URL: https://www.opiq.ee/kit/8/chapter/348
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 7.5
Topics ET: loodusõpetus, kordamine, korda, harjutan, eesti, loodusvarad, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Eesti loodusvarad; Kordamisküsimused

## Inimese mõju keskkonnale
URL: https://www.opiq.ee/kit/8/chapter/349
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 8.1
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, inimese, mõju, keskkonnale, inimesed, muudavad, keskkonda, mõtle, loonud
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Inimese mõju keskkonnale; Inimesed muudavad keskkonda; Mõtle!; Inimesed on loonud tehiskeskkonna; Inimeste arv maailmas kasvab; Inimesed tarbivad üha enam; Keskkonda peavad kaitsma kõik; Keskkonnaprobleemid ei tunne riigipiire; Mõisted; Ma tean, et …
Task examples: Millistel põhjustel praegu paljud liigid välja surevad? Vaata vastamiseks videot.; Mida saab teha selleks, et tekiks vähem jäätmeid?

## Loodus- ja keskkonna­kaitse Eestis
URL: https://www.opiq.ee/kit/8/chapter/350
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 8.2
Topics ET: loodusõpetus, loodus, keskkond, keskkonna, kaitse, eestis, keskkonnakaitse, erinevus, liikide, elukoosluste
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Loodus- ja keskkonna­kaitse Eestis; Loodus- ja keskkonnakaitse erinevus; Liikide ja elukoosluste kaitse; Mõtle!; Kaitsealasid on mitut tüüpi; Mõisted; Ma tean, et …
Task examples: Milliste teemadega tegeleb keskkonnakaitse, millistega looduskaitse? Lohista sõnad õige pealkirja alla.

## Eesti rahvuspargid
URL: https://www.opiq.ee/kit/8/chapter/351
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 8.3
Topics ET: loodusõpetus, eesti, rahvuspargid, palju, eestis, kaitsealasid, esimene, rahvuspark, lahemaa
Topics RU: природоведение
Topics EN: science
Headings: Eesti rahvuspargid; Kui palju on Eestis kaitsealasid?; Eesti esimene rahvuspark on Lahemaa rahvuspark; Vilsandi rahvuspargis asub Eesti esimene looduskaitseala; Mõtle!; Matsalu rahvuspark on maailmas tuntuim Eesti rahvuspark; Karula rahvuspark hõlmab Karula kõrgustiku kõige väärtuslikuma osa; Alutaguse rahvuspark loodi 2018. aastal; Lisa. Kaitsealad on jagatud vöönditeks; Ma tean, et …
Task examples: Milliste maakondade piiril asub Karula rahvuspark? Vasta kaardi põhjal.; Milliste maakondade piiril asub Soomaa rahvuspark? Vasta kaardi põhjal.

## Niit kui Eesti kõige liigirikkam kooslus
URL: https://www.opiq.ee/kit/8/chapter/352
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 8.4
Topics ET: loodusõpetus, niit, eesti, kõige, liigirikkam, kooslus, niitude, taimestik, liigirikas
Topics RU: природоведение
Topics EN: science
Headings: Niit kui Eesti kõige liigirikkam kooslus; Mis on niit?; Niitude taimestik on liigirikas; Lisa. Käpalised on looduskaitse all; Puisniidud on kõige liigirikkamad kooslused; Kasvutingimused niidul; Niidu loomastik; Mõisted; Ma tean, et …
Task examples: Mille poolest on liblikõielised taimed erilised? Tuleta meelde põllutundides õpitut.; Millised taimed neist on põhilised niidutaimed?

## Pärand­kooslused ja nende kaitse
URL: https://www.opiq.ee/kit/8/chapter/353
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 8.5
Topics ET: loodusõpetus, pärand, kooslused, nende, kaitse, niidud, niitudel, kasvab, palju
Topics RU: природоведение
Topics EN: science
Headings: Pärand­kooslused ja nende kaitse; Niidud on pärand­kooslused; Niitudel kasvab palju mitmesuguseid taimi; Looduskaitse­alused niidud; Maaomanikud saavad maastiku­hoolduseks toetust; Lisa. Vikat ja trimmer; Niidetud hein tuleb koristada; Mõisted; Ma tean, et …
Task examples: Milliseid töid on inimesed põlvkondade jooksul pärandkooslustel teinud?; Miks tuleb väärtuslikke looduslikke niite kaitsta?

## Kordamine. Loodus- ja keskkonna­kaitse Eestis
URL: https://www.opiq.ee/kit/8/chapter/354
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 8.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond, keskkonna, kaitse, eestis, kordamisküsimused
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда
Topics EN: science, revision, review, practice, nature, environment
Headings: Kordamine. Loodus- ja keskkonna­kaitse Eestis; Kordamisküsimused

## Looduspäevik
URL: https://www.opiq.ee/kit/8/chapter/355
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.1
Topics ET: loodusõpetus, looduspäevik, looduspäeviku, täitmise, juhend
Topics RU: природоведение
Topics EN: science
Headings: Looduspäevik; Looduspäeviku täitmise juhend

## Eesti looduskaart
URL: https://www.opiq.ee/kit/8/chapter/356
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.2
Topics ET: loodusõpetus, eesti, looduskaart
Topics RU: природоведение
Topics EN: science
Headings: Eesti looduskaart

## Eesti halduskaart
URL: https://www.opiq.ee/kit/8/chapter/357
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.3
Topics ET: loodusõpetus, eesti, halduskaart
Topics RU: природоведение
Topics EN: science
Headings: Eesti halduskaart

## Eesti kaitsealade kaart
URL: https://www.opiq.ee/kit/8/chapter/358
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.4
Topics ET: loodusõpetus, eesti, kaitsealade, kaart
Topics RU: природоведение
Topics EN: science
Headings: Eesti kaitsealade kaart

## Lisamaterjale uudishimulikele
URL: https://www.opiq.ee/kit/8/chapter/360
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, lisamaterjale, uudishimulikele, kirjandus, eesti, maailma, loodusest, imetajad
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Lisamaterjale uudishimulikele; Kirjandus; Eesti ja maailma loodusest; Imetajad, linnud ja putukad; Taimed; Kivimid; Teadus ja entsüklopeediad; Internetiviited

## Kordamine
URL: https://www.opiq.ee/kit/8/chapter/25883
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, planeedid, planeetide, järjestus, ilmakaared, need, asuvad, molekulid, aatomid
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Planeedid; Planeetide järjestus; Ilmakaared; Kus need ilmakaared asuvad?; Molekulid ja aatomid; Vee koostis; Aine olekute muutumine; Aine eri olekutes

## Mõisted
URL: https://www.opiq.ee/kit/8/chapter/359
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.7
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/8/chapter/20511
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.8
Topics ET: loodusõpetus, sõnaseletused
Topics RU: природоведение
Topics EN: science
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/8/chapter/361
Book: Maakoor koosneb kivimitest
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_est
Chapter ID: 9.9
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Природоведение для 6 класса – Opiq
URL: https://www.opiq.ee/Kit/Details/18
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 442
Topics ET: loodusõpetus, loodus, keskkond, opiq
Topics RU: природоведение, природа, окружающая среда, класса
Topics EN: science, nature, environment

## Земная кора состоит из горных пород
URL: https://www.opiq.ee/kit/18/chapter/799
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 1.1
Topics ET: loodusõpetus
Topics RU: природоведение, земная, кора, состоит, горных, пород, образование, подумай, зернышко
Topics EN: science
Headings: Земная кора состоит из горных пород; Образование горных пород; Подумай; Зернышко за зернышком: так растет осадочная порода; Где можно увидеть горные породы?; Прочитай текст, рассмотри рисунок и ответь на вопросы.; Насколько ценны горные породы?; Понятия; Я знаю, что…
Task examples: Отметь верные утверждения.; Перетащи определения и примеры в правильные колонки.

## Рельеф и формы рельефа на карте
URL: https://www.opiq.ee/kit/18/chapter/800
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 1.2
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem
Topics RU: природоведение, сравнение, сравни, больше, меньше, рельеф, формы, рельефа, карте, абсолютная, высота, места, уровнем
Topics EN: science, comparison, compare, greater, less
Headings: Рельеф и формы рельефа на карте; Рельеф и формы рельефа; Абсолютная высота – высота места над уровнем моря; Подумай; Сравнение высот и относительная высота; Работа с рисунком; Понятия; Я знаю, что…
Task examples: Выбери правильное понятие.; Рассмотри рисунок. По какому склону проще всего забраться на холм Б?

## Крупнейшие формы рельефа Эстонии
URL: https://www.opiq.ee/kit/18/chapter/801
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 1.3
Topics ET: loodusõpetus
Topics RU: природоведение, крупнейшие, формы, рельефа, эстонии, возвышенная, низинная, эстония, подумай
Topics EN: science
Headings: Крупнейшие формы рельефа Эстонии; Возвышенная и Низинная Эстония; Подумай; Северо-Эстонский глинт; Приложение. Высота глинта; Низинная Эстония раньше была морским дном; Разнообразие рельефа Возвышенной Эстонии; Профиль рельефа; Понятия; Я знаю, что…
Task examples: Перетащи названия форм рельефа в подходящую колонку.; Рассмотри карту. Где в Эстонии можно полюбоваться глинтом?

## Ледниковые формы рельефа
URL: https://www.opiq.ee/kit/18/chapter/802
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 1.4
Topics ET: loodusõpetus
Topics RU: природоведение, ледниковые, формы, рельефа, ледник, движущийся, подумай, материковый, принес
Topics EN: science
Headings: Ледниковые формы рельефа; Ледник – движущийся лед; Подумай; Материковый лед принес с собой отложения; Следы ледникового периода в Эстонии повсюду; Понятия; Я знаю, что…
Task examples: Рассмотри карту. Территорию каких современных государств Европы во время последнего ледникового периода покрывал ледник?; Как в Эстонию попали гранитные валуны?

## Влияние рельефа на деятельность человека. Созданные людьми формы рельефа
URL: https://www.opiq.ee/kit/18/chapter/803
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 1.5
Topics ET: loodusõpetus
Topics RU: природоведение, влияние, рельефа, деятельность, человека, созданные, людьми, формы, природу, постоянно
Topics EN: science
Headings: Влияние рельефа на деятельность человека. Созданные людьми формы рельефа; Влияние человека на природу постоянно растет; Как рельеф влияет на деятельность человека в разных областях Эстонии?; Подумай; Приложение. Вооремаа; Добыча полезных ископаемых изменяет рельеф; Понятия; Я знаю, что…
Task examples: Отметь факторы, сформировавшие ландшафт Эстонии.; Из чего сложены терриконы в Ида-Вирумаа?

## Повторение. Рельеф и формы рельефа
URL: https://www.opiq.ee/kit/18/chapter/804
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 1.6
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, рельеф, формы, рельефа, вопросы
Topics EN: science, revision, review, practice
Headings: Повторение. Рельеф и формы рельефа; Вопросы на повторение

## Образование и развитие почв
URL: https://www.opiq.ee/kit/18/chapter/805
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 2.1
Topics ET: loodusõpetus
Topics RU: природоведение, образование, развитие, почв, почва, ценнейшее, природное, богатство, выветривании
Topics EN: science
Headings: Образование и развитие почв; Почва – ценнейшее природное богатство; При выветривании породы образуются песок, глина и гравий; Темный цвет почве придает гумус; Приложение. Хумус; Приложение. Почва постоянно развивается; Понятия; Я знаю, что…
Task examples: Отметь верные утверждения.; Как называется почвенный материал, образовавшийся в ходе выветривания пород?

## Состав почвы
URL: https://www.opiq.ee/kit/18/chapter/806
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 2.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, состав, почвы, почве, содержатся, твердые, вещества, воздух
Topics EN: science, water, water safety, body of water
Headings: Состав почвы; В почве содержатся твердые вещества, вода и воздух; Почва состоит из слоев; Подумай; Состав почвы меняется; Плодородие почвы; Приложение. Какие бывают почвы?; Понятия; Я знаю, что…
Task examples: Что находится между почвенными агрегатами?; Отметь составные части почвы.

## Почва как среда обитания
URL: https://www.opiq.ee/kit/18/chapter/807
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 2.3
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, почва, среда, обитания, почвы, получают, воду, питательные, вещества
Topics EN: science, plant, plants, tree, flower
Headings: Почва как среда обитания; Из почвы растения получают воду и питательные вещества; Подумай; Почва как место обитания организмов; Я знаю, что…
Task examples: Пропалывая грядки, важно удалять сорняки вместе с корнями. Почему?; Почему почва важна для растений?

## Почвенные организмы
URL: https://www.opiq.ee/kit/18/chapter/808
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 2.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, почвенные, организмы, почве, живет, множество, организмов, черви
Topics EN: science, animal, animals, birds, insects
Headings: Почвенные организмы; В почве живет множество организмов; Черви, насекомые и паукообразные; Приложение. Знаешь ли ты, что...; В почве обитают и более крупные животные; Почвенные организмы улучшают свойства почвы; Понятия; Я знаю, что…
Task examples: Какие почвенные организмы можно разглядеть только в микроскоп?; Бактерии и грибы в почве необходимы, потому что ...

## Обитатели почвы зимой
URL: https://www.opiq.ee/kit/18/chapter/809
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 2.5
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, обитатели, почвы, зимой, большинство, почвенных, организмов, отдыхают, однолетние
Topics EN: science, plant, plants, tree, flower
Headings: Обитатели почвы зимой; Большинство почвенных организмов зимой отдыхают; Однолетние и многолетние растения; Я знаю, что…
Task examples: Почему малоснежные зимы опасны для многолетних растений?; Перетащи признаки растений в подходящую колонку.

## Движение воды в почве
URL: https://www.opiq.ee/kit/18/chapter/810
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 2.6
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, движение, воды, почве, может, подниматься, благодаря, капиллярности, подумай
Topics EN: science, water, water safety, body of water
Headings: Движение воды в почве; Вода в почве может подниматься благодаря капиллярности; Подумай; Движение воды зависит от состава почвы; Приложение. Торф в цветочном горшке; Движение воды в растении; Я знаю, что…
Task examples: Что такое капиллярность?; Какое явление позволяет почвенной воде двигаться вверх?

## Повторение. Почва
URL: https://www.opiq.ee/kit/18/chapter/811
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 2.7
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, почва, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Почва; Вопросы для повторения

## Сад и поле как природное сообщество
URL: https://www.opiq.ee/kit/18/chapter/812
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.1
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, поле, природное, сообщество, культурные, конкурируют, сорняками, условия
Topics EN: science, plant, plants, tree, flower
Headings: Сад и поле как природное сообщество; Культурные растения конкурируют с сорняками; Условия жизни в поле; Условия жизни в саду разнообразнее, чем в поле; Понятия; Я знаю, что…
Task examples: Кого называют вредителями?; Что такое культурные растения?

## Повторение. Сад и поле
URL: https://www.opiq.ee/kit/18/chapter/821
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.10
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, поле, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Сад и поле; Вопросы для повторения

## Как появились поля?
URL: https://www.opiq.ee/kit/18/chapter/813
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.2
Topics ET: loodusõpetus
Topics RU: природоведение, появились, поля, подсечное, пашенное, земледелие, подумай, севооборот, чередование
Topics EN: science
Headings: Как появились поля?; Подсечное и пашенное земледелие; Подумай; Севооборот, или чередование полевых культур; Бобовые; Приложение. С появлением железных орудий увеличились размеры полей; Понятия; Я знаю, что…
Task examples: Выбери правильное понятие.; Что такое севооборот?

## Поле и плодородие почвы
URL: https://www.opiq.ee/kit/18/chapter/814
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.3
Topics ET: loodusõpetus
Topics RU: природоведение, поле, плодородие, почвы, многообразие, почв, эстонии, полеводстве, надо
Topics EN: science
Headings: Поле и плодородие почвы; Многообразие почв Эстонии; В полеводстве надо учитывать свойства почвы; Удобрениями и средствами защиты растений следует пользоваться разумно; Почву необходимо защищать; Подумай; Понятия; Я знаю, что…
Task examples: В каких регионах Эстонии больше всего плодородных почв? Изучи карту и отметь два региона.; Что можно сделать, чтобы поля были богаче видами?

## Основные полевые культуры
URL: https://www.opiq.ee/kit/18/chapter/815
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.4
Topics ET: loodusõpetus
Topics RU: природоведение, основные, полевые, культуры, зерновые, картофель, корнеплоды, приложение, цветные
Topics EN: science
Headings: Основные полевые культуры; Зерновые культуры; Картофель и корнеплоды; Приложение. Цветные овощи; Рапс и лён; Приложение. Как растет гречиха?; Я знаю, что…
Task examples: Что делают из зерна различных злаков? Соедини пары.; Какие злаки изображены на картинках?

## Животный мир поля
URL: https://www.opiq.ee/kit/18/chapter/816
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, животный, поля, поле, мало, животных, полевые, работы, мешают
Topics EN: science, animal, animals, birds, insects
Headings: Животный мир поля; В поле мало животных; Полевые работы мешают гнездованию птиц; Многие птицы и некоторые млекопитающие находят пищу в поле; Немногие млекопитающие могут обитать в поле; Я знаю, что…
Task examples: Вспомни, каковы условия жизни в поле. Отметь все верные ответы.; Что угрожает чибисам и жаворонкам, начавшим гнездование ранней весной на невспаханном поле?

## Огород и фруктовый сад
URL: https://www.opiq.ee/kit/18/chapter/817
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.6
Topics ET: loodusõpetus
Topics RU: природоведение, огород, фруктовый, многообразие, садов, ягодный, подумай, приложение, размножение
Topics EN: science
Headings: Огород и фруктовый сад; Многообразие садов; Фруктовый и ягодный сад; Подумай; Приложение. Размножение фруктовых деревьев и ягодных кустов; Огород; Приложение. Репа; Сад пряных и лекарственных трав; Понятия; Я знаю, что…
Task examples: Вспомни, чем отличаются условия в поле и в саду. Заполни пропуски.; Распредели плоды в правильные колонки.

## Декоративный сад
URL: https://www.opiq.ee/kit/18/chapter/818
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.7
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, декоративный, декоративного, сада, подумай, декоративные, деревья, кустарники
Topics EN: science, plant, plants, tree, flower
Headings: Декоративный сад; Растения декоративного сада; Подумай; Декоративные деревья и кустарники; Приложение. Бонсай; Однолетние и многолетние цветы; Понятия; Я знаю, что…
Task examples: Что может находится в декоративном саду?; Какую пользу приносят живые изгороди вдоль дорог?

## Животные – обитатели сада
URL: https://www.opiq.ee/kit/18/chapter/819
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.8
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, aeg, kell, kalender, loom, loomad, linnud, putukad
Topics RU: природоведение, сравнение, сравни, больше, меньше, время, часы, календарь, животное, животные, птицы, насекомые, обитатели, сада, саду, обитает, видов, поле
Topics EN: science, comparison, compare, greater, less, time, clock, calendar, animal, animals, birds, insects
Headings: Животные – обитатели сада; В саду обитает больше видов, чем в поле; В разное время года птицы находят в саду разную пищу; Приложение. Отношения людей и птиц; В садах обитают разные млекопитающие; Подумай; Я знаю, что…
Task examples: Какие условия жизни подходят улитке и слизню? Что привлекает их в сад?; Почему человек не рад скворцам и дроздам во время созревания урожая?

## Сорняки и вредители
URL: https://www.opiq.ee/kit/18/chapter/820
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 3.9
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, сорняки, вредители, сорняками, сложно, бороться, сада, вредителей
Topics EN: science, animal, animals, birds, insects
Headings: Сорняки и вредители; С сорняками сложно бороться; Животные-вредители сада; Вредителей можно истребить при помощи хищных насекомых; Подумай; Я знаю, что…
Task examples: За какие ресурсы конкурируют культурные растения и сорняки?; Какие свойства сорняков делают борьбу с ними такой сложной?

## Изображение поселений на карте
URL: https://www.opiq.ee/kit/18/chapter/822
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение, изображение, поселений, карте, карты, составляют, фотографиям, работа, фотографиями, картой
Topics EN: science
Headings: Изображение поселений на карте; Карты составляют по фотографиям; Работа с фотографиями и картой; Карты бывают разными; Административная карта Эстонии; Работа с картой; Числовые данные представляют в виде таблиц и диаграмм; Самые крупные села в Эстонии в 2011 году; Изучи диаграммы и таблицу и ответь на вопросы.; Я знаю, что…
Task examples: Представь, что ты турист и приехал в незнакомый город. Какие объекты тебе нужно видеть на карте этого города?; Рассмотри карту. Отметь уезды, граничащие с Тартумаа.

## Возникновение поселений
URL: https://www.opiq.ee/kit/18/chapter/823
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.2
Topics ET: loodusõpetus
Topics RU: природоведение, возникновение, поселений, заселение, территории, эстонии, подумай, развитие, деревень
Topics EN: science
Headings: Возникновение поселений; Заселение территории Эстонии; Подумай; Развитие деревень; Деревни растут и вымирают; Я знаю, что…
Task examples: Какой фактор стал играть определяющую роль при выборе мест для поселений, когда люди начали заниматься возделыванием земли?; Какой фактор был определяющим при создании первых поселений?

## Развитие города
URL: https://www.opiq.ee/kit/18/chapter/824
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.3
Topics ET: loodusõpetus
Topics RU: природоведение, развитие, города, возникновение, городов, рассмотри, карты, тарту, ответь, вопросы
Topics EN: science
Headings: Развитие города; Возникновение городов; Рассмотри карты города Тарту и ответь на вопросы.; Рост городов продолжается; Каждый город своеобразен; Развитием города управляют планировщики города; Подумай; Я знаю, что…
Task examples: Какое влияние на развитие Тарту оказала постройка железной дороги?; Что показывает, что постройки достигли берегов реки?

## Условия жизни в городе
URL: https://www.opiq.ee/kit/18/chapter/825
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.4
Topics ET: loodusõpetus
Topics RU: природоведение, условия, жизни, городе, природу, города, влияет, деятельность, человека
Topics EN: science
Headings: Условия жизни в городе; На природу города влияет деятельность человека; Город зависит от других сообществ; В городе теплее, чем в его окрестностях; Подумай; Городской воздух загрязнен; Застроенные площади оставляют для растений мало места; Понятия; Я знаю, что…
Task examples: Что характеризует живые сообщества в городе?; Отметь верные утверждения.

## Растительный мир города
URL: https://www.opiq.ee/kit/18/chapter/826
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.5
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, растительный, города, городе, растут, неприхотливые, лучше, выживают
Topics EN: science, plant, plants, tree, flower
Headings: Растительный мир города; В городе растут неприхотливые растения; В городе лучше выживают растения, устойчивые к вытаптыванию; Подумай; По наличию лишайника можно судить о чистоте воздуха; Понятия; Я знаю, что…
Task examples: Какую пользу в городах приносят деревья?; Что препятствует росту растений в городах?

## Животный мир города
URL: https://www.opiq.ee/kit/18/chapter/827
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, животный, города, городе, гнездится, множество, птиц, подумай
Topics EN: science, animal, animals, birds, insects
Headings: Животный мир города; В городе гнездится множество птиц; Подумай; Птицы и животные в сельской местности; Некоторые животные обитают в жилых помещениях; Понятия; Я знаю, что…
Task examples: Отметь птиц, которые часто встречаются в городе.; Почему в городе мало млекопитающих?

## Парк как живая часть города
URL: https://www.opiq.ee/kit/18/chapter/828
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.7
Topics ET: loodusõpetus
Topics RU: природоведение, парк, живая, часть, города, парках, произрастают, местные, экзотические, виды
Topics EN: science
Headings: Парк как живая часть города; В парках произрастают как местные, так и экзотические виды деревьев; Приложение. Липа крупнолистная; Приложение. Парки в английском или французском стиле; Парки важны для здоровья горожан; В парках мало млекопитающих, но много птиц; Подумай; Приложение. Кладбище может быть и самой «живой» частью города; Понятия; Я знаю, что…
Task examples: Отметь в перечне виды парковых деревьев, которые были завезены в Эстонию.; Почему парки важны для здоровья горожан?

## Повторение. Поселения
URL: https://www.opiq.ee/kit/18/chapter/829
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 4.8
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, поселения, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Поселения; Вопросы для повторения

## Условия жизни в лесу
URL: https://www.opiq.ee/kit/18/chapter/830
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.1
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, loom, loomad, linnud, putukad
Topics RU: природоведение, сравнение, сравни, больше, меньше, животное, животные, птицы, насекомые, условия, жизни, лесу, деревья, влияют, друг, друга, экосистема
Topics EN: science, comparison, compare, greater, less, animal, animals, birds, insects
Headings: Условия жизни в лесу; Деревья в лесу влияют друг на друга; Лес – это экосистема; Подумай; Приложение. Экосистемы мира; В лесу меньше света, а температура стабильнее; Животные находят в лесу укрытие и разнообразную пищу; Понятия; Я знаю, что…
Task examples: Отметь верные утверждения.; Как вещества, содержащиеся в опавших листьях дерева, попадают обратно в растения? Посмотри видео и расположи события в правильном порядке.

## Повторение. Лес (II)
URL: https://www.opiq.ee/kit/18/chapter/839
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.10
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Лес (II); Вопросы для повторения

## Леса Эстонии
URL: https://www.opiq.ee/kit/18/chapter/831
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.2
Topics ET: loodusõpetus
Topics RU: природоведение, леса, эстонии, какие, растут, классификация, лесов, основе, преобладающей
Topics EN: science
Headings: Леса Эстонии; Какие леса растут в Эстонии?; Классификация лесов на основе преобладающей породы деревьев; Природные и хозяйственные леса; Обновление леса; Леса бывают разного возраста; Подумай; Понятия; Я знаю, что…
Task examples: Рассмотри карту. Какой вид деревьев преобладает на Сааремаа?; Отметь широко распространенные в лесах Эстонии породы деревьев.

## Лесные ярусы
URL: https://www.opiq.ee/kit/18/chapter/832
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.3
Topics ET: loodusõpetus
Topics RU: природоведение, лесные, ярусы, древесный, ярус, подлесок, подумай, приложение, лещина
Topics EN: science
Headings: Лесные ярусы; Древесный ярус и подлесок; Подумай; Приложение. Лещина; Кустарничковый и травяной ярусы; Прослушай песню о кустарничках на эстонском языке и выполни задания.; Мохово-лишайниковый ярус; Приложение. Применение лишайников; Понятия; Я знаю, что…
Task examples: Расположи лесные ярусы в правильном порядке, начиная с верхнего.; Выбери, к какому ярусу относится растение.

## Типы леса. Сухие и свежие боры
URL: https://www.opiq.ee/kit/18/chapter/833
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.4
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, типы, леса, сухие, свежие, боры, определяется, свойствами, почвы, подумай
Topics EN: science, plant, plants, tree, flower
Headings: Типы леса. Сухие и свежие боры; Тип леса определяется свойствами почвы; Подумай; Сосна – наиболее распространенное в эстонских лесах дерево; Сухие боры; Свежие боры; Приложение. Брусника и толокнянка; Понятия; Я знаю, что…
Task examples: На основании чего классифицируют типы лесов?; Отметь верные предложения.

## Типы леса. Ельники и широколист­венные леса
URL: https://www.opiq.ee/kit/18/chapter/834
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.5
Topics ET: loodusõpetus
Topics RU: природоведение, типы, леса, ельники, широколист, венные, эстонии, растет, много, елей
Topics EN: science
Headings: Типы леса. Ельники и широколист­венные леса; В Эстонии растет много елей; Свежие ельники; Сложные ельники и широколиственные леса; Подумай; Понятия; Я знаю, что…
Task examples: Чем ель отличается от сосны?; Каковы условия в свежих ельниках? Заполни пропуски.

## Повторение. Лес (I)
URL: https://www.opiq.ee/kit/18/chapter/835
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.6
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Лес (I); Вопросы для повторения

## Беспозвоноч­ные и птицы в лесу
URL: https://www.opiq.ee/kit/18/chapter/836
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, беспозвоноч, лесу, муравьи, возводят, муравейники, большой, еловый
Topics EN: science, animal, animals, birds, insects
Headings: Беспозвоноч­ные и птицы в лесу; Муравьи возводят муравейники; Большой еловый короед наносит вред деревьям; Самые заметные обитатели лесов – птицы; Подумай; Большой пестрый дятел – самый многочисленный вид дятлов; Я знаю, что…
Task examples: Почему лесники не любят короедов?; Почему зяблик является самой распространенной певчей птицей в Эстонии?

## Млекопитаю­щие в лесу
URL: https://www.opiq.ee/kit/18/chapter/837
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.8
Topics ET: loodusõpetus
Topics RU: природоведение, млекопитаю, лесу, место, обитания, множества, млекопитающих, подумай, лось
Topics EN: science
Headings: Млекопитаю­щие в лесу; Лес – место обитания множества млекопитающих; Подумай; Лось – крупнейшее парнокопытное в Эстонии; Косуля обитает в небольших лесах; У волка нет естественных врагов; Бурый медведь всеяден; Многообразие лесных животных; Понятия; Я знаю, что…
Task examples: Какие из нижеперечисленных животных являются парнокопытными? При необходимости найди дополнительную информацию в интернете.; Выбери правильное понятие.

## Важность лесов и их использование
URL: https://www.opiq.ee/kit/18/chapter/838
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 5.9
Topics ET: loodusõpetus
Topics RU: природоведение, важность, лесов, использование, ценное, достояние, леса, позволяют, поддерживать
Topics EN: science
Headings: Важность лесов и их использование; Лес – это ценное достояние; Леса позволяют поддерживать постоянный состав атмосферы и защищают почву; Лесная и деревообраба­тыва­ю­щая промышленность – одни из важнейших отраслей экономики в Эстонии; С лесом нужно обращаться бережно; В лесах живет множество редких и исчезающих видов; Лес – прекрасное место отдыха; Приложение. Частные и государственные леса; Леса следует защищать от огня, болезней и вредителей; Я знаю, что…
Task examples: Как человек использует леса?; Почему леса важны для тебя, всех людей и всей планеты? Посмотри видео и отметь верные утверждения.

## Условия жизни в болоте
URL: https://www.opiq.ee/kit/18/chapter/840
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.1
Topics ET: loodusõpetus
Topics RU: природоведение, условия, жизни, болоте, почва, постоянно, влажная, подумай, торфяных
Topics EN: science
Headings: Условия жизни в болоте; Почва в болоте постоянно влажная; Подумай; В торфяных мхах содержится много воды; Торф создает для растений особую среду; Приложение. История в торфе; Приложение. Загадочное болото; Понятия; Я знаю, что…
Task examples: Отметь верное утверждение.; Отметь утверждения, которые характеризуют торфяные мхи.

## Как возникает болото?
URL: https://www.opiq.ee/kit/18/chapter/841
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.2
Topics ET: loodusõpetus
Topics RU: природоведение, возникает, болото, формирование, болота, занимает, много, времени, заболачивание
Topics EN: science
Headings: Как возникает болото?; Формирование болота занимает много времени; Заболачивание низинных участков; Зарастание озера; Я знаю, что…
Task examples: Почему болота формируются крайне медленно?; Отметь утверждения, которые описывают заболачивание низинных участков.

## Этапы развития болота. Низинное, переходное и верховое болото
URL: https://www.opiq.ee/kit/18/chapter/842
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.3
Topics ET: loodusõpetus
Topics RU: природоведение, этапы, развития, болота, низинное, переходное, верховое, болото, формирование, низинного
Topics EN: science
Headings: Этапы развития болота. Низинное, переходное и верховое болото; Формирование низинного болота; Низинное болото превращается в переходное; Подумай; Переходное болото превращается в верховое; Верховое болото разнообразно; Понятия; Я знаю, что…
Task examples: Отметь растения низинного болота.; Почему растения низинных болот не могут расти в переходном болоте повсюду?

## Растительность верховых болот
URL: https://www.opiq.ee/kit/18/chapter/843
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.4
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, растительность, верховых, болот, болота, отличается, видовым, разнообразием, грибы
Topics EN: science, plant, plants, tree, flower
Headings: Растительность верховых болот; Растительность болота не отличается видовым разнообразием; Грибы помогают кустарничкам получать питательные вещества; Росянка – насекомоядное растение; У болотных растений маленькие кожистые листья; Подумай; Морошка; Карликовые сосны; Понятия; Я знаю, что…
Task examples: От каких растений зависит состав растительности всего верхового болота?; Как грибы связаны с морошкой, клюквой и багульником?

## Животный мир верховых болот
URL: https://www.opiq.ee/kit/18/chapter/844
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, животный, верховых, болот, пауки, бесхвостые, земноводные, ящерицы
Topics EN: science, animal, animals, birds, insects
Headings: Животный мир верховых болот; Насекомые и пауки; Бесхвостые земноводные, ящерицы и гадюки; Приложение. Гадюка; Болота предлагают птицам укрытие и места гнездования, но мало пищи; Приложение. Cерый сорокопут и беркут; Серый, или большой, сорокопут; Беркут; Посещают болота и птицы, гнездящиеся в других местах; Млекопитающие редко встречаются на болотах; Я знаю, что…
Task examples: Почему в болотах много кровососущих насекомых?; Каких пресмыкающихся можно встретить на болоте?

## Значение болот и их использование
URL: https://www.opiq.ee/kit/18/chapter/845
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.6
Topics ET: loodusõpetus
Topics RU: природоведение, значение, болот, использование, природы, болотах, скрыты, природные, богатства
Topics EN: science
Headings: Значение болот и их использование; Значение болот для природы; В болотах скрыты природные богатства; Торф следует использовать экономно; Лесные и сельскохозяйственные угодья на месте болот; Болотам угрожают осушение, загрязнение воздуха и шахты; Восстановление болот; Я знаю, что…
Task examples: Почему болота важны?; Для чего используется торф?

## Болота и болотные заповедники Эстонии
URL: https://www.opiq.ee/kit/18/chapter/846
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.7
Topics ET: loodusõpetus, aeg, kell, kalender
Topics RU: природоведение, время, часы, календарь, болота, болотные, заповедники, эстонии, крупные, располагаются, равнинах, подумай
Topics EN: science, time, clock, calendar
Headings: Болота и болотные заповедники Эстонии; Крупные болота располагаются на равнинах; Подумай; Возникновению болот способствуют равнинный ландшафт и прохладный влажный климат; В Эстонии много болотных заповедников; Пятое время года в Соомаа; Заповедник Алам-Педья; Походы на болота; Приложение. Советы о том, как передвигаться по болоту; Я знаю, что…
Task examples: Сравни карту болот Эстонии с физической картой Эстонии. Где расположены болота – на возвышенностях или на низменностях?; Рассмотри карту. В каких регионах Эстонии много крупных болот?

## Повторение. Болото
URL: https://www.opiq.ee/kit/18/chapter/847
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 6.8
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, болото, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Болото; Вопросы для повторения

## Возобновляе­мые и невозобновля­емые ресурсы
URL: https://www.opiq.ee/kit/18/chapter/848
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 7.1
Topics ET: loodusõpetus
Topics RU: природоведение, возобновляе, невозобновля, емые, ресурсы, такое, природные, приложение, полезное
Topics EN: science
Headings: Возобновляе­мые и невозобновля­емые ресурсы; Что такое природные ресурсы?; Приложение. Полезное или вредное?; Некоторые природные ресурсы восстанавливаются; Невозобновляемые природные ресурсы надо потреблять бережно; Приложение. Сферы использования нефти; Подумай; Понятия; Я знаю, что…
Task examples: Что из нижеперечисленного является природными ресурсами?; Можно ли использовать возобновляемые природные ресурсы в любом количестве (например, выловить из моря всю рыбу)?

## Природные ресурсы как источник энергии
URL: https://www.opiq.ee/kit/18/chapter/849
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 7.2
Topics ET: loodusõpetus
Topics RU: природоведение, природные, ресурсы, источник, энергии, такое, энергия, подумай, тепла
Topics EN: science
Headings: Природные ресурсы как источник энергии; Что такое энергия?; Подумай; Из тепла можно производить электроэнергию; Приложение. Торф – возобновляемый или невозобновляемый ресурс?; Энергию можно получать из текучей воды и ветра; Солнечная энергия – основа всей жизни; Самые мощные электростанции – атомные; Понятия; Я знаю, что…
Task examples: Отметь действия, для которых человеку необходима энергия.; Выбери правильное понятие.

## Природные ресурсы Эстонии, их использование и охрана
URL: https://www.opiq.ee/kit/18/chapter/850
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 7.3
Topics ET: loodusõpetus
Topics RU: природоведение, природные, ресурсы, эстонии, использование, охрана, земля, природный, ресурс
Topics EN: science
Headings: Природные ресурсы Эстонии, их использование и охрана; Земля – это природный ресурс; Приложение. Эстония редко заселена; Ценность земли для земледельца зависит от качеств почвы; Лес – важнейший природный ресурс Эстонии; Подумай; Лес – возобновляемый природный ресурс, который нужно беречь; Воды в Эстонии достаточно; Природные ресурсы следует использовать экономно; Я знаю, что…
Task examples: Для чего людям нужна земля? Запиши как можно больше вариантов ответа и сравни их с вариантами соседа по парте.; Где плотность населения наибольшая?

## Полезные ископаемые Эстонии
URL: https://www.opiq.ee/kit/18/chapter/851
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 7.4
Topics ET: loodusõpetus
Topics RU: природоведение, полезные, ископаемые, эстонии, распределены, неравномерно, подумай, строительстве, используется
Topics EN: science
Headings: Полезные ископаемые Эстонии; Полезные ископаемые в Эстонии распределены неравномерно; Подумай; В строительстве используется местное сырье; В Эстонии добывают топливо; Приложение. В Эстонии есть «опасные для окружающей среды» полезные ископаемые; Понятия; Я знаю, что…
Task examples: Перетащи название полезных ископаемых под соответствующий заголовок.; Выбери правильное полезное ископаемое.

## Повторение. Природные ресурсы Эстонии
URL: https://www.opiq.ee/kit/18/chapter/852
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 7.5
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, природные, ресурсы, эстонии, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Природные ресурсы Эстонии; Вопросы для повторения

## Влияние человека на природу
URL: https://www.opiq.ee/kit/18/chapter/853
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 8.1
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis
Topics RU: природоведение, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье, влияние, человека, природу, меняет, окружающую, среду, подумай
Topics EN: science, comparison, compare, greater, less, human, body, senses, health
Headings: Влияние человека на природу; Человек меняет окружающую среду; Подумай; Люди сформировали искусственную среду; Численность населения в мире растет; Люди потребляют все больше; Окружающую среду должны защищать все; Экологические проблемы не знают государственных границ; Понятия; Я знаю, что…
Task examples: Отметь верные утверждения.; Отметь верные утверждения.

## Охрана природы и окружающей среды в Эстонии
URL: https://www.opiq.ee/kit/18/chapter/854
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 8.2
Topics ET: loodusõpetus
Topics RU: природоведение, охрана, природы, окружающей, среды, эстонии, различия, охране, видов
Topics EN: science
Headings: Охрана природы и окружающей среды в Эстонии; Различия в охране природы и охране окружающей среды; Охрана видов и сообществ; Подумай; Типы заповедников; Понятия; Я знаю, что…
Task examples: Что является объектом охраны природы, а что – объектом охраны окружающей среды? Перетащи объекты в подходящую колонку.; Отметь верное утверждение.

## Национальные парки Эстонии
URL: https://www.opiq.ee/kit/18/chapter/855
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 8.3
Topics ET: loodusõpetus
Topics RU: природоведение, национальные, парки, эстонии, сколько, охраняемых, территорий, рассмотри, карту, ответь
Topics EN: science
Headings: Национальные парки Эстонии; Сколько в Эстонии охраняемых территорий?; Рассмотри карту и ответь на вопросы.; Лахемааский национальный парк – старейший национальный парк в Эстонии; В состав национального парка Вилсанди входит первый в Эстонии природный заповедник; Подумай; Матсалу – самый известный в мире национальный парк Эстонии; Национальный парк Карула охватывает самую ценную часть возвышенности Карула; Национальный парк Алутагузе был создан в 2018 году; Приложение. Заповедники поделены на зоны; Я знаю, что…
Task examples: В каких уездах находится национальный парк Карула?; В каких уездах находится национальный парк Соомаа?

## Луг как самое богатое видами сообщество Эстонии
URL: https://www.opiq.ee/kit/18/chapter/856
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 8.4
Topics ET: loodusõpetus
Topics RU: природоведение, самое, богатое, видами, сообщество, эстонии, такое, растительность, лугов
Topics EN: science
Headings: Луг как самое богатое видами сообщество Эстонии; Что такое луг?; Растительность лугов богата видами; Приложение. Орхидные находятся под охраной; Лесолуга – самые богатые видами сообщества; Условия жизни на лугу; Животный мир луга; Понятия; Я знаю, что…
Task examples: Выбери правильный вариант ответа.; Вспомни изученный ранее материал. В чем особенность бобовых растений?

## Полуприродные сообщества и их охрана
URL: https://www.opiq.ee/kit/18/chapter/857
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 8.5
Topics ET: loodusõpetus
Topics RU: природоведение, полуприродные, сообщества, охрана, луга, лугах, произрастают, многие, виды
Topics EN: science
Headings: Полуприродные сообщества и их охрана; Луга – полуприродные сообщества; На лугах произрастают многие виды растений; Охраняемые луга; Землевладельцы получают пособия по уходу за ландшафтом; Приложение. Триммер и коса; Скошенное сено надо убирать; Понятия; Я знаю, что…
Task examples: Что на протяжении веков делал человек в полуприродных сообществах?; Почему необходимо сохранить природные луга?

## Повторение. Охрана природы и окружающей среды в Эстонии
URL: https://www.opiq.ee/kit/18/chapter/858
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 8.6
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, охрана, природы, окружающей, среды, эстонии, вопросы, повторения
Topics EN: science, revision, review, practice
Headings: Повторение. Охрана природы и окружающей среды в Эстонии; Вопросы для повторения

## Дневник природы
URL: https://www.opiq.ee/kit/18/chapter/859
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 9.1
Topics ET: loodusõpetus
Topics RU: природоведение, дневник, природы, руководство, ведению, дневника
Topics EN: science
Headings: Дневник природы; Руководство по ведению дневника природы

## Физическая карта Эстонии
URL: https://www.opiq.ee/kit/18/chapter/860
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 9.2
Topics ET: loodusõpetus
Topics RU: природоведение, физическая, карта, эстонии
Topics EN: science
Headings: Физическая карта Эстонии

## Административная карта Эстонии
URL: https://www.opiq.ee/kit/18/chapter/861
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 9.3
Topics ET: loodusõpetus
Topics RU: природоведение, административная, карта, эстонии
Topics EN: science
Headings: Административная карта Эстонии

## Карта заповедников Эстонии
URL: https://www.opiq.ee/kit/18/chapter/862
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 9.4
Topics ET: loodusõpetus
Topics RU: природоведение, карта, заповедников, эстонии
Topics EN: science
Headings: Карта заповедников Эстонии

## Дополнитель­ные материалы для любозна­тель­ных
URL: https://www.opiq.ee/kit/18/chapter/864
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 9.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, дополнитель, материалы, любозна, тель, литература
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Дополнитель­ные материалы для любозна­тель­ных; Литература; Животные, птицы и насекомые; Растения; Энциклопедии; Интересные сайты о природе

## Понятия
URL: https://www.opiq.ee/kit/18/chapter/24285
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 9.6
Topics ET: loodusõpetus
Topics RU: природоведение, понятия
Topics EN: science
Headings: Понятия

## Импрессум
URL: https://www.opiq.ee/kit/18/chapter/865
Book: Земная кора состоит из горных пород
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 5k_loodusõpetus_avita_rus
Chapter ID: 9.7
Topics ET: loodusõpetus
Topics RU: природоведение, импрессум
Topics EN: science
Headings: Импрессум

## Loodusõpetus 6. klassile 2025 – Opiq
URL: https://www.opiq.ee/Kit/Details/580
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 287
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Muld
URL: https://www.opiq.ee/kit/580/chapter/32158
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.1
Topics ET: loodusõpetus, muld
Topics RU: природоведение
Topics EN: science
Headings: Muld

## Mulla koostis
URL: https://www.opiq.ee/kit/580/chapter/32150
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.2
Topics ET: loodusõpetus, mulla, koostis, millest, muld, koosneb, proovi, järele, huumus, huumuse
Topics RU: природоведение
Topics EN: science
Headings: Mulla koostis; Millest muld koosneb?; Proovi järele; Huumus; Huumuse teke; Pean meeles; Küsimusi ja ülesandeid; Rühmita mulla koostisosad; Edasimõtlemiseks ja uurimiseks

## Muldade teke ja areng
URL: https://www.opiq.ee/kit/580/chapter/32151
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.3
Topics ET: loodusõpetus, muldade, teke, areng, kuidas, muld, tekib, mullateket, mõjutavad, tegurid
Topics RU: природоведение
Topics EN: science
Headings: Muldade teke ja areng; Kuidas muld tekib?; Mullateket mõjutavad tegurid; Pean meeles; Küsimusi ja ülesandeid; Mulla tekkimine; Edasimõtlemiseks ja uurimiseks

## Mulla­organismid
URL: https://www.opiq.ee/kit/580/chapter/32152
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.4
Topics ET: loodusõpetus, mulla, organismid, elab, sees, mullaelustik, talvel, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Mulla­organismid; Kes elab mulla sees?; Mullaelustik talvel; Pean meeles; Küsimusi ja ülesandeid; Mullaorganismid; Edasimõtlemiseks ja uurimiseks

## Aineringe
URL: https://www.opiq.ee/kit/580/chapter/32153
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.5
Topics ET: loodusõpetus, aineringe, vihmausside, tähtsus, vihmaussid, lagundajad, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Aineringe; Vihmausside tähtsus; Vihmaussid; Lagundajad; Pean meeles; Küsimusi ja ülesandeid; Arvuta; Edasimõtlemiseks ja uurimiseks

## Mulla osa kooslustes
URL: https://www.opiq.ee/kit/580/chapter/32154
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.6
Topics ET: loodusõpetus, mulla, kooslustes, taimestik, sõltub, mullast, muld, kultuurtaimed, temperatuur, niiskus
Topics RU: природоведение
Topics EN: science
Headings: Mulla osa kooslustes; Taimestik sõltub mullast; Muld ja taimestik; Muld ja kultuurtaimed; Temperatuur; Niiskus; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Mullakaeve
URL: https://www.opiq.ee/kit/580/chapter/32155
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.7
Topics ET: loodusõpetus, mullakaeve, muld, kihilise, ehitusega, pean, meeles, küsimusi, ülesandeid, mullahorisondid
Topics RU: природоведение
Topics EN: science
Headings: Mullakaeve; Muld on kihilise ehitusega; Pean meeles; Küsimusi ja ülesandeid; Mullahorisondid; Praktiline töö. Kirjelda mullakaevet.

## Vee liikumine mullas
URL: https://www.opiq.ee/kit/580/chapter/32156
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.8
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, liikumine, mullas, liigub, mullapoorides, liiv, savi, pean, meeles
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Vee liikumine mullas; Vesi liigub mullapoorides; Liiv ja savi; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/580/chapter/32157
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 1.9
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Aed ja põld elukeskkonnana
URL: https://www.opiq.ee/kit/580/chapter/32170
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.1
Topics ET: loodusõpetus, põld, elukeskkonnana
Topics RU: природоведение
Topics EN: science
Headings: Aed ja põld elukeskkonnana

## Mulla reostumine ja hävimine
URL: https://www.opiq.ee/kit/580/chapter/32167
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.10
Topics ET: loodusõpetus, mulla, reostumine, hävimine, kuidas, võivad, inimesed, mulda, kahjustada, väetamise
Topics RU: природоведение
Topics EN: science
Headings: Mulla reostumine ja hävimine; Kuidas võivad inimesed mulda kahjustada?; Väetamise ohud; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Mulla kaitse
URL: https://www.opiq.ee/kit/580/chapter/32168
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.11
Topics ET: loodusõpetus, mulla, kaitse, mille, eest, tuleb, muldi, kaitsta, vaesumine, erosioon
Topics RU: природоведение
Topics EN: science
Headings: Mulla kaitse; Mille eest tuleb muldi kaitsta?; Mulla vaesumine; Erosioon; Maakasutaja kohustused; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/580/chapter/32169
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.12
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused, põllundus, ristsõna
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused; Põllundus. Ristsõna

## Mullaviljakus
URL: https://www.opiq.ee/kit/580/chapter/32159
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.2
Topics ET: loodusõpetus, mullaviljakus, mullaelustik, liblikõieliste, tähtsus, pean, meeles, küsimusi, ülesandeid, mullaviljakuse
Topics RU: природоведение
Topics EN: science
Headings: Mullaviljakus; Mullaviljakus ja mullaelustik; Liblikõieliste tähtsus; Pean meeles; Küsimusi ja ülesandeid; Mullaviljakuse säilitamine; Edasimõtlemiseks ja uurimiseks

## Aia elukooslus
URL: https://www.opiq.ee/kit/580/chapter/32160
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.3
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, elukooslus, kujundab, elukooslust, kapsaliblikad, rasvatihased, lehetäid, lepatriinud, teod
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Aia elukooslus; Inimene kujundab aia elukooslust; Kapsaliblikad ja rasvatihased; Lehetäid ja lepatriinud; Teod ja siilid; Elukoosluse muutlikkus; Toiduahelad aias; Aiakahjurid; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Kes aias?; Edasimõtlemiseks ja uurimiseks

## Fotosüntees
URL: https://www.opiq.ee/kit/580/chapter/32161
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.4
Topics ET: loodusõpetus, fotosüntees, kuidas, toimub, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks, uurimiseks
Topics RU: природоведение
Topics EN: science
Headings: Fotosüntees; Kuidas toimub fotosüntees?; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Aiad ja aiataimed
URL: https://www.opiq.ee/kit/580/chapter/32162
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.5
Topics ET: loodusõpetus, aiad, aiataimed, kultuurtaimed, köögiviljaaiad, kapsal, mitmeid, teisendeid, puuviljaaiad, iluaiad
Topics RU: природоведение
Topics EN: science
Headings: Aiad ja aiataimed; Kultuurtaimed; Köögiviljaaiad; Kapsal on mitmeid teisendeid; Puuviljaaiad; Iluaiad; Tõene või väär?; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Teekummel; Edasimõtlemiseks ja uurimiseks

## Põllu elukooslus
URL: https://www.opiq.ee/kit/580/chapter/32163
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, põllu, elukooslus, põllul, rebane, toiduahelad, pean, meeles
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Põllu elukooslus; Taimed põllul; Loomad põllul; Rebane; Toiduahelad põllul; Pean meeles; Küsimusi ja ülesandeid; Põllutaimed; Edasimõtlemiseks ja uurimiseks

## Bioloogiline ja keemiline tõrje
URL: https://www.opiq.ee/kit/580/chapter/32164
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, bioloogiline, keemiline, tõrje, pean, meeles, küsimusi, ülesandeid, kasulikud, kahjulikud
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Bioloogiline ja keemiline tõrje; Bioloogiline tõrje; Keemiline tõrje; Pean meeles; Küsimusi ja ülesandeid; Kasulikud ja kahjulikud loomad; Edasimõtlemiseks ja uurimiseks

## Mahepõllundus
URL: https://www.opiq.ee/kit/580/chapter/32165
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.8
Topics ET: loodusõpetus, mahepõllundus, mullaviljakuse, tagamine, kompostimine, taimede, kaitsmine, eelised, puudused, pean
Topics RU: природоведение
Topics EN: science
Headings: Mahepõllundus; Mis on mahepõllundus?; Mullaviljakuse tagamine; Kompostimine; Taimede kaitsmine; Eelised ja puudused; Pean meeles; Küsimusi ja ülesandeid; Märke toodetel; Edasimõtlemiseks ja uurimiseks

## Põlluharimise mõju mullale
URL: https://www.opiq.ee/kit/580/chapter/32166
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 2.9
Topics ET: loodusõpetus, põlluharimise, mõju, mullale, maaparandus, mullaharimine, väetised, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Põlluharimise mõju mullale; Maaparandus ja mullaharimine; Väetised; Pean meeles; Küsimusi ja ülesandeid; Põllutööd; Edasimõtlemiseks ja uurimiseks

## Mets
URL: https://www.opiq.ee/kit/580/chapter/32181
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.1
Topics ET: loodusõpetus, mets
Topics RU: природоведение
Topics EN: science
Headings: Mets

## Metsade kaitse
URL: https://www.opiq.ee/kit/580/chapter/32179
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.10
Topics ET: loodusõpetus, metsade, kaitse, metsa, väärtused, jahindus, kaitsealused, metsad, proovi, järele
Topics RU: природоведение
Topics EN: science
Headings: Metsade kaitse; Metsa väärtused; Jahindus; Kaitsealused metsad; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/580/chapter/32180
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.11
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused, mets, ristsõna
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused; Mets. Ristsõna

## Mets kui elukooslus
URL: https://www.opiq.ee/kit/580/chapter/32171
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.2
Topics ET: loodusõpetus, mets, elukooslus, ökosüsteem, elutingimused, metsas, metsarinded, metsatüübid, kaardiga, proovi
Topics RU: природоведение
Topics EN: science
Headings: Mets kui elukooslus; Mis on ökosüsteem?; Elutingimused metsas; Metsarinded; Metsatüübid; Töö kaardiga; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Nõmme- ja palumetsa taimed
URL: https://www.opiq.ee/kit/580/chapter/32172
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, nõmme, palumetsa, elutingimused, nõmmemetsas, mänd, nõmmemetsa, alustaimestu, palumets
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Nõmme- ja palumetsa taimed; Elutingimused nõmmemetsas; Mänd; Nõmmemetsa alustaimestu; Palumets; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Mis taimed?; Edasimõtlemiseks ja uurimiseks

## Nõmme- ja palumetsa loomad
URL: https://www.opiq.ee/kit/580/chapter/32173
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, nõmme, palumetsa, imetajad, mäger, pean, meeles
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Nõmme- ja palumetsa loomad; Putukad; Linnud; Imetajad; Mäger; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Laanemetsa taimed
URL: https://www.opiq.ee/kit/580/chapter/32174
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, laanemetsa, tingimused, laanemetsas, puurinne, alustaimestu, õistaimed, proovi, järele
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Laanemetsa taimed; Tingimused laanemetsas; Puurinne; Laanemetsa alustaimestu; Laanemetsa õistaimed; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Metsatüübid; Edasimõtlemiseks ja uurimiseks

## Laanemetsa loomad
URL: https://www.opiq.ee/kit/580/chapter/32175
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, laanemetsa, imetajad, valgejänes, proovi, järele, pean
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Laanemetsa loomad; Putukad; Linnud; Imetajad; Valgejänes; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Salumetsa taimed
URL: https://www.opiq.ee/kit/580/chapter/32176
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.7
Topics ET: loodusõpetus, taim, taimed, puu, lill, salumetsa, tingimused, salumetsas, puurinne, puulehed, põõsarinne, rohurinne, rohttaimed
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Salumetsa taimed; Tingimused salumetsas; Puurinne; Puulehed; Põõsarinne; Rohurinne; Salumetsa rohttaimed; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Salumetsa loomad
URL: https://www.opiq.ee/kit/580/chapter/32177
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.8
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, salumetsa, mullaloomad, kasekedrik, metsvint, lehelind, imetajad
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Salumetsa loomad; Mullaloomad ja putukad; Kasekedrik; Linnud; Metsvint ja lehelind; Imetajad; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Metsade tähtsus ja kasutamine
URL: https://www.opiq.ee/kit/580/chapter/32178
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 3.9
Topics ET: loodusõpetus, metsade, tähtsus, kasutamine, metsamajandus, majandusmets, loodusmets, mets, loodusvara, proovi
Topics RU: природоведение
Topics EN: science
Headings: Metsade tähtsus ja kasutamine; Metsamajandus; Majandusmets ja loodusmets; Mets kui loodusvara; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Majandusmets ja põlismets; Edasimõtlemiseks ja uurimiseks

## Õhk ja ilm
URL: https://www.opiq.ee/kit/580/chapter/32194
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение
Topics EN: science
Headings: Õhk ja ilm

## Sademed ja sademete mõõtmine
URL: https://www.opiq.ee/kit/580/chapter/32190
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.10
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, sademed, sademete, kuidas, tekivad, tekkimine, liiki, laus, hoogsadu
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Sademed ja sademete mõõtmine; Kuidas tekivad sademed?; Sademete tekkimine; Eri liiki sademed; Laus- ja hoogsadu; Kuidas mõõdetakse sademeid?; Pean meeles; Küsimusi ja ülesandeid; Sademete hulk ööpäevas; Edasimõtlemiseks ja uurimiseks

## Ilm ja ilma ennustamine
URL: https://www.opiq.ee/kit/580/chapter/32191
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.11
Topics ET: loodusõpetus, ilma, ennustamine, millest, sõltub, pean, meeles, küsimusi, ülesandeid, kõrgrõhkkond
Topics RU: природоведение
Topics EN: science
Headings: Ilm ja ilma ennustamine; Millest sõltub ilm?; Ilma ennustamine; Pean meeles; Küsimusi ja ülesandeid; Kõrgrõhkkond ja madalrõhkkond; Edasimõtlemiseks ja uurimiseks

## Taimede ja loomade kohastumisi õhkkeskkonnaga
URL: https://www.opiq.ee/kit/580/chapter/32192
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.12
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, taimede, loomade, kohastumisi, õhkkeskkonnaga, seemnete, levimine, tolmlemine, lendamine, tõene
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Taimede ja loomade kohastumisi õhkkeskkonnaga; Seemnete levimine; Tolmlemine; Lendamine; Tõene või väär. Linnud; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/580/chapter/32193
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.13
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Õhu koostis
URL: https://www.opiq.ee/kit/580/chapter/32182
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.2
Topics ET: loodusõpetus, koostis, katse, küünlaga, gaasid, koostises, koostise, diagramm, lisaained, õhus
Topics RU: природоведение
Topics EN: science
Headings: Õhu koostis; Katse küünlaga; Gaasid õhu koostises; Õhu koostise diagramm; Lisaained õhus; Pean meeles; Küsimusi ja ülesandeid; Arvutamiseks; Edasimõtlemiseks ja uurimiseks

## Hapniku tähtsus: hingamine, põlemine ja kõdunemine
URL: https://www.opiq.ee/kit/580/chapter/32183
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.3
Topics ET: loodusõpetus, hapniku, tähtsus, hingamine, põlemine, kõdunemine, proovi, järele, ainete, ringkäik
Topics RU: природоведение
Topics EN: science
Headings: Hapniku tähtsus: hingamine, põlemine ja kõdunemine; Proovi järele; Hingamine; Põlemine ja kõdunemine; Ainete ringkäik; Pean meeles; Küsimusi ja ülesandeid; Kuidas muutub õhu koostis?; Edasimõtlemiseks ja uurimiseks

## Õhu omadused
URL: https://www.opiq.ee/kit/580/chapter/32184
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.4
Topics ET: loodusõpetus, liitmine, liida, summa, kokku, omadused, täidab, ruumi, väga, kerge, õhku, saab, suruda
Topics RU: природоведение, сложение, сложи, сумма
Topics EN: science, addition, add, sum
Headings: Õhu omadused; Õhk täidab ruumi; Õhk on väga kerge; Õhku saab kokku suruda; Õhurõhk; Soojenemisel õhk paisub; Õhk on halb soojusjuht; Pean meeles; Küsimusi ja ülesandeid; Õhu omaduste kasutamine; Edasimõtlemiseks ja uurimiseks

## Õhkkond
URL: https://www.opiq.ee/kit/580/chapter/32185
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.5
Topics ET: loodusõpetus, õhkkond, õhkkonna, ehitus, suurtel, kõrgustel, tähtsus, miks, lähevad, lennukis
Topics RU: природоведение
Topics EN: science
Headings: Õhkkond; Õhkkonna ehitus; Suurtel kõrgustel; Õhkkonna tähtsus; Miks lähevad lennukis kõrvad lukku?; Pean meeles; Küsimusi ja ülesandeid; Tingimused mäetipus; Edasimõtlemiseks ja uurimiseks

## Õhutemperatuur
URL: https://www.opiq.ee/kit/580/chapter/32186
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.6
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, õhutemperatuur, kuidas, soojeneb, päikesekiirte, langemisnurk, päev, proovi
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Õhutemperatuur; Kuidas õhk soojeneb?; Päikesekiirte langemisnurk; Päev ja öö, suvi ja talv; Proovi järele; Öö ja päeva vaheldumine; Liiva ja vee erinevus; Klimaatilised aastaajad; Mis veel mõjutab temperatuuri?; Pilvede mõju; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Õhutemperatuuri mõõtmine
URL: https://www.opiq.ee/kit/580/chapter/32187
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.7
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, õhutemperatuuri, temperatuuri, graafik, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Õhutemperatuuri mõõtmine; Temperatuuri mõõtmine; Temperatuuri graafik; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Tuul
URL: https://www.opiq.ee/kit/580/chapter/32188
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.8
Topics ET: loodusõpetus, tuul, tuule, iseloomustamine, suund, proovi, järele, kiirus, ilmateates, põhjustab
Topics RU: природоведение
Topics EN: science
Headings: Tuul; Tuule iseloomustamine; Tuule suund; Proovi järele; Tuule kiirus; Tuul ilmateates; Mis põhjustab tuult?; Kuidas töötab tuulelipp?; Vana Toomas; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Pilved
URL: https://www.opiq.ee/kit/580/chapter/32189
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 4.9
Topics ET: loodusõpetus, pilved, kuidas, tekivad, pilvede, liigid, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Pilved; Kuidas tekivad pilved?; Mis on udu?; Pilvede liigid; Pean meeles; Küsimusi ja ülesandeid; Pilvetüübid; Edasimõtlemiseks ja uurimiseks

## Läänemeri
URL: https://www.opiq.ee/kit/580/chapter/33061
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.1
Topics ET: loodusõpetus, läänemeri
Topics RU: природоведение
Topics EN: science
Headings: Läänemeri

## Läänemere reostumine ja kaitse
URL: https://www.opiq.ee/kit/580/chapter/33059
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.10
Topics ET: loodusõpetus, läänemere, reostumine, kaitse, mürkained, läänemeres, toitainete, üleküllus, plastireostus, majandustegevus
Topics RU: природоведение
Topics EN: science
Headings: Läänemere reostumine ja kaitse; Mürkained Läänemeres; Toitainete üleküllus; Plastireostus; Majandustegevus ja laevaliiklus; Pean meeles; Küsimusi ja ülesandeid; Läänemere kaitse; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/580/chapter/33060
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.11
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused; Mis on suurem?

## Elutingimused Läänemeres
URL: https://www.opiq.ee/kit/580/chapter/33051
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.2
Topics ET: loodusõpetus, elutingimused, läänemeres, soolsus, proovi, järele, läänemere, elustik, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Elutingimused Läänemeres; Vee soolsus; Proovi järele; Läänemere elustik; Pean meeles; Küsimusi ja ülesandeid; Läänemere vee soolsus; Edasimõtlemiseks ja uurimiseks

## Läänemere asend ja ümbritsevad riigid
URL: https://www.opiq.ee/kit/580/chapter/33052
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.3
Topics ET: loodusõpetus, läänemere, asend, ümbritsevad, riigid, sisemeri, kaardiga, rannajoon, proovi, järele
Topics RU: природоведение
Topics EN: science
Headings: Läänemere asend ja ümbritsevad riigid; Sisemeri; Töö kaardiga; Rannajoon; Proovi järele; Läänemere saared; Eesti saared; Poolsaared ja lahed; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Läänemere mõju ilmastikule
URL: https://www.opiq.ee/kit/580/chapter/33053
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.4
Topics ET: loodusõpetus, läänemere, mõju, ilmastikule, õhutemperatuurid, kaardiga, tuuled, pilvkate, sademed, ranniku
Topics RU: природоведение
Topics EN: science
Headings: Läänemere mõju ilmastikule; Õhutemperatuurid; Töö kaardiga; Tuuled, pilvkate ja sademed; Ranniku ja sisemaa ilmastik; Atlandi ookeani mõju; Atlandi ookeani mõjud; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Läänemere rannik
URL: https://www.opiq.ee/kit/580/chapter/33054
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.5
Topics ET: loodusõpetus, läänemere, rannik, rand, kaardiga, laiud, rahud, karid, saaremaast, hiiumaast
Topics RU: природоведение
Topics EN: science
Headings: Läänemere rannik; Rand ja rannik; Töö kaardiga; Laiud, rahud ja karid; Saaremaast ja Hiiumaast saab manner; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Vetikad Läänemere elustikus
URL: https://www.opiq.ee/kit/580/chapter/33055
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.6
Topics ET: loodusõpetus, vetikad, läänemere, elustikus, vetikate, roll, elukoosluses, merevetikad, rohevetikad, pruunvetikad
Topics RU: природоведение
Topics EN: science
Headings: Vetikad Läänemere elustikus; Vetikate roll elukoosluses; Merevetikad; Rohevetikad; Pruunvetikad; Punavetikad; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Läänemere selgrootud loomad ja kalad
URL: https://www.opiq.ee/kit/580/chapter/33056
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, läänemere, selgrootud, kalad, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Läänemere selgrootud loomad ja kalad; Selgrootud; Kalad; 1/3 Läänemere kalad; 2/3 Läänemere kalad; 3/3 Läänemere kalad; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Läänemere linnustik
URL: https://www.opiq.ee/kit/580/chapter/33057
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.8
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, läänemere, linnustik, rändlinnud, jagunevad, kaheks, haudelinnud, tõene, väär
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Läänemere linnustik; Rändlinnud jagunevad kaheks; Haudelinnud; Tõene või väär? Läänemere linnud; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Inimtegevus ja rannaasustus
URL: https://www.opiq.ee/kit/580/chapter/33058
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 5.9
Topics ET: loodusõpetus, inimtegevus, rannaasustus, ajalugu, läänemeri, tänapäeval, põhjaranniku, kuulus, kapteniteküla, pean
Topics RU: природоведение
Topics EN: science
Headings: Inimtegevus ja rannaasustus; Ajalugu; Läänemeri tänapäeval; Põhjaranniku kuulus kapteniteküla; Pean meeles; Küsimusi ja ülesandeid; Ristsõna; Edasimõtlemiseks ja uurimiseks

## Eesti loodusvarad
URL: https://www.opiq.ee/kit/580/chapter/33068
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 6.1
Topics ET: loodusõpetus, eesti, loodusvarad
Topics RU: природоведение
Topics EN: science
Headings: Eesti loodusvarad

## Taastuvad ja taastumatud loodusvarad
URL: https://www.opiq.ee/kit/580/chapter/33062
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 6.2
Topics ET: loodusõpetus, taastuvad, taastumatud, loodusvarad, taaskasutus, ringmajandus, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Taastuvad ja taastumatud loodusvarad; Mis on loodusvarad; Taastuvad loodusvarad; Taastumatud loodusvarad; Taaskasutus ja ringmajandus; Pean meeles; Küsimusi ja ülesandeid; Loodusvarad; Edasimõtlemiseks ja uurimiseks

## Loodusvarad energiaallikatena
URL: https://www.opiq.ee/kit/580/chapter/33063
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 6.3
Topics ET: loodusõpetus, loodusvarad, energiaallikatena, milleks, vajame, energiat, kütused, elektrienergia, kaardiga, tuumajaam
Topics RU: природоведение
Topics EN: science
Headings: Loodusvarad energiaallikatena; Milleks me vajame energiat; Kütused; Elektrienergia; Töö kaardiga; Tuumajaam – kas tulevikulahendus?; Pean meeles; Küsimusi ja ülesandeid; Taastuvad energiaallikad; Edasimõtlemiseks ja uurimiseks

## Eesti maavarad
URL: https://www.opiq.ee/kit/580/chapter/33064
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 6.4
Topics ET: loodusõpetus, eesti, maavarad, kivimid, põlevkivi, kaardiga, lubjakivi, savi, liiv, kruus
Topics RU: природоведение
Topics EN: science
Headings: Eesti maavarad; Kivimid; Põlevkivi; Töö kaardiga; Lubjakivi; 1/3 Kivimid; 2/3 Kivimid; 3/3 Kivimid; Savi, liiv, kruus; Turvas; Töö arvutiga; Ravimuda; Fosforiit – tulevikumaavara?; Pean meeles; Küsimusi ja ülesandeid; Maavarade kasutamine; Edasimõtlemiseks ja uurimiseks

## Kaevandamine ja keskkond
URL: https://www.opiq.ee/kit/580/chapter/33065
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 6.5
Topics ET: loodusõpetus, loodus, keskkond, kaevandamine, mõju, keskkonnale, karjäärialade, korrastamine, kestlik, areng, pean
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Kaevandamine ja keskkond; Mõju keskkonnale; Karjäärialade korrastamine; Kestlik areng; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Jäätmed ja keskkond
URL: https://www.opiq.ee/kit/580/chapter/33066
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 6.6
Topics ET: loodusõpetus, loodus, keskkond, jäätmed, mida, teha, jäätmetega, kuidas, prügi, sorteerida, tekstiilijäätmete
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Jäätmed ja keskkond; Mida teha jäätmetega?; Kuidas prügi sorteerida?; Tekstiilijäätmete probleem; Mida saad sina teha?; Pean meeles; Küsimusi ja ülesandeid; Prügi sorteerimine; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/580/chapter/33067
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 6.7
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Loodus- ja keskkonnakaitse Eestis
URL: https://www.opiq.ee/kit/580/chapter/33077
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.1
Topics ET: loodusõpetus, loodus, keskkond, keskkonnakaitse, eestis
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Loodus- ja keskkonnakaitse Eestis

## Eesti looduse elurikkus
URL: https://www.opiq.ee/kit/580/chapter/33069
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.2
Topics ET: loodusõpetus, loodus, keskkond, eesti, looduse, elurikkus, mitmekesine, metsad, sood, rannikumeri, järved
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Eesti looduse elurikkus; Eesti loodus on mitmekesine; Metsad; Sood; Rannikumeri; Järved; Inimese kujundatud ökosüsteem; Eesti loodus – Euroopa viie rikkama seas!; Pean meeles; Küsimusi ja ülesandeid; Ökosüsteemid; Edasimõtlemiseks ja uurimiseks

## Looduslik tasakaal. Inimese mõju loodusele
URL: https://www.opiq.ee/kit/580/chapter/33070
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.3
Topics ET: loodusõpetus, looduslik, tasakaal, inimese, mõju, loodusele, võõrliigid, inimmõju, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Looduslik tasakaal. Inimese mõju loodusele; Looduslik tasakaal; Võõrliigid; Inimmõju; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Keskkonna saastumine ja keskkonnakaitse
URL: https://www.opiq.ee/kit/580/chapter/33071
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.4
Topics ET: loodusõpetus, keskkonna, saastumine, keskkonnakaitse, saasteallikad, müra, võib, olla, saastaja, ravimijäägid
Topics RU: природоведение
Topics EN: science
Headings: Keskkonna saastumine ja keskkonnakaitse; Saasteallikad ja keskkonnakaitse; Ka müra võib olla saastaja; Ravimijäägid; Valgusreostus; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Looduskaitse Eestis. Kaitsealad
URL: https://www.opiq.ee/kit/580/chapter/33072
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.5
Topics ET: loodusõpetus, looduskaitse, eestis, kaitsealad, millega, tegeleb, rahvuspargid, eesti, looduskaitsealad, maastikukaitsealad
Topics RU: природоведение
Topics EN: science
Headings: Looduskaitse Eestis. Kaitsealad; Millega tegeleb looduskaitse?; Rahvuspargid; Eesti rahvuspargid; Looduskaitsealad; Maastikukaitsealad; Töö kaardiga; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kaitsealused üksikobjektid
URL: https://www.opiq.ee/kit/580/chapter/33073
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.6
Topics ET: loodusõpetus, kaitsealused, üksikobjektid, looduskaitse, alused, pean, meeles, küsimusi, ülesandeid, objektid
Topics RU: природоведение
Topics EN: science
Headings: Kaitsealused üksikobjektid; Looduskaitse­alused üksikobjektid; Pean meeles; Küsimusi ja ülesandeid; Kaitsealused objektid 1; Kaitsealused objektid 2; Kaitsealused objektid 3; Kaitsealused objektid 4; Edasimõtlemiseks ja uurimiseks

## Elurikkuse kaitse
URL: https://www.opiq.ee/kit/580/chapter/33074
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.7
Topics ET: loodusõpetus, elurikkuse, kaitse, kaitsealused, liigid, kuidas, kaitstakse, haruldasi, liike, pean
Topics RU: природоведение
Topics EN: science
Headings: Elurikkuse kaitse; Kaitsealused liigid; Kuidas kaitstakse haruldasi liike; Pean meeles; Küsimusi ja ülesandeid; Hoiualad ja püsielupaigad; Edasimõtlemiseks ja uurimiseks

## Niidud on elurikkad pärand­kooslused
URL: https://www.opiq.ee/kit/580/chapter/33075
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.8
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, niidud, elurikkad, pärand, kooslused, eesti, niidul, pean
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Niidud on elurikkad pärand­kooslused; Eesti niidud; Taimed ja loomad niidul; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/580/chapter/33076
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 7.9
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Sõnaseletused
URL: https://www.opiq.ee/kit/580/chapter/32195
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_2025_est
Chapter ID: 8.1
Topics ET: loodusõpetus, sõnaseletused
Topics RU: природоведение
Topics EN: science
Headings: Sõnaseletused

## Loodusõpetus 6. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/98
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 86
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Muld
URL: https://www.opiq.ee/kit/98/chapter/4720
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.1
Topics ET: loodusõpetus, muld
Topics RU: природоведение
Topics EN: science
Headings: Muld

## Mulla koostis
URL: https://www.opiq.ee/kit/98/chapter/4721
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.2
Topics ET: loodusõpetus, mulla, koostis, millest, muld, koosneb, proovi, järele, huumus, pean
Topics RU: природоведение
Topics EN: science
Headings: Mulla koostis; Millest muld koosneb; Proovi järele; Huumus; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Muldade teke ja areng
URL: https://www.opiq.ee/kit/98/chapter/4722
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.3
Topics ET: loodusõpetus, muldade, teke, areng, kuidas, muld, tekib, mullateket, mõjutavad, tegurid
Topics RU: природоведение
Topics EN: science
Headings: Muldade teke ja areng; Kuidas muld tekib; Mullateket mõjutavad tegurid; Pean meeles; Küsimusi ja ülesandeid; Millest moodustub mulda huumus?; Edasimõtlemiseks ja uurimiseks

## Mulla­organismid
URL: https://www.opiq.ee/kit/98/chapter/4723
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.4
Topics ET: loodusõpetus, mulla, organismid, elab, sees, mutt, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Mulla­organismid; Kes elab mulla sees; Mutt; Pean meeles; Küsimusi ja ülesandeid; Mullaorganismid; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Aineringe
URL: https://www.opiq.ee/kit/98/chapter/4724
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.5
Topics ET: loodusõpetus, aineringe, saab, surnud, organismidest, mullas, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Aineringe; Mis saab surnud organismidest mullas?; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?; Arvuta; Edasimõtlemiseks ja uurimiseks

## Mulla osa kooslustes
URL: https://www.opiq.ee/kit/98/chapter/4725
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.6
Topics ET: loodusõpetus, mulla, kooslustes, taimestik, sõltub, mullast, muld, kultuurtaimed, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Mulla osa kooslustes; Taimestik sõltub mullast; Muld ja kultuurtaimed; Pean meeles; Küsimusi ja ülesandeid; Temperatuur; Niiskus; Edasimõtlemiseks ja uurimiseks

## Mullakaeve
URL: https://www.opiq.ee/kit/98/chapter/4726
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.7
Topics ET: loodusõpetus, mullakaeve, muld, kihilise, ehitusega, pean, meeles, küsimusi, ülesandeid, mullahorisondid
Topics RU: природоведение
Topics EN: science
Headings: Mullakaeve; Muld on kihilise ehitusega; Pean meeles; Küsimusi ja ülesandeid; Mullahorisondid; Praktiline töö. Kirjelda mullakaevet.; Tähesegadik

## Vee liikumine mullas
URL: https://www.opiq.ee/kit/98/chapter/4727
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.8
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, liikumine, mullas, liigub, mullapoorides, erinevad, mullad, kuidas, eristada
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Vee liikumine mullas; Vesi liigub mullapoorides; Erinevad mullad; Kuidas eristada muldasid?; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4728
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 1.9
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Aed ja põld elukeskkonnana
URL: https://www.opiq.ee/kit/98/chapter/4729
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.1
Topics ET: loodusõpetus, põld, elukeskkonnana
Topics RU: природоведение
Topics EN: science
Headings: Aed ja põld elukeskkonnana

## Mulla reostumine ja hävimine
URL: https://www.opiq.ee/kit/98/chapter/4738
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.10
Topics ET: loodusõpetus, mulla, reostumine, hävimine, kuidas, võivad, inimesed, mulda, kahjustada, pean
Topics RU: природоведение
Topics EN: science
Headings: Mulla reostumine ja hävimine; Kuidas võivad inimesed mulda kahjustada?; Pean meeles; Küsimusi ja ülesandeid; Kemikaalid põllumajanduses; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Mulla kaitse
URL: https://www.opiq.ee/kit/98/chapter/4739
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.11
Topics ET: loodusõpetus, mulla, kaitse, millega, arvestada, kaitsmisel, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Mulla kaitse; Millega arvestada mulla kaitsmisel; Pean meeles; Küsimusi ja ülesandeid; Karjäärid; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4740
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.12
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Mullaviljakus
URL: https://www.opiq.ee/kit/98/chapter/4730
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.2
Topics ET: loodusõpetus, mullaviljakus, mullaelustik, kuidas, parandavad, liblikõielised, mullaviljakust, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Mullaviljakus; Mullaviljakus ja mullaelustik; Kuidas parandavad liblikõielised mullaviljakust?; Pean meeles; Küsimusi ja ülesandeid; Taimekasvuks sobiv muld; Edasimõtlemiseks ja uurimiseks

## Aed kui elukooslus
URL: https://www.opiq.ee/kit/98/chapter/4731
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.3
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, elukooslus, kujundab, elukooslust, kapsaliblikad, rasvatihased, lehetäid, lepatriinud, teod
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Aed kui elukooslus; Inimene kujundab aia elukooslust; Kapsaliblikad ja rasvatihased; Lehetäid ja lepatriinud; Teod ja siilid; Inimese osa aia elukoosluses; Toiduahelad aias; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Kes aias?; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Fotosüntees
URL: https://www.opiq.ee/kit/98/chapter/4732
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.4
Topics ET: loodusõpetus, fotosüntees, kuidas, toimub, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks, uurimiseks
Topics RU: природоведение
Topics EN: science
Headings: Fotosüntees; Kuidas toimub fotosüntees?; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Aiad ja aiataimed
URL: https://www.opiq.ee/kit/98/chapter/4733
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.5
Topics ET: loodusõpetus, aiad, aiataimed, kultuurtaimed, köögiviljaaiad, kapsal, mitmeid, teisendeid, puuviljaaiad, iluaiad
Topics RU: природоведение
Topics EN: science
Headings: Aiad ja aiataimed; Kultuurtaimed; Köögiviljaaiad; Kapsal on mitmeid teisendeid; Puuviljaaiad; Iluaiad; Tõene või väär?; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Teekummel; Edasimõtlemiseks ja uurimiseks

## Põld kui elukooslus
URL: https://www.opiq.ee/kit/98/chapter/4734
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, põld, elukooslus, põllul, toiduahelad, pean, meeles, küsimusi
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Põld kui elukooslus; Taimed põllul; Loomad põllul; Toiduahelad põllul; Pean meeles; Küsimusi ja ülesandeid; Kas tunned teravilju?; Edasimõtlemiseks ja uurimiseks

## Bioloogiline ja keemiline tõrje
URL: https://www.opiq.ee/kit/98/chapter/4735
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, bioloogiline, keemiline, tõrje, kuidas, tõrjutakse, kahjureid, pean, meeles, küsimusi
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Bioloogiline ja keemiline tõrje; Kuidas tõrjutakse kahjureid; Pean meeles; Küsimusi ja ülesandeid; Kasulikud ja kahjulikud loomad; Edasimõtlemiseks ja uurimiseks

## Mahepõllundus
URL: https://www.opiq.ee/kit/98/chapter/4736
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.8
Topics ET: loodusõpetus, mahepõllundus, väetamine, taimede, kaitsmine, märke, toodetel, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Mahepõllundus; Mis on mahepõllundus?; Väetamine; Taimede kaitsmine; Märke toodetel; Pean meeles; Küsimusi ja ülesandeid; Keemiline või bioloogiline tõrje?; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Inimtegevuse mõju mullale
URL: https://www.opiq.ee/kit/98/chapter/4737
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 2.9
Topics ET: loodusõpetus, inimtegevuse, mõju, mullale, kuidas, tõstetakse, mullaviljakust, põllutööd, väetised, pean
Topics RU: природоведение
Topics EN: science
Headings: Inimtegevuse mõju mullale; Kuidas tõstetakse mullaviljakust?; Põllutööd; Väetised; Pean meeles; Küsimusi ja ülesandeid; Kompostimine; Edasimõtlemiseks ja uurimiseks

## Mets elukeskkonnana
URL: https://www.opiq.ee/kit/98/chapter/4741
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.1
Topics ET: loodusõpetus, mets, elukeskkonnana
Topics RU: природоведение
Topics EN: science
Headings: Mets elukeskkonnana

## Metsade kaitse
URL: https://www.opiq.ee/kit/98/chapter/4750
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.10
Topics ET: loodusõpetus, metsade, kaitse, metsa, väärtused, kaitsealused, metsad, proovi, järele, pean
Topics RU: природоведение
Topics EN: science
Headings: Metsade kaitse; Metsa väärtused; Kaitsealused metsad; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Metsa kasutusvõimalusi; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4751
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.11
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Mets kui elukooslus
URL: https://www.opiq.ee/kit/98/chapter/4742
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.2
Topics ET: loodusõpetus, mets, elukooslus, ökosüsteem, elutingimused, metsas, metsarinded, metsatüübid, kaardiga, proovi
Topics RU: природоведение
Topics EN: science
Headings: Mets kui elukooslus; Mis on ökosüsteem?; Elutingimused metsas; Metsarinded; Metsatüübid; Töö kaardiga; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Nõmme- ja palumetsa taimed
URL: https://www.opiq.ee/kit/98/chapter/4743
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, nõmme, palumetsa, elutingimused, nõmmemetsas, mänd, nõmmemetsa, alustaimestu, palumets
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Nõmme- ja palumetsa taimed; Elutingimused nõmmemetsas; Mänd; Nõmmemetsa alustaimestu; Palumets; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Määra taimed; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Nõmme- ja palumetsa loomad
URL: https://www.opiq.ee/kit/98/chapter/4744
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, nõmme, palumetsa, imetajad, pean, meeles, küsimusi
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Nõmme- ja palumetsa loomad; Putukad; Linnud; Imetajad; Pean meeles; Küsimusi ja ülesandeid; Mäger; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Laanemetsa taimed
URL: https://www.opiq.ee/kit/98/chapter/4745
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, laanemetsa, tingimused, laanemetsas, puurinne, alustaimestu, proovi, järele, pean
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Laanemetsa taimed; Tingimused laanemetsas; Puurinne; Laanemetsa alustaimestu; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Metsatüübid; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Laanemetsa loomad
URL: https://www.opiq.ee/kit/98/chapter/4746
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, laanemetsa, imetajad, proovi, järele, pean, meeles
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Laanemetsa loomad; Putukad; Linnud; Imetajad; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Valgejänes; Edasimõtlemiseks ja uurimiseks; Täherägastik

## Salumetsa taimed
URL: https://www.opiq.ee/kit/98/chapter/4747
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.7
Topics ET: loodusõpetus, taim, taimed, puu, lill, salumetsa, tingimused, salumetsas, puurinne, põõsarinne, rohurinne, proovi, järele
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Salumetsa taimed; Tingimused salumetsas; Puurinne; Põõsarinne; Rohurinne; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Puulehed; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Salumetsa loomad
URL: https://www.opiq.ee/kit/98/chapter/4748
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.8
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, salumetsa, mullaloomad, imetajad, proovi, järele, pean
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Salumetsa loomad; Mullaloomad ja putukad; Linnud; Imetajad; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Metsvint ja lehelind; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Metsade tähtsus ja kasutamine
URL: https://www.opiq.ee/kit/98/chapter/4749
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 3.9
Topics ET: loodusõpetus, metsade, tähtsus, kasutamine, metsamajandus, majandusmets, loodusmets, mets, loodusvara, proovi
Topics RU: природоведение
Topics EN: science
Headings: Metsade tähtsus ja kasutamine; Metsamajandus; Majandusmets ja loodusmets; Mets kui loodusvara; Proovi järele; Pean meeles; Küsimusi ja ülesandeid; Majandusmets ja põlismets; Edasimõtlemiseks ja uurimiseks

## Õhk
URL: https://www.opiq.ee/kit/98/chapter/4752
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение
Topics EN: science
Headings: Õhk

## Õhu liikumine soojenedes
URL: https://www.opiq.ee/kit/98/chapter/4761
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.10
Topics ET: loodusõpetus, liitmine, liida, summa, kokku, liikumine, soojenedes, paisub, jahtudes, tõmbub, katse, esimene, õhupallilend
Topics RU: природоведение, сложение, сложи, сумма
Topics EN: science, addition, add, sum
Headings: Õhu liikumine soojenedes; Soojenedes õhk paisub, jahtudes tõmbub kokku; Katse; Esimene õhupallilend; Pean meeles; Küsimusi ja ülesandeid; Õhutemperatuur eri kõrgustel; Edasimõtlemiseks ja uurimiseks

## Õhu liikumine ja tuul
URL: https://www.opiq.ee/kit/98/chapter/4762
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.11
Topics ET: loodusõpetus, lahutamine, lahuta, vahe, liikumine, tuul, mõjutab, meie, tuule, suund, proovi, järele, kiirus
Topics RU: природоведение, вычитание, вычти, разность
Topics EN: science, subtraction, subtract, difference
Headings: Õhu liikumine ja tuul; Tuul mõjutab meie elu; Tuule suund; Proovi järele; Tuule kiirus; Tuul ja õhurõhkude vahe; Tuulete kujutamine graafiliselt; Töö kaardiga; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kuiv ja niiske õhk
URL: https://www.opiq.ee/kit/98/chapter/4763
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.12
Topics ET: loodusõpetus, kuiv, niiske, õhuniiskus, pean, meeles, küsimusi, ülesandeid, kuiva, võrdlus
Topics RU: природоведение
Topics EN: science
Headings: Kuiv ja niiske õhk; Õhuniiskus ja ilm; Pean meeles; Küsimusi ja ülesandeid; Kuiva ja niiske õhu võrdlus; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Pilved ja sademed
URL: https://www.opiq.ee/kit/98/chapter/4764
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.13
Topics ET: loodusõpetus, pilved, sademed, pilvede, liigid, sademete, tekkimine, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Pilved ja sademed; Pilved; Pilvede liigid; Sademete tekkimine; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Veeringe
URL: https://www.opiq.ee/kit/98/chapter/4765
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.14
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, veeringe, ringleb, maal, energiaallikas, suur, pean, meeles, küsimusi
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Veeringe; Vesi ringleb Maal; Veeringe energiaallikas; Suur veeringe; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Ilm ja ilmastik
URL: https://www.opiq.ee/kit/98/chapter/4766
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.15
Topics ET: loodusõpetus, ilmastik, proovi, järele, meteoroloogid, burromeeter, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Ilm ja ilmastik; Ilm; Proovi järele; Meteoroloogid; Burromeeter; Pean meeles; Küsimusi ja ülesandeid; Ilmastik Eestis; Edasimõtlemiseks ja uurimiseks

## Sademete mõõtmine
URL: https://www.opiq.ee/kit/98/chapter/4767
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.16
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, sademete, kuidas, mõõdetakse, sademeid, kaardiga, sademed, eestis, pean
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Sademete mõõtmine; Kuidas mõõdetakse sademeid?; Töö kaardiga; Sademed Eestis; Pean meeles; Küsimusi ja ülesandeid; Sademete hulk ööpäevas; Aasta sademete hulk; Edasimõtlemiseks ja uurimiseks

## Ilma ennustamine
URL: https://www.opiq.ee/kit/98/chapter/4768
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.17
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, ilma, ennustamine, õhurõhk, ilmakaart, mida, tähendavad, kaardil, madalrõhkkond
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Ilma ennustamine; Õhurõhk; Ilmakaart; Mida tähendavad kaardil arvud?; Madalrõhkkond ja kõrgrõhkkond; Pean meeles; Küsimusi ja ülesandeid; Ilm kõrgrõhualal ja madalrõhualal; Edasimõtlemiseks ja uurimiseks

## Õhu saastumise vältimine
URL: https://www.opiq.ee/kit/98/chapter/4769
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.18
Topics ET: loodusõpetus, saastumise, vältimine, organismid, vajavad, puhast, õhku, transport, põllumajandus, jäätmed
Topics RU: природоведение
Topics EN: science
Headings: Õhu saastumise vältimine; Organismid vajavad puhast õhku; Transport; Põllumajandus; Jäätmed; Pean meeles; Küsimusi ja ülesandeid; Õhusaaste kodukohas; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4770
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.19
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Õhk. Õhu tähtsus
URL: https://www.opiq.ee/kit/98/chapter/4753
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.2
Topics ET: loodusõpetus, tähtsus, kuidas, mõjutab, organisme, pean, meeles, küsimusi, ülesandeid, õhus
Topics RU: природоведение
Topics EN: science
Headings: Õhk. Õhu tähtsus; Mis on õhk?; Kuidas mõjutab õhk organisme?; Pean meeles; Küsimusi ja ülesandeid; Õhus leiduvad gaasid; Edasimõtlemiseks ja uurimiseks

## Ilmastik kui uurimisobjekt
URL: https://www.opiq.ee/kit/98/chapter/4771
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.20
Topics ET: loodusõpetus, ilmastik, uurimisobjekt, vaatlusandmete, kogumine
Topics RU: природоведение
Topics EN: science
Headings: Ilmastik kui uurimisobjekt; Vaatlusandmete kogumine

## Õhkkond
URL: https://www.opiq.ee/kit/98/chapter/4754
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.3
Topics ET: loodusõpetus, õhkkond, atmosfäär, atmosfääri, tähtsus, organismidele, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Õhkkond; Atmosfäär; Atmosfääri tähtsus organismidele; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Organismide kohastumine õhkkeskkonnaga
URL: https://www.opiq.ee/kit/98/chapter/4755
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, organismide, kohastumine, õhkkeskkonnaga, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Organismide kohastumine õhkkeskkonnaga; Taimed; Loomad; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär; Edasimõtlemiseks ja uurimiseks

## Õhu koostis
URL: https://www.opiq.ee/kit/98/chapter/4756
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.5
Topics ET: loodusõpetus, koostis, katse, küünlaga, mida, sisaldab, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Õhu koostis; Katse küünlaga; Mida sisaldab õhk?; Pean meeles; Küsimusi ja ülesandeid; Arvutamiseks; Edasimõtlemiseks ja uurimiseks

## Hapniku tähtsus: hingamine, põlemine ja kõdunemine
URL: https://www.opiq.ee/kit/98/chapter/4757
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.6
Topics ET: loodusõpetus, hapniku, tähtsus, hingamine, põlemine, kõdunemine, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Hapniku tähtsus: hingamine, põlemine ja kõdunemine; Hingamine; Põlemine ja kõdunemine; Pean meeles; Küsimusi ja ülesandeid; Kuidas muutub õhu koostis?; Edasimõtlemiseks ja uurimiseks

## Õhu omadused
URL: https://www.opiq.ee/kit/98/chapter/4758
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.7
Topics ET: loodusõpetus, omadused, millised, õhul, õhurõhk, soojusjuhtivus, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Õhu omadused; Millised omadused on õhul?; Õhurõhk; Soojusjuhtivus; Pean meeles; Küsimusi ja ülesandeid; Tähesegadik

## Õhutemperatuur ja selle mõõtmine
URL: https://www.opiq.ee/kit/98/chapter/4759
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.8
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, õhutemperatuur, selle, temperatuuri, proovi, järele, kuidas, mõjutab, päike
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Õhutemperatuur ja selle mõõtmine; Temperatuuri mõõtmine; Proovi järele; Kuidas mõjutab Päike õhutemperatuuri?; Mis mõjutab veel õhutemperatuuri?; Pean meeles; Küsimusi ja ülesandeid; Öö ja päeva vaheldumine; Edasimõtlemiseks ja uurimiseks

## Õhutemperatuuri ööpäevane muutumine
URL: https://www.opiq.ee/kit/98/chapter/4760
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 4.9
Topics ET: loodusõpetus, õhutemperatuuri, ööpäevane, muutumine, käik, aastane, õhutemperatuurid, eestis, kaardiga, pean
Topics RU: природоведение
Topics EN: science
Headings: Õhutemperatuuri ööpäevane muutumine; Õhutemperatuuri ööpäevane käik; Õhutemperatuuri aastane käik; Õhutemperatuurid Eestis; Töö kaardiga; Pean meeles; Küsimusi ja ülesandeid; Temperatuuri graafik; Edasimõtlemiseks ja uurimiseks

## Läänemeri elukeskkonnana
URL: https://www.opiq.ee/kit/98/chapter/4772
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.1
Topics ET: loodusõpetus, läänemeri, elukeskkonnana
Topics RU: природоведение
Topics EN: science
Headings: Läänemeri elukeskkonnana

## Läänemere elukooslus. Läänemere kaitse
URL: https://www.opiq.ee/kit/98/chapter/4781
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.10
Topics ET: loodusõpetus, läänemere, elukooslus, kaitse, saasteained, meres, mürkide, mõju, elukooslusele, naftareostus
Topics RU: природоведение
Topics EN: science
Headings: Läänemere elukooslus. Läänemere kaitse; Läänemere elukooslus; Saasteained meres; Mürkide mõju elukooslusele; Naftareostus kahjustab mereelustikku; Pean meeles; Küsimusi ja ülesandeid; Läänemere kaitse; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4782
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.11
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Läänemere vesi. Elutingimused Läänemeres
URL: https://www.opiq.ee/kit/98/chapter/4773
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, läänemere, elutingimused, läänemeres, soolsus, proovi, järele, elustik, pean
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Läänemere vesi. Elutingimused Läänemeres; Vee soolsus; Proovi järele; Läänemere elustik; Pean meeles; Küsimusi ja ülesandeid; Läänemere vee soolsus; Edasimõtlemiseks ja uurimiseks

## Läänemere asend ja ümbritsevad riigid
URL: https://www.opiq.ee/kit/98/chapter/4774
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.3
Topics ET: loodusõpetus, läänemere, asend, ümbritsevad, riigid, sisemeri, kaardiga, rannajoon, proovi, järele
Topics RU: природоведение
Topics EN: science
Headings: Läänemere asend ja ümbritsevad riigid; Sisemeri; Töö kaardiga; Rannajoon; Proovi järele; Läänemere saared; Poolsaared ja lahed; Pean meeles; Küsimusi ja ülesandeid; Eesti saared; Edasimõtlemiseks ja uurimiseks

## Läänemere mõju ilmastikule
URL: https://www.opiq.ee/kit/98/chapter/4775
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.4
Topics ET: loodusõpetus, läänemere, mõju, ilmastikule, kliima, õhumassid, briisid, eesti, kliimale, probleem
Topics RU: природоведение
Topics EN: science
Headings: Läänemere mõju ilmastikule; Kliima; Õhumassid; Briisid; Läänemere mõju Eesti kliimale; Probleem; Pean meeles; Küsimusi ja ülesandeid; Kliimadiagramm; Edasimõtlemiseks ja uurimiseks

## Läänemere rannik
URL: https://www.opiq.ee/kit/98/chapter/4776
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.5
Topics ET: loodusõpetus, läänemere, rannik, rand, kaardiga, laiud, rahud, karid, saaremaast, hiiumaast
Topics RU: природоведение
Topics EN: science
Headings: Läänemere rannik; Rand ja rannik; Töö kaardiga; Laiud, rahud ja karid; Saaremaast ja Hiiumaast saab manner; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Vetikad Läänemere elustikus
URL: https://www.opiq.ee/kit/98/chapter/4777
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.6
Topics ET: loodusõpetus, vetikad, läänemere, elustikus, vetikate, roll, elukoosluses, rohevetikad, pruunvetikad, punavetikad
Topics RU: природоведение
Topics EN: science
Headings: Vetikad Läänemere elustikus; Vetikate roll elukoosluses; Rohevetikad; Pruunvetikad; Punavetikad; Pean meeles; Küsimusi ja ülesandeid; Agarik; Edasimõtlemiseks ja uurimiseks

## Läänemere selgrootud loomad ja kalad
URL: https://www.opiq.ee/kit/98/chapter/4778
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, läänemere, selgrootud, kalad, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Läänemere selgrootud loomad ja kalad; Selgrootud; Kalad; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Läänemere linnustik
URL: https://www.opiq.ee/kit/98/chapter/4779
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.8
Topics ET: loodusõpetus, läänemere, linnustik, rändlinnud, jagunevad, kaheks, haudelinnud, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Läänemere linnustik; Rändlinnud jagunevad kaheks; Haudelinnud; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?; Edasimõtlemiseks ja uurimiseks

## Läänemere mõju inimtegevusele ja rannaasustuse kujunemisele
URL: https://www.opiq.ee/kit/98/chapter/4780
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 5.9
Topics ET: loodusõpetus, läänemere, mõju, inimtegevusele, rannaasustuse, kujunemisele, ajalugu, läänemeri, tänapäeval, põhjaranniku
Topics RU: природоведение
Topics EN: science
Headings: Läänemere mõju inimtegevusele ja rannaasustuse kujunemisele; Ajalugu; Läänemeri tänapäeval; Põhjaranniku kuulus kapteniteküla; Pean meeles; Küsimusi ja ülesandeid; Ristsõna; Edasimõtlemiseks ja uurimiseks

## Elukeskkonnad Eestis
URL: https://www.opiq.ee/kit/98/chapter/4783
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 6.1
Topics ET: loodusõpetus, elukeskkonnad, eestis
Topics RU: природоведение
Topics EN: science
Headings: Elukeskkonnad Eestis

## Eesti looduse elurikkus
URL: https://www.opiq.ee/kit/98/chapter/4784
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 6.2
Topics ET: loodusõpetus, loodus, keskkond, eesti, looduse, elurikkus, mitmekesine, metsad, sood, rannikumeri, järved
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Eesti looduse elurikkus; Eesti loodus on mitmekesine; Metsad; Sood; Rannikumeri; Järved; Inimese kujundatud ökosüsteem; Eesti loodus – euroopa viie rikkama seas!; Pean meeles; Küsimusi ja ülesandeid; Ökosüsteemid; Edasimõtlemiseks ja uurimiseks

## Toitumissuhted ja ainete ringkäik ökosüsteemis
URL: https://www.opiq.ee/kit/98/chapter/4785
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 6.3
Topics ET: loodusõpetus, toitumissuhted, ainete, ringkäik, ökosüsteemis, organismid, moodustavad, toiduahelaid, muid, toitumissuhteid
Topics RU: природоведение
Topics EN: science
Headings: Toitumissuhted ja ainete ringkäik ökosüsteemis; Organismid moodustavad toiduahelaid; Muid toitumissuhteid; Pean meeles; Küsimusi ja ülesandeid; Toitumissuhted; Edasimõtlemiseks ja uurimiseks

## Looduslik tasakaal. Inimese mõju loodusele
URL: https://www.opiq.ee/kit/98/chapter/4786
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 6.4
Topics ET: loodusõpetus, looduslik, tasakaal, inimese, mõju, loodusele, inimmõju, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Looduslik tasakaal. Inimese mõju loodusele; Looduslik tasakaal; Inimmõju; Pean meeles; Küsimusi ja ülesandeid; Metskits ja ilves; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4787
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 6.5
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Eesti loodusvarad
URL: https://www.opiq.ee/kit/98/chapter/4788
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 7.1
Topics ET: loodusõpetus, eesti, loodusvarad
Topics RU: природоведение
Topics EN: science
Headings: Eesti loodusvarad

## Eesti loodusvarad, nende kasutamine ja kaitse
URL: https://www.opiq.ee/kit/98/chapter/4789
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 7.2
Topics ET: loodusõpetus, eesti, loodusvarad, nende, kasutamine, kaitse, taastuvad, taastumatud, joogivesi, mets
Topics RU: природоведение
Topics EN: science
Headings: Eesti loodusvarad, nende kasutamine ja kaitse; Taastuvad ja taastumatud loodusvarad; Joogivesi; Mets; Pean meeles; Küsimusi ja ülesandeid; Loodusvarad; Edasimõtlemiseks ja uurimiseks

## Loodusvarad energiaallikatena
URL: https://www.opiq.ee/kit/98/chapter/4790
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 7.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, vesi, veeohutus, veekogu, loodusvarad, energiaallikatena, päike, tuul, põlevkivi, kaardiga, pean
Topics RU: природоведение, растение, растения, дерево, цветок, вода, безопасность на воде, водоём
Topics EN: science, plant, plants, tree, flower, water, water safety, body of water
Headings: Loodusvarad energiaallikatena; Päike; Vesi; Tuul; Taimed; Põlevkivi; Töö kaardiga; Pean meeles; Küsimusi ja ülesandeid; Energiaallikad; Edasimõtlemiseks ja uurimiseks

## Eesti maavarad, nende kaevandamine ja kasutamine
URL: https://www.opiq.ee/kit/98/chapter/4791
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 7.4
Topics ET: loodusõpetus, eesti, maavarad, nende, kaevandamine, kasutamine, kivimid, tardkivimid, settekivimid, moondekivimid
Topics RU: природоведение
Topics EN: science
Headings: Eesti maavarad, nende kaevandamine ja kasutamine; Kivimid; Tardkivimid; Settekivimid; Moondekivimid; Maavarad; Põlevkivi; Töö kaardiga; Lubjakivi; Savi; Liiv; Turvas; Ravimuda; Fosforiit; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kaevanduste ja karjääride kasutamisega seotud keskkonna­probleemid
URL: https://www.opiq.ee/kit/98/chapter/4792
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 7.5
Topics ET: loodusõpetus, kaevanduste, karjääride, kasutamisega, keskkonna, probleemid, kaevandamine, karjäärialade, korrastamine, pean
Topics RU: природоведение
Topics EN: science
Headings: Kaevanduste ja karjääride kasutamisega seotud keskkonna­probleemid; Kaevandamine; Karjäärialade korrastamine; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4793
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 7.6
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Loodus- ja keskkonnakaitse Eestis
URL: https://www.opiq.ee/kit/98/chapter/4794
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.1
Topics ET: loodusõpetus, loodus, keskkond, keskkonnakaitse, eestis
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Loodus- ja keskkonnakaitse Eestis

## Kokkuvõte
URL: https://www.opiq.ee/kit/98/chapter/4803
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.10
Topics ET: loodusõpetus, kokkuvõte, oskad, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Sa oskad; Kordamisküsimused

## Keskkonna saastumine ja keskkonnakaitse
URL: https://www.opiq.ee/kit/98/chapter/4795
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.2
Topics ET: loodusõpetus, keskkonna, saastumine, keskkonnakaitse, saasteallikad, õhuseire, tallinnas, müra, võib, olla
Topics RU: природоведение
Topics EN: science
Headings: Keskkonna saastumine ja keskkonnakaitse; Saasteallikad ja keskkonnakaitse; Õhuseire Tallinnas; Ka müra võib olla saastaja; Pean meeles; Küsimusi ja ülesandeid; Seirejaamad; Edasimõtlemiseks ja uurimiseks

## Looduskaitse Eestis. Kaitsealad
URL: https://www.opiq.ee/kit/98/chapter/4796
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.3
Topics ET: loodusõpetus, looduskaitse, eestis, kaitsealad, millega, tegeleb, rahvuspargid, looduskaitsealad, maastikukaitsealad, kaardiga
Topics RU: природоведение
Topics EN: science
Headings: Looduskaitse Eestis. Kaitsealad; Millega tegeleb looduskaitse?; Rahvuspargid; Looduskaitsealad; Maastikukaitsealad; Töö kaardiga; Pean meeles; Küsimusi ja ülesandeid; Eesti rahvuspargid; Edasimõtlemiseks ja uurimiseks

## Kaitsealused üksikobjektid
URL: https://www.opiq.ee/kit/98/chapter/4797
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.4
Topics ET: loodusõpetus, kaitsealused, üksikobjektid, looduskaitse, alused, pean, meeles, küsimusi, ülesandeid, objektid
Topics RU: природоведение
Topics EN: science
Headings: Kaitsealused üksikobjektid; Looduskaitse­alused üksikobjektid; Pean meeles; Küsimusi ja ülesandeid; Kaitsealused objektid 1; Kaitsealused objektid 2; Kaitsealused objektid 3; Kaitsealused objektid 4; Edasimõtlemiseks ja uurimiseks

## Elurikkuse kaitse
URL: https://www.opiq.ee/kit/98/chapter/4798
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.5
Topics ET: loodusõpetus, elurikkuse, kaitse, kaitsealused, liigid, kuidas, kaitstakse, haruldasi, liike, pean
Topics RU: природоведение
Topics EN: science
Headings: Elurikkuse kaitse; Kaitsealused liigid; Kuidas kaitstakse haruldasi liike; Pean meeles; Küsimusi ja ülesandeid; Hoiualad ja püsielupaigad; Edasimõtlemiseks ja uurimiseks

## Niidud on elurikkad pärand­kooslused
URL: https://www.opiq.ee/kit/98/chapter/4799
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, niidud, elurikkad, pärand, kooslused, eesti, niidul, pean
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Niidud on elurikkad pärand­kooslused; Eesti niidud; Taimed ja loomad niidul; Pean meeles; Küsimusi ja ülesandeid; Tõene või väär?; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Looduskesk­konna muutumine inim­tegevuse tagajärjel
URL: https://www.opiq.ee/kit/98/chapter/4800
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.7
Topics ET: loodusõpetus, looduskesk, konna, muutumine, inim, tegevuse, tagajärjel, keskkonna, probleemid, maakohas
Topics RU: природоведение
Topics EN: science
Headings: Looduskesk­konna muutumine inim­tegevuse tagajärjel; Keskkonna­probleemid maakohas; Linnakeskkond; Pean meeles; Küsimusi ja ülesandeid; Mets; Edasimõtlemiseks ja uurimiseks

## Jäätmekäitlus
URL: https://www.opiq.ee/kit/98/chapter/4801
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.8
Topics ET: loodusõpetus, jäätmekäitlus, prügi, kuidas, sortida, saab, sorteeritud, jäätmetest, edasi, pean
Topics RU: природоведение
Topics EN: science
Headings: Jäätmekäitlus; Prügi ja jäätmekäitlus; Kuidas prügi sortida?; Mis saab sorteeritud jäätmetest edasi?; Pean meeles; Küsimusi ja ülesandeid; Prügi sorteerimine; Edasimõtlemiseks ja uurimiseks

## Säästev tarbimine
URL: https://www.opiq.ee/kit/98/chapter/4802
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 8.9
Topics ET: loodusõpetus, säästev, tarbimine, kuidas, saame, loodust, hoida, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Säästev tarbimine; Kuidas saame loodust hoida; Pean meeles; Küsimusi ja ülesandeid; Ökomärgisega tooted; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Sõnaseletused
URL: https://www.opiq.ee/kit/98/chapter/4804
Book: Muld
Class: 6
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_est
Chapter ID: 9.1
Topics ET: loodusõpetus, sõnaseletused
Topics RU: природоведение
Topics EN: science
Headings: Sõnaseletused

## Природо­ведение 6 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/269
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 374
Topics ET: loodusõpetus, opiq
Topics RU: природоведение, природо, ведение, класс
Topics EN: science

## Почва
URL: https://www.opiq.ee/kit/269/chapter/15294
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.1
Topics ET: loodusõpetus
Topics RU: природоведение, почва
Topics EN: science
Headings: Почва

## Состав почвы
URL: https://www.opiq.ee/kit/269/chapter/15287
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.2
Topics ET: loodusõpetus
Topics RU: природоведение, состав, почвы, чего, состоит, почва, опыт, гумус, практическое
Topics EN: science
Headings: Состав почвы; Из чего состоит почва?; Опыт; Гумус; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Образование и развитие почв
URL: https://www.opiq.ee/kit/269/chapter/15288
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.3
Topics ET: loodusõpetus
Topics RU: природоведение, образование, развитие, почв, образуется, почва, факторы, влияющие, почвообразование, запомни
Topics EN: science
Headings: Образование и развитие почв; Как образуется почва; Факторы, влияющие на почвообразование; ЗАПОМНИ!; Вопросы и задания; Из чего в почве образуется гумус?; Размышляй и исследуй

## Почвенные организмы
URL: https://www.opiq.ee/kit/269/chapter/15289
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.4
Topics ET: loodusõpetus
Topics RU: природоведение, почвенные, организмы, живет, почве, крот, запомни, вопросы, буквенная
Topics EN: science
Headings: Почвенные организмы; Кто живет в почве; Крот; ЗАПОМНИ!; Вопросы и задания; Буквенная путаница; Размышляй и исследуй

## Круговорот веществ
URL: https://www.opiq.ee/kit/269/chapter/15290
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.5
Topics ET: loodusõpetus
Topics RU: природоведение, круговорот, веществ, происходит, умершими, организмами, почве, запомни, вопросы
Topics EN: science
Headings: Круговорот веществ; Что происходит с умершими организмами в почве?; ЗАПОМНИ!; Вопросы и задания; Верно или неверно?; Вычисли; Размышляй и исследуй

## Роль почвы в сообществах
URL: https://www.opiq.ee/kit/269/chapter/15291
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.6
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, роль, почвы, сообществах, растительность, зависит, почва, культурные, запомни
Topics EN: science, plant, plants, tree, flower
Headings: Роль почвы в сообществах; Растительность зависит от почвы; Почва и культурные растения; ЗАПОМНИ!; Вопросы и задания; Температура; Размышляй и исследуй

## Почвенный разрез
URL: https://www.opiq.ee/kit/269/chapter/15292
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.7
Topics ET: loodusõpetus
Topics RU: природоведение, почвенный, разрез, почва, имеет, слоистое, строение, запомни, вопросы
Topics EN: science
Headings: Почвенный разрез; Почва имеет слоистое строение; ЗАПОМНИ!; Вопросы и задания; Почвенные горизонты; Размышляй и исследуй

## Движение воды в почве
URL: https://www.opiq.ee/kit/269/chapter/15293
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.8
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, движение, воды, почве, перемещается, через, поры, различные, виды
Topics EN: science, water, water safety, body of water
Headings: Движение воды в почве; Вода перемещается через поры в почве; Различные виды почвы; Как определить вид почвы?; ЗАПОМНИ!; Вопросы и задания; Верно или неверно?; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15295
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 1.9
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь; Вопросы для повторения

## Сад и поле как среда обитания
URL: https://www.opiq.ee/kit/269/chapter/15306
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.1
Topics ET: loodusõpetus
Topics RU: природоведение, поле, среда, обитания
Topics EN: science
Headings: Сад и поле как среда обитания

## Загрязнение и истощение почвы
URL: https://www.opiq.ee/kit/269/chapter/15304
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.10
Topics ET: loodusõpetus
Topics RU: природоведение, загрязнение, истощение, почвы, люди, могут, нанести, вред, почве, запомни
Topics EN: science
Headings: Загрязнение и истощение почвы; Как люди могут нанести вред почве?; ЗАПОМНИ!; Вопросы и задания; Химикалии в сельском хозяйстве; Буквенная путаница; Размышляй и исследуй

## Защита почвы
URL: https://www.opiq.ee/kit/269/chapter/15305
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.11
Topics ET: loodusõpetus
Topics RU: природоведение, защита, почвы, нужно, учитывать, защите, запомни, вопросы, карьеры
Topics EN: science
Headings: Защита почвы; Что нужно учитывать при защите почвы; ЗАПОМНИ!; Вопросы и задания; Карьеры; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15307
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.12
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь; Вопросы для повторения

## Плодородие почвы
URL: https://www.opiq.ee/kit/269/chapter/15296
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.2
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, плодородие, почвы, почвенные, организмы, мотыльковые, повышают, запомни, вопросы
Topics EN: science, plant, plants, tree, flower
Headings: Плодородие почвы; Плодородие почвы и почвенные организмы; Как мотыльковые растения повышают плодородие почвы?; ЗАПОМНИ!; Вопросы и задания; Почва, подходящая для роста растений; Размышляй и исследуй

## Сад как биотическое сообщество
URL: https://www.opiq.ee/kit/269/chapter/15297
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.3
Topics ET: loodusõpetus, inimene, keha, meeled, tervis
Topics RU: природоведение, человек, тело, чувства, здоровье, биотическое, сообщество, создает, сада, капустницы, большие, синицы, листовые
Topics EN: science, human, body, senses, health
Headings: Сад как биотическое сообщество; Человек создает биотическое сообщество сада; Капустницы и большие синицы; Листовые тли и божьи коровки; Улитки и ежи; Роль человека в формировании биотического сообщества сада; Пищевые цепи в саду; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Виды, обитающие в саду; Буквенная путаница; Размышляй и исследуй

## Фотосинтез
URL: https://www.opiq.ee/kit/269/chapter/15298
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.4
Topics ET: loodusõpetus
Topics RU: природоведение, фотосинтез, такое, запомни, вопросы, размышляй, исследуй
Topics EN: science
Headings: Фотосинтез; Что такое фотосинтез?; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Сады и садовые растения
URL: https://www.opiq.ee/kit/269/chapter/15299
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.5
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, сады, садовые, культурные, огороды, капуста, имеет, множество, разновидностей
Topics EN: science, plant, plants, tree, flower
Headings: Сады и садовые растения; Культурные растения; Огороды; КАПУСТА ИМЕЕТ МНОЖЕСТВО РАЗНОВИДНОСТЕЙ; Фруктовые сады; Декоративные сады; Верно или неверно?; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Ромашка аптечная; Размышляй и исследуй

## Поле как биотическое сообщество
URL: https://www.opiq.ee/kit/269/chapter/15300
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, поле, биотическое, сообщество, полевые, пищевые, цепи, запомни
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Поле как биотическое сообщество; Полевые растения; Полевые животные; Пищевые цепи в поле; ЗАПОМНИ!; Вопросы и задания; Знаешь ли ты злаки?; Размышляй и исследуй

## Биологическая и химическая защита
URL: https://www.opiq.ee/kit/269/chapter/15301
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, биологическая, химическая, защита, борются, вредителями, запомни, вопросы, полезные
Topics EN: science, animal, animals, birds, insects
Headings: Биологическая и химическая защита; Как борются с вредителями; ЗАПОМНИ!; Вопросы и задания; Полезные животные и вредители в саду; Размышляй и исследуй

## Щадящее земледелие
URL: https://www.opiq.ee/kit/269/chapter/15302
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.8
Topics ET: loodusõpetus
Topics RU: природоведение, щадящее, земледелие, такое, удобрение, почвы, защита, растений, значки, продуктах
Topics EN: science
Headings: Щадящее земледелие; Что такое щадящее земледелие?; Удобрение почвы; Защита растений; Значки на продуктах питания; ЗАПОМНИ!; Вопросы и задания; Буквенная путаница; Химическая или биологическая защита?; Размышляй и исследуй

## Воздействие человеческой деятельности на почву
URL: https://www.opiq.ee/kit/269/chapter/15303
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 2.9
Topics ET: loodusõpetus
Topics RU: природоведение, воздействие, человеческой, деятельности, почву, повышают, плодородие, почвы, полевые, работы
Topics EN: science
Headings: Воздействие человеческой деятельности на почву; Как повышают плодородие почвы?; Полевые работы; Удобрения; ЗАПОМНИ!; Вопросы и задания; Компостирование; Размышляй и исследуй

## Лес как среда обитания
URL: https://www.opiq.ee/kit/269/chapter/15317
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.1
Topics ET: loodusõpetus
Topics RU: природоведение, среда, обитания
Topics EN: science
Headings: Лес как среда обитания

## Защита лесов
URL: https://www.opiq.ee/kit/269/chapter/15316
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.10
Topics ET: loodusõpetus
Topics RU: природоведение, защита, лесов, свойства, леса, охраняемые, практическое, запомни, вопросы
Topics EN: science
Headings: Защита лесов; Свойства леса; Охраняемые леса; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Возможности использования лесов; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15318
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.11
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь; Вопросы для повторения

## Лес как биотическое сообщество
URL: https://www.opiq.ee/kit/269/chapter/15308
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.2
Topics ET: loodusõpetus
Topics RU: природоведение, биотическое, сообщество, такое, экосистема, условия, жизни, лесу, ярусы, леса
Topics EN: science
Headings: Лес как биотическое сообщество; Что такое экосистема?; Условия жизни в лесу; Ярусы леса; Типы леса; Работа с картой; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Растения cоснового и cосново-елового леса
URL: https://www.opiq.ee/kit/269/chapter/15309
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.3
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, елового, леса, условия, произрастания, сосновом, лесу
Topics EN: science, plant, plants, tree, flower
Headings: Растения cоснового и cосново-елового леса; Условия произрастания в сосновом лесу; Сосна; Растения нижних ярусов соснового леса; Сосново-еловый лес; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Определи растения; Буквенная путаница; Размышляй и исследуй

## Животные – обитатели cоснового и сосново-елового леса
URL: https://www.opiq.ee/kit/269/chapter/15310
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, обитатели, сосново, елового, леса, сосновый, пилильщик
Topics EN: science, animal, animals, birds, insects
Headings: Животные – обитатели cоснового и сосново-елового леса; Насекомые; Сосновый пилильщик может съесть большую часть хвоинок на сосне; Сосновый долгоносик может погубить молодые деревья; Птицы; Желна – самый крупный дятел; Млекопитающие; ЗАПОМНИ!; Вопросы и задания; Буквенная путаница; Барсук; Размышляй и исследуй

## Растения темнохвойного леса
URL: https://www.opiq.ee/kit/269/chapter/15311
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.5
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, темнохвойного, леса, условия, произрастания, темнохвойном, лесу, древесный, ярус
Topics EN: science, plant, plants, tree, flower
Headings: Растения темнохвойного леса; Условия произрастания в темнохвойном лесу; Древесный ярус; Растения живого покрова темнохвойного леса; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Буквенная путаница; Размышляй и исследуй

## Животные – обитатели темнохвойного леса
URL: https://www.opiq.ee/kit/269/chapter/15312
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, обитатели, темнохвойного, леса, млекопитающие, практическое
Topics EN: science, animal, animals, birds, insects
Headings: Животные – обитатели темнохвойного леса; Насекомые; Птицы; Млекопитающие; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Буквенная путаница; Заяц-беляк; Размышляй и исследуй

## Растения смешанно-лиственного леса
URL: https://www.opiq.ee/kit/269/chapter/15313
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.7
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, смешанно, лиственного, леса, условия, произрастания, лиственном, лесу, древесный
Topics EN: science, plant, plants, tree, flower
Headings: Растения смешанно-лиственного леса; Условия произрастания в смешанно-лиственном лесу; Древесный ярус; Видов ольхи два – ольха серая и ольха черная; Кустарниковый ярус; Травяной ярус; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Буквенная путаница; Листья деревьев; Размышляй и исследуй

## Животные – обитатели смешанно-лиственного леса
URL: https://www.opiq.ee/kit/269/chapter/15314
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.8
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, обитатели, смешанно, лиственного, леса, почвенные, млекопитающие
Topics EN: science, animal, animals, birds, insects
Headings: Животные – обитатели смешанно-лиственного леса; Почвенные животные и насекомые; Птицы; Млекопитающие; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Зяблик и пеночка; Буквенная путаница; Размышляй и исследуй

## Значение и использование леса
URL: https://www.opiq.ee/kit/269/chapter/15315
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 3.9
Topics ET: loodusõpetus
Topics RU: природоведение, значение, использование, леса, лесное, хозяйство, хозяйственный, естественный, природное, богатство
Topics EN: science
Headings: Значение и использование леса; Лесное хозяйство; Хозяйственный и естественный лес; Лес как природное богатство; Практическое задание; ЗАПОМНИ!; Вопросы и задания; Хозяйственный лес и девственный лес; Размышляй и исследуй

## Воздух
URL: https://www.opiq.ee/kit/269/chapter/15335
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение, воздух
Topics EN: science
Headings: Воздух

## Движение воздуха при нагревании
URL: https://www.opiq.ee/kit/269/chapter/15327
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.10
Topics ET: loodusõpetus
Topics RU: природоведение, движение, воздуха, нагревании, воздух, расширяется, охлаждении, сжимается, опыт, первый
Topics EN: science
Headings: Движение воздуха при нагревании; При нагревании воздух расширяется, при охлаждении сжимается; Опыт; Первый полет на воздушном шаре; ЗАПОМНИ!; Вопросы и задания; Температура воздуха на разной высоте; Размышляй и исследуй

## Движение воздуха и ветер
URL: https://www.opiq.ee/kit/269/chapter/15328
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.11
Topics ET: loodusõpetus
Topics RU: природоведение, движение, воздуха, ветер, влияет, нашу, жизнь, направление, ветра, практическое
Topics EN: science
Headings: Движение воздуха и ветер; Ветер влияет на нашу жизнь; Направление ветра; Практическое задание; Скорость ветра; Ветер и разница атмосферного давления; Роза ветров; Работа с картой; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Сухой и влажный воздух
URL: https://www.opiq.ee/kit/269/chapter/15329
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.12
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem
Topics RU: природоведение, сравнение, сравни, больше, меньше, сухой, влажный, воздух, влажность, воздуха, погода, запомни, вопросы
Topics EN: science, comparison, compare, greater, less
Headings: Сухой и влажный воздух; Влажность воздуха и погода; ЗАПОМНИ!; Вопросы и задания; Сравнение сухого и влажного воздуха; Буквенная путаница; Размышляй и исследуй

## Облака и осадки
URL: https://www.opiq.ee/kit/269/chapter/15330
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.13
Topics ET: loodusõpetus
Topics RU: природоведение, облака, осадки, виды, облаков, образование, осадков, запомни, вопросы
Topics EN: science
Headings: Облака и осадки; Облака; Виды облаков; Образование осадков; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Круговорот воды в природе
URL: https://www.opiq.ee/kit/269/chapter/15331
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.14
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, круговорот, воды, природе, земле, движется, источник, энергии, циркуляции
Topics EN: science, water, water safety, body of water
Headings: Круговорот воды в природе; Вода на Земле движется; Источник энергии для циркуляции воды; Большой круговорот воды; ЗАПОМНИ!; Вопросы и задания; Круговорот воды; Размышляй и исследуй

## Погода
URL: https://www.opiq.ee/kit/269/chapter/15332
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.15
Topics ET: loodusõpetus
Topics RU: природоведение, погода, практическое, метеорологи, буррометр, запомни, вопросы, эстонии
Topics EN: science
Headings: Погода; Практическое задание; Метеорологи; Буррометр; ЗАПОМНИ!; Вопросы и задания; Погода в Эстонии; Размышляй и исследуй

## Измерение количества осадков
URL: https://www.opiq.ee/kit/269/chapter/15333
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.16
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, количества, осадков, измеряется, количество, работа, картой, осадки, эстонии
Topics EN: science, measurement, unit, length, mass, volume
Headings: Измерение количества осадков; Как измеряется количество осадков?; Работа с картой; Осадки в Эстонии; ЗАПОМНИ!; Вопросы и задания; Суточное количество осадков; Годовое количество осадков; Размышляй и исследуй

## Прогноз погоды
URL: https://www.opiq.ee/kit/269/chapter/15334
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.17
Topics ET: loodusõpetus
Topics RU: природоведение, прогноз, погоды, атмосферное, давление, карта, такое, миллибар, высокое, низкое
Topics EN: science
Headings: Прогноз погоды; Атмосферное давление; Карта погоды; Что такое миллибар?; Высокое атмосферное давление и низкое атмосферное давление; ЗАПОМНИ!; Вопросы и задания; Погода в области высокого давления и в области низкого давления; Размышляй и исследуй

## Предотвращение загрязнения воздуха
URL: https://www.opiq.ee/kit/269/chapter/15336
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.18
Topics ET: loodusõpetus
Topics RU: природоведение, предотвращение, загрязнения, воздуха, чистый, воздух, нужен, всем, организмам, транспорт
Topics EN: science
Headings: Предотвращение загрязнения воздуха; Чистый воздух нужен всем организмам; Транспорт; Сельское хозяйство; Отходы; ЗАПОМНИ!; Вопросы и задания; Загрязнение воздуха в месте, где ты живешь; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15337
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.19
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь:; Вопросы для повторения

## Воздух. Значение воздуха
URL: https://www.opiq.ee/kit/269/chapter/15319
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.2
Topics ET: loodusõpetus
Topics RU: природоведение, воздух, значение, воздуха, такое, влияет, организмы, запомни, вопросы
Topics EN: science
Headings: Воздух. Значение воздуха; Что такое воздух?; Как воздух влияет на организмы?; ЗАПОМНИ!; Вопросы и задания; Содержащиеся в воздухе газы; Размышляй и исследуй

## Погода как объект исследования
URL: https://www.opiq.ee/kit/269/chapter/15338
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.20
Topics ET: loodusõpetus
Topics RU: природоведение, погода, объект, исследования, сбор, данных, наблюдения
Topics EN: science
Headings: Погода как объект исследования; Сбор данных наблюдения

## Воздушная оболочка
URL: https://www.opiq.ee/kit/269/chapter/15320
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.3
Topics ET: loodusõpetus
Topics RU: природоведение, воздушная, оболочка, атмосфера, значение, атмосферы, организмов, запомни, вопросы
Topics EN: science
Headings: Воздушная оболочка; Атмосфера; Значение атмосферы для организмов; ЗАПОМНИ!; Вопросы и задания; Буквенная путаница; Размышляй и исследуй

## Приспособление организмов к воздушной среде
URL: https://www.opiq.ee/kit/269/chapter/15321
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, приспособление, организмов, воздушной, среде, запомни, вопросы
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Приспособление организмов к воздушной среде; Растения; Животные; ЗАПОМНИ!; Вопросы и задания; Верно или неверно?; Размышляй и исследуй

## Состав воздуха
URL: https://www.opiq.ee/kit/269/chapter/15322
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.5
Topics ET: loodusõpetus
Topics RU: природоведение, состав, воздуха, опыт, свечой, содержится, воздухе, запомни, вопросы
Topics EN: science
Headings: Состав воздуха; Опыт со свечой; Что содержится в воздухе?; ЗАПОМНИ!; Вопросы и задания; Рассчитай; Размышляй и исследуй

## Важность кислорода: дыхание, горение и гниение
URL: https://www.opiq.ee/kit/269/chapter/15323
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.6
Topics ET: loodusõpetus
Topics RU: природоведение, важность, кислорода, дыхание, горение, гниение, запомни, вопросы, изменяется
Topics EN: science
Headings: Важность кислорода: дыхание, горение и гниение; Дыхание; Горение и гниение; ЗАПОМНИ!; Вопросы и задания; Как изменяется состав воздуха?; Размышляй и исследуй

## Свойства воздуха
URL: https://www.opiq.ee/kit/269/chapter/15324
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.7
Topics ET: loodusõpetus
Topics RU: природоведение, свойства, воздуха, какие, есть, атмосферное, давление, теплопроводность, запомни, вопросы
Topics EN: science
Headings: Свойства воздуха; Какие свойства есть у воздуха?; Атмосферное давление; Теплопроводность; ЗАПОМНИ!; Вопросы и задания

## Температура воздуха и ее измерение
URL: https://www.opiq.ee/kit/269/chapter/15325
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.8
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём, температура, воздуха, температуры, практическое, солнце, влияет, температуру
Topics EN: science, measurement, unit, length, mass, volume
Headings: Температура воздуха и ее измерение; Измерение температуры; Практическое задание; Как Солнце влияет на температуру воздуха?; Опыт; Что еще влияет на температуру воздуха?; ЗАПОМНИ!; Вопросы и задания; Смена дня и ночи; Размышляй и исследуй

## Суточное изменение температуры воздуха
URL: https://www.opiq.ee/kit/269/chapter/15326
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 4.9
Topics ET: loodusõpetus
Topics RU: природоведение, суточное, изменение, температуры, воздуха, суточный, годовой, температура, эстонии, работа
Topics EN: science
Headings: Суточное изменение температуры воздуха; Суточный ход температуры воздуха; Годовой ход температуры воздуха; Температура воздуха в Эстонии; Работа с картой; ЗАПОМНИ!; Вопросы и задания; График температуры; Размышляй и исследуй

## Балтийское море как среда обитания
URL: https://www.opiq.ee/kit/269/chapter/15348
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.1
Topics ET: loodusõpetus
Topics RU: природоведение, балтийское, море, среда, обитания
Topics EN: science
Headings: Балтийское море как среда обитания

## Биотическое сообщество Балтийского моря. Защита моря
URL: https://www.opiq.ee/kit/269/chapter/15347
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.10
Topics ET: loodusõpetus
Topics RU: природоведение, биотическое, сообщество, балтийского, моря, защита, загрязнение, влияние, ядовитых, веществ
Topics EN: science
Headings: Биотическое сообщество Балтийского моря. Защита моря; Биотическое сообщество Балтийского моря; Загрязнение моря; Влияние ядовитых веществ на биотическое сообщество; Нефтяное загрязнение наносит вред морской флоре и фауне; Запомни!; Вопросы и задания; Защита Балтийского моря; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15349
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.11
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь; Вопросы для повторения

## Вода Балтийского моря. Условия жизни в Балтийском море
URL: https://www.opiq.ee/kit/269/chapter/15339
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, балтийского, моря, условия, жизни, балтийском, море, соленость, воды
Topics EN: science, water, water safety, body of water
Headings: Вода Балтийского моря. Условия жизни в Балтийском море; Соленость воды; Опыт; Флора и фауна Балтийского моря; Запомни!; Вопросы и задания; Соленость воды в Балтийском море; Размышляй и исследуй

## Расположение Балтийского моря и окружающие его страны
URL: https://www.opiq.ee/kit/269/chapter/15340
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.3
Topics ET: loodusõpetus
Topics RU: природоведение, расположение, балтийского, моря, окружающие, страны, внутреннее, море, работа, картой
Topics EN: science
Headings: Расположение Балтийского моря и окружающие его страны; Внутреннее море; Работа с картой; Береговая линия; Острова Балтийского моря; Полуострова и заливы; Запомни!; Вопросы и задания; Острова Эстонии; Размышляй и исследуй

## Влияние Балтийского моря на климат
URL: https://www.opiq.ee/kit/269/chapter/15341
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.4
Topics ET: loodusõpetus
Topics RU: природоведение, влияние, балтийского, моря, климат, воздушные, массы, бризы, эстонии, проблема
Topics EN: science
Headings: Влияние Балтийского моря на климат; Климат; Воздушные массы; Бризы; Влияние Балтийского моря на климат Эстонии; Проблема; Запомни!; Вопросы и задания; Климатическая диаграмма; Размышляй и исследуй

## Побережье Балтийского моря
URL: https://www.opiq.ee/kit/269/chapter/15342
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.5
Topics ET: loodusõpetus
Topics RU: природоведение, побережье, балтийского, моря, берег, работа, картой, островки, рифы, мели
Topics EN: science
Headings: Побережье Балтийского моря; Побережье и берег; Работа с картой; Островки, рифы и мели; Сааремаа и Хийумаа станут частью материка; Запомни!; Вопросы и задания; Буквенная путаница; Размышляй и исследуй

## Водоросли Балтийского моря
URL: https://www.opiq.ee/kit/269/chapter/15343
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.6
Topics ET: loodusõpetus
Topics RU: природоведение, водоросли, балтийского, моря, роль, водорослей, биотическом, сообществе, зеленые, бурые
Topics EN: science
Headings: Водоросли Балтийского моря; Роль водорослей в биотическом сообществе моря; Зеленые водоросли; Бурые водоросли; Красные водоросли; Запомни!; Вопросы и задания; Фурцеллярия; Размышляй и исследуй

## Беспозвоночные и рыбы Балтийского моря
URL: https://www.opiq.ee/kit/269/chapter/15344
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.7
Topics ET: loodusõpetus
Topics RU: природоведение, беспозвоночные, рыбы, балтийского, моря, запомни, вопросы, размышляй, исследуй
Topics EN: science
Headings: Беспозвоночные и рыбы Балтийского моря; Беспозвоночные; Рыбы; Запомни!; Вопросы и задания; Размышляй и исследуй

## Птицы Балтийского моря
URL: https://www.opiq.ee/kit/269/chapter/15345
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.8
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, балтийского, моря, пролетные, гнездящиеся, запомни, вопросы, верно
Topics EN: science, animal, animals, birds, insects
Headings: Птицы Балтийского моря; Пролетные и гнездящиеся птицы; Гнездящиеся птицы; Запомни!; Вопросы и задания; Верно или неверно?; Размышляй и исследуй

## Влияние Балтийского моря на человеческую деятельность и заселение побережья
URL: https://www.opiq.ee/kit/269/chapter/15346
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 5.9
Topics ET: loodusõpetus
Topics RU: природоведение, влияние, балтийского, моря, человеческую, деятельность, заселение, побережья, история, балтийское
Topics EN: science
Headings: Влияние Балтийского моря на человеческую деятельность и заселение побережья; История; Балтийское море в наши дни; Знаменитая Капитанская деревня на северном побережье; Запомни!; Вопросы и задания; Кроссворд; Размышляй и исследуй

## Разные среды обитания в Эстонии
URL: https://www.opiq.ee/kit/269/chapter/15353
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 6.1
Topics ET: loodusõpetus
Topics RU: природоведение, разные, среды, обитания, эстонии
Topics EN: science
Headings: Разные среды обитания в Эстонии

## Многообразие эстонской природы
URL: https://www.opiq.ee/kit/269/chapter/15350
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 6.2
Topics ET: loodusõpetus, loodus, keskkond
Topics RU: природоведение, природа, окружающая среда, многообразие, эстонской, природы, наша, многообразна, леса, болота, прибрежная
Topics EN: science, nature, environment
Headings: Многообразие эстонской природы; Наша природа многообразна; Леса; Болота; Прибрежная часть моря; Озера; Созданная человеком экосистема; Эстонская природа – в числе пяти богатейших в Европе!; Запомни!; Вопросы и задания; Экосистемы; Размышляй и исследуй

## Пищевые отношения в экосистеме
URL: https://www.opiq.ee/kit/269/chapter/15351
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 6.3
Topics ET: loodusõpetus
Topics RU: природоведение, пищевые, отношения, экосистеме, организмы, образуют, цепи, другие, запомни, вопросы
Topics EN: science
Headings: Пищевые отношения в экосистеме; Организмы образуют пищевые цепи; Другие пищевые отношения; Запомни!; Вопросы и задания; Пищевые отношения; Размышляй и исследуй

## Природное равновесие. Влияние человека на природу
URL: https://www.opiq.ee/kit/269/chapter/15352
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 6.4
Topics ET: loodusõpetus
Topics RU: природоведение, природное, равновесие, влияние, человека, природу, воздействие, запомни, вопросы
Topics EN: science
Headings: Природное равновесие. Влияние человека на природу; Природное равновесие; Воздействие человека; Запомни!; Вопросы и задания; Косуля и рысь; Буквенная путаница; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15354
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 6.5
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь; Вопросы для повторения

## Природные ресурсы Эстонии
URL: https://www.opiq.ee/kit/269/chapter/15358
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 7.1
Topics ET: loodusõpetus
Topics RU: природоведение, природные, ресурсы, эстонии
Topics EN: science
Headings: Природные ресурсы Эстонии

## Природные ресурсы Эстонии, их использование и защита
URL: https://www.opiq.ee/kit/269/chapter/15355
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 7.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu
Topics RU: природоведение, вода, безопасность на воде, водоём, природные, ресурсы, эстонии, использование, защита, возобновляемые, невозобновляемые, чистая, питьевая
Topics EN: science, water, water safety, body of water
Headings: Природные ресурсы Эстонии, их использование и защита; Возобновляемые и невозобновляемые природные ресурсы; Чистая питьевая вода; Лес; Запомни!; Вопросы и задания; Природные ресурсы; Размышляй и исследуй

## Природные ресурсы как источники энергии
URL: https://www.opiq.ee/kit/269/chapter/15356
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 7.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, vesi, veeohutus, veekogu
Topics RU: природоведение, растение, растения, дерево, цветок, вода, безопасность на воде, водоём, природные, ресурсы, источники, энергии, солнце, ветер, сланец
Topics EN: science, plant, plants, tree, flower, water, water safety, body of water
Headings: Природные ресурсы как источники энергии; Солнце; Вода; Ветер; Растения; Сланец; Работа с картой; Запомни!; Вопросы и задания; Источники энергии; Размышляй и исследуй

## Полезные ископаемые Эстонии, их добыча и использование
URL: https://www.opiq.ee/kit/269/chapter/15357
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 7.4
Topics ET: loodusõpetus
Topics RU: природоведение, полезные, ископаемые, эстонии, добыча, использование, горные, породы, магматические, осадочные
Topics EN: science
Headings: Полезные ископаемые Эстонии, их добыча и использование; Горные породы; Магматические горные породы; Осадочные горные породы; Метаморфические горные породы; Полезные ископаемые; Сланец; Работа с картой; Известняк; Глина; Песок; Торф; Лечебная грязь; Фосфорит; Запомни!; Вопросы и задания; Размышляй и исследуй

## Проблемы окружающей среды, связанные с использованием шахт и карьеров
URL: https://www.opiq.ee/kit/269/chapter/15359
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 7.5
Topics ET: loodusõpetus
Topics RU: природоведение, проблемы, окружающей, среды, связанные, использованием, шахт, карьеров, добыча, полезных
Topics EN: science
Headings: Проблемы окружающей среды, связанные с использованием шахт и карьеров; Добыча полезных ископаемых; Приведение карьеров в порядок; Запомни!; Вопросы и задания; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15360
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 7.6
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь; Вопросы для повторения

## Охрана природы и окружающей среды в Эстонии
URL: https://www.opiq.ee/kit/269/chapter/15368
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.1
Topics ET: loodusõpetus
Topics RU: природоведение, охрана, природы, окружающей, среды, эстонии
Topics EN: science
Headings: Охрана природы и окружающей среды в Эстонии

## В заключение
URL: https://www.opiq.ee/kit/269/chapter/15370
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.10
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, знаешь, умеешь, вопросы, повторения
Topics EN: science
Headings: В заключение; Ты знаешь; Ты умеешь; Вопросы для повторения

## Загрязнение и охрана окружающей среды
URL: https://www.opiq.ee/kit/269/chapter/15361
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.2
Topics ET: loodusõpetus
Topics RU: природоведение, загрязнение, охрана, окружающей, среды, источники, загрязнения, таллинне, воздуха, постоянно
Topics EN: science
Headings: Загрязнение и охрана окружающей среды; Источники загрязнения и охрана окружающей среды; В Таллинне загрязнение воздуха постоянно измеряется в трех пунктах; Шум тоже может быть загрязнителем; Запомни!; Вопросы и задания; Мониторинговые станции; Размышляй и исследуй

## Охрана природы в Эстонии. Охраняемые территории
URL: https://www.opiq.ee/kit/269/chapter/15362
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.3
Topics ET: loodusõpetus, loodus, keskkond
Topics RU: природоведение, природа, окружающая среда, охрана, природы, эстонии, охраняемые, территории, охраняется, национальные, парки
Topics EN: science, nature, environment
Headings: Охрана природы в Эстонии. Охраняемые территории; Как охраняется природа?; Национальные парки; Заповедники; Ландшафтные заповедники; Работа с картой; Запомни!; Вопросы и задания; Национальные парки Эстонии; Размышляй и исследуй

## Отдельные охраняемые природные объекты
URL: https://www.opiq.ee/kit/269/chapter/15363
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.4
Topics ET: loodusõpetus
Topics RU: природоведение, отдельные, охраняемые, природные, объекты, находящиеся, охраной, запомни, вопросы
Topics EN: science
Headings: Отдельные охраняемые природные объекты; Находящиеся под охраной отдельные природные объекты; Запомни!; Вопросы и задания; Охраняемые объекты 4; Охраняемые объекты 1; Охраняемые объекты 2; Охраняемые объекты 3; Размышляй и исследуй

## Защита природного многообразия
URL: https://www.opiq.ee/kit/269/chapter/15364
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.5
Topics ET: loodusõpetus
Topics RU: природоведение, защита, природного, многообразия, охраняемые, виды, защищают, редкие, запомни, вопросы
Topics EN: science
Headings: Защита природного многообразия; Охраняемые виды; Как защищают редкие виды; Запомни!; Вопросы и задания; Природоохранные зоны и места постоянного обитания; Размышляй и исследуй

## Луга как богатые видами полуестественные сообщества
URL: https://www.opiq.ee/kit/269/chapter/15365
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, луга, богатые, видами, полуестественные, сообщества, эстонии, запомни
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Луга как богатые видами полуестественные сообщества; Луга в Эстонии; Растения и животные луга; Запомни!; Вопросы и задания; Верно или неверно?; Размышляй и исследуй

## Изменение природной среды в результате человеческой деятельности
URL: https://www.opiq.ee/kit/269/chapter/15366
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.7
Topics ET: loodusõpetus
Topics RU: природоведение, изменение, природной, среды, результате, человеческой, деятельности, проблемы, окружающей, сельской
Topics EN: science
Headings: Изменение природной среды в результате человеческой деятельности; Проблемы окружающей среды в сельской местности; Городская среда; Запомни!; Вопросы и задания; Лес; Размышляй и исследуй

## Обращение с отходами
URL: https://www.opiq.ee/kit/269/chapter/15367
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.8
Topics ET: loodusõpetus
Topics RU: природоведение, обращение, отходами, сортировать, мусор, происходит, рассортированными, потом, запомни, вопросы
Topics EN: science
Headings: Обращение с отходами; Как сортировать мусор?; Что происходит с рассортированными отходами потом?; Запомни!; Вопросы и задания; Сортировка мусора; Размышляй и исследуй

## Экономное потребление
URL: https://www.opiq.ee/kit/269/chapter/15369
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 8.9
Topics ET: loodusõpetus
Topics RU: природоведение, экономное, потребление, можем, беречь, природу, запомни, вопросы, товары
Topics EN: science
Headings: Экономное потребление; Как мы можем беречь природу; Запомни!; Вопросы и задания; Товары с экомаркировкой; Размышляй и исследуй

## Mõisted
URL: https://www.opiq.ee/kit/269/chapter/19288
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 9.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Понятия и термины
URL: https://www.opiq.ee/kit/269/chapter/15371
Book: Почва
Class: 5
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 5k_loodusõpetus_koolibri_rus
Chapter ID: 9.2
Topics ET: loodusõpetus
Topics RU: природоведение, понятия, термины
Topics EN: science
Headings: Понятия и термины
