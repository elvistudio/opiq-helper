## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/195
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 1
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/195
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 123
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Tere hommikust!
URL: https://www.opiq.ee/kit/195/chapter/11090
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 1.1
Topics ET: matemaatika, tere, hommikust
Topics RU: математика
Topics EN: mathematics
Headings: Tere hommikust!; TERE
Task examples: Kirjuta võõrkeelsete tervituste rütm ja vastava riigi nimi töövihikus. Värvi pilt. Tervita pinginaabrit võõrkeeltes lauldes.; Vali Hando Runneli luuletusest „Tere” olulisemad mõtted teretamise kohta ja pane need kirja.

## Koeruselaul
URL: https://www.opiq.ee/kit/195/chapter/11147
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 10.1
Topics ET: matemaatika, koeruselaul, laulutunnis
Topics RU: математика
Topics EN: mathematics
Headings: Koeruselaul; Laulutunnis
Task examples: Joonista töövihikusse pilt laulust „Koeruselaul” KOERUSELAUL; Tee viis luuletusele „Laulutunnis” (õpikus lk 81). Kõigepealt mõtle ja kirjuta rütmi alla astmenimed töövihikus. Seejärel kirjuta viis noodijoonestikule.

## Hüppa kaasa
URL: https://www.opiq.ee/kit/195/chapter/11148
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 10.2
Topics ET: matemaatika, hüppa, kaasa
Topics RU: математика
Topics EN: mathematics
Headings: Hüppa kaasa
Task examples: Kirjuta laul „Hüppa kaasa” (õpikus lk 82) noodijoonestikule töövihikus. Esita laul koos saatega.

## Lumemees
URL: https://www.opiq.ee/kit/195/chapter/11149
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 10.3
Topics ET: matemaatika, lumemees
Topics RU: математика
Topics EN: mathematics
Headings: Lumemees
Task examples: Kirjuta nootide alla astmenimed töövihikus. Esita laulude katkendid. Kirjuta igale laulule pealkiri (vt õpikust lk 45–72). Leia laulu päritolumaa ja märgi selle number õigesse kastikesse.

## Tulge meie tantsuringi
URL: https://www.opiq.ee/kit/195/chapter/11150
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.1
Topics ET: matemaatika, tulge, meie, tantsuringi
Topics RU: математика
Topics EN: mathematics
Headings: Tulge meie tantsuringi
Task examples: Kirjuta laul „Tulge meie tantsuringi” töövihikus noodijoonestikule. Esitage laul kaanonina koos omatehtud ostinato’ga.

## Lapse palve päikesele
URL: https://www.opiq.ee/kit/195/chapter/11159
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.10
Topics ET: matemaatika, lapse, palve, päikesele
Topics RU: математика
Topics EN: mathematics
Headings: Lapse palve päikesele

## Laulvad aasad
URL: https://www.opiq.ee/kit/195/chapter/11160
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.11
Topics ET: matemaatika, laulvad, aasad
Topics RU: математика
Topics EN: mathematics
Headings: Laulvad aasad

## Kaks sammu sissepoole
URL: https://www.opiq.ee/kit/195/chapter/11161
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.12
Topics ET: matemaatika, kaks, sammu, sissepoole, duur
Topics RU: математика
Topics EN: mathematics
Headings: Kaks sammu sissepoole; Duur
Task examples: Märgi taktimõõt töövihikus. Kirjuta viis noodijoonestikule. Laula käemärkidega.; Kirjuta peast astmetrepile töövihikus astmenimed (J–JI). Laula astmerida J–JI käemärkidega.

## Labajalavalss
URL: https://www.opiq.ee/kit/195/chapter/11162
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.13
Topics ET: matemaatika, labajalavalss
Topics RU: математика
Topics EN: mathematics
Headings: Labajalavalss

## Hüppemäng
URL: https://www.opiq.ee/kit/195/chapter/11163
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.14
Topics ET: matemaatika, hüppemäng
Topics RU: математика
Topics EN: mathematics
Headings: Hüppemäng
Task examples: Täida tühjad taktid ja kirjuta astmenimed töövihikus. Esita viis jaurami saatel, rõhutades iga takti algust.

## Sambalele
URL: https://www.opiq.ee/kit/195/chapter/11164
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.15
Topics ET: matemaatika, sambalele
Topics RU: математика
Topics EN: mathematics
Headings: Sambalele

## Politsei rock
URL: https://www.opiq.ee/kit/195/chapter/11165
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.16
Topics ET: matemaatika, politsei, rock, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Politsei rock; Tähesegadik
Task examples: Kirjuta viis noodijoonestikule töövihikus. Laula viisi astmenimedega. Esita harjutus mõnel silbil (du, pa, rai jne) ja tantsi kaasa rokki.

## Virulaste tants
URL: https://www.opiq.ee/kit/195/chapter/11151
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.2
Topics ET: matemaatika, virulaste, tants
Topics RU: математика
Topics EN: mathematics
Headings: Virulaste tants

## Menuett
URL: https://www.opiq.ee/kit/195/chapter/11152
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.3
Topics ET: matemaatika, menuett
Topics RU: математика
Topics EN: mathematics
Headings: Menuett
Task examples: Arvuta ja kirjuta puuduv + või – märk töövihikusse.

## Timmu-tammu teile
URL: https://www.opiq.ee/kit/195/chapter/11153
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.4
Topics ET: matemaatika, timmu, tammu, teile
Topics RU: математика
Topics EN: mathematics
Headings: Timmu-tammu teile
Task examples: Märgi taktimõõt ja lõpeta rütmiharjutus töövihikus. Esitage see koos sõbraga kaanonina kas keha- või rütmipillidel.

## Rits-rats-rundibumm
URL: https://www.opiq.ee/kit/195/chapter/11154
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.5
Topics ET: matemaatika, rits, rats, rundibumm
Topics RU: математика
Topics EN: mathematics
Headings: Rits-rats-rundibumm; RITS-RATS, RUNDIBUMM

## Tantsi polkat
URL: https://www.opiq.ee/kit/195/chapter/11155
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.6
Topics ET: matemaatika, tantsi, polkat
Topics RU: математика
Topics EN: mathematics
Headings: Tantsi polkat

## Marupolka
URL: https://www.opiq.ee/kit/195/chapter/11156
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.7
Topics ET: matemaatika, marupolka
Topics RU: математика
Topics EN: mathematics
Headings: Marupolka
Task examples: Kirjuta, mis tantse piltidel tantsitakse. Värvi pildid töövihikus.

## Kolm kihulast
URL: https://www.opiq.ee/kit/195/chapter/11157
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.8
Topics ET: matemaatika, kolm, kihulast
Topics RU: математика
Topics EN: mathematics
Headings: Kolm kihulast

## Hei, vallerii
URL: https://www.opiq.ee/kit/195/chapter/11158
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 11.9
Topics ET: matemaatika, vallerii
Topics RU: математика
Topics EN: mathematics
Headings: Hei, vallerii
Task examples: Tõmba töövihikus maha sõnad, mis ei sobi tulpa. Leia igale tulbale ühisnimetus.; Jaga töövihikus viis taktidesse. Kirjuta astmenimed nootide alla. Laula mõlemat häält. Esitage harjutus kahehäälselt. Millist tantsu võiks selle muusika järgi tantsida? Põhjenda.

## Üksinda kõnnin ma
URL: https://www.opiq.ee/kit/195/chapter/11166
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 12.1
Topics ET: matemaatika, üksinda, kõnnin
Topics RU: математика
Topics EN: mathematics
Headings: Üksinda kõnnin ma
Task examples: Kuula muusikat ja joonista pilt oma sõbrast töövihikusse (inimene, loom, väljamõeldud sõber).Kirjuta, millised iseloomuomadused peaksid tal olema.

## Laulgem, sõbrad
URL: https://www.opiq.ee/kit/195/chapter/11167
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 12.2
Topics ET: matemaatika, laulgem, sõbrad
Topics RU: математика
Topics EN: mathematics
Headings: Laulgem, sõbrad

## Šooder
URL: https://www.opiq.ee/kit/195/chapter/11168
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 12.3
Topics ET: matemaatika, šooder
Topics RU: математика
Topics EN: mathematics
Headings: Šooder
Task examples: Loe luuletust „Musitavad loomad”. Kirjutage sõbraga rütmi-ostinato töövihikus ja esitage luuletus koos saatega.

## Mu sõbrake
URL: https://www.opiq.ee/kit/195/chapter/11169
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 12.4
Topics ET: matemaatika, sõbrake
Topics RU: математика
Topics EN: mathematics
Headings: Mu sõbrake
Task examples: Leia iga vanasõna algus ja lõpp.

## Emakeel
URL: https://www.opiq.ee/kit/195/chapter/11170
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 13.1
Topics ET: matemaatika, emakeel
Topics RU: математика
Topics EN: mathematics
Headings: Emakeel

## Vaikne kena kohakene
URL: https://www.opiq.ee/kit/195/chapter/11171
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 13.2
Topics ET: matemaatika, vaikne, kena, kohakene
Topics RU: математика
Topics EN: mathematics
Headings: Vaikne kena kohakene
Task examples: Joonista laulust „Vaikne kena kohakene” pilt töövihikusse. Pane pildile pealkiri. Vaikne kena kohakene; Tõmba taktijooned ja kirjuta astmenimed töövihikus. Laula käemärkidega ja seejärel sõnadega.

## Mul on väike vellekene
URL: https://www.opiq.ee/kit/195/chapter/11172
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 13.3
Topics ET: matemaatika, väike, vellekene
Topics RU: математика
Topics EN: mathematics
Headings: Mul on väike vellekene
Task examples: Leia ja kirjuta töövihikus tornidesse Eesti linnade nimed vastavalt rütmile (kasuta Eesti kaarti).

## Pisike puu
URL: https://www.opiq.ee/kit/195/chapter/11173
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 13.4
Topics ET: matemaatika, taim, taimed, puu, lill, pisike
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pisike puu
Task examples: Koosta vanemate abiga oma perekonna sugupuu töövihikusse. Joonista puule oksad ning kirjuta iga pereliikme nimi ja sugulusaste (vanaema, vanaisa, ema, isa, vend, õde, onu, tädi jne).

## Mu isamaa, mu õnn ja rõõm
URL: https://www.opiq.ee/kit/195/chapter/11174
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 13.5
Topics ET: matemaatika, isamaa, rõõm
Topics RU: математика
Topics EN: mathematics
Headings: Mu isamaa, mu õnn ja rõõm

## Pillimehed
URL: https://www.opiq.ee/kit/195/chapter/11175
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 14.1
Topics ET: matemaatika, pillimehed
Topics RU: математика
Topics EN: mathematics
Headings: Pillimehed
Task examples: Jaga rütm taktidesse töövihikus. Esita sõbraga rütmikaanonid kas silpidel või rütmipillidel.; Kirjuta vastav muusikaline märk töövihikus.

## Pillimäng
URL: https://www.opiq.ee/kit/195/chapter/11176
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 14.2
Topics ET: matemaatika, pillimäng, plokkflöödi, mänguvõtted
Topics RU: математика
Topics EN: mathematics
Headings: Pillimäng; Plokkflöödi mänguvõtted

## Meeril oli talleke
URL: https://www.opiq.ee/kit/195/chapter/11177
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 14.3
Topics ET: matemaatika, meeril, talleke
Topics RU: математика
Topics EN: mathematics
Headings: Meeril oli talleke
Task examples: Märgi töövihikus plokkflöödi piltidele õiged mänguvõtted. Mängi.

## Vastlalaul
URL: https://www.opiq.ee/kit/195/chapter/11178
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 14.4
Topics ET: matemaatika, vastlalaul
Topics RU: математика
Topics EN: mathematics
Headings: Vastlalaul
Task examples: Leia ja värvi vastlapäevaga seotud sõnad töövihikus.

## Teatris ei või sülitada
URL: https://www.opiq.ee/kit/195/chapter/11179
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.1
Topics ET: matemaatika, teatris, sülitada, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Teatris ei või sülitada; Teatris; Tähesegadik
Task examples: Täida ülesanne töövihikus.

## Kull ja värvuke
URL: https://www.opiq.ee/kit/195/chapter/11180
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.2
Topics ET: matemaatika, kull, värvuke, võluflööt
Topics RU: математика
Topics EN: mathematics
Headings: Kull ja värvuke; Võluflööt
Task examples: Leia ja kirjuta pildi juurde töövihikus, kus asuvad rõdu, loož, parter, eesriie, solistid, lava, dirigent ja orkester.

## Printsess Okasroos
URL: https://www.opiq.ee/kit/195/chapter/11181
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.3
Topics ET: matemaatika, printsess, okasroos
Topics RU: математика
Topics EN: mathematics
Headings: Printsess Okasroos
Task examples: Joonista töövihikusse lavakujundus laulule „Printsess Okasroos” või laulule „Mereröövlisaar”.

## Mereröövlisaar
URL: https://www.opiq.ee/kit/195/chapter/11182
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.4
Topics ET: matemaatika, mereröövlisaar
Topics RU: математика
Topics EN: mathematics
Headings: Mereröövlisaar

## Ballett
URL: https://www.opiq.ee/kit/195/chapter/11183
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.5
Topics ET: matemaatika, ballett, pähklipureja, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Ballett; Pähklipureja; Tähesegadik
Task examples: Tõmba taktijooned ja kirjuta astmenimed töövihikus. Esita harjutuse rütm koputades ja ütle rütmisilpe kaasa. Laula ja näita käemärke.

## Vana prantsuse lauluke
URL: https://www.opiq.ee/kit/195/chapter/11184
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.6
Topics ET: matemaatika, vana, prantsuse, lauluke
Topics RU: математика
Topics EN: mathematics
Headings: Vana prantsuse lauluke
Task examples: Lavasta koos oma pere või sõpradega lühiooper või -ballett. Kujunda ise teatrietenduse kuulutus töövihikus. KUULUTUS

## Ilus elu
URL: https://www.opiq.ee/kit/195/chapter/11185
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.7
Topics ET: matemaatika, ilus
Topics RU: математика
Topics EN: mathematics
Headings: Ilus elu

## Mesilane Susumu
URL: https://www.opiq.ee/kit/195/chapter/11186
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 15.8
Topics ET: matemaatika, mesilane, susumu
Topics RU: математика
Topics EN: mathematics
Headings: Mesilane Susumu
Task examples: Täida ülesanne töövihikus.

## Luuletava siili laul
URL: https://www.opiq.ee/kit/195/chapter/11187
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 16.1
Topics ET: matemaatika, luuletava, siili, laul, komalaul
Topics RU: математика
Topics EN: mathematics
Headings: Luuletava siili laul; KOMALAUL

## Mustikasuu
URL: https://www.opiq.ee/kit/195/chapter/11188
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 16.2
Topics ET: matemaatika, mustikasuu
Topics RU: математика
Topics EN: mathematics
Headings: Mustikasuu
Task examples: Leia ja kirjuta luuletuse „Komalaul” (õpikus lk 136) salmide rütm töövihikusse. Kirjuta rütmi-ostinato. Esita.

## Herilane sõidab jänest
URL: https://www.opiq.ee/kit/195/chapter/11189
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 16.3
Topics ET: matemaatika, herilane, sõidab, jänest, henno, kuidas, käsi, käib
Topics RU: математика
Topics EN: mathematics
Headings: Herilane sõidab jänest; Henno Käo; KUIDAS KÄSI KÄIB?
Task examples: Vali ja kirjuta pallidelt rütmid ja nendele sobivad astmenimed töövihikusse. Kirjuta viis noodijoonestikule. Värvi pallid.; Jaga viis taktidesse töövihikus. Laula noodist mõlemat häält. Esitage harjutus kahehäälselt.

## Naljamaa
URL: https://www.opiq.ee/kit/195/chapter/11190
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 16.4
Topics ET: matemaatika, naljamaa
Topics RU: математика
Topics EN: mathematics
Headings: Naljamaa

## Rõõmsad haned
URL: https://www.opiq.ee/kit/195/chapter/11191
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 16.5
Topics ET: matemaatika, rõõmsad, haned
Topics RU: математика
Topics EN: mathematics
Headings: Rõõmsad haned
Task examples: Kirjuta töövihikus kastidesse sobiva pikkusega rütmivormid. Mõtle ise harjutusi juurde.; Kirjuta laul „Rõõmsad haned” noodijoonestikule töövihikus. Laula ja näita käemärke.

## Linnud toovad ilmad
URL: https://www.opiq.ee/kit/195/chapter/11192
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.1
Topics ET: matemaatika, loom, loomad, linnud, putukad, toovad, ilmad
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Linnud toovad ilmad

## Laulgem kõik koos!
URL: https://www.opiq.ee/kit/195/chapter/11201
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.10
Topics ET: matemaatika, laulgem, kõik, koos
Topics RU: математика
Topics EN: mathematics
Headings: Laulgem kõik koos!
Task examples: Kirjuta astmenimed töövihikusse. Laula ja näita käemärke. Esitage kaanon pa-, tu- või don-silpidel.

## Kevadpidu
URL: https://www.opiq.ee/kit/195/chapter/11202
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.11
Topics ET: matemaatika, kevadpidu
Topics RU: математика
Topics EN: mathematics
Headings: Kevadpidu

## Jüripäev
URL: https://www.opiq.ee/kit/195/chapter/11193
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.2
Topics ET: matemaatika, jüripäev
Topics RU: математика
Topics EN: mathematics
Headings: Jüripäev

## Üks väike karjapiiga
URL: https://www.opiq.ee/kit/195/chapter/11194
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.3
Topics ET: matemaatika, väike, karjapiiga
Topics RU: математика
Topics EN: mathematics
Headings: Üks väike karjapiiga
Task examples: Tõmba taktijooned ja kirjuta astmenimed töövihikus. Laula viisi rütmisaatega.; Leia astmed ja värvi pilt töövihikus: DI – helesinine, J – must, L – kollane, M – sinine, N – oranž, S – punane, R – roheline, D – pruun, JI – lilla.

## Kiigelaul
URL: https://www.opiq.ee/kit/195/chapter/11195
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.4
Topics ET: matemaatika, kiigelaul
Topics RU: математика
Topics EN: mathematics
Headings: Kiigelaul

## Kuula, mu linnuke
URL: https://www.opiq.ee/kit/195/chapter/11196
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.5
Topics ET: matemaatika, kuula, linnuke
Topics RU: математика
Topics EN: mathematics
Headings: Kuula, mu linnuke

## Kägu
URL: https://www.opiq.ee/kit/195/chapter/11197
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.6
Topics ET: matemaatika, kägu
Topics RU: математика
Topics EN: mathematics
Headings: Kägu
Task examples: Kirjuta viis noodijoonestikule töövihikus. Laula astmenimede ja sõnadega. Esitage kaanon rühmades.

## Lõoke
URL: https://www.opiq.ee/kit/195/chapter/11198
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.7
Topics ET: matemaatika, lõoke
Topics RU: математика
Topics EN: mathematics
Headings: Lõoke

## Kägu
URL: https://www.opiq.ee/kit/195/chapter/11199
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.8
Topics ET: matemaatika, kägu
Topics RU: математика
Topics EN: mathematics
Headings: Kägu

## Vihmakene, vellekene
URL: https://www.opiq.ee/kit/195/chapter/11200
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 17.9
Topics ET: matemaatika, vihmakene, vellekene
Topics RU: математика
Topics EN: mathematics
Headings: Vihmakene, vellekene
Task examples: Lahenda koodmõistatus töövihikus.

## Ema
URL: https://www.opiq.ee/kit/195/chapter/11203
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 18.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ema

## Kes on meie ema?
URL: https://www.opiq.ee/kit/195/chapter/11204
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 18.2
Topics ET: matemaatika, meie
Topics RU: математика
Topics EN: mathematics
Headings: Kes on meie ema?
Task examples: Kuula muusikat ja joonista pilt emadepäevast töövihikusse. EMADEPÄEV

## Vana maja jõe ääres
URL: https://www.opiq.ee/kit/195/chapter/11205
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 18.3
Topics ET: matemaatika, vana, maja, ääres
Topics RU: математика
Topics EN: mathematics
Headings: Vana maja jõe ääres
Task examples: Kirjuta astmetrepile töövihikus RAI–RA astmenimed.

## Minu vanaema
URL: https://www.opiq.ee/kit/195/chapter/11206
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 18.4
Topics ET: matemaatika, vanaema
Topics RU: математика
Topics EN: mathematics
Headings: Minu vanaema

## Süda tuksub
URL: https://www.opiq.ee/kit/195/chapter/11207
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 19.1
Topics ET: matemaatika, süda, tuksub
Topics RU: математика
Topics EN: mathematics
Headings: Süda tuksub

## Saab sööki ja jooki
URL: https://www.opiq.ee/kit/195/chapter/11208
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 19.2
Topics ET: matemaatika, saab, sööki, jooki
Topics RU: математика
Topics EN: mathematics
Headings: Saab sööki ja jooki
Task examples: Kes on pildil? Kirjuta töövihikusse, kes see isik ametilt on.

## Tuhat tänu
URL: https://www.opiq.ee/kit/195/chapter/11209
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 19.3
Topics ET: matemaatika, tuhat, tänu
Topics RU: математика
Topics EN: mathematics
Headings: Tuhat tänu
Task examples: Värvi lauamäng töövihikus. Mängi sõpradega lauamängu.

## Koolitöö lõpeb
URL: https://www.opiq.ee/kit/195/chapter/11210
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 19.4
Topics ET: matemaatika, koolitöö, lõpeb, puhkus
Topics RU: математика
Topics EN: mathematics
Headings: Koolitöö lõpeb; Puhkus
Task examples: Kirjuta ühe muusikaetenduse arvustus töövihikusse. (lavastuse pealkiri ja autorid; kus ja millal etendus toimus; kirjelda tegelasi, kostüüme ja lavakujundust; missugune oli lavastuse muusika; mis sulle etenduses kõige ro

## Hommik
URL: https://www.opiq.ee/kit/195/chapter/11091
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 2.1
Topics ET: matemaatika, hommik
Topics RU: математика
Topics EN: mathematics
Headings: Hommik

## Bugi
URL: https://www.opiq.ee/kit/195/chapter/11092
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 2.2
Topics ET: matemaatika, bugi
Topics RU: математика
Topics EN: mathematics
Headings: Bugi

## Plaksutame koos
URL: https://www.opiq.ee/kit/195/chapter/11093
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 2.3
Topics ET: matemaatika, plaksutame, koos
Topics RU: математика
Topics EN: mathematics
Headings: Plaksutame koos; PLAKSUTAME KOOS!
Task examples: Arvuta ja kirjuta vastused töövihikus. Esita rütmid ja ütle rütmisilpe kaasa.; Kuula ja iseloomusta muusikapala. Ovaalidest leiad sobivaid omadussõnu. Täida lüngad töövihikus.

## Sõnaseletused
URL: https://www.opiq.ee/kit/195/chapter/11211
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 20.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Neli pilti
URL: https://www.opiq.ee/kit/195/chapter/11094
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 3.1
Topics ET: matemaatika, neli, pilti
Topics RU: математика
Topics EN: mathematics
Headings: Neli pilti
Task examples: Leia värvid lauludest „Neli pilti” ja „Koduvärvid”. Joonista ühest laulust pilt töövihikusse.; Leia ja kirjuta sõnarütm töövihikus. Laula luuletust kandle või rütmipilli saatel.

## Koduvärvid
URL: https://www.opiq.ee/kit/195/chapter/11095
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 3.2
Topics ET: matemaatika, koduvärvid
Topics RU: математика
Topics EN: mathematics
Headings: Koduvärvid

## Sõmeralt sain Sõrmikulle
URL: https://www.opiq.ee/kit/195/chapter/11096
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 3.3
Topics ET: matemaatika, sõmeralt, sain, sõrmikulle, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Sõmeralt sain Sõrmikulle; Tähesegadik

## Kellakapi kägu
URL: https://www.opiq.ee/kit/195/chapter/11097
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 3.4
Topics ET: matemaatika, kellakapi, kägu
Topics RU: математика
Topics EN: mathematics
Headings: Kellakapi kägu
Task examples: Moodusta ajamõistetest pingerida. Alusta kõige lühemast (tund, sajand, ööpäev, aasta, minut, kuu, sekund, nädal).; Täida taktid oma rütmidega töövihikus. Esitage harjutused koos pinginaabriga erinevatel pillidel.

## Väikene laululind
URL: https://www.opiq.ee/kit/195/chapter/11098
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.1
Topics ET: matemaatika, väikene, laululind
Topics RU: математика
Topics EN: mathematics
Headings: Väikene laululind
Task examples: Leia muusikaline märk ja sellele vastav mõiste.

## Lõikuse laul
URL: https://www.opiq.ee/kit/195/chapter/11107
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.10
Topics ET: matemaatika, lõikuse, laul
Topics RU: математика
Topics EN: mathematics
Headings: Lõikuse laul
Task examples: Kirjuta taktimõõt, puuduvad astmenimed ja noodipead töövihikus. Tõmba N-astmele värviline ring ümber. Laula käemärkidega.; Moodusta viisilõikudest meloodia ja kirjuta see noodijoonestikule töövihikus. Laula.

## Ketramas
URL: https://www.opiq.ee/kit/195/chapter/11108
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.11
Topics ET: matemaatika, ketramas, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Ketramas; Tähesegadik
Task examples: Leia ja kirjuta pillide nimed töövihikus. Tõmba rütmipillidele värviline joon ümber.; Kuula muusikapala ja joonista töövihikusse MUUSIKAMAA tegelastele pillid, mille esitust sa kuulsid.

## Laulge poisid!
URL: https://www.opiq.ee/kit/195/chapter/11109
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.12
Topics ET: matemaatika, laulge, poisid
Topics RU: математика
Topics EN: mathematics
Headings: Laulge poisid!; LAULGE, POISID!

## Hiir hüppas
URL: https://www.opiq.ee/kit/195/chapter/11110
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.13
Topics ET: matemaatika, hiir, hüppas
Topics RU: математика
Topics EN: mathematics
Headings: Hiir hüppas
Task examples: Märgi taktimõõt ja kirjuta astmenimed töövihikus. Esita kaanon koos sõbraga.; Leia lausetele õiged lõpud.

## Hällilaul
URL: https://www.opiq.ee/kit/195/chapter/11111
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.14
Topics ET: matemaatika, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Hällilaul

## Karupoja hällilaul
URL: https://www.opiq.ee/kit/195/chapter/11112
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.15
Topics ET: matemaatika, karupoja, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Karupoja hällilaul
Task examples: Jaga töövihikus rütm taktidesse ja esita kahe käega korraga.; Kirjuta I ja II hääle viisid noodijoonestikule töövihikus. Esitage laul kahehäälselt.

## Ninna nanna
URL: https://www.opiq.ee/kit/195/chapter/11113
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.16
Topics ET: matemaatika, ninna, nanna
Topics RU: математика
Topics EN: mathematics
Headings: Ninna nanna
Task examples: Tõmba taktijooned töövihikus ja esita rütmikaanon koos sõbraga.

## Unelauluke
URL: https://www.opiq.ee/kit/195/chapter/11114
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.17
Topics ET: matemaatika, unelauluke
Topics RU: математика
Topics EN: mathematics
Headings: Unelauluke

## Seenekoor
URL: https://www.opiq.ee/kit/195/chapter/11099
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.2
Topics ET: matemaatika, seenekoor
Topics RU: математика
Topics EN: mathematics
Headings: Seenekoor

## Vihma sajab
URL: https://www.opiq.ee/kit/195/chapter/11100
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.3
Topics ET: matemaatika, vihma, sajab
Topics RU: математика
Topics EN: mathematics
Headings: Vihma sajab
Task examples: Leia seente nimed laulust „Seenekoor” (õpikus lk 16) ning kirjuta need vastava rütmi juurde töövihikus. Esita rütmid rütmipillidel.

## Uued kummikud
URL: https://www.opiq.ee/kit/195/chapter/11101
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.4
Topics ET: matemaatika, uued, kummikud
Topics RU: математика
Topics EN: mathematics
Headings: Uued kummikud

## Tigu-ligu
URL: https://www.opiq.ee/kit/195/chapter/11102
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.5
Topics ET: matemaatika, tigu, ligu
Topics RU: математика
Topics EN: mathematics
Headings: Tigu-ligu
Task examples: Tõmba taktijooned töövihikus. Kirjuta astmenimed nootide alla. Laula koos käemärkidega.

## Tige tigu
URL: https://www.opiq.ee/kit/195/chapter/11103
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.6
Topics ET: matemaatika, tige, tigu
Topics RU: математика
Topics EN: mathematics
Headings: Tige tigu

## Heinaaeg on ikka nii!
URL: https://www.opiq.ee/kit/195/chapter/11104
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.7
Topics ET: matemaatika, heinaaeg, ikka
Topics RU: математика
Topics EN: mathematics
Headings: Heinaaeg on ikka nii!
Task examples: Kirjuta laulule „Heinaaeg on ikka nii” kaks ostinato’t ehk rütmisaadet töövihikus ja esita need koos lauluga.

## Raa-rii-raa
URL: https://www.opiq.ee/kit/195/chapter/11105
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Raa-rii-raa
Task examples: Kirjuta käemärkide alla astmenimed töövihikus. Laula käemärkidega. Värvi käed.; Kirjuta eelmine harjutus noodijoonestikule töövihikus. Tõmba N-astmele värviline ring ümber. Laula.

## Marjuke
URL: https://www.opiq.ee/kit/195/chapter/11106
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 4.9
Topics ET: matemaatika, marjuke
Topics RU: математика
Topics EN: mathematics
Headings: Marjuke

## Rõõmsad rändurid
URL: https://www.opiq.ee/kit/195/chapter/11115
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 5.1
Topics ET: matemaatika, rõõmsad, rändurid
Topics RU: математика
Topics EN: mathematics
Headings: Rõõmsad rändurid

## Lähme, lapsed
URL: https://www.opiq.ee/kit/195/chapter/11116
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 5.2
Topics ET: matemaatika, lähme, lapsed, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Lähme, lapsed; Tähesegadik
Task examples: Märgi taktimõõt töövihikus. Täida tühjad taktid. Esita rütmiharjutused kehapillil või mõnel rütmipillil.; Jaga töövihikus viis taktidesse ja kirjuta nootide alla astmenimed. Tõmba N-astmele värviline ring ümber. Laula käemärkidega.

## Liiolii
URL: https://www.opiq.ee/kit/195/chapter/11118
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 5.3
Topics ET: matemaatika, liiolii
Topics RU: математика
Topics EN: mathematics
Headings: Liiolii
Task examples: Kirjuta viis noodijoonestikule töövihikus. Tõmba JI-astmele värviline ring ümber. Mõtle viisile sõnad juurde. Esita laul.; Igas laevas on ühe laulu algus (vt õpikust lk 19–35). Leia ja kirjuta laulude pealkirjad töövihikusse. Vali ja esita üks laul. Värvi.

## Käi ümber küla ringi
URL: https://www.opiq.ee/kit/195/chapter/11119
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 5.4
Topics ET: matemaatika, ümber, küla, ringi
Topics RU: математика
Topics EN: mathematics
Headings: Käi ümber küla ringi
Task examples: Kuula muusikat ja ühenda töövihikus riimuvad sõnad joonega. Kirjuta luuletus oma õpetajast. Kasuta riimuvaid sõnu.

## Tuuled nüüd puhuvad
URL: https://www.opiq.ee/kit/195/chapter/11120
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 5.5
Topics ET: matemaatika, tuuled, nüüd, puhuvad, dünaamika
Topics RU: математика
Topics EN: mathematics
Headings: Tuuled nüüd puhuvad; Dünaamika
Task examples: Kirjuta töövihikus DI-aste värviliselt. Lisa astmenimed.

## Uhti, uhti, uhkesti
URL: https://www.opiq.ee/kit/195/chapter/11121
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 5.6
Topics ET: matemaatika, uhti, uhkesti, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Uhti, uhti, uhkesti; UHTI, UHTI UHKESTI; Tähesegadik
Task examples: Täida ülesanne töövihikus.; Leia ja kirjuta luuletuse „Tule jälle, ole hea!” rütm (õpikus lk 46). Kirjuta rütmile viis, kasutades S-, N-, M-, L- ja J-astmeid. Laula viisi käemärkidega.

## Laupäeva õhtul isaga
URL: https://www.opiq.ee/kit/195/chapter/11122
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.1
Topics ET: matemaatika, laupäeva, õhtul, isaga
Topics RU: математика
Topics EN: mathematics
Headings: Laupäeva õhtul isaga

## Sepapoisid
URL: https://www.opiq.ee/kit/195/chapter/11123
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.2
Topics ET: matemaatika, sepapoisid
Topics RU: математика
Topics EN: mathematics
Headings: Sepapoisid
Task examples: Leia ja kirjuta laulust „Laupäeva õhtul isaga”, mida võib koos isaga teha. Joonista pilt töövihikusse.; Lahenda ülesanne töövihikus.

## Meeste sugu
URL: https://www.opiq.ee/kit/195/chapter/11124
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.3
Topics ET: matemaatika, meeste, sugu
Topics RU: математика
Topics EN: mathematics
Headings: Meeste sugu

## Mardilaul
URL: https://www.opiq.ee/kit/195/chapter/11125
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.4
Topics ET: matemaatika, mardilaul
Topics RU: математика
Topics EN: mathematics
Headings: Mardilaul

## Vares, vaga linnukene
URL: https://www.opiq.ee/kit/195/chapter/11126
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.5
Topics ET: matemaatika, vares, vaga, linnukene
Topics RU: математика
Topics EN: mathematics
Headings: Vares, vaga linnukene

## Kuldne viljatera
URL: https://www.opiq.ee/kit/195/chapter/11127
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.6
Topics ET: matemaatika, kuldne, viljatera, leib
Topics RU: математика
Topics EN: mathematics
Headings: Kuldne viljatera; Leib
Task examples: Meisterda jauram Vaata valmistamisjuhendit töövihikus Esita „Mardilaul” (õpikus lk 52) jaurami saatel.; Lahenda ristsõna töövihikus.

## Mängulaul
URL: https://www.opiq.ee/kit/195/chapter/11128
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.7
Topics ET: matemaatika, mängulaul
Topics RU: математика
Topics EN: mathematics
Headings: Mängulaul

## Kadrilaul
URL: https://www.opiq.ee/kit/195/chapter/11129
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.8
Topics ET: matemaatika, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kadrilaul

## Tänamise laul
URL: https://www.opiq.ee/kit/195/chapter/11130
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 6.9
Topics ET: matemaatika, tänamise, laul
Topics RU: математика
Topics EN: mathematics
Headings: Tänamise laul
Task examples: Leia mõistatustele vastused. Kirjuta töövihikus puuduvad tähed. Mõtle mõistatusi juurde.

## Laul vaprast koerasüdamest
URL: https://www.opiq.ee/kit/195/chapter/11131
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 7.1
Topics ET: matemaatika, laul, vaprast, koerasüdamest, leelo, tungal
Topics RU: математика
Topics EN: mathematics
Headings: Laul vaprast koerasüdamest; Leelo Tungal

## Mesimumm
URL: https://www.opiq.ee/kit/195/chapter/11132
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 7.2
Topics ET: matemaatika, mesimumm
Topics RU: математика
Topics EN: mathematics
Headings: Mesimumm
Task examples: Arvuta ja kirjuta vastused töövihikusse. Esita rütmid kehapillil.

## Meie vutikene
URL: https://www.opiq.ee/kit/195/chapter/11133
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 7.3
Topics ET: matemaatika, meie, vutikene
Topics RU: математика
Topics EN: mathematics
Headings: Meie vutikene

## Loomade pidu
URL: https://www.opiq.ee/kit/195/chapter/11134
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 7.4
Topics ET: matemaatika, loomade, pidu
Topics RU: математика
Topics EN: mathematics
Headings: Loomade pidu

## Minu hani
URL: https://www.opiq.ee/kit/195/chapter/11135
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 7.5
Topics ET: matemaatika, hani
Topics RU: математика
Topics EN: mathematics
Headings: Minu hani
Task examples: Kirjuta I ja II hääle viisid noodijoonestikule töövihikus. Esitage harjutus kahehäälselt.; Kirjuta laul „Minu hani” (õpikus lk 63) noodijoonestikule töövihikus.

## Lumeveski
URL: https://www.opiq.ee/kit/195/chapter/11136
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 8.1
Topics ET: matemaatika, lumeveski
Topics RU: математика
Topics EN: mathematics
Headings: Lumeveski
Task examples: Kuula muusikat ja joonista pilt töövihikusse. LUMEVESKI

## Tihane
URL: https://www.opiq.ee/kit/195/chapter/11137
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 8.2
Topics ET: matemaatika, tihane
Topics RU: математика
Topics EN: mathematics
Headings: Tihane

## Metsas sirgus kuuseke
URL: https://www.opiq.ee/kit/195/chapter/11138
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 8.3
Topics ET: matemaatika, metsas, sirgus, kuuseke
Topics RU: математика
Topics EN: mathematics
Headings: Metsas sirgus kuuseke

## Kuuse tegemise laul
URL: https://www.opiq.ee/kit/195/chapter/11139
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 8.4
Topics ET: matemaatika, kuuse, tegemise, laul, olav, ehala
Topics RU: математика
Topics EN: mathematics
Headings: Kuuse tegemise laul; Olav Ehala
Task examples: Kirjuta töövihikus astmenimed nootide alla ja astmed koos rütmiga noodijoonestikule. Laula.

## Päkapikk
URL: https://www.opiq.ee/kit/195/chapter/11140
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 9.1
Topics ET: matemaatika, päkapikk
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikk

## Tooma laulukoor
URL: https://www.opiq.ee/kit/195/chapter/11141
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 9.2
Topics ET: matemaatika, tooma, laulukoor
Topics RU: математика
Topics EN: mathematics
Headings: Tooma laulukoor
Task examples: Koosta jõululaua menüü töövihikus.

## Jõulud jõudvad
URL: https://www.opiq.ee/kit/195/chapter/11142
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 9.3
Topics ET: matemaatika, jõulud, jõudvad
Topics RU: математика
Topics EN: mathematics
Headings: Jõulud jõudvad

## Läbi öö
URL: https://www.opiq.ee/kit/195/chapter/11143
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 9.4
Topics ET: matemaatika, läbi
Topics RU: математика
Topics EN: mathematics
Headings: Läbi öö
Task examples: Kuula jõulumuusikat ja täienda pilti töövihikus.

## Piparkoogipoiste laul
URL: https://www.opiq.ee/kit/195/chapter/11144
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 9.5
Topics ET: matemaatika, piparkoogipoiste, laul
Topics RU: математика
Topics EN: mathematics
Headings: Piparkoogipoiste laul

## Mul ütle, miks?
URL: https://www.opiq.ee/kit/195/chapter/11145
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 9.6
Topics ET: matemaatika, ütle, miks
Topics RU: математика
Topics EN: mathematics
Headings: Mul ütle, miks?
Task examples: Paranda rütmivead punase pliiatsiga töövihikus. Mitu viga oli igas ülesandes? Esita rütmiread.; Tee jõuluvaheajal oma vanavanematega intervjuu ja uuri, kuidas vanasti kodudes jõule peeti.

## Aisakell
URL: https://www.opiq.ee/kit/195/chapter/11146
Book: Muusikamaa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikamaa
Chapter ID: 9.7
Topics ET: matemaatika, aisakell
Topics RU: математика
Topics EN: mathematics
Headings: Aisakell

## Muusikaõpik 3. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/163
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 124
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikaõpik 3. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/163
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 157
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Laul ja pill
URL: https://www.opiq.ee/kit/163/chapter/9173
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.1
Topics ET: matemaatika, aeg, kell, kalender, laul, pill, laula, hõiska, sest, laulu, käes, millest, koosneb
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Laul ja pill; Oh laula ja hõiska, sest laulu aeg on käes!; Millest laul koosneb?; Kui mina hakkan laulemaie; Kuidas laulu õppida?; Laul on pop!
Task examples: Mis pannakse kirja sõnade, mis nootidega? Jaota vastused kahte rühma.; Milliseid hääli oled sa kuulnud looduses suvel, sügisel, talvel, kevadel? Loetle.

## Mardi- ja kadrilaulud
URL: https://www.opiq.ee/kit/163/chapter/9184
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.10
Topics ET: matemaatika, mardi, kadrilaulud, olgõ, terve, pereesä, kadriko, õnne, maale, karjale
Topics RU: математика
Topics EN: mathematics
Headings: Mardi- ja kadrilaulud; Olgõ terve, pereesä, kadriko, kadriko!; Õnne maale ja karjale; Sisselaskmine; Õnne soovimine; Andide palumine; Tänamine ja soovid
Task examples: Millist õnne toovad kadrid, millist mardid? Lohista pildid õigesse veergu.; Millised soovid olid pererahval kadridele? Kuula või uuri laulusõnu ja ühenda paarid.

## Dünaamika
URL: https://www.opiq.ee/kit/163/chapter/9191
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.11
Topics ET: matemaatika, dünaamika, meelelaad, muusikas, kõlajõud, meie, ümber, lugu
Topics RU: математика
Topics EN: mathematics
Headings: Dünaamika; Meelelaad muusikas; Kõlajõud; Dünaamika meie ümber; Aja lugu
Task examples: Kuula helinäidet ja pane dünaamikamärgid õigesse järjekorda.; Kuula helinäiteid ja märgi õige dünaamika.

## Gustav Ernesaks
URL: https://www.opiq.ee/kit/163/chapter/9182
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.12
Topics ET: matemaatika, gustav, ernesaks, eesti, rahva, laulutaat, laulupidude, hing, kolm
Topics RU: математика
Topics EN: mathematics
Headings: Gustav Ernesaks; Eesti rahva laulutaat; Laulupidude hing; Kolm kihulast; Uhti, uhti uhkesti
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Aste JO'
URL: https://www.opiq.ee/kit/163/chapter/9192
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.13
Topics ET: matemaatika, aste, helirea, lõpp, algus, mängi, pillimees, helitrepil, joonestikul
Topics RU: математика
Topics EN: mathematics
Headings: Aste JO'; Helirea lõpp ja algus; Mängi, mängi, pillimees; Aste JO' helitrepil ja joonestikul; Rong juba saabub; Rütmirongid
Task examples: Millised JO-astmed kõlavad? Kuula heliridasid ja vali õige vastus.; Kuula helinäiteid ja järjesta käemärgid.

## Muusika esitajad
URL: https://www.opiq.ee/kit/163/chapter/9177
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.14
Topics ET: matemaatika, muusika, esitajad, hääle, pilliga, vokaal, instrumentaalmuusika, koosseisud, piltidel
Topics RU: математика
Topics EN: mathematics
Headings: Muusika esitajad; Hääle ja pilliga; Vokaal- ja instrumentaalmuusika; Koosseisud piltidel; Valik muusikanäiteid
Task examples: Sorteeri märksõnad kahte rühma.; Märgi loetelus ära pillid.

## Talvelaulud
URL: https://www.opiq.ee/kit/163/chapter/9185
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.15
Topics ET: matemaatika, talvelaulud, lumised, lood, esimene, lumi, tali, vihistab, jõululaul, jõulunukrus
Topics RU: математика
Topics EN: mathematics
Headings: Talvelaulud; Lumised lood; Esimene lumi; Tali; Las vihistab; Jõululaul; Jõulunukrus, jõulurõõm; Sa südames nüüd pane; Jõulukellad; Tuhat valgust; Aisakell; Metsas sirgus kuuseke; Uuel aastal; Jaanuar; Muusika piltides

## Kehapill
URL: https://www.opiq.ee/kit/163/chapter/9174
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.2
Topics ET: matemaatika, kehapill, ikka, kaasas, kehapilli, kõlad, rütm, muusika, rütmiharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kehapill; Ikka kaasas; Kehapilli kõlad; Rütm ja muusika; Rütmiharjutus kehapillile; Loomine
Task examples: Kuula helinäidet ja märgi, millised kehapillihelid kõlavad.; Uuri laulusõnu. Vali või märgi õige vastus.

## Noot
URL: https://www.opiq.ee/kit/163/chapter/9187
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.3
Topics ET: matemaatika, noot, vars, leht, noodipuul, noodipikkused, kõla, lahke, laulukaja
Topics RU: математика
Topics EN: mathematics
Headings: Noot; Vars ja leht noodipuul; Noodipikkused; Kõla, lahke laulukaja
Task examples: Vali rippmenüüst õige rütmisõna. Mõtle välja kaks uut võrdust.

## Taktimõõt
URL: https://www.opiq.ee/kit/163/chapter/9188
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.4
Topics ET: matemaatika, taktimõõt, mõõdab, löögid, taktidesse, kuidas, märkida, kivikasukas, tuttavate
Topics RU: математика
Topics EN: mathematics
Headings: Taktimõõt; Mõõdab löögid taktidesse; Kuidas märkida?; Kivikasukas; Tuttavate laulude rütmid; Kodu
Task examples: Kuula, loe ja mängi 2. klassis õpitud laulude rütmi. Kirjuta õige laulu pealkiri ning mitu lööki on taktis.; Kuula, loe ja mängi 2. klassis õpitud laulude rütmi. Kirjuta õige laulu pealkiri ning mitu lööki on taktis.

## Pausid
URL: https://www.opiq.ee/kit/163/chapter/9189
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.5
Topics ET: matemaatika, pausid, vaikus, muusika, pausi, tähised, kägu
Topics RU: математика
Topics EN: mathematics
Headings: Pausid; Vaikus on muusika; Pausi tähised; Kägu; Õpetaja
Task examples: Sorteeri pildid kahte rühma.; Ühenda omavahel võrdse pikkusega pausid ja noodid.

## Kaanon
URL: https://www.opiq.ee/kit/163/chapter/9175
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.6
Topics ET: matemaatika, kaanon, sepapoisid, lihtne, mitmehäälne, laul, tervituskaanon, rütmikaanon
Topics RU: математика
Topics EN: mathematics
Headings: Kaanon; Sepapoisid, sepapoisid ...; Lihtne mitmehäälne laul; Tervituskaanon; Rütmikaanon

## Improvisatsioon
URL: https://www.opiq.ee/kit/163/chapter/9176
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.7
Topics ET: matemaatika, improvisatsioon, kujutluspilt, saab, tõeks, hetkes, loomine, rütmi, karjapoisi, pasunalugu
Topics RU: математика
Topics EN: mathematics
Headings: Improvisatsioon; Kujutluspilt saab tõeks; Hetkes loomine; Rütmi-improvisatsioon; Karjapoisi pasunalugu; Imed

## Rütm TI-RI-TI-RI
URL: https://www.opiq.ee/kit/163/chapter/9190
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.8
Topics ET: matemaatika, rütm, jooksusammurütm, laul, vihmast, rütmid, kehapillil
Topics RU: математика
Topics EN: mathematics
Headings: Rütm TI-RI-TI-RI; Jooksusammurütm; Laul vihmast; TI-RI-TI-RI rütm; Rütmid kehapillil
Task examples: Jaota sõnad rütmi põhjal kahte rühma.; Loe ja plaksuta lausete rütmi ning reasta noodikaardid.

## Marss
URL: https://www.opiq.ee/kit/163/chapter/9179
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 1.9
Topics ET: matemaatika, marss, vasak, parem, ikka, taktis, astu, marsse, mitmesuguseid
Topics RU: математика
Topics EN: mathematics
Headings: Marss; Vasak, parem, vasak, parem, ikka taktis astu ...; Marsse on mitmesuguseid; Kuula marsimuusikat; Väike maailm; Mänguasjade rongkäik
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Rütm TA-I-RI
URL: https://www.opiq.ee/kit/163/chapter/9193
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, rütm, hüpperütm, kingsepa, tants, liisutus, käes
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Rütm TA-I-RI; Hüpperütm; Kingsepa tants; TA-I-RI; Liisutus; Käes on talv
Task examples: Kuula ja plaksuta helinäiteid ning järjesta rütmid.

## Miina Härma
URL: https://www.opiq.ee/kit/163/chapter/9183
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.10
Topics ET: matemaatika, miina, härma, mitte, vaiki, olla, lauluviisi, lõpeta, esimene, elukutseline
Topics RU: математика
Topics EN: mathematics
Headings: Miina Härma; Ei saa mitte vaiki olla, lauluviisi lõpeta’; Esimene elukutseline naishelilooja; Emakesele
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Eesti laulud
URL: https://www.opiq.ee/kit/163/chapter/9186
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.2
Topics ET: matemaatika, eesti, laulud, keeles, meeles, emakeel, isamaa, armas, süda, tuksub
Topics RU: математика
Topics EN: mathematics
Headings: Eesti laulud; Keeles ja meeles; Emakeel; Mu isamaa armas; Süda tuksub; Pill hüüdis pinu taga; Oksad oravaid täis; Vastlalaul; Tähemäng; Hea tuju kaanon; Kellalapsed; Päike ja mina; Kommimaa kuninga laul
Task examples: Tuleta meelde, milliseid eesti rahvapille sa tead. Märgi loetelus ainult rahvapillid.; Märgi õige vastus ja kirjuta.

## Aste NA
URL: https://www.opiq.ee/kit/163/chapter/9194
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.3
Topics ET: matemaatika, aste, helirea, keskel, vares, vaga, linnukene, helitrepil, joonestikul
Topics RU: математика
Topics EN: mathematics
Headings: Aste NA; Helirea keskel; Vares, vaga linnukene; Aste NA helitrepil ja joonestikul; Laulud NA-astmega; Vainul, lombil
Task examples: Kas astmete vahel on pool- või tervetoon? Vali rippmenüüst õige vastus.; Märgi õiged vastused.

## Wolfgang Amadeus Mozart
URL: https://www.opiq.ee/kit/163/chapter/9178
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.4
Topics ET: matemaatika, wolfgang, amadeus, mozart, kaunilt, kõlab, ilus, hääl, täht, muusikataevas
Topics RU: математика
Topics EN: mathematics
Headings: Wolfgang Amadeus Mozart; Kui kaunilt see kõlab, kui ilus see hääl!; Ere täht muusikataevas; Sära, sära, täheke
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Aste DI
URL: https://www.opiq.ee/kit/163/chapter/9195
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.5
Topics ET: matemaatika, aste, alumine, naaber, sääsk, helitrepil, noodijoonestikul, miks, napid
Topics RU: математика
Topics EN: mathematics
Headings: Aste DI; JO alumine naaber; Sääsk; Helitrepil ja noodijoonestikul; Miks?; Minu napid teadmised siidiussidest
Task examples: Märgi õige tegelane. Mõtle, kuidas kõlab hääl looduses, ja kirjelda seda muusikaliste väljenditega, nagu näiteks piano, forte, crescendo, diminuendo, kõrge, madal, hele, tume.; Kirjuta sõnu, mis algavad DI-ga või sisaldavad tähti DI. Näiteks karDIn.

## Valss
URL: https://www.opiq.ee/kit/163/chapter/9180
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.6
Topics ET: matemaatika, valss, keeruta, lennuta, linalakk, neidu, tants, kolmeosalises, taktimõõdus
Topics RU: математика
Topics EN: mathematics
Headings: Valss; Keeruta, lennuta linalakk-neidu!; Tants kolmeosalises taktimõõdus; Tuntud valsid; Uisutajad; Labajalavalss; Edelweiss; Õnnitluskaanon
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Polka
URL: https://www.opiq.ee/kit/163/chapter/9181
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.7
Topics ET: matemaatika, polka, hiir, hüppas, kass, kargas, tants, kaheosalises, taktimõõdus
Topics RU: математика
Topics EN: mathematics
Headings: Polka; Hiir hüppas ja kass kargas!; Tants kaheosalises taktimõõdus; Tuntud polkad; Virulaste tants
Task examples: Märgi õiged vastused.

## JO-astmerida
URL: https://www.opiq.ee/kit/163/chapter/9196
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.8
Topics ET: matemaatika, astmerida, rõõmsa, kõlaga, helitrepp, aste, kõige, mängulaul
Topics RU: математика
Topics EN: mathematics
Headings: JO-astmerida; Rõõmsa kõlaga helitrepp; JO-aste kõige ees; Mängulaul
Task examples: Järjesta astmenimed JO-astmereaks.; Märgi astmepaarid, mille vahel on pooltoon.

## RA-astmerida
URL: https://www.opiq.ee/kit/163/chapter/9197
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 2.9
Topics ET: matemaatika, astmerida, nukra, kõlaga, helitrepp, uueks, teeb, utekesed
Topics RU: математика
Topics EN: mathematics
Headings: RA-astmerida; Nukra kõlaga helitrepp; Uni uueks teeb; Utu-utu, utekesed
Task examples: Järjesta astmenimed RA-astmereaks.; Kas kõlab pool- või tervetoon? Kuula helinäiteid ja märgi õige vastus.

## Lauluvara
URL: https://www.opiq.ee/kit/163/chapter/9198
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 3.1
Topics ET: matemaatika, aeg, kell, kalender, taim, taimed, puu, lill, aastaajad, kevad, suvi, sügis, talv, lauluvara, laula, suukene, liigu, linnukeelekene, mõlgu, marjameelekene, ilutse, südamekene
Topics RU: математика, время, часы, календарь, растение, растения, дерево, цветок, времена года, весна, лето, осень, зима
Topics EN: mathematics, time, clock, calendar, plant, plants, tree, flower, seasons, spring, summer, autumn, winter
Headings: Lauluvara; Laula, laula, suukene, liigu, linnukeelekene, mõlgu, marjameelekene, ilutse, südamekene!; Teele, teele, kurekesed!; Kunstnik sügis; Kinga-rock; Sügise tants; Laulud noodist; Indiaanlaste laul; Vana Texas; Laevuke läks merele; Aeg; Unistus on saladus; Hea kiik; Kiituselaul; Õnnista ja hoia; Ümmargune kuu; Kõnemäng; Hiir hüppas; Puukingatants; Väike pagar; Palgapäev; Haldjalugu; Pärlitest puu; Minu kullake; Linnurahva pulmatrall; Kevadpidu; Tuhat tänu; Ema ootab koju; Vahva vahtrapuu; Tantsulaul; Laula noodist; Mis algab, see lõpeb

## Laulude tähestikuline loetelu
URL: https://www.opiq.ee/kit/163/chapter/21911
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 3.2
Topics ET: matemaatika, laulude, tähestikuline, loetelu
Topics RU: математика
Topics EN: mathematics
Headings: Laulude tähestikuline loetelu; A – K; L – P; R – Ü

## Plokkflööt
URL: https://www.opiq.ee/kit/163/chapter/9199
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 3.3
Topics ET: matemaatika, plokkflööt, kümme, sõrme, tuhat, viisi, pilli, ehitus, plokkflöödi, mänguvõtted
Topics RU: математика
Topics EN: mathematics
Headings: Plokkflööt; Kümme sõrme, tuhat viisi; Pilli ehitus; Plokkflöödi mänguvõtted; Kui mina hakkan laulemaie; Tiiu, talutütrekene; Mäeküla taadi talu

## Kannel
URL: https://www.opiq.ee/kit/163/chapter/9200
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 3.4
Topics ET: matemaatika, kannel, kullakeeleline, pilli, ehitus, häälestus, mänguvõtted, kägu, uhti, uhkesti
Topics RU: математика
Topics EN: mathematics
Headings: Kannel; Kannel kullakeeleline ...; Pilli ehitus ja häälestus; Mänguvõtted; Kägu; Uhti, uhti uhkesti; Vainul, lombil; Linnurahva pulmatrall

## Mõisted
URL: https://www.opiq.ee/kit/163/chapter/9201
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 3.5
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/163/chapter/9202
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 3.6
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/163/chapter/19490
Book: Muusikaõpik 3. klassile – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile
Chapter ID: 3.7
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Muusikaõpik 3. klassile 2025 – Opiq
URL: https://www.opiq.ee/Kit/Details/592
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 158
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikaõpik 3. klassile 2025 – Opiq
URL: https://www.opiq.ee/Kit/Details/592
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 191
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Laul ja pill
URL: https://www.opiq.ee/kit/592/chapter/33403
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.1
Topics ET: matemaatika, aeg, kell, kalender, laul, pill, laula, hõiska, sest, laulu, käes, millest, koosneb
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Laul ja pill; Oh laula ja hõiska, sest laulu aeg on käes!; Millest laul koosneb?; Kui mina hakkan laulemaie; Kuidas laulu õppida?; Laul on pop!
Task examples: Mis pannakse kirja sõnade, mis nootidega? Jaota vastused kahte rühma.; Milliseid hääli oled sa kuulnud looduses suvel, sügisel, talvel, kevadel? Loetle.

## Mardi- ja kadrilaulud
URL: https://www.opiq.ee/kit/592/chapter/33412
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.10
Topics ET: matemaatika, mardi, kadrilaulud, olgõ, terve, pereesä, kadriko, õnne, maale, karjale
Topics RU: математика
Topics EN: mathematics
Headings: Mardi- ja kadrilaulud; Olgõ terve, pereesä, kadriko, kadriko!; Õnne maale ja karjale; Sisselaskmine; Õnne soovimine; Andide palumine; Tänamine ja soovid
Task examples: Millist õnne toovad kadrid, millist mardid? Lohista pildid õigesse veergu.; Millised soovid olid pererahval kadridele? Kuula või uuri laulusõnu ja ühenda paarid.

## Dünaamika
URL: https://www.opiq.ee/kit/592/chapter/33413
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.11
Topics ET: matemaatika, dünaamika, meelelaad, muusikas, kõlajõud, meie, ümber, lugu
Topics RU: математика
Topics EN: mathematics
Headings: Dünaamika; Meelelaad muusikas; Kõlajõud; Dünaamika meie ümber; Aja lugu
Task examples: Kuula helinäidet ja pane dünaamikamärgid õigesse järjekorda.; Kuula helinäiteid ja märgi õige dünaamika.

## Gustav Ernesaks
URL: https://www.opiq.ee/kit/592/chapter/33414
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.12
Topics ET: matemaatika, gustav, ernesaks, eesti, rahva, laulutaat, laulupidude, hing, kolm
Topics RU: математика
Topics EN: mathematics
Headings: Gustav Ernesaks; Eesti rahva laulutaat; Laulupidude hing; Kolm kihulast; Uhti, uhti uhkesti
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Aste JO'
URL: https://www.opiq.ee/kit/592/chapter/33415
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.13
Topics ET: matemaatika, aste, helirea, lõpp, algus, mängi, pillimees, helitrepil, joonestikul
Topics RU: математика
Topics EN: mathematics
Headings: Aste JO'; Helirea lõpp ja algus; Mängi, mängi, pillimees; Aste JO' helitrepil ja joonestikul; Rong juba saabub; Rütmirongid
Task examples: Millised JO-astmed kõlavad? Kuula heliridasid ja vali õige vastus.; Kuula helinäiteid ja järjesta käemärgid.

## Muusika esitajad
URL: https://www.opiq.ee/kit/592/chapter/33416
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.14
Topics ET: matemaatika, muusika, esitajad, hääle, pilliga, vokaal, instrumentaalmuusika, koosseisud, piltidel
Topics RU: математика
Topics EN: mathematics
Headings: Muusika esitajad; Hääle ja pilliga; Vokaal- ja instrumentaalmuusika; Koosseisud piltidel; Valik muusikanäiteid
Task examples: Sorteeri märksõnad kahte rühma.; Märgi loetelus ära pillid.

## Talvelaulud
URL: https://www.opiq.ee/kit/592/chapter/33417
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.15
Topics ET: matemaatika, talvelaulud, lumised, lood, esimene, lumi, tali, vihistab, jõululaul, jõulunukrus
Topics RU: математика
Topics EN: mathematics
Headings: Talvelaulud; Lumised lood; Esimene lumi; Tali; Las vihistab; Jõululaul; Jõulunukrus, jõulurõõm; Sa südames nüüd pane; Jõulukellad; Tuhat valgust; Aisakell; Metsas sirgus kuuseke; Uuel aastal; Jaanuar

## Kehapill
URL: https://www.opiq.ee/kit/592/chapter/33404
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.2
Topics ET: matemaatika, kehapill, ikka, kaasas, kehapilli, kõlad, rütm, muusika, rütmiharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kehapill; Ikka kaasas; Kehapilli kõlad; Rütm ja muusika; Rütmiharjutus kehapillile; Loomine
Task examples: Kuula helinäidet ja märgi, millised kehapillihelid kõlavad.; Uuri laulusõnu. Vali või märgi õige vastus.

## Noot
URL: https://www.opiq.ee/kit/592/chapter/33405
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.3
Topics ET: matemaatika, noot, vars, leht, noodipuul, noodipikkused, kõla, lahke, laulukaja
Topics RU: математика
Topics EN: mathematics
Headings: Noot; Vars ja leht noodipuul; Noodipikkused; Kõla, lahke laulukaja
Task examples: Vali rippmenüüst õige rütmisõna. Mõtle välja kaks uut võrdust.

## Taktimõõt
URL: https://www.opiq.ee/kit/592/chapter/33406
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.4
Topics ET: matemaatika, taktimõõt, mõõdab, löögid, taktidesse, kuidas, märkida, kivikasukas, tuttavate
Topics RU: математика
Topics EN: mathematics
Headings: Taktimõõt; Mõõdab löögid taktidesse; Kuidas märkida?; Kivikasukas; Tuttavate laulude rütmid; Kodu
Task examples: Kuula, loe ja mängi 2. klassis õpitud laulude rütmi. Kirjuta õige laulu pealkiri ning mitu lööki on taktis.; Kuula, loe ja mängi 2. klassis õpitud laulude rütmi. Kirjuta õige laulu pealkiri ning mitu lööki on taktis.

## Pausid
URL: https://www.opiq.ee/kit/592/chapter/33407
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.5
Topics ET: matemaatika, pausid, vaikus, muusika, pausi, tähised, kägu
Topics RU: математика
Topics EN: mathematics
Headings: Pausid; Vaikus on muusika; Pausi tähised; Kägu; Õpetaja
Task examples: Sorteeri pildid kahte rühma.; Ühenda omavahel võrdse pikkusega pausid ja noodid.

## Kaanon
URL: https://www.opiq.ee/kit/592/chapter/33408
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.6
Topics ET: matemaatika, kaanon, sepapoisid, lihtne, mitmehäälne, laul, tervituskaanon, rütmikaanon
Topics RU: математика
Topics EN: mathematics
Headings: Kaanon; Sepapoisid, sepapoisid ...; Lihtne mitmehäälne laul; Tervituskaanon; Rütmikaanon

## Improvisatsioon
URL: https://www.opiq.ee/kit/592/chapter/33409
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.7
Topics ET: matemaatika, improvisatsioon, kujutluspilt, saab, tõeks, hetkes, loomine, rütmi, karjapoisi, pasunalugu
Topics RU: математика
Topics EN: mathematics
Headings: Improvisatsioon; Kujutluspilt saab tõeks; Hetkes loomine; Rütmi-improvisatsioon; Karjapoisi pasunalugu; Imed

## Rütm TI-RI-TI-RI
URL: https://www.opiq.ee/kit/592/chapter/33410
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.8
Topics ET: matemaatika, rütm, jooksusammurütm, laul, vihmast, rütmid, kehapillil
Topics RU: математика
Topics EN: mathematics
Headings: Rütm TI-RI-TI-RI; Jooksusammurütm; Laul vihmast; TI-RI-TI-RI rütm; Rütmid kehapillil
Task examples: Jaota sõnad rütmi põhjal kahte rühma.; Loe ja plaksuta lausete rütmi ning reasta noodikaardid.

## Marss
URL: https://www.opiq.ee/kit/592/chapter/33411
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 1.9
Topics ET: matemaatika, marss, vasak, parem, ikka, taktis, astu, marsse, mitmesuguseid
Topics RU: математика
Topics EN: mathematics
Headings: Marss; Vasak, parem, vasak, parem, ikka taktis astu ...; Marsse on mitmesuguseid; Kuula marsimuusikat; Väike maailm; Mänguasjade rongkäik
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Rütm TA-I-RI
URL: https://www.opiq.ee/kit/592/chapter/33418
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, rütm, hüpperütm, kingsepa, tants, liisutus, käes
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Rütm TA-I-RI; Hüpperütm; Kingsepa tants; TA-I-RI; Liisutus; Käes on talv
Task examples: Kuula ja plaksuta helinäiteid ning järjesta rütmid.

## Miina Härma
URL: https://www.opiq.ee/kit/592/chapter/33427
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.10
Topics ET: matemaatika, miina, härma, mitte, vaiki, olla, lauluviisi, lõpeta, esimene, elukutseline
Topics RU: математика
Topics EN: mathematics
Headings: Miina Härma; Ei saa mitte vaiki olla, lauluviisi lõpeta’; Esimene elukutseline naishelilooja; Emakesele
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Eesti laulud
URL: https://www.opiq.ee/kit/592/chapter/33419
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.2
Topics ET: matemaatika, eesti, laulud, keeles, meeles, emakeel, isamaa, armas, süda, tuksub
Topics RU: математика
Topics EN: mathematics
Headings: Eesti laulud; Keeles ja meeles; Emakeel; Mu isamaa armas; Süda tuksub; Pill hüüdis pinu taga; Oksad oravaid täis; Vastlalaul; Tähemäng; Hea tuju kaanon; Kellalapsed; Päike ja mina; Kommimaa kuninga laul
Task examples: Tuleta meelde, milliseid eesti rahvapille sa tead. Märgi loetelus ainult rahvapillid.; Märgi õige vastus ja kirjuta.

## Aste NA
URL: https://www.opiq.ee/kit/592/chapter/33420
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.3
Topics ET: matemaatika, aste, helirea, keskel, vares, vaga, linnukene, helitrepil, joonestikul
Topics RU: математика
Topics EN: mathematics
Headings: Aste NA; Helirea keskel; Vares, vaga linnukene; Aste NA helitrepil ja joonestikul; Laulud NA-astmega; Vainul, lombil
Task examples: Kas astmete vahel on pool- või tervetoon? Vali rippmenüüst õige vastus.; Märgi õiged vastused.

## Wolfgang Amadeus Mozart
URL: https://www.opiq.ee/kit/592/chapter/33421
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.4
Topics ET: matemaatika, wolfgang, amadeus, mozart, kaunilt, kõlab, ilus, hääl, täht, muusikataevas
Topics RU: математика
Topics EN: mathematics
Headings: Wolfgang Amadeus Mozart; Kui kaunilt see kõlab, kui ilus see hääl!; Ere täht muusikataevas; Sära, sära, täheke
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Aste DI
URL: https://www.opiq.ee/kit/592/chapter/33422
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.5
Topics ET: matemaatika, aste, alumine, naaber, sääsk, helitrepil, noodijoonestikul, miks, napid
Topics RU: математика
Topics EN: mathematics
Headings: Aste DI; JO alumine naaber; Sääsk; Helitrepil ja noodijoonestikul; Miks?; Minu napid teadmised siidiussidest
Task examples: Märgi õige tegelane. Mõtle, kuidas kõlab hääl looduses, ja kirjelda seda muusikaliste väljenditega, nagu näiteks piano, forte, crescendo, diminuendo, kõrge, madal, hele, tume.; Kirjuta sõnu, mis algavad DI-ga või sisaldavad tähti DI. Näiteks karDIn.

## Valss
URL: https://www.opiq.ee/kit/592/chapter/33423
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.6
Topics ET: matemaatika, valss, keeruta, lennuta, linalakk, neidu, tants, kolmeosalises, taktimõõdus
Topics RU: математика
Topics EN: mathematics
Headings: Valss; Keeruta, lennuta linalakk-neidu!; Tants kolmeosalises taktimõõdus; Tuntud valsid; Uisutajad; Labajalavalss; Edelweiss; Õnnitluskaanon
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Polka
URL: https://www.opiq.ee/kit/592/chapter/33424
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.7
Topics ET: matemaatika, polka, hiir, hüppas, kass, kargas, tants, kaheosalises, taktimõõdus
Topics RU: математика
Topics EN: mathematics
Headings: Polka; Hiir hüppas ja kass kargas!; Tants kaheosalises taktimõõdus; Tuntud polkad; Virulaste tants
Task examples: Märgi õiged vastused.

## JO-astmerida
URL: https://www.opiq.ee/kit/592/chapter/33425
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.8
Topics ET: matemaatika, astmerida, rõõmsa, kõlaga, helitrepp, aste, kõige, mängulaul
Topics RU: математика
Topics EN: mathematics
Headings: JO-astmerida; Rõõmsa kõlaga helitrepp; JO-aste kõige ees; Mängulaul
Task examples: Järjesta astmenimed JO-astmereaks.; Märgi astmepaarid, mille vahel on pooltoon.

## RA-astmerida
URL: https://www.opiq.ee/kit/592/chapter/33426
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 2.9
Topics ET: matemaatika, astmerida, nukra, kõlaga, helitrepp, uueks, teeb, utekesed
Topics RU: математика
Topics EN: mathematics
Headings: RA-astmerida; Nukra kõlaga helitrepp; Uni uueks teeb; Utu-utu, utekesed
Task examples: Järjesta astmenimed RA-astmereaks.; Kas kõlab pool- või tervetoon? Kuula helinäiteid ja märgi õige vastus.

## Lauluvara
URL: https://www.opiq.ee/kit/592/chapter/33428
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 3.1
Topics ET: matemaatika, aeg, kell, kalender, taim, taimed, puu, lill, aastaajad, kevad, suvi, sügis, talv, lauluvara, laula, suukene, liigu, linnukeelekene, mõlgu, marjameelekene, ilutse, südamekene
Topics RU: математика, время, часы, календарь, растение, растения, дерево, цветок, времена года, весна, лето, осень, зима
Topics EN: mathematics, time, clock, calendar, plant, plants, tree, flower, seasons, spring, summer, autumn, winter
Headings: Lauluvara; Laula, laula, suukene, liigu, linnukeelekene, mõlgu, marjameelekene, ilutse, südamekene!; Teele, teele, kurekesed!; Kunstnik sügis; Kinga-rock; Sügise tants; Laulud noodist; Indiaanlaste laul; Vana Texas; Laevuke läks merele; Aeg; Unistus on saladus; Hea kiik; Kiituselaul; Õnnista ja hoia; Ümmargune kuu; Kõnemäng; Hiir hüppas; Puukingatants; Väike pagar; Palgapäev; Haldjalugu; Pärlitest puu; Minu kullake; Linnurahva pulmatrall; Kevadpidu; Tuhat tänu; Ema ootab koju; Vahva vahtrapuu; Tantsulaul; Laula noodist; Mis algab, see lõpeb

## Laulude tähestikuline loetelu
URL: https://www.opiq.ee/kit/592/chapter/33429
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 3.2
Topics ET: matemaatika, laulude, tähestikuline, loetelu
Topics RU: математика
Topics EN: mathematics
Headings: Laulude tähestikuline loetelu; A – K; L – P; R – Ü

## Plokkflööt
URL: https://www.opiq.ee/kit/592/chapter/33430
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 3.3
Topics ET: matemaatika, plokkflööt, kümme, sõrme, tuhat, viisi, pilli, ehitus, plokkflöödi, mänguvõtted
Topics RU: математика
Topics EN: mathematics
Headings: Plokkflööt; Kümme sõrme, tuhat viisi; Pilli ehitus; Plokkflöödi mänguvõtted; Kui mina hakkan laulemaie; Tiiu, talutütrekene; Mäeküla taadi talu

## Kannel
URL: https://www.opiq.ee/kit/592/chapter/33431
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 3.4
Topics ET: matemaatika, kannel, kullakeeleline, pilli, ehitus, häälestus, mänguvõtted, kägu, uhti, uhkesti
Topics RU: математика
Topics EN: mathematics
Headings: Kannel; Kannel kullakeeleline ...; Pilli ehitus ja häälestus; Mänguvõtted; Kägu; Uhti, uhti uhkesti; Vainul, lombil; Linnurahva pulmatrall

## Mõisted
URL: https://www.opiq.ee/kit/592/chapter/33432
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 3.5
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/592/chapter/33433
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 3.6
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/592/chapter/33434
Book: Muusikaõpik 3. klassile 2025 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_3._klassile_2025
Chapter ID: 3.7
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Музыка – волшебная страна. 3 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/239
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 192
Topics ET: matemaatika, opiq
Topics RU: математика, музыка, волшебная, страна, класс
Topics EN: mathematics

## Музыка – волшебная страна. 3 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/239
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 315
Topics ET: matemaatika, opiq
Topics RU: математика, музыка, волшебная, страна, класс
Topics EN: mathematics

## Здравствуй, дружок! Tere sõber!
URL: https://www.opiq.ee/kit/239/chapter/13560
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.1
Topics ET: matemaatika, tere, sõber
Topics RU: математика, здравствуй, дружок
Topics EN: mathematics
Headings: Здравствуй, дружок! Tere sõber!

## Звени, звонок
URL: https://www.opiq.ee/kit/239/chapter/13561
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, звени, звонок
Topics EN: mathematics
Headings: Звени, звонок

## Когда приходит утро
URL: https://www.opiq.ee/kit/239/chapter/13562
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, когда, приходит, утро
Topics EN: mathematics
Headings: Когда приходит утро
Task examples: Выполни задание в рабочей тетради. (с. 5) Вспомни правила пения и отметь верные варианты (x) крестиком (уч. с. 4). Для того, чтобы красиво петь, надо ...

## Пробуждальная песенка
URL: https://www.opiq.ee/kit/239/chapter/13563
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, пробуждальная, песенка
Topics EN: mathematics
Headings: Пробуждальная песенка
Task examples: Выполни задание в рабочей тетради. (с. 7) Исполни ритмы и узнай по ним песни, которые Ты выучил во втором классе. Соедини ритм с соответствующим названием песни.

## Marjuke
URL: https://www.opiq.ee/kit/239/chapter/13564
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.5
Topics ET: matemaatika, marjuke
Topics RU: математика
Topics EN: mathematics
Headings: Marjuke
Task examples: Выполни задание в рабочей тетради. (с. 8) Подпиши под ручными знаками названия ступеней. Спой ступени снизу вверх и обратно, показывая их рукой.

## Во кузнице
URL: https://www.opiq.ee/kit/239/chapter/13565
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, кузнице
Topics EN: mathematics
Headings: Во кузнице

## Samm ja plaks
URL: https://www.opiq.ee/kit/239/chapter/13566
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.7
Topics ET: matemaatika, samm, plaks
Topics RU: математика
Topics EN: mathematics
Headings: Samm ja plaks

## Mamma marakas
URL: https://www.opiq.ee/kit/239/chapter/13567
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 1.8
Topics ET: matemaatika, mamma, marakas
Topics RU: математика
Topics EN: mathematics
Headings: Mamma marakas
Task examples: Выполни задание в рабочей тетради. (с. 11) Подпиши названия ритмических инструментов. Опиши (устно) звучание каждого из них.

## Старый танец
URL: https://www.opiq.ee/kit/239/chapter/13641
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.1
Topics ET: matemaatika
Topics RU: математика, старый, танец
Topics EN: mathematics
Headings: Старый танец
Task examples: Выполни задание в рабочей тетради. (с. 103) Заполни пропуски.

## Зачем мальчишкам карманы?
URL: https://www.opiq.ee/kit/239/chapter/13650
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.10
Topics ET: matemaatika
Topics RU: математика, зачем, мальчишкам, карманы
Topics EN: mathematics
Headings: Зачем мальчишкам карманы?

## Полька
URL: https://www.opiq.ee/kit/239/chapter/13642
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.2
Topics ET: matemaatika
Topics RU: математика, полька
Topics EN: mathematics
Headings: Полька

## Laulge, poisid!
URL: https://www.opiq.ee/kit/239/chapter/13643
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.3
Topics ET: matemaatika, laulge, poisid
Topics RU: математика
Topics EN: mathematics
Headings: Laulge, poisid!
Task examples: Выполни задание в рабочей тетради. (с. 105) Подпиши под нотами названия ступеней. Сочини ритм в соответствии с размером такта. Спой мелодию с названием ступеней, показывая их рукой.

## За рекою старый дом
URL: https://www.opiq.ee/kit/239/chapter/13644
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.4
Topics ET: matemaatika
Topics RU: математика, рекою, старый, иоганн, себастьян
Topics EN: mathematics
Headings: За рекою старый дом; Иоганн Себастьян Бах

## Менуэт
URL: https://www.opiq.ee/kit/239/chapter/13645
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.5
Topics ET: matemaatika
Topics RU: математика, менуэт
Topics EN: mathematics
Headings: Менуэт
Task examples: Выполни задание в рабочей тетради. (с. 107) Запиши слова, передающие характер музыки И. С. Баха.

## Пастушка
URL: https://www.opiq.ee/kit/239/chapter/13646
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.6
Topics ET: matemaatika
Topics RU: математика, пастушка
Topics EN: mathematics
Headings: Пастушка

## Песня ввысь летит
URL: https://www.opiq.ee/kit/239/chapter/13647
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.7
Topics ET: matemaatika
Topics RU: математика, песня, ввысь, летит
Topics EN: mathematics
Headings: Песня ввысь летит

## Весёлый вальс
URL: https://www.opiq.ee/kit/239/chapter/13648
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.8
Topics ET: matemaatika
Topics RU: математика, вальс
Topics EN: mathematics
Headings: Весёлый вальс

## Hei, vallerii
URL: https://www.opiq.ee/kit/239/chapter/13649
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 10.9
Topics ET: matemaatika, vallerii
Topics RU: математика
Topics EN: mathematics
Headings: Hei, vallerii
Task examples: Выполни задание в рабочей тетради. (с. 111) Запиши мелодию в ритме слов. Выучи песню. Спойте её в каноне.

## Нарядная песенка
URL: https://www.opiq.ee/kit/239/chapter/13651
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.1
Topics ET: matemaatika
Topics RU: математика, нарядная, песенка
Topics EN: mathematics
Headings: Нарядная песенка

## Kevade ootel
URL: https://www.opiq.ee/kit/239/chapter/13652
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.2
Topics ET: matemaatika, kevade, ootel
Topics RU: математика
Topics EN: mathematics
Headings: Kevade ootel
Task examples: Выполни задание в рабочей тетради. (с.115) Раздели мелодии на такты. Напиши под нотами названия ступеней. Выучи обе партии. Спойте упражнение двухголосно.

## Птичка
URL: https://www.opiq.ee/kit/239/chapter/13653
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.3
Topics ET: matemaatika
Topics RU: математика, птичка
Topics EN: mathematics
Headings: Птичка
Task examples: Соедини части предложений.

## Гуси прилетели
URL: https://www.opiq.ee/kit/239/chapter/13654
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.4
Topics ET: matemaatika
Topics RU: математика, гуси, прилетели
Topics EN: mathematics
Headings: Гуси прилетели

## Хорошо бы нам узнать
URL: https://www.opiq.ee/kit/239/chapter/13655
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.5
Topics ET: matemaatika
Topics RU: математика, хорошо, узнать
Topics EN: mathematics
Headings: Хорошо бы нам узнать
Task examples: Выполни задание в рабочей тетради. (с. 118) Раздели ритмы на такты. Исполните с соседом по парте ритмы с одинаковым размером такта одновременно на разных инструментах.

## Kevadpidu
URL: https://www.opiq.ee/kit/239/chapter/13656
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.6
Topics ET: matemaatika, kevadpidu
Topics RU: математика
Topics EN: mathematics
Headings: Kevadpidu

## Деньки стоят погожие
URL: https://www.opiq.ee/kit/239/chapter/13657
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.7
Topics ET: matemaatika
Topics RU: математика, деньки, стоят, погожие
Topics EN: mathematics
Headings: Деньки стоят погожие
Task examples: Выполни задание в рабочей тетради. (с. 120) Придумай и запиши ступени к ритму первого четверостишия стихотворения Сергея Есенина «Пасхальный благовест». Запиши мелодию на нотоносце и спой с ней всё стихотворение.

## Молитва
URL: https://www.opiq.ee/kit/239/chapter/13658
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 11.8
Topics ET: matemaatika
Topics RU: математика, молитва
Topics EN: mathematics
Headings: Молитва

## Сказка – ярмарка чудес
URL: https://www.opiq.ee/kit/239/chapter/13659
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 12.1
Topics ET: matemaatika
Topics RU: математика, сказка, ярмарка, чудес
Topics EN: mathematics
Headings: Сказка – ярмарка чудес
Task examples: Выполни задание в рабочей тетради. Нарисуй картинку к музыке Раймо Кангро «Как всё же Золушка прекрасна!»

## Весенняя
URL: https://www.opiq.ee/kit/239/chapter/13660
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 12.2
Topics ET: matemaatika
Topics RU: математика, весенняя, вольфганг, амадей, моцарт
Topics EN: mathematics
Headings: Весенняя; Вольфганг Амадей Моцарт
Task examples: Выполни задание в рабочей тетради. (с. 125) Прослушай и опиши музыку «Турецкого марша» Вольфганга Амадея Моцарта. Тебе помогут слова в овалах.

## Das klinget so herrlich
URL: https://www.opiq.ee/kit/239/chapter/13661
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 12.3
Topics ET: matemaatika, klinget, herrlich
Topics RU: математика
Topics EN: mathematics
Headings: Das klinget so herrlich

## Лунный кораблик
URL: https://www.opiq.ee/kit/239/chapter/13662
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 12.4
Topics ET: matemaatika
Topics RU: математика, лунный, кораблик
Topics EN: mathematics
Headings: Лунный кораблик

## Ilus elu
URL: https://www.opiq.ee/kit/239/chapter/13663
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 12.5
Topics ET: matemaatika, ilus
Topics RU: математика
Topics EN: mathematics
Headings: Ilus elu
Task examples: Выбери все верные ответы.

## Золотой ключик
URL: https://www.opiq.ee/kit/239/chapter/13664
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 12.6
Topics ET: matemaatika
Topics RU: математика, золотой, ключик, ильич, чайковский
Topics EN: mathematics
Headings: Золотой ключик; Пётр Ильич Чайковский
Task examples: Выполни задание в рабочей тетради. (с. 133) Запиши мелодию на нотоносце. Спой её на слоге «ду» вместе с ритмическим аккомпанементом.

## Песня о братьях меньших
URL: https://www.opiq.ee/kit/239/chapter/13665
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 13.1
Topics ET: matemaatika
Topics RU: математика, песня, братьях, меньших
Topics EN: mathematics
Headings: Песня о братьях меньших

## Sipsik
URL: https://www.opiq.ee/kit/239/chapter/13666
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 13.2
Topics ET: matemaatika, sipsik
Topics RU: математика
Topics EN: mathematics
Headings: Sipsik

## Жеребёнок рыжий
URL: https://www.opiq.ee/kit/239/chapter/13667
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 13.3
Topics ET: matemaatika
Topics RU: математика, жереб, рыжий
Topics EN: mathematics
Headings: Жеребёнок рыжий
Task examples: Выполни задание в рабочей тетради. (с. 136) Заполни пропуски.

## Будьте добры!
URL: https://www.opiq.ee/kit/239/chapter/13668
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 13.4
Topics ET: matemaatika
Topics RU: математика, будьте, добры
Topics EN: mathematics
Headings: Будьте добры!

## Капли и море
URL: https://www.opiq.ee/kit/239/chapter/13669
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 14.1
Topics ET: matemaatika
Topics RU: математика, капли, море
Topics EN: mathematics
Headings: Капли и море
Task examples: Выполни задание в рабочей тетради. (с. 141) Напиши сообщение о музыкальном спектакле, который ты посетил.

## Konnad
URL: https://www.opiq.ee/kit/239/chapter/13670
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 14.2
Topics ET: matemaatika, konnad
Topics RU: математика, арво, пярт
Topics EN: mathematics
Headings: Konnad; Арво Пярт
Task examples: Выполни задание в рабочей тетради. (с. 142) Запиши и спой мелодию с названием ступеней. Исполните её в каноне.

## Кукушка
URL: https://www.opiq.ee/kit/239/chapter/13671
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 14.3
Topics ET: matemaatika
Topics RU: математика, кукушка
Topics EN: mathematics
Headings: Кукушка
Task examples: Выполни задание в рабочей тетради. (с. 143) Зачеркни слово, которое не подходит в колонку. Придумай название для каждой группы.

## Любитель-рыболов
URL: https://www.opiq.ee/kit/239/chapter/13672
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 14.4
Topics ET: matemaatika
Topics RU: математика, любитель, рыболов
Topics EN: mathematics
Headings: Любитель-рыболов
Task examples: Выполни задание в рабочей тетради. (с. 144) Допиши мелодию и спой её с сопровождением.

## Süda tuksub
URL: https://www.opiq.ee/kit/239/chapter/13673
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 14.5
Topics ET: matemaatika, süda, tuksub
Topics RU: математика
Topics EN: mathematics
Headings: Süda tuksub

## Лесные бусы
URL: https://www.opiq.ee/kit/239/chapter/13674
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 15.1
Topics ET: matemaatika
Topics RU: математика, лесные, бусы
Topics EN: mathematics
Headings: Лесные бусы
Task examples: Выполни задание в рабочей тетради. (с. 146) Запиши названия городов Эстонии в соответствии с ритмом.

## Vanaema
URL: https://www.opiq.ee/kit/239/chapter/13675
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 15.2
Topics ET: matemaatika, vanaema
Topics RU: математика
Topics EN: mathematics
Headings: Vanaema

## Добрая сказка
URL: https://www.opiq.ee/kit/239/chapter/13676
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 15.3
Topics ET: matemaatika
Topics RU: математика, добрая, сказка
Topics EN: mathematics
Headings: Добрая сказка

## Koolitöö lõpeb
URL: https://www.opiq.ee/kit/239/chapter/13677
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 15.4
Topics ET: matemaatika, koolitöö, lõpeb
Topics RU: математика
Topics EN: mathematics
Headings: Koolitöö lõpeb
Task examples: Выполни задание в рабочей тетради. (с. 150) Спой отрывки мелодий. Определи название произведения и запиши соответствующий номер. Запиши фамилию композитора.

## Песенка львёнка и черепахи
URL: https://www.opiq.ee/kit/239/chapter/13678
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 15.5
Topics ET: matemaatika
Topics RU: математика, песенка, черепахи
Topics EN: mathematics
Headings: Песенка львёнка и черепахи

## Круглая песня
URL: https://www.opiq.ee/kit/239/chapter/13679
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 15.6
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка, круглая, песня
Topics EN: mathematics, revision, review, practice
Headings: Круглая песня; ПОВТОРЕНИЕ
Task examples: Выполни задание в рабочей тетради. (с. 153) Раздели ритм на такты и исполни его на инструменте.; Выполни задание в рабочей тетради. (с. 154) Запиши фамилию и профессию человека.

## Mõisted
URL: https://www.opiq.ee/kit/239/chapter/13680
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 16.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/239/chapter/13681
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 16.2
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Осенняя песенка
URL: https://www.opiq.ee/kit/239/chapter/13568
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, осенняя, песенка
Topics EN: mathematics
Headings: Осенняя песенка

## Mängulaul
URL: https://www.opiq.ee/kit/239/chapter/13577
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.10
Topics ET: matemaatika, mängulaul
Topics RU: математика
Topics EN: mathematics
Headings: Mängulaul
Task examples: Выполни задание в рабочей тетради. (с. 21) Запиши мелодию на нотоносце. Спой песню с названием ступеней и со словами.

## Sügis käes
URL: https://www.opiq.ee/kit/239/chapter/13569
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, käes
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Sügis käes

## Песенка о зонтиках
URL: https://www.opiq.ee/kit/239/chapter/13570
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, песенка, зонтиках
Topics EN: mathematics
Headings: Песенка о зонтиках
Task examples: Выполни задание в рабочей тетради. (с. 15) Сочини мелодию к стихотворению «Осень» (с. 12 в учебнике): определи и запиши размер такта; сочини и запиши под ритмом названия ступеней. Запиши мелодию на нотоносце. Спой песню.

## Vihma sajab
URL: https://www.opiq.ee/kit/239/chapter/13571
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.4
Topics ET: matemaatika, vihma, sajab
Topics RU: математика
Topics EN: mathematics
Headings: Vihma sajab

## Mardilaul
URL: https://www.opiq.ee/kit/239/chapter/13572
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.5
Topics ET: matemaatika, mardilaul
Topics RU: математика
Topics EN: mathematics
Headings: Mardilaul
Task examples: Выполни задание в рабочей тетради. (с. 16) Заполни пропуски.

## Песня пастушка
URL: https://www.opiq.ee/kit/239/chapter/13573
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, песня, пастушка
Topics EN: mathematics
Headings: Песня пастушка

## Kadrilaul
URL: https://www.opiq.ee/kit/239/chapter/13574
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.7
Topics ET: matemaatika, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kadrilaul
Task examples: Выполни задание в рабочей тетради. (с. 18) Запиши мелодию на нотоносце. Спой её в каноне с названием ступеней и со словами.

## Листья-парашюты
URL: https://www.opiq.ee/kit/239/chapter/13575
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, листья, парашюты
Topics EN: mathematics
Headings: Листья-парашюты; ЛИСТЬЯ – ПАРАШЮТЫ

## Тeele, teele, kurekesed!
URL: https://www.opiq.ee/kit/239/chapter/13576
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 2.9
Topics ET: matemaatika, teele, kurekesed
Topics RU: математика
Topics EN: mathematics
Headings: Тeele, teele, kurekesed!

## В хороводе были мы
URL: https://www.opiq.ee/kit/239/chapter/13578
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, хороводе, были, балалайки, оркестра
Topics EN: mathematics
Headings: В хороводе были мы; От балалайки до оркестра
Task examples: Выполни задание в рабочей тетради. (с. 22) Раздели мелодию на такты и спой её с названием ступеней. Спойте мелодию в каноне на разных слогах («па», «ри», «мо» и др.).

## Пойду ль я, выйду ль я
URL: https://www.opiq.ee/kit/239/chapter/13587
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.10
Topics ET: matemaatika
Topics RU: математика, пойду, выйду
Topics EN: mathematics
Headings: Пойду ль я, выйду ль я
Task examples: Выполни задание в рабочей тетради. (с. 33) Найди и обведи названия 9 известных тебе русских народных инструментов. Охарактеризуй их звучание.

## Мужик на гармонике играет
URL: https://www.opiq.ee/kit/239/chapter/13588
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.11
Topics ET: matemaatika
Topics RU: математика, мужик, гармонике, играет
Topics EN: mathematics
Headings: Мужик на гармонике играет

## Ай, чу-чу!
URL: https://www.opiq.ee/kit/239/chapter/13589
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.12
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ай, чу-чу!; АЙ, ЧУ–ЧУ!
Task examples: Выполни задание в рабочей тетради. (с. 35) Запиши ритм слов загадки. Разгадай её и запиши отгадку на русском и эстонском языках. Спой песенку.

## Закличка солнышка
URL: https://www.opiq.ee/kit/239/chapter/13579
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, закличка, солнышка
Topics EN: mathematics
Headings: Закличка солнышка

## Слон и скрипочка
URL: https://www.opiq.ee/kit/239/chapter/13580
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, слон, скрипочка
Topics EN: mathematics
Headings: Слон и скрипочка

## Добрый мельник
URL: https://www.opiq.ee/kit/239/chapter/13581
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, добрый, мельник
Topics EN: mathematics
Headings: Добрый мельник

## Как в лесу, лесу, лесочке
URL: https://www.opiq.ee/kit/239/chapter/13582
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, лесу, лесочке
Topics EN: mathematics
Headings: Как в лесу, лесу, лесочке
Task examples: Выполни задание в рабочей тетради. (с. 27) Разгадай ритмический кроссворд – расставь длительности так, чтобы по вертикали и по горизонтали в сумме получалось три ТА (.I).

## Андрей-воробей
URL: https://www.opiq.ee/kit/239/chapter/13583
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.6
Topics ET: matemaatika, kiigelaul
Topics RU: математика, андрей, воробей, сыграй, блок, флейте
Topics EN: mathematics
Headings: Андрей-воробей; Сыграй на блок-флейте; АНДРЕЙ–ВОРОБЕЙ; KIIGELAUL
Task examples: Выполни задание в рабочей тетради. (с. 28) Запиши мелодию на нотоносце. Спой её с названием ступеней и сыграй на блок-флейте.

## А я по лугу
URL: https://www.opiq.ee/kit/239/chapter/13584
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.7
Topics ET: matemaatika
Topics RU: математика, лугу
Topics EN: mathematics
Headings: А я по лугу

## Kägu
URL: https://www.opiq.ee/kit/239/chapter/13585
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.8
Topics ET: matemaatika, kägu
Topics RU: математика, зайка
Topics EN: mathematics
Headings: Kägu; ЗАЙКА

## Перепёлка
URL: https://www.opiq.ee/kit/239/chapter/13586
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 3.9
Topics ET: matemaatika
Topics RU: математика, переп
Topics EN: mathematics
Headings: Перепёлка

## Это очень интересно
URL: https://www.opiq.ee/kit/239/chapter/13590
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, очень, интересно
Topics EN: mathematics
Headings: Это очень интересно
Task examples: Выполни задание в рабочей тетради. (с. 37) Сочини и запиши мелодию загадки. Разгадай её и запиши отгадку на русском и эстонском языках. Спой песенку.

## Дети любят рисовать
URL: https://www.opiq.ee/kit/239/chapter/13591
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, дети, любят, рисовать
Topics EN: mathematics
Headings: Дети любят рисовать
Task examples: Выполни задание в рабочей тетради. (с. 39) Изобрази в рисунке песню «Дети любят рисовать».

## Козёл-парикмахер
URL: https://www.opiq.ee/kit/239/chapter/13592
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, парикмахер
Topics EN: mathematics
Headings: Козёл-парикмахер

## Nädalapäevade laul
URL: https://www.opiq.ee/kit/239/chapter/13593
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.4
Topics ET: matemaatika, nädalapäevade, laul
Topics RU: математика
Topics EN: mathematics
Headings: Nädalapäevade laul
Task examples: Выполни задание в рабочей тетради. (с. 41) Допиши названия дней недели на русском и эстонском языках. Простучи и запиши рядом со словом его ритм. Выпиши повторяющиеся ритмы.

## Хорошо бы!
URL: https://www.opiq.ee/kit/239/chapter/13594
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, хорошо
Topics EN: mathematics
Headings: Хорошо бы!
Task examples: Выполни задание в рабочей тетради. (с. 43) Сочини мелодию к стихотворению на с. 43. Запиши под ритмом названия ступеней. Запиши мелодию на нотоносце и спой её с названием ступеней. Исполни свою песенку.

## Naerutants
URL: https://www.opiq.ee/kit/239/chapter/13595
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.6
Topics ET: matemaatika, naerutants
Topics RU: математика
Topics EN: mathematics
Headings: Naerutants
Task examples: Выполни задание в рабочей тетради. (с. 44) Сосчитай и запиши ответы. Простучи ритм.

## Если был бы я девчонкой
URL: https://www.opiq.ee/kit/239/chapter/13596
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика, если, девчонкой
Topics EN: mathematics
Headings: Если был бы я девчонкой

## Kivikasukas
URL: https://www.opiq.ee/kit/239/chapter/13597
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 4.8
Topics ET: matemaatika, kivikasukas
Topics RU: математика
Topics EN: mathematics
Headings: Kivikasukas
Task examples: Выполни задание в рабочей тетради. (с. 47) Допиши мелодию в ритме слов. Спой частушку.

## Зимняя сказка
URL: https://www.opiq.ee/kit/239/chapter/13598
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, зимняя, сказка
Topics EN: mathematics
Headings: Зимняя сказка
Task examples: Выполни задание в рабочей тетради. (с. 49) Запиши ступени на нотоносце. Сочини слова и спой песенку.

## Meeril oli talleke
URL: https://www.opiq.ee/kit/239/chapter/13599
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 5.2
Topics ET: matemaatika, meeril, talleke
Topics RU: математика
Topics EN: mathematics
Headings: Meeril oli talleke
Task examples: Запиши, к каким понятиям относятся эти значения.

## Radi-ridi ralla
URL: https://www.opiq.ee/kit/239/chapter/13600
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 5.3
Topics ET: matemaatika, radi, ridi, ralla
Topics RU: математика
Topics EN: mathematics
Headings: Radi-ridi ralla

## Снеговик
URL: https://www.opiq.ee/kit/239/chapter/13601
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, снеговик
Topics EN: mathematics
Headings: Снеговик
Task examples: Выполни задание в рабочей тетради. (с. 55) Слушай музыку. Нарисуй картинку зимы.

## Рождество
URL: https://www.opiq.ee/kit/239/chapter/13602
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, рождество
Topics EN: mathematics
Headings: Рождество

## Jõulud jõudvad
URL: https://www.opiq.ee/kit/239/chapter/13603
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.2
Topics ET: matemaatika, jõulud, jõudvad
Topics RU: математика
Topics EN: mathematics
Headings: Jõulud jõudvad
Task examples: Выполни задание в рабочей тетради. (с. 59) Раздели ритм на такты и исполни его на пластиночном инструменте.

## Pagari piparkook
URL: https://www.opiq.ee/kit/239/chapter/13604
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.3
Topics ET: matemaatika, pagari, piparkook
Topics RU: математика
Topics EN: mathematics
Headings: Pagari piparkook

## Снежинкина сестричка
URL: https://www.opiq.ee/kit/239/chapter/13605
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.4
Topics ET: matemaatika
Topics RU: математика, снежинкина, сестричка
Topics EN: mathematics
Headings: Снежинкина сестричка
Task examples: Выполни задание в рабочей тетради. (с. 61) Заполни пустые такты и спой частушку со словами.

## Oh, jõulupuu
URL: https://www.opiq.ee/kit/239/chapter/13606
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.5
Topics ET: matemaatika, jõulupuu
Topics RU: математика
Topics EN: mathematics
Headings: Oh, jõulupuu

## Jõuluõhtul
URL: https://www.opiq.ee/kit/239/chapter/13607
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.6
Topics ET: matemaatika, kordamine, korda, harjutan, jõuluõhtul
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Jõuluõhtul; Повторение

## Тоома laulukoor
URL: https://www.opiq.ee/kit/239/chapter/13608
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.7
Topics ET: matemaatika, laulukoor
Topics RU: математика, тоома
Topics EN: mathematics
Headings: Тоома laulukoor
Task examples: Выполни задание в рабочей тетради. (с. 65) Соедини рифмующиеся слова.

## Läbi öö
URL: https://www.opiq.ee/kit/239/chapter/13609
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.8
Topics ET: matemaatika, läbi
Topics RU: математика
Topics EN: mathematics
Headings: Läbi öö

## Tiliseb, tiliseb aisakell
URL: https://www.opiq.ee/kit/239/chapter/13610
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 6.9
Topics ET: matemaatika, tiliseb, aisakell
Topics RU: математика
Topics EN: mathematics
Headings: Tiliseb, tiliseb aisakell
Task examples: Выполни задание в рабочей тетради. (с. 67) Сочини ритм и исполни его на ксилофоне.

## Приходят в гости
URL: https://www.opiq.ee/kit/239/chapter/13611
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.1
Topics ET: matemaatika
Topics RU: математика, приходят, гости, песни
Topics EN: mathematics
Headings: Приходят в гости; ПРИХОДЯТ В ГОСТИ ПЕСНИ
Task examples: Выполни задание в рабочей тетради.

## Пряха
URL: https://www.opiq.ee/kit/239/chapter/13620
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.10
Topics ET: matemaatika
Topics RU: математика, пряха
Topics EN: mathematics
Headings: Пряха
Task examples: Выполни задание в рабочей тетради. (с. 79) Сочини мелодию к стихотворению со с. 77 в учебнике. Раздели ритм на такты и подпиши ступени. Запиши мелодию на нотоносце. Спой песню.

## Raa-rii-raa
URL: https://www.opiq.ee/kit/239/chapter/13621
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.11
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Raa-rii-raa

## Маленький почтальон
URL: https://www.opiq.ee/kit/239/chapter/13622
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.12
Topics ET: matemaatika
Topics RU: математика, маленький, почтальон
Topics EN: mathematics
Headings: Маленький почтальон
Task examples: Выполни задание в рабочей тетради. (с. 81) Раздели упражнение на такты и исполни его вместе с другом. Придумайте вместе новое упражнение. Запишите и исполните его на телоинструменте.

## Kaks sammu sissepoole
URL: https://www.opiq.ee/kit/239/chapter/13623
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.13
Topics ET: matemaatika, kaks, sammu, sissepoole
Topics RU: математика
Topics EN: mathematics
Headings: Kaks sammu sissepoole

## Me lähme rukist lõikama
URL: https://www.opiq.ee/kit/239/chapter/13624
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.14
Topics ET: matemaatika, lähme, rukist, lõikama
Topics RU: математика
Topics EN: mathematics
Headings: Me lähme rukist lõikama
Task examples: Выполни задание в рабочей тетради. (с. 83) Найди и обведи жанры вокальной музыки.

## К радости
URL: https://www.opiq.ee/kit/239/chapter/13625
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.15
Topics ET: matemaatika
Topics RU: математика, радости, людвиг, бетховен
Topics EN: mathematics
Headings: К радости; Людвиг ван Бетховен

## Малиновка
URL: https://www.opiq.ee/kit/239/chapter/13626
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.16
Topics ET: matemaatika
Topics RU: математика, малиновка
Topics EN: mathematics
Headings: Малиновка
Task examples: Выполни задание в рабочей тетради. с. 85) Заполни пропуски.

## Марш слона
URL: https://www.opiq.ee/kit/239/chapter/13627
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.17
Topics ET: matemaatika
Topics RU: математика, марш, слона
Topics EN: mathematics
Headings: Марш слона

## Lähme, lapsed
URL: https://www.opiq.ee/kit/239/chapter/13628
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.18
Topics ET: matemaatika, lähme, lapsed
Topics RU: математика
Topics EN: mathematics
Headings: Lähme, lapsed
Task examples: Выполни задание в рабочей тетради. (С. 87) Сравни музыку двух маршей. Какими словами можешь их описать?

## Марш деревянных солдатиков
URL: https://www.opiq.ee/kit/239/chapter/13629
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.19
Topics ET: matemaatika
Topics RU: математика, марш, деревянных, солдатиков, виктор, лунин
Topics EN: mathematics
Headings: Марш деревянных солдатиков; Виктор Лунин
Task examples: Выполни задание в рабочей тетради. (с. 89) Раздели отрывки мелодий на такты. Спой их с названием ступеней и отгадай песни ( с. 81–89). Запиши названия песен, исполни их.

## Мы дружим с музыкой
URL: https://www.opiq.ee/kit/239/chapter/13612
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.2
Topics ET: matemaatika
Topics RU: математика, дружим, музыкой, йозеф, гайдн
Topics EN: mathematics
Headings: Мы дружим с музыкой; Йозеф Гайдн
Task examples: Выполни задание в рабочей тетради. (с. 70) Заполни пропуски.

## Музыканты
URL: https://www.opiq.ee/kit/239/chapter/13613
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.3
Topics ET: matemaatika
Topics RU: математика, музыканты
Topics EN: mathematics
Headings: Музыканты

## Nooditundja
URL: https://www.opiq.ee/kit/239/chapter/13614
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.4
Topics ET: matemaatika, nooditundja
Topics RU: математика
Topics EN: mathematics
Headings: Nooditundja
Task examples: Выполни задание в рабочей тетради. (с. 73) Зачеркни слова, которые не относятся к выразительным средствам музыки.

## Шар земной
URL: https://www.opiq.ee/kit/239/chapter/13615
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.5
Topics ET: matemaatika
Topics RU: математика, земной
Topics EN: mathematics
Headings: Шар земной

## Ninna nanna
URL: https://www.opiq.ee/kit/239/chapter/13616
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.6
Topics ET: matemaatika, ninna, nanna
Topics RU: математика
Topics EN: mathematics
Headings: Ninna nanna

## Старинная французская песенка
URL: https://www.opiq.ee/kit/239/chapter/13617
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.7
Topics ET: matemaatika
Topics RU: математика, старинная, французская, песенка
Topics EN: mathematics
Headings: Старинная французская песенка
Task examples: Выполни задание в рабочей тетради. (с. 76) Раздели мелодию на такты и напиши над нотами названия ступеней. Придумай ещё одну строку слов. Спой колыбельную песенку.

## Пастушья песня
URL: https://www.opiq.ee/kit/239/chapter/13618
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.8
Topics ET: matemaatika
Topics RU: математика, пастушья, песня
Topics EN: mathematics
Headings: Пастушья песня

## Кetramas
URL: https://www.opiq.ee/kit/239/chapter/13619
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 7.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Кetramas

## Когда мои друзья со мной
URL: https://www.opiq.ee/kit/239/chapter/13630
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 8.1
Topics ET: matemaatika
Topics RU: математика, когда, друзья, мной
Topics EN: mathematics
Headings: Когда мои друзья со мной
Task examples: Выполни задание в рабочей тетради. (с. 91) Найди пары и соедини их.

## Laul sõprusest
URL: https://www.opiq.ee/kit/239/chapter/13631
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 8.2
Topics ET: matemaatika, laul, sõprusest
Topics RU: математика
Topics EN: mathematics
Headings: Laul sõprusest

## Без друзей никак нельзя
URL: https://www.opiq.ee/kit/239/chapter/13632
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 8.3
Topics ET: matemaatika
Topics RU: математика, друзей, никак, нельзя
Topics EN: mathematics
Headings: Без друзей никак нельзя

## Šooder
URL: https://www.opiq.ee/kit/239/chapter/13633
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 8.4
Topics ET: matemaatika, šooder
Topics RU: математика
Topics EN: mathematics
Headings: Šooder
Task examples: Выполни задание в рабочей тетради. (с. 94) Запиши под нотами названия ступеней. Спой мелодии и определи по ним песни (с. 30–77). Запиши название песни и определи ее родину, расставь соответствующие цифры.

## Tule sõbraks
URL: https://www.opiq.ee/kit/239/chapter/13634
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 8.5
Topics ET: matemaatika, tule, sõbraks
Topics RU: математика
Topics EN: mathematics
Headings: Tule sõbraks

## Mu isamaa, mu õnn ja rõõm
URL: https://www.opiq.ee/kit/239/chapter/13635
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 8.6
Topics ET: matemaatika, isamaa, rõõm
Topics RU: математика
Topics EN: mathematics
Headings: Mu isamaa, mu õnn ja rõõm

## Koduvärvid
URL: https://www.opiq.ee/kit/239/chapter/13636
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 8.7
Topics ET: matemaatika, koduvärvid
Topics RU: математика
Topics EN: mathematics
Headings: Koduvärvid

## Потанцуй со мной, дружок
URL: https://www.opiq.ee/kit/239/chapter/13637
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 9.1
Topics ET: matemaatika
Topics RU: математика, потанцуй, мной, дружок
Topics EN: mathematics
Headings: Потанцуй со мной, дружок; ПОТАНЦУЙ СО МНОЙ, ДРУЖОК!
Task examples: Выполни задание в рабочей тетради. (c. 98) Запиши ступени на нотоносце. Спой мелодию с названием ступеней. Сочини куплеты до конца и исполни песенку со словами.

## Каеra-jaan
URL: https://www.opiq.ee/kit/239/chapter/13638
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 9.2
Topics ET: matemaatika, jaan
Topics RU: математика
Topics EN: mathematics
Headings: Каеra-jaan

## Не щебечи, соловейку
URL: https://www.opiq.ee/kit/239/chapter/13639
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 9.3
Topics ET: matemaatika
Topics RU: математика, щебечи, соловейку
Topics EN: mathematics
Headings: Не щебечи, соловейку

## Плясовая
URL: https://www.opiq.ee/kit/239/chapter/13640
Book: Музыка – волшебная страна. 3 класс – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._3_класс
Chapter ID: 9.4
Topics ET: matemaatika
Topics RU: математика, плясовая
Topics EN: mathematics
Headings: Плясовая
Task examples: Выполни задание в рабочей тетради.
