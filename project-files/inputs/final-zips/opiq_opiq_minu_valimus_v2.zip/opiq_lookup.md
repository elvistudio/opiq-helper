## Inimeseõpetus 3. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/281
Book: Minu välimus
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 101
Topics ET: matemaatika, inimeseõpetus, klassile, lihtsustatud, õppekava, opiq
Topics RU: математика
Topics EN: mathematics

## Minu välimus
URL: https://www.opiq.ee/kit/281/chapter/15779
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.1
Topics ET: matemaatika, välimus, harjuta, vaata, pilte, milline, sinu, hoolitsen, välimuse, eest
Topics RU: математика
Topics EN: mathematics
Headings: Minu välimus; Loe; Harjuta; 1. Loe ja vaata pilte.; 1.d. Loe ja vaata pilte.; 1.a. Loe ja vaata pilte.; 1.b. Loe ja vaata pilte.; 1.c. Loe ja vaata pilte.; 2. Milline on sinu välimus?; Ma hoolitsen oma välimuse eest.; 3. Karl on puhas.; 4. Kumb poiss on Karl?; 5. Mida läheb vaja, et olla puhas?; 5.b. Mida läheb vaja, et olla puhas?; Mida läheb vaja, et olla puhas?; 6. Otsusta, kas lause on õige või vale.; 7. Arutle õpetajaga.; Tööleht

## Sünnipäev
URL: https://www.opiq.ee/kit/281/chapter/15788
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.10
Topics ET: matemaatika, sünnipäev, kutsele, kirjutatakse, harjuta, tuleb, sünni, päev, laused, millised
Topics RU: математика
Topics EN: mathematics
Headings: Sünnipäev; Loe; Loe, mis kutsele kirjutatakse.; Harjuta; 1. Sul tuleb sünni-päev.; 2. Loe laused. Millised laused ei sobi sünni-päeva kutsele?; Kuula teksti.; 3. Mida ostis Robin poest?; 4. Mida sõbrad sünni-päevale kaasa võtavad?; 5. Miks ei ole hea liiga palju arvutis mängida?; 6. Mida võib sünnipäeval teha?; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/281/chapter/15789
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.11
Topics ET: matemaatika, kordamine, korda, harjutan, harjuta, pildil, liisa, helena, uuri, nende, välimust, arutlege
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Harjuta; 1.d. Pildil on Liisa ja Helena. Uuri nende välimust.; 1.a. Pildil on Liisa ja Helena. Uuri nende välimust.; 1.b. Pildil on Liisa ja Helena. Uuri nende välimust.; 1.c. Pildil on Liisa ja Helena. Uuri nende välimust.; 2. Arutlege klassis täidetud tabeli järgi.; 3. Kuidas hoiad ennast puhtana?; Vaata pilti ja vali õige vastus.; Vaata pilte ja vali õige vastus.; 4. Vaata pilte. Mida teed kodus ja/või koolis?; 5. Vaata pilte. Täida ristsõna.; 6. Vaata pilte.; 7. Mis on raamatuga juhtunud?; 8. Loe laused. Kuidas tuleb raamatu-kogus käituda?; 9. Kirjuta oma sõbrale sünni-päeva kaart.; 10. Valetada ei ole õige.; Tööleht

## Sarnane ja erinev
URL: https://www.opiq.ee/kit/281/chapter/15780
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, sarnane, erinev, harjuta, vasta, küsimustele, tead, akiko, kuula, teksti
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Sarnane ja erinev; Harjuta; 1. Vasta küsimustele.; Kas sa tead, kes on Akiko?; Kuula teksti.; 2. Loe ja kuula jaapani-keelseid sõnu.; 3. Vaata Eesti ja Jaapani lippe.; 4. Tee koos õpetajaga.; 5. Vaata pilte. Mida meeldib Akikole teha?; 5.c. Vaata pilti. Mida meeldib Akikole teha?; 5.a. Vaata pilti. Mida meeldib Akikole teha?; 5.b. Vaata pilti. Mida meeldib Akikole teha?; 6. Lõpeta laused enda kohta.; 7. Täida laused Akiko kohta.; 8. Võrdle ennast Akikoga.; 8.b. Võrdle ennast Akikoga.; 8.a. Võrdle ennast Akikoga.; Õpetaja Madise päev; 9. Mida õpetaja Madis päeva jooksul teeb?; 10. Võrdle õpetaja Madise ja enda päeva.; 10.c. Võrdle õpetaja Madise ja enda päeva.; 10.a. Võrdle õpetaja Madise ja enda päeva.; 10.b. Võrdle õpetaja Madise ja enda päeva.; 11. Täida laused enda kohta.; 12. Lahenda ristsõna.; Tööleht

## Iga inimene on tähtis
URL: https://www.opiq.ee/kit/281/chapter/15781
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.3
Topics ET: matemaatika, raha, euro, sent, inimene, keha, meeled, tervis, tähtis, harjuta, odav, kallis, vaata, pilte, mida
Topics RU: математика, деньги, евро, цент, человек, тело, чувства, здоровье
Topics EN: mathematics, money, euro, cent, human, body, senses, health
Headings: Iga inimene on tähtis; Raha; Harjuta; 1. Mis on odav? Mis on kallis?; 2. Vaata pilte. Mida raha eest osta EI SAA?; 3. Arutle õpetajaga.; Õigused; 4. Vaata videot Karelist, kes räägib, mis õigused igal lapsel on.; 5. Millised õigused sul on?; Loe; Kuula Hugo ja Mariami juttu.; 6. Millised õigused on Mariamil ja Hugol?; 5.d. Millised õigused on Mariamil ja Hugol?; 5.a. Millised õigused on Mariamil ja Hugol?; 5.b. Millised õigused on Mariamil ja Hugol?; 5.c. Millised õigused on Mariamil ja Hugol?; Kiitlemine; 7. Millega kiitles Robin? Millega kiitles Gustav?; Kuula uuesti Gustavi ja Robini kahe-kõnet. Mis oli teist-moodi?; 8. Mille eest kiitis Gustav Robinit? Mille eest kiitis Robin Gustavit?; 9. Loe.; 10. Millega inimesed kiitlevad? Koosta laused.; 11. Mida keegi oskab hästi teha?; 12. Loe, mida nad sulle ütlevad.; 13. Vaata pilte ja loe.; 14. Mida sina oskad hästi?; 15. Arutle õpetajaga.; Tööleht

## Näoilmed
URL: https://www.opiq.ee/kit/281/chapter/15782
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.4
Topics ET: matemaatika, näoilmed, inimese, osad, kuula, ilmete, kirjeldusi, harjuta, vaata, pilte
Topics RU: математика
Topics EN: mathematics
Headings: Näoilmed; Loe; 1. Inimese näo osad; Loe ja kuula näo-ilmete kirjeldusi.; Harjuta; 2. Vaata pilte ja loe.; 2.b. Vaata pilte ja loe.; 2.a. Vaata pilte ja loe.; 3. Vaata pilte.; 4. Arutle õpetajaga, mida võid tunda, kui ...; Tööleht

## Valetamine
URL: https://www.opiq.ee/kit/281/chapter/15783
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.5
Topics ET: matemaatika, valetamine, harjuta, lõpeta, laused, vaata, pilte, käitumine, õige, vale
Topics RU: математика
Topics EN: mathematics
Headings: Valetamine; Loe; Harjuta; 1. Lõpeta laused.; 2. Vaata pilte ja loe.; Kas käitumine oli õige või vale?; Vaata pilte ja loe; 3. Mis juhtub, kui valetada? Kuidas tüli lõpetada?; 4. Mis juhtub, kui tunnistada vale üles?; 5. Loe vana-sõna.; 6. Loe. Lõpeta laused.; 11. Vali õige vastus.; 7. Vali õige vastus.; 9. Vali õige vastus.; Tööleht

## Käitumine koduümbruses
URL: https://www.opiq.ee/kit/281/chapter/15784
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.6
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, käitumine, koduümbruses, harjuta, kuidas, saad, naabreid, aidata, vaata
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Käitumine koduümbruses; Loe; Harjuta; 1. Kuidas saad naabreid aidata?; 2. Vaata ja võrdle pilte.; 3. Vaata pilte. Mis tegevus rõõmustab naabreid?; Kuula teksti.; 4. Lõpeta laused.; 5. Kas peab luba küsima?; Tööleht

## Käitumine raamatukogus
URL: https://www.opiq.ee/kit/281/chapter/15785
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.7
Topics ET: matemaatika, käitumine, raamatukogus, kuula, teksti, harjuta, tuleta, meelde, nädala, päevad
Topics RU: математика
Topics EN: mathematics
Headings: Käitumine raamatukogus; Loe; Kuula teksti.; Harjuta; 1. Tuleta meelde nädala-päevad.; 2. Raamatu-kogu ukse peal oli silt.; 3.c. Mis päeval on raamatu-kogu suletud?; 3.a. Mis päevadel oli raamatu-kogu avatud?; 3.b. Mitmel päeval saab Robin raamatu-kogus käia?; 4. Vaata pilte ja loe.; 5. Loe raamatu-kogu reegleid.; 6. Kuidas peab raamatu-kogus käituma?; 7. Mida EI TOHI raamatukogus teha?; 8. Täida enda andmetega leht raamatu-kogu jaoks.; 9. Arutle õpetajaga.; Tööleht

## Käitumine söögilauas
URL: https://www.opiq.ee/kit/281/chapter/15786
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.8
Topics ET: matemaatika, käitumine, söögilauas, harjuta, vaata, pilte, hugo, köögis, kata, laud
Topics RU: математика
Topics EN: mathematics
Headings: Käitumine söögilauas; Harjuta; 1. Loe ja vaata pilte.; Vaata pilte ja loe; 2. Hugo köögis; 3. Kata laud.; 4. Mida tuleb teha enne sööma hakkamist?; 5. Mida EI TOHI söögi-lauas teha?; 6. Arutle, miks ei tohi söögi-lauas:; Loe; 7. Kes mida tegi?; Tööleht

## Külas
URL: https://www.opiq.ee/kit/281/chapter/15787
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 1.9
Topics ET: matemaatika, külas, kuidas, viisakas, vastata, harjuta, tore, külaline, keda, sina
Topics RU: математика
Topics EN: mathematics
Headings: Külas; Loe; 1. Kuidas on viisakas vastata?; Harjuta; 2. Kes on tore külaline?; 3. Keda sina endale külla tahad kutsuda?; 5. Loe. Leia igale pildile sobiv selgitus.; 4. Vaata pilte ja loe. Mida tegi Noora enne külla minekut?; 6. Kus elab Noora?; 7. Kus elab Laura?; 8. Lõpeta lause.; 9. Millega Noora võis Laura juurde sõita?; 10. Noora jõudis Laura poole. Kuidas võib külas käituda?; Tööleht

## Minu enesetunne
URL: https://www.opiq.ee/kit/281/chapter/15790
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 2.1
Topics ET: matemaatika, taim, taimed, puu, lill, enesetunne, kuula, teksti, harjuta, mida, vaja, teha, enne, pirni
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Minu enesetunne; Loe; Kuula teksti.; Harjuta; 1. Mida on vaja teha enne pirni söömist?; 2. Kuidas puu-viljad mustaks saavad?; Kuidas puu-viljad mustaks saavad?; Skeem.; 3. Vaata videost,​kuidas õunu vahatatakse.; 4. Mis põhjustab halba enese-tunnet?; Ravimid; 5. Arutle õpetajaga.; 6. Kuidas need ravimid inimest aitavad?; Kui sul on halb enese-tunne, siis räägi sellest:; Tööleht

## Terve ja haige inimene
URL: https://www.opiq.ee/kit/281/chapter/15791
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 2.2
Topics ET: matemaatika, inimene, keha, meeled, tervis, terve, haige, kuula, teksti, harjuta, vasta, küsimustele, millist
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Terve ja haige inimene; Loe; Kuula teksti.; Harjuta; 1. Vasta küsimustele.; 2. Millist kraadi-klaasi oled sina kasutanud?; 3. Vaata kraadi-klaaside pilte.; 4. Otsusta, kas inimesel on palavik või mitte.; 5. Mis võis olla Kadri keha-temperatuur?; 6. Kuidas ära tunda külmetus-haigust?; Valu; 7. Arutle õpetajaga.; 8. Vahel võib juhtuda, et jääd koolis haigeks. Mida siis teha?; 9. Kuidas käitud, kui oled jäänud koolis haigeks?; 10. Vanemad on tööl. Olen üksi kodus. Jään haigeks. Mida teen?; 11. Arutle õpetajaga.; Allergia; Inimesed võivad olla tundlikud ​mõne asja suhtes. Näiteks; Allergial võivad olla sellised tunnused:; 12. Paranda allergia tunnused õigeks.; 13. Arutle õpetajaga.; Tööleht

## Kuidas haigusi ära hoida?
URL: https://www.opiq.ee/kit/281/chapter/15792
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 2.3
Topics ET: matemaatika, kuidas, haigusi, hoida, mida, teha, olla, terve, harjuta, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas haigusi ära hoida?; Mida teha, et olla terve?; Harjuta; Vaata videot, kuidas ennetada nakatumist.; 1. Vasta küsimustele video kohta. Vali õige vastus.; Mida teha, et haigust ära hoida?; Kuula teksti.; 1. PESEN KÄSI.; 2. KÜLMA ILMAGA KANNAN SOOJA RIIETUST.; 3. SOOJA ILMAGA KANNAN ÕHUKESI RIIDEID.; 4. TEEN KODUS AKNAD LAHTI JA ​ÕHUTAN TUBA.; 5. KARASTAN.; 2. Milliseid riideid ja jalanõusid kannan suvel?; 3. Loe.; Loe; Tööleht

## Tervislik eluviis
URL: https://www.opiq.ee/kit/281/chapter/15793
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 2.4
Topics ET: matemaatika, tervislik, eluviis, toitumine, harjuta, vaata, toidu, ainete, pilte, millised
Topics RU: математика
Topics EN: mathematics
Headings: Tervislik eluviis; Toitumine; Harjuta; 1. Vaata toidu-ainete pilte.; 2. Millised toidud on tervislikud?; 3. Vaata toidu ja joogi pilte. Mida sina sööd ja jood hommikuti?; Liikumine; Kuula teksti.; 4. Mis tegevus on liikumine?; 5. Tee oma liikumis-plaan kolmeks päevaks.; Uni ja puhkus; 6. Vaata joonist. Arutle õpetajaga.; 7. Inimese une-vajadus öösel. Kui kaua peavad inimesed magama öösel?; 8. Täida lüngad tabeli abil; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/281/chapter/15794
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 2.5
Topics ET: matemaatika, kordamine, korda, harjutan, inimene, keha, meeled, tervis, harjuta, milline, haige, terve, vali, lausele, õige
Topics RU: математика, повторение, повтори, тренировка, человек, тело, чувства, здоровье
Topics EN: mathematics, revision, review, practice, human, body, senses, health
Headings: Kordamine; Harjuta; 1.b. Milline on haige inimene?; 1.a. Milline on terve inimene?; 2. Vali lausele õige lõpp.; 3. Kes mida teeb, et hoida tervist?; 4. Kas toit on tervislik?; Tööleht

## Suurpere ja väike pere
URL: https://www.opiq.ee/kit/281/chapter/15795
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 3.1
Topics ET: matemaatika, suurpere, väike, pere, erinevad, pered, harjuta, milline, suur, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Suurpere ja väike pere; Erinevad pered; Harjuta; 1. Milline on suur-pere ja väike pere?; Suur-pere; Mõtle ja vasta küsimustele; 2. Leia pildilt vana-ema, vana-isa, isa, ema, laps.; 3. Vaata piltidel erinevaid pere-kondi. Vasta suuliselt küsimustele.; Õed ja vennad; 4. Vaata pilti.; Tädid ja onud; 5. Vali õige vastus.; 6. Kes on pere-liikmed?; Tööleht

## Minu pere
URL: https://www.opiq.ee/kit/281/chapter/15796
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 3.2
Topics ET: matemaatika, pere, kuula, teksti, harjuta, arutle, õpetajaga, kirjelda, peret, meie
Topics RU: математика
Topics EN: mathematics
Headings: Minu pere; Pere; Kuula teksti.; Harjuta; 1. Arutle õpetajaga.; 2. Kirjelda oma peret.; D. Meie pere-liikmed; A. Kellega elan koos?; B. Minu õed ja vennad.; C. Meie pere lemmikloomad; 3. Mida teevad sinu pere-liikmed?; 4. Mida te koos perega teete?; Nimi ja vanus; Mõtle ja vasta küsimustele; 5. Vasta küsimustele.; 6. Arutle perega, kuidas sina omale nime said.; 7. Vaata neid inimesi.; B. Kui vana on keegi?; A. Leia beebi, õde, vana-ema.; Tööleht

## Hoolin oma perest
URL: https://www.opiq.ee/kit/281/chapter/15797
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 3.3
Topics ET: matemaatika, hoolin, perest, aitamine, kuula, teksti, harjuta, lõpeta, laused, otsusta
Topics RU: математика
Topics EN: mathematics
Headings: Hoolin oma perest; Aitamine; Kuula teksti.; Harjuta; 1. Lõpeta laused.; 2. Otsusta, kas tegija arvestab teistega või mitte.; E. Vali õige vastus.; A. Vali õige vastus.; B. Vali õige vastus.; C. Vali õige vastus.; D. Vali õige vastus.; Kohustused; Mõtle ja vasta küsimustele; 3. Mis on sinu kohustused peres?; H. Kas prügi välja viimine on sinu kohustus?; A. Kas söögi tegemine on sinu kohustus?; B. Kas laua katmine on sinu kohustus?; C. Kas nõude pesemine on sinu kohustus?; D. Kas oma toa koristamine on sinu kohustus?; E. Kas pesu riputamine on sinu kohustus?; F. Kas pesu triikimine on sinu kohustus?; G. Kas lemmik-looma eest hoolitsemine on sinu kohustus?; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/281/chapter/15798
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 3.4
Topics ET: matemaatika, kordamine, korda, harjutan, harjuta, töötab, õpib, kodune, mille, poolest, erinevad, sarnanevad
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Harjuta; 1. Kes töötab? Kes õpib? Kes on kodune?; 2. Mille poolest erinevad ja sarnanevad pered? Arutle õpetajaga.; 3. Loe laused. Otsusta, kas tegija arvestab teistega või mitte.; 4. Onu või tädi?; 5. Kes on väike pere ja kes suur-pere?; Vali õige vastus.; 6. Vaata piltidel tegevusi. Kas sa oled neid tegevusi teinud või mitte?; Kas sa oled neid tegevusi teinud või mitte?; 7. Vasta küsimustele eelmise ülesande piltide järgi.; 8. Kirjelda oma peret.; Tööleht

## Eestimaa on minu kodumaa
URL: https://www.opiq.ee/kit/281/chapter/16713
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 4.1
Topics ET: matemaatika, eestimaa, kodumaa, eesti, vaba, riik, harjuta, laused, vaata, pilti
Topics RU: математика
Topics EN: mathematics
Headings: Eestimaa on minu kodumaa; Eesti Vaba-riik; Harjuta; 1. Loe laused.; 2. Vaata pilti.; Rahvas; 3. Vasta küsimustele.; Loe; 4. Loe laused.; 5. Vaata pilte. Piltidel on eesti inimeste jaoks olulised tegevused.; 6. Arutle õpetajaga.; 7. Loe laused.; President; 8. Vasta küsimustele suuliselt.; 9. Märgista õige vastus.; Minu Eesti; 10. Vaata videot Eestimaast.; 11. Mida videost nägid?; Tööleht

## Eestimaa kaart
URL: https://www.opiq.ee/kit/281/chapter/16714
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 4.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, eestimaa, kaart, harjuta, eesti, vaata, seda, leia, abiga, kaardilt
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Eestimaa kaart; Harjuta; 1. See on Eesti-maa kaart. Vaata seda. Leia õpetaja abiga kaardilt oma kodu-koht.; Pealinn; 2. Vasta küsimustele.; 3. Leia kaardilt Eesti kõige suurem linn – Tallinn.; Suuremad linnad; 4. Noora elab Tallinnas. Tema sõber Anna elab Narvas. ​Noora vana-ema Helmi elab Tartus.; 5. Vali õige linn. Otsi kaardilt ja märgista.; Vali õige linn. Otsi kaardilt ja märgista.; Naabrid; Mõtle ja vasta küsimustele; 6. Arutle õpetajaga.; 7. Kirjuta kaardile, kus asuvad Eesti naaber-riigid.; 8. Loe küsimused.; 9. Millega saab naabritele külla sõita?; 10. Millega saab naabritele külla sõita?; 11. Millega saab naabritele külla sõita?; 12. Millega saab naabritele külla sõita?; Tööleht

## Eestimaa sümbolid
URL: https://www.opiq.ee/kit/281/chapter/16715
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 4.3
Topics ET: matemaatika, taim, taimed, puu, lill, eestimaa, sümbolid, riigi, lipp, harjuta, vaata, kahte, pilti, milline
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Eestimaa sümbolid; Riigi sümbolid; Lipp; Harjuta; 1. Vaata kahte pilti.; 2. Milline lipp sobib Eesti lipuks?; Vapp; Mõtle ja vasta küsimustele; 3. Milline on Eesti vapp?; 4. Loe laused.; 5. Mis värvid on Eesti vapil?; Hümn; 6. Kaks poissi laulavad hümni. Kumb poistest käitub õigesti?; 7. Loe laused.; 8. Kuula Eesti hümni ja vasta küsimusele.; Suitsu-pääsuke; 9. Kuula suitsu-pääsukese laulu ja vasta küsimusele.; 10. Milline neist on pääsukese saba?; 11. Vaata pilte. Leia suitsu-pääsukesed.; 12. Mis värvi on suitsu-pääsuke?; Rukki-lill; 13. Vaata pilte. Leia rukki-lill.; 14. Mis värvi on rukki-lilled?; Tööleht

## Pühad ja kombed
URL: https://www.opiq.ee/kit/281/chapter/16716
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 4.4
Topics ET: matemaatika, liitmine, liida, summa, kokku, pühad, kombed, vastla, päev, päeval, harjuta, aasta, ajal, tähistame
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Pühad ja kombed; Pühad; Vastla-päev; Vastla-päeval ...; Harjuta; 1. Mis aasta-ajal tähistame vastla-päeva?; 2. Vaata pilte. Millised pildid sobivad kokku vastla-päevaga?; 3. Loe laused.; Eesti Vaba-riigi sünni-päev; Eesti sünni-päeval ...; 4. Vasta küsimustele.; 5. Vaata pilte. Millised pildid sobivad kokku Eesti sünni-päevaga?; Volber; 6. Mis aasta-ajal tähistame volbri-päeva?; 7. Vaata pilte. Millised pildid sobivad kokku volbri-päevaga?; Jaani-päev; Jaani-päeval ...; 8. Mis aasta-ajal tähistame jaani-päeva?; 9. Vaata pilte. Millised pildid sobivad kokku jaani-päevaga?; Mardi-päev ja kadri-päev; Mardi-päev; Kadri-päev; 10. Mis aasta-ajal tähistame kadri-päeva ja mardi-päeva?; 11. Loe laused.; Jõulud; Jõulude ajal ...; 12. Mis aasta-ajal tähistame jõule?; 13. Vaata pilte. Millised pildid sobivad kokku jõuludega?; Meie pere pühad; 14. Milliseid pühasid sinu pere tähistab?; 15. Mis on sinu lemmik-püha?; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/281/chapter/16717
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 4.5
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kordamine, korda, harjutan, harjuta, miks, eestis, elada, laused, vaata, pilte, millist
Topics RU: математика, число, числа, цифры, повторение, повтори, тренировка
Topics EN: mathematics, number, numbers, digits, revision, review, practice
Headings: Kordamine; Harjuta; 1. Loe, miks on Eestis hea elada.; 2. Loe laused.; 3. Vaata pilte. Millist tööd teeb president?; 4. Kus asuvad Eesti naabrid? Kirjuta kaardile Eesti naaber-riigid.; 5. Loe laused.; 6. Milline lipp sobib Eesti lipuks?; 7. Vaata Eesti vappi.; 8. Igal riigil on oma hümn. Kuula kolme hümni. Milline neist on Eesti hümn?; 9. Lohista pildi juurde õigesse kohta sobiva märk-sõna number.; 10. Loe laused.; 11. Vaata pilte. Millised on Eesti sümbolid?; 12. Ühenda püha õige aasta-ajaga.; 13. Ühenda oma-vahel püha ja sellega sobiv toit.; Tööleht

## Aasta-ajad
URL: https://www.opiq.ee/kit/281/chapter/16718
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 5.1
Topics ET: matemaatika, liitmine, liida, summa, kokku, aastaajad, kevad, suvi, sügis, talv, aasta, ajad, harjuta, vaata, pilte, kirjuta, ajaga, sobivad
Topics RU: математика, сложение, сложи, сумма, времена года, весна, лето, осень, зима
Topics EN: mathematics, addition, add, sum, seasons, spring, summer, autumn, winter
Headings: Aasta-ajad; Harjuta; 1. Vaata pilte.; 2. Kirjuta aasta-ajaga kokku sobivad kuud.; Kevad; 3. Mida inimesed kevadel õues teevad?; 4. Mida pead tegema, kui sõidad jalg-rattaga?; 5. Mida sinule meeldib kevadel teha?; 6. Arutle õpetajaga.; 7. Vaata pilte. Loe ja arutle õpetajaga.; 8. Vali küsimusele sobiv vastus.; Suvi; 9. Mida inimesed suvel teevad?; 10. Mida sinule meeldib suvel teha?; 11. Arutle õpetajaga.; 12. Vaata pilte. Loe ja arutle õpetajaga.; 13. Loe küsimus.; Sügis; 14. Mida inimesed sügisel teevad?; 15. Mida sinule meeldib sügisel teha?; 16. Arutle õpetajaga.; 17. Vaata pilte. Loe ja arutle õpetajaga.; 18. Loe küsimus.; Talv; 19. Mida inimesed teevad talvel?; 20. Mida sinule meeldib talvel teha?; 21. Arutle õpetajaga.; 22. Vaata pilte. Loe ja arutle õpetajaga.; 23. Loe küsimus.; Tööleht

## Kalender
URL: https://www.opiq.ee/kit/281/chapter/16719
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 5.2
Topics ET: matemaatika, aeg, kell, kalender, kuud, harjuta, vaata, joonist, pilte, pildi, juures, oleva
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Kalender; Kuud; Harjuta; 1.Vaata joonist; 2. Vaata pilte ja loe pildi juures oleva kuu nimetus.; Nädal; 3. Lõpeta laused suuliselt.; 4. Loe. Ütle laused õigesti.; 5. Täida lüngad.; 6. Vaata Noora nädala-plaani; 7. Arutle õpetajaga.; 8. Arutle õpetajaga.; 9. Vaata kalendrit ja vasta küsimustele.; 10. Täida ise kalendrit juhiste järgi.; 11. Vaata klassi kalendrit. Vasta küsimustele suuliselt.; Tööleht

## Kellaaeg
URL: https://www.opiq.ee/kit/281/chapter/16720
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 5.3
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, aeg, kell, kalender, kellaaeg, harjuta, arutle, õpetajaga, piltidel, erinevad, kellad, kuula, milliseid
Topics RU: математика, деление, раздели, частное, половина, время, часы, календарь
Topics EN: mathematics, division, divide, quotient, half, time, clock, calendar
Headings: Kellaaeg; Loe; Harjuta; 1. Arutle õpetajaga.; 2. Piltidel on erinevad kellad; 3. Kuula, milliseid helisid kellad teevad.; 4. Loe laused.; Kordame täis-tundi; 5. Jälgi kella osuteid.; 6. Kella-aeg on antud, aga kell ei näita õiget aega.; 7. Vali kella juurde sama aeg.; 8. Juss õpib täis-tundi. Ta on iga kella alla kirjutanud aja.; Kordame pool-tundi; 9. Jälgi kella osuteid.; 10. Kella-aeg on antud, aga kell ei näita õiget aega.; 11. Juss õpib ka pool-tundi. Ta on iga kella alla kirjutanud aja.; Tegevuste ajaline järje-kord; 12. Loe ja vaata pilte, milline on Anna päev. Mis kell Anna midagi tegi? ​Märgi kellale, kuhu peaks osutama väike osuti.; 1. Loe ja vaata pilte, milline on Anna päev. Mis kell Anna midagi tegi?; 2. Kella-aeg on antud, aga kell ei näita õiget aega, sest väike osuti on puudu.; 13. Anna sööb lõuna-sööki kell 12:00.; Tööleht

## Vaba aeg
URL: https://www.opiq.ee/kit/281/chapter/16721
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 5.4
Topics ET: matemaatika, aeg, kell, kalender, vaba, harjuta, vaata, videot, hobidega, tegeleb, hiiu, valla, rahvas
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Vaba aeg; Loe; Harjuta; 1. Vaata videot, mis hobidega tegeleb Hiiu valla rahvas.; 2. Vaata pilte. Mida teevad lapsed pildil? Nimeta.; 3. Mida saab teha toas? Mida õues?; 4. Loe ja kuula, kuidas Karl Marko külla kutsub.; 5. Arutle õpetajaga.; Huvi-ringid; 6. Vaata videot laste joogast.; 7. Kuidas sa tunned ennast pärast jooga-harjutuste tegemist?; 8. Vaata Kalda kooli huvi-ringide tabelit.; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/281/chapter/16722
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 5.5
Topics ET: matemaatika, aeg, kell, kalender, kordamine, korda, harjutan, harjuta, vaata, pilte, aasta, pildil, järjesta, ajad, õiges
Topics RU: математика, время, часы, календарь, повторение, повтори, тренировка
Topics EN: mathematics, time, clock, calendar, revision, review, practice
Headings: Kordamine; Harjuta; 1. Vaata pilte. Mis aasta-aeg on pildil?; 2. Järjesta aasta-ajad õiges järje-korras.; 3. Mis aasta-ajal võib esineda ohtlikke olukordi?; 4. Loe lause.; 5. Loe lause.; 6. Lohista nädala-päevad õigesse järjekorda.; 7. Vaata skeemi. Järjesta päevad skeemi alusel.; 8.; 8. Täida lüngad eelmise harjutuse järgi.; 9 . Vaata kalendrit.; 10. Vali kellaga sama aeg.; 11. Vaata kella-aega.; 12. Vaata kella-aega. Märgi kellale, kuhu peaksid osutama mõlemad osutid.; 13. Vaata kella-aega.; 13. Mis ei sobi kooli-tundi?; 14. Mida saab teha õues ja toas?; Tööleht

## Minu koolitee
URL: https://www.opiq.ee/kit/281/chapter/16723
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 6.1
Topics ET: matemaatika, koolitee, harjuta, vasta, küsimustele, arutle, õpetajaga, millega, sina, täna
Topics RU: математика
Topics EN: mathematics
Headings: Minu koolitee; Loe; Harjuta; 1. Vasta küsimustele. Arutle õpetajaga.; 2. Millega sina täna kooli tulid?; Liiklus; 4. Vaata videot, kuidas tuleb teed ületada.; 5. Märgi õige vastus.; Nuti-telefon ja kõrva-klapid; 6. Vaata videot, mis võib juhtuda, kui kõnnid kõrvaklapid peas.; Helkur; Ohud; 7. Loe ja vaata pilte. Mis on kooli-teel ohtlik? Mis võib juhtuda?; 8. Loe; Kuula teksti; Tööleht

## Tundmatud ained minu ümber
URL: https://www.opiq.ee/kit/281/chapter/16724
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 6.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, tundmatud, ained, ümber, vedelikud, harjuta, katse, vett, äädikat
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Tundmatud ained minu ümber; Vedelikud; Harjuta; 1.c KATSE. Võrdle vett ja äädikat.; 1.a KATSE. Võrdle vett ja äädikat. Mis on sarnane? Mis on erinev?; 1.b KATSE. Võrdle vett ja äädikat.; 2. Millised vedelikud kodus on terava lõhnaga? Mida ei tohi otse nuusutada, maitsta ega katsuda? Märgista.; 2. Millised vedelikud kodus on terava lõhnaga? Mida ei tohi otse nuusutada, maitsta ega katsuda? Märgi.; Loe; 3. Vaata videot, kuidas poisid leiavad tundmatuid vedelikke.; 4. Vali õige vastus.; 5. Vali õige vastus.; 6. Arutle õpetajaga. Vasta küsimustele suuliselt.; Gaas; 7. Vaata videot, kuidas kodus gaasi kasutatakse.; Kuidas käitun ohtlikus olu-korras?; 8. Vali, kas väide on õige või vale.; Tööleht

## Kiirabi, politsei, pääste-amet
URL: https://www.opiq.ee/kit/281/chapter/16725
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 6.3
Topics ET: matemaatika, kiirabi, politsei, pääste, amet, harjuta, vaata, videot, kuidas, jõuab
Topics RU: математика
Topics EN: mathematics
Headings: Kiirabi, politsei, pääste-amet; Harjuta; 1. Vaata videot, kuidas jõuab abi hädas-olijani.; 2. Vali või märgi õige(d) vastus(ed).; Kiir-abi; 3. Täida lüngad.; Politsei; 4. Märgi õige vastus.; Pääste-amet; 5. Loe väidet.; 6. Vaata videot, kuidas näeb välja päästjate välja-kutse.; 7. Arutle õpetajaga.; 8. Otsusta, mis on kiir-abi, politsei ja päästjate ülesanded.; Abi vajadus; 9. Vaata pilte. Keda on vaja appi kutsuda?; Tööleht

## Helistan numbril 112
URL: https://www.opiq.ee/kit/281/chapter/16726
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 6.4
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, arv, arvud, arvu, numbrid, kordamine, harjutan, helistan, numbril, harjuta, millal, tuleb, helistada, kodu, vägi, vald
Topics RU: математика, умножение, умножь, произведение, число, числа, цифры, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, number, numbers, digits, revision, review, practice
Headings: Helistan numbril 112; Loe; Harjuta; 1. Millal tuleb helistada 112?; Kodu-vägi-vald; 2. Vaata videot, kuidas käituda, kui keegi on kodus vägi-valdne.; 3. Vasta küsimustele.; Loe ja kuula juhiseid; 4. Pane tegevused õigesse järje-korda.; Tähtsad numbrid; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/281/chapter/16727
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 6.5
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kordamine, korda, harjutan, harjuta, märgi, õiged, vastused, millised, ohud, võivad, olla
Topics RU: математика, число, числа, цифры, повторение, повтори, тренировка
Topics EN: mathematics, number, numbers, digits, revision, review, practice
Headings: Kordamine; Harjuta; 1. Märgi õiged vastused.; 2. Millised ohud võivad olla kooli-teel?; 3. Mida tohib teha kodus vedelikega?; 4. Mida tähendavad märgid?; 5. Vaata videot tuleohtlikest ainetest.; 6. Arutle õpetajaga.; 6. Mis ametid on siin peidus?; 7. Kelle number on 112?; 8. Kelle auto on pildil?; 9. Kuidas helistada numbril 112?; 10. Kuidas käituda vägi-valla korral?; 11. Keda on vaja ruttu kutsuda?; 12. Kellele teatad?; 13. Mis numbril helistad?; 14. Nuputa.; Tööleht

## Metoodilised juhised õpetajale õppevara kasutamiseks
URL: https://www.opiq.ee/kit/281/chapter/15799
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 7.1
Topics ET: matemaatika, metoodilised, juhised, õpetajale, õppevara, kasutamiseks
Topics RU: математика
Topics EN: mathematics
Headings: Metoodilised juhised õpetajale õppevara kasutamiseks

## Inimeseõpetus 3. klassile. I osa (print-pdf)
URL: https://www.opiq.ee/kit/281/chapter/15800
Book: Minu välimus
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 7.2
Topics ET: matemaatika, inimeseõpetus, klassile, print
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 3. klassile. I osa (print-pdf)

## Inimeseõpetus 3. klassile. II osa (print-pdf)
URL: https://www.opiq.ee/kit/281/chapter/16712
Book: Minu välimus
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 7.3
Topics ET: matemaatika, inimeseõpetus, klassile, print
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 3. klassile. II osa (print-pdf)

## Impressum
URL: https://www.opiq.ee/kit/281/chapter/15801
Book: Minu välimus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1k_inimeseopetus_innove_est
Chapter ID: 7.4
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## IN3 – Opiq
URL: https://www.opiq.ee/Kit/Details/146
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 61
Topics ET: matemaatika, opiq
Topics RU: математика
Topics EN: mathematics

## Jälle koolis
URL: https://www.opiq.ee/kit/146/chapter/8129
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 1.1
Topics ET: matemaatika, jälle, koolis, mida, õpid, klassi, inimeseõpetuses, uuri, fotosid
Topics RU: математика
Topics EN: mathematics
Headings: Jälle koolis; Mida õpid 3. klassi inimeseõpetuses?; Uuri fotosid; Töötage rühmas; Vasta küsimustele

## Haridustee
URL: https://www.opiq.ee/kit/146/chapter/8130
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 1.2
Topics ET: matemaatika, haridustee, töötage, rühmas, uuri, skeemi, ülemist, vasta, küsimustele
Topics RU: математика
Topics EN: mathematics
Headings: Haridustee; Töötage rühmas; Uuri skeemi; Uuri ülemist skeemi ja vasta küsimustele; Uuri fotosid ja teavet; Mõtle ja aruta klassis; Märgi oma haridustee

## Teabeallikad
URL: https://www.opiq.ee/kit/146/chapter/8131
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 1.3
Topics ET: matemaatika, teabeallikad, uuri, pilte, töötage, rühmas, kokkuvõte, rühmatööst, koosta
Topics RU: математика
Topics EN: mathematics
Headings: Teabeallikad; Uuri pilte; Töötage rühmas; Kokkuvõte rühmatööst; Koosta mõistekaart

## Eesti teiste riikide seas
URL: https://www.opiq.ee/kit/146/chapter/8145
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 10.1
Topics ET: matemaatika, eesti, teiste, riikide, seas, uuri, kaarti, naaberriikide, lipud, tunne
Topics RU: математика
Topics EN: mathematics
Headings: Eesti teiste riikide seas; Uuri kaarti; EESTI NAABERRIIKIDE LIPUD; Tunne meie naabreid; Euroopa Liit; Mõtle ja aruta klassis

## Eesti Vabariigi sümbolid
URL: https://www.opiq.ee/kit/146/chapter/8146
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 10.2
Topics ET: matemaatika, eesti, vabariigi, sümbolid, riiklikud, märgi, kodumaakonna, vapp, rahvuslikud
Topics RU: математика
Topics EN: mathematics
Headings: Eesti Vabariigi sümbolid; RIIKLIKUD SÜMBOLID; Märgi oma kodumaakonna vapp; RAHVUSLIKUD SÜMBOLID; Leia õiged rahvussümbolid; Lahenda ristsõna

## Eestis elavad rahvused
URL: https://www.opiq.ee/kit/146/chapter/8147
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 10.3
Topics ET: matemaatika, eestis, elavad, rahvused, täida, lüngad, mõtle, aruta, klassis
Topics RU: математика
Topics EN: mathematics
Headings: Eestis elavad rahvused; Täida lüngad; Mõtle ja aruta klassis; Ühenda

## Tean ja oskan
URL: https://www.opiq.ee/kit/146/chapter/8148
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 11.1
Topics ET: matemaatika, tean, oskan, lisa, esivanemate
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan; Lisa 4. ESIVANEMATE ELU
Task examples: Vali õige lauselõpp. Õigeid vastuseid võib olla mitu. Ülesanne 68 Eesti naaberriik ei ole ... … Leedu. … Läti. … Soome. Eesti rahvuslikud sümbolid on ... … suitsupääsuke. … vapp. … rukkilill. Sallivus on ... … pärilikkus; Mida õppisid Eesti ja naaberriikide kohta? Täienda tabelit. (Märka, et tuleb lisada riikide ametlikud nimed.) Ülesanne 69 RiikPealinnPõhirahvusEesti Vabariik Helsingi rootslasedVenemaa Föderatsioon Riia Joonista lisapabe

## Mina ise
URL: https://www.opiq.ee/kit/146/chapter/8149
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 12.1
Topics ET: matemaatika, mina, katse, hinda, võimeid
Topics RU: математика
Topics EN: mathematics
Headings: Mina ise; Tee katse; Hinda oma võimeid

## Tervislik toitumine
URL: https://www.opiq.ee/kit/146/chapter/8150
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 12.2
Topics ET: matemaatika, tervislik, toitumine, vaata, toidupüramiidi, vasta, küsimustele, taldrikureegel, uuri, skeemi
Topics RU: математика
Topics EN: mathematics
Headings: Tervislik toitumine; Vaata toidupüramiidi ja vasta küsimustele; TALDRIKUREEGEL; Uuri skeemi; Õiged mõisted; Kas sina toitud tervislikult?; Missuguseid roogi oskad ise valmistada?; Pane silbid õigesse järjekorda

## Liikumine, uni, puhtus
URL: https://www.opiq.ee/kit/146/chapter/8151
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 12.3
Topics ET: matemaatika, liikumine, puhtus, uuri, pilte, mõtle, aruta, klassis, töötage, rühmas
Topics RU: математика
Topics EN: mathematics
Headings: Liikumine, uni, puhtus; Uuri pilte; Mõtle ja aruta klassis; Töötage rühmas; UNI; PUHTUS

## Hoia oma tervist
URL: https://www.opiq.ee/kit/146/chapter/8152
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 12.4
Topics ET: matemaatika, hoia, tervist, vali, sobiv, vastus, uuri, pilte, sõltuvust
Topics RU: математика
Topics EN: mathematics
Headings: Hoia oma tervist; Vali sobiv vastus; Uuri pilte; Sõltuvust tekitavad ained; Mõtle ja aruta klassis; Tee katse; Märgi sobivad toiduained; Õige või vale; Rollimäng

## Esmaabi
URL: https://www.opiq.ee/kit/146/chapter/8153
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 12.5
Topics ET: matemaatika, esmaabi, uuri, pilte, mõtle, aruta, klassis, pilti
Topics RU: математика
Topics EN: mathematics
Headings: Esmaabi; Uuri pilte; Mõtle ja aruta klassis; Uuri pilti

## Keskkonnasõbralik eluviis
URL: https://www.opiq.ee/kit/146/chapter/8154
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 13.1
Topics ET: matemaatika, keskkonnasõbralik, eluviis, uuri, skeemi, vali, õige, vastus, pane
Topics RU: математика
Topics EN: mathematics
Headings: Keskkonnasõbralik eluviis; Uuri skeemi; Vali õige vastus; Pane tegevused õigesse järjekorda

## Suvele vastu
URL: https://www.opiq.ee/kit/146/chapter/8155
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 14.1
Topics ET: matemaatika, suvele, vastu, täienda, skeemi, vali, sobiv, lauselõpp, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Suvele vastu; Täienda skeemi; Vali sobiv lauselõpp; Mõtle ja aruta klassis

## Tean ja oskan
URL: https://www.opiq.ee/kit/146/chapter/8156
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 15.1
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Täienda reegleid järgnevate sõnadega: jäätmed, vaja, elektrit, prügikasti. Kirjuta ka ise mõni oluline reegel. Ülesanne 98 KESKKONNASÕBRALIKU TARBIJA MEELESPEA Hoia kodus ja koolis kokku nii vett kui ka jäätmedvajaelektr; Täienda korraliku liikleja lubadusi. Lohista sõnad õigesse lünka. Ülesanne 99 KORRALIKU LIIKLEJA LUBADUSED Tänav Sõiduteed paremal turvavöö jalgratturi juhiluba helkurit silmad kiiver Ühistranspordis Tänaval hoian ja kõr

## Ülestõusmispühad
URL: https://www.opiq.ee/kit/146/chapter/8157
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 16.1
Topics ET: matemaatika, ülestõusmispühad
Topics RU: математика
Topics EN: mathematics
Headings: Ülestõusmispühad
Task examples: Kevadel peetakse lihavõtte- ehk ülestõusmispühi. Kui jõulu esimesel pühal, 25. detsembril tähistatakse kristliku ajalooga maades Jeesuse Kristuse sünnipäeva, siis ülestõusmispühadel mälestatakse Jeesuse kannatusi ja pühi; Ühenda ülestõusmispühade ehk kevadpühade sümbolite tähendused. Ülesanne 105 {"data":["Meenutab Jeesuse surma.","Nendega lehvitades tervitati kuningaid. Jeesuse saabumisel Jeruusalemma tervitasid inimesed teda kui kuninga

## Lapse õigused ja kohustused
URL: https://www.opiq.ee/kit/146/chapter/8132
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 2.1
Topics ET: matemaatika, lapse, õigused, kohustused, mõtle, aruta, klassis, pane, sõnad, õigetesse
Topics RU: математика
Topics EN: mathematics
Headings: Lapse õigused ja kohustused; Mõtle ja aruta klassis; Pane sõnad õigetesse lünkadesse; Uuri skeemi; Sobita paaridesse

## Kodus, koolis ja kooliteel
URL: https://www.opiq.ee/kit/146/chapter/8133
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 3.1
Topics ET: matemaatika, kodus, koolis, kooliteel, mõtle, aruta, klassis, liiklus, tehke, katse
Topics RU: математика
Topics EN: mathematics
Headings: Kodus, koolis ja kooliteel; Mõtle ja aruta klassis; Liiklus; Tehke katse; Leia sobiv lauselõpp; Rollimäng; Töötage rühmas; Kokkuvõte rühmatööst

## Tean ja oskan
URL: https://www.opiq.ee/kit/146/chapter/8134
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 4.1
Topics ET: matemaatika, tean, oskan, lisa, õppimine, lemmiktund, kool, enne, nüüd
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan; Lisa 1. ÕPPIMINE – LEMMIKTUND; Lisa 1; Lisa 2. KOOL ENNE JA NÜÜD
Task examples: Vali õige lauselõpp. Õigeid vastuseid võib olla mitu. Ülesanne 18 Tavaliselt omandatakse põhiharidus ... 6 aastaga. 9 aastaga. 12 aastaga. Lapse õigused tagavad lapsele ... võimaluse omandada haridust. võimaluse tegelda ; Mis aitab ja mis segab sind õppimisel? Tee katse. Ülesanne 19 A. Õpi pähe kaks salmi. Tee seda ühel juhul vaikuses, teisel juhul muusika kuulamise või teksti ettelugemise ajal.1) vaikusesOh seda siili, siidivenda –okaste

## Sõprus
URL: https://www.opiq.ee/kit/146/chapter/8135
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 5.1
Topics ET: matemaatika, sõprus, uuri, skeemi, mõtle, aruta, klassis, märgi, linnukesega
Topics RU: математика
Topics EN: mathematics
Headings: Sõprus; Uuri skeemi; Mõtle ja aruta klassis; Märgi linnukesega; Pane silbid õigesse järjekorda; Töötage rühmas

## Mured koolis
URL: https://www.opiq.ee/kit/146/chapter/8136
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 5.2
Topics ET: matemaatika, mured, koolis, anni, mure, mõtle, aruta, klassis, vasta, küsimustele
Topics RU: математика
Topics EN: mathematics
Headings: Mured koolis; Anni mure; Mõtle ja aruta klassis; Vasta küsimustele jutu „Anni mure” põhjal; Kirjuta sobiv vastus; Märgi sobiv vastus

## Teod ja tagajärjed
URL: https://www.opiq.ee/kit/146/chapter/8137
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 5.3
Topics ET: matemaatika, teod, tagajärjed, mõtle, aruta, klassis, leia, sobiv, vastus
Topics RU: математика
Topics EN: mathematics
Headings: Teod ja tagajärjed; Mõtle ja aruta klassis; Leia sobiv vastus; Töötage rühmas

## Inimesed on erinevad
URL: https://www.opiq.ee/kit/146/chapter/8138
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 5.4
Topics ET: matemaatika, inimesed, erinevad, mõtle, aruta, klassis, õppijad, erivajadustega, töötage, rühmas
Topics RU: математика
Topics EN: mathematics
Headings: Inimesed on erinevad; Mõtle ja aruta klassis; ERINEVAD ÕPPIJAD; Erivajadustega inimesed; Töötage rühmas; Nägemispuudega inimesed; Kuulmispuudega inimesed; Liikumispuudega inimesed; Kokkuvõte rühmatööst; Tehke katse; Uuri skeemi; Mõtle ja aruta paarilisega

## Tean ja oskan
URL: https://www.opiq.ee/kit/146/chapter/8139
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 6.1
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Vasta küsimustele. Ülesanne 35 Missugune on hea sõber? Kuidas saad sõpra kaitsta kiusamise eest? Kellele võid oma muredest rääkida? Mis on laste abitelefoni number? Leia töövihikust. : 0 : 0 Lisa oma materjali Tekstiabi ; Leia täheruudustikust seitse mõistet, mis on seotud käitumisega. Ülesanne 36 {"data":[["EKSAKUUXERPDRES"],["ANNUBDZPBXTJNZU"],["NTNSCRBUIBVIZPK"],["CHAUMSCXVVMQGBK"],["NRBSTSALLIVUSFI"],["OIBJVSMYPÕAFRUL"],["OVLTYCUPQFIQ

## Jõulud
URL: https://www.opiq.ee/kit/146/chapter/8140
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 7.1
Topics ET: matemaatika, jõulud, jõulupühad, uuri, pilti, ühenda, sümbol, selle, tähendus
Topics RU: математика
Topics EN: mathematics
Headings: Jõulud; Jõulupühad; Uuri pilti; Ühenda sümbol ja selle tähendus; Kirjuta jõulusoove; Märgi iga teine täht

## Töö ja raha
URL: https://www.opiq.ee/kit/146/chapter/8141
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 8.1
Topics ET: matemaatika, raha, euro, sent, uuri, pilte, skeemi, vasta, küsimustele, arutle, paarilisega
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: Töö ja raha; Uuri pilte; Raha; Uuri skeemi; Vasta küsimustele; Arutle paarilisega ning vasta; Eluks hädavajalikud asjad; Mõtle ja aruta klassis; Töötage rühmas; Soovid ja vajadused; Taskuraha planeerimine

## Reklaam ja asjad
URL: https://www.opiq.ee/kit/146/chapter/8142
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 8.2
Topics ET: matemaatika, reklaam, asjad, mõtle, aruta, klassis, uuri, skeemi, töötage, rühmas
Topics RU: математика
Topics EN: mathematics
Headings: Reklaam ja asjad; Mõtle ja aruta klassis; Uuri skeemi; Reklaam; Töötage rühmas; Eksitav reklaam; Uuri pilte; Kirjuta reklaam

## Internetimaailm
URL: https://www.opiq.ee/kit/146/chapter/8143
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 8.3
Topics ET: matemaatika, internetimaailm, mõtle, aruta, klassis, reeglid, interneti, kasutamisel, vali, sobiv
Topics RU: математика
Topics EN: mathematics
Headings: Internetimaailm; Mõtle ja aruta klassis; Reeglid interneti kasutamisel; Vali sobiv vastus

## Tean ja oskan
URL: https://www.opiq.ee/kit/146/chapter/8144
Book: Jälle koolis
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_inimeseopetus_koolibri_est
Chapter ID: 9.1
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Vali lausetele õige lõpp. Ülesanne 53 asjade, ürituste ja teenuste kohta kokku lepitud vanematega kui seda on palka oma paroole kellelegi saadud kirju sularahaga ja pangakaardiga siis annan ma neist alati oma vanematele ; Lahenda ristsõna. Ülesanne 54 1234567→1.Arvutivõrk5.Salasõna6.Tasu töö eest7.Informatsioon kaupade, teenuste ja ürituste kohta↓2.Tulude ja kulude planeerimine3.Tegevus, mille eest makstakse palka4.Maksevahend : 0 : 0 Lis

## Наш мир. Человеко­ведение 3 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/230
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 1
Topics ET: matemaatika, opiq
Topics RU: математика, человеко, ведение, класс
Topics EN: mathematics

## Наш мир. Человеко­ведение 3 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/230
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 31
Topics ET: matemaatika, opiq
Topics RU: математика, человеко, ведение, класс
Topics EN: mathematics

## Снова в школе
URL: https://www.opiq.ee/kit/230/chapter/13115
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, снова, школе, будешь, изучать, классе, уроках, человековедения, рассмотри, фотографии
Topics EN: mathematics
Headings: Снова в школе; Что ты будешь изучать в 3 классе на уроках человековедения?; Рассмотри фотографии; Работа в группе

## Образование
URL: https://www.opiq.ee/kit/230/chapter/13116
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, образование, работа, группе, рассмотри, схему, фотографии, ознакомься, информацией, подумай
Topics EN: mathematics
Headings: Образование; Работа в группе; Рассмотри схему; Рассмотри фотографии и ознакомься с информацией; Подумай и обсуди с одноклассниками

## Источники информации
URL: https://www.opiq.ee/kit/230/chapter/13117
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, источники, информации, рассмотри, картинки, работа, группе
Topics EN: mathematics
Headings: Источники информации; Рассмотри картинки; Работа в группе

## Эстония среди других стран
URL: https://www.opiq.ee/kit/230/chapter/13131
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 10.1
Topics ET: matemaatika
Topics RU: математика, эстония, среди, других, стран, рассмотри, карту, флаги, эстонии, соседних
Topics EN: mathematics
Headings: Эстония среди других стран; Рассмотри карту; ФЛАГИ ЭСТОНИИ И СОСЕДНИХ СТРАН; Европейский Союз; Подумай и обсуди с одноклассниками

## Символы Эстонской Республики
URL: https://www.opiq.ee/kit/230/chapter/13132
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 10.2
Topics ET: matemaatika
Topics RU: математика, символы, эстонской, республики, государственные, национальные
Topics EN: mathematics
Headings: Символы Эстонской Республики; ГОСУДАРСТВЕННЫЕ СИМВОЛЫ; НАЦИОНАЛЬНЫЕ СИМВОЛЫ

## Народности, живущие в Эстонии
URL: https://www.opiq.ee/kit/230/chapter/13133
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 10.3
Topics ET: matemaatika
Topics RU: математика, народности, живущие, эстонии, подумай, обсуди, одноклассниками
Topics EN: mathematics
Headings: Народности, живущие в Эстонии; Подумай и обсуди с одноклассниками

## Знаю и умею
URL: https://www.opiq.ee/kit/230/chapter/13134
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 11.1
Topics ET: matemaatika
Topics RU: математика, знаю, умею, приложение, жизнь, предков
Topics EN: mathematics
Headings: Знаю и умею; Приложение 4. ЖИЗНЬ ПРЕДКОВ
Task examples: Правильно закончи предложение. Правильных ответов может быть несколько. При необходимости воспользуйся учебником и рабочей тетрадью.; Знания об Эстонии и соседних с ней странах. Заполни таблицу.

## Мое тело, мои способности
URL: https://www.opiq.ee/kit/230/chapter/13135
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 12.1
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, способности
Topics EN: mathematics, human, body, senses, health
Headings: Мое тело, мои способности

## Здоровое питание
URL: https://www.opiq.ee/kit/230/chapter/13136
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 12.2
Topics ET: matemaatika
Topics RU: математика, здоровое, питание, рассмотри, пищевую, пирамиду, ответь, вопросы, правило, тарелки
Topics EN: mathematics
Headings: Здоровое питание; Рассмотри пищевую пирамиду и ответь на вопросы; ПРАВИЛО ТАРЕЛКИ; Рассмотри схему

## Движение, сон, гигиена
URL: https://www.opiq.ee/kit/230/chapter/13137
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 12.3
Topics ET: matemaatika
Topics RU: математика, движение, гигиена, рассмотри, фотографии, подумай, обсуди, одноклассниками
Topics EN: mathematics
Headings: Движение, сон, гигиена; Рассмотри фотографии; Подумай и обсуди с одноклассниками; СОН; ГИГИЕНА

## Береги здоровье
URL: https://www.opiq.ee/kit/230/chapter/13138
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 12.4
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, береги, рассмотри, картинки, подумай, обсуди, одноклассниками
Topics EN: mathematics, human, body, senses, health
Headings: Береги здоровье; Рассмотри картинки; Подумай и обсуди с одноклассниками

## Первая помощь
URL: https://www.opiq.ee/kit/230/chapter/13139
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 12.5
Topics ET: matemaatika
Topics RU: математика, первая, помощь, рассмотри, картинки, подумай, обсуди, одноклассниками
Topics EN: mathematics
Headings: Первая помощь; Рассмотри картинки; Подумай и обсуди с одноклассниками

## Экологический образ жизни
URL: https://www.opiq.ee/kit/230/chapter/13140
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 13.1
Topics ET: matemaatika
Topics RU: математика, экологический, образ, жизни
Topics EN: mathematics
Headings: Экологический образ жизни

## Навстречу лету
URL: https://www.opiq.ee/kit/230/chapter/13141
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 14.1
Topics ET: matemaatika
Topics RU: математика, навстречу, лету, подумай, обсуди, одноклассниками
Topics EN: mathematics
Headings: Навстречу лету; Подумай и обсуди с одноклассниками

## Знаю и умею
URL: https://www.opiq.ee/kit/230/chapter/13142
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 15.1
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Дополни правила. Напиши и сам какое-нибудь нужное правило.; Дополни правила поведения дисциплинированного участника движения.

## Пасха
URL: https://www.opiq.ee/kit/230/chapter/13143
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 16.1
Topics ET: matemaatika
Topics RU: математика, пасха
Topics EN: mathematics
Headings: Пасха
Task examples: Пасха – весенний праздник.; Найди значения символов пасхальных праздников. Соедини символ и его значение.

## Права и обязанности детей
URL: https://www.opiq.ee/kit/230/chapter/13118
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, права, обязанности, детей, напишите, доске, свои, подумай, обсуди, одноклассниками
Topics EN: mathematics
Headings: Права и обязанности детей; Напишите на доске свои права; Подумай и обсуди с одноклассниками; Рассмотри схему

## Дома, в школе и по пути в школу
URL: https://www.opiq.ee/kit/230/chapter/13119
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, дома, школе, пути, школу, подумай, обсуди, одноклассниками, дорожное, движение
Topics EN: mathematics
Headings: Дома, в школе и по пути в школу; Подумай и обсуди с одноклассниками; Дорожное движение; Рассмотри картинки, подумай и обсуди с одноклассниками; Работа в группе

## Знаю и умею
URL: https://www.opiq.ee/kit/230/chapter/13120
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, знаю, умею, приложение, учеба, любимый, предмет, школа, прошлом
Topics EN: mathematics
Headings: Знаю и умею; Приложение 1. УЧЕБА И ЛЮБИМЫЙ ПРЕДМЕТ; Приложение 1; Приложение 2. ШКОЛА В ПРОШЛОМ И СЕГОДНЯ; На рисунках ты видишь школьные принадлежности разных времен. Подпиши каждый предмет.
Task examples: Закончи предложение. Правильных ответов может быть несколько. Если нужно, воспользуйся учебником и рабочей тетрадью.; Что помогает и что мешает тебе в учебе? Опыт.

## Дружба
URL: https://www.opiq.ee/kit/230/chapter/13121
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, дружба, рассмотри, схему, подумай, обсуди, одноклассниками
Topics EN: mathematics
Headings: Дружба; Рассмотри схему; Подумай и обсуди с одноклассниками

## Огорчения в школе
URL: https://www.opiq.ee/kit/230/chapter/13122
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, огорчения, школе, почему, огорчилась, анни, подумай, обсуди, одноклассниками
Topics EN: mathematics
Headings: Огорчения в школе; Почему огорчилась Анни; Подумай и обсуди с одноклассниками

## Поступки и последствия
URL: https://www.opiq.ee/kit/230/chapter/13123
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, поступки, последствия, подумай, обсуди, одноклассниками, работа, группе
Topics EN: mathematics
Headings: Поступки и последствия; Подумай и обсуди с одноклассниками; Работа в группе

## Все люди разные
URL: https://www.opiq.ee/kit/230/chapter/13124
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, люди, разные, подумай, обсуди, одноклассниками, ученики, тоже, особыми, потребностями
Topics EN: mathematics
Headings: Все люди разные; Подумай и обсуди с одноклассниками; УЧЕНИКИ ТОЖЕ РАЗНЫЕ; Люди с особыми потребностями; Работа в группе; Обсудите в группе; Изучи схему; Подумай и обсуди с одноклассником

## Знаю и умею
URL: https://www.opiq.ee/kit/230/chapter/13125
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Найди понятия, связанные с поведением. Задание 36 Выбери одно понятие. Объясни соседу по парте, что оно означает. Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riikl; Что помогает преодолеть горе? Отыщи как можно больше помощников. Задание 37 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023

## Рождество
URL: https://www.opiq.ee/kit/230/chapter/13126
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 7.1
Topics ET: matemaatika
Topics RU: математика, рождество, канун, рождества, рассмотри, картину
Topics EN: mathematics
Headings: Рождество; Канун Рождества; Рассмотри картину

## Работа и деньги
URL: https://www.opiq.ee/kit/230/chapter/13127
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 8.1
Topics ET: matemaatika, raha, euro, sent
Topics RU: математика, деньги, евро, цент, работа, рассмотри, картинки, схему, необходимые, жизни, вещи, подумай
Topics EN: mathematics, money, euro, cent
Headings: Работа и деньги; Рассмотри картинки; Деньги; Рассмотри схему; Необходимые для жизни вещи; Подумай и обсуди с одноклассниками; Желания и потребности; Планирование карманных денег

## Реклама и вещи
URL: https://www.opiq.ee/kit/230/chapter/13128
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 8.2
Topics ET: matemaatika
Topics RU: математика, реклама, вещи, подумай, обсуди, одноклассниками, рассмотри, схему, работа, группе
Topics EN: mathematics
Headings: Реклама и вещи; Подумай и обсуди с одноклассниками; Рассмотри схему; Реклама; Работа в группе; Реклама, вводящая в заблуждение; Рассмотри фотографии

## Мир Интернета
URL: https://www.opiq.ee/kit/230/chapter/13129
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 8.3
Topics ET: matemaatika
Topics RU: математика, интернета, подумай, обсуди, одноклассниками, правила, пользования, интернетом
Topics EN: mathematics
Headings: Мир Интернета; Подумай и обсуди с одноклассниками; Правила пользования Интернетом

## Знаю и умею
URL: https://www.opiq.ee/kit/230/chapter/13130
Book: Наш мир. Человеко­ведение 3 класс – Opiq
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 1k_inimeseopetus_koolibri_rus
Chapter ID: 9.1
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Выбери правильные окончания предложений. Запиши.

## Inimeseõpetus algklassidele, II osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/494
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 138
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## LIIKLUS. LIIKLEMISE REEGLID
URL: https://www.opiq.ee/kit/494/chapter/27186
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.1
Topics ET: matemaatika, liiklus, liiklemise, reeglid, arutle, eesõigus, andmine, ülekäigurada, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS. LIIKLEMISE REEGLID; LIIKLUS; Arutle; EESÕIGUS JA TEE ANDMINE; ÜLEKÄIGURADA; LAHENDA
Task examples: Liiklemise reeglid on kokku lepitud selleks, et liiklemine oleks; Kõnniteel on eesõigus liikuda

## LIIKLUS. ERILISED SÕIDUKID
URL: https://www.opiq.ee/kit/494/chapter/27187
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.2
Topics ET: matemaatika, liiklus, erilised, sõidukid, eritalituse, lahenda, rongid, raudtee, ületamine
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS. ERILISED SÕIDUKID; ERITALITUSE SÕIDUKID; LAHENDA; RONGID JA RAUDTEE ÜLETAMINE
Task examples: Vaata pilti. Kes peab andma teed, kui päästeautol vilkurid ja sireen töötavad?; Lohista sõiduk õigesse tulpa.

## VEEOHUTUS I
URL: https://www.opiq.ee/kit/494/chapter/27188
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.3
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, ujumine, ujulas, veekogus, avalik, rand, arutle
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS I; UJUMINE UJULAS VÕI VEEKOGUS; 1.; 2.; 3.; 4.; 5.; 6.; 7.; AVALIK RAND; Arutle
Task examples: Millised laused on õiged? Märgi need.; Vali lünka õige sõna.

## VEEOHUTUS II
URL: https://www.opiq.ee/kit/494/chapter/27189
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.4
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, hädasolija, märkamine, aitamine, päästevest, talvel, arutle
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS II; HÄDASOLIJA MÄRKAMINE JA AITAMINE; PÄÄSTEVEST; VEEOHUTUS TALVEL; HÄDASOLIJA AITAMINE TALVEL; Arutle
Task examples: Uppumisohtu sattunud laps; Millist sõiduvahendit kasutades tuleb päästevest enne selga panna?

## AJA PLANEERIMINE
URL: https://www.opiq.ee/kit/494/chapter/27190
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.5
Topics ET: matemaatika, aeg, kell, kalender, planeerimine, lahenda, arutle
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: AJA PLANEERIMINE; AEG; LAHENDA; Arutle
Task examples: Nuputa ja ühenda, millega on hea arvestada ...; Miks on vaja parajalt aega varuda?

## PERE JA SUGULASED
URL: https://www.opiq.ee/kit/494/chapter/27191
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.6
Topics ET: matemaatika, pere, sugulased, arutle
Topics RU: математика
Topics EN: mathematics
Headings: PERE JA SUGULASED; PERE; SUGULASED; Arutle
Task examples: Armastust, mõistmist ja turvatunnet peab lapsele pakkuma eelkõige; Otsusta, kas tegu on lapse õiguse või kohustusega.

## NAABRID JA KOGUKOND
URL: https://www.opiq.ee/kit/494/chapter/27192
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.7
Topics ET: matemaatika, naabrid, kogukond, arutle
Topics RU: математика
Topics EN: mathematics
Headings: NAABRID JA KOGUKOND; NAABRID; KOGUKOND; Arutle
Task examples: Milliseid nõuandeid võiks kortermajas elades järgida? Märgi need.; Kas lause on õige või vale?

## RAHVAKOMBED SÜGISEL I
URL: https://www.opiq.ee/kit/494/chapter/27193
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.8
Topics ET: matemaatika, rahvakombed, sügisel, aastaring, hingedepäev, arutle
Topics RU: математика
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL I; RAHVAKOMBED; AASTARING; HINGEDEPÄEV; Arutle
Task examples: Millise rahvakalendri tähtpäevaga on perenaise ütlus seotud?; Mis aastaajal see tähtpäev on?

## RAHVAKOMBED SÜGISEL II
URL: https://www.opiq.ee/kit/494/chapter/27194
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 1.9
Topics ET: matemaatika, rahvakombed, sügisel, mardipäev, kadripäev, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL II; MARDIPÄEV; KADRIPÄEV; LAHENDA; Arutle
Task examples: Vali lünka õige(d) sõna(d).; Kadrisandi riided on tavaliselt

## INIMESE PÕHIVAJADUSED
URL: https://www.opiq.ee/kit/494/chapter/27833
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.1
Topics ET: matemaatika, inimese, põhivajadused, märguanded, arutle
Topics RU: математика
Topics EN: mathematics
Headings: INIMESE PÕHIVAJADUSED; PÕHIVAJADUSED; AJU MÄRGUANDED; Arutle
Task examples: Märgi linnukesega, milleta me ei saa elada.; Lohista sõna õigesse tulpa.

## TERVISLIK PUHKUS JA UNI
URL: https://www.opiq.ee/kit/494/chapter/27834
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.2
Topics ET: matemaatika, tervislik, puhkus, ööpäev, piisav
Topics RU: математика
Topics EN: mathematics
Headings: TERVISLIK PUHKUS JA UNI; ÖÖPÄEV; PIISAV PUHKUS
Task examples: Vali lünka õige sõna.; Uuri pildilt, mis kell Robin hommikuti ärkab. Mis kell ta peaks õhtul voodisse minema, et ta saaks öösel 9 tundi magada? Võta abiks seinakell.

## TERVISLIK TOITUMINE JA LIIKUMINE
URL: https://www.opiq.ee/kit/494/chapter/27835
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.3
Topics ET: matemaatika, tervislik, toitumine, liikumine, toit, taldrikureegel, arutle
Topics RU: математика
Topics EN: mathematics
Headings: TERVISLIK TOITUMINE JA LIIKUMINE; TOIT; TALDRIKUREEGEL; LIIKUMINE; Arutle
Task examples: Ühenda lause algus ja lõpp.; Lohista toiduained õigesse kohta.

## OHUD VABAL AJAL. ESMAABI I
URL: https://www.opiq.ee/kit/494/chapter/27836
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.4
Topics ET: matemaatika, ohud, vabal, ajal, esmaabi, kukkumine, peapõrutus, haav, arutle
Topics RU: математика
Topics EN: mathematics
Headings: OHUD VABAL AJAL. ESMAABI I; MIS ON ESMAABI?; KUKKUMINE; PEAPÕRUTUS; HAAV; Arutle
Task examples: Esmaabi on oluline, sest; Vali lünka õige sõna.

## OHUD VABAL AJAL. ESMAABI II
URL: https://www.opiq.ee/kit/494/chapter/27837
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.5
Topics ET: matemaatika, inimene, keha, meeled, tervis, ohud, vabal, ajal, esmaabi, mürgistus, põletus, teadvuseta
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: OHUD VABAL AJAL. ESMAABI II; MÜRGISTUS; PÕLETUS; TEADVUSETA INIMENE; LAHENDA; Arutle
Task examples: Mürgistust võivad põhjustada erinevad asjad. Ühenda paarid.; Mis võib põhjustada põletust, kui olla hooletu?

## MIKS ME JÄÄME HAIGEKS?
URL: https://www.opiq.ee/kit/494/chapter/27838
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.6
Topics ET: matemaatika, inimene, keha, meeled, tervis, miks, jääme, haigeks, sagedasemad, lastehaigused, lahenda, arutle
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MIKS ME JÄÄME HAIGEKS?; TERVIS; SAGEDASEMAD LASTEHAIGUSED; LAHENDA; Arutle
Task examples: Vali lünka õiged sõnad.; Mida teha, et püsida terve? Ühenda sobiva pildiga.

## KUIDAS ME PARANEME?
URL: https://www.opiq.ee/kit/494/chapter/27839
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.7
Topics ET: matemaatika, kuidas, paraneme, mida, teha, arst, ravimid, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS ME PARANEME?; MIDA TEHA?; ARST JA RAVIMID; LAHENDA; Arutle
Task examples: Kui ravimit valesti võtta, siis võib see põhjustada; Leia sõnarägastikust sõnad.

## HAMMASTE TERVIS
URL: https://www.opiq.ee/kit/494/chapter/27840
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 2.8
Topics ET: matemaatika, inimene, keha, meeled, tervis, hammaste, hambad, kuidas, hambaid, õigesti, pesta, lahenda
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: HAMMASTE TERVIS; HAMBAD; KUIDAS HAMBAID ÕIGESTI PESTA?; LAHENDA; Arutle
Task examples: Vali lünka õige sõna või sõnad.; Millised liitsõnad saad? Lohista.

## JÕULUKOMBED
URL: https://www.opiq.ee/kit/494/chapter/28143
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 3.1
Topics ET: matemaatika, jõulukombed, talvine, pööripäev, kombed, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUKOMBED; TALVINE PÖÖRIPÄEV; KOMBED; LAHENDA; Arutle
Task examples: Pärast talvist pööripäeva hakkavad päevad tasapisi; Millise pööripäeva paiku hakati tähistama jõule?

## TALU
URL: https://www.opiq.ee/kit/494/chapter/28144
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 3.2
Topics ET: matemaatika, talu, maarahvas, kellele, kuulusid, talud, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: TALU; MAARAHVAS; KELLELE KUULUSID TALUD?; LAHENDA; Arutle
Task examples: Millised esemed ja tööriistad leiad pildilt? Märgi need.; Vali lünka õige sõna.

## TALUHOONED
URL: https://www.opiq.ee/kit/494/chapter/28145
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 3.3
Topics ET: matemaatika, taluhooned, rehemaja, reheahi, toit, laut, suveköök, saun, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: TALUHOONED; REHEMAJA; REHEAHI JA TOIT; AIT JA LAUT; SUVEKÖÖK JA SAUN; LAHENDA; Arutle
Task examples: Ühenda samatähendusega sõnad.; Talurahvas sõi peamiselt kodus kasvatatud toitu. Mis võis kuuluda talurahva toidulauale? Vajuta neile sõnadele.

## TALUPERE
URL: https://www.opiq.ee/kit/494/chapter/28146
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 3.4
Topics ET: matemaatika, talupere, suur, pere, peremees, perenaine, lapsed, abilised, lastel
Topics RU: математика
Topics EN: mathematics
Headings: TALUPERE; SUUR PERE; PEREMEES JA PERENAINE; LAPSED JA ABILISED; KAS LASTEL OLI VAHEL IGAV?; LAHENDA; Arutle
Task examples: Otsusta teksti põhjal, kes võisid elada ühes talus.; Kõige tähtsamad tööloomad talus olid

## MÕIS
URL: https://www.opiq.ee/kit/494/chapter/28147
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 3.5
Topics ET: matemaatika, mõis, suur, majapidamine, hooned, mõisapere, talurahvas, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MÕIS; SUUR MAJAPIDAMINE; HOONED; MÕISAPERE JA TALURAHVAS; LAHENDA; Arutle
Task examples: Uuri hoolega mõisaõue pilti. Keda või mida nägid pildil? Märgi.; Millised asjad ja loomad kuulusid pigem mõisalapsele?

## LINNAELU
URL: https://www.opiq.ee/kit/494/chapter/28148
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 3.6
Topics ET: matemaatika, linnaelu, linn, linna, maainimesed, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: LINNAELU; LINN; LINNA- JA MAAINIMESED; LAHENDA; Arutle
Task examples: Uuri hoolega linnaelu pilti. Milliseid ametimehi pildil märkasid?; Linnas oli palju toredaid paiku. Mis sa arvad, kus said käia vabrikutöölised?

## REEGLID JA SEADUSED
URL: https://www.opiq.ee/kit/494/chapter/28149
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 4.1
Topics ET: matemaatika, reeglid, seadused, käitumisreeglid, dokumendid, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: REEGLID JA SEADUSED; KÄITUMISREEGLID; SEADUSED; DOKUMENDID; LAHENDA; Arutle
Task examples: Mida tähendab lause kõik on seaduse ees võrdsed?; Eesti kõige tähtsam seadus on

## OMAND JA VÄÄRTUS
URL: https://www.opiq.ee/kit/494/chapter/28150
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 4.2
Topics ET: matemaatika, omand, väärtus, sularaha, pangakaart, laenamine, kaotamine, leidmine, arutle
Topics RU: математика
Topics EN: mathematics
Headings: OMAND JA VÄÄRTUS; VÄÄRTUS; SULARAHA JA PANGAKAART; OMAND JA LAENAMINE; KAOTAMINE JA LEIDMINE; Arutle
Task examples: Rahakotti on mõistlik hoida; Pangakaardi PIN-kood tuleb ...

## TARBIMINE JA TAAS­KASUTUS
URL: https://www.opiq.ee/kit/494/chapter/28151
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 4.3
Topics ET: matemaatika, tarbimine, taas, kasutus, asjad, teenused, materjalid, taaskasutus, pakendite
Topics RU: математика
Topics EN: mathematics
Headings: TARBIMINE JA TAAS­KASUTUS; ASJAD JA TEENUSED; MATERJALID; TAASKASUTUS; PAKENDITE JA MUU PRÜGI SORTEERIMINE; LAHENDA
Task examples: Sorteeri sõnad õigesse rühma.; Millised ametid on koolikoti valmistamises otseselt osalenud? Vajuta neile.

## MEEDIA JA REKLAAM
URL: https://www.opiq.ee/kit/494/chapter/28152
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 4.4
Topics ET: matemaatika, meedia, reklaam, keda, uskuda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MEEDIA JA REKLAAM; MEEDIA; KEDA USKUDA?; REKLAAM; Arutle
Task examples: Millisest allikast võiks infot otsida? Ühenda.; Kas lause on õige või vale? Märgi õiged laused.

## MINA JA KAASLASED. USALDUS
URL: https://www.opiq.ee/kit/494/chapter/28153
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 5.1
Topics ET: matemaatika, mina, kaaslased, usaldus, sõprus, tüdruk, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MINA JA KAASLASED. USALDUS; SÕPRUS; UUS TÜDRUK; USALDUS; LAHENDA; Arutle
Task examples: Kummal pildil on tüdruk parem sõber oma koerale? Miks?; Kas lause on õige või vale? Märgi õiged.

## VALIKUTE TAGAJÄRJED
URL: https://www.opiq.ee/kit/494/chapter/28154
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 5.2
Topics ET: matemaatika, valikute, tagajärjed, mida, teha, vastutus, kaks, eurot, ümbritsev
Topics RU: математика
Topics EN: mathematics
Headings: VALIKUTE TAGAJÄRJED; MIDA TEHA?; VASTUTUS; KAKS EUROT; ÜMBRITSEV MAAILM; LAHENDA
Task examples: Millised laused sobivad sinu kohta? Märgi need.; Vali lünka õige sõna.

## AGRESSIIVNE KÄITUMINE
URL: https://www.opiq.ee/kit/494/chapter/28155
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 5.3
Topics ET: matemaatika, loom, loomad, linnud, putukad, agressiivne, käitumine, agressiivsed, inimesed, põhjused, mida, siis
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: AGRESSIIVNE KÄITUMINE; AGRESSIIVSED LOOMAD; AGRESSIIVSED INIMESED; PÕHJUSED; MIDA SIIS TEHA?
Task examples: Lõvi on agressiivne siis, kui ...; Vali lünka õige sõna.

## LEPPIMINE JA ANDESTAMINE
URL: https://www.opiq.ee/kit/494/chapter/28156
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 5.4
Topics ET: matemaatika, leppimine, andestamine, kaile, tuleb, külaline, käskis, tõeline, vabandus
Topics RU: математика
Topics EN: mathematics
Headings: LEPPIMINE JA ANDESTAMINE; KAILE TULEB KÜLALINE; ATS KÄSKIS; TÕELINE VABANDUS
Task examples: Tüdrukud ehitavad onni.; Märt lõhub onni ära.

## NUTISEADMED I
URL: https://www.opiq.ee/kit/494/chapter/28157
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 5.5
Topics ET: matemaatika, nutiseadmed, miks, need, meile, meeldivad, teevad, õnnelikuks, turvaline
Topics RU: математика
Topics EN: mathematics
Headings: NUTISEADMED I; MIKS NEED MEILE MEELDIVAD?; KAS NUTISEADMED TEEVAD ÕNNELIKUKS?; TURVALINE KÄITUMINE VEEBIKESKKONNAS; Arutle
Task examples: Kas lause on õige või vale? Märgi õiged laused.; Vali lünka sobiv sõna.

## NUTISEADMED II
URL: https://www.opiq.ee/kit/494/chapter/28158
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 5.6
Topics ET: matemaatika, inimene, keha, meeled, tervis, nutiseadmed, magamistoas, arutle
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: NUTISEADMED II; NUTISEADMED JA TERVIS; NUTISEADMED MAGAMISTOAS; Arutle
Task examples: Nutikaelast saab hoiduda, kui ...; Väikese ekraani jälgimine lähedalt ...

## AJU JA ÕPPIMISNÕKSUD
URL: https://www.opiq.ee/kit/494/chapter/28159
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 5.7
Topics ET: matemaatika, õppimisnõksud, meeldejätmine, mida, teha, õppimine, edeneks, paremini, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: AJU JA ÕPPIMISNÕKSUD; MEELDEJÄTMINE; MIDA TEHA, ET ÕPPIMINE EDENEKS PAREMINI?; LAHENDA; Arutle
Task examples: Loe need sõnad läbi. Pööra pilk ekraanilt ära ja meenuta, mitu sõna sul meelde tuleb.; Ühenda sõnad paarideks. Loe sõnapaarid veelkord läbi. Pööra pilk ekraanilt ära ja meenuta, mitu sõnapaari sul meelde tuleb.

## Sõnaseletused
URL: https://www.opiq.ee/kit/494/chapter/27195
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 6.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/494/chapter/28142
Book: LIIKLUS. LIIKLEMISE REEGLID
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita1_est
Chapter ID: 6.2
Topics ET: matemaatika, impressum, inimeseõpetuse, õpik, algklassidele
Topics RU: математика
Topics EN: mathematics
Headings: Impressum; Inimeseõpetuse õpik algklassidele

## Inimeseõpetus algklassidele. II osa – Opiq
URL: https://www.opiq.ee/Kit/Details/579
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 139
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus algklassidele. II osa – Opiq
URL: https://www.opiq.ee/Kit/Details/579
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 164
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## LIIKLUS. LIIKLEMISE REEGLID
URL: https://www.opiq.ee/kit/579/chapter/32046
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.1
Topics ET: matemaatika, liiklus, liiklemise, reeglid, arutle
Topics RU: математика, движение, правила, движения
Topics EN: mathematics
Headings: LIIKLUS. LIIKLEMISE REEGLID; Движение. Правила движения; LIIKLUS; Arutle; EESÕIGUS JA TEE ANDMINE; ÜLEKÄIGURADA; LAHENDA; INIMESEÕPETUS EESTI KEELES
Task examples: Правила движения установлены для того, чтобы движение было ...; Liiklemise reeglid on kokku lepitud selleks, et liiklemine oleks ...

## LIIKLUS. ERILISED SÕIDUKID
URL: https://www.opiq.ee/kit/579/chapter/32047
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.2
Topics ET: matemaatika, liiklus, erilised, sõidukid, eritalituse
Topics RU: математика, движение, особые, транспортные, средства
Topics EN: mathematics
Headings: LIIKLUS. ERILISED SÕIDUKID; Движение. Особые транспортные средства; ERITALITUSE SÕIDUKID; Arutle; LAHENDA; RONGID JA RAUDTEE ÜLETAMINE; INIMESEÕPETUS EESTI KEELES
Task examples: Рассмотри картинку. Кто должен уступить дорогу, если у машины спасательной службы включены сигнальные маячки и сирена?; Vaata pilti. Kes peab andma teed, kui päästeautol vilkurid ja sireen töötavad?

## VEEOHUTUS I. ENDA OHUTUSE TAGAMINE
URL: https://www.opiq.ee/kit/579/chapter/32048
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.3
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, enda, ohutuse, tagamine
Topics RU: природоведение, вода, безопасность на воде, водоём, безопасность, воде, обеспечение, собственной, безопасности
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS I. ENDA OHUTUSE TAGAMINE; Безопасность на воде.​ ​Обеспечение собственной безопасности; UJUMINE UJULAS VÕI VEEKOGUS; 7.; 1.; 2.; 3.; 4.; 5.; 6.; AVALIK RAND; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Какие предложения верные? Отметь их.; Millised laused on õiged? Märgi need.

## VEEOHUTUS II. TEISTE AITAMINE. VEEOHUTUS TALVEL
URL: https://www.opiq.ee/kit/579/chapter/32049
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.4
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, teiste, aitamine, talvel
Topics RU: природоведение, вода, безопасность на воде, водоём, безопасность, воде, помощь, другим, зимой
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS II. TEISTE AITAMINE. VEEOHUTUS TALVEL; Безопасность на воде. Помощь другим. ​Безопасность на воде зимой​; HÄDASOLIJA MÄRKAMINE JA AITAMINE; PÄÄSTEVEST; VEEOHUTUS TALVEL; HÄDASOLIJA AITAMINE TALVEL; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Закончи предложения.; Закончи предложения.

## AJA PLANEERIMINE
URL: https://www.opiq.ee/kit/579/chapter/32441
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.5
Topics ET: matemaatika, aeg, kell, kalender, planeerimine, lahenda, arutle, inimeseõpetus, eesti
Topics RU: математика, время, часы, календарь, планирование, времени
Topics EN: mathematics, time, clock, calendar
Headings: AJA PLANEERIMINE; Планирование времени; AEG; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Подумай и соедини, с помощью чего хорошо считать ...; Nuputa ja ühenda, millega on hea arvestada ...

## PERE JA SUGULASED
URL: https://www.opiq.ee/kit/579/chapter/32442
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.6
Topics ET: matemaatika, pere, sugulased, arutle, inimeseõpetus, eesti
Topics RU: математика, семья, родственники
Topics EN: mathematics
Headings: PERE JA SUGULASED; Семья и родственники; PERE; SUGULASED; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Любовь, понимание и чувство безопас­ности ребёнку должна давать, в первую очередь, ...; Armastust, mõistmist ja turvatunnet peab lapsele pakkuma eelkõige ...

## NAABRID JA KOGUKOND
URL: https://www.opiq.ee/kit/579/chapter/32443
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.7
Topics ET: matemaatika, naabrid, kogukond, arutle, inimeseõpetus, eesti
Topics RU: математика, соседи, община
Topics EN: mathematics
Headings: NAABRID JA KOGUKOND; Соседи и община; NAABRID; Arutle; KOGUKOND; INIMESEÕPETUS EESTI KEELES
Task examples: Каким советам нужно следовать, живя в многоквартирном доме? Отметь их.; Milliseid nõuandeid võiks kortermajas elades järgida? Märgi need.

## RAHVAKOMBED SÜGISEL I. HINGEDEPÄEV
URL: https://www.opiq.ee/kit/579/chapter/32444
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.8
Topics ET: matemaatika, rahvakombed, sügisel, hingedepäev
Topics RU: математика, народные, обычаи, осенью, день, поминовения, усопших
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL I. HINGEDEPÄEV; Народные обычаи осенью. День поминовения душ усопших; RAHVAKOMBED; AASTARING; HINGEDEPÄEV; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: В давние времена в субботу вечером ...; Vanasti laupäeva õhtul ...

## RAHVAKOMBED SÜGISEL II. MARDIPÄEV JA KADRIPÄEV
URL: https://www.opiq.ee/kit/579/chapter/32445
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 1.9
Topics ET: matemaatika, rahvakombed, sügisel, mardipäev, kadripäev, lahenda, arutle, inimeseõpetus
Topics RU: математика
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL II. MARDIPÄEV JA KADRIPÄEV; MARDIPÄEV; KADRIPÄEV; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## INIMESE PÕHI­VAJADUSED
URL: https://www.opiq.ee/kit/579/chapter/32446
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.1
Topics ET: matemaatika, inimese, põhi, vajadused, põhivajadused
Topics RU: математика, основные, потребности, человека
Topics EN: mathematics
Headings: INIMESE PÕHI­VAJADUSED; Основные потребности человека; PÕHIVAJADUSED; AJU MÄRGUANDED; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Отметь, без чего мы не можем жить.; Märgi, milleta me ei saa elada.

## TERVISLIK PUHKUS JA UNI
URL: https://www.opiq.ee/kit/579/chapter/32447
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.2
Topics ET: matemaatika, tervislik, puhkus, ööpäev, arutle, piisav
Topics RU: математика, здоровый, отдых
Topics EN: mathematics
Headings: TERVISLIK PUHKUS JA UNI; Здоровый отдых и сон; ÖÖPÄEV; Arutle; PIISAV PUHKUS; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## TERVISLIK TOITUMINE JA LIIKUMINE
URL: https://www.opiq.ee/kit/579/chapter/32448
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.3
Topics ET: matemaatika, tervislik, toitumine, liikumine, toit
Topics RU: математика, здоровое, питание, движение
Topics EN: mathematics
Headings: TERVISLIK TOITUMINE JA LIIKUMINE; Здоровое питание и движение; TOIT; TALDRIKUREEGEL; LIIKUMINE; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Перетащи продукты в правильную колонку.; Lohista toiduained õigesse tulpa.

## OHUD VABAL AJAL. ESMAABI I
URL: https://www.opiq.ee/kit/579/chapter/32449
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.4
Topics ET: matemaatika, aeg, kell, kalender, ohud, vabal, ajal, esmaabi
Topics RU: математика, время, часы, календарь, опасности, свободное, первая, помощь
Topics EN: mathematics, time, clock, calendar
Headings: OHUD VABAL AJAL. ESMAABI I; Опасности в свободное время. Первая помощь; MIS ON ESMAABI?; KUKKUMINE; PEAPÕRUTUS; HAAV; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Первая помощь важна, потому что ...; Esmaabi on oluline, sest ...

## OHUD VABAL AJAL. ESMAABI II
URL: https://www.opiq.ee/kit/579/chapter/32450
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.5
Topics ET: matemaatika, aeg, kell, kalender, inimene, keha, meeled, tervis, ohud, vabal, ajal, esmaabi
Topics RU: математика, время, часы, календарь, человек, тело, чувства, здоровье, опасности, свободное, первая, помощь
Topics EN: mathematics, time, clock, calendar, human, body, senses, health
Headings: OHUD VABAL AJAL. ESMAABI II; Опасности в свободное время. Первая помощь; MÜRGISTUS; PÕLETUS; TEADVUSETA INIMENE; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Отравление могут вызвать разные вещи. Соедини пары.; Mürgistust võivad põhjustada erinevad asjad. Ühenda paarid.

## MIKS ME JÄÄME HAIGEKS?
URL: https://www.opiq.ee/kit/579/chapter/32451
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.6
Topics ET: matemaatika, inimene, keha, meeled, tervis, miks, jääme, haigeks, sagedasemad
Topics RU: математика, человек, тело, чувства, здоровье, почему, заболеваем
Topics EN: mathematics, human, body, senses, health
Headings: MIKS ME JÄÄME HAIGEKS?; Почему мы заболеваем?; TERVIS; SAGEDASEMAD LASTEHAIGUSED; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## KUIDAS ME PARANEME?
URL: https://www.opiq.ee/kit/579/chapter/32452
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.7
Topics ET: matemaatika, kuidas, paraneme, mida, teha, arst, ravimid
Topics RU: математика, выздоравливаем
Topics EN: mathematics
Headings: KUIDAS ME PARANEME?; Как мы выздоравливаем?; MIDA TEHA?; ARST JA RAVIMID; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Больному ребёнку нужны ...; Haige laps vajab ...

## HAMMASTE TERVIS
URL: https://www.opiq.ee/kit/579/chapter/32453
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 2.8
Topics ET: matemaatika, inimene, keha, meeled, tervis, hammaste, hambad, kuidas, hambaid, õigesti, pesta
Topics RU: математика, человек, тело, чувства, здоровье, зубов
Topics EN: mathematics, human, body, senses, health
Headings: HAMMASTE TERVIS; Здоровье зубов; HAMBAD; KUIDAS HAMBAID ÕIGESTI PESTA?; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## JÕULUKOMBED
URL: https://www.opiq.ee/kit/579/chapter/32454
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 3.1
Topics ET: matemaatika, jõulukombed, talvine, pööripäev, kombed, arutle
Topics RU: математика, рождественские, обычаи
Topics EN: mathematics
Headings: JÕULUKOMBED; Рождественские обычаи; TALVINE PÖÖRIPÄEV; KOMBED; Arutle; LAHENDA; INIMESEÕPETUS EESTI KEELES
Task examples: Когда стали отмечать Рождество?; Pärast talvist pööripäeva hakkavad päevad tasapisi ...

## TALU
URL: https://www.opiq.ee/kit/579/chapter/33048
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 3.2
Topics ET: matemaatika, talu, maarahvas, kellele, kuulusid, talud, lahenda
Topics RU: математика, хутор
Topics EN: mathematics
Headings: TALU; Хутор; MAARAHVAS; KELLELE KUULUSID TALUD?; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Какие предметы и орудия труда ты найдёшь на картинке? Отметь их.; Mis esemed ja tööriistad on pildil?Märgi need.

## TALUHOONED
URL: https://www.opiq.ee/kit/579/chapter/33049
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 3.3
Topics ET: matemaatika, taluhooned, rehemaja, reheahi, toit, laut
Topics RU: математика, хуторские, постройки
Topics EN: mathematics
Headings: TALUHOONED; Хуторские постройки; REHEMAJA; REHEAHI JA TOIT; AIT JA LAUT; SUVEKÖÖK JA SAUN; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Соедини слово и его значение.; Ühenda sõna ja selle tähendus.

## TALUPERE
URL: https://www.opiq.ee/kit/579/chapter/33050
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 3.4
Topics ET: matemaatika, talupere, suur, pere, peremees, perenaine
Topics RU: математика, крестьянская, семья
Topics EN: mathematics
Headings: TALUPERE; Крестьянская семья; SUUR PERE; PEREMEES JA PERENAINE; LAPSED JA ABILISED; KAS LASTEL OLI VAHEL IGAV?; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Определи на основе текста, кто могли жить на одном хуторе.; Otsusta teksti põhjal, kes võisid elada ühes talus.

## MÕIS
URL: https://www.opiq.ee/kit/579/chapter/33388
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 3.5
Topics ET: matemaatika, mõis, suur, majapidamine, hooned, mõisapere, talurahvas
Topics RU: математика, мыза
Topics EN: mathematics
Headings: MÕIS; Мыза; SUUR MAJAPIDAMINE; HOONED; MÕISAPERE JA TALURAHVAS; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Внимательно изучи картинку, на которой изображён двор мызы. Кого или что ты видишь на картинке? Отметь.; Uuri hoolega mõisaõue pilti. Keda või mida näed pildil? Märgi.

## LINNAELU
URL: https://www.opiq.ee/kit/579/chapter/33389
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 3.6
Topics ET: matemaatika, linnaelu, linn, linna, maainimesed, lahenda
Topics RU: математика, городская, жизнь
Topics EN: mathematics
Headings: LINNAELU; Городская жизнь; LINN; LINNA- JA MAAINIMESED; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Внимательно изучи картинку, на которой изображена городская жизнь. Предста­ви­телей каких профессий ты видишь?; Uuri hoolega linnaelu pilti. Milliseid ametimehi pildil märkad?

## Impressum
URL: https://www.opiq.ee/kit/579/chapter/32455
Book: Inimeseõpetus algklassidele. II osa – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3k_inimeseopetus_avita2_est
Chapter ID: 4.1
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Inimeseõpetus algklassidele, III osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/545
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 198
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## KRIIS. OHUTEAVITUS
URL: https://www.opiq.ee/kit/545/chapter/32104
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 1.1
Topics ET: matemaatika, kriis, ohuteavitus, kuidas, peaksid, käituma, saad, ohuteavituse, olulised
Topics RU: математика
Topics EN: mathematics
Headings: KRIIS. OHUTEAVITUS; MIS ON KRIIS?; OHUTEAVITUS; KUIDAS PEAKSID KÄITUMA, KUI SAAD OHUTEAVITUSE?; OLULISED TELEFONINUMBRID JA KODULEHEKÜLJED KRIISI KORRAL
Task examples: Vaata pilti. Otsusta, kas tegemist on kriisi või lihtsalt halva olukorraga.; Vaata pilti. Otsusta, kas tegemist on kriisi või lihtsalt halva olukorraga.

## KRIIS. MIDA SAAN MINA TEHA?
URL: https://www.opiq.ee/kit/545/chapter/32105
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 1.2
Topics ET: matemaatika, kriis, mida, saan, mina, teha, kriisiks, valmistumine, kodused
Topics RU: математика
Topics EN: mathematics
Headings: KRIIS. MIDA SAAN MINA TEHA?; KRIISIKS VALMISTUMINE; KODUSED VARUD; TEISTE ABISTAMINE
Task examples: Mida tähendab kriisiks valmistumine?; Kujutle, et pead kiiresti kodust lahkuma ja saad kaasa võtta ainult 4 asja. Märgi, mis sa kaasa võtaksid.

## OHUTUS. TULI JA TULEKAHJU
URL: https://www.opiq.ee/kit/545/chapter/32106
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 1.3
Topics ET: matemaatika, ohutus, tuli, tulekahju, miks, tuld, vaja, vajab, alati
Topics RU: математика
Topics EN: mathematics
Headings: OHUTUS. TULI JA TULEKAHJU; MIKS ON TULD VAJA?; TULI VAJAB ALATI JÄRELEVALVET; ELEKTER; MIDA TEHA TULEKAHJU KORRAL?
Task examples: Vali, millal on tuli kasulik ja millal ohtlik.; Vaata pilti. Kas need küünlad põlevad ohutult? Põhjenda.

## LIIKUMINE JA TERVIS
URL: https://www.opiq.ee/kit/545/chapter/32107
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 2.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, liikumine, tervisele, kasulik, igapäevane
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: LIIKUMINE JA TERVIS; LIIKUMINE ON TERVISELE KASULIK; IGAPÄEVANE LIIKUMINE
Task examples: Vali kõik õiged vastused.; Kuidas sina päeva jooksul liigud?

## LIIKUMIS­OSKUSED
URL: https://www.opiq.ee/kit/545/chapter/32108
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 2.2
Topics ET: matemaatika, liikumis, oskused, oskuste, harjutamine, kehalised, võimed
Topics RU: математика
Topics EN: mathematics
Headings: LIIKUMIS­OSKUSED; OSKUSTE HARJUTAMINE; KEHALISED VÕIMED
Task examples: Milliseid teadmisi ja oskusi on sul tarvis osata selleks, et ...; Milliseid teadmisi ja oskusi on sul tarvis osata selleks, et ...

## TOITUMINE, I
URL: https://www.opiq.ee/kit/545/chapter/32109
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 2.3
Topics ET: matemaatika, toitumine, mida, saame, toidust, mitmekesine, tasakaalustatud, toit
Topics RU: математика
Topics EN: mathematics
Headings: TOITUMINE, I; MIDA SAAME TOIDUST?; MITMEKESINE JA TASAKAALUSTATUD TOIT
Task examples: Märgi, millised on toidud.; Märgi, millised on toitained.

## TOITUMINE, II
URL: https://www.opiq.ee/kit/545/chapter/32110
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 2.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, toitumine, milline, hommikusöök, tervisele, kasulik, peaks, olema, lõunasöök
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: TOITUMINE, II; MILLINE HOMMIKUSÖÖK ON TERVISELE KASULIK?; MILLINE PEAKS OLEMA LÕUNASÖÖK?; MILLINE ON TERVIST TOETAV VAHEPALA?; MILLIST ÕHTUSÖÖKI VAJAB KEHA?
Task examples: Miks on hommikusöök oluline?; Nimeta koolitoite, mis sulle maitsevad.

## INTERNET
URL: https://www.opiq.ee/kit/545/chapter/32111
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 3.1
Topics ET: matemaatika, internet, nutikas, internetikasutus, ekraaniaeg
Topics RU: математика
Topics EN: mathematics
Headings: INTERNET; MIS ON INTERNET?; NUTIKAS INTERNETIKASUTUS; EKRAANIAEG
Task examples: Märgi, mille jaoks sina kõige rohkem internetti kasutad.; Märgi tegevused, mis aitavad sul internetis midagi uut õppida.

## INFO INTERNETIS
URL: https://www.opiq.ee/kit/545/chapter/32112
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 3.2
Topics ET: matemaatika, info, internetis, targalt, tehisaru, valeinfo, infomullid
Topics RU: математика
Topics EN: mathematics
Headings: INFO INTERNETIS; TARGALT INTERNETIS; TEHISARU; VALEINFO; INFOMULLID
Task examples: Vaata pilti. Kas see pilt on päris või muudetud?; Milliseid ülesandeid tasub tehisarule anda?

## NETIREEGLID. MINA JA TEISED
URL: https://www.opiq.ee/kit/545/chapter/32113
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 3.3
Topics ET: matemaatika, netireeglid, mina, teised, suhtlemine, internetis, mida, tasub, internetti
Topics RU: математика
Topics EN: mathematics
Headings: NETIREEGLID. MINA JA TEISED; SUHTLEMINE INTERNETIS; MIDA TASUB INTERNETTI POSTITADA?; TEISTEST PILTIDE JA VIDEOTE POSTITAMINE; SA EI OLE MUREGA ÜKSI!
Task examples: Kuidas meeldib sulle kõige rohkem suhelda?; Loe näiteid ja otsusta, kas see on isiklik või tavaline info. Lohista vastused õigesse lahtrisse.

## NETIREEGLID. TURVALISELT INTERNETIS
URL: https://www.opiq.ee/kit/545/chapter/32114
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 3.4
Topics ET: matemaatika, netireeglid, turvaliselt, internetis, netis, parool, vanusepiirang, tasuta, tasuline
Topics RU: математика
Topics EN: mathematics
Headings: NETIREEGLID. TURVALISELT INTERNETIS; TURVALISELT NETIS; PAROOL; VANUSEPIIRANG; TASUTA VÕI TASULINE?; INTERNETILÕKSUD JA PETTUSED
Task examples: Kuidas sina internetis ettevaatlik oled? Kirjuta välja üks oluline reegel.; Vali kõik väited, mis aitavad luua turvalise ja tugeva parooli.

## PÕHI­VAJADUSED. VAJADUSTE PÜRAMIID
URL: https://www.opiq.ee/kit/545/chapter/32115
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.1
Topics ET: matemaatika, põhi, vajadused, vajaduste, püramiid, põhivajadused, turvatunne, kuuluvusvajadus, saavutus
Topics RU: математика
Topics EN: mathematics
Headings: PÕHI­VAJADUSED. VAJADUSTE PÜRAMIID; PÕHIVAJADUSED; TURVATUNNE; KUULUVUSVAJADUS; SAAVUTUS- JA TUNNUSTUS­VAJADUS; ARENEMISVAJADUS; VAJADUSTE PÜRAMIID
Task examples: Märgi linnukesega inimese põhivajadused.; Mõtiskle, milline inimene sina tahaksid olla. Vali, mis sind kõige rohkem aitab selliseks saada.

## ÕPPIMINE. EES­MÄRKIDE SEADMINE
URL: https://www.opiq.ee/kit/545/chapter/32124
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.10
Topics ET: matemaatika, õppimine, märkide, seadmine, kuidas, lihtsam, õppida, aitab, endale
Topics RU: математика
Topics EN: mathematics
Headings: ÕPPIMINE. EES­MÄRKIDE SEADMINE; ÕPPIMINE; KUIDAS ON LIHTSAM ÕPPIDA?; MIS AITAB ENDALE PÜSTITATUD EESMÄRKI SAAVUTADA?
Task examples: Kas sul jäävad uued teadmised kiirelt meelde või pigem läheb aega?; Vaata pilte. Kummas toas oleks parem õppida? Miks?

## TAKISTUSTE ÜLETAMINE
URL: https://www.opiq.ee/kit/545/chapter/32125
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.11
Topics ET: matemaatika, takistuste, ületamine, kõik, kohtavad, takistusi, emotsioonide, juhtimine, rahunemis
Topics RU: математика
Topics EN: mathematics
Headings: TAKISTUSTE ÜLETAMINE; KÕIK KOHTAVAD TAKISTUSI; EMOTSIOONIDE JUHTIMINE; LOO OMA RAHUNEMIS­PLAAN
Task examples: Mis oleks hea mõte, kui vanad lahendused ei toimi?; Mida võiksid teha, kui miski ei õnnestu?

## INIMESED ON ERINEVAD
URL: https://www.opiq.ee/kit/545/chapter/32116
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.2
Topics ET: matemaatika, inimesed, erinevad, erinevused, sarnasused
Topics RU: математика
Topics EN: mathematics
Headings: INIMESED ON ERINEVAD; ERINEVUSED JA SARNASUSED
Task examples: Võrdle tabeli abil Liisit ja Tomi. Mis on neil erinevat?; Võrdle tabeli abil Liisit ja Tomi. Mis on neil mõlemal sarnane?

## INIMESED ON ERINEVAD. SALLIVUS
URL: https://www.opiq.ee/kit/545/chapter/32117
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.3
Topics ET: matemaatika, inimesed, erinevad, sallivus, ühesugune, maailm, erilised, vajadused, abivahendid
Topics RU: математика
Topics EN: mathematics
Headings: INIMESED ON ERINEVAD. SALLIVUS; ÜHESUGUNE MAAILM; ERILISED VAJADUSED; ABIVAHENDID; KIUSAMINE
Task examples: Mis värvi on sinu sõbra silmad?; Mis värvi on sinu silmad?

## VAIMNE TERVIS
URL: https://www.opiq.ee/kit/545/chapter/32118
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, vaimne, kuidas, päriselt, läheb, vaimse, tervise, mõjutajad
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: VAIMNE TERVIS; KUIDAS MUL PÄRISELT LÄHEB?; VAIMSE TERVISE MÕJUTAJAD; KA TUNDED VAJAVAD HOOLT; KEERULISED OLUKORRAD
Task examples: Kuidas aitab liikumine mõjutada meie vaimset tervist?; Mida võiks teha, kui tunned end kontrolltöö ajal ärevalt või pinges?

## MINAPILT. KUIDAS MA ENNAST NÄEN?
URL: https://www.opiq.ee/kit/545/chapter/32119
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.5
Topics ET: matemaatika, minapilt, kuidas, ennast, näen, suhtlus, endaga
Topics RU: математика
Topics EN: mathematics
Headings: MINAPILT. KUIDAS MA ENNAST NÄEN?; KUIDAS MA ENNAST NÄEN?; SUHTLUS ENDAGA
Task examples: Uuri pilte. Kumb laps on alla andmas?; Uuri pilte. Kumb laps kogeb küll raskusi, aga pingutab edasi ega ole nõus alla andma?

## RÜNDAV KÄITUMINE. KIUSAMINE
URL: https://www.opiq.ee/kit/545/chapter/32120
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.6
Topics ET: matemaatika, ründav, käitumine, kiusamine, valikute, tagajärjed, miks, inimesed, ründavalt
Topics RU: математика
Topics EN: mathematics
Headings: RÜNDAV KÄITUMINE. KIUSAMINE; VALIKUTE TAGAJÄRJED; MIKS INIMESED RÜNDAVALT KÄITUVAD?; KIUSAMINE
Task examples: Vaata pilte. Kumma küsimuse peale laenaks sina parema meelega sellele poisile joonlauda?; Mida saaksid teha, kui sinu negatiivsed tunded muutuvad väga tugevaks? Tee linnuke nende tegevuste juurde, mis võiksid aidata sul rahuneda.

## KOOSTÖÖ. VÕIT JA KAOTUS
URL: https://www.opiq.ee/kit/545/chapter/32121
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.7
Topics ET: matemaatika, koostöö, võit, kaotus, mäng, ainult, tähtis
Topics RU: математика
Topics EN: mathematics
Headings: KOOSTÖÖ. VÕIT JA KAOTUS; KOOSTÖÖ JA MÄNG; VÕIT JA KAOTUS; KAS AINULT VÕIT ON TÄHTIS?
Task examples: Miks on hea teha koostööd?; Miks ei ole kaotamine alati halb?

## KUIDAS EBA­ÕNNESTUMI­SEGA TOIME TULLA?
URL: https://www.opiq.ee/kit/545/chapter/32122
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.8
Topics ET: matemaatika, kuidas, õnnestumi, sega, toime, tulla, kaotamine, tunded, mida
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS EBA­ÕNNESTUMI­SEGA TOIME TULLA?; KAOTAMINE JA TUNDED; MIDA EBAÕNNESTUMISEST ÕPPIDA?
Task examples: Mis nõu sa annaksid sõbrale, kes tahab igas mängus alati võita ja on kaotades väga endast väljas?; Miks ei pea ebaõnnestumist kartma? Vali kõik sobivad vastused.

## SUHTLEMINE. TEISTEGA ARVESTAMINE
URL: https://www.opiq.ee/kit/545/chapter/32123
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 4.9
Topics ET: matemaatika, suhtlemine, teistega, arvestamine, empaatia, miks, vaja, teiste, tundeid
Topics RU: математика
Topics EN: mathematics
Headings: SUHTLEMINE. TEISTEGA ARVESTAMINE; EMPAATIA; MIKS ON VAJA TEISTE TUNDEID MÄRGATA JA NEID OLULISEKS PIDADA?; ENDA TUNNETE VÄLJENDAMINE; MIDA ME TEISTE INIMESTE SUHTES TÄHELE PANEME?
Task examples: Vaata pilti. Kuidas poiss saaks sõbra murele empaatiliselt vastata?; Miks on hea märgata teiste tundeid?

## ELU EESTI VABARIIGI ALGUSAJAL 1918–1939
URL: https://www.opiq.ee/kit/545/chapter/30088
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.1
Topics ET: matemaatika, aeg, kell, kalender, eesti, vabariigi, algusajal, eestiaegne, talupidamine, kodu, laste, elust
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: ELU EESTI VABARIIGI ALGUSAJAL 1918–1939; EESTI AEG; EESTIAEGNE TALUPIDAMINE; EESTI KODU; LASTE ELUST; KUIDAS EESTI AJAL VABA AEGA VEEDETI?; EESTIAEGSED ASJAD
Task examples: Millised laused sobivad Eesti aja kohta? Märgi need.; Märgi, mis võis moodsama talumaja juurde kuuluda.

## LISA. LIPP JA VAPP
URL: https://www.opiq.ee/kit/545/chapter/30465
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.10
Topics ET: matemaatika, lisa, lipp, vapp, lipud, vapid, ammustel, aegadel, eesti
Topics RU: математика
Topics EN: mathematics
Headings: LISA. LIPP JA VAPP; LIPUD JA VAPID AMMUSTEL AEGADEL; EESTI LIPP; VAPID MINEVIKUS; PEREMÄRGID; EESTI VAPP
Task examples: Märgi linnukesega, millised neist on trikoloorid.; Kas tunned ära, milliste riikide lipud need on?

## ELU NÕUKOGUDE OKUPATSIOONI AJAL 1944–1991
URL: https://www.opiq.ee/kit/545/chapter/30089
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.2
Topics ET: matemaatika, aeg, kell, kalender, nõukogude, okupatsiooni, ajal, kolhoosis, kodune, lapsepõlv, kolhoosiajal, mida
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: ELU NÕUKOGUDE OKUPATSIOONI AJAL 1944–1991; NÕUKOGUDE AEG; ELU KOLHOOSIS; KODUNE ELU; LAPSEPÕLV KOLHOOSIAJAL; MIDA TEHTI VABAL AJAL?; NÕUKOGUDE-AEGSED ASJAD
Task examples: Vali seletuse juurde sobiv mõiste.; Mis nendest võis ühes kolhoosis olla? Märgi.

## ELU VABAS EESTIS, I
URL: https://www.opiq.ee/kit/545/chapter/30090
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.3
Topics ET: matemaatika, vabas, eestis, taas, vaba, eesti
Topics RU: математика
Topics EN: mathematics
Headings: ELU VABAS EESTIS, I; TAAS VABA EESTI
Task examples: Millal Eesti iseseisvus taastati?; Millal sai Eesti esimest korda iseseisvaks?

## ELU VABAS EESTIS, II
URL: https://www.opiq.ee/kit/545/chapter/30087
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.4
Topics ET: matemaatika, vabas, eestis
Topics RU: математика
Topics EN: mathematics
Headings: ELU VABAS EESTIS, II
Task examples: Ühenda ajastu sobiva lausega.; Ühenda ajastu sobiva lausega.

## MEIE RIIK ON EESTI VABARIIK
URL: https://www.opiq.ee/kit/545/chapter/30460
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.5
Topics ET: matemaatika, meie, riik, eesti, vabariik, rahvas, õigus, kehtestada, reegleid
Topics RU: математика
Topics EN: mathematics
Headings: MEIE RIIK ON EESTI VABARIIK; MIS ON RIIK?; RAHVAS; MAA-ALA; ÕIGUS KEHTESTADA REEGLEID EHK SEADUSI
Task examples: Märgi, kas väide on õige.; Mis on Eesti kõige tähtsam seadus?

## RIIGI ELU KORRALDAMINE
URL: https://www.opiq.ee/kit/545/chapter/30461
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.6
Topics ET: matemaatika, riigi, korraldamine, ühiselu, seadusandlik, võim, täidesaatev, kohtuvõim, president
Topics RU: математика
Topics EN: mathematics
Headings: RIIGI ELU KORRALDAMINE; ÜHISELU KORRALDAMINE; SEADUSANDLIK VÕIM; TÄIDESAATEV VÕIM; KOHTUVÕIM; PRESIDENT
Task examples: Millise elukorralduse on valinud Eesti riik?; Kes võtab Eestis seadusi vastu?

## DEMOKRAATIA
URL: https://www.opiq.ee/kit/545/chapter/30462
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.7
Topics ET: matemaatika, demokraatia, rahva, võim, võrdsus, põhiõigused
Topics RU: математика
Topics EN: mathematics
Headings: DEMOKRAATIA; RAHVA VÕIM; VÕRDSUS JA PÕHIÕIGUSED
Task examples: Kas Eestis tähendavad parlament ja riigikogu sama asja?; Kuidas nimetatakse Eesti kodanike esinduskogu?

## EESTI RIIK TEISTE RIIKIDE SEAS
URL: https://www.opiq.ee/kit/545/chapter/30463
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.8
Topics ET: matemaatika, eesti, riik, teiste, riikide, seas, naabrid, koostöö, liidud
Topics RU: математика
Topics EN: mathematics
Headings: EESTI RIIK TEISTE RIIKIDE SEAS; EESTI NAABRID; KOOSTÖÖ; RIIKIDE LIIDUD
Task examples: Millised neist riikidest on Eesti maismaanaabrid, millised ülemerenaabrid?; Millised neist on liidud, millesse Eesti kuulub? Märgi need linnukesega.

## RIIGI ÜLALPIDAMINE. MAKSUD
URL: https://www.opiq.ee/kit/545/chapter/30464
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 5.9
Topics ET: matemaatika, riigi, ülalpidamine, maksud, käibemaks, maks, kehtib, kõigile, ettevõtte
Topics RU: математика
Topics EN: mathematics
Headings: RIIGI ÜLALPIDAMINE. MAKSUD; MAKSUD; KÄIBEMAKS – MAKS, MIS KEHTIB KÕIGILE; ETTEVÕTTE JA TÖÖTAJA MAKSUD; MILLE PEALE ME OMA ÜHISRAHA KULUTAME?
Task examples: Kes maksavad käibemaksu?

## Impressum
URL: https://www.opiq.ee/kit/545/chapter/32126
Book: KRIIS. OHUTEAVITUS
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 3k_inimeseopetus_avita3_est
Chapter ID: 6.1
Topics ET: matemaatika, impressum, inimeseõpetuse, õpik, algklassidele
Topics RU: математика
Topics EN: mathematics
Headings: Impressum; Inimeseõpetuse õpik algklassidele
