## Starter Book. English step by step 1 – Opiq
URL: https://www.opiq.ee/Kit/Details/453
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1
Topics ET: matemaatika, starter, book, english, step, opiq
Topics RU: математика
Topics EN: mathematics

## Starter Book. English step by step 1 – Opiq
URL: https://www.opiq.ee/Kit/Details/453
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 37
Topics ET: matemaatika, starter, book, english, step, opiq
Topics RU: математика
Topics EN: mathematics

## Unit 1
URL: https://www.opiq.ee/kit/453/chapter/24658
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.1
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 1

## Unit 10
URL: https://www.opiq.ee/kit/453/chapter/24667
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.10
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 10; The [ə] sound symbol; Exercise 2; Exercise 3

## Unit 11
URL: https://www.opiq.ee/kit/453/chapter/24668
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.11
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbols, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 11; The [ɔː] and [i:] sound symbols; Exercise 2; Exercise 3

## Unit 12
URL: https://www.opiq.ee/kit/453/chapter/24669
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.12
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbols, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 12; The [ɔɪ] and [ɜ:] sound symbols; Exercise 2; Exercise 3

## Unit 13
URL: https://www.opiq.ee/kit/453/chapter/24670
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.13
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbols, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 13; The [ɑː] and [aɪ] sound symbols; Exercise 2; Exercise 4

## Unit 14
URL: https://www.opiq.ee/kit/453/chapter/24671
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.14
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbols, exercise, bingo
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 14; The [ŋ] and [z] sound symbols; Exercise 2; Exercise 3; Exercise 5; BINGO

## Unit 15
URL: https://www.opiq.ee/kit/453/chapter/24672
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.15
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 15; The [ð] sound symbol; Exercise 2; Exercise 3

## Unit 16
URL: https://www.opiq.ee/kit/453/chapter/24673
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.16
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 16; The [w] sound symbol; Exercise 2

## Unit 17
URL: https://www.opiq.ee/kit/453/chapter/24674
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.17
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 17; The [θ] sound symbol; Exercise 1; Exercise 3; Exercise 4

## Unit 18
URL: https://www.opiq.ee/kit/453/chapter/24675
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.18
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 18; Exercise 2

## Unit 19
URL: https://www.opiq.ee/kit/453/chapter/24676
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.19
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, phonetic, transcriptions, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 19; Phonetic transcriptions; Exercise 1

## Unit 2
URL: https://www.opiq.ee/kit/453/chapter/24659
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.2
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 2; The [e] sound symbol; Exercise 3

## Unit 20
URL: https://www.opiq.ee/kit/453/chapter/24677
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.20
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, phonetic, transcriptions, exercise, alphabet
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 20; Phonetic transcriptions; Exercise 1; Exercise 2; Exercise 4; THE ALPHABET

## Unit 21
URL: https://www.opiq.ee/kit/453/chapter/24678
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.21
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, bingo, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 21; BINGO; ABC; Exercise ABC 1; Exercise ABC 2; Exercise ABC 3

## Unit 22
URL: https://www.opiq.ee/kit/453/chapter/24679
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.22
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 22; Words; ABC; Exercise ABC 1

## Unit 23
URL: https://www.opiq.ee/kit/453/chapter/24680
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.23
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 23; Words

## Unit 24
URL: https://www.opiq.ee/kit/453/chapter/24681
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.24
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 24; ABC; Exercise ABC 1

## Unit 25
URL: https://www.opiq.ee/kit/453/chapter/24682
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.25
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 25; Words; ABC; Exercise ABC 5; Exercise ABC 6

## Unit 26
URL: https://www.opiq.ee/kit/453/chapter/24683
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.26
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 26; Words; Exercise 1; ABC; Exercise ABC 1; Exercise ABC 3

## Unit 27
URL: https://www.opiq.ee/kit/453/chapter/24684
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.27
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 27; Words; Exercise 2; ABC; Exercise ABC 1

## Unit 28
URL: https://www.opiq.ee/kit/453/chapter/24685
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.28
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 28; Words; ABC; Exercise ABC 1

## Unit 29
URL: https://www.opiq.ee/kit/453/chapter/24686
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.29
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 29; Words; ABC; Exercise ABC 1

## Unit 3
URL: https://www.opiq.ee/kit/453/chapter/24660
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.3
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 3; The [ɒ] sound symbol; Exercise 2; Exercise 3

## Unit 30
URL: https://www.opiq.ee/kit/453/chapter/24687
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.30
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 30; Words; ABC; Exercise ABC 1; Exercise ABC 2

## Unit 31
URL: https://www.opiq.ee/kit/453/chapter/24688
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.31
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, words, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 31; Words; ABC; Exercise ABC 1

## Unit 32
URL: https://www.opiq.ee/kit/453/chapter/24689
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.32
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 32; ABC; Exercise ABC 1; Exercise ABC 3

## Unit 33
URL: https://www.opiq.ee/kit/453/chapter/24690
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.33
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 33; ABC; Exercise ABC 1

## Unit 34
URL: https://www.opiq.ee/kit/453/chapter/24691
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.34
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, bingo, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 34; BINGO; ABC; Exercise ABC 1

## Unit 35
URL: https://www.opiq.ee/kit/453/chapter/24692
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.35
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, game
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 35; GAME

## Unit 4
URL: https://www.opiq.ee/kit/453/chapter/24661
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.4
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 4; The [ʃ] sound symbol; Exercise 2; Exercise 3

## Unit 5
URL: https://www.opiq.ee/kit/453/chapter/24662
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.5
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbols, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 5; The [ɪ] and [tʃ] sound symbols; Exercise 2; Exercise 3

## Unit 6
URL: https://www.opiq.ee/kit/453/chapter/24663
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.6
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 6; The [dʒ] sound symbol; Exercise 2

## Unit 7
URL: https://www.opiq.ee/kit/453/chapter/24664
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.7
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 7; The [ʌ] sound symbol; Exercise 2; Exercise 3

## Unit 8
URL: https://www.opiq.ee/kit/453/chapter/24665
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.8
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbol, exercise, bingo
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 8; The [æ] sound symbol; Exercise 2; Exercise 4; BINGO

## Unit 9
URL: https://www.opiq.ee/kit/453/chapter/24666
Book: eesti keel 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: ma_õpin_eesti_keeles._ii_osa._я_учусь_на_эстонском_языке._часть_ii
Chapter ID: 1.9
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sound, symbols, exercise
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Unit 9; The [u] and [u:] sound symbols; Exercise 2; Exercise 6
