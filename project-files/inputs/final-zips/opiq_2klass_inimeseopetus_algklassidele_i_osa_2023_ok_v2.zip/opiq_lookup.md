## Inimeseõpetus algklassidele, I osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/449
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 41
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus algklassidele, I osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/449
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 88
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus algklassidele, II osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/494
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 169
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus algklassidele, II osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/494
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 174
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## LIIKLUS. LIIKLEMISE REEGLID
URL: https://www.opiq.ee/kit/494/chapter/27186
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.1
Topics ET: matemaatika, liiklus, liiklemise, reeglid, arutle, eesõigus, andmine, ülekäigurada, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS. LIIKLEMISE REEGLID; LIIKLUS; Arutle; EESÕIGUS JA TEE ANDMINE; ÜLEKÄIGURADA; LAHENDA
Task examples: Liiklemise reeglid on kokku lepitud selleks, et liiklemine oleks; Kõnniteel on eesõigus liikuda

## LIIKLUS. ERILISED SÕIDUKID
URL: https://www.opiq.ee/kit/494/chapter/27187
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.2
Topics ET: matemaatika, liiklus, erilised, sõidukid, eritalituse, lahenda, rongid, raudtee, ületamine
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS. ERILISED SÕIDUKID; ERITALITUSE SÕIDUKID; LAHENDA; RONGID JA RAUDTEE ÜLETAMINE
Task examples: Vaata pilti. Kes peab andma teed, kui päästeautol vilkurid ja sireen töötavad?; Lohista sõiduk õigesse tulpa.

## VEEOHUTUS I
URL: https://www.opiq.ee/kit/494/chapter/27188
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.3
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, ujumine, ujulas, veekogus, avalik, rand, arutle
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS I; UJUMINE UJULAS VÕI VEEKOGUS; 1.; 2.; 3.; 4.; 5.; 6.; 7.; AVALIK RAND; Arutle
Task examples: Millised laused on õiged? Märgi need.; Vali lünka õige sõna.

## VEEOHUTUS II
URL: https://www.opiq.ee/kit/494/chapter/27189
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.4
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, hädasolija, märkamine, aitamine, päästevest, talvel, arutle
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS II; HÄDASOLIJA MÄRKAMINE JA AITAMINE; PÄÄSTEVEST; VEEOHUTUS TALVEL; HÄDASOLIJA AITAMINE TALVEL; Arutle
Task examples: Uppumisohtu sattunud laps; Millist sõiduvahendit kasutades tuleb päästevest enne selga panna?

## AJA PLANEERIMINE
URL: https://www.opiq.ee/kit/494/chapter/27190
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.5
Topics ET: matemaatika, aeg, kell, kalender, planeerimine, lahenda, arutle
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: AJA PLANEERIMINE; AEG; LAHENDA; Arutle
Task examples: Nuputa ja ühenda, millega on hea arvestada ...; Miks on vaja parajalt aega varuda?

## PERE JA SUGULASED
URL: https://www.opiq.ee/kit/494/chapter/27191
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.6
Topics ET: matemaatika, pere, sugulased, arutle
Topics RU: математика
Topics EN: mathematics
Headings: PERE JA SUGULASED; PERE; SUGULASED; Arutle
Task examples: Armastust, mõistmist ja turvatunnet peab lapsele pakkuma eelkõige; Otsusta, kas tegu on lapse õiguse või kohustusega.

## NAABRID JA KOGUKOND
URL: https://www.opiq.ee/kit/494/chapter/27192
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.7
Topics ET: matemaatika, naabrid, kogukond, arutle
Topics RU: математика
Topics EN: mathematics
Headings: NAABRID JA KOGUKOND; NAABRID; KOGUKOND; Arutle
Task examples: Milliseid nõuandeid võiks kortermajas elades järgida? Märgi need.; Kas lause on õige või vale?

## RAHVAKOMBED SÜGISEL I
URL: https://www.opiq.ee/kit/494/chapter/27193
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.8
Topics ET: matemaatika, rahvakombed, sügisel, aastaring, hingedepäev, arutle
Topics RU: математика
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL I; RAHVAKOMBED; AASTARING; HINGEDEPÄEV; Arutle
Task examples: Millise rahvakalendri tähtpäevaga on perenaise ütlus seotud?; Mis aastaajal see tähtpäev on?

## RAHVAKOMBED SÜGISEL II
URL: https://www.opiq.ee/kit/494/chapter/27194
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 1.9
Topics ET: matemaatika, rahvakombed, sügisel, mardipäev, kadripäev, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL II; MARDIPÄEV; KADRIPÄEV; LAHENDA; Arutle
Task examples: Vali lünka õige(d) sõna(d).; Kadrisandi riided on tavaliselt

## INIMESE PÕHIVAJADUSED
URL: https://www.opiq.ee/kit/494/chapter/27833
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.1
Topics ET: matemaatika, inimese, põhivajadused, märguanded, arutle
Topics RU: математика
Topics EN: mathematics
Headings: INIMESE PÕHIVAJADUSED; PÕHIVAJADUSED; AJU MÄRGUANDED; Arutle
Task examples: Märgi linnukesega, milleta me ei saa elada.; Lohista sõna õigesse tulpa.

## TERVISLIK PUHKUS JA UNI
URL: https://www.opiq.ee/kit/494/chapter/27834
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.2
Topics ET: matemaatika, tervislik, puhkus, ööpäev, piisav
Topics RU: математика
Topics EN: mathematics
Headings: TERVISLIK PUHKUS JA UNI; ÖÖPÄEV; PIISAV PUHKUS
Task examples: Vali lünka õige sõna.; Uuri pildilt, mis kell Robin hommikuti ärkab. Mis kell ta peaks õhtul voodisse minema, et ta saaks öösel 9 tundi magada? Võta abiks seinakell.

## TERVISLIK TOITUMINE JA LIIKUMINE
URL: https://www.opiq.ee/kit/494/chapter/27835
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.3
Topics ET: matemaatika, tervislik, toitumine, liikumine, toit, taldrikureegel, arutle
Topics RU: математика
Topics EN: mathematics
Headings: TERVISLIK TOITUMINE JA LIIKUMINE; TOIT; TALDRIKUREEGEL; LIIKUMINE; Arutle
Task examples: Ühenda lause algus ja lõpp.; Lohista toiduained õigesse kohta.

## OHUD VABAL AJAL. ESMAABI I
URL: https://www.opiq.ee/kit/494/chapter/27836
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.4
Topics ET: matemaatika, ohud, vabal, ajal, esmaabi, kukkumine, peapõrutus, haav, arutle
Topics RU: математика
Topics EN: mathematics
Headings: OHUD VABAL AJAL. ESMAABI I; MIS ON ESMAABI?; KUKKUMINE; PEAPÕRUTUS; HAAV; Arutle
Task examples: Esmaabi on oluline, sest; Vali lünka õige sõna.

## OHUD VABAL AJAL. ESMAABI II
URL: https://www.opiq.ee/kit/494/chapter/27837
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.5
Topics ET: matemaatika, inimene, keha, meeled, tervis, ohud, vabal, ajal, esmaabi, mürgistus, põletus, teadvuseta
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: OHUD VABAL AJAL. ESMAABI II; MÜRGISTUS; PÕLETUS; TEADVUSETA INIMENE; LAHENDA; Arutle
Task examples: Mürgistust võivad põhjustada erinevad asjad. Ühenda paarid.; Mis võib põhjustada põletust, kui olla hooletu?

## MIKS ME JÄÄME HAIGEKS?
URL: https://www.opiq.ee/kit/494/chapter/27838
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.6
Topics ET: matemaatika, inimene, keha, meeled, tervis, miks, jääme, haigeks, sagedasemad, lastehaigused, lahenda, arutle
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MIKS ME JÄÄME HAIGEKS?; TERVIS; SAGEDASEMAD LASTEHAIGUSED; LAHENDA; Arutle
Task examples: Vali lünka õiged sõnad.; Mida teha, et püsida terve? Ühenda sobiva pildiga.

## KUIDAS ME PARANEME?
URL: https://www.opiq.ee/kit/494/chapter/27839
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.7
Topics ET: matemaatika, kuidas, paraneme, mida, teha, arst, ravimid, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS ME PARANEME?; MIDA TEHA?; ARST JA RAVIMID; LAHENDA; Arutle
Task examples: Kui ravimit valesti võtta, siis võib see põhjustada; Leia sõnarägastikust sõnad.

## HAMMASTE TERVIS
URL: https://www.opiq.ee/kit/494/chapter/27840
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 2.8
Topics ET: matemaatika, inimene, keha, meeled, tervis, hammaste, hambad, kuidas, hambaid, õigesti, pesta, lahenda
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: HAMMASTE TERVIS; HAMBAD; KUIDAS HAMBAID ÕIGESTI PESTA?; LAHENDA; Arutle
Task examples: Vali lünka õige sõna või sõnad.; Millised liitsõnad saad? Lohista.

## JÕULUKOMBED
URL: https://www.opiq.ee/kit/494/chapter/28143
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 3.1
Topics ET: matemaatika, jõulukombed, talvine, pööripäev, kombed, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUKOMBED; TALVINE PÖÖRIPÄEV; KOMBED; LAHENDA; Arutle
Task examples: Pärast talvist pööripäeva hakkavad päevad tasapisi; Millise pööripäeva paiku hakati tähistama jõule?

## TALU
URL: https://www.opiq.ee/kit/494/chapter/28144
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 3.2
Topics ET: matemaatika, talu, maarahvas, kellele, kuulusid, talud, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: TALU; MAARAHVAS; KELLELE KUULUSID TALUD?; LAHENDA; Arutle
Task examples: Millised esemed ja tööriistad leiad pildilt? Märgi need.; Vali lünka õige sõna.

## TALUHOONED
URL: https://www.opiq.ee/kit/494/chapter/28145
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 3.3
Topics ET: matemaatika, taluhooned, rehemaja, reheahi, toit, laut, suveköök, saun, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: TALUHOONED; REHEMAJA; REHEAHI JA TOIT; AIT JA LAUT; SUVEKÖÖK JA SAUN; LAHENDA; Arutle
Task examples: Ühenda samatähendusega sõnad.; Talurahvas sõi peamiselt kodus kasvatatud toitu. Mis võis kuuluda talurahva toidulauale? Vajuta neile sõnadele.

## TALUPERE
URL: https://www.opiq.ee/kit/494/chapter/28146
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 3.4
Topics ET: matemaatika, talupere, suur, pere, peremees, perenaine, lapsed, abilised, lastel
Topics RU: математика
Topics EN: mathematics
Headings: TALUPERE; SUUR PERE; PEREMEES JA PERENAINE; LAPSED JA ABILISED; KAS LASTEL OLI VAHEL IGAV?; LAHENDA; Arutle
Task examples: Otsusta teksti põhjal, kes võisid elada ühes talus.; Kõige tähtsamad tööloomad talus olid

## MÕIS
URL: https://www.opiq.ee/kit/494/chapter/28147
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 3.5
Topics ET: matemaatika, mõis, suur, majapidamine, hooned, mõisapere, talurahvas, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MÕIS; SUUR MAJAPIDAMINE; HOONED; MÕISAPERE JA TALURAHVAS; LAHENDA; Arutle
Task examples: Uuri hoolega mõisaõue pilti. Keda või mida nägid pildil? Märgi.; Millised asjad ja loomad kuulusid pigem mõisalapsele?

## LINNAELU
URL: https://www.opiq.ee/kit/494/chapter/28148
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 3.6
Topics ET: matemaatika, linnaelu, linn, linna, maainimesed, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: LINNAELU; LINN; LINNA- JA MAAINIMESED; LAHENDA; Arutle
Task examples: Uuri hoolega linnaelu pilti. Milliseid ametimehi pildil märkasid?; Linnas oli palju toredaid paiku. Mis sa arvad, kus said käia vabrikutöölised?

## REEGLID JA SEADUSED
URL: https://www.opiq.ee/kit/494/chapter/28149
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.1
Topics ET: matemaatika, reeglid, seadused, käitumisreeglid, dokumendid, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: REEGLID JA SEADUSED; KÄITUMISREEGLID; SEADUSED; DOKUMENDID; LAHENDA; Arutle
Task examples: Mida tähendab lause kõik on seaduse ees võrdsed?; Eesti kõige tähtsam seadus on

## ÕPPIMISNÕKSUD
URL: https://www.opiq.ee/kit/449/chapter/24919
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.10
Topics ET: matemaatika, õppimisnõksud, harjutamine, teeb, meistriks, eesmärgid, meisterlikkuseni, arutle
Topics RU: математика
Topics EN: mathematics
Headings: ÕPPIMISNÕKSUD; HARJUTAMINE TEEB MEISTRIKS!; EESMÄRGID; TEE MEISTERLIKKUSENI; Arutle
Task examples: Vali lünka õige sõna.; Millised oskused oleks võimalik ühel lapsel omandada, kui ta soovib?

## OMAND JA VÄÄRTUS
URL: https://www.opiq.ee/kit/494/chapter/28150
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.2
Topics ET: matemaatika, omand, väärtus, sularaha, pangakaart, laenamine, kaotamine, leidmine, arutle
Topics RU: математика
Topics EN: mathematics
Headings: OMAND JA VÄÄRTUS; VÄÄRTUS; SULARAHA JA PANGAKAART; OMAND JA LAENAMINE; KAOTAMINE JA LEIDMINE; Arutle
Task examples: Rahakotti on mõistlik hoida; Pangakaardi PIN-kood tuleb ...

## TARBIMINE JA TAAS­KASUTUS
URL: https://www.opiq.ee/kit/494/chapter/28151
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.3
Topics ET: matemaatika, tarbimine, taas, kasutus, asjad, teenused, materjalid, taaskasutus, pakendite
Topics RU: математика
Topics EN: mathematics
Headings: TARBIMINE JA TAAS­KASUTUS; ASJAD JA TEENUSED; MATERJALID; TAASKASUTUS; PAKENDITE JA MUU PRÜGI SORTEERIMINE; LAHENDA
Task examples: Sorteeri sõnad õigesse rühma.; Millised ametid on koolikoti valmistamises otseselt osalenud? Vajuta neile.

## MEEDIA JA REKLAAM
URL: https://www.opiq.ee/kit/494/chapter/28152
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.4
Topics ET: matemaatika, meedia, reklaam, keda, uskuda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MEEDIA JA REKLAAM; MEEDIA; KEDA USKUDA?; REKLAAM; Arutle
Task examples: Millisest allikast võiks infot otsida? Ühenda.; Kas lause on õige või vale? Märgi õiged laused.

## SUHTLEMINE. KEEL JA KEHAKEEL
URL: https://www.opiq.ee/kit/449/chapter/24915
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.5
Topics ET: matemaatika, inimene, keha, meeled, tervis, suhtlemine, keel, kehakeel, reedab, salamõtteid, arutle, lahenda
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: SUHTLEMINE. KEEL JA KEHAKEEL; KEEL; KEHA REEDAB SALAMÕTTEID!; Arutle; LAHENDA
Task examples: Püüa aru saada laste kehakeelest. Kes ütleb EI ja kes JAA?; Püüa aru saada laste kehakeelest. Kes ütleb EI ja kes JAA?

## MINA JA TEISED. KOOSTÖÖ JA MÄNG
URL: https://www.opiq.ee/kit/449/chapter/24916
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.6
Topics ET: matemaatika, mina, teised, koostöö, mäng, mängureeglid, võit, kaotus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MINA JA TEISED. KOOSTÖÖ JA MÄNG; KOOSTÖÖ; MÄNGUREEGLID; VÕIT JA KAOTUS; Arutle; LAHENDA
Task examples: Millisel kiigel on hea üksi kiikuda?; Millisel kiigel ei saa üksi kiikuda? Miks?

## Kuidas kuningas EI ütles
URL: https://www.opiq.ee/kit/449/chapter/24921
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.7
Topics ET: matemaatika, kuidas, kuningas, ütles, öelda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas kuningas EI ütles; II; III; Kuidas öelda EI?; Arutle

## MINA ISE. ISESEISVUS
URL: https://www.opiq.ee/kit/449/chapter/24917
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.8
Topics ET: matemaatika, mina, iseseisvus, valikud, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MINA ISE. ISESEISVUS; VALIKUD; ISESEISVUS; LAHENDA; Arutle
Task examples: Head tuleb teha sellepärast, et ...; Vali lünka õige sõna.

## MIDA TEHA, ET AJU ARENEKS HÄSTI?
URL: https://www.opiq.ee/kit/449/chapter/24918
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 4.9
Topics ET: matemaatika, inimene, keha, meeled, tervis, mida, teha, areneks, hästi, meie, lihased, arutle, soodustab
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MIDA TEHA, ET AJU ARENEKS HÄSTI?; MEIE LIHASED JA AJU; Arutle; MIS SOODUSTAB AJU TÖÖD?; INIMENE ARENEB KOGU ELU; KUIDAS ME OMANDAME EMAKEELE VÕI VÕÕRKEELE?
Task examples: Meie lihased ja aju vajavad, et me neid; Milliseid toite peaks sööma rohkem ja milliseid vähem, et soodustada aju tööd?

## MINA JA KAASLASED. USALDUS
URL: https://www.opiq.ee/kit/494/chapter/28153
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.1
Topics ET: matemaatika, mina, kaaslased, usaldus, sõprus, tüdruk, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MINA JA KAASLASED. USALDUS; SÕPRUS; UUS TÜDRUK; USALDUS; LAHENDA; Arutle
Task examples: Kummal pildil on tüdruk parem sõber oma koerale? Miks?; Kas lause on õige või vale? Märgi õiged.

## VALIKUTE TAGAJÄRJED
URL: https://www.opiq.ee/kit/494/chapter/28154
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.2
Topics ET: matemaatika, valikute, tagajärjed, mida, teha, vastutus, kaks, eurot, ümbritsev
Topics RU: математика
Topics EN: mathematics
Headings: VALIKUTE TAGAJÄRJED; MIDA TEHA?; VASTUTUS; KAKS EUROT; ÜMBRITSEV MAAILM; LAHENDA
Task examples: Millised laused sobivad sinu kohta? Märgi need.; Vali lünka õige sõna.

## AGRESSIIVNE KÄITUMINE
URL: https://www.opiq.ee/kit/494/chapter/28155
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.3
Topics ET: matemaatika, loom, loomad, linnud, putukad, agressiivne, käitumine, agressiivsed, inimesed, põhjused, mida, siis
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: AGRESSIIVNE KÄITUMINE; AGRESSIIVSED LOOMAD; AGRESSIIVSED INIMESED; PÕHJUSED; MIDA SIIS TEHA?
Task examples: Lõvi on agressiivne siis, kui ...; Vali lünka õige sõna.

## LEPPIMINE JA ANDESTAMINE
URL: https://www.opiq.ee/kit/494/chapter/28156
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.4
Topics ET: matemaatika, leppimine, andestamine, kaile, tuleb, külaline, käskis, tõeline, vabandus
Topics RU: математика
Topics EN: mathematics
Headings: LEPPIMINE JA ANDESTAMINE; KAILE TULEB KÜLALINE; ATS KÄSKIS; TÕELINE VABANDUS
Task examples: Tüdrukud ehitavad onni.; Märt lõhub onni ära.

## NUTISEADMED I
URL: https://www.opiq.ee/kit/494/chapter/28157
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.5
Topics ET: matemaatika, nutiseadmed, miks, need, meile, meeldivad, teevad, õnnelikuks, turvaline
Topics RU: математика
Topics EN: mathematics
Headings: NUTISEADMED I; MIKS NEED MEILE MEELDIVAD?; KAS NUTISEADMED TEEVAD ÕNNELIKUKS?; TURVALINE KÄITUMINE VEEBIKESKKONNAS; Arutle
Task examples: Kas lause on õige või vale? Märgi õiged laused.; Vali lünka sobiv sõna.

## NUTISEADMED II
URL: https://www.opiq.ee/kit/494/chapter/28158
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.6
Topics ET: matemaatika, inimene, keha, meeled, tervis, nutiseadmed, magamistoas, arutle
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: NUTISEADMED II; NUTISEADMED JA TERVIS; NUTISEADMED MAGAMISTOAS; Arutle
Task examples: Nutikaelast saab hoiduda, kui ...; Väikese ekraani jälgimine lähedalt ...

## AJU JA ÕPPIMISNÕKSUD
URL: https://www.opiq.ee/kit/494/chapter/28159
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.7
Topics ET: matemaatika, õppimisnõksud, meeldejätmine, mida, teha, õppimine, edeneks, paremini, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: AJU JA ÕPPIMISNÕKSUD; MEELDEJÄTMINE; MIDA TEHA, ET ÕPPIMINE EDENEKS PAREMINI?; LAHENDA; Arutle
Task examples: Loe need sõnad läbi. Pööra pilk ekraanilt ära ja meenuta, mitu sõna sul meelde tuleb.; Ühenda sõnad paarideks. Loe sõnapaarid veelkord läbi. Pööra pilk ekraanilt ära ja meenuta, mitu sõnapaari sul meelde tuleb.

## KUIDAS EESTLASED VANASTI ELASID LINNAS?
URL: https://www.opiq.ee/kit/449/chapter/24928
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 5.8
Topics ET: matemaatika, kuidas, eestlased, vanasti, elasid, linnas, elas, inimesi, linnaelu
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS EESTLASED VANASTI ELASID LINNAS?; KA VANASTI ELAS OSA INIMESI LINNAS; LINNAELU; LAHENDA
Task examples: Uuri keskaegse linnatänava pilti. Märgi, mis on pildil olemas.; Vali õiged vastused.

## Sõnaseletused
URL: https://www.opiq.ee/kit/494/chapter/27195
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 6.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/494/chapter/28142
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 6.2
Topics ET: matemaatika, impressum, inimeseõpetuse, õpik, algklassidele
Topics RU: математика
Topics EN: mathematics
Headings: Impressum; Inimeseõpetuse õpik algklassidele

## LAENAMINE, ANDMINE
URL: https://www.opiq.ee/kit/449/chapter/26255
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 6.3
Topics ET: matemaatika, laenamine, andmine, mida, teha
Topics RU: математика
Topics EN: mathematics
Headings: LAENAMINE, ANDMINE; MIDA TEHA?; LAENAMINE
Task examples: Vaata pilti. Kumba raamatut tahaksid sina tagasi saada?; Laenad sõbralt mardilaupäevaks tema suure mütsi. See kukub aga porilompi ja saab mustaks. Millisena peaksid sa järgmisel päeval mütsi tagasi andma?

## LAPSE KOHUSTUSED JA ÕIGUSED
URL: https://www.opiq.ee/kit/449/chapter/26256
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 6.4
Topics ET: matemaatika, lapse, kohustused, õigused, aina, rohkem, õigusi, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LAPSE KOHUSTUSED JA ÕIGUSED; LAPSE ÕIGUSED; AINA ROHKEM ÕIGUSI; LAPSE KOHUSTUSED; LAHENDA
Task examples: Lohista Lasteabi telefoninumber õigesse järjekorda.; Milline lause on õige?

## LAPSE OTSUSED JA VALIKUD
URL: https://www.opiq.ee/kit/449/chapter/26257
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 6.5
Topics ET: matemaatika, lapse, otsused, valikud, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: LAPSE OTSUSED JA VALIKUD; OTSUSED; VALIKUD; LAHENDA; Arutle
Task examples: Kumb tegevus on tervislikum? Kui pead mõlemat tervislikuks, märgi mõlemad.; Kumb tegevus on tervislikum? Kui pead mõlemat tervislikuks, märgi mõlemad.

## See on minu kuningriik!
URL: https://www.opiq.ee/kit/449/chapter/26258
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 6.6
Topics ET: matemaatika, kuningriik, ahoi, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: See on minu kuningriik!; Ahoi!; LAHENDA
Task examples: Leia sõnale seletus.

## TOIMETULEK TUNNETEGA
URL: https://www.opiq.ee/kit/449/chapter/26259
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 7.1
Topics ET: matemaatika, toimetulek, tunnetega, pane, tähele, mida, olukordades, tunned, tunne, tugev
Topics RU: математика
Topics EN: mathematics
Headings: TOIMETULEK TUNNETEGA; PANE TÄHELE; Pane tähele, mida sa eri olukordades tunned.; Minu tunne on nii tugev kui ...; Viha võib olla nagu ...; MILLAL ON RASKE ENNAST KONTROLLIDA?; VIHA TASEMED

## KUIDAS SAADA HAKKAMA KURBUSE JA VIHAGA?
URL: https://www.opiq.ee/kit/449/chapter/26260
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 7.2
Topics ET: matemaatika, kuidas, saada, hakkama, kurbuse, vihaga, kurbusega
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS SAADA HAKKAMA KURBUSE JA VIHAGA?; KUIDAS SAADA HAKKAMA VIHAGA?; KUIDAS SAADA HAKKAMA KURBUSEGA?
Task examples: Kas lause on õige või vale?

## Impressum
URL: https://www.opiq.ee/kit/449/chapter/26261
Book: Inimeseõpetus algklassidele, I osa. 2023 ÕK 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_et
Chapter ID: 8.1
Topics ET: matemaatika, impressum, inimeseõpetuse, õpik, algklassidele
Topics RU: математика
Topics EN: mathematics
Headings: Impressum; Inimeseõpetuse õpik algklassidele

## Inimeseõpetus algklassidele. II osa – Opiq
URL: https://www.opiq.ee/Kit/Details/579
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 175
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus algklassidele. II osa – Opiq
URL: https://www.opiq.ee/Kit/Details/579
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 200
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## LIIKLUS. LIIKLEMISE REEGLID
URL: https://www.opiq.ee/kit/579/chapter/32046
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.1
Topics ET: matemaatika, liiklus, liiklemise, reeglid, arutle
Topics RU: математика, движение, правила, движения
Topics EN: mathematics
Headings: LIIKLUS. LIIKLEMISE REEGLID; Движение. Правила движения; LIIKLUS; Arutle; EESÕIGUS JA TEE ANDMINE; ÜLEKÄIGURADA; LAHENDA; INIMESEÕPETUS EESTI KEELES
Task examples: Правила движения установлены для того, чтобы движение было ...; Liiklemise reeglid on kokku lepitud selleks, et liiklemine oleks ...

## LIIKLUS. ERILISED SÕIDUKID
URL: https://www.opiq.ee/kit/579/chapter/32047
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.2
Topics ET: matemaatika, liiklus, erilised, sõidukid, eritalituse
Topics RU: математика, движение, особые, транспортные, средства
Topics EN: mathematics
Headings: LIIKLUS. ERILISED SÕIDUKID; Движение. Особые транспортные средства; ERITALITUSE SÕIDUKID; Arutle; LAHENDA; RONGID JA RAUDTEE ÜLETAMINE; INIMESEÕPETUS EESTI KEELES
Task examples: Рассмотри картинку. Кто должен уступить дорогу, если у машины спасательной службы включены сигнальные маячки и сирена?; Vaata pilti. Kes peab andma teed, kui päästeautol vilkurid ja sireen töötavad?

## VEEOHUTUS I. ENDA OHUTUSE TAGAMINE
URL: https://www.opiq.ee/kit/579/chapter/32048
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.3
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, enda, ohutuse, tagamine
Topics RU: природоведение, вода, безопасность на воде, водоём, безопасность, воде, обеспечение, собственной, безопасности
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS I. ENDA OHUTUSE TAGAMINE; Безопасность на воде.​ ​Обеспечение собственной безопасности; UJUMINE UJULAS VÕI VEEKOGUS; 7.; 1.; 2.; 3.; 4.; 5.; 6.; AVALIK RAND; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Какие предложения верные? Отметь их.; Millised laused on õiged? Märgi need.

## VEEOHUTUS II. TEISTE AITAMINE. VEEOHUTUS TALVEL
URL: https://www.opiq.ee/kit/579/chapter/32049
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.4
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, teiste, aitamine, talvel
Topics RU: природоведение, вода, безопасность на воде, водоём, безопасность, воде, помощь, другим, зимой
Topics EN: science, water, water safety, body of water
Headings: VEEOHUTUS II. TEISTE AITAMINE. VEEOHUTUS TALVEL; Безопасность на воде. Помощь другим. ​Безопасность на воде зимой​; HÄDASOLIJA MÄRKAMINE JA AITAMINE; PÄÄSTEVEST; VEEOHUTUS TALVEL; HÄDASOLIJA AITAMINE TALVEL; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Закончи предложения.; Закончи предложения.

## AJA PLANEERIMINE
URL: https://www.opiq.ee/kit/579/chapter/32441
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.5
Topics ET: matemaatika, aeg, kell, kalender, planeerimine, lahenda, arutle, inimeseõpetus, eesti
Topics RU: математика, время, часы, календарь, планирование, времени
Topics EN: mathematics, time, clock, calendar
Headings: AJA PLANEERIMINE; Планирование времени; AEG; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Подумай и соедини, с помощью чего хорошо считать ...; Nuputa ja ühenda, millega on hea arvestada ...

## PERE JA SUGULASED
URL: https://www.opiq.ee/kit/579/chapter/32442
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.6
Topics ET: matemaatika, pere, sugulased, arutle, inimeseõpetus, eesti
Topics RU: математика, семья, родственники
Topics EN: mathematics
Headings: PERE JA SUGULASED; Семья и родственники; PERE; SUGULASED; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Любовь, понимание и чувство безопас­ности ребёнку должна давать, в первую очередь, ...; Armastust, mõistmist ja turvatunnet peab lapsele pakkuma eelkõige ...

## NAABRID JA KOGUKOND
URL: https://www.opiq.ee/kit/579/chapter/32443
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.7
Topics ET: matemaatika, naabrid, kogukond, arutle, inimeseõpetus, eesti
Topics RU: математика, соседи, община
Topics EN: mathematics
Headings: NAABRID JA KOGUKOND; Соседи и община; NAABRID; Arutle; KOGUKOND; INIMESEÕPETUS EESTI KEELES
Task examples: Каким советам нужно следовать, живя в многоквартирном доме? Отметь их.; Milliseid nõuandeid võiks kortermajas elades järgida? Märgi need.

## RAHVAKOMBED SÜGISEL I. HINGEDEPÄEV
URL: https://www.opiq.ee/kit/579/chapter/32444
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.8
Topics ET: matemaatika, rahvakombed, sügisel, hingedepäev
Topics RU: математика, народные, обычаи, осенью, день, поминовения, усопших
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL I. HINGEDEPÄEV; Народные обычаи осенью. День поминовения душ усопших; RAHVAKOMBED; AASTARING; HINGEDEPÄEV; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: В давние времена в субботу вечером ...; Vanasti laupäeva õhtul ...

## RAHVAKOMBED SÜGISEL II. MARDIPÄEV JA KADRIPÄEV
URL: https://www.opiq.ee/kit/579/chapter/32445
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 1.9
Topics ET: matemaatika, rahvakombed, sügisel, mardipäev, kadripäev, lahenda, arutle, inimeseõpetus
Topics RU: математика
Topics EN: mathematics
Headings: RAHVAKOMBED SÜGISEL II. MARDIPÄEV JA KADRIPÄEV; MARDIPÄEV; KADRIPÄEV; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## INIMESE PÕHI­VAJADUSED
URL: https://www.opiq.ee/kit/579/chapter/32446
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.1
Topics ET: matemaatika, inimese, põhi, vajadused, põhivajadused
Topics RU: математика, основные, потребности, человека
Topics EN: mathematics
Headings: INIMESE PÕHI­VAJADUSED; Основные потребности человека; PÕHIVAJADUSED; AJU MÄRGUANDED; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Отметь, без чего мы не можем жить.; Märgi, milleta me ei saa elada.

## TERVISLIK PUHKUS JA UNI
URL: https://www.opiq.ee/kit/579/chapter/32447
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.2
Topics ET: matemaatika, tervislik, puhkus, ööpäev, arutle, piisav
Topics RU: математика, здоровый, отдых
Topics EN: mathematics
Headings: TERVISLIK PUHKUS JA UNI; Здоровый отдых и сон; ÖÖPÄEV; Arutle; PIISAV PUHKUS; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## TERVISLIK TOITUMINE JA LIIKUMINE
URL: https://www.opiq.ee/kit/579/chapter/32448
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.3
Topics ET: matemaatika, tervislik, toitumine, liikumine, toit
Topics RU: математика, здоровое, питание, движение
Topics EN: mathematics
Headings: TERVISLIK TOITUMINE JA LIIKUMINE; Здоровое питание и движение; TOIT; TALDRIKUREEGEL; LIIKUMINE; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Перетащи продукты в правильную колонку.; Lohista toiduained õigesse tulpa.

## OHUD VABAL AJAL. ESMAABI I
URL: https://www.opiq.ee/kit/579/chapter/32449
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.4
Topics ET: matemaatika, aeg, kell, kalender, ohud, vabal, ajal, esmaabi
Topics RU: математика, время, часы, календарь, опасности, свободное, первая, помощь
Topics EN: mathematics, time, clock, calendar
Headings: OHUD VABAL AJAL. ESMAABI I; Опасности в свободное время. Первая помощь; MIS ON ESMAABI?; KUKKUMINE; PEAPÕRUTUS; HAAV; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Первая помощь важна, потому что ...; Esmaabi on oluline, sest ...

## OHUD VABAL AJAL. ESMAABI II
URL: https://www.opiq.ee/kit/579/chapter/32450
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.5
Topics ET: matemaatika, aeg, kell, kalender, inimene, keha, meeled, tervis, ohud, vabal, ajal, esmaabi
Topics RU: математика, время, часы, календарь, человек, тело, чувства, здоровье, опасности, свободное, первая, помощь
Topics EN: mathematics, time, clock, calendar, human, body, senses, health
Headings: OHUD VABAL AJAL. ESMAABI II; Опасности в свободное время. Первая помощь; MÜRGISTUS; PÕLETUS; TEADVUSETA INIMENE; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Отравление могут вызвать разные вещи. Соедини пары.; Mürgistust võivad põhjustada erinevad asjad. Ühenda paarid.

## MIKS ME JÄÄME HAIGEKS?
URL: https://www.opiq.ee/kit/579/chapter/32451
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.6
Topics ET: matemaatika, inimene, keha, meeled, tervis, miks, jääme, haigeks, sagedasemad
Topics RU: математика, человек, тело, чувства, здоровье, почему, заболеваем
Topics EN: mathematics, human, body, senses, health
Headings: MIKS ME JÄÄME HAIGEKS?; Почему мы заболеваем?; TERVIS; SAGEDASEMAD LASTEHAIGUSED; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## KUIDAS ME PARANEME?
URL: https://www.opiq.ee/kit/579/chapter/32452
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.7
Topics ET: matemaatika, kuidas, paraneme, mida, teha, arst, ravimid
Topics RU: математика, выздоравливаем
Topics EN: mathematics
Headings: KUIDAS ME PARANEME?; Как мы выздоравливаем?; MIDA TEHA?; ARST JA RAVIMID; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Больному ребёнку нужны ...; Haige laps vajab ...

## HAMMASTE TERVIS
URL: https://www.opiq.ee/kit/579/chapter/32453
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 2.8
Topics ET: matemaatika, inimene, keha, meeled, tervis, hammaste, hambad, kuidas, hambaid, õigesti, pesta
Topics RU: математика, человек, тело, чувства, здоровье, зубов
Topics EN: mathematics, human, body, senses, health
Headings: HAMMASTE TERVIS; Здоровье зубов; HAMBAD; KUIDAS HAMBAID ÕIGESTI PESTA?; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Выбери правильные слова.; Vali lünka õiged sõnad.

## JÕULUKOMBED
URL: https://www.opiq.ee/kit/579/chapter/32454
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 3.1
Topics ET: matemaatika, jõulukombed, talvine, pööripäev, kombed, arutle
Topics RU: математика, рождественские, обычаи
Topics EN: mathematics
Headings: JÕULUKOMBED; Рождественские обычаи; TALVINE PÖÖRIPÄEV; KOMBED; Arutle; LAHENDA; INIMESEÕPETUS EESTI KEELES
Task examples: Когда стали отмечать Рождество?; Pärast talvist pööripäeva hakkavad päevad tasapisi ...

## TALU
URL: https://www.opiq.ee/kit/579/chapter/33048
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 3.2
Topics ET: matemaatika, talu, maarahvas, kellele, kuulusid, talud, lahenda
Topics RU: математика, хутор
Topics EN: mathematics
Headings: TALU; Хутор; MAARAHVAS; KELLELE KUULUSID TALUD?; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Какие предметы и орудия труда ты найдёшь на картинке? Отметь их.; Mis esemed ja tööriistad on pildil?Märgi need.

## TALUHOONED
URL: https://www.opiq.ee/kit/579/chapter/33049
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 3.3
Topics ET: matemaatika, taluhooned, rehemaja, reheahi, toit, laut
Topics RU: математика, хуторские, постройки
Topics EN: mathematics
Headings: TALUHOONED; Хуторские постройки; REHEMAJA; REHEAHI JA TOIT; AIT JA LAUT; SUVEKÖÖK JA SAUN; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Соедини слово и его значение.; Ühenda sõna ja selle tähendus.

## TALUPERE
URL: https://www.opiq.ee/kit/579/chapter/33050
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 3.4
Topics ET: matemaatika, talupere, suur, pere, peremees, perenaine
Topics RU: математика, крестьянская, семья
Topics EN: mathematics
Headings: TALUPERE; Крестьянская семья; SUUR PERE; PEREMEES JA PERENAINE; LAPSED JA ABILISED; KAS LASTEL OLI VAHEL IGAV?; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Определи на основе текста, кто могли жить на одном хуторе.; Otsusta teksti põhjal, kes võisid elada ühes talus.

## MÕIS
URL: https://www.opiq.ee/kit/579/chapter/33388
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 3.5
Topics ET: matemaatika, mõis, suur, majapidamine, hooned, mõisapere, talurahvas
Topics RU: математика, мыза
Topics EN: mathematics
Headings: MÕIS; Мыза; SUUR MAJAPIDAMINE; HOONED; MÕISAPERE JA TALURAHVAS; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Внимательно изучи картинку, на которой изображён двор мызы. Кого или что ты видишь на картинке? Отметь.; Uuri hoolega mõisaõue pilti. Keda või mida näed pildil? Märgi.

## LINNAELU
URL: https://www.opiq.ee/kit/579/chapter/33389
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 3.6
Topics ET: matemaatika, linnaelu, linn, linna, maainimesed, lahenda
Topics RU: математика, городская, жизнь
Topics EN: mathematics
Headings: LINNAELU; Городская жизнь; LINN; LINNA- JA MAAINIMESED; LAHENDA; Arutle; INIMESEÕPETUS EESTI KEELES
Task examples: Внимательно изучи картинку, на которой изображена городская жизнь. Предста­ви­телей каких профессий ты видишь?; Uuri hoolega linnaelu pilti. Milliseid ametimehi pildil märkad?

## Impressum
URL: https://www.opiq.ee/kit/579/chapter/32455
Book: Inimeseõpetus algklassidele. II osa 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: avita_inimeseõpe_2_ru
Chapter ID: 4.1
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Loodus- ja inimeseõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/56
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 201
Topics ET: loodusõpetus, loodus, keskkond, inimeseõpetus, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodus- ja inimeseõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/56
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 262
Topics ET: loodusõpetus, loodus, keskkond, inimeseõpetus, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Kodu ja naabrid
URL: https://www.opiq.ee/kit/56/chapter/2749
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.1
Topics ET: loodusõpetus, kodu, naabrid, hannese, kiri, erinevad, kodud, mina, nabalinna, plaan
Topics RU: природоведение
Topics EN: science
Headings: Kodu ja naabrid; Hannese kiri; Erinevad kodud; Mina; Nabalinna plaan

## Vee ringlemine
URL: https://www.opiq.ee/kit/56/chapter/2758
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.10
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, ringlemine, ringleb, loigud, pilved, vihm, lisa, emaläte, veekogude
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Vee ringlemine; Vesi ringleb; Loigud; Pilved ja vihm; Lisa. Emaläte; Veekogude kaart

## Ilma ennustamine
URL: https://www.opiq.ee/kit/56/chapter/2759
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.11
Topics ET: loodusõpetus, ilma, ennustamine, tuul, millega, seda, mõõdetakse
Topics RU: природоведение
Topics EN: science
Headings: Ilma ennustamine; Ilm; Tuul; Millega seda mõõdetakse?

## Ilm
URL: https://www.opiq.ee/kit/56/chapter/2760
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.12
Topics ET: loodusõpetus, ilma, iseloomustamine, ilmale, vastav, riietus, ilmagraafikud, ilmamärgid, ilmastikunähtused, ilmamõõteriistad
Topics RU: природоведение
Topics EN: science
Headings: Ilm; Ilma iseloomustamine; Ilmale vastav riietus; Ilmagraafikud; Ilmamärgid; Ilmastikunähtused; Ilmamõõteriistad

## Tervis
URL: https://www.opiq.ee/kit/56/chapter/2761
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.13
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, hannes, haige, haigused, allergia, haiguste, vältimine
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Tervis; Hannes on haige; Haigused ja allergia; Haiguste vältimine

## Esmaabi
URL: https://www.opiq.ee/kit/56/chapter/2762
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.14
Topics ET: loodusõpetus, esmaabi, esialgne, käitumine, õnnetuse, korral
Topics RU: природоведение
Topics EN: science
Headings: Esmaabi; Esmaabi on esialgne abi; Käitumine õnnetuse korral

## Loomad
URL: https://www.opiq.ee/kit/56/chapter/2763
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.15
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, loomariik, imetajad, loomade, kehaosad, vähi
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Loomad; Loomariik; Imetajad; Loomade kehaosad; Vähi kehaosad

## Looma kirjeldamine
URL: https://www.opiq.ee/kit/56/chapter/2764
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.16
Topics ET: loodusõpetus, looma, kirjeldamine, kirjelda, loomade, kehaosi, konna, hobuse, luige, räime
Topics RU: природоведение
Topics EN: science
Headings: Looma kirjeldamine; Kirjelda loomade kehaosi; Kirjelda konna, hobuse, luige ja räime kehaosi.

## Elupaik
URL: https://www.opiq.ee/kit/56/chapter/2765
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.17
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, elupaik, loomade, elupaigad, kodud, millises, kodus, elab, looma
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Elupaik; Loomade elupaigad; Loomade kodud; Millises kodus elab loom?; Looma elupaik; Taimede kasvukohad; Erinevad kasvukohad

## Metsas elavad loomad
URL: https://www.opiq.ee/kit/56/chapter/2766
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.18
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, metsas, elavad, hannes, loomade, tegevusjäljed, kuklased, suur, kirjurähn
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Metsas elavad loomad; Hannes metsas; Loomade tegevusjäljed metsas; Kuklased ja suur-kirjurähn; Kuidas käituda metsas?

## Põder ja metskits
URL: https://www.opiq.ee/kit/56/chapter/2767
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.19
Topics ET: loodusõpetus, põder, metskits, põdra, kehaosad, toidulaud, metskitse
Topics RU: природоведение
Topics EN: science
Headings: Põder ja metskits; Põder; Põdra kehaosad; Põdra toidulaud; Metskits; Metskitse kehaosad

## Maal või linnas?
URL: https://www.opiq.ee/kit/56/chapter/2750
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.2
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, maal, linnas, kodu, milline, võib, olla, linnaelu, lisa
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Maal või linnas?; Kodu; Milline võib kodu olla?; Maa- ja linnaelu võrdlemine; Lisa. Kodud mujal maailmas

## Pruunkaru ja metssiga
URL: https://www.opiq.ee/kit/56/chapter/2768
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.20
Topics ET: loodusõpetus, pruunkaru, metssiga, karu, kehaosad, toidulaud, metssea, toidulaua, sortimine
Topics RU: природоведение
Topics EN: science
Headings: Pruunkaru ja metssiga; Pruunkaru; Karu kehaosad; Karu toidulaud; Metssiga; Metssea kehaosad; Metssea toidulaua sortimine

## Hunt ja rebane
URL: https://www.opiq.ee/kit/56/chapter/2769
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.21
Topics ET: loodusõpetus, hunt, rebane, hundi, kehaosad, keda, sööb, rebase
Topics RU: природоведение
Topics EN: science
Headings: Hunt ja rebane; Hunt; Hundi kehaosad; Keda hunt sööb?; Rebane; Rebase kehaosad

## Loomapark, loomaaed ja lemmikloomad
URL: https://www.opiq.ee/kit/56/chapter/2770
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.22
Topics ET: loodusõpetus, loomapark, loomaaed, lemmikloomad, hannese, kiri, koerte, ametid
Topics RU: природоведение
Topics EN: science
Headings: Loomapark, loomaaed ja lemmikloomad; Hannese kiri; Lemmikloomad; Loomapark ja loomaaed; Koerte ametid

## Jõulud
URL: https://www.opiq.ee/kit/56/chapter/2771
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.23
Topics ET: loodusõpetus, jõulud, jõulude, tähistamine, lisa, jõuluvana, jõulusalm, kõige, ilusam, jõulupuu
Topics RU: природоведение
Topics EN: science
Headings: Jõulud; Jõulude tähistamine; Lisa. Jõuluvana; Jõulusalm; Kõige ilusam jõulupuu; Kirjuta oma jõulusalm.

## Lähedased inimesed
URL: https://www.opiq.ee/kit/56/chapter/2751
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.3
Topics ET: loodusõpetus, lähedased, inimesed, hannese, perekond, sugulased, mõisted, sõbrad
Topics RU: природоведение
Topics EN: science
Headings: Lähedased inimesed; Hannese lähedased; Minu perekond; Hannese sugulased; Mõisted; Sõbrad ja sugulased

## Mets
URL: https://www.opiq.ee/kit/56/chapter/2752
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, mets, hannes, käib, metsas, erinevad, metsad, puud, eesti, lehtpuud
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Mets; Hannes käib metsas; Erinevad metsad; Puud; Eesti lehtpuud; Eesti okaspuud; Puu osad; Leht- ja okaspuu

## Lehtpuud
URL: https://www.opiq.ee/kit/56/chapter/2753
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.5
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, lehtpuud, lehtpuude, tunnused, kask, tamm, metsas
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Lehtpuud; Lehtpuude tunnused; Kask ja tamm; Aastaajad metsas

## Okaspuud
URL: https://www.opiq.ee/kit/56/chapter/2754
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.6
Topics ET: loodusõpetus, okaspuud, okaspuudel, okkad, okaspuu, mõiste, käbid, marikäbid, lisa, aastarõngad
Topics RU: природоведение
Topics EN: science
Headings: Okaspuud; Okaspuudel on okkad; Okaspuu mõiste; Käbid ja marikäbid; Lisa. Aastarõngad; Tüve läbilõige; Leht- ja okaspuud; Tunne Eesti puid; Lehtpuu ja okaspuu

## Põõsad
URL: https://www.opiq.ee/kit/56/chapter/2755
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.7
Topics ET: loodusõpetus, põõsad, põõsal, varred, kibuvits, pähklid
Topics RU: природоведение
Topics EN: science
Headings: Põõsad; Põõsal on varred; Kibuvits; Pähklid

## Puhmad
URL: https://www.opiq.ee/kit/56/chapter/2756
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.8
Topics ET: loodusõpetus, puhmad, puhmas, kääbuspõõsas, pohl, kanarbik, milline, tunned, puhmaid
Topics RU: природоведение
Topics EN: science
Headings: Puhmad; Puhmas on kääbuspõõsas; Pohl ja kanarbik; Milline puhmas? 3; Kas tunned puhmaid?; Milline puhmas? 1; Milline puhmas? 2

## Park
URL: https://www.opiq.ee/kit/56/chapter/2757
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.9
Topics ET: loodusõpetus, park, hannes, pargis, pargid, inimeste, rajatud, linnapark
Topics RU: природоведение
Topics EN: science
Headings: Park; Hannes pargis; Pargid on inimeste rajatud; Linnapark

## Raamatud ja raamatukogu
URL: https://www.opiq.ee/kit/56/chapter/3345
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.1
Topics ET: loodusõpetus, raamatud, raamatukogu, raamatukogus, hoitakse, raamatuid, loetud, milliseid, olemas, mida
Topics RU: природоведение
Topics EN: science
Headings: Raamatud ja raamatukogu; Raamatukogus hoitakse raamatuid; Loetud raamatud; Milliseid raamatuid on olemas?; Mida saab raamatukogus teha?; Lauaarvuti

## Mineviku jäljed
URL: https://www.opiq.ee/kit/56/chapter/3477
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.10
Topics ET: loodusõpetus, mineviku, jäljed, nabalinna, sõpruskooli, külaskäik, vana, asjad, õpikukaas
Topics RU: природоведение
Topics EN: science
Headings: Mineviku jäljed; Nabalinna sõpruskooli külaskäik; Vana aja asjad; Vana õpikukaas

## Sõbrad
URL: https://www.opiq.ee/kit/56/chapter/3478
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.11
Topics ET: loodusõpetus, sõbrad, hannese
Topics RU: природоведение
Topics EN: science
Headings: Sõbrad; Hannese sõbrad; Minu sõbrad

## Teater ja kino
URL: https://www.opiq.ee/kit/56/chapter/3479
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.12
Topics ET: loodusõpetus, teater, kino, hannes, teatris, töötab, filmivõtted
Topics RU: природоведение
Topics EN: science
Headings: Teater ja kino; Hannes teatris; Kes töötab teatris?; Teatris; Kino; Filmivõtted

## Post
URL: https://www.opiq.ee/kit/56/chapter/3502
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.13
Topics ET: loodusõpetus, post, kirja, saatmine, ümbriku, vormistamine, postmargid
Topics RU: природоведение
Topics EN: science
Headings: Post; Kirja saatmine; Ümbriku vormistamine; Postmargid

## Transport
URL: https://www.opiq.ee/kit/56/chapter/3503
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.14
Topics ET: loodusõpetus, transport, transpordivahendid, bussijaama, sõiduplaan, rongipilet
Topics RU: природоведение
Topics EN: science
Headings: Transport; Transpordivahendid; Bussijaama sõiduplaan; Rongipilet

## Vabrik
URL: https://www.opiq.ee/kit/56/chapter/3504
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.15
Topics ET: loodusõpetus, vabrik, hannese, töökoht, erinevad, vabrikud, toodeti
Topics RU: природоведение
Topics EN: science
Headings: Vabrik; Hannese ema töökoht; Erinevad vabrikud; Kus see toodeti?

## Turg
URL: https://www.opiq.ee/kit/56/chapter/3505
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.16
Topics ET: loodusõpetus, turg, hannes, turul, sõna
Topics RU: природоведение
Topics EN: science
Headings: Turg; Hannes turul; Turul; Sõna turg

## Raha
URL: https://www.opiq.ee/kit/56/chapter/3611
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.17
Topics ET: loodusõpetus, raha, euro, sent, väärtus, mida, eest, osta, hoitakse, pangas, lisa
Topics RU: природоведение, деньги, евро, цент
Topics EN: science, money, euro, cent
Headings: Raha; Raha väärtus; Mida ei saa raha eest osta?; Euro; Raha hoitakse pangas; Lisa. Raha väärtus

## Kust tulevad asjad?
URL: https://www.opiq.ee/kit/56/chapter/3612
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.18
Topics ET: loodusõpetus, kust, tulevad, asjad, mida, saab, teha, jahust, puuvillast, riieteni
Topics RU: природоведение
Topics EN: science
Headings: Kust tulevad asjad?; Mida saab teha jahust?; Puuvillast riieteni

## Keskkond
URL: https://www.opiq.ee/kit/56/chapter/3613
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.19
Topics ET: loodusõpetus, loodus, keskkond, hannes, hoiab, koduümbruse, korras, kõik, meid, ümbritseb, puhas
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Keskkond; Hannes hoiab koduümbruse korras; Keskkond on kõik, mis meid ümbritseb; Puhas Eestimaa; Koristamine ja korras hoidmine

## Õigus
URL: https://www.opiq.ee/kit/56/chapter/3346
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, õigus, seadused, politsei, kohus
Topics RU: природоведение
Topics EN: science
Headings: Õigus; Seadused; Seadused, politsei ja kohus; Politsei

## Materjalid ja taaskasutus
URL: https://www.opiq.ee/kit/56/chapter/3614
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.20
Topics ET: loodusõpetus, materjalid, taaskasutus, sorteeri, prügi, ohtlikud, jäätmed
Topics RU: природоведение
Topics EN: science
Headings: Materjalid ja taaskasutus; Taaskasutus; Materjalid; Sorteeri prügi; Ohtlikud jäätmed

## Aed
URL: https://www.opiq.ee/kit/56/chapter/7625
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.21
Topics ET: loodusõpetus, aiataimed, taimeosad, tunned, marju
Topics RU: природоведение
Topics EN: science
Headings: Aed; Aiataimed; Taimeosad; Kas tunned marju?

## Rohttaimed
URL: https://www.opiq.ee/kit/56/chapter/7626
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.22
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, rohttaimed, rohttaimede, varred, rohtsed, rohttaim, puittaim, üheaastased
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Rohttaimed; Rohttaimede varred on rohtsed; Rohttaim, puittaim või loom?; Üheaastased taimed; Mõisted rohttaim, puittaim ja üheaastane taim

## Mitmeaastased taimed
URL: https://www.opiq.ee/kit/56/chapter/7627
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.23
Topics ET: loodusõpetus, taim, taimed, puu, lill, mitmeaastased, tulp, maikelluke, tulbi, osad, rukkilill
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Mitmeaastased taimed; Tulp ja maikelluke; Tulbi osad; Tulp, maikelluke ja rukkilill

## Aialoomad
URL: https://www.opiq.ee/kit/56/chapter/7628
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.24
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, aialoomad, vihmaussid, nälkjad, teod, konnad, siil, lisa
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Aialoomad; Vihmaussid; Nälkjad, teod ja konnad; Siil; Linnud ja putukad; Lisa. Päevapaabusilm; Päevapaabusilm

## Botaanikaaed
URL: https://www.opiq.ee/kit/56/chapter/7629
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.25
Topics ET: loodusõpetus, botaanikaaed, hannese, kiri, tartu, toataimed, orhidee
Topics RU: природоведение
Topics EN: science
Headings: Botaanikaaed; Hannese kiri; Tartu botaanikaaed; Toataimed; Hannese ema orhidee

## Põld
URL: https://www.opiq.ee/kit/56/chapter/7701
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.26
Topics ET: loodusõpetus, põld, teraviljad, vali, kõik, mida, kasvatatakse, eestis, talivilja, aastaring
Topics RU: природоведение
Topics EN: science
Headings: Põld; Teraviljad; Vali kõik teraviljad, mida kasvatatakse Eestis.; Talivilja aastaring; Teraviljade mõisted; Teravili on tähtis toit; Teraviljatooted

## Koduloomad
URL: https://www.opiq.ee/kit/56/chapter/7702
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.27
Topics ET: loodusõpetus, koduloomad, koduloomade, nimetamine, mida, koduloomadelt, saame, lisa, meierei, piimatööstus
Topics RU: природоведение
Topics EN: science
Headings: Koduloomad; Koduloomade nimetamine; Mida me koduloomadelt saame?; Lisa. Meierei ehk piimatööstus

## Soo
URL: https://www.opiq.ee/kit/56/chapter/7703
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.28
Topics ET: loodusõpetus, vesine, koht, millised, marjad, kasvavad, soos, iseloomustamine
Topics RU: природоведение
Topics EN: science
Headings: Soo; Soo on vesine koht; Millised marjad kasvavad soos?; Soo iseloomustamine

## Soos elavad loomad
URL: https://www.opiq.ee/kit/56/chapter/7704
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.29
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, soos, elavad, sookured, sookurg, valge, toonekurg, konnad, sääsed
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Soos elavad loomad; Sookured; Sookurg ja valge-toonekurg; Konnad ja sääsed; Eesti konnad

## Muuseum
URL: https://www.opiq.ee/kit/56/chapter/3347
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.3
Topics ET: loodusõpetus, muuseum, muuseumis, hoitakse, väärtuslikke, esemeid, muuseumid
Topics RU: природоведение
Topics EN: science
Headings: Muuseum; Muuseumis hoitakse väärtuslikke esemeid; Muuseumid

## Veekogud
URL: https://www.opiq.ee/kit/56/chapter/7705
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.30
Topics ET: loodusõpetus, veekogud, hannes, ujumas, veekogude, nimetused, tähistamine, lisa, eesti, tuntuimad
Topics RU: природоведение
Topics EN: science
Headings: Veekogud; Hannes ujumas; Veekogude nimetused; Veekogude tähistamine; Lisa. Eesti tuntuimad veekogud; Tunne Eesti veekogusid

## Veetaimed
URL: https://www.opiq.ee/kit/56/chapter/7706
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.31
Topics ET: loodusõpetus, veetaimed
Topics RU: природоведение
Topics EN: science
Headings: Veetaimed

## Veeloomad
URL: https://www.opiq.ee/kit/56/chapter/7707
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.32
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, veeloomad, veeloomade, eesti, kalad
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Veeloomad; Veeloomade keha; Eesti kalad

## Linnuse varemed
URL: https://www.opiq.ee/kit/56/chapter/7708
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.33
Topics ET: loodusõpetus, linnuse, varemed, hannes, vanas, linnuses, lisa, eesti, linnused, kaitsmine
Topics RU: природоведение
Topics EN: science
Headings: Linnuse varemed; Hannes vanas linnuses; Lisa. Eesti linnused; Linnuse kaitsmine

## Nabalinna pilt ja kaart
URL: https://www.opiq.ee/kit/56/chapter/7709
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.34
Topics ET: loodusõpetus, nabalinna, pilt, kaart
Topics RU: природоведение
Topics EN: science
Headings: Nabalinna pilt ja kaart

## Eesti kaart
URL: https://www.opiq.ee/kit/56/chapter/7710
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.35
Topics ET: loodusõpetus, eesti, kaart, tunne, eestimaad
Topics RU: природоведение
Topics EN: science
Headings: Eesti kaart; Tunne Eestimaad

## Tervishoiumuuseum
URL: https://www.opiq.ee/kit/56/chapter/3348
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, tervishoiumuuseum, hannese, kiri, tervishoiumuuseumist, mõõteriistad, miks, tuleb, mõõtmisel
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Tervishoiumuuseum; Hannese kiri tervishoiumuuseumist; Mõõteriistad; Pikkus; Miks tuleb mõõtmisel olla hoolikas?; Lisa. Da Vinci joonistatud inimkeha; Inimkeha joonis

## Mõõtmine
URL: https://www.opiq.ee/kit/56/chapter/3349
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, mõõtühikud, ühikutes, mõõdetakse, teepikkust, eestis, kohupiima, ahjupannkook, tööraamatu
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mõõtmine; Mõõtühikud; Mis ühikutes mõõdetakse teepikkust Eestis?; Kohupiima-ahjupannkook; Tööraamatu pikkus; Mida saab mõõta?

## Inimene
URL: https://www.opiq.ee/kit/56/chapter/3350
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.6
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis, inimese, gorilla, põlvnemine, tasakaal
Topics RU: природоведение, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье
Topics EN: science, comparison, compare, greater, less, human, body, senses, health
Headings: Inimene; Inimene ja ahv; Inimese ja gorilla võrdlemine; Inimese põlvnemine; Tasakaal

## Inimkeha
URL: https://www.opiq.ee/kit/56/chapter/3351
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.7
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, inimkeha, inimese, kehaosad, osad, lisa, millest, koosneb
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimkeha; Inimese kehaosad; Näo osad; Kehaosad; Lisa. Millest keha koosneb?

## Uus elu
URL: https://www.opiq.ee/kit/56/chapter/3352
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.8
Topics ET: loodusõpetus, hannes, käis, sünnitusmajas, lapse, saab, alguse, kõhus, rasedus, algus
Topics RU: природоведение
Topics EN: science
Headings: Uus elu; Hannes käis sünnitusmajas; Lapse elu saab alguse ema kõhus; Rasedus ja elu algus; Lisa. Ultraheli; Ultraheli

## Tähtsad päevad minevikust
URL: https://www.opiq.ee/kit/56/chapter/3353
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.9
Topics ET: loodusõpetus, tähtsad, päevad, minevikust, sünnipäevad, pühad, milliseid, tähtpäevi, tähistab, vaid
Topics RU: природоведение
Topics EN: science
Headings: Tähtsad päevad minevikust; Sünnipäevad; Pühad; Milliseid tähtpäevi tähistab vaid Eesti?; Tähtsad päevad; Milliseid tähtpäevi tähistavad ka teised riigid?

## Impressum
URL: https://www.opiq.ee/kit/56/chapter/2772
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 3.1
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Mõisted
URL: https://www.opiq.ee/kit/56/chapter/2773
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 4.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Inimeseõpetus 2. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/286
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 129
Topics ET: matemaatika, inimeseõpetus, klassile, lihtsustatud, õppekava, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus 2. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/286
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 168
Topics ET: matemaatika, inimeseõpetus, klassile, lihtsustatud, õppekava, opiq
Topics RU: математика
Topics EN: mathematics

## Tervitamine ja hüvastijätmine
URL: https://www.opiq.ee/kit/286/chapter/15950
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 1.1
Topics ET: matemaatika, tervitamine, hüvastijätmine, ilmed, teretamine, tere, sulle, teretan, jätan, hüvasti
Topics RU: математика
Topics EN: mathematics
Headings: Tervitamine ja hüvastijätmine; 1. Näo-ilmed; 1.; 2. Teretamine; 3. Tere, tere sulle; 4. Teretan. Jätan hüvasti; 5. Viisakas käitumine; 6. Viisakad vastused; Tööleht; Tööleht 1.1.

## Mina
URL: https://www.opiq.ee/kit/286/chapter/15951
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 1.2
Topics ET: matemaatika, mina, miia, vali, küsimus, vastus, eesnimi, perekonnanimi, sinu, nimi
Topics RU: математика
Topics EN: mathematics
Headings: Mina; 1. Miia ja Ott; VALI; 2. Küsimus ja vastus; 3. Eesnimi ja perekonnanimi; 7. Mis on sinu nimi?; 4. Laste välimus; 5. Minu välimus; 6. Vanus; Minu vanus; 7. Küsime ja vastame; 8. Mina ja minu klass; Tööleht; Tööleht 1.2.

## Minu õpetaja. Õpetajate päev
URL: https://www.opiq.ee/kit/286/chapter/16084
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 1.3
Topics ET: matemaatika, õpetajate, päev, töötab, koolis, lilled, õpetajale, soovid, vaasis, tööleht
Topics RU: математика
Topics EN: mathematics
Headings: Minu õpetaja. Õpetajate päev; 1. Minu õpetaja; 2. Õpetaja töötab koolis; 3. Õpetajate päev; Õpetajate päev; 4. Lilled õpetajale; 5. Soovid õpetajale; 6. Lilled vaasis; Lilled; Tööleht; Tööleht 1.3.

## Asjad koolis
URL: https://www.opiq.ee/kit/286/chapter/16085
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 1.4
Topics ET: matemaatika, asjad, koolis, meie, ühised, asjade, küsimine, kaaslaselt, kuidas, kadri
Topics RU: математика
Topics EN: mathematics
Headings: Asjad koolis; 1. Minu asjad; 2. Meie asjad; 3. Meie ühised asjad; 4. Õpetaja asjad; 5. Asjade küsimine kaaslaselt; 11. Kuidas Kadri võiks õpetajalt kella küsida?; 6. Laenamine ja tagastamine; 7. Asjade laenamine. Varastamine; Tööleht; Tööleht 1.4.

## Tegevused koolis
URL: https://www.opiq.ee/kit/286/chapter/16577
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 1.5
Topics ET: matemaatika, tegevused, koolis, nädalapäevad, tunnid, tund, mulle, meeldib, meeldi, lemmiktund
Topics RU: математика
Topics EN: mathematics
Headings: Tegevused koolis; 1. Nädalapäevad; 2. Tunnid koolis; Mis tund on (3)?; Mis tund on (1)?; Mis tund on (2)?; 3. Mulle meeldib. Mulle ei meeldi; Meeldib , ei meeldi?; Minu lemmiktund; 4. Vahetunnid; 5. Sõbralikud lapsed; Sõbralik või kiusaja?; 6. Mängud; Tööleht; Tööleht 1.5.

## Inimesed koolis
URL: https://www.opiq.ee/kit/286/chapter/16578
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 1.6
Topics ET: matemaatika, inimesed, koolis, õpetajad, teised, töötajad, pildil, meie, kelle, asjad
Topics RU: математика
Topics EN: mathematics
Headings: Inimesed koolis; 1. Õpetajad koolis; 2. Teised töötajad koolis; Kes on pildil? (inimesed koolis); Töötajad minu koolis; 3. Töötajad meie koolis; Töötajad minu koolis 2.; 4. Kelle asjad?; 5. Tervitamine koolis; 6. Teatamine. Abi küsimine; Tööleht; Tööleht 1.6.

## Liiklusmärgid, valgusfoor
URL: https://www.opiq.ee/kit/286/chapter/16790
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 2.1
Topics ET: matemaatika, geomeetria, kujund, kujundid, sirge, lõik, liiklusmärgid, valgusfoor, liiklus, meie, ümber, liiklusmärgi, tunnused, märk, nimetus
Topics RU: математика, геометрия, фигура, фигуры, прямая, отрезок
Topics EN: mathematics, geometry, shape, shapes, line, segment
Headings: Liiklusmärgid, valgusfoor; 1. Liiklus meie ümber; 2. Liiklusmärgi tunnused; 3. Liiklusmärgid; Märk ja nimetus.; Kujund ja märk; 4. Valgusfoor; 9. Mis värvi tuli põleb valgus-fooris?; 5. Sõidutee ületamine; Tööleht; Tööleht 2.1.

## Helkur. Lapsed liikluses
URL: https://www.opiq.ee/kit/286/chapter/16791
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 2.2
Topics ET: matemaatika, helkur, lapsed, liikluses, liiklus, õige, vale, liiklusmärkide, värvus, pilt
Topics RU: математика
Topics EN: mathematics
Headings: Helkur. Lapsed liikluses; 1. Liiklus; 2. Helkur; 3. Õige või vale?; Õige või vale? (4.); Õige või vale? (1.); Õige või vale? (2.); Õige või vale? (3.); 4. Liiklusmärkide värvus ja pilt; 5. Mis märk ei sobi ritta?; Tööleht; Tööleht 2.2.

## Sõidukid ja käitumine
URL: https://www.opiq.ee/kit/286/chapter/16792
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 2.3
Topics ET: matemaatika, sõidukid, käitumine, sõiduk, liigub, lünklaused, sõidab, liikumine, kooli, koju
Topics RU: математика
Topics EN: mathematics
Headings: Sõidukid ja käitumine; 1. Sõidukid; Sõidukid; 2. Kus sõiduk liigub?; Lünklaused; 3. Mis sõiduk see on?; 3. Mis sõiduk sõidab?; 4. Liikumine kooli ja koju; Kuidas tuled kooli?; 5. Sõitmine autos; 6. Sõidukid ja pilet; Pilet sõidukis; 7. Pilet ühissõidukis; 8. Käitumine sõidukis ja väljumisel; Tööleht; Tööleht 2.3.

## Minu kodu
URL: https://www.opiq.ee/kit/286/chapter/16912
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 3.1
Topics ET: matemaatika, kodu, erinevad, majad, suur, maja, laste, kodud, maal, linnas
Topics RU: математика
Topics EN: mathematics
Headings: Minu kodu; 1. Erinevad majad; Kui suur on see maja?; 2. Laste kodud; Maal - linnas; 3. Minu kodu; 4. Postkast ja ümbrik; 5. Nimi ja aadress; Nimi ja aadress; 6. Minu nimi ja aadress; Aadress (3); Aadress (1); Aadress (2); 7. Ruumid ja asjad; 8. Lapse tuba; Tööleht; Tööleht 3.1.

## Minu pere
URL: https://www.opiq.ee/kit/286/chapter/16913
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 3.2
Topics ET: matemaatika, loom, loomad, linnud, putukad, pere, miia, pilt, poeg, tütar, vend, siimu, kaili, miku
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Minu pere; 1. Miia pere pilt; 2. Miia pere; 3. Poeg ja tütar; Poeg ja tütar; 4. Õde ja vend; Siimu õed; Miia õde ja vend; Kaili õde ja vend; 5. Miku pere pilt; 6. Miku pere; 7. Erinevad pered; Mitu inimest on peres?; Perede suurused; 8. Minu pere; Vanavanemad. Loomad; Tööleht; Tööleht 3.2.

## Tegevused kodus
URL: https://www.opiq.ee/kit/286/chapter/16916
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 3.3
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, loom, loomad, linnud, putukad, tegevused, kodus, erinevad, miku, asjad, kuula, heli, lohista
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка, животное, животные, птицы, насекомые
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice, animal, animals, birds, insects
Headings: Tegevused kodus; 1. Erinevad tegevused kodus; 2. Loomad kodus; Loomad Miku kodus; 3. Asjad ja tegevused; KUULA heli. LOHISTA pildid samasse järje-korda.; 4. Aitame üksteist; Töötab või puhkab?; 5. Ohud kodus; Leia pildil ohukohad.; Tööleht; Tööleht 3.3.

## Vanemate ametid
URL: https://www.opiq.ee/kit/286/chapter/16914
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 3.4
Topics ET: matemaatika, vanemate, ametid, miia, õmbleja, asjad, asju, õmblejal, vaja, miku
Topics RU: математика
Topics EN: mathematics
Headings: Vanemate ametid; 1. Miia ema töö; 2. Õmbleja asjad; Mis asju on õmblejal vaja?; 3. Miku isa töö; 4. Talumehe asjad; Mida on vaja Miku isal?; 5. Kodused inimesed; 6. Vanemate ametid; Tööleht; Tööleht 3.4.

## Sugulased
URL: https://www.opiq.ee/kit/286/chapter/16917
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 3.5
Topics ET: matemaatika, sugulased, pereliikmed, vanaema, vanaisa, tädi, tädilapsed, miku, onulapsed, miia
Topics RU: математика
Topics EN: mathematics
Headings: Sugulased; 1. Pereliikmed; 2. Vanaema; Vanaema 1; 3. Vanaisa; Vanaisa 2; Vanaisa 1; 4. Tädi ja tädilapsed; Miku tädilapsed; Miku tädi; 5. Onu ja onulapsed; Miia onu ja onulapsed; 6. Sugulased; Tööleht; Tööleht_3.5

## Pere ja sugulased
URL: https://www.opiq.ee/kit/286/chapter/16915
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 3.6
Topics ET: matemaatika, pere, sugulased, meie, pereliikmete, nimed, vana, vanemad, vanavanemad, tädid
Topics RU: математика
Topics EN: mathematics
Headings: Pere ja sugulased; 1. Minu pere; Meie pere; Pereliikmete nimed; 2. Minu vana-vanemad; Vanavanemad; 3. Minu tädid ja onud; Tädi ja tädilapsed; Onu ja onulapsed; Tööleht; Tööleht 3.6.

## Aasta
URL: https://www.opiq.ee/kit/286/chapter/17080
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 4.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, aasta, ajad, aastas, kuud, erinevad, sündmused, pildid, liikuvad
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Aasta; 1. Aasta-ajad; 4.; 1.; 2.; 3.; Aastaajad; 2. Aastas on 12 kuud; 3. Kuud aastas; 4. Aasta-ajad ja kuud; Aastaajad ja kuud; 5. Erinevad kuud ja sündmused; Pildid (6); Pildid 1; Pildid 2; Pildid 3; Pildid 4; Pildid 5; 6. Liikuvad pühad; Vastlapäev, munadepühad; 7. Kuu, nädalad ja päevad; Tööleht; Tööleht 4.1.

## Minu sünnipäev
URL: https://www.opiq.ee/kit/286/chapter/17081
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 4.2
Topics ET: matemaatika, sünnipäev, päevad, miku, miia, sünnipäevad, laste, vanus, aastaaeg
Topics RU: математика
Topics EN: mathematics
Headings: Minu sünnipäev; 1. Kuu ja päevad; 2. Miku ja Miia sünnipäevad; 3. Sünnipäevad; Miku ja Miia sünnipäev; 4. Laste vanus; 5. Minu sünnipäev; Sünnipäev (vanus, aastaaeg); 6. Sama kuu sünnipäevad; 7. Õnnitlused sünnipäevaks; Tööleht; Tööleht 4.2.
Task examples: 4.B. Loe. Võrdle: VAREM või HILJEM.; 14. LOHISTA õige järje-kord.

## Kell
URL: https://www.opiq.ee/kit/286/chapter/17082
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 4.3
Topics ET: matemaatika, geomeetria, kujund, kujundid, sirge, lõik, aeg, kell, kalender, liigub, käib, mõistatus, erineva, kujuga, kellad, pildil
Topics RU: математика, геометрия, фигура, фигуры, прямая, отрезок, время, часы, календарь
Topics EN: mathematics, geometry, shape, shapes, line, segment, time, clock, calendar
Headings: Kell; 1. Aeg liigub; 2. Mis see käib?; Mõistatus (kell); 3. Kell käib; 4. Erineva kujuga kellad; Mis kujund on pildil?; Mis kujuga on kellad?; 5. Kella-aeg; Kellaajad 1.; 6. Ole täpne. Jälgi kella.; Nimed; 3. Tiit läks arsti juurde.; 1. Poiss jõudis kooli.; 2. Kertu tuli peole.; 7. Äratuskell; 8. Kell seisab; Tööleht; Tööleht 4.3.

## Päevakava
URL: https://www.opiq.ee/kit/286/chapter/17083
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 4.4
Topics ET: matemaatika, aeg, kell, kalender, päevakava, päev, vali, õiged, laused, märgi, sõnad, ööpäev, nädala
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Päevakava; 1. Öö ja päev; Vali õiged laused (Märgi sõnad.); 2. Öö-päev; Ööpäev; 3. Nädala-päevad; Nädala-päevad; Täna-eile jne; 4. Hommik ja õhtu; 5. Miia koolipäevad; Koolipäevad; 6. Miia huvi-alad; 7. Erinevad pillid; Mis pill on pildil?; Mis pilli heli see on?; 8. Laste tegevused. Vaba aeg; Mulle meeldivad need tegevused; Tööleht; Tööleht 4.4.

## Eestimaa. Eesti sümbolid
URL: https://www.opiq.ee/kit/286/chapter/17084
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 5.1
Topics ET: matemaatika, taim, taimed, puu, lill, eestimaa, eesti, sümbolid, linnad, kodukoht, eestimaal, mina, elan, eestis
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Eestimaa. Eesti sümbolid; 1. Eestimaa; Eesti linnad; 2. Kodukoht Eestimaal; 3. Mina elan Eestis; 2. Ülesanne (Minu elukoht); 4. Liikumine kodust kaugemale; Mikk läheb külla; 5. Eesti lipp; Eesti lipp; 6. Eesti lipp lehvib; 7. Lipu-päev; 8. Eesti lipu värvid looduses; 9. Rahvus-lill ja rahvus-lind; 10. Rahva-riided; Tööleht; Tööleht 5.1.

## Eesti riigi aastapäev. Pidulik riietus
URL: https://www.opiq.ee/kit/286/chapter/17085
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 5.2
Topics ET: matemaatika, eesti, riigi, aastapäev, pidulik, riietus, aastaaeg, praegu, dets, jaan
Topics RU: математика
Topics EN: mathematics
Headings: Eesti riigi aastapäev. Pidulik riietus; 1. Aastaaeg ja kuu; Aastaaeg ja kuu praegu (dets, jaan, veebr); 2. Eesti sünnipäev; Eesti riigi aastapäev; 3. Eesti sünnipäev on lipupäev; Kus lipp lehvib?; 4. Pidulik riietus; 5. Riiete hoidmine; 6. Eesti sünnipäev koolis; Pidulik riietus; 7. Eesti hümn; 8. Eesti sünnipäev kodus; Tööleht; Tööleht 5.2.

## Liikumine
URL: https://www.opiq.ee/kit/286/chapter/17527
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 6.1
Topics ET: matemaatika, liikumine, koos, lemmikloomaga, kuidas, liigud, sina, talvel, riietus, kellel
Topics RU: математика
Topics EN: mathematics
Headings: Liikumine; 1. Liikumine; Liikumine 3.; Liikumine 1.; Liikumine 2.; 2. Liikumine koos lemmikloomaga; 3. Kuidas liigud sina?; 4. Talvel – liikumine ja riietus; Kellel hakkab külm?; Kes on pildil? (Talvel õues); 5. Kõik inimesed ei saa hästi liikuda; 6. Õige või vale?; Õige või vale?; Õige või vale? 1.; Tööleht; Tööleht 6.1.

## Puhkus ja uni
URL: https://www.opiq.ee/kit/286/chapter/17528
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 6.2
Topics ET: matemaatika, aeg, kell, kalender, puhkus, liikumine, väsimine, kehale, silmadele, õppimise, ajal, lastest, puhkavad
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Puhkus ja uni; 1. Liikumine ja väsimine; 2. Puhkus kehale ja silmadele; 3. Puhkus õppimise ajal; Kes lastest puhkavad?; 4. Uni; Uni; 5. Piisav aeg magamiseks; Miia läheb voodisse; 6. Tegevused enne uinumist; Mida Miia teeb enne voodisse minemist?; 7. Tegevused pärast ärkamist; Mida poiss teeb pärast ärkamist?; Tööleht; Tööleht 6.2.

## Puhas laps
URL: https://www.opiq.ee/kit/286/chapter/17529
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 6.3
Topics ET: matemaatika, aeg, kell, kalender, puhas, laps, kehaosad, pesemine, lastest, peab, pesema, puhtad, käed
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Puhas laps; 1. Kehaosad ja pesemine; Kes lastest peab pesema?; 2. Puhtad käed; 3. Pesemise koht ja vahendid; 4. Pesemise aeg; 5. Juuksed; Juuksed; 6. Puhtad riided; 2. Ülesanne; 7. Ole ettevaatlik!; Tööleht; Tööleht 6.3.

## Meie toit
URL: https://www.opiq.ee/kit/286/chapter/17530
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 6.4
Topics ET: matemaatika, meie, toit, joogid, jook, sulle, maitseb, joogis, suhkrut, suhkur
Topics RU: математика
Topics EN: mathematics
Headings: Meie toit; 1. Joogid; Mis jook sulle maitseb?; Mis joogis ei ole suhkrut?; SUHKUR JOOGI SEES; 2. Mis võis juhtuda?; 3. Köögiviljad, puuviljad, marjad; Tikrid ja sõstrad ...; Sibul ja kapsas on ...; Herned ja oad on ...; Kõrvits ja porgand on ...; Õun ja pirn on ...; Kirsid ja ploomid on ...; 4. Rämpstoit; 5. Toitude rühmad; 6. Söögiajad; Mina söön (millal?); 7. Toidukorrad ja vahepalad; Toidukorrad; Toidukorrad ja vahepalad; 8. Tervislik toit; Tööleht; Tööleht 6.4.

## Toidulaud ja käitumine
URL: https://www.opiq.ee/kit/286/chapter/17531
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 6.5
Topics ET: matemaatika, toidulaud, käitumine, pereliikmete, tegevused, söögikord, toidunõud, laual, puhtus, laua
Topics RU: математика
Topics EN: mathematics
Headings: Toidulaud ja käitumine; 1. Pereliikmete tegevused; Söögikord; Toidunõud; 2. Toidunõud; 3. Toidunõud laual ja puhtus; 4. Laua katmine; 5. Söömine ja lauakombed; Õige koht; Viisakas ja puhas laps; Tervislik toit; Tööleht; Tööleht 6.5.

## Terved hambad
URL: https://www.opiq.ee/kit/286/chapter/17532
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 6.6
Topics ET: matemaatika, terved, hambad, bakterid, suus, mida, vaja, pildil, sobita, hamba
Topics RU: математика
Topics EN: mathematics
Headings: Terved hambad; 1. Minu suu; 2. Bakterid suus; 3. Mida on vaja?; Mis on pildil? (sobita); 4. Hamba-pasta ja hamba-niit; 5. Hammaste pesemine; 6. Hamba-sõbralik toit; Mis toit on hea hammastele?; 7. Hamba-arst; Timo; Tööleht; Tööleht 6.6.

## Haige laps ja terve laps
URL: https://www.opiq.ee/kit/286/chapter/17533
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 6.7
Topics ET: matemaatika, haige, laps, terve, haiguse, tunnused, palav, palavik, mida, haigele
Topics RU: математика
Topics EN: mathematics
Headings: Haige laps ja terve laps; 1. Haige või terve?; Terve laps; 2. Haiguse tunnused; Haiguse tunnused; 3. Palav või palavik?; Palav või palavik?; Mida on haigele lapsele vaja?; 4. Kodune ravi; Mida teed kodus haiguse ajal?; 5. Ravimid; Millisel pildil on ravimid?; 6. Haige laps ja arst; 6. Terve laps ja arst; Mida arst teeb?; 7. Kes aitab?; Tööleht; Tööleht 6.7.

## Vanad ja uued asjad
URL: https://www.opiq.ee/kit/286/chapter/17534
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 7.1
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, vanad, uued, asjad, asjade, hind, teele, timo, rõõmus, kurb
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Vanad ja uued asjad; 1. Asjad ja asjade hind; Asjad; 2. Asjade hind; 3. Teele ja Timo; Rõõmus-kurb; 4. Asja väärtus; Kellel?; Timo; 4. Ülesanne; 5. Asju saab korda teha; 6. Vana-aja asjad; Asjad praegu ja vanasti; 7. Vanad asjad; 8. Muuseum; 9. Erinevad muuseumid; 10. Ristsõna; Ristsõna; Tööleht; Tööleht 7.1.

## Asjad ja prügi
URL: https://www.opiq.ee/kit/286/chapter/17535
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 7.2
Topics ET: matemaatika, asjad, prügi, toas, joogi, pakendid, joogipakendid, tühi, taara
Topics RU: математика
Topics EN: mathematics
Headings: Asjad ja prügi; 1. Asjad toas; 2. Prügi; 2. Ülesanne; 3. Joogi-pakendid; Joogipakendid; 4. Tühi taara; 5. Erinevad prügikastid; 6. Sorteerime prügi; Millisesse prügikasti need asjad sobivad?; 7. Ohtlik prügi; prügi; 8. Meisterdame prügist; 3. Ülesanne; Tööleht; Tööleht 7.2.

## Telefon
URL: https://www.opiq.ee/kit/286/chapter/17536
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 7.3
Topics ET: matemaatika, arv, arvud, arvu, numbrid, telefon, telefonid, aegadel, erinevad, mikk, helistab, isale, helistas, tegevuste
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Telefon; 1. Telefonid eri aegadel; 2. Erinevad telefonid; 3. Minu telefon; 4. Mikk helistab isale; Mikk helistas isale (tegevuste järjekord); 5. Miku ja isa jutt; 6. Miia helistab emale; 7. Lapsed helistavad vanematele; Lapse soov; 8. Õnnetus mänguväljakul; 1. Ülesanne; Kes aitasid poissi?; 9. Hädaabi; Hädaabi number; Tööleht; Tööleht 7.3.

## Võõrad inimesed, asjad ja loomad
URL: https://www.opiq.ee/kit/286/chapter/17537
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 8.1
Topics ET: matemaatika, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, võõrad, inimesed, asjad, võõras, meie, kodus, nägu, hoia
Topics RU: математика, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье
Topics EN: mathematics, animal, animals, birds, insects, human, body, senses, health
Headings: Võõrad inimesed, asjad ja loomad; 1. Võõras meie kodus; Isa nägu; 2. Hoia oma kodu; 3. Võõras on ukse taga; 4. Õige või vale käitumine?; TEELE. Kas laps teeb õigesti?; MIKK. Kas laps teeb õigesti?; KADRI. Kas laps teeb õigesti?; 5. Võõras kutsub endaga kaasa; 6. Kuidas sa käitud?; Võõras inimene; 7. Tundmatud ja võõrad asjad; 8. Käitumine loomadega; Tööleht; Tööleht 8.1.

## Võõras ümbrus ja eksimine
URL: https://www.opiq.ee/kit/286/chapter/17538
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 8.2
Topics ET: matemaatika, võõras, ümbrus, eksimine, suures, rahvahulgas, kadri, nägu, küsis, märka
Topics RU: математика
Topics EN: mathematics
Headings: Võõras ümbrus ja eksimine; 1. Eksimine suures rahvahulgas; Kadri nägu; 2. Kadri küsis abi; 3. Märka ümbrust; Koht; Mida jätad meelde?; 4. Teatamine enda asukohast; 5. Eksimine metsas; Kus on Miia?; Metsas (Ole nähtav! Ole paigal!); Tööleht; Tööleht 8.2.

## Metoodilised juhised õppevara kasutamiseks (print-pdf)
URL: https://www.opiq.ee/kit/286/chapter/15952
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 9.1
Topics ET: matemaatika, metoodilised, juhised, õppevara, kasutamiseks, print, peitu
Topics RU: математика
Topics EN: mathematics
Headings: Metoodilised juhised õppevara kasutamiseks (print-pdf); Peitu

## Mängude ja tegevuste juhendid (print-pdf)
URL: https://www.opiq.ee/kit/286/chapter/15953
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 9.2
Topics ET: matemaatika, mängude, tegevuste, juhendid, print, peitu
Topics RU: математика
Topics EN: mathematics
Headings: Mängude ja tegevuste juhendid (print-pdf); Peitu

## Inimeseõpetus 2. klassile I osa (print-pdf)
URL: https://www.opiq.ee/kit/286/chapter/15954
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 9.3
Topics ET: matemaatika, inimeseõpetus, klassile, print, peitu
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 2. klassile I osa (print-pdf); Peitu

## Inimeseõpetus 2. klassile II osa (print-pdf)
URL: https://www.opiq.ee/kit/286/chapter/17079
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 9.4
Topics ET: matemaatika, inimeseõpetus, klassile, print, failid
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 2. klassile II osa (print-pdf); Failid

## Impressum
URL: https://www.opiq.ee/kit/286/chapter/15955
Book: Inimeseõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Harno
Book ID: harno_inimeseõpe_2_et
Chapter ID: 9.5
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## IN2 – Opiq
URL: https://www.opiq.ee/Kit/Details/142
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 89
Topics ET: matemaatika, opiq
Topics RU: математика
Topics EN: mathematics

## IN2 – Opiq
URL: https://www.opiq.ee/Kit/Details/142
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 128
Topics ET: matemaatika, opiq
Topics RU: математика
Topics EN: mathematics

## Mina
URL: https://www.opiq.ee/kit/142/chapter/7988
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 1.1
Topics ET: matemaatika, mina, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Mina; Lisaülesanne 1; Lisaülesanne 1b
Task examples: Missugune sina oled? Kirjuta lünka. Ülesanne 1 Minu nimi on . Ma olen aastat vana. Mina olen (tüdruk/poiss). Minu sünnipäev on . Minu juuksed on . Minu silmad on . Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kop; Missugune on sinu klass? Koosta selle näidisdiagrammi põhjal oma diagramm: värvi igas tulbas nii mitu ristkülikut, kui palju on sinu klassis vastavas vanuses õpilasi. Kui soovid, võid näidisdiagrammi ka välja printida. ​

## Minu tegevused
URL: https://www.opiq.ee/kit/142/chapter/7989
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 1.2
Topics ET: matemaatika, tegevused
Topics RU: математика
Topics EN: mathematics
Headings: Minu tegevused
Task examples: Mida sa oskad ja mida ei oska? Märgi tegevused, mida oskad. Ülesanne 4a lugemine laulmine tantsimine ujumine lendamine küünte lõikamine Salvesta Kirjuta veel tegevusi juurde. Ülesanne 4b OSKANEI OSKA Salvesta Moodusta ta; Moodusta silpidest sõnu, mis väljendavad tegevusi. Ülesanne 5 HÜP MI NE PA MÄN MI NE GI LII MI NE MI LU MI NE GE MAA MI NE LI VÕRD MI NE LE : 0 : 0 Kirjuta iga sõna alla joonele, mis tundides seda tegevust teed. Lisa oma

## Minu huvialad
URL: https://www.opiq.ee/kit/142/chapter/7990
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 1.3
Topics ET: matemaatika, huvialad
Topics RU: математика
Topics EN: mathematics
Headings: Minu huvialad
Task examples: Karli klassi lapsed rääkisid, mida nad vabal ajal teevad. Uuri diagrammi ja vasta diagrammi põhjal küsimustele. Ülesanne 7 Mitu Karli klassi poissi käib robootikaringis? Mitu tantsupaari on nende rahvatantsurühmas? Poole; Mis huviringe sa tead? Kirjuta sobivasse tulpa. Ülesanne 8 MuusikaSportKunst Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 202

## Käitumine tänaval
URL: https://www.opiq.ee/kit/142/chapter/7991
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 1.4
Topics ET: matemaatika, käitumine, tänaval
Topics RU: математика
Topics EN: mathematics
Headings: Käitumine tänaval
Task examples: Vali plaanilt maja, kus tahaksid elada. Trüki pilt välja ja värvi. Ohutuks liiklemiseks peab täitma liiklusreegleid. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õpp; Mis ohud võivad olla liikluses? Jutusta. Mis ohud võivad olla sinu kooliteel? Kirjuta. Ülesanne 13 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 201

## Head kombed
URL: https://www.opiq.ee/kit/142/chapter/7992
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 1.5
Topics ET: matemaatika, head, kombed, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Head kombed; Lisaülesanne 2; Lisaülesanne 2a; Lisaülesanne 2b
Task examples: Mis reegleid tuleb täita tänaval? Jutusta. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õppekava 2; Mis reegleid täidad koolis? Jutusta. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õppekava 2010 Põ

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/7993
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 1.6
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Kas järgmised laused on õiged või valed? Ülesanne 24 Meie klassis on kõige rohkem 7-aastaseid lapsi. ÕigeVale Kõik inimesed erinevad üksteisest. ÕigeVale Mina olen poiss. ÕigeVale Jalgpallitrennis käimine on muusikaga te; Kas sina oled viisakas ja täidad reegleid? Mõtle järele ja vali sobiv vastus. Ülesanne 25 Täidan klassireegleid. Alati Sageli Harva Jalakäijana täidan liiklusreegleid. Alati Sageli Harva Arvestan teistega. Alati Sageli H

## Minu kodu ja pere
URL: https://www.opiq.ee/kit/142/chapter/7994
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 2.1
Topics ET: matemaatika, kodu, pere
Topics RU: математика
Topics EN: mathematics
Headings: Minu kodu ja pere
Task examples: Pered on erinevad. Vaata pilte ja jutusta. Missuguseid peresid sa veel tead? Jutusta. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 202; Joonista oma pere. Kirjuta pereliikmete nimed. Tutvusta oma pereliikmeid klassikaaslastele. Pere jaoks on väärtuslik iga liige. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: 

## Pereliikmete tööd
URL: https://www.opiq.ee/kit/142/chapter/7995
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 2.2
Topics ET: matemaatika, pereliikmete, tööd, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Pereliikmete tööd; Lisaülesanne 3
Task examples: Kes teeb neid töid sinu kodus? Kirjuta (enda puhul kirjuta oma nimi). Ülesanne 5 teeb süüa. lõhub puid. triigib pesu. kastab lilli. katab lauda. peseb nõusid. koristab tuba. viib prügi välja. vahetab auto ratast. jalutab; Mis koduseid töid sinu peres veel tehakse? Täida tabel. Ülesanne 6 KesMida teeb Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 

## Muutused peres
URL: https://www.opiq.ee/kit/142/chapter/7996
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 2.3
Topics ET: matemaatika, muutused, peres
Topics RU: математика
Topics EN: mathematics
Headings: Muutused peres
Task examples: Kui perre tuleb väike õde või vend, tähendab see uusi võimalusi ja kohustusi. Mis sulle meeldiks (+) või ei meeldiks (-)? Lapse tulek perre toob kaasa muutused. Ülesanne 12 Väikese õe või vennaga jalutamas käimine. +– La; Alfredil on kohustus hoolitseda oma lemmiklooma eest. Vaata pilte ja jutusta. Ats: Alfred, miks sa kurb oled?Alfred: Minu Puhvi ei tahtnud täna hommikul süüa ega juua. Ta ei liigutanudki end. Siis nägin, et ta on surnud.

## Pidupäevad peres
URL: https://www.opiq.ee/kit/142/chapter/7997
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 2.4
Topics ET: matemaatika, pidupäevad, peres
Topics RU: математика
Topics EN: mathematics
Headings: Pidupäevad peres
Task examples: Kas neid tähtpäevi peetakse sinu peres? Vali sobiv vastus. Ülesanne 16a Tähtpäev(Jah/Ei)Kuupäev1.uusaasta JahEi 24. veebruar2.kolmekuningapäev JahEi 1.1. jaanuar3.vastlapäev JahEi 6. jaanuar4.sõbrapäev JahEi liikuv püha5

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/7998
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 2.5
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Otsusta, kas järgmised laused on õiged või valed? Ülesanne 17 Mõnes peres on kaks liiget. ÕigeVale Sinu ema on nii sinu pere liige kui ka sugulane. ÕigeVale Sinu ema ema ja isa ema on üks ja sama inimene. ÕigeVale Kirjak; Kui sageli oled abivalmis ja kohusetundlik pereliige? Mõtle ja märgi sobiv vastus. Ülesanne 18 Kuulan oma vanemate sõna. Alati Sageli Harva Aitan teha koduseid töid. Alati Sageli Harva Valmistan pereliikmetele rõõmu. Ala

## Ohud kodus
URL: https://www.opiq.ee/kit/142/chapter/7999
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 3.1
Topics ET: matemaatika, ohud, kodus
Topics RU: математика
Topics EN: mathematics
Headings: Ohud kodus
Task examples: Prindi pilt ja värvi ohtlikud kohad/asjad. Õnnetuse ärahoidmiseks tuleb olla ettevaatlik. Selgita, miks ja millal need on ohtlikud. Joonista pildile suitsuandur. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link T; Miks on suitsuandur vajalik? Arutlege. Mitu suitsuandurit on sinu klassiruumis ja mitu kodus? Loe kokku ja täida lüngad. Ülesanne 2 Klassiruumis on suitsuandurit. Kodus on suitsuandurit. Salvesta Lisa oma materjali Tekst

## Häire koolis
URL: https://www.opiq.ee/kit/142/chapter/8000
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 3.2
Topics ET: matemaatika, häire, koolis
Topics RU: математика
Topics EN: mathematics
Headings: Häire koolis
Task examples: Mis võib olla juhtunud, kui koolikell katkestab alanud tunni? Arutlege. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli li; Kuidas tuleb tegutseda, kui koolis on puhkenud tulekahju? Arutlege. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsu

## Ohud ümbruses
URL: https://www.opiq.ee/kit/142/chapter/8001
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 3.3
Topics ET: matemaatika, ohud, ümbruses
Topics RU: математика
Topics EN: mathematics
Headings: Ohud ümbruses
Task examples: Jutusta, mis juhtus Jüriga. Miks õnnetus juhtus? Kuidas käituda, kui keegi on läbi jää vajunud? Õnnetuse korral hüüa appi. Püüa ronida jääle ja roomata kalda poole tagasi. Lisa oma materjali Tekstiabi Muud tegevused Kope; Mari väljus vales peatuses ja on eksinud. Mida peaks Mari niisuguses olukorras teadma? Ülesanne 12a kodu aadressi oma koera nime kus ta on ema (või isa või venna või õe) telefoninumbrit : 0 : 0 Kuidas peaks Mari tegutsem

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/8002
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 3.4
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Kas järgmised laused on õiged või valed? Vali õige vastus. Ülesanne 13 Vooluvõrku unustatud triikraud võib põhjustada tulekahju. ÕigeVale Lahtine tuli kodus peab olema järelevalve all. ÕigeVale Kodus peab olema igas toas; Kui sageli toimid nii? Mõtle järele ja vali sobiv vastus. Ülesanne 14 Aitan, kui keegi abi palub. Alati Sageli Harva Olen klassikaaslastega sõbralik. Alati Sageli Harva Mõtlen võimalikele ohtudele. Alati Sageli Harva Sal

## Jõulud
URL: https://www.opiq.ee/kit/142/chapter/8003
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 4.1
Topics ET: matemaatika, jõulud, küünalde, põletamine
Topics RU: математика
Topics EN: mathematics
Headings: Jõulud; Küünalde põletamine
Task examples: Märgi loetelus jõulukombed plussiga (+). Need, mis ei ole jõulukombed, märgi miinusega (-). Ülesanne 1 Kuuse ehtimine +– Ilutulestiku tegemine +– Kirikus käimine +– Sanditamine +– Küünalde põletamine +– Lõkke tegemine +–; Mitu küünalt on pildil? Kirjuta joonele vastus. Ülesanne 2 : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsus

## Aeg ja aja mõõtmine
URL: https://www.opiq.ee/kit/142/chapter/8004
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 4.2
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, aeg, kell, kalender
Topics RU: математика, измерение, единица измерения, длина, масса, объём, время, часы, календарь
Topics EN: mathematics, measurement, unit, length, mass, volume, time, clock, calendar
Headings: Aeg ja aja mõõtmine
Task examples: Täida lüngad. Vali rippmenüüst, kas jutuks on minevik, olevik või tulevik. Ülesanne 10 Ma sündisin . aastal. MINEVIKOLEVIKTULEVIK Praegu on tund. MINEVIKOLEVIKTULEVIK Järgmisel aastal olen . klassis. MINEVIKOLEVIKTULEVIK; Täienda skeemi iseenda kohta. Ülesanne 11 lasteaed MINEVIK 2. klassi lõpetamine TULEVIK 2. klassi õpilaneOLEVIK Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik

## Aja kavandamine
URL: https://www.opiq.ee/kit/142/chapter/8005
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 4.3
Topics ET: matemaatika, kavandamine
Topics RU: математика
Topics EN: mathematics
Headings: Aja kavandamine
Task examples: Tutvu Jaanuse ühe nädala plaaniga. Vasta küsimustele Jaanuse nädalaplaani põhjal. Ülesanne 19a Mitu tundi nädalas on Jaanus koolis? Mitu tundi nädalas tegeleb Jaanus huvialadega? Mitu tundi nädalas veedab Jaanus sõpradeg; Mõtle homsele päevale. Koosta oma päevakava. Ülesanne 20a KellaaegTegevus6.00 7.00 8.00 9.00 10.00 11.00 12.00 13.00 14.00 15.00 16.00 17.00 18.00 19.00 20.00 21.00 22.00 Salvesta Kirjuta lünka tegevused, millest tunned 

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/8006
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 4.4
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Vali õige lauselõpp. Ülesanne 22 Aeg liigub … minevikust tulevikku. tulevikust minevikku. See, mis toimub praegu, on … minevik. olevik. Ühes nädalas on … 24 tundi. 7 päeva. Kevadkuud on … aprill, mai, märts. märts, april; Kas sina oled täpne ja täidad kohustusi? Mõtle järele ja märgi sobiv vastus. Ülesanne 23 Kavandan oma päeva. Alati Sageli Harva Käin huviringides meelsasti. Alati Sageli Harva Teen ära kodused ülesanded. Alati Sageli Har

## Asja väärtus ja hind
URL: https://www.opiq.ee/kit/142/chapter/8007
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 5.1
Topics ET: matemaatika, asja, väärtus, hind, kadunud, binokkel, asjade
Topics RU: математика
Topics EN: mathematics
Headings: Asja väärtus ja hind; Kadunud binokkel; Asjade hind
Task examples: Pane kirja asjad, mida endale sooviksid. Ülesanne 1a Salvesta Mis neist on sinu arvates eluks hädavajalikud? Kirjuta need joonele. Põhjenda oma valikut. Ülesanne 1b Salvesta Lisa oma materjali Tekstiabi Muud tegevused Ko; Toit, riided ja eluase on eluks hädavajalikud. Ülejäänud asjad muudavad inimese elu paremaks, mugavamaks, kergemaks. Neid saab endale osta siis, kui esmavajadused on rahuldatud. Otsusta, missuguseid asju kindlasti vajad.

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/8008
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 5.2
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Kas järgmised laused on õiged või valed? Ülesanne 8 Minu sõbra asjad on ka minu asjad. ÕigeVale Koolis on kõik asjad kõikide omad. ÕigeVale Kooli ei tohi kaasa võtta hinnalisi asju. ÕigeVale Laenatud asja annan tagasi ai; Mis asjad on koolis sinu meelest hädavajalikud? Vali + või -. Põhjenda oma valikut. Ülesanne 13a +– +– +– +– +– +– +– +– +– +– +– +– +– +– +– +– Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata vea

## Eesti Vabariik
URL: https://www.opiq.ee/kit/142/chapter/8009
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 6.1
Topics ET: matemaatika, eesti, vabariik, vabariigi, lipp, vapp, hümn, valitsus, president
Topics RU: математика
Topics EN: mathematics
Headings: Eesti Vabariik; Eesti Vabariigi lipp, vapp ja hümn; Eesti Vabariigi valitsus ja president; Lisaülesanne; Eesti Vabariigi hümn
Task examples: Uuri kaarti ja otsusta, kus asub Eesti ning tema naaberriigid. Lohista kaardil riikide nimed õigesse kohta. Ülesanne 1a {"data":["EESTI","LÄTI","SOOME","ROOTSI","VENEMAA"]}EESTI11LÄTI22SOOME33ROOTSI44VENEMAA55 : 0 : 0 Ig; Uuri Eesti kaarti. Leia kaardilt oma kodukoht. Ülesanne 2 Mina elan maakonnas. Eestis on kokku maakonda. : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekav

## Minu kodukoht
URL: https://www.opiq.ee/kit/142/chapter/8010
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 6.2
Topics ET: matemaatika, kodukoht
Topics RU: математика
Topics EN: mathematics
Headings: Minu kodukoht
Task examples: Kus sa elad? Kirjuta. Ülesanne 7 Mina elan... maakonnas vallas/linnas külas/alevis/alevikus tänaval Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 20; Millised on Eesti maakondade vapid? Ühenda maakond vapiga. Ülesanne 8 {"data":["Põlvamaa","Ida-Virumaa","Pärnumaa","Harjumaa","Võrumaa","Tartumaa","Järvamaa","Raplamaa","Saaremaa","Läänemaa","Hiiumaa","Jõgevamaa","Lääne-

## Elu linnas ja maal
URL: https://www.opiq.ee/kit/142/chapter/8011
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 6.3
Topics ET: matemaatika, linnas, maal
Topics RU: математика
Topics EN: mathematics
Headings: Elu linnas ja maal
Task examples: Vaata pilte ja vali õige pealkiri. Ülesanne 11a MaalLinnas : 0 : 0 Kus keegi töötab? Kirjuta pildi põhjal igasse lünka sobiv number. Ülesanne 11b näitleja politseinik müüja õpetaja taksojuht trammijuht insener juuksur ap; Mis ametite esindajaid on nii linnas kui maal? Kirjuta. Ülesanne 12 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikoo

## Eestimaa rikkus
URL: https://www.opiq.ee/kit/142/chapter/8012
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 6.4
Topics ET: matemaatika, eestimaa, rikkus, tuntud, inimesed, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Eestimaa rikkus; Tuntud inimesed; Lisaülesanne 5; Lisaülesanne 5a; Lisaülesanne 5b
Task examples: Kas sina oled nendes kohtades käinud? Ülesanne 14a JahEi JahEi JahEi JahEi JahEi JahEi JahEi JahEi JahEi Salvesta Kuhu sa tahaksid Eestimaal veel minna? Kirjuta ja põhjenda, miks sa tahad just sellesse paika minna. Ülesa; Kes on need tuntud Eesti inimesed? Ühenda nimi ja foto. Vajadusel kasuta internetti. Ülesanne 15 {"data":["vigursuusataja Kelly Sildaru","rallisõitja Ott Tänak","näitleja Hele Kõrve","kunstnik ja kirjanik Piret Raud","he

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/8013
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 6.5
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Lõpeta laused. Eestimaa rikkus, kolm lõvi, rahvusvärvid, riigilipu, seistakse püsti, sõnade autor, sünnipäev, Tallinn, Kersti Kaljulaid, vapp Ülesanne 16 Eesti Vabariigi pealinn on . Eesti lipul on eesti . Eesti Vabariig; Kui sageli toimid nii? Mõtle järele ja vali sobiv vastusevariant. Ülesanne 17 Eesti Vabariigi hümni kuulates seisan püsti. Alati Sageli Harva Külastan meelsasti Eestimaa kauneid paiku. Alati Sageli Harva Õppekäikudel pea

## Minu tervis
URL: https://www.opiq.ee/kit/142/chapter/8014
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 7.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, puhtus
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Minu tervis; Puhtus
Task examples: Kas need tegevused ja valikud aitavad olla terve? Loe ja otsusta. Ülesanne 1 Pidev teleri vaatamine JahEi Hammaste pesemine JahEi Puhtus JahEi Rõõmus meel JahEi Ilmale vastav riietus JahEi Magamine JahEi Liikumismängud J; Kes on terve ja kes on haige? Vali piltidele sobivad pealkirjad. Ülesanne 2a Haige lapsJänes JussTerve laps Haige lapsJänes JussTerve laps : 0 : 0 Kuidas tunnevad end piltidel olevad lapsed? Kirjuta. Ülesanne 2b Salvesta

## Hoian oma tervist
URL: https://www.opiq.ee/kit/142/chapter/8015
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 7.2
Topics ET: matemaatika, hoian, tervist, puhkus
Topics RU: математика
Topics EN: mathematics
Headings: Hoian oma tervist; Puhkus
Task examples: Mis tegevused sulle meeldivad? Märgi. Ülesanne 6a +– +– +– +– +– +– +– +– +– +– +– +– +– Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik ; Tutvu loetletud tegevustega. Kas ja kui tihti sina neid tegevusi teed? Ülesanne 7 Hommikvõimlemine Ei teeHarva, kuni pool tundiMitu korda päevas Teleri vaatamine Ei teeHarva, kuni pool tundiMitu korda päevas Kõndimine vä

## Tervislik toiduvalik
URL: https://www.opiq.ee/kit/142/chapter/8016
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 7.3
Topics ET: matemaatika, tervislik, toiduvalik, ebatervislikud, toiduained, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Tervislik toiduvalik; Ebatervislikud toiduained; LISAÜLESANNE. Tervislik toiduvalik
Task examples: Pildil on tervislik toiduvalik. Märgi toidud, mida sa eile sõid. Ülesanne 11a vorst liha kala kohupiim keefir hapukoor või jogurt piim kodujuust rõõskkoor riis kaerahelbed puder sai müsli värske sibul küüslauk porgand ku; Koosta endale hommikueine. Räägi paarilisele, mis toidud valisid ja miks. Sa ei pea kasutama kõiki nõusid. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011

## Arsti juures
URL: https://www.opiq.ee/kit/142/chapter/8017
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 7.4
Topics ET: matemaatika, arsti, juures, haigused, ravimid
Topics RU: математика
Topics EN: mathematics
Headings: Arsti juures; Haigused; Ravimid
Task examples: Millal teie klass käis viimati arsti juures? Ülesanne 16a Salvesta Mida arst kontrollis? Kirjuta. Ülesanne 16b Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik ; Mõõtke, kui pikad on teie klassi õpilased. Ülesanne 17 Minu pikkus on m cm. Meie klassi kõige pikem õpilane on (m cm). Meie klassi kõige lühem õpilane on (m cm). Salvesta Võrrelge tulemusi ülesandega 3 peatükis "Mina". A

## Ohud tervisele
URL: https://www.opiq.ee/kit/142/chapter/8018
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 7.5
Topics ET: matemaatika, ohud, tervisele
Topics RU: математика
Topics EN: mathematics
Headings: Ohud tervisele
Task examples: Mis on lastega juhtunud? Vaadake pilte ja arutlege. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õ; Arutlege, kuidas käitute. Täida tabel. Ülesanne 24 KÄITUMISVIISMillise tervist ohustava õnnetuse võib selline käitumine kaasa tuua?Kas oled oma koolis näinud sellist käitumist?Kas sina oled koolis nii käitunud?Mööda trep

## Esmaabi
URL: https://www.opiq.ee/kit/142/chapter/8019
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 7.6
Topics ET: matemaatika, esmaabi
Topics RU: математика
Topics EN: mathematics
Headings: Esmaabi
Task examples: Kirjuta vajalikud telefoninumbrid. Ülesanne 25 Isa või ema telefon Hädaabitelefon : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava; Vaata pilte ja jutusta, mis õnnetus on juhtunud. Millise õnnetuse puhul sobib see esmaabivõte? Märgi õiged numbrid. Ülesanne 26 1 2 3 4 1 2 3 4 1 2 3 4 : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Tea

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/8020
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 7.7
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Vasta küsimustele. Ülesanne 28 Mitu korda päevas tuleb hambaid pesta? Mitu tundi ööpäevas peab 2. klassi õpilane magama? Kas liikumine aitab olla terve? Kes kirjutab haiguse korral välja ravimi? Mis on hädaabinumber? Kui; Kas sina hoiad oma tervist? Vali sobiv vastusevariant. Ülesanne 29 Pesen käsi enne söömist. Alati Sageli Harva Pesen hambaid kaks minutit järjest. Alati Sageli Harva Söön mitmekesist toitu. Alati Sageli Harva Teen sporti

## Mina looduses
URL: https://www.opiq.ee/kit/142/chapter/8021
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 8.1
Topics ET: loodusõpetus, mina, looduses, ohud, lisaülesanne
Topics RU: природоведение
Topics EN: science
Headings: Mina looduses; Ohud looduses; Lisaülesanne 1; Lisaülesanne 1a
Task examples: Vaata pilti. Otsusta, mis on pildil ilus ja mis ilusa ära rikub. Kirjuta vastavasse tulpa. Ülesanne 1 LOODUSES ILUS RIKUB LOODUST Salvesta Asjad, mis inimene loodusesse jätab, võivad olla ohtlikud. Lisa oma materjali Tek; Hoia loodust! ​Ka sina oled osake loodusest. Kelle jaoks ja kuidas võivad olla ohtlikud järgmised asjad? Mõtle ja kirjuta igale reale üks näide. Ülesanne 2 kilekott – klaasikillud – tühi konservikarp – Salvesta Lisa oma 

## Kuidas olla säästlik?
URL: https://www.opiq.ee/kit/142/chapter/8022
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 8.2
Topics ET: matemaatika, kuidas, olla, säästlik
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas olla säästlik?
Task examples: Kirjuta kodumasinaid, mis töötavad elektriga. Ülesanne 11 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsus; Kuidas kasutad oma kodus elektrit? Vasta küsimustele. Ülesanne 12 Mitu elektriga töötavat kodumasinat on sinu kodus? Mitmega neist tohid töötada sina? Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Tea

## Tean ja oskan
URL: https://www.opiq.ee/kit/142/chapter/8023
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 8.3
Topics ET: matemaatika, tean, oskan
Topics RU: математика
Topics EN: mathematics
Headings: Tean ja oskan
Task examples: Vasta küsimustele. Ülesanne 17 Mis putukad võivad olla inimese tervisele ohtlikud? Miks ei tohi puudutada tundmatut eset? Miks on alati ohutum ujuda kalda poole? Kuhu paned matkal olles oma prahi? Miks on kulu põletamine; Kas sina hoiad loodust? Mõtle järele ja vali sobiv vastus. Ülesanne 18 Hoian kokku elektrit. Alati Sageli Harva Panen prahi selleks ette nähtud kohta. Alati Sageli Harva Matkal olen looduse sõber. Alati Sageli Harva Salv

## Lihavõtted
URL: https://www.opiq.ee/kit/142/chapter/8024
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 9.1
Topics ET: matemaatika, lihavõtted
Topics RU: математика
Topics EN: mathematics
Headings: Lihavõtted
Task examples: Märgi asjad, mis on seotud munadepühadega. Ülesanne 1a +– +– +– +– +– +– +– +– +– : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava; Kuidas sinu peres lihavõttepühi tähistatakse? Märgi ära sobivad vastused. Ülesanne 2 Peidetakse mune Süüakse kohupiimatoite Värvitakse mune Süüakse mune Koksitakse mune Otsitakse mune Veeretatakse mune Käiakse kirikus Ka

## Mida õppisime inimese­õpetuses?
URL: https://www.opiq.ee/kit/142/chapter/8025
Book: IN2 2. klassi inimeseõpetus 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: koolibri_in2_2._kla_2_et
Chapter ID: 9.2
Topics ET: matemaatika, mida, õppisime, inimese, õpetuses
Topics RU: математика
Topics EN: mathematics
Headings: Mida õppisime inimese­õpetuses?
Task examples: Uuri skeemi ja täienda tööraamatu abil. Ülesanne 1 Minu klassMinu pereMinu huvialadMINA Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õ; Loosige järgmised viis teemat rühmade vahel välja. Koostage oma teema kohta suurele paberile skeem. Tutvustage oma skeemi teistele. Kuula ja vaata rühmatööde esitlusi. Täida skeemid. Ülesanne 2 TÄHTPÄEVAD EESTI VABARIIK 

## Мой мир. Человеко­ведение 2 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/229
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 1
Topics ET: matemaatika, opiq
Topics RU: математика, человеко, ведение, класс
Topics EN: mathematics

## Мой мир. Человеко­ведение 2 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/229
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 40
Topics ET: matemaatika, opiq
Topics RU: математика, человеко, ведение, класс
Topics EN: mathematics

## Я
URL: https://www.opiq.ee/kit/229/chapter/13074
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, дополнительное
Topics EN: mathematics
Headings: Дополнительное задание
Task examples: Какой / какая ты? Заполни пропуски. Задание 1 Меня зовут . Мне лет. Я (девочка / мальчик). Мой день рождения . У меня волосы. Глаза у меня . Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast n; Сколько лет твоим одноклассникам? Составь диаграмму: в каждом столбике закрась столько прямоугольников, сколько в классе ребят такого возраста. Распечатай и заполни Lisa oma materjali Tekstiabi Muud tegevused Kopeeri lin

## Мои занятия
URL: https://www.opiq.ee/kit/229/chapter/13075
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, занятия
Topics EN: mathematics
Headings: Мои занятия
Task examples: Что ты умеешь делать, а чего не умеешь? Впиши в соответствующий столбик таблицы. Читать, петь, танцевать, плавать, летать, стричь ногти. Задание 4а Умею Не умею Salvesta Дополни таблицу: напиши, что ещё ты умеешь делать ; Из данных на рисунке частей составь слова, которые обозначают занятия. Задание 5 Salvesta Запиши эти слова в столбик, рядом напиши, на каком уроке ты этим занимаешься. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri 

## Мои увлечения
URL: https://www.opiq.ee/kit/229/chapter/13076
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, увлечения
Topics EN: mathematics
Headings: Мои увлечения; Заданиe 8
Task examples: Изучи диаграмму и ответь на вопросы. Задание 7 Сколько мальчиков из класса Максима занимаются в техническом кружке? Сколько танцевальных пар участвует в кружке народного танца? Половина мальчиков, занимающихся музыкой, у; Какие кружки ты знаешь? Запиши. Заданиe 8 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õp

## Поведение на улице
URL: https://www.opiq.ee/kit/229/chapter/13077
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, поведение, улице
Topics EN: mathematics
Headings: Поведение на улице
Task examples: Выбери на плане дом, в котором тебе хотелось бы жить. Распечатай рисунок и раскрась его. Отметь на плане дорогу из дома в школу. Сколько пешеходных переходов тебе надо перейти? Распечатай и заполни Для безопасного передв; Какие опасности могут подстерегать человека на дороге? Расскажи. Какие опасности могут подстерегать тебя по дороге в школу? Напиши. Задание 13 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast

## Хорошие манеры
URL: https://www.opiq.ee/kit/229/chapter/13078
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, хорошие, манеры, дополнительное
Topics EN: mathematics
Headings: Хорошие манеры; Дополнительное задание; Дополнительное задание 1; Дополнительное задание 2
Task examples: Какие правила надо соблюдать на улице? Расскажи. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õppe; Какие правила ты соблюдаешь в школе? Расскажи. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õppeka

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13079
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Верно или неверно? Задание 24 В нашем классе больше всего 7-летних детей. ВерноНеверно Все люди отличаются друг от друга. ВерноНеверно Я – мальчик. ВерноНеверно Ходить на тренировки по футболу – значит, заниматься музыко; Как часто ты соблюдаешь правила? Подумай и выбери свой ответ. Задание 25 Соблюдаю правила нашего класса. Всегда Часто Редко Соблюдаю правила дорожного движения для пешеходов. Всегда Часто Редко Считаюсь с другими. Всегда

## Пасха
URL: https://www.opiq.ee/kit/229/chapter/13111
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 10.1
Topics ET: matemaatika
Topics RU: математика, пасха
Topics EN: mathematics
Headings: Пасха
Task examples: Отметь на картинке значком + то, что имеет отношение к Пасхе. Задание 1 +– +– +– +– +– +– +– +– +– : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011; Как отмечают Пасху в твоей семье? Отметь подходящие ответы. Задание 2 Катают яйца Красят яйца Прячут яйца Готовят блюдо из сладкого творога Ходят в церковь Украшают дом Пекут куличи Покупают куличи Дарят подарки Сеют зел

## Мои дом и семья
URL: https://www.opiq.ee/kit/229/chapter/13080
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, семья
Topics EN: mathematics
Headings: Мои дом и семья
Task examples: Семьи бывают разные. Рассмотри картинки и расскажи. Какие ещё семьи ты знаешь? Расскажи. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava ; Нарисуй свою семью. Напиши имена членов своей семьи.Расскажи одноклассникам о своей семье. В семье важен каждый. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekav

## Домашние обязанности членов семьи
URL: https://www.opiq.ee/kit/229/chapter/13081
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, домашние, обязанности, членов, семьи, дополнительное
Topics EN: mathematics
Headings: Домашние обязанности членов семьи; Дополнительное задание
Task examples: Кто у вас дома выполняет эту работу? Задание 5 готовит еду. гладит бельё. накрывает на стол. убирает комнату. меняет колесо у машины. колет дрова. поливает цветы. моет посуду. выносит мусор. гуляет с собакой. Salvesta Li; Какую ещё работу выполняют в вашей семье? Заполни таблицу. Задание 6 Кто?Что делает? Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppe

## Изменения в жизни семьи
URL: https://www.opiq.ee/kit/229/chapter/13082
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, изменения, жизни, семьи
Topics EN: mathematics
Headings: Изменения в жизни семьи
Task examples: Появление в семье маленькой сестрёнки или братика, означает, что появляются новые возможности и обязанности. Что тебе понравилось бы (+), а что нет (-)? Появление в семье ребёнка меняет жизнь семьи. Задание 12 Гулять с с; Максим должен заботиться о своём домашнем любимце. Рассмотри картинки и расскажи. Саша: Максим, почему ты такой грустный?Максим: Мой хомячок Пух сегодня утром не хотел ни пить, ни есть. Он даже не двигался. Потом я увиде

## Семейные праздники
URL: https://www.opiq.ee/kit/229/chapter/13083
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, семейные, праздники
Topics EN: mathematics
Headings: Семейные праздники
Task examples: Какие праздники отмечают в твоей семье? Отметь значками + или –. Задание 16а Праздник/знаменательный день(+/–)Число1.Новый год +– 24 февраля2.Международный женский день +– 1.1 января3.Масленица +– 8 марта4.День друга +– 

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13084
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Какие предложения верные, а какие нет? Выбери правильный ответ. Задание 17 Некоторые семьи состоят из двух человек. ВерноНеверно Твоя мама – член твоей семьи и твоя родственница. ВерноНеверно Мама твоей мамы и мама твоег; Как часто ты бываешь примерным ребёнком в своей семье? Выбери ответ. Задание 18 Слушаюсь своих родителей. Всегда Часто Редко Помогаю делать работу по дому. Всегда Часто Редко Стараюсь радовать членов семьи. Всегда Часто 

## Опасности в доме
URL: https://www.opiq.ee/kit/229/chapter/13085
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, опасности, доме
Topics EN: mathematics
Headings: Опасности в доме
Task examples: Найди на рисунке опасные места / предметы. Распечатай рисунок и раскрась их. Распечатай и заполни Дома нужно быть очень осторожным, чтобы избежать несчастного случая. Объясни, почему эти места / предметы могут быть опасн; Зачем нужен дымовой датчик? Обсудите. Сколько дымовых датчиков пожарной сигнализации в твоём классе и сколько дома?Сосчитай и запиши. Задание 2 В классе датчиков. Дома датчиков. Salvesta Lisa oma materjali Tekstiabi Muud

## Тревога в школе
URL: https://www.opiq.ee/kit/229/chapter/13086
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, тревога, школе
Topics EN: mathematics
Headings: Тревога в школе
Task examples: Что могло произойти, если звонок прерывает только что начавшийся урок? Обсудите. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põh; Что надо делать, если в школе начался пожар? Обсудите. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riikli

## Опасности в окружающей среде
URL: https://www.opiq.ee/kit/229/chapter/13087
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, опасности, окружающей, среде
Topics EN: mathematics
Headings: Опасности в окружающей среде
Task examples: Расскажи, что случилось с Юрой. Почему произошло несчастье? Что надо делать, если кто-то провалился под лёд? Если произошло несчастье, зови на помощь. Попробуй вылезти на лёд и ползти к берегу. Lisa oma materjali Tekstia; Маша вышла не на той автобусной остановке и заблудилась. Что должна знать Маша в такой ситуации? Подумай и отметь. Задание 12а домашний адрес кличку своей собаки место, где она находится номер телефона мамы (папы, брата 

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13088
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Верно или неверно? Задание 13 Если утюг не выключить из розетки, то может возникнуть пожар. ВерноНеверно За открытым огнём дома надо следить. ВерноНеверно Дома в каждой комнате должен быть дымовой датчик. ВерноНеверно В ; Как часто ты так поступаешь? Задание 14 Помогаю, когда кто-то просит помочь. Всегда Часто Редко Дружески отношусь к своим одноклассникам. Всегда Часто Редко Думаю о том, где может подстерегать опасность. Всегда Часто Ред

## Рождество
URL: https://www.opiq.ee/kit/229/chapter/13089
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, рождество, свечи
Topics EN: mathematics
Headings: Рождество; Свечи
Task examples: Какие из этих традиций и обычаев связаны с Рождеством? Отметь значком + или –. Задание 1 Наряжать елку +– Запускать фейерверки +– Ходить в церковь +– Колядовать +– Зажигать свечи +– Разжигать костер +– Слушать и петь рож; Сколько свечек на рисунке? Задание 2 : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õppekava

## Время и его измерение
URL: https://www.opiq.ee/kit/229/chapter/13090
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 4.2
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, aeg, kell, kalender
Topics RU: математика, измерение, единица измерения, длина, масса, объём, время, часы, календарь
Topics EN: mathematics, measurement, unit, length, mass, volume, time, clock, calendar
Headings: Время и его измерение
Task examples: Заполни пропуски. Выбери из предложенных ответов, о чём идет речь: о прошлом, настоящем или будущем. Задание 10 Я родился / родилась в году. ПРОШЛОЕНАСТОЯЩЕЕБУДУЩЕЕ Сейчас идёт урок . ПРОШЛОЕНАСТОЯЩЕЕБУДУЩЕЕ В следующем ; Заполни схему о себе. Впиши слова или словосочетания, которые связаны с твоим прошлым, настоящим и будущим. Задание 11 детский сад ПРОШЛОЕ окончание 2-го класса БУДУЩЕЕ НАСТОЯЩЕЕ Salvesta Lisa oma materjali Tekstiabi Muu

## Планирование времени
URL: https://www.opiq.ee/kit/229/chapter/13091
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, планирование, времени
Topics EN: mathematics
Headings: Планирование времени
Task examples: Ознакомься с планом Максима на неделю. Ответь на вопросы по плану Максима. Задание 19а Сколько часов в неделю Максим проводит в школе? Сколько часов в неделю Максим тратит на любимые занятия? Сколько часов в неделю Макси; Подумай о завтрашнем дне. Составь свой распорядок дня. Задание 20а ВремяЗанятие6.00 7.00 8.00 9.00 10.00 11.00 12.00 13.00 14.00 15.00 16.00 17.00 18.00 19.00 20.00 21.00 22.00 Salvesta Запиши занятия, которые тебе нравя

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13092
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Найди и отметь правильное окончание предложения. Задание 22 Время движется … из прошлого в будущее. из будущего в прошлое. То, что происходит сейчас – это … прошлое. настоящее. В неделе … 24 часа. 7 дней. Весенние месяцы; Как часто ты так поступаешь? Подумай и отметь свой вариант. Задание 23 Планирую свой день. Всегда Часто Редко С удовольствием посещаю кружки. Всегда Часто Редко Выполняю домашние задания. Всегда Часто Редко Salvesta Обсу

## Ценность и стоимость вещи
URL: https://www.opiq.ee/kit/229/chapter/13093
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, ценность, стоимость, вещи, пропавший, бинокль, вещей
Topics EN: mathematics
Headings: Ценность и стоимость вещи; Пропавший бинокль; Стоимость вещей
Task examples: Напиши, какие вещи ты хотел/а бы иметь. Задание 1а Salvesta Какие из них, по-твоему, необходимы для жизни? Запиши их. Объясни, почему ты выбрал/а именно эти вещи. Задание 1б Salvesta ​Еда, одежда и жильё необходимы для ж; Подумай, какие три вещи из изображенных на картинке тебе действительно необходимы. Объясни свой выбор. Задание 2 +– +– +– +– +– +– +– +– +– +– +– +– +– Salvesta Назови какую-нибудь свою вещь, которая тебе особенно дорога

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13094
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Прочитай и реши – верно или неверно. Задание 8 Вещи моего друга – это и мои вещи. ВерноНеверно В школе все вещи общие. ВерноНеверно В школу нельзя приносить ценные вещи. ВерноНеверно Одолженную вещь я возвращаю тогда, ко; Какие вещи необходимы тебе в школе? Отметь значком + или –. Объясни свой выбор. Задание 9 +– +– +– +– +– +– +– +– +– +– +– +– +– +– +– +– Salvesta Если хочешь, распечатай лист и раскрась вещи, которые тебе действительно 

## Эстонская Республика
URL: https://www.opiq.ee/kit/229/chapter/13095
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, эстонская, республика, флаг, герб, гимн, эстонской, республики, правительство
Topics EN: mathematics
Headings: Эстонская Республика; Флаг, герб и гимн Эстонской Республики; Правительство и президент Эстонской Республики; Гимн Эстонской Республики
Task examples: Найди на карте Эстонию и соседние государства – Финляндию, Швецию, Латвию, Россию. У каждого государства есть своя столица. Рассмотри карту и заполни пропуски. Задание 1 Столица Эстонии – . Столица Финляндии – . Рига – с; Изучи карту Эстонии. Найди на карте то место, где ты живёшь. Задание 2 Я живу в уезде. Всего в Эстонии уездов. : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õ

## Мой родной край
URL: https://www.opiq.ee/kit/229/chapter/13096
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, родной, край
Topics EN: mathematics
Headings: Мой родной край
Task examples: Где ты живёшь? Напиши. Задание 7 Я живу ... в уезде . волости / городе . деревне / посёлке . на улице . Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekav; Знаешь ли ты флаг и герб твоего родного края? Рассмотри гербы уездов Эстонии и отметь герб уезда, в котором ты живёшь. Задание 8 {"data":["Герб уезда, в котором я живу."]}Герб уезда, в котором я живу.11 : 0 : 0 Как выгля

## Жизнь в городе и деревне
URL: https://www.opiq.ee/kit/229/chapter/13097
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, жизнь, городе, деревне
Topics EN: mathematics
Headings: Жизнь в городе и деревне
Task examples: Рассмотри картинки и выбери для них заголовки. Задание 11а В ДЕРЕВНЕВ ГОРОДЕ : 0 : 0 Кто где работает? Запиши номер того места, где работают люди этих профессий. Задание 11б актёр полицейский продавец учитель таксист вод; Люди каких профессий работают и в городе, и в деревне? Напиши. Задание 12 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 P

## Богатство Эстонии
URL: https://www.opiq.ee/kit/229/chapter/13098
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 6.4
Topics ET: matemaatika
Topics RU: математика, богатство, эстонии, известные, люди, дополнительное
Topics EN: mathematics
Headings: Богатство Эстонии; Известные люди; Дополнительное задание; Дополнительное задание 1; Дополнительное задание 2
Task examples: Бывал/а ли ты в этих местах? Отметь крестиком ( + ) те места, где ты бывал/а. Задание 14а парк Тойла-Ору +– Мельницы Англа +– Пярнуский мол +– водопад Валасте +– Таэваскода +– музей А. Х. Таммсааре в волости Албу +– гора; Знаешь ли ты этих известных людей Эстонии? Соедини имя с фотографией. Как ты узнал/а об этих людях? Если нужно, воспользуйся интернетом. Задание 15 {"data":["дискобол Герд Кантер","актёр Эдуард Томан","художник Эдгар Вал

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13099
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 6.5
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Допиши предложения, используя данные слова: богатство Эстонии, три льва, национальные цвета, государственный флаг, встают, день рождения, Таллинн, Алар Карис, герб. Задание 16 Столица Эстонской Республики – . На флаге Эс; Как часто ты так поступаешь? Подумай и выбери вариант ответа. Задание 17 Гимн Эстонской Республики я слушаю стоя. Всегда Часто Редко С удовольствием посещаю красивые места Эстонии. Всегда Часто Редко Во время экскурсии я

## Моё здоровье
URL: https://www.opiq.ee/kit/229/chapter/13100
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 7.1
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, чистота
Topics EN: mathematics, human, body, senses, health
Headings: Моё здоровье; Чистота
Task examples: Что помогает быть здоровым? Прочитай и выбери. Задание 1 Постоянный просмотр телепередач ДАНЕТ Чистка зубов ДАНЕТ Чистоплотность ДАНЕТ Хорошее настроение ДАНЕТ Одежда по погоде ДАНЕТ Сон ДАНЕТ Подвижные игры ДАНЕТ Хороши; Кто из этих детей болен, а кто здоров? Выбери для картинок подходящие заголовки. Задание 2а РЕБЁНОК БОЛЕНРЕБЁНОК ЗДОРОВ РЕБЁНОК БОЛЕНРЕБЁНОК ЗДОРОВ : 0 : 0 Как себя чувствуют дети, изображённые на этих картинках? Напиши.

## Я берегу своё здоровье
URL: https://www.opiq.ee/kit/229/chapter/13101
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 7.2
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, берегу, отдых
Topics EN: mathematics, human, body, senses, health
Headings: Я берегу своё здоровье; Отдых
Task examples: Каким видом спорта тебе нравится заниматься? Отметь значком + или –. Задание 6 +– +– +– +– +– +– +– +– +– +– +– +– +– Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: R; Прочитай перечисленные виды занятий. Чем ты занимаешься и как часто? Задание 7 Утренняя зарядка Не занимаюсьИногда, редко, не больше получасаНесколько раз в день, более получаса Просмотр телепередач Не занимаюсьИногда, р

## Здоровое питание
URL: https://www.opiq.ee/kit/229/chapter/13102
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 7.3
Topics ET: matemaatika
Topics RU: математика, здоровое, питание, продукты, которые, полезны, здоровья, дополнительные
Topics EN: mathematics
Headings: Здоровое питание; Продукты, которые не полезны для здоровья; ДОПОЛНИТЕЛЬНЫЕ ЗАДАНИЯ: Как вести себя за столом
Task examples: На рисунке изображены полезные для здоровья продукты. Отметь, какие из них тебе нравятся. Задание 11 колбаса мясо рыба творог кефир сметана масло йогурт молоко зернистый творог сливки рис овсяные хлопья каша булка мюсли ; Составь себе завтрак. Расскажи соседу по парте, какие продукты ты выбрал и почему. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 P

## У врача
URL: https://www.opiq.ee/kit/229/chapter/13103
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 7.4
Topics ET: matemaatika
Topics RU: математика, врача, болезни, лекарства
Topics EN: mathematics
Headings: У врача; Болезни; Лекарства
Task examples: Когда ваш класс в последний раз ходил к школьному врачу? Задание 16а Salvesta Что проверял врач? Напиши. Задание 16б Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Ri; Измерьте рост учеников вашего класса. Задание 17 Мой рост м см. Самый высокий / самая высокая в нашем классе ( м см). Самый маленький / самая маленькая в нашем классе ( м см). Salvesta Сравните результаты с заданием 3 в 

## Что опасно для здоровья
URL: https://www.opiq.ee/kit/229/chapter/13104
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 7.5
Topics ET: matemaatika
Topics RU: математика, опасно, здоровья
Topics EN: mathematics
Headings: Что опасно для здоровья
Task examples: Что случилось с ребятами? Рассмотрите картинки и обсудите. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud ri; Обсудите, как вы себя ведёте. Заполни таблицу. Задание 24 ПОВЕДЕНИЕКакой вред здоровью может нанести такое поведение?Сталкивался/лась ли ты в школе с таким поведением?Вёл / вела ли ты себя так в школе?Нестись по лестнице

## Первая помощь
URL: https://www.opiq.ee/kit/229/chapter/13105
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 7.6
Topics ET: matemaatika
Topics RU: математика, первая, помощь
Topics EN: mathematics
Headings: Первая помощь
Task examples: Впиши нужные номера телефонов. Задание 25 Телефон родителей – Телефон вызова экстренной помощи – : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 R; Рассмотри картинки и расскажи, какую первую помощь надо оказать в этих случаях. Выбери подходящую помощь для каждого несчастного случая. Проставь под картинкой соответствующий номер / номера. Задание 26 1 2 3 4 1 2 3 4 1

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13106
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 7.7
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Ответь на вопросы. Задание 28 Сколько раз в день надо чистить зубы? 21 Сколько часов в сутки должен спать второклассник? 79 Помогает ли движение быть здоровым? ДАНЕТ Кто в случае болезни выписывает лекарство? АПТЕКАРЬВРА; Как часто ты так поступаешь? Подумай и выбери ответ. Задание 29 Мою руки перед едой. Всегда Часто Редко Чищу зубы в течение двух минут. Всегда Часто Редко Разнообразно питаюсь. Всегда Часто Редко Занимаюсь спортом. Всегд

## Я на природе
URL: https://www.opiq.ee/kit/229/chapter/13107
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 8.1
Topics ET: matemaatika
Topics RU: математика, природе, опасности, которыми, можно, столкнуться, дополнительное, навстречу, лету
Topics EN: mathematics
Headings: Я на природе; Опасности, с которыми можно столкнуться на природе; Дополнительное задание: Навстречу лету; Дополнительное задание
Task examples: Рассмотри картинку. Что на картинке красиво, а что эту красоту портит? Запиши в колонки. Задание 1 КРАСИВО ПОРТИТ КРАСОТУ Salvesta Предметы, которые люди оставляют после себя на природе, могут быть опасными. Lisa oma mat; Для кого и чем могут быть опасны предметы, которые люди оставляют после себя на природе? Подумай и на каждой строчке напиши по одному примеру. Береги природу! Ты тоже являешься частью природы. Задание 2 пластиковый пакет

## Как быть бережливым?
URL: https://www.opiq.ee/kit/229/chapter/13108
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 8.2
Topics ET: matemaatika
Topics RU: математика, быть, бережливым
Topics EN: mathematics
Headings: Как быть бережливым?
Task examples: Напиши, какие бытовые приборы работают на электричестве. Задание 11 Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikoo; Как ты дома пользуешься электричеством? Ответь на вопросы. Задание 12 Сколько у вас дома бытовых электроприборов? Сколькими из них тебе разрешается пользоваться? Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopee

## Знаю и умею
URL: https://www.opiq.ee/kit/229/chapter/13109
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 8.3
Topics ET: matemaatika
Topics RU: математика, знаю, умею
Topics EN: mathematics
Headings: Знаю и умею
Task examples: Ответь на вопросы. Задание 17 Какие насекомые могут быть опасными для человека? Почему нельзя трогать незнакомый предмет? Почему всегда безопаснее плыть к берегу? Куда ты денешь мусор во время похода? Почему запрещается ; Как часто ты так поступаешь? Подумай и выбери ответ. Задание 18 Экономлю электроэнергию. Всегда Часто Редко Выбрасываю мусор в предназначенные для этого места. Всегда Часто Редко В походе бережно отношусь к природе. Всег

## Что мы изучали на уроках?
URL: https://www.opiq.ee/kit/229/chapter/13110
Book: Мой мир. Человеко­ведение 2 класс 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_мой_мир._ч_2_ru
Chapter ID: 9.1
Topics ET: matemaatika
Topics RU: математика, изучали, уроках
Topics EN: mathematics
Headings: Что мы изучали на уроках?
Task examples: Изучи схему и дополни её, пользуясь рабочей книгой. Задание 1 Мой классМоя семьяМои увлеченияЯ Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Ri; Распределите по жребию между группами следующие пять тем. Пользуясь рабочей книгой, составьте по своей теме на большом листе бумаги схему. Представьте свою схему другим группам.Послушай и посмотри выступления других груп
