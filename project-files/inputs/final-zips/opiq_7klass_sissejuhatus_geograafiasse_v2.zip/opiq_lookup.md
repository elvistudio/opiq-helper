## Geograafia 7. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/543
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 105
Topics ET: matemaatika, geograafia, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Sissejuhatus geograafiasse
URL: https://www.opiq.ee/kit/543/chapter/30032
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.1
Topics ET: matemaatika, sissejuhatus, geograafiasse, geograafia, mida, uurib, mõtle, lohista, uurimisteemad, haru
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus geograafiasse; Mis on geograafia ja mida see uurib?; Mõtle!; Lohista uurimisteemad geograafia haru alla, mis sellega tegeleb.; Vali ja märgi õiged sõnad.; Kuidas tehakse geograafilisi uuringuid?; Milliseid uurimismeetodeid saab kasutada, kui soovime teada saada, kuidas on Peipsi rannajoon viimase 200 aasta jooksul muutunud?; Millist uurimismeetodit tuleks kasutada, kui soovime teada saada sademete hulka mingis paigas aasta jooksul?; Millist uurimismeetodit tuleks kasutada, kui soovime teada saada, kuidas kujunes välja Eesti praegune teedevõrk?; Millist uurimismeetodit tuleks kasutada, kui soovime teada saada mingi piirkonna täpset rahvaarvu?; Milliseid uurimismeetodeid saab kasutada, kui soovime teada saada vallaelanike eelistatud liikumisviise ja -suundi?; Millist uurimismeetodit tuleks kasutada, kui soovime teada saada, kui palju reoaineid on Emajões?; Nüüdisaegsed uurimismeetodid geograafias; Milleks kasutatakse geograafias satelliidipilte?; Kus saab Eestis geograafiat õppida?; Kellena töötavad geograafid?; Mõisted

## Kordamine. Kaardiõpetus
URL: https://www.opiq.ee/kit/543/chapter/30220
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.10
Topics ET: matemaatika, liitmine, liida, summa, kokku, korrutamine, korruta, korrutis, korda, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, aeg, kell, kalender, kordamine, harjutan, kaardiõpetus, sissejuhatus, geograafiasse, milleks, kasutatakse, geograafias, satelliidipilte, vali
Topics RU: математика, сложение, сложи, сумма, умножение, умножь, произведение, число, числа, цифры, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём, время, часы, календарь, повторение, повтори, тренировка
Topics EN: mathematics, addition, add, sum, multiplication, multiply, product, number, numbers, digits, comparison, compare, greater, less, measurement, unit, length, mass, volume, time, clock, calendar, revision, review, practice
Headings: Kordamine. Kaardiõpetus; 1.1. Sissejuhatus geograafiasse; Milleks kasutatakse geograafias satelliidipilte?; Vali ja märgi õiged sõnad.; Lohista uurimisteemad geograafia haru alla, mis sellega tegeleb.; Mis uurimismeetodit tuleks kasutada, kui soovime teada saada sademete hulka mingis paigas aasta jooksul?; Mis uurimismeetodit tuleks kasutada, kui soovime teada saada, kuidas kujunes välja Eesti praegune teedevõrk?; Millist uurimismeetodit tuleks kasutada, kui soovime teada saada mingi piirkonna täpset rahvaarvu?; Milliseid uurimismeetodeid saab kasutada, kui soovime teada saada vallaelanike eelistatud liikumisviise ja -suundi?; Millist uurimismeetodit tuleks kasutada, kui soovime teada saada, kui palju reoaineid on Emajões?; Milliseid uurimismeetodeid saab kasutada, kui soovime teada saada, kuidas on Peipsi rannajoon viimase 200 aasta jooksul muutunud?; 1.2. Maa kuju ja suurus; Vali lünka õige variant.; Miks pidasid meie esivanemad Maad lapikuks?; Millised tegevused on tõendanud Maa kerakujulisust?; Mandrid ja maailmajaod; Millise mandri rannikut uhuvad nelja ookeani veed?; Milline neist ei ole maailmajagu?; Milline ookean ääristab vaid üht mandrit?; Millised ookeanid puutuvad vahetult kokku kõikide ülejäänud ookeanidega?; Mille alusel on maailmajagude piirid peamiselt kokku lepitud?; Millised maakera piirkonnad avastati viimasena; Kelle juhtimisel purjetati esimest korda ümber maakera ja tõestati, et see on ümmargune?; Miks on Maa läbimõõt kõige suurem ekvaatoril?; Kui suur on ligikaudu Maa ümbermõõt?; Miks on vaja teada Maa mõõtmeid?; 1.3. Kaardid ja nende mitmekesisus; Mis on topograafilise kaardi eelised aerofoto ees?; Mille kohta saab teavet kõikidelt kaartidelt?; Kuidas nimetatakse kaartide valmistamise kunsti ja töövõtteid hõlmavat valdkonda?; Mis on kaardiatlas?; Milliseid objekte ja nähtusi kujutatakse topograafilistel kaartidel?; Kuidas nimetatakse Eesti kõige olulisemat topograafilist kaarti?; Mis on kaardi legend?; Millist tüüpi leppemärgiga võiks maastikuobjekti kaardil kujutada?; Mis on aerofoto?; 1.4. Pinnamoe kujutamine kaardil; Mida näitab pinnamoe profiilijoon?; Kuidas saab samakõrgusjoonte abil leida kaardilt järsemaid nõlvu?; Mis suunas kasvab samakõrgusjoontega kaardil nõlva kõrgus?; Kuidas kulgevad samakõrgusjooned kaardil, millel kõrgusvahemikke eristavad värvitoonid?; Mis on nende pinnamoe kujutusviiside eelised?; Millist kõrgust näidatakse topograafilistel kaartidel?; 1.5. Mõõtkava ja vahemaade mõõtmine; Millist kaarti on kõige rohkem üldistatud?; Mida näitab kaardi mõõtkava?; Milleks on kasulik kaardi joonmõõtkava?; Mida näitab arvmõõtkava parempoolne arv?; Milline võrdlusmõõtkava sobib kaardile mõõtkavas 1 : 10 000?; Millisele kaardile mahub kõige suurem ala loodusest?; Mis kaardil on kujutatud loodust kõige üksikasjalikumalt?; Mõõtkava suurus; Miks on vaja kaarti üldistada?; Kaardi üldistamine; 1.6. Suunad looduses ja kaardil; Mitut orientiiri on vaja, et kaart maastiku järgi orienteerida?; Mille järgi saab looduses ilmakaari määrata?; Milleks on vajalikud orientiirid?; Millise kompassi osa järgi saad teada põhjasuuna?; Mis on asimuut?; Mida tähendab kaardi orienteerimine?; Mida tuleb teha, et kaarti kompassi abil orienteerida?; 1.7. Asukoha määramine. Geograafilised koordinaadid; Vaata Tallinna turismikaarti. Peamiselt millises aadressiruudus asuvad need kohad?; Millisteks osadeks jaotab ekvaator maakera?; Mille järgi jaotatakse maakera ida- ja läänepoolkeraks?; Mis on suurim väärtus?; Kuidas määratakse geograafilist laiust?; Kuidas määratakse geograafilist pikkust?; Milliste ühikutega tähistatakse geograafilisi koordinaate?; Millised paigad Maa pinnal on lähtekohaks nii geograafilise laiuse kui ka geograafilise pikkuse määramisel?; Miks ei ole poolustel geograafilist pikkust?; Vaata kaardivõrguga maailmakaarti ja leia vahemike suurus.; Kus asub nullmeridiaani ja ekvaatori ristumispunkt?; Vaata kaardivõrguga maailmakaarti. Mis võiks olla Eesti ligikaudsed koordinaadid?; Kuidas saab sinu telefon teavet sinu asukohast Maa pinnal?; Kuidas jaguneb Eesti territoorium?; Järjesta üksused väiksemast suuremani nii, et aadress saaks korrektne.; 1.8. Digitaalsed kaardid; Milleks kasutatakse GIS-i?; Kuidas jaotatakse digikaartide kasutamise keskkondi?; Milleks on kasulik arvutikaartide kihiline ülesehitus?; Millised omadused muudavad kaardi interaktiivseks?; Milleks on kasulikud animeeritud kaardid?; 1.9. Ajavööndid; Miks kaalutakse Euroopa Liidus kellakeeramine lõpetamist?; Kuidas erineb Eestis kohalik päikeseaeg, kui liikuda mööda 25° ip meridiaani põhjast lõunasse?; Kuidas erineb Eestis kohalik päikeseaeg, kui liikuda mööda 59° pl paralleeli läänest itta?; Kus asub Päike antud koha suhtes, kui sealne kohalik päikeseaeg on 00.00?; Millistes riikides on kasutusel mitu vööndiaega?; Kui palju erineb Ida-Euroopa aeg maailmaajast?; Mis on Eesti ajavööndi keskmeridiaan?; Mis suunda peaksid liikuma, et jõuda alanud päeva hommikust kiiremini sama päeva õhtusse?; Kuidas peab reisides kella keerama?; Miks ei kulge kuupäevaraja piki meridiaani?; Mis hetkel on kõikjal maailmas sama kuupäev?; Miks läks Magalhãesi ümbermaailmareisi laevapäevikust üks päev kaduma?; Kella keeramine; Kellaaeg Venemaal

## Maa kuju ja suurus
URL: https://www.opiq.ee/kit/543/chapter/30033
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.2
Topics ET: matemaatika, liitmine, liida, summa, kokku, korrutamine, korruta, korrutis, korda, võrdlemine, võrdle, suurem, väiksem, aeg, kell, kalender, kordamine, harjutan, kuju, suurus, milline, ettekujutus, maast, kauges, minevikus, ümmargune, miks
Topics RU: математика, сложение, сложи, сумма, умножение, умножь, произведение, сравнение, сравни, больше, меньше, время, часы, календарь, повторение, повтори, тренировка
Topics EN: mathematics, addition, add, sum, multiplication, multiply, product, comparison, compare, greater, less, time, clock, calendar, revision, review, practice
Headings: Maa kuju ja suurus; Milline oli ettekujutus Maast kauges minevikus?; Maa on ümmargune; Miks pidasid meie esivanemad Maad lapikuks?; Mandrid, ookeanid ja maailmajaod; Mille alusel on maailmajagude piirid peamiselt kokku lepitud?; Mandrid ja maailmajaod; Millise mandri rannikut uhuvad nelja ookeani veed?; Milline neist ei ole maailmajagu?; Milline ookean ääristab vaid üht mandrit?; Millised ookeanid puutuvad vahetult kokku kõikide ülejäänud ookeanidega?; Kuidas avardus inimeste ettekujutus Maast?; Kelle juhtimisel purjetati esimest korda ümber maakera ja tõestati, et see on ümmargune?; Millised riigid olid suurimad koloniaalimpeeriumite rajajad?; Millised maakera piirkonnad avastati viimasena; Kui suur on maakera?; Maa ja aeg; Kui täpselt arvutas Eratosthenes rohkem kui 1700 aastat tagasi välja Maa ümbermõõdu?; Miks on Maa läbimõõt kõige suurem ekvaatoril?; Kui suur on ligikaudu Maa ümbermõõt?; Miks on vaja teada Maa mõõtmeid?; Mõisted

## Kaardid ja nende mitmekesisus
URL: https://www.opiq.ee/kit/543/chapter/30070
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.3
Topics ET: matemaatika, kaardid, nende, mitmekesisus, milleks, kaarte, vaja, kaardiatlas, mille, kohta
Topics RU: математика
Topics EN: mathematics
Headings: Kaardid ja nende mitmekesisus; Milleks on kaarte vaja?; Mis on kaardiatlas?; Mille kohta saab teavet kõikidelt kaartidelt?; Kuidas nimetatakse kaartide valmistamise kunsti ja töövõtteid hõlmavat valdkonda?; Üldgeograafilised kaardid; Kuidas nimetatakse Eesti kõige olulisemat topograafilist kaarti?; Milliseid objekte ja nähtusi kujutatakse topograafilistel kaartidel?; Temaatilised kaardid; Kaks peamist kaarditüüpi; Milleks on kaardil leppemärgid?; Millist tüüpi leppemärgiga võiks maastikuobjekti kaardil kujutada?; Mis on kaardi legend?; Mille poolest erinevad kaardid satelliidipildist või aerofotost?; Mis on topograafilise kaardi eelised aerofoto ees?; Mis on aerofoto?; Mõisted

## Pinnamoe kujutamine kaardil
URL: https://www.opiq.ee/kit/543/chapter/30071
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.4
Topics ET: matemaatika, lahutamine, lahuta, vahe, pinnamoe, kujutamine, kaardil, samakõrgusjooned, kuidas, kulgevad, millel, eristavad, kõrgusvahemikke
Topics RU: математика, вычитание, вычти, разность
Topics EN: mathematics, subtraction, subtract, difference
Headings: Pinnamoe kujutamine kaardil; Mis on samakõrgusjooned?; Kuidas kulgevad samakõrgusjooned kaardil, millel eristavad kõrgusvahemikke värvitoonid?; Kuidas saab samakõrgusjoonte abil leida kaardilt järsemaid nõlvu?; Mis suunas kasvab samakõrgusjoontega kaardil nõlva kõrgus?; Mis on reljeefi varjutamine?; Mis on nende pinnamoe kujutusviiside eelised?; Mis vahe on absoluutsel ja suhtelisel kõrgusel?; Leia põhikaardi lehelt, kui suur on suhteline kõrgus Saadjärve ja Allika talu vahel.; Millist kõrgust näidatakse topograafilistel kaartidel?; Mida näitab profiiljoon?; Millesel kõrgusel asub hüpsograafilise kõvera järgi 2% maapinnast?; Mida näitab pinnamoe profiiljoon?; Leia maakera hüpsograafiliselt kõveralt, kui suur osa Maa pinnast on maailmamere all.; Mõisted

## Mõõtkava ja vahemaade mõõtmine
URL: https://www.opiq.ee/kit/543/chapter/30152
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.5
Topics ET: matemaatika, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, mõõtkava, vahemaade, mida, näitab, kaardi, joonmõõtkava, millised, väited
Topics RU: математика, число, числа, цифры, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, number, numbers, digits, comparison, compare, greater, less, measurement, unit, length, mass, volume
Headings: Mõõtkava ja vahemaade mõõtmine; Mida näitab kaardi mõõtkava?; Joonmõõtkava; Millised väited on tõesed?; Arvmõõtkava; Milline võrdlusmõõtkava sobib kaardile, mille mõõtkava on 1 : 10 000?; Mida näitab arvmõõtkava parempoolne arv?; Erineva otstarbega kaartidel on erinev mõõtkava; Mõõtkava suurus; Millisele kaardile mahub kõige suurem ala loodusest?; Mis kaardil on kujutatud loodust kõige üksikasjalikumalt?; Mis on kaardi üldistamine?; Millist kaarti on kõige rohkem üldistatud?; Miks on vaja kaarti üldistada?; Kaardi üldistamine; Mõisted

## Suunad looduses ja kaardil
URL: https://www.opiq.ee/kit/543/chapter/30153
Book: Sissejuhatus geograafiasse
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.6
Topics ET: loodusõpetus, suunad, looduses, kaardil, kuidas, määrata, suunda, milleks, vajalikud, orientiirid
Topics RU: природоведение
Topics EN: science
Headings: Suunad looduses ja kaardil; Kuidas määrata suunda looduses?; Milleks on vajalikud orientiirid?; Mille järgi saab looduses ilmakaari määrata?; Mis on asimuut ja kuidas seda kompassiga määrata?; Millise asimuudiga kursil tuleb purjetada, et jõuda Ruhnust Roomassaarde?; Millise kompassi osa järgi saad teada põhjasuuna?; Mis on asimuut?; Mis asimuudil asub Pärnu Ruhnust?; Mida tähendab kaardi orienteerimine?; Mitut orientiiri on vaja, et kaart maastiku järgi orienteerida?; Mida tuleb teha, et kaarti kompassi abil orienteerida?; Mõisted

## Asukoha määramine. Geograafilised koordinaadid
URL: https://www.opiq.ee/kit/543/chapter/30187
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.7
Topics ET: matemaatika, asukoha, määramine, geograafilised, koordinaadid, kuidas, määrata, asukohta, koordinaatide, abil
Topics RU: математика
Topics EN: mathematics
Headings: Asukoha määramine. Geograafilised koordinaadid; Kuidas määrata asukohta koordinaatide abil?; Miks ei ole poolustel geograafilist pikkust?; Millisteks osadeks jaotab ekvaator maakera?; Mille järgi jaotatakse maakera ida- ja läänepoolkeraks?; Milline on suurim väärtus?; Kuidas määratakse geograafilist laiust?; Kuidas määratakse geograafilist pikkust?; Milliste ühikutega tähistatakse geograafilisi koordinaate?; Millised paigad Maa pinnal on lähtekohaks nii geograafilise laiuse kui ka geograafilise pikkuse määramisel?; Kuidas aitab kaardivõrk koordinaate määrata?; Vaata kaardivõrguga maailmakaarti. Mis võiks olla Eesti ligikaudsed koordinaadid?; Vaata kaardivõrguga maailmakaarti.; Kus asub nullmeridiaani ja ekvaatori ristumispunkt?; Mis on üleilmne asukoha määramise süsteem?; Kuidas saab sinu telefon teavet sinu asukohast Maa pinnal?; Kuidas määrata asukohta aadressi järgi?; Vaata Tallinna turismikaarti. Millises peamises aadressiruudus asuvad toodud kohad?; Kuidas jaguneb Eesti territoorium?; Järjesta üksused väiksemast suuremani nii, et aadress saaks korrektne.; Mõisted

## Digitaalsed kaardid
URL: https://www.opiq.ee/kit/543/chapter/30188
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.8
Topics ET: matemaatika, digitaalsed, kaardid, milleks, kasulik, arvutikaartide, kihiline, ülesehitus, kuidas, jaotatakse
Topics RU: математика
Topics EN: mathematics
Headings: Digitaalsed kaardid; Mis on digitaalsed kaardid?; Milleks on kasulik arvutikaartide kihiline ülesehitus?; Kuidas jaotatakse digikaartide kasutamise keskkondi?; Mida digitaalsete kaartidega teha saab?; Millised omadused muudavad kaardi interaktiivseks?; Digitaalsed kaardid töö- ja uurimisvahendina; Milleks on kasulikud animeeritud kaardid?; Lisalugemine. Kuidas digitaalsed kaardid valmivad?; Milleks kasutatakse GIS-i?; Millised on trükikaardi eelised?; Mõisted

## Ajavööndid
URL: https://www.opiq.ee/kit/543/chapter/30203
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 1.9
Topics ET: matemaatika, aeg, kell, kalender, ajavööndid, kohalik, päikeseaeg, asub, päike, antud, koha, suhtes, sealne
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Ajavööndid; Mis on kohalik päikeseaeg?; Kus asub Päike antud koha suhtes, kui sealne kohalik päikeseaeg on 00.00?; Kuidas erineb Eestis kohalik päikeseaeg, kui liikuda mööda 25° ip meridiaani põhjast lõunasse?; Kuidas erineb Eestis kohalik päikeseaeg, kui liikuda mööda 59° pl paralleeli läänest itta?; Mis on ajavööndid?; Mis suunda peaksid liikuma, et jõuda alanud päeva hommikust kiiremini sama päeva õhtusse?; Millistes riikides on kasutusel mitu vööndiaega?; Kui palju erineb Ida-Euroopa aeg maailmaajast?; Mis on Eesti ajavööndi keskmeridiaan?; Miks on reisides vaja kella keerata?; Kuidas peab reisides kella keerama?; Kuidas ja kus saab alguse uus kuupäev?; Mis hetkel on kõikjal maailmas sama kuupäev?; Miks ei kulge kuupäevaraja piki meridiaani?; Lisalugemine. Kuidas päev kaotsi läks?; Miks läks Magalhãesi ümbermaailmareisi laevapäevikust üks päev kaduma?; Miks keeratakse kevaditi ja sügiseti kella?; Miks kaalutakse Euroopa Liidus kellakeeramise lõpetamist?; Kella keeramine; Kellaaeg Venemaal; Mõisted

## Maa siseehitus. Laamad
URL: https://www.opiq.ee/kit/543/chapter/30034
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.1
Topics ET: matemaatika, siseehitus, laamad, kuidas, saadakse, teavet, sisemuse, kohta, saavad, geoloogid
Topics RU: математика
Topics EN: mathematics
Headings: Maa siseehitus. Laamad; Kuidas saadakse teavet Maa sisemuse kohta?; Kuidas saavad geoloogid teavet Maa sisemuses asuvate kivimite kohta?; Maad katab maakoor; Mille poolest erinevad mandriline ja ookeaniline maakoor?; Ligikaudu kui paks on maakoor Eestis?; Mis on Maa sees?; Mis elemendid Maa tuumas põhjustavad magnetismi?; Maa kivimilised kestad; Miks on Maa sisetuum tahkes, välistuum aga vedelas olekus?; Miks on maakoor laamadeks lõhenenud?; Miks laamad liiguvad?; Laamade liikumine; Vaata laamade kaarti ja märgi, kuidas liiguvad naaberlaamad teineteise suhtes.; Mõtle!; Mõisted

## Geoloogilised protsessid laamade servaaladel
URL: https://www.opiq.ee/kit/543/chapter/30221
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.2
Topics ET: matemaatika, geoloogilised, protsessid, laamade, servaaladel, külgepidi, liikuvad, laamad, milline, murrangutüüp
Topics RU: математика
Topics EN: mathematics
Headings: Geoloogilised protsessid laamade servaaladel; Külgepidi liikuvad laamad; Milline murrangutüüp kujuneb maakooreplokkide vahele, mis teineteisest eemalduvad?; Miks kuhjuvad külgepidi liikuvate laamaservade vööndis maakoorde suured pinged?; Milliseid protsesse esineb küljetsi liikuvate laamaservade piirkonnas?; Laamade lahknemine; Mis tegurite mõjul on tekkinud ookeani keskmäestik?; Kus paiknevad teineteise suhtes lahknevad laamaservad?; Millised protsessid esinevad laamade lahknemisvööndis?; Laamade põrkumine; Kus on mandriline maakoor kõige paksem?; Miks sukeldub laamade põrkumisel ookeanilise maakoorega laam mandrilise maakoorega laama alla?; Mis on süvik?; Miks ei äärista Lõuna-Ameerika idarannikut mäestik, nii nagu ääristab see läänerannikut?; Kuidas võivad hiljem tekkinud maakoore kivimid sattuda varem tekkinud kivimite alla?; Mõisted

## Maavärinad
URL: https://www.opiq.ee/kit/543/chapter/30262
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.3
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, maavärinad, miks, väriseb, rappub, maavärina, korral, maapind, kõige, rohkem
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Maavärinad; Miks maa väriseb?; Kus rappub maavärina korral maapind kõige rohkem?; Mis loodusnähtused võivad põhjustada maavärinaid?; Kus vallandub maavärin?; Kuidas levib maavärinas vallandunud energia?; Kus jõuab maavärinas vallandunud energia kõige varem maapinnani?; Kuidas ja kus tekivad hiidlained?; Millised tunnused võivad rannikul anda märku peagi saabuvast hiidlainest?; Kuidas põhjustab maavärin hiidlaineid?; Kus liigub tsunamilaine kõige kiiremini?; Kuidas mõõdetakse maavärina tugevust?; Mitu korda rohkem energiat vallandus Sendai maavärinas (2011) võrreldes Haiti maavärinaga (2010)?; Kus esineb maavärinaid?; Millistes toodud piirkondades esineb tihti maavärinaid?; Mõisted

## Vulkaanid
URL: https://www.opiq.ee/kit/543/chapter/30263
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.4
Topics ET: matemaatika, vulkaanid, kuidas, tekivad, milline, kirjeldus, iseloomustab, kuuma, täppi, mida
Topics RU: математика
Topics EN: mathematics
Headings: Vulkaanid; Kuidas ja kus tekivad vulkaanid?; Milline kirjeldus iseloomustab kuuma täppi?; Mida võib vulkaan maapõuest välja paisata?; Kus esineb vulkaane?; Mille poolest vulkaanid erinevad?; Miks kasvavad kihtvulkaanid kõrgusse?; Milline magma on vedelam?; Millistes kohtades asuvad kihtvulkaanid?; Millistes kohtades asuvad kilpvulkaanid?; Kui sageli vulkaanid purskavad?; Mis eristab geisreid muudest kuumaveeallikatest?; Millist vulkaani lause kirjeldab?; Mõisted

## Inimesed vulkaanilistes ja maavärinaohtlikes piirkondades
URL: https://www.opiq.ee/kit/543/chapter/30393
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.5
Topics ET: matemaatika, inimesed, vulkaanilistes, maavärinaohtlikes, piirkondades, millised, tagajärjed, maavärinatel, kuidas, aitab
Topics RU: математика
Topics EN: mathematics
Headings: Inimesed vulkaanilistes ja maavärinaohtlikes piirkondades; Millised tagajärjed on maavärinatel?; Kuidas aitab looduslik taimkate kaitsta nõlva lihkumise eest?; Mis tagajärjed võivad olla maavärinatel?; Mida toovad kaasa vulkaanipursked?; Milline vulkaaniline nähtus ohustab kõige rohkem inimeste elu ja tervist?; Miks elatakse vulkaanide lähedal?; Miks on vulkaanide jalamil viljakad mullad?; Mis soodustab inimasustust vulkaanide lähedal?; Kuidas varitsevate ohtudega toime tulla?; Kuidas õnnestub suure rahvaarvuga Jaapanil sagedaste tugevate maavärinate ajal vältida rohkeid inimkaotusi?; Kuidas toimida maavärina korral?; Mõisted

## Kivimid
URL: https://www.opiq.ee/kit/543/chapter/30394
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.6
Topics ET: matemaatika, kivimid, mineraalid, kuidas, tekkinud, tardkivimid, süvakivimid, millest, sõltub, mõned
Topics RU: математика
Topics EN: mathematics
Headings: Kivimid; Mis on kivimid?; Kivimid ja mineraalid; Kuidas on tekkinud tardkivimid?; Mis on süvakivimid?; Millest sõltub, et mõned tardkivimid on ühtlase, teised aga teralise või laigulise välisilmega?; Murenemine ja setted; Järjesta setted selle järgi, kui tugevat veevoolu on nende edasikandmiseks vaja.; Milliste tegurite toimel kivimid murenevad?; Kuidas on tekkinud settekivimid?; Kuidas on tekkinud fossiilsed kütused?; Miks on settekivimid kihilise ehitusega?; Kuidas on tekkinud moondekivimid?; Millised on kivimite moondumiseks vajalikud tingimused?; Mida tähendab, et kivim moondub?; Mis tüüpi kivimitest võivad tekkida moondekivimid?; Kus on kivimite moondumiseks sobivad tingimused?; Kas kivimid on igavesed?; Vali õige etapp kivimiringe lõigus.; Mõisted

## Maavarad ja kivimite kasutamine
URL: https://www.opiq.ee/kit/543/chapter/30421
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.7
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, maavarad, kivimite, kasutamine, milliseid, rikkusi, leidub, maapõues, miks, maapõuest
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Maavarad ja kivimite kasutamine; Milliseid rikkusi leidub maapõues?; Miks on iga maapõuest leitud naftakogum üleilmselt tähtis?; Mis on maavara?; Miks on vaja kaevandatud kivimeid enamasti rikastada?; Milleks kasutatakse kivimeid?; Milleks kasutatakse setteid?; Mis valdkonnas leiab kasutamist kõige suurem osa maapõuest välja toodud kivimitest?; Mõisted

## Kordamine. Geoloogia
URL: https://www.opiq.ee/kit/543/chapter/30422
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 2.8
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, võrdlemine, võrdle, suurem, väiksem, kordamine, harjutan, geoloogia, siseehitus, laamad, vaata, laamade, kaarti, märgi, kuidas
Topics RU: математика, умножение, умножь, произведение, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, comparison, compare, greater, less, revision, review, practice
Headings: Kordamine. Geoloogia; 2.1. Maa siseehitus. Laamad; Vaata laamade kaarti ja märgi, kuidas liiguvad naaberlaamad teineteise suhtes.; Kuidas saavad geoloogid teavet Maa keskosas asuvate kivimite kohta?; Mille poolest erinevad mandriline ja ookeaniline maakoor?; Ligikaudu kui paks on maakoor Eestis?; Maa kivimilised kestad; Miks on Maa sisetuum tahkes, välistuum aga vedelas olekus?; Mis elemendid Maa tuumas põhjustavad magnetismi?; Miks laamad liiguvad?; Millist maakoort laamadel leidub?; 2.2. Geoloogilised protsessid laamade servaaladel; Kus on mandriline maakoor kõige paksem?; Miks kuhjuvad külgepidi liikuvate laamaservade vööndis maakoorde suured pinged?; Milliseid protsesse esineb küljetsi liikuvate laamaservade piirkonnas?; Milline murrangutüüp kujuneb maakooreplokkide vahele, mis teineteisest eemalduvad?; Kus paiknevad teinetese suhtes lahknevad laamaservad?; Millised protsessid esinevad laamade lahknemisvööndis?; Mis tegurite mõjul on tekkinud ookeani keskmäestik?; Miks sukeldub laamade põrkumisel ookeanilise maakoorega laam mandrilise maakoorega laama alla?; Mis on süvik?; Miks ei äärista Lõuna-Ameerika idarannikut mäestik, nii nagu ääristab see läänerannikut?; Kuidas võivad hiljem tekkinud maakoore kivimid sattuda varem tekkinud kivimite alla?; 2.3. Maavärinad; Millistes toodud piirkondades esineb tihti maavärinaid?; Mis loodusnähtused võivad põhjustada maavärina?; Kus vallandub maavärin?; Kuidas levib maavärinas vallandunud energia?; Kus jõuab maavärinas vallandunud energia kõige varem maapinnani?; Kus rappub maavärina korral maapind kõige rohkem?; Kuidas põhjustab maavärin hiidlaineid?; Kus liigub tsunamilaine kõige kiiremini?; Millised tunnused võivad rannikul anda märku peagi saabuvast hiidlainest?; Mitu korda rohkem energiat vallandus Sendai maavärinas (2011) võrreldes Haiti maavärinaga (2010)?; 2.4. Vulkaanid; Mis eristab geisreid muudest kuumaveeallikatest?; Mida võib vulkaan maapõuest välja paisata?; Kus esineb vulkaane?; Milline kirjeldus iseloomustab kuuma täppi?; Milline magma on vedelam?; Millistes kohtades asuvad kihtvulkaanid?; Millistes kohtades asuvad kilpvulkaanid?; Miks kasvavad kihtvulkaanid kõrgusse?; Millist vulkaani lause kirjeldab?; 2.5. Inimesed vulkaanilistes ja maavärinaohtlikes piirkondades; Kuidas õnnestub suure rahvaarvuga Jaapanil sagedastes tugevates maavärinates vältida rohkeid inimkaotusi?; Mis tagajärjed võivad olla maavärinatel?; Kuidas aitab looduslik taimkate kaitsta nõlva lihkumise eest?; Milline vulkaaniline nähtus ohustab kõige rohkem inimeste elu ja tervist?; Mis soodustab inimasustust vulkaanide lähedal?; Miks on vulkaanide jalamil viljakad mullad?; 2.6. Kivimid; Millised on kivimite moondumiseks vajalikud tingimused?; Kivimid ja mineraalid; Millest sõltub see, et mõned tardkivimid on ühtlase, teised aga teralise või laigulise välimusega?; Mis on süvakivimid?; Milliste tegurite toimel kivimid murenevad?; Järjesta setted selle järgi, kui tugevat veevoolu on nende edasikandmiseks vaja.; Miks on settekivimid kihilise ehitusega?; Kuidas on tekkinud fossiilsed kütused?; Mida tähendab, et kivim moondub?; Mis tüüpi kivimitest võivad tekkida moondekivimid?; Kus on kivimite moondumiseks sobivad tingimused?; 2.7. Maavarad ja kivimite kasutamine; Milleks kasutatakse setteid?; Mis on maavara?; Miks on vaja kaevandatud kivimeid enamasti rikastada?; Miks on iga maapõuest leitud naftakogum üleilmselt tähtis?; Mis valdkonnas leiab kasutamist kõige suurem osa maapõuest välja toodud kivimitest?

## Pinnamood ja pinnavormid
URL: https://www.opiq.ee/kit/543/chapter/30423
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 3.1
Topics ET: matemaatika, pinnamood, pinnavormid, kuidas, iseloomustatakse, pinda, järjesta, suuruse, järgi, alusta
Topics RU: математика
Topics EN: mathematics
Headings: Pinnamood ja pinnavormid; Kuidas iseloomustatakse Maa pinda?; Järjesta pinnavormid suuruse järgi. Alusta suurimast; Mis on reljeef?; Mis on maakera suurimad pinnavormid?; Kuidas mõjutab pinnamood inimesi ja loodust?; Mida tähendab, et mingi piirkonna pinnamood on vaheldusrikas?; Mõisted

## Maailmamere põhjareljeef
URL: https://www.opiq.ee/kit/543/chapter/30424
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 3.2
Topics ET: matemaatika, maailmamere, põhjareljeef, kuidas, piiritleda, mandreid, ookeaninõgusid, mille, poolest, erineb
Topics RU: математика
Topics EN: mathematics
Headings: Maailmamere põhjareljeef; Kuidas piiritleda mandreid ja ookeaninõgusid?; Mille poolest erineb rannikumeri avaookeanist?; Mandrid ja ookeaninõod; Kus on mandrilise ja ookeanilise maakoore piir?; Milline on maailmamere põhjareljeef?; Kus paiknevad süvikud?; Märgi tõesed väited ookeanide keskmäestiku kohta.; Mis on ookeanide keskmine sügavus?; Mõisted

## Mäestikud ja mägismaad
URL: https://www.opiq.ee/kit/543/chapter/30425
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 3.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, mäestikud, mägismaad, milliseid, pinnavorme, moodustavad, mäed, maailma, kõrgeim, mäestik
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Mäestikud ja mägismaad; Milliseid pinnavorme moodustavad mäed?; Mis on maailma kõrgeim mäestik?; Mis on mäestik?; Mis on mägismaa?; Mis on pikim mäestik maismaal?; Orud ja nõod liigendavad pinnamoodi; Võrdle orgu ja nõgu.; Miks on mäestikud eriilmelised?; Mäestikuvööndid; Võrdle noori ja vanu mäestikke.; Kuidas jaotatakse mäestikke kõrguse järgi?; Mäestike kõrgus; Inimtegevus mägise pinnamoega aladel; Märgi tõesed väited mäestikes valitsevate olude kohta.; Mõisted

## Tasandikud
URL: https://www.opiq.ee/kit/543/chapter/30446
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 3.4
Topics ET: matemaatika, tasandikud, mille, poolest, erinevad, kõrgel, paiknevad, kiltmaad, paikneb, enamik
Topics RU: математика
Topics EN: mathematics
Headings: Tasandikud; Mille poolest tasandikud erinevad?; Kui kõrgel paiknevad kiltmaad?; Kus paikneb enamik maailma madalikke?; Mis eristab alamikke teistest tasandikest?; Millised pinnavormid peamiselt lavamaade pinnamoodi liigestavad?; Mis on lauskmaa?; Märgi lauskmaad kirjeldavad tunnused.; Inimtegevus tasase pinnamoega aladel; Millised tegurid soodustavad inimasustust tasandikel võrreldes mäestikega?; Mõisted

## Maa pinnamood muutub
URL: https://www.opiq.ee/kit/543/chapter/30447
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 3.5
Topics ET: matemaatika, pinnamood, muutub, sise, välisjõud, lohista, loodusprotsess, õigesse, rühma, maapind
Topics RU: математика
Topics EN: mathematics
Headings: Maa pinnamood muutub; Maa sise- ja välisjõud; Lohista loodusprotsess õigesse rühma.; Maapind kerkib ja vajub; Mida võib kaasa tuua maakoore vajumine?; Miks maapind Põhja-Euroopas kerkib?; Kuidas kulutab maapinda vihmavesi?; Millises protsessis tekib uhtorg?; Millised inimtegevused soodustavad erosiooni?; Kus kujundavad pinnamoodi liustikud?; Milliste kivimite teke on sarnane liustiku tekkele?; Millistel tingimustel saab tekkida liustik?; Mis on Gröönimaa mandrijääkilbi keskmine paksus?; Milliste alade pinnamoodi mõjutab tuul kõige rohkem?; Tuul pinnamoe kujundajana; Millise kliimaga paikades on tuul peamine pinnamoe kujundaja?; Mõisted

## Inimtegevuse mõju pinnamoele
URL: https://www.opiq.ee/kit/543/chapter/30448
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 3.6
Topics ET: matemaatika, inimene, keha, meeled, tervis, inimtegevuse, mõju, pinnamoele, milliseid, pinnavorme, loob, kuidas, pinnavorm
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Inimtegevuse mõju pinnamoele; Milliseid pinnavorme loob inimene?; Kuidas on pinnavorm tekkinud?; Millega peab inimene arvestama?; Millega peab inimene maad kasutades arvestama?

## Kordamine. Pinnamood
URL: https://www.opiq.ee/kit/543/chapter/30449
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 3.7
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan, inimene, keha, meeled, tervis, pinnamood, pinnavormid, mida, tähendab, mingi, piirkonna, vaheldusrikas, reljeef
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка, человек, тело, чувства, здоровье
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice, human, body, senses, health
Headings: Kordamine. Pinnamood; 3.1. Pinnavormid ja pinnamood; Mida tähendab, et mingi piirkonna pinnamood on vaheldusrikas?; Mis on reljeef?; Mis on maakera suurimad pinnavormid?; Järjesta pinnavormid suuruse järgi. Alusta suurimast; 3.2. Maailmamere põhjareljeef; Kus paiknevad süvikud?; Märgi tõesed väited mandrite ja ookeaninõgude kohta.; Kus on mandrilise ja ookeanilise maakoore piir?; Mille poolest erineb rannikumeri avaookeanist?; Märgi tõesed väited ookeanide keskmäestiku kohta.; Mis on ookeanide keskmine sügavus?; 3.3. Mäestikud ja mägismaad; Märgi tõesed väited mäestikes valitsevate olude kohta.; Mis on mäestik?; Mis on pikim mäestik maismaal?; Mis on maailma kõrgeim mäestik?; Võrdle orgu ja nõgu.; Võrdle noori ja vanu mäestikke.; Mäestikuvööndid; Mäestike kõrgus; 3.4. Tasandikud; Millised tegurid soodustavad inimasustust tasandikel võrreldes mäestikega?; Kus paikneb enamik maailma madalikke?; Mis eristab alamikke teistest tasandikest?; Millised pinnavormid liigestavad peamiselt lavamaade pinnamoodi?; Kui kõrgel paiknevad kiltmaad?; Märgi lauskmaa tunnused.; 3.5. Maa pinnamood muutub; Tuul pinnamoe kujundajana; Lohista loodusprotsess õigesse rühma.; Miks maapind Põhja-Euroopas kerkib?; Mida võib kaasa tuua maakoore vajumine?; Millised inimtegevused soodustavad erosiooni?; Millises protsessis tekib uhtorg?; Millistel tingimustel saab mingisse paika tekkida liustik?; Mis on Antarktise mandrijääkilbi keskmine paksus?; Milliste kivimite teke on sarnane liustiku tekkele?; Millise kliimaga paikades on tuul peamine pinnamoe kujundaja?; 3.6. Inimtegevuse mõju pinnamoele; Millega peab inimene maad kasutades arvestama?; Kuidas on pinnavorm tekkinud?

## Mõisted
URL: https://www.opiq.ee/kit/543/chapter/30035
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 4.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Maailma looduskaart
URL: https://www.opiq.ee/kit/543/chapter/30072
Book: Sissejuhatus geograafiasse
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 4.2
Topics ET: loodusõpetus, maailma, looduskaart, põhja, ameerika, lõuna, euroopa, aafrika, aasia, austraalia
Topics RU: природоведение
Topics EN: science
Headings: Maailma looduskaart; Põhja-Ameerika; Lõuna-Ameerika; Euroopa ja Aafrika; Aasia; Austraalia ja Okeaania

## Maailma poliitiline kaart
URL: https://www.opiq.ee/kit/543/chapter/30264
Book: Sissejuhatus geograafiasse
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 7k__geograafia_avita_est
Chapter ID: 4.3
Topics ET: matemaatika, maailma, poliitiline, kaart, põhja, ameerika, euroopa, aasia, austraalia, okeaania
Topics RU: математика
Topics EN: mathematics
Headings: Maailma poliitiline kaart; Põhja-Ameerika; Euroopa; Aasia; Austraalia ja Okeaania; Aafrika; Lõuna-Ameerika

## География для 7 класса – Opiq
URL: https://www.opiq.ee/Kit/Details/19
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 186
Topics ET: matemaatika, opiq
Topics RU: математика, география, класса
Topics EN: mathematics

## Природа и деятель­ность человека
URL: https://www.opiq.ee/kit/19/chapter/866
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 1.1
Topics ET: matemaatika, aeg, kell, kalender, loodus, loodusõpetus, keskkond
Topics RU: математика, время, часы, календарь, природа, природоведение, окружающая среда, деятель, ность, человека, занимаются, географы, наше, входит
Topics EN: mathematics, time, clock, calendar, nature, science, environment
Headings: Природа и деятель­ность человека; Чем занимаются географы в наше время?; Что не входит в список объектов исследования географии населения?; Что изучает география?; Как отображаются результаты географических исследований?; Что не входит в список объектов исследования физической географии?; Как проводятся географические исследования?; Подумай!; Для чего используются снимки со спутника?; Как распреде­ляются на Земле материки, части света и океаны?; Что из перечисленного не является частью света?; Берега какого материка омывают воды четырех океанов?; Материки и части света

## Форма и размеры Земли
URL: https://www.opiq.ee/kit/19/chapter/867
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.1
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, форма, размеры, земли, люди, изображали, землю, далеком, прошлом, доказало
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Форма и размеры Земли; Как люди изображали Землю в далеком прошлом?; Что доказало шаро­об­раз­ную форму Земли?; Почему объекты, удаляясь от нас, пропадают из нашего поля зрения?; Подумай!; Как выглядели первые карты?; Определи по карте Птолемея, какие части света были известны древним грекам.; Из каких источников получали сведения о дальних странах географы периода Древнего мира?; Как формировалось представ­ле­ние людей о мире?; Какие регионы Земли были иссле­до­ва­ны последними?; Кто возглавлял первое кругосветное плавание, доказавшее, что Земля – это шар?; Какие государства были самыми крупными колониальными империями?; Какого размера земной шар?; Зачем нужно знать размеры Земли?; Почему Земля сплюснута с полюсов?; Какова длина экватора Земли?

## Различные виды карт
URL: https://www.opiq.ee/kit/19/chapter/868
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, различные, виды, карт, чего, нужны, карты, такое, атлас, подумай
Topics EN: mathematics
Headings: Различные виды карт; Для чего нужны карты?; Что такое атлас?; Подумай!; Какие бывают карты?; Как называется самая важная топографическая карта Эстонии?; Чем тематическая карта отличается от общегеографической?; Чем отличаются карты от снимков?; Карта и аэрофотоснимок; Что такое аэрофото­снимок?; Зачем нужны условные знаки?; Что отображают линейными условными знаками?; Для чего нужна легенда карты?; Дополнительный материал. Топографическая карта Эстонии; По каким признакам найти на карте болото?; Какова высота самой высокой точки?; На какой высоте над уровнем моря находится поверхность озера Саадъярв?; На какой высоте над уровнем моря находится валун Kalevi­poja lingukivi?; Понятия

## Электронная карта
URL: https://www.opiq.ee/kit/19/chapter/869
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, электронная, карта, представляют, собой, электронные, карты, почему, делят, слои
Topics EN: mathematics
Headings: Электронная карта; Что представляют собой электронные карты?; Почему электронные карты делят на слои?; Что позволяют делать программы для просмотра электронных карт?; Подумай!; Что такое ГИС?; Для чего используют ГИС?; Что такое интерактивная карта?; Какими свойствами обладают интерактивные карты?; Какие преимущества есть у типографских карт?; Каковы преимущества электронных карт по сравнению с бумажными?; Понятия

## Масштаб и измерение расстояний
URL: https://www.opiq.ee/kit/19/chapter/870
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.4
Topics ET: matemaatika, arv, arvud, arvu, numbrid, mõõtmine, mõõtühik, pikkus, mass, maht, loodus, loodusõpetus, keskkond
Topics RU: математика, число, числа, цифры, измерение, единица измерения, длина, масса, объём, природа, природоведение, окружающая среда, масштаб, расстояний, показывает, справа, численном, масштабе, чего
Topics EN: mathematics, number, numbers, digits, measurement, unit, length, mass, volume, nature, science, environment
Headings: Масштаб и измерение расстояний; Что показывает масштаб?; Что показывает число справа в численном масштабе?; Для чего необходимо указывать на карте масштаб?; Как делятся карты по масштабу?; Карту какого масштаба ты возьмешь в поездку из Лууа в Ляхте?; На какой карте изображена самая маленькая территория?; На какой карте природа изображена наиболее подробно?; Что такое генерализация карты?; Генерализация карт; Для чего необходима генерализация?; Какие карты наиболее генерализованы?; Понятия

## Направле­ние на местности и на карте
URL: https://www.opiq.ee/kit/19/chapter/871
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, направле, местности, карте, определить, направление, стороны, горизонта, отыскать, ночном
Topics EN: mathematics
Headings: Направле­ние на местности и на карте; Как определить направление на местности?; Как определить стороны горизонта на местности?; Как отыскать на ночном небе Полярную звезду?; Что такое азимут и как его определить по компасу?; По какому азимуту нужно двигаться, чтобы добраться из Виртсу на Рухну?; Куда направлена магнитная стрелка компаса?; Что такое азимут?; Как сориентировать карту?; Как сориентировать карту по сторонам света?; Подумай!; Понятия

## Определе­ние место­нахож­дения. Географи­ческие координаты
URL: https://www.opiq.ee/kit/19/chapter/872
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.6
Topics ET: matemaatika, jagamine, jaga, jagatis, pool
Topics RU: математика, деление, раздели, частное, половина, определе, место, нахож, дения, географи, ческие, координаты, определить, местоположение
Topics EN: mathematics, division, divide, quotient, half
Headings: Определе­ние место­нахож­дения. Географи­ческие координаты; Как определить местоположение по адресу?; Подумай!; Деление территории Эстонии; Как определить местона­хож­де­ние по координатам?; Как определить географическую долготу точки?; На какие части делит Землю экватор?; Что делит Землю на Западное и Восточное полушария?; Каким будет наибольшее значение для меридианов и параллелей?; Как определить географическую широту точки?; Как картографическая сетка по­мо­гает определить направление?; Как GPS-приемник определяет свое место нахождения?; Что такое картографическая сетка?; Понятия

## Часовые пояса
URL: https://www.opiq.ee/kit/19/chapter/873
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.7
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, часовые, пояса, такое, местное, изменяется, солнечное, эстонии, движении
Topics EN: mathematics, time, clock, calendar
Headings: Часовые пояса; Что такое местное время?; Как изменяется местное солнечное время в Эстонии при движении вдоль меридиана 25° в. д. с севера на юг?; Подумай!; Что такое часовые пояса?; В каких государствах несколько часовых поясов??; На сколько часов восточноевропейское время отличается от всемирного?; В каком направлении нужно ехать, чтобы вечер того же дня наступил для тебя быстрее?; С какого меридиана начинается новый день?; Почему во время кругосветного плавания Магеллана один день пропал из судового журнала?; Почему линия перемены дат не проходит строго по меридиану?; Почему во время путешествия нужно переводить стрелки часов?; Время в России; Куда нужно перевести часы?; Зачем нужно летнее и зимнее время?; Перевод часов; Чем зимнее время отличается от летнего?; Понятия

## Повторение: картография
URL: https://www.opiq.ee/kit/19/chapter/874
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 2.8
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, aeg, kell, kalender, kordamine, korda, harjutan
Topics RU: математика, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём, время, часы, календарь, повторение, повтори, тренировка, картография, форма, размеры, земли, материк, часть, света, чего
Topics EN: mathematics, comparison, compare, greater, less, measurement, unit, length, mass, volume, time, clock, calendar, revision, review, practice
Headings: Повторение: картография; 2.1 Форма и размеры Земли; Материк или часть света?; Для чего нужно знать размеры Земли?; Мировой океан; Какова форма Земли?; 2.2 Различные виды карт; Типы карт; Сравни карту и аэрофотоснимок; Что такое карта?; Как называется самая важная топографическая карта Эстонии?; 2.3 Электронная карта; Для чего используют ГИС?; Какими свойствами обладают интерактивные карты?; Почему данные на компьютерных картах наносятся отдельными слоями?; 2.4 Масштаб и измерение расстояний; Какая карта требует меньше всего обобщений?; На какой карте можно найти самое детальное изображение природы?; С каким масштабом мы имеем дело?; Какая из данных карт самая подробная?; На какую карту поместится самый большой участок природной зоны?; 2.5 Направле­ние на местности и на карте; Что такое азимут?; Как можно определить стороны света на местности?; 2.6 Определе­ние место­нахож­де­ния. Географи­ческие координаты; Что такое картографическая сетка?; Что делит Землю на восточное и западное полушария?; Каково наибольшее значение?; Как определить географическую широту?; 2.7 Часовые пояса; Часовые пояса; Чем зимнее время отличается от летнего?; Как изменяется местное солнечное время в Эстонии при движении вдоль меридиана 25° в. д. с севера на юг?; Во время каких путешествий мы быстрее попадем из вечера сегодняшнего дня в завтрашнее утро?; Понятия; Кроссворд по теме «Картография»

## Внутреннее строение Земли
URL: https://www.opiq.ee/kit/19/chapter/875
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, внутреннее, строение, земли, находится, внутри, какие, элементы, ядре, обуславливают
Topics EN: mathematics
Headings: Внутреннее строение Земли; Что находится внутри Земли?; Какие элементы в ядре Земли обуславливают магнитные свойства планеты?; Строение Земли; Чем литосфера отличается от земной коры?; Везде ли земная кора одинаковая?; Из каких пород состоит материковая земная кора?; Чем материковая земная кора отличается от океанической?; Подумай!; Понятия

## Литосфер­ные плиты и их движение
URL: https://www.opiq.ee/kit/19/chapter/876
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, литосфер, плиты, движение, почему, земная, кора, раскололась, какие, состоят
Topics EN: mathematics
Headings: Литосфер­ные плиты и их движение; Почему земная кора раскололась?; Какие плиты состоят как из океанической, так и из материковой земной коры?; Почему литосферные плиты движутся?; Из какого типа земной коры состоят литосферные плиты?; Что происходит, когда плиты расходятся?; Какие процессы происходят в зоне расхождения литосферных плит?; Где происходят разрыв земной коры и расхождение литосферных плит?; Что происходит, когда плиты сталкиваются?; Где материковая земная кора имеет наибольшую толщину?; Почему при столкновении плит океаническая плита погружается под материковую?; Что такое глубоководный желоб?; Почему на восточном побережье Южной Америки нет гор?; Каким образом более молодые горные породы могут оказаться под слоем более древних?; Подумай!; Что происходит при параллель­ном перемещении плит?; К какому типу относится разлом Сан-Андреас?; Какие процессы обус­лов­ле­ны гори­зон­таль­ным дви­же­ни­ем ли­то­сфер­ных плит?; Понятия

## Землетря­сения
URL: https://www.opiq.ee/kit/19/chapter/877
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, землетря, сения, почему, сотрясается, земля, возникают, цунами, колебания, земной
Topics EN: mathematics
Headings: Землетря­сения; Почему сотрясается земля?; Где и как возникают цунами?; Почему возникают колебания земной коры?; Чем различаются сейсмические и морские волны?; Где происходят землетрясения?; Где могут происходить землетрясения?; Подумай!; Как измеряют силу землетрясения?; Шкала Рихтера и шкала Меркалли; Понятия

## Вулканы
URL: https://www.opiq.ee/kit/19/chapter/878
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, вулканы, возникают, расположены, магма, лава, побережье, тихого, океана, часто
Topics EN: mathematics
Headings: Вулканы; Как возникают вулканы?; Где расположены вулканы?; Магма и лава; Побережье Тихого океана часто называют Тихоокеанским огненным поясом. Почему?; Подумай!; Как часто извергаются вулканы?; С каким вулканом мы имеем дело?; Какие бывают вулканы?; Как связаны между собой вулканы и горячие источники?; Почему извержения некоторых вулканов сопровождаются мощным взрывом?; Понятия

## Жизнь людей в сейсмически опасных зонах и вблизи вулканов
URL: https://www.opiq.ee/kit/19/chapter/879
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, жизнь, людей, сейсмически, опасных, зонах, вблизи, вулканов, предостерегают, опасности
Topics EN: mathematics
Headings: Жизнь людей в сейсмически опасных зонах и вблизи вулканов; Как предостерегают об опасности?; На границе каких литосферных плит находится Япония?; С какими природными опасностями приходится сталкиваться жителям Японии?; Почему люди живут вблизи вулканов?; Почему близость вулкана выгодна для людей?; Почему у подножия вулканов плодородная почва?; Что служит основным источником для производства тепловой энергии в Исландии?

## Горные породы
URL: https://www.opiq.ee/kit/19/chapter/880
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика, горные, породы, образовались, магматические, такое, вулканические, глубинные, осадочные, рыхлая
Topics EN: mathematics
Headings: Горные породы; Как образовались магматические горные породы?; Что такое вулканические породы?; Что такое глубинные породы?; Как образовались осадочные горные породы?; Чем рыхлая осадочная порода отличается от твердой?; Расположи фракции осадочных пород в порядке увеличения их размера.; Как образовалось фоссильное топливо?; Подумай!; Как образовались метамор­фи­чес­кие горные породы?; Из чего образуются метаморфические породы?; В каких условиях обра­зу­ют­ся мета­мор­фи­чес­кие породы?; Какие изменения про­ис­хо­дят при мета­мор­фо­зе горных пород?; Вечны ли горные породы?; Образование горных пород; Как используются горные породы?; В каких горных породах содержится фоссильное топливо?; Какие отрасли снабжают сырьем горные породы?; Дополнительный материал: Страницы «каменной книги»; На территории какого штата США расположен Большой Каньон?; В какой залив впадает река Колорадо?; Понятия

## Повторение: геология
URL: https://www.opiq.ee/kit/19/chapter/881
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 3.7
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка, геология, внутреннее, строение, земли, каких, горных, пород, состоит
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice
Headings: Повторение: геология; 3.1 Внутреннее строение Земли; Из каких горных пород состоит океаническая земная кора??; Чем отличаются океаническая и материковая земная кора?; Строение Земли; Чем литосфера отличается от земной коры?; 3.2 Литосфер­ные плиты и их движение; Расхождение и столкновение литосферных плит; Какие плиты состоят как из океанической, так и из материковой земной коры?; Какие плиты состоят только из океанической земной коры?; Где материковая земная кора толще всего?; Почему литосферные плиты движутся?; Где образуется новая земная кора?; 3.3 Землетря­сения; Чем измеряют мощность землетрясений?; Где случаются наиболее сильные землетрясения?; Где на земной поверхности сила толчков будет наибольшей?; Где разрушения от цунами будут наибольшими?; 3.4 Вулканы; Почему близость вулкана выгодна для людей?; Чем отличается уснувший вулкан от потухшего?; Магма и лава; На побережье какого океана больше всего вулканов?; Что характеризует щитовой вулкан?; 3.5 Жизнь людей в сейсмически опасных зонах и вблизи вулканов; Как сделать жизнь в сейсмически активном регионе безопаснее?; Какую пользу приносит людям проживание вблизи вулкана?; 3.6 Горные породы; Глубинные и вулканические породы; Образование горных пород; Чем рыхлая осадочная порода отличается от твердой?; Понятия; Кроссворд по теме «Геология»

## Рельеф и его формы
URL: https://www.opiq.ee/kit/19/chapter/882
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, рельеф, формы, такое, рельефа, различаются, какие, самые, большие, охарактеризовать
Topics EN: mathematics
Headings: Рельеф и его формы; Что такое формы рельефа и чем они различаются?; Какие формы рельефа самые большие?; Что такое рельеф?; Как охарактеризовать рельеф?; Рельеф стран; Подумай!; Дополнительный материал. Рельеф Австрии; Понятия

## Изображение рельефа на карте
URL: https://www.opiq.ee/kit/19/chapter/883
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, изображение, рельефа, карте, такое, горизонталь, подумай, послойной, окраской, находятся
Topics EN: mathematics
Headings: Изображение рельефа на карте; Что такое горизонталь?; Подумай!; Где на карте с послойной окраской находятся горизонтали?; Какова высота сечения рельефа на базовой карте Эстонии?; Как будет выглядеть на карте крутой склон?; Базовая карта Эстонии; Что такое метод отмывки?; Какой метод дает более точное представление о рельефе?; Что показывает профиль рельефа?; Согласно гипсо­гра­фи­чес­кой кривой, 2% земной поверхности имеет высоту...; При помощи гипсографи­ческой кривой Земли определи, какую часть Земли занимает Мировой океан?; При помощи гипсографи­ческой кривой Земли определи, какую часть Земли занимают высоты от –4000 м до 4000 м?; Чем отличаются абсолютная и относительная высота?; Найди при помощи данной карты, какое из озер имеет наибольшую абсолютную высоту.; Какая высота указана на картах?; Найди при помощи данной карты высоту хутора Аллика относительно озера Саадъярв.; Понятия

## Горы и горные системы
URL: https://www.opiq.ee/kit/19/chapter/884
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, горы, горные, системы, какие, формы, рельефа, образуют, различаются, горный
Topics EN: mathematics
Headings: Горы и горные системы; Какие формы рельефа образуют горы?; Чем различаются горный хребет и нагорье?; Что такое горная система?; Долины и впадины оживляют рельеф; Чем отличается впадина от долины?; Какие водоемы Эстонии расположены в долине?; Почему горные системы отличаются друг от друга?; Почему молодые и старые горы выглядят по-разному?; Чем старые горы внешне отличаются от молодых?; Как делятся горы по высоте?; Назови ближайшее к Эстонии высокогорье; Деятельность человека в горных областях; Что характеризует условия для земледелия в горах?; Дополнительный материал. Как разрушаются горные хребты?; Какие государства не находятся на Восточно-Европейской равнине?; Понятия

## Равнины
URL: https://www.opiq.ee/kit/19/chapter/885
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, равнины, находятся, разной, высоте, чего, зависит, облик, равнин, такое
Topics EN: mathematics
Headings: Равнины; Равнины находятся на разной высоте; От чего зависит облик равнин?; Что такое депрессия?; Чем различаются нагорье и плоскогорье?; На каком материке находятся данные равнины?; Деятельность человека на равнинных территориях; Подумай!; Что характеризует жизнь людей на равнинах?; Понятия

## Рельеф дна Мирового океана
URL: https://www.opiq.ee/kit/19/chapter/886
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, рельеф, мирового, океана, проходит, граница, между, материками, океанами, прибрежные
Topics EN: mathematics
Headings: Рельеф дна Мирового океана; Где проходит граница между материками и океанами?; Чем прибрежные воды отличаются от открытого моря?; Почему границы океанских впадин не совпадают с границами Мирового океана?; Где проходит граница между океа­ни­чес­кой и материковой земной корой?; Каков рельеф дна Мирового океана?; Где расположены глубоководные желоба?; Какие из данных островов расположены над срединно-океаническим хребтом?; Понятия

## Рельеф Земли изменяется (1)
URL: https://www.opiq.ee/kit/19/chapter/887
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, рельеф, земли, изменяется, земная, поверхность, поднимается, опускается, почему, карты
Topics EN: mathematics
Headings: Рельеф Земли изменяется (1); Земная поверхность поднимается и опускается; Почему карты западного побережья Эстонии за последние столетия сильно изменились?; Почему земная кора в Балтийском регионе поднимается?; Подумай!; Почему разрушаются горные породы?; В чем состоит важность выветривания?; Какие факторы влияют на процесс выветривания?; Как изменяют рельеф дождевые воды?; Какие виды человеческой деятельности ускоряют эрозию?; Что такое овраг?; Понятия

## Рельеф Земли изменяется (2)
URL: https://www.opiq.ee/kit/19/chapter/888
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.7
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, рельеф, земли, изменяется, изменяют, ледники, такое, морена, какие, утверждения
Topics EN: mathematics, human, body, senses, health
Headings: Рельеф Земли изменяется (2); Как изменяют рельеф ледники?; Что такое морена?; Какие утверждения характеризуют образование ледников?; Зачем изучают ледники?; В каких регионах рельеф форми­ру­ется под действием ветра?; Ветер формирует рельеф; В каком климате ветер оказывает наибольшее влияние на рельеф?; Какие формы рельефа создает человек?; Назови самые высокие горы искуственного происхождения в Эстонии.; Как возникли данные формы рельефа?; Подумай!

## Повторение: рельеф
URL: https://www.opiq.ee/kit/19/chapter/889
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 4.8
Topics ET: matemaatika, lahutamine, lahuta, vahe, kordamine, korda, harjutan
Topics RU: математика, вычитание, вычти, разность, повторение, повтори, тренировка, рельеф, формы, является, самыми, крупными, формами, рельефа, земле
Topics EN: mathematics, subtraction, subtract, difference, revision, review, practice
Headings: Повторение: рельеф; 4.1 Рельеф и его формы; Что является самыми крупными формами рельефа на Земле?; На что влияет рельеф?; 4.2 Изображение рельефа на карте; Какова разность высот горизонталей (сечение рельефа) для данного холма?; Что соединяет горизонталь?; Какая форма отображения рельефа дает наилучшее представление о нем?; Что показывает профильная линия рельефа?; 4.3 Горы и горные системы; Высота гор; Чем старые горы внешне отличаются от молодых?; Что такое нагорье?; Чем впадина отличается от долины?; 4.4 Равнины; На каком материке находятся данные равнины?; Восточно-Европейская равнина; Что такое депрессия?; Чем различаются нагорье и плоскогорье?; 4.5 Рельеф дна Мирового океана; Элементы рельефа океанического дна; Где расположены глубоководные океанические желоба?; Материки и океаны; Где проходит граница между океанической и материковой земной корой?; 4.6 Рельеф Земли изменяется (1); Какие виды человеческой деятельности ускоряют эрозию?; Осадки и текучие воды; Что способствует выветриванию горных пород?; 4.7 Рельеф Земли изменяется (2); Ветер формирует рельеф; Как образовались формы рельефа?; Что такое морена?; Что характеризует образование ледников?; Вопросы для повторения; Кроссворд по теме «Рельеф»

## Государства на карте мира
URL: https://www.opiq.ee/kit/19/chapter/890
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.1
Topics ET: matemaatika, arv, arvud, arvu, numbrid
Topics RU: математика, число, числа, цифры, государства, карте, мира, отражено, политической, площадь, государств, сколько, входит
Topics EN: mathematics, number, numbers, digits
Headings: Государства на карте мира; Что отражено на политической карте мира?; Площадь государств; Сколько государств входит в Европейский Союз (ЕС)?; Сколько уездов в Эстонии?; Чем различаются государства?; Какие государства входят в десятку крупнейших и по площади, и по чис­лен­нос­ти населения стран?; Расположи показатели согласно месту Эстонии в рейтинге стран; Какие государства входят в число лидеров как по ожидаемой продолжи­тельности жизни, так и по уровню образования?; Подумай!; Экономически развитые и развивающиеся страны; Какие регионы более успешны в экономическом плане?; Подумай; Врачебная помощь и потребление электроэнергии; Дополнительное чтение. Индекс бигмака; Индекс бигмака; Что показывает географическое положение страны?; Что характеризует географическое положение Эстонии?; Понятия

## Население мира
URL: https://www.opiq.ee/kit/19/chapter/891
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, население, мира, языки, укажи, страны, которых, испанский, является, государственным
Topics EN: mathematics
Headings: Население мира; Языки мира; Укажи страны, в которых испанский является государственным языком.; Государственный и родной языки; Какая система письма использовалась для написания этого учебника?; Подумай!; Как национальная культура влияет на человека?; Какие факторы влияют на мировоззрение человека?; Какая религия наиболее распространена в Эстонии?; Понятия

## Размещение населения (1)
URL: https://www.opiq.ee/kit/19/chapter/892
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, размещение, населения, почему, одни, районы, заселены, плотнее, других, какие
Topics EN: mathematics
Headings: Размещение населения (1); Почему одни районы заселены плотнее других?; Какие факторы ограничивают заселение территории людьми?; Какова средняя плотность населения на Земле?; Почему наиболее густо заселены побережья и устья рек?; Как сеть современных поселений отражает историческое развитие государства?; Развитие поселений; Развитие городов; Понятия

## Размещение населения (2)
URL: https://www.opiq.ee/kit/19/chapter/893
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.4
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, размещение, населения, каких, районах, самая, высокая, плотность, расположи, регионы
Topics EN: mathematics, time, clock, calendar
Headings: Размещение населения (2); В каких районах самая высокая плотность населения?; Расположи регионы в порядке увеличения проживающей в них доли мирового населения; Размещение населения на Земле; Население Европы; Почему население Европы в наше время не увеличивается?; Население Америки; Где проживает основная часть населения Северной Америки?; Население Азии; Почему Восточная и Южная Азия так плотно заселены?; Какая часть населения Земли проживает в Азии?; Население Африки и Австралии; Какие регионы Африки густо заселены?; Почему большая часть Австралии практически не заселена?

## Изменение численности населения (1)
URL: https://www.opiq.ee/kit/19/chapter/894
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.5
Topics ET: matemaatika
Topics RU: математика, изменение, численности, населения, влияет, почему, развивающихся, странах, высокая, смертность
Topics EN: mathematics
Headings: Изменение численности населения (1); Что влияет на изменение численности населения?; Почему в развивающихся странах высокая смертность?; Почему в развивающихся странах высокая рождаемость?; Рассмотри диаграмму темпов роста населения. Что из нижеперечисленного верно?; Как изменялась численность населения Земли?; Почему в начале прошлого века численность населения начала быстро расти?; Какие изменения принесли с собой увеличение темпа роста численности населения?; Подумай!

## Изменение численности населения (2)
URL: https://www.opiq.ee/kit/19/chapter/895
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.6
Topics ET: matemaatika
Topics RU: математика, изменение, численности, населения, какие, проблемы, возникают, быстрого, роста, каком
Topics EN: mathematics
Headings: Изменение численности населения (2); Какие проблемы возникают из-за быстрого роста численности населения?; В каком регионе в ближайшие десятилетия ожидается наибольший рост численности населения?; Почему в Китае предпочтение отдается новорожденным мальчикам?; Дополнительный материал. Роберт Мальтус; Почему предсказания Р. Мальтуса об истощении пищевых ресурсов не сбылось?; Подумай!; Почему люди меняют место жительства?; В какие страны пере­се­ля­лись жители Европы?; Почему люди вынуждены покидать свои дома?

## Города. Урбанизация
URL: https://www.opiq.ee/kit/19/chapter/896
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.7
Topics ET: matemaatika
Topics RU: математика, города, урбанизация, возникли, первые, строились, такое, город, почему, трудно
Topics EN: mathematics
Headings: Города. Урбанизация; Где возникли первые города?; Где строились первые города?; Что такое город?; Почему трудно определить точную границу города?; Размеры городов. Крупнейшие города мира; Как возникают городские агломерации?; Самые крупные города мира; Что такое урбанизация?; Как изменяется доля городского населения в наши дни?; Что стало причиной урбанизации?; Какие проблемы сопровождают урбанизацию?; Подумай!; Почему связанные с урбанизацией проблемы чаще всего возникают в развивающихся странах?; Дополнительный материал. «Мусорный кризис» в Неаполе; Понятия

## Повторение: население
URL: https://www.opiq.ee/kit/19/chapter/897
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 5.8
Topics ET: matemaatika, aeg, kell, kalender, kordamine, korda, harjutan
Topics RU: математика, время, часы, календарь, повторение, повтори, тренировка, население, государства, карте, мира, развитые, развивающиеся, страны, признаки
Topics EN: mathematics, time, clock, calendar, revision, review, practice
Headings: Повторение: население; 5.1 Государства на карте мира; Развитые и развивающиеся страны; Признаки государства; Географическое положение государства; К какому типу карт относятся политические карты?; 5.2 Население мира; Какая религия наиболее распространена в Эстонии?; Государственный и родной языки; Какие факторы влияют на мировоззрение человека?; 5.3 Размещение населения (1); Население мира и его размещение (3); Население мира и его размещение (1); Население мира и его размещение (2); Почему наиболее густо заселены побережья и устья рек?; Какие факторы ограничивают заселение территории людьми?; 5.4 Размещение населения (2); Расположи части света в порядке уменьшения проживающей в них доли мирового населения; Размещение населения на Земле; Население каких регионов земного шара наиболее велико?; 5.5 Изменение численности населения (1); Почему в начале прошлого века численность населения начала быстро расти?; Почему в развивающихся странах высокая рождаемость?; Почему в развивающихся странах высокая смертность?; 5.6 Изменение численности населения (2); В каком регионе численность населения растет в наше время быстрее всего?; Почему люди мигрируют?; 5.7 Города. Урбанизация; Почему связанные с урбанизацией проблемы чаще всего возникают в развивающихся странах?; Урбанизация в наши дни; Где строились первые города?; Почему трудно определить точную границу города?; Что стало причиной урбанизации?; Понятия; Кроссворд по теме «Население»

## Обзорная карта Эстонии
URL: https://www.opiq.ee/kit/19/chapter/900
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, обзорная, карта, эстонии
Topics EN: mathematics
Headings: Обзорная карта Эстонии

## Физическая карта мира
URL: https://www.opiq.ee/kit/19/chapter/901
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, физическая, карта, мира, северная, америка, южная, европа, африка, азия
Topics EN: mathematics
Headings: Физическая карта мира; Северная Америка; Южная Америка; Европа и Африка; Азия; Австралия и Океания

## Политичес­кая карта мира
URL: https://www.opiq.ee/kit/19/chapter/902
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, политичес, карта, мира, северная, америка, европа, азия, австралия, океания
Topics EN: mathematics
Headings: Политичес­кая карта мира; Северная Америка; Европа; Азия; Австралия и Океания; Африка; Южная Америка

## Построение диаграммы
URL: https://www.opiq.ee/kit/19/chapter/21019
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.4
Topics ET: matemaatika
Topics RU: математика, построение, диаграммы, запуск, программы, ввод, данных, выбор, оформление, сохранение
Topics EN: mathematics
Headings: Построение диаграммы; Запуск программы; Ввод данных; Выбор диаграммы; Оформление диаграммы; Сохранение диаграммы

## Условные обозначения на топографи­ческой карте Эстонии
URL: https://www.opiq.ee/kit/19/chapter/899
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.5
Topics ET: matemaatika
Topics RU: математика, условные, обозначения, топографи, ческой, карте, эстонии
Topics EN: mathematics
Headings: Условные обозначения на топографи­ческой карте Эстонии

## Понятия
URL: https://www.opiq.ee/kit/19/chapter/898
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.6
Topics ET: matemaatika
Topics RU: математика, понятия
Topics EN: mathematics
Headings: Понятия

## Толкования слов
URL: https://www.opiq.ee/kit/19/chapter/21018
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.7
Topics ET: matemaatika
Topics RU: математика, толкования, слов
Topics EN: mathematics
Headings: Толкования слов

## Импрессум
URL: https://www.opiq.ee/kit/19/chapter/903
Book: Природа и деятель­ность человека
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 7k__geograafia_avita_rus
Chapter ID: 6.8
Topics ET: matemaatika
Topics RU: математика, импрессум
Topics EN: mathematics
Headings: Импрессум

## Geograafia 7. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/96
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 1
Topics ET: matemaatika, geograafia, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Geograafia 7. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/96
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 38
Topics ET: matemaatika, geograafia, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Mis on geograafia?
URL: https://www.opiq.ee/kit/96/chapter/4655
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 1.1
Topics ET: matemaatika, geograafia, kreeka, seos, teiste, õppeainetega, millega, tegeleb, kuidas, õppida
Topics RU: математика
Topics EN: mathematics
Headings: Mis on geograafia?; Kreeka; Seos teiste õppeainetega; Millega tegeleb geograafia?; Kuidas õppida geograafiat?; Üldgeograafiline kaart; Riikide kaart

## Kaart on alati vajalik
URL: https://www.opiq.ee/kit/96/chapter/4656
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.1
Topics ET: matemaatika, kaart, alati, vajalik, mõisted, elukutsed, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Kaart on alati vajalik; Mõisted; Elukutsed; Küsimused

## Maa kuju ja suurus. Kaart ja plaan
URL: https://www.opiq.ee/kit/96/chapter/4657
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.2
Topics ET: matemaatika, kuju, suurus, kaart, plaan, korteri, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Maa kuju ja suurus. Kaart ja plaan; Maa; Kaart; Plaan; Korteri plaan; Plaan ja kaart; Küsimused

## Mõõtkava, vahemaade mõõtmine looduses ja kaardil
URL: https://www.opiq.ee/kit/96/chapter/4658
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.3
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, mõõtkava, vahemaade, looduses, kaardil, mõõtkavad, varstu, kaartide, jaotus
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mõõtkava, vahemaade mõõtmine looduses ja kaardil; Mõõtkavad; Varstu; Kaartide jaotus mõõtkava järgi; Erineva mõõtkavaga kaardid; Väikese- ja suure­mõõt­kavaline kaart; Mõõtkava; Küsimused

## Kaartide mitmekesisus ja otstarve
URL: https://www.opiq.ee/kit/96/chapter/4659
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.4
Topics ET: matemaatika, kaartide, mitmekesisus, otstarve, üldgeograafilised, teema, kaardid, eesti, kaguosa, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kaartide mitmekesisus ja otstarve; Üldgeograafilised ja teema­kaardid; Eesti kaguosa kaart; Leppemärgid, kaardi üldistamine; Samakõrgusjooned; Atlas; Küsimused

## Trüki- ja arvutikaardid
URL: https://www.opiq.ee/kit/96/chapter/4660
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.5
Topics ET: matemaatika, trüki, arvutikaardid, geoinfosüsteemid, rakendusi, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Trüki- ja arvutikaardid; Geoinfosüsteemid; GIS-i rakendusi; GPS; Küsimused

## Suundade määramine looduses ja kaardil
URL: https://www.opiq.ee/kit/96/chapter/4661
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.6
Topics ET: loodusõpetus, suundade, määramine, looduses, kaardil, asimuudi, ringmalli, kasutamine, ilmakaared, loodusmärgid
Topics RU: природоведение
Topics EN: science
Headings: Suundade määramine looduses ja kaardil; Asimuudi määramine; Ringmalli kasutamine; Ilmakaared ja loodusmärgid; Suundade määramine; Küsimused

## Asukoha määramine ja geograafilised koordinaadid
URL: https://www.opiq.ee/kit/96/chapter/4662
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.7
Topics ET: matemaatika, asukoha, määramine, geograafilised, koordinaadid, põhitõed, meridiaanid, paralleelid, metsa, eksinud
Topics RU: математика
Topics EN: mathematics
Headings: Asukoha määramine ja geograafilised koordinaadid; Põhitõed; Meridiaanid ja paralleelid; Geograafilised koordinaadid; Metsa eksinud; Kraadid, minutid, sekundid; Küsimused

## Ajavööndid
URL: https://www.opiq.ee/kit/96/chapter/4663
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.8
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, aeg, kell, kalender, ajavööndid, maailma, linnades, päeva, laiustel, küsimused
Topics RU: математика, измерение, единица измерения, длина, масса, объём, время, часы, календарь
Topics EN: mathematics, measurement, unit, length, mass, volume, time, clock, calendar
Headings: Ajavööndid; Aeg; Ajavööndid 1; Ajavööndid 2; Ajavööndid 3; Aeg maailma linnades; Päeva ja öö pikkus; Päeva ja öö pikkus ei laiustel; Küsimused

## Kokkuvõte kaardiõpetuse kordamiseks
URL: https://www.opiq.ee/kit/96/chapter/4664
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 2.9
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kokkuvõte, kaardiõpetuse, kordamiseks, ülevaade, mõisted, oskused, riikide, kaart, kordamisülesanded
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Kokkuvõte kaardiõpetuse kordamiseks; Ülevaade; Mõisted; Oskused; Riikide kaart; Kordamisülesanded; Kaardi lugemine; Maad iseloomustavad arvud; Mõisted 1; Mõisted 2

## Rahvastik ja seda iseloomustavad andmed
URL: https://www.opiq.ee/kit/96/chapter/4665
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.1
Topics ET: matemaatika, rahvastik, seda, iseloomustavad, andmed, piltidelt, info, kogumine, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Rahvastik ja seda iseloomustavad andmed; Piltidelt info kogumine; Küsimused

## Riigid maailma kaardil
URL: https://www.opiq.ee/kit/96/chapter/4666
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.2
Topics ET: matemaatika, riigid, maailma, kaardil, mandrid, maailmajaod, maailmajagude, saared, anglo, ladina
Topics RU: математика
Topics EN: mathematics
Headings: Riigid maailma kaardil; Mandrid ja maailmajaod; Maailmajagude saared; Riigid; Anglo- ja Ladina-Ameerika riigid; Poliitiline kaart; Mis riikidega on tegemist?; Näidis geograafilise asendi iseloomusta­miseks; Läti geograafiline asend; Küsimused

## Maailma rahvaarv ja selle muutumine
URL: https://www.opiq.ee/kit/96/chapter/4667
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.3
Topics ET: matemaatika, maailma, rahvaarv, selle, muutumine, millal, täitus, järgmine, miljard, iive
Topics RU: математика
Topics EN: mathematics
Headings: Maailma rahvaarv ja selle muutumine; Millal täitus järgmine miljard?; IIve; Sündimus, suremus ja iive; Muutused maailma rahvaarvus; Rahvastikupüramiid; Maailma rahvaarvu muutumine; Euroopa ja Aafrika rahvastik; Ränne; Ränne ja selle liigid; Küsimused

## Rassid ja rahvused
URL: https://www.opiq.ee/kit/96/chapter/4668
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.4
Topics ET: matemaatika, rassid, rahvused, segarassid, rasside, tunnused, oled, roomas, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Rassid ja rahvused; Segarassid; Rasside tunnused; Rassid; Rahvused; Kui oled Roomas...; Küsimused

## Rahvastiku paiknemine ja tihedus
URL: https://www.opiq.ee/kit/96/chapter/4669
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.5
Topics ET: matemaatika, rahvastiku, paiknemine, tihedus, asustus, ajaloos, loodusobjektid, riikide, järjestamine, hõre
Topics RU: математика
Topics EN: mathematics
Headings: Rahvastiku paiknemine ja tihedus; Rahvastiku paiknemine; Asustus ajaloos; Loodusobjektid ja rahvastiku paiknemine; Rahvastiku tihedus; Riikide järjestamine; Hõre ja tihe asustus; Küsimused

## Linnad ja linnastumine
URL: https://www.opiq.ee/kit/96/chapter/4670
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.6
Topics ET: matemaatika, linnad, linnastumine, london, arengumaa, arenenud, linnastud, lõuna, ameerika, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Linnad ja linnastumine; London; Linnastumine; Arengumaa või arenenud maa; Linnastud; Lõuna-Ameerika linnad; Küsimused

## Kokkuvõte rahvastiku kordamiseks
URL: https://www.opiq.ee/kit/96/chapter/4671
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.7
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kokkuvõte, rahvastiku, kordamiseks, ülevaade, mõisted, oskused, tunne, kaarti, kordamisülesanded
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Kokkuvõte rahvastiku kordamiseks; Ülevaade; Mõisted; Oskused; Tunne kaarti; Kordamisülesanded; Ühenda arvud õige teabega; Märksõnad

## Juhendid
URL: https://www.opiq.ee/kit/96/chapter/4672
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.8
Topics ET: matemaatika, juhendid, sammupaari, pikkuse, määramine, teadsid, kompassi, kasutamine, kaardi, järgi
Topics RU: математика
Topics EN: mathematics
Headings: Juhendid; Sammupaari pikkuse määramine; Kas teadsid?; Kompassi kasutamine; Kaardi järgi orienteerumine; Lihtsa plaani koostamine; Interaktiivse kaardi kasutamine; Tabelite lugemine ja koostamine; Diagrammide lugemine ja koostamine; Rahvastikupüramiidi lugemine

## Tabelid
URL: https://www.opiq.ee/kit/96/chapter/4673
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 3.9
Topics ET: matemaatika, tabelid, maailma, riigid, suurema, elanike, arvuga, linnad, linnastud
Topics RU: математика
Topics EN: mathematics
Headings: Tabelid; Maailma riigid 2009; Maailma suurema elanike arvuga linnad; Maailma suurema elanike arvuga linnastud, 2008

## Maa siseehitus ja maakoor
URL: https://www.opiq.ee/kit/96/chapter/4674
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 4.1
Topics ET: matemaatika, siseehitus, maakoor, siseehituse, uurimine, paljandi, maakoore, kihid, temperatuur, sisemuses
Topics RU: математика
Topics EN: mathematics
Headings: Maa siseehitus ja maakoor; Maa siseehituse uurimine; Paljandi uurimine; Maa siseehitus; Maakoore kihid; Maakoor; Temperatuur Maa sisemuses; Küsimused

## Laamad ja nende liikumine
URL: https://www.opiq.ee/kit/96/chapter/4675
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 4.2
Topics ET: matemaatika, laamad, nende, liikumine, pangaea, maakoor, jaguneb, laamadeks, laamade, islandi
Topics RU: математика
Topics EN: mathematics
Headings: Laamad ja nende liikumine; Pangaea; Maakoor jaguneb laamadeks; Laamade liikumine; Islandi teke; Maailma laamad; Küsimused; Geograafilised kohad

## Maavärinad
URL: https://www.opiq.ee/kit/96/chapter/4676
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 4.3
Topics ET: matemaatika, maavärinad, maavärinate, osmussaare, maavärin, tsunamid, maavärinaid, lähiajaloos, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Maavärinad; Maavärinate oht; Osmussaare maavärin; Tsunamid; Maavärinaid lähiajaloos; Küsimused

## Vulkaanid
URL: https://www.opiq.ee/kit/96/chapter/4677
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 4.4
Topics ET: matemaatika, vulkaanid, vulkaani, ehitus, mauna, vulkaanipurse, kustunud, tegevvulkaanid, vulkaanide, paiknemine
Topics RU: математика
Topics EN: mathematics
Headings: Vulkaanid; Vulkaani ehitus; Mauna Kea; Vulkaanipurse; Kustunud ja tegevvulkaanid; Vulkaanide paiknemine; Maailma vulkaanid; Kuumaveeallikad ja geisrid; Küsimused

## Kivimid ja nende teke
URL: https://www.opiq.ee/kit/96/chapter/4678
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 4.5
Topics ET: matemaatika, kivimid, nende, teke, kivimi, mõiste, graniidi, koostis, tardkivimid, settekivimid
Topics RU: математика
Topics EN: mathematics
Headings: Kivimid ja nende teke; Kivimi mõiste; Graniidi koostis; Tardkivimid; Settekivimid; Pankrannik; Murenemine; Moondekivimid; Küsimused; Kivimite kasutamine

## Inimeste elu maavärinate ja vulkaanide aladel
URL: https://www.opiq.ee/kit/96/chapter/4679
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 4.6
Topics ET: matemaatika, inimeste, maavärinate, vulkaanide, aladel, maavärinaohtlikel, maavärina, ohtlikkus, kuidas, käituda
Topics RU: математика
Topics EN: mathematics
Headings: Inimeste elu maavärinate ja vulkaanide aladel; Elu maavärinaohtlikel aladel; Maavärina ohtlikkus; Kuidas käituda maavärina ja tsunami korral; Elu vulkaanilistel aladel; Küsimused

## Kokkuvõte geoloogia kordamiseks
URL: https://www.opiq.ee/kit/96/chapter/4680
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 4.7
Topics ET: matemaatika, kokkuvõte, geoloogia, kordamiseks, ülevaade, mõisted, oskused, tunne, kaarti, kordamisülesanded
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte geoloogia kordamiseks; Ülevaade; Mõisted; Oskused; Tunne kaarti; Kordamisülesanded; Tõene või väär; Ristsõna

## Pinnamood ja pinnavormid. Ookeaninõod ja mandrid
URL: https://www.opiq.ee/kit/96/chapter/4681
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.1
Topics ET: matemaatika, pinnamood, pinnavormid, ookeaninõod, mandrid, suured, ookeanide, piirid, pinnavormide, suurus
Topics RU: математика
Topics EN: mathematics
Headings: Pinnamood ja pinnavormid. Ookeaninõod ja mandrid; Ookeaninõod ja mandrid; Suured pinnavormid; Ookeanide piirid; Pinnavormide suurus; Küsimused

## Pinnamoe kujutamine kaardil
URL: https://www.opiq.ee/kit/96/chapter/4682
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.2
Topics ET: matemaatika, lahutamine, lahuta, vahe, pinnamoe, kujutamine, kaardil, kõrgus, sügavus, kõrgused, sügavused, samakõrgusjoonte
Topics RU: математика, вычитание, вычти, разность
Topics EN: mathematics, subtraction, subtract, difference
Headings: Pinnamoe kujutamine kaardil; Kõrgus ja sügavus; Kõrgused ja sügavused kaardil; Samakõrgusjoonte vahe; Absoluutne ja suhteline; Profiiljoon; Küsimused

## Maailmamere põhja pinnamood
URL: https://www.opiq.ee/kit/96/chapter/4683
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.3
Topics ET: matemaatika, maailmamere, põhja, pinnamood, merepõhja, uurimine, titanicu, vrakk, ookeanipõhi, veealused
Topics RU: математика
Topics EN: mathematics
Headings: Maailmamere põhja pinnamood; Merepõhja uurimine; Titanicu vrakk; Ookeanipõhi; Veealused uurimistööd; Mariaani süviku uurimine; Uppunud sõjalaev; Küsimused

## Tasandikud
URL: https://www.opiq.ee/kit/96/chapter/4684
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.4
Topics ET: matemaatika, tasandikud, euroopa, lauskmaa, tasandike, liigitamine, surnumeri, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Tasandikud; Ida-Euroopa lauskmaa; Tasandike liigitamine; Surnumeri; Küsimused

## Mäestikud ja mägismaad
URL: https://www.opiq.ee/kit/96/chapter/4685
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.5
Topics ET: matemaatika, mäestikud, mägismaad, mägi, mäeahelik, mäestik, lõuna, ameerika, läbilõige, pinnavorm
Topics RU: математика
Topics EN: mathematics
Headings: Mäestikud ja mägismaad; Mägi, mäeahelik, mäestik; Lõuna-Ameerika läbilõige; Mis pinnavorm?; Küsimused

## Inimeste elu erineva pinnamoega aladel
URL: https://www.opiq.ee/kit/96/chapter/4686
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.6
Topics ET: matemaatika, inimeste, erineva, pinnamoega, aladel, tegevusalad, pinnamood, inimese, mõju, pinnamoele
Topics RU: математика
Topics EN: mathematics
Headings: Inimeste elu erineva pinnamoega aladel; Tegevusalad ja pinnamood; Inimese mõju pinnamoele; Pinnamoe muutmine; Küsimused

## Pinnamoe muutumine aja jooksul
URL: https://www.opiq.ee/kit/96/chapter/4687
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.7
Topics ET: matemaatika, pinnamoe, muutumine, jooksul, kulumine, kuhjumine, põhjavee, mõju, karst, maalihked
Topics RU: математика
Topics EN: mathematics
Headings: Pinnamoe muutumine aja jooksul; Kulumine ja kuhjumine; Põhjavee mõju; Karst; Maalihked; Jää mõju; Tuule mõju; Küsimused

## Kokkuvõte pinnamoe kordamiseks
URL: https://www.opiq.ee/kit/96/chapter/4688
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.8
Topics ET: matemaatika, kokkuvõte, pinnamoe, kordamiseks, ülevaade, mõisted, oskused, tunne, kaarti, kordamisülesanded
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte pinnamoe kordamiseks; Ülevaade; Mõisted; Oskused; Tunne kaarti; Kordamisülesanded; Väited pinnamoest; Inimtekkelised pinnavormid; Maailma suured pinnavormid; Maailma kõrgeim mägi

## Juhendid
URL: https://www.opiq.ee/kit/96/chapter/4689
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 5.9
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, taim, taimed, puu, lill, juhendid, paljandi, kirjeldamine, geoloogilise, objekti, sündmuse, teabeallikate, abil, esitluse
Topics RU: математика, измерение, единица измерения, длина, масса, объём, растение, растения, дерево, цветок
Topics EN: mathematics, measurement, unit, length, mass, volume, plant, plants, tree, flower
Headings: Juhendid; Paljandi kirjeldamine; Geoloogilise objekti või sündmuse kirjeldamine teabeallikate abil (esitluse koostamine); Suhtelise kõrguse mõõtmine; Variant A; Variant B; Nõlva kaldenurga mõõtmine; Puu kõrguse mõõtmine

## Mõisted
URL: https://www.opiq.ee/kit/96/chapter/4690
Book: Geograafia 7. klassile – Opiq
Class: 7
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 7k__geograafia_koolibri_est
Chapter ID: 6.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## География 7 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/301
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 76
Topics ET: matemaatika, opiq
Topics RU: математика, география, класс
Topics EN: mathematics

## География 7 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/301
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 145
Topics ET: matemaatika, opiq
Topics RU: математика, география, класс
Topics EN: mathematics

## Что такое география?
URL: https://www.opiq.ee/kit/301/chapter/16602
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, такое, география, греция, занимается, изучать, географию, общегеографическая, карта, мира
Topics EN: mathematics
Headings: Что такое география?; Греция; Чем занимается география?; Как изучать географию?; Общегеографическая карта мира; Работа с картой; Карта стран мира

## Карта нужна всегда
URL: https://www.opiq.ee/kit/301/chapter/16603
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, карта, нужна, всегда, понятия, профессии, вопросы
Topics EN: mathematics
Headings: Карта нужна всегда; Понятия; Профессии; Вопросы

## Форма и размеры Земли. Карта и план
URL: https://www.opiq.ee/kit/301/chapter/16604
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, форма, размеры, земли, карта, план, земля, квартиры, вопросы
Topics EN: mathematics
Headings: Форма и размеры Земли. Карта и план; Земля; Карта и план; План и карта; План квартиры; Вопросы

## Масштаб, измерение расстояний на местности и по карте
URL: https://www.opiq.ee/kit/301/chapter/16605
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.3
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, масштаб, расстояний, местности, карте, пункт, интерактивной, карты, разного
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Масштаб, измерение расстояний на местности и по карте; Измерение расстояний; Масштаб; Пункт на интерактивной карте; Карты разного масштаба; Мелкомасштабная и крупномасштабная карты; Вопросы

## Разнообразие карт и их назначение
URL: https://www.opiq.ee/kit/301/chapter/16606
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, разнообразие, карт, назначение, общегеографическая, тематическая, карты, карта, восточной, части
Topics EN: mathematics
Headings: Разнообразие карт и их назначение; Общегеографическая и тематическая карты; Карта юго-восточной части Эстонии; Условные знаки, генерализация карт; Изогипса; Атлас; Вопросы

## Печатные и компьютерные карты
URL: https://www.opiq.ee/kit/301/chapter/16607
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, печатные, компьютерные, карты, геоинформационная, система, вопросы
Topics EN: mathematics
Headings: Печатные и компьютерные карты; Геоинформационная система; ​ГИС; GPS; Вопросы

## Ориентирова­ние на местности и по карте
URL: https://www.opiq.ee/kit/301/chapter/16608
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, ориентирова, местности, карте, определение, азимута, азимут, ориентирование, природным, признакам
Topics EN: mathematics
Headings: Ориентирова­ние на местности и по карте; Определение азимута; Азимут; Ориентирование на местности по природным признакам; Ориентирование; Вопросы

## Определение местонахожд­ения и географичес­кие координаты
URL: https://www.opiq.ee/kit/301/chapter/16609
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, определение, местонахожд, ения, географичес, координаты, основные, понятия, меридианы, параллели
Topics EN: mathematics
Headings: Определение местонахожд­ения и географичес­кие координаты; Основные понятия; Меридианы и параллели; Географические координаты; Без компаса и карты; Градусы, минуты, секунды; Крайние точки материковой Эстонии; Вопросы

## Часовые пояса
URL: https://www.opiq.ee/kit/301/chapter/16610
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.8
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, часовые, пояса, всемирное, поясное, местное, который, продолжительность, ночи
Topics EN: mathematics, time, clock, calendar
Headings: Часовые пояса; Всемирное, поясное и местное время; Который час?; Продолжительность дня и ночи; Вопросы

## Подведение итогов и повторение: Картография
URL: https://www.opiq.ee/kit/301/chapter/16611
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 2.9
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kordamine, korda, harjutan
Topics RU: математика, число, числа, цифры, повторение, повтори, тренировка, подведение, итогов, картография, понятия, умения, повторения
Topics EN: mathematics, number, numbers, digits, revision, review, practice
Headings: Подведение итогов и повторение: Картография; Повторение; Понятия; Умения; Задания для повторения; Числа, характеризующие Землю; Понятия I; Понятия II; Работа с картой

## Население и его характеристики
URL: https://www.opiq.ee/kit/301/chapter/16612
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, население, характеристики, вопросы
Topics EN: mathematics
Headings: Население и его характеристики; Население; Вопросы

## Страны на карте мира
URL: https://www.opiq.ee/kit/301/chapter/16613
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, страны, карте, мира, материки, вместе, островами, образуют, части, света
Topics EN: mathematics
Headings: Страны на карте мира; Материки вместе с островами образуют части света; Материки и части света; Государства; Государства Англо-Америки и Латинской Америки; Политическая карта; О каком государстве идет речь?; Пример характеристики географического положения; Географическое положение Латвии; Вопросы

## Численность населения Земли и ее динамика
URL: https://www.opiq.ee/kit/301/chapter/16614
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, численность, населения, земли, динамика, когда, население, достигнет, следующего, миллиарда
Topics EN: mathematics
Headings: Численность населения Земли и ее динамика; Когда население Земли достигнет следующего миллиарда?; Прирост населения; Изменение численности населения Земли; Рождаемость, смертность, прирост населения; Динамика численности населения Европы и Африки; Миграция; Миграция и ее типы; Вопросы

## Расы и национальности
URL: https://www.opiq.ee/kit/301/chapter/16615
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, расы, национальности, признаки, смешанные, расовый, состав, населения, бразилии, перу
Topics EN: mathematics
Headings: Расы и национальности; Признаки расы; Смешанные расы; Расовый состав населения Бразилии и Перу; Национальности; Умей себя вести в гостях; Вопросы

## Размещение и плотность населения
URL: https://www.opiq.ee/kit/301/chapter/16616
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, размещение, плотность, населения, регионы, высокой, плотностью, влияние, природных, объектов
Topics EN: mathematics
Headings: Размещение и плотность населения; Размещение населения; Регионы с высокой плотностью населения; Влияние природных объектов на размещение населения; Плотность населения; Численность населения и площадь территории; Регионы с высокой и низкой плотностью населения; Вопросы

## Города и урбанизация
URL: https://www.opiq.ee/kit/301/chapter/16617
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика, города, урбанизация, лондон, развитая, развивающаяся, страна, конурбации, население, городов
Topics EN: mathematics
Headings: Города и урбанизация; Лондон; Урбанизация; Развитая или развивающаяся страна?; Конурбации; Население городов Южной Америки; Вопросы

## Подведение итогов и повторение: Население
URL: https://www.opiq.ee/kit/301/chapter/16618
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.7
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kordamine, korda, harjutan
Topics RU: математика, число, числа, цифры, повторение, повтори, тренировка, подведение, итогов, население, понятия, умения, покажи, карте
Topics EN: mathematics, number, numbers, digits, revision, review, practice
Headings: Подведение итогов и повторение: Население; Повторение; Понятия; Умения; Покажи на карте; Задания для повторения; Соедини число и информацию; Население

## Руководства
URL: https://www.opiq.ee/kit/301/chapter/16619
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика, руководства, определять, длину, пары, шагов, пользоваться, компасом, ориентироваться, карте
Topics EN: mathematics
Headings: Руководства; Как определять длину пары шагов; Как пользоваться компасом; Как ориентироваться по карте; Как составлять простой план; Как пользоваться интерактивной картой; Как читать и составлять таблицы; Как читать и составлять диаграммы; Как читать пирамиду населения

## Таблицы
URL: https://www.opiq.ee/kit/301/chapter/16620
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 3.9
Topics ET: matemaatika
Topics RU: математика, таблицы, крупнейшие, города, мира, конурбации, страны
Topics EN: mathematics
Headings: Таблицы; Крупнейшие города мира; Крупнейшие конурбации мира, 2008; Страны мира, 2009

## Внутреннее строение Земли. Земная кора
URL: https://www.opiq.ee/kit/301/chapter/16621
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, внутреннее, строение, земли, земная, кора, изучение, внутреннего, строения, обнажений
Topics EN: mathematics
Headings: Внутреннее строение Земли. Земная кора; Изучение внутреннего строения Земли; Изучение обнажений; Внутреннее строение Земли; Строение земной коры; Земная кора; Температура в недрах Земли; Вопросы

## Литосферные плиты и их движение
URL: https://www.opiq.ee/kit/301/chapter/16622
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, литосферные, плиты, движение, пангея, тектоника, литосферных, плит, образование, острова
Topics EN: mathematics
Headings: Литосферные плиты и их движение; Пангея; Литосферные плиты; Тектоника литосферных плит; Образование острова Исландия; Вопросы; Географические объекты

## Землетрясения
URL: https://www.opiq.ee/kit/301/chapter/16623
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, землетрясения, землетрясение, опасность, землетрясений, осмуссаареское, цунами, недавнего, времени, вопросы
Topics EN: mathematics
Headings: Землетрясения; Землетрясение; Опасность землетрясений; Осмуссаареское землетрясение; Цунами; Землетрясения недавнего времени; Вопросы

## Вулканы
URL: https://www.opiq.ee/kit/301/chapter/16624
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, вулканы, строение, вулкана, мауна, извержение, действующие, потухшие, расположение, вулканов
Topics EN: mathematics
Headings: Вулканы; Строение вулкана; Мауна-Кеа; Извержение вулкана; Действующие и потухшие вулканы; Расположение вулканов; Вулканы на Земле; Гейзеры и горячие источники; Вопросы

## Горные породы и их образование
URL: https://www.opiq.ee/kit/301/chapter/16625
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, горные, породы, образование, такое, горная, порода, состав, гранита, изверженные
Topics EN: mathematics
Headings: Горные породы и их образование; Что такое горная порода?; Состав гранита; Изверженные горные породы; Осадочные горные породы; Обрывистый берег; Выветривание; Метаморфические горные породы; Вопросы; Использование горных пород

## Жизнь людей в регионах вулканических извержений и землетрясений
URL: https://www.opiq.ee/kit/301/chapter/16626
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 4.6
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, жизнь, людей, регионах, вулканических, извержений, землетрясений, опасность, вести, себя
Topics EN: mathematics, time, clock, calendar
Headings: Жизнь людей в регионах вулканических извержений и землетрясений; Жизнь в регионах землетрясений; Опасность землетрясений; Как вести себя во время землетрясения и цунами; Жизнь в регионах вулканической деятельности; Вопросы

## Подведение итогов и повторение: Геология
URL: https://www.opiq.ee/kit/301/chapter/16627
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 4.7
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка, подведение, итогов, геология, понятия, умения, знай, карту
Topics EN: mathematics, revision, review, practice
Headings: Подведение итогов и повторение: Геология; Повторение; Понятия; Умения; Знай карту; Задания для повторения; Верно или нет?; Кроссворд

## Рельеф и формы рельефа. Океанические впадины и материки
URL: https://www.opiq.ee/kit/301/chapter/16628
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, рельеф, формы, рельефа, океанические, впадины, материки, крупные, границы, океанов
Topics EN: mathematics
Headings: Рельеф и формы рельефа. Океанические впадины и материки; Океанические впадины и материки; Крупные формы рельефа; Границы океанов; Размеры форм рельефа; Вопросы

## Изображение рельефа на карте
URL: https://www.opiq.ee/kit/301/chapter/16629
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, изображение, рельефа, карте, высота, глубина, высоты, глубины, разница, между
Topics EN: mathematics
Headings: Изображение рельефа на карте; Высота и глубина; Высоты и глубины на карте; Разница между изогипсами; Абсолютное и относительное; Профиль рельефа; Профиль; Вопросы

## Рельеф дна Мирового океана
URL: https://www.opiq.ee/kit/301/chapter/16630
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, рельеф, мирового, океана, исследование, морского, останки, титаника, вопросы
Topics EN: mathematics
Headings: Рельеф дна Мирового океана; Исследование морского дна; Останки «Титаника»; Дно океана; Вопросы

## Равнины
URL: https://www.opiq.ee/kit/301/chapter/16631
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, равнины, восточно, европейская, равнина, виды, равнин, мертвое, море, вопросы
Topics EN: mathematics
Headings: Равнины; Восточно-Европейская равнина; Виды равнин; Мертвое море; Вопросы

## Горы и нагорья
URL: https://www.opiq.ee/kit/301/chapter/16632
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.5
Topics ET: matemaatika
Topics RU: математика, горы, нагорья, гора, горная, цепь, система, рельеф, южной, америки
Topics EN: mathematics
Headings: Горы и нагорья; Гора, горная цепь, горная система; Рельеф Южной Америки; Формы рельефа; Вопросы

## Жизнь людей в регионах с разным рельефом
URL: https://www.opiq.ee/kit/301/chapter/16633
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.6
Topics ET: matemaatika
Topics RU: математика, жизнь, людей, регионах, разным, рельефом, рельеф, деятельность, человека, влияние
Topics EN: mathematics
Headings: Жизнь людей в регионах с разным рельефом; Рельеф и деятельность человека; Влияние человека на рельеф; Изменение рельефа; Вопросы

## Изменение рельефа с течением времени
URL: https://www.opiq.ee/kit/301/chapter/16634
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.7
Topics ET: matemaatika
Topics RU: математика, изменение, рельефа, течением, времени, аккумулятивные, денудационные, формы, воздействие, грунтовых
Topics EN: mathematics
Headings: Изменение рельефа с течением времени; Аккумулятивные и денудационные формы рельефа; Воздействие грунтовых вод; Карст; Оползни; Воздействие льда; Воздействие ветра; Вопросы

## Подведение итогов и повторение: Рельеф
URL: https://www.opiq.ee/kit/301/chapter/16635
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.8
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка, подведение, итогов, рельеф, понятия, умения, знай, карту
Topics EN: mathematics, revision, review, practice
Headings: Подведение итогов и повторение: Рельеф; Повторение; Понятия; Умения; Знай карту; Задания для повторения; Правильно или нет?; Формы рельефа, созданные человеком; Крупные формы рельефа; Высочайшая гора планеты

## Руководства
URL: https://www.opiq.ee/kit/301/chapter/30119
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 5.9
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, руководства, описание, геологических, обнажений, геологического, объекта, события, использованием, источников
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Руководства; Описание геологических обнажений; Описание геологического объекта или события с использованием источников информации (подготовка презентации); Измерение относительной высоты; Измерение угла наклона склона; Измерение высоты дерева

## Карты
URL: https://www.opiq.ee/kit/301/chapter/16636
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, карты, общегеографическая, карта, мира, стран, государства, европы
Topics EN: mathematics
Headings: Карты; Общегеографическая карта мира; Карта стран мира; Государства Европы

## Словарь терминов
URL: https://www.opiq.ee/kit/301/chapter/16637
Book: Что такое география?
Class: 7
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 7k__geograafia_koolibri_rus
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, словарь, терминов
Topics EN: mathematics
Headings: Словарь терминов

## Loodus­geograafia 7. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/2
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 144
Topics ET: loodusõpetus, loodus, keskkond, geograafia, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodus ja inimtegevus
URL: https://www.opiq.ee/kit/2/chapter/33
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 1.1
Topics ET: loodusõpetus, loodus, keskkond, inimtegevus, millega, tegelevad, geograafid, tänapäeval, kuulu, inimgeograafi, ülesannete
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Loodus ja inimtegevus; Millega tegelevad geograafid tänapäeval?; Mis ei kuulu inimgeograafi ülesannete hulka?; Mida uurib geograafia; Kuidas kujutatakse geograafia uurimistulemusi?; Mis ei kuulu loodusgeograafi ülesannete hulka?; Kuidas tehakse geograafilisi uuringuid?; Mõtle; Milleks kasutatakse satelliidipilte?; Kuidas jaotuvad Maal mandrid, maailmajaod ja ookeanid?; Milline neist ei ole maailmajagu?; Millise mandri rannikut uhuvad nelja ookeani veed?; Mandrid ja maailmajaod

## Maa kuju ja suurus
URL: https://www.opiq.ee/kit/2/chapter/34
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.1
Topics ET: loodusõpetus, liitmine, liida, summa, kokku, korrutamine, korruta, korrutis, korda, kordamine, harjutan, kuju, suurus, milline, ettekujutus, maast, kauges, minevikus, andis, lõpuks
Topics RU: природоведение, сложение, сложи, сумма, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: science, addition, add, sum, multiplication, multiply, product, revision, review, practice
Headings: Maa kuju ja suurus; Milline oli ettekujutus Maast kauges minevikus?; Mis andis lõpuks kinnituse, et maakera on kerakujuline?; Miks ei näe me silmapiiri taha jäävaid objekte?; Mõtle; Millised nägid välja esimesed kaardid?; Vaata Ptolemaiose kaardilt, milliseid maailmajagusid tundsid muistsed kreeklased?; Kust said vanaaja geograafid teadmisi kaugete maade kohta?; Kuidas avardus inimeste ettekujutus Maast?; Millised maakera piirkonnad avastati viimasena; Kelle juhtimisel purjetati esimest korda ümber maakera ja tõestati, et see on ümmargune?; Millised riigid olid suurimad koloniaalimpeeriumite asutajad?; Kui suur on maakera?; Miks on vaja teada Maa mõõtmeid?; Miks on Maa poolustelt kokku surutud?; Kui suur on ligikaudu Maa ümbermõõt?

## Kaartide mitmekesisus
URL: https://www.opiq.ee/kit/2/chapter/35
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.2
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, kaartide, mitmekesisus, milleks, kaarte, vaja, kaardiatlas, mõtle, milliseid, olemas
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Kaartide mitmekesisus; Milleks on kaarte vaja?; Mis on kaardiatlas?; Mõtle; Milliseid kaarte on olemas?; Kuidas nimetatakse Eesti kõige olulisemat topograafilist kaarti?; Mille poolest erineb teemakaart üldgeograafilisest kaardist?; Mille poolest erinevad kaardid satelliidipildist või aerofotost?; Võrdle kaarti ja aerofotot.; Mis on aerofoto?; Milleks on kaardil leppemärgid?; Mida kujutatakse kaardil joonleppemärkidega?; Milleks on vajalik kaardi legend?; Lisamaterjal. Eesti põhikaart; Mille järgi leiad kaardilt soo?; Kui kõrge on kõrgeim koht toodud põhikaardi lehel?; Kui kõrge on Saadjärve keskmine veetase?; Kui kõrgel asub kultuskivi Kalevipoja lingukivi; Mõisted

## Arvutikaardid
URL: https://www.opiq.ee/kit/2/chapter/36
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.3
Topics ET: loodusõpetus, arvutikaardid, mida, kujutavad, endast, mõtle, miks, jaotatakse, teemad, arvutikaardil
Topics RU: природоведение
Topics EN: science
Headings: Arvutikaardid; Mida kujutavad endast arvutikaardid?; Mõtle; Miks jaotatakse teemad arvutikaardil eri kihtidele?; Milleks kasutatakse kaardisirvijaid?; Mida tähendab GIS?; Milleks GIS-i kasutatakse?; Mis on interaktiivne kaart?; Millised omadused on interaktiivsetel kaartidel?; Mis on trükikaardi eelised?; Mis on arvutikaardi eelised paberkaardi ees?; Mõisted

## Mõõtkava ja vahemaade mõõtmine
URL: https://www.opiq.ee/kit/2/chapter/37
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.4
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, mõõtkava, vahemaade, mida, näitab, kaardi, arvmõõtkava, parempoolne, miks
Topics RU: природоведение, число, числа, цифры, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём
Topics EN: science, number, numbers, digits, comparison, compare, greater, less, measurement, unit, length, mass, volume
Headings: Mõõtkava ja vahemaade mõõtmine; Mida näitab kaardi mõõtkava?; Mida näitab arvmõõtkava parempoolne arv?; Miks on kaardile vaja märkida mõõtkava?; Kuidas jaotatakse kaarte mõõtkava alusel?; Millise mõõtkavaga paberkaarti on kõige otstarbekam kasutada, kui tahaksid sõita Luualt Lähtele?; Millisele kaardile mahub kõige väiksem ala loodusest?; Mis kaardil on loodust kujutatud kõige üksikasjalikumalt?; Mida tähendab kaardi üldistamine?; Kaardi üldistamine; Miks on vaja kaarti üldistada?; Millist kaarti on vaja kõige enam üldistada?; Mõisted

## Suunad looduses ja kaardil
URL: https://www.opiq.ee/kit/2/chapter/38
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.5
Topics ET: loodusõpetus, suunad, looduses, kaardil, kuidas, määrata, suunda, mille, järgi, saab
Topics RU: природоведение
Topics EN: science
Headings: Suunad looduses ja kaardil; Kuidas määrata suunda looduses?; Mille järgi saab looduses ilmakaari määrata?; Kuidas sa leiad öisest taevast üles Põhjanaela?; Mis on asimuut ja kuidas seda kompassiga määrata?; Missuguse asimuudi järgi tuleb purjetada, et jõuda Virtsust Ruhnu?; Mis ilmakaarde on suunatud kompassi magnetnõel?; Mis on asimuut?; Mida tähendab kaardi orienteerimine?; Mida tuleb teha, et kaarti ilmakaarte järgi orienteerida?; Mõtle; Mõisted

## Asukoha määramine. Geograafilised koordinaadid
URL: https://www.opiq.ee/kit/2/chapter/39
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.6
Topics ET: loodusõpetus, asukoha, määramine, geograafilised, koordinaadid, kuidas, määrata, asukohta, aadressi, järgi
Topics RU: природоведение
Topics EN: science
Headings: Asukoha määramine. Geograafilised koordinaadid; Kuidas määrata asukohta aadressi järgi?; Mõtle; Kuidas on jaguneb Eesti territoorium?; Kuidas määrata asukohta koordinaatide abil?; Kuidas määratakse geograafilist pikkust?; Millisteks osadeks jaotab ekvaator maakera?; Mille järgi jaotatakse maakera ida- ja läänepoolkeraks?; Mis on suurim väärtus...; Kuidas määratakse geograafilist laiust?; Kuidas aitab kaardivõrk suunda määrata?; Kust saab GPS-vastuvõtja info oma asukohast?; Mis on kaardivõrk?; Mõisted

## Ajavööndid
URL: https://www.opiq.ee/kit/2/chapter/40
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.7
Topics ET: loodusõpetus, aeg, kell, kalender, ajavööndid, kohalik, päikeseaeg, kuidas, muutub, eestis, liikuda, mööda, meridiaani
Topics RU: природоведение, время, часы, календарь
Topics EN: science, time, clock, calendar
Headings: Ajavööndid; Mis on kohalik päikeseaeg?; Kuidas muutub Eestis kohalik päikeseaeg, kui liikuda mööda 25° ip meridiaani põhjast lõunasse?; Mõtle; Mis on ajavööndid?; Millistes riikides on kasutusel mitu vööndiaega?; Kui palju erineb Ida-Euroopa aeg maailmaajast?; Mis suunas peaksid liikuma, et jõuda alanud päeva hommikust kiiremini sama päeva õhtusse?; Milliselt meridiaanilt algab uus päev?; Miks läks Magalhãesi ümbermaailmareisi laevapäevikust üks päev kaduma?; Miks ei kulge kuupäevaraja mööda meridiaani?; Miks on reisides vaja kella keerata?; Kuidas peab reisides kella keerama?; Miks kasutatakse suve- ja talveaega?; Kellaaeg Venemaal; Kuidas erineb talveaeg suveajast?; Kella keeramine; Mõisted

## Kordamine. Kaardiõpetus
URL: https://www.opiq.ee/kit/2/chapter/41
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 2.8
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, kaardiõpetus, kuju, suurus, märgi, tegu, mandri, maailmajao, mõlemaga
Topics RU: природоведение, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка
Topics EN: science, comparison, compare, greater, less, measurement, unit, length, mass, volume, revision, review, practice
Headings: Kordamine. Kaardiõpetus; 2.1. Maa kuju ja suurus; Märgi, kas tegu on mandri, maailmajao või mõlemaga.; Miks on vaja teada Maa mõõtmeid?; Maailmameri.; Milline on Maa kuju?; 2.2. Kaartide mitmekesisus; Kaarditüübid; Võrdle kaarti ja aerofotot.; Mis on kaart?; Kuidas nimetatakse Eesti kõige olulisemat topograafilist kaarti?; 2.3. Arvutikaardid; Milleks GIS-i kasutatakse?; Millised omadused on interaktiivsetel kaartidel?; Miks jaotatakse teemad arvutikaardil eri kihtidele?; 2.4. Mõõtkava ja vahemaade mõõtmine; Millist kaarti on vaja kõige vähem üldistada?; Mis kaardil on loodust kujutatud kõige detailsemalt?; Mis mõõtkavaga on tegu?; Märgi, millise mõõtkavaga kaart on kõige üksikasjalikum.; Millisele kaardile mahub kõige suurem ala loodusest?; 2.5. Suunad looduses ja kaardil; Mis on asimuut?; Mille järgi saab looduses ilmakaari määrata?; 2.6. Asukoha määramine. Geograafilised koordinaadid; Mis on kaardivõrk?; Mille järgi jaotatakse maakera ida- ja läänepoolkeraks?; Mis on suurim väärtus...; Kuidas määratakse geograafilist laiust?; 2.7. Ajavööndid; Ajavööndid; Kuidas erineb talveaeg suveajast?; Kuidas muutub Eestis kohalik päikeseaeg, kui liikuda mööda 25° ip meridiaani põhjast lõunasse?; Milliste reisisuundade puhul jõuaksid käesoleva päeva õhtust kiiremini uue päeva hommikusse?; Mõisted; Ristsõna. Kaardiõpetus

## Maa siseehitus
URL: https://www.opiq.ee/kit/2/chapter/42
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 3.1
Topics ET: loodusõpetus, jagamine, jaga, jagatis, pool, siseehitus, sees, elemendid, tuumas, põhjustavad, magnetismi, sfäärid, mille, poolest
Topics RU: природоведение, деление, раздели, частное, половина
Topics EN: science, division, divide, quotient, half
Headings: Maa siseehitus; Mis on Maa sees?; Mis elemendid Maa tuumas põhjustavad magnetismi?; Maa sfäärid; Mille poolest erineb litosfäär maakoorest?; Kas maakoor on igal pool ühesugune?; Mis kivimitest koosneb mandriline maakoor?; Mille poolest erinevad mandriline ja ookeaniline maakoor?; Mõtle; Mõisted

## Laamad ja laamade liikumine
URL: https://www.opiq.ee/kit/2/chapter/43
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 3.2
Topics ET: loodusõpetus, laamad, laamade, liikumine, miks, maakoor, lõhenenud, millistel, laamadel, ainult
Topics RU: природоведение
Topics EN: science
Headings: Laamad ja laamade liikumine; Miks on maakoor lõhenenud?; Millistel laamadel on ainult ookeaniline maakoor?; Miks laamad liiguvad?; Millise maakoorega laamasid on olemas?; Millistel laamadel on nii mandrilist kui ka ookeanilist maakoort?; Mis juhtub, kui laamad teineteisest eemalduvad?; Millised protsessid esinevad laamade lahknemisvööndis?; Kus on maakoor rebenenud ja toimub laamade lahknemine?; Mis juhtub, kui laamad põrkuvad?; Kus on mandriline maakoor kõige paksem?; Miks sukeldub laamade põrkumisel ookeaniline laam mandrilise laama alla?; Mis on süvik?; Miks ei äärista Lõuna-Ameerika idarannikut mäestik nagu see on läänerannikul?; Kuidas võivad hiljem tekkinud maakoore kivimid sattuda varem tekkinud kivimite alla?; Mõtle; Laamade liikumine küljetsi; Milliseid protsesse esineb küljetsi liikuvate laamaservade piirkonnas?; Mis tüüpi on San Andrease murrang?; Mõisted

## Maavärinad
URL: https://www.opiq.ee/kit/2/chapter/44
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 3.3
Topics ET: loodusõpetus, maavärinad, miks, väriseb, võivad, tekkida, tsunamid, paneb, värisema, mille
Topics RU: природоведение
Topics EN: science
Headings: Maavärinad; Miks maa väriseb?; Kus võivad tekkida tsunamid?; Mis paneb Maa värisema?; Mille poolest erinevad seismilised lained merelainetest?; Kus esineb maavärinaid?; Mõtle; Kus võib esineda maavärinaid?; Kuidas mõõdetakse maavärina tugevust?; Richteri ja Mercalli skaala; Mõisted

## Vulkaanid
URL: https://www.opiq.ee/kit/2/chapter/45
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 3.4
Topics ET: loodusõpetus, vulkaanid, kuidas, tekivad, esineb, vulkaane, magma, laava, vaikset, ookeani
Topics RU: природоведение
Topics EN: science
Headings: Vulkaanid; Kuidas tekivad vulkaanid?; Kus esineb vulkaane?; Magma ja laava; Vaikset ookeani ümbritsevat rannikuvööndit nimetatakse sageli Vaikse ookeani tulerõngaks. Miks?; Mõtle; Kui sageli vulkaanid purskavad?; Millise vulkaaniga on tegu?; Miks on vulkaanid erinevad?; Kuidas on seotud vulkaanid ja kuumaveeallikad?; Miks on osade vulkaanide pursked enamasti plahvatuslikud?; Mõisted

## Inimeste elu ja majandus­tegevus seismilistes ja vulkaanilistes piirkondades
URL: https://www.opiq.ee/kit/2/chapter/46
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 3.5
Topics ET: loodusõpetus, inimeste, majandus, tegevus, seismilistes, vulkaanilistes, piirkondades, kuidas, varitsevate, ohtudega
Topics RU: природоведение
Topics EN: science
Headings: Inimeste elu ja majandus­tegevus seismilistes ja vulkaanilistes piirkondades; Kuidas varitsevate ohtudega silmitsi seista?; Milliste laamade kokkupuutevööndis paikneb Jaapan?; Milliste looduslike ohtudega tuleb Jaapani elanikel silmitsi seista; Miks elatakse vulkaanide lähedal?; Kuidas on elu vulkaanide lähedal inimestele kasulik?; Miks on vulkaanide jalamil viljakad mullad?; Kuidas toodetakse Islandil peamine osa küttesoojusest?

## Kivimid
URL: https://www.opiq.ee/kit/2/chapter/47
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 3.6
Topics ET: loodusõpetus, lahutamine, lahuta, vahe, kivimid, kuidas, tekkinud, tardkivimid, purskekivimid, süvakivimid, settekivimid, settel
Topics RU: природоведение, вычитание, вычти, разность
Topics EN: science, subtraction, subtract, difference
Headings: Kivimid; Kuidas on tekkinud tardkivimid?; Mis on purskekivimid?; Mis on süvakivimid?; Kuidas on tekkinud settekivimid?; Mis vahe on settel ja settekivimil?; Reasta setted suuruse järgi alustades väikseimast.; Kuidas on tekkinud fossiilsed kütused?; Kuidas on tekkinud moondekivimid?; Millest tekivad moondekivimid?; Millistes tingimustes tekib moondekivim?; Millised muutused toimuvad kivimite moondumisel?; Kas kivimid on igavesed?; Kivimite teke; Mõtle; Kuidas kivimeid kasutatakse?; Milliste kivimite sees leidub fossiilkütuseid?; Millise tööstusharu või tegevuse peamise tooraine pärineb kivimitest?; Lisamaterjal. Kivisse raiutud ajalooraamatud; Millise osariigi territooriumile jääb Suur kanjon?; Mis lahte suubub Colorado jõgi?; Mõisted

## Kordamine. Geoloogia
URL: https://www.opiq.ee/kit/2/chapter/48
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 3.7
Topics ET: loodusõpetus, lahutamine, lahuta, vahe, kordamine, korda, harjutan, geoloogia, siseehitus, kivimitest, koosneb, ookeaniline, maakoor, mille, poolest
Topics RU: природоведение, вычитание, вычти, разность, повторение, повтори, тренировка
Topics EN: science, subtraction, subtract, difference, revision, review, practice
Headings: Kordamine. Geoloogia; 3.1. Maa siseehitus; Mis kivimitest koosneb ookeaniline maakoor?; Mille poolest erinevad mandriline ja ookeaniline maakoor?; Maa sfäärid; Mille poolest erineb litosfäär maakoorest?; 3.2. Laamad ja laamade liikumine; Laamade lahknemine ja põrkumine; Millistel laamadel on nii mandrilist kui ka ookeanilist maakoort?; Millistel laamadel on ainult ookeaniline maakoor?; Kus on maakoor rebenenud ja toimub laamade lahknemine?; Miks laamad liiguvad?; Kus tekib maakoort juurde?; Kus on mandriline maakoor kõige paksem?; Millise maakoorega laamasid on olemas?; 3.3. Maavärinad; Millega mõõdetakse maavärina võimsust?; Kus esineb väga tugevaid maavärinaid?; Kus maapinnal on maakoore vappumine ja kõikumine kõige tugevam?; Kus on tsunami mõju kõige purustavam?; 3.4. Vulkaanid; Vali väited, mis iseloomustavad kilpvulkaane.; Mille poolest erinevad passiivne ja kustunud vulkaan?; Magma ja laava; Millise ookeani rannikul on kõige rohkem vulkaane?; 3.5. Inimeste elu ja majandus­tegevus seismilistes ja vulkaanilistes piirkondades; Milliseid abinõusid kasutatakse, et seismilistes ja vulkaanilistes piirkondades elamine oleks hõlpsam ja turvalisem?; Kuidas on elu vulkaanide lähedal inimestele kasulik?; 3.6. Kivimid; Süva- ja purskekivimid?; Kivimite teke; Mis vahe on settel ja settekivimil?; Mõisted; Ristsõna. Geoloogia

## Pinnavormid ja pinnamood
URL: https://www.opiq.ee/kit/2/chapter/49
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.1
Topics ET: loodusõpetus, pinnavormid, pinnamood, mille, poolest, erinevad, maakera, suurimad, reljeef, kuidas
Topics RU: природоведение
Topics EN: science
Headings: Pinnavormid ja pinnamood; Mis on pinnavormid ja mille poolest nad erinevad?; Mis on maakera suurimad pinnavormid?; Mis on reljeef?; Kuidas iseloomustada pinnamoodi?; Mõtle; Riikide pinnamood; Lisamaterjal. Austria pinnamood; Mõisted

## Pinnamoe kujutamine kaardil
URL: https://www.opiq.ee/kit/2/chapter/50
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.2
Topics ET: loodusõpetus, lahutamine, lahuta, vahe, pinnamoe, kujutamine, kaardil, samakõrgusjooned, mõtle, kuidas, kulgevad, kõrgusvahemikke, eristavad
Topics RU: природоведение, вычитание, вычти, разность
Topics EN: science, subtraction, subtract, difference
Headings: Pinnamoe kujutamine kaardil; Mis on samakõrgusjooned?; Mõtle; Kuidas kulgevad samakõrgusjooned kaardil, kus kõrgusvahemikke eristavad värvitoonid?; Kui suur on horisontaalide lõikevahe Eesti baaskaardil?; Kuidas kujutatakse samakõrgusjoontega järsku mäenõlva?; Eesti baaskaart; Mis on reljeefi varjutamine?; Milline reljeefi kujutamise viis annab pinnamoest täpseima ettekujutuse?; Mida näitab profiiljoon?; Hüpsograafilise kõvera järgi asub 2% maapinnast; Mida näitab pinnamoe profiilijoon?; Leia maakera hüpsograafiliselt kõveralt, kui suur osa Maa pinnast on maailmamere all.; Leia maakera hüpsograafiliselt kõveralt, kui suur osa maapinnast asub kõrgusvahemikus 4000m...–4000m.; Mis vahe on absoluutsel ja suhtelisel kõrgusel?; Leia põhikaardi lehelt, kumb järv asub kõrgemal absoluutkõrgusel.; Millist kõrgust näidatakse maakaartidel?; Leia põhikaardi lehelt, kui suur on suhteline kõrgus Saadjärve ja Allika talu vahel.; Mõisted

## Mäestikud ja mägismaad
URL: https://www.opiq.ee/kit/2/chapter/51
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.3
Topics ET: loodusõpetus, mäestikud, mägismaad, milliseid, pinnavorme, moodustavad, mäed, mille, poolest, erinevad
Topics RU: природоведение
Topics EN: science
Headings: Mäestikud ja mägismaad; Milliseid pinnavorme moodustavad mäed?; Mille poolest erinevad mäeahelik ja mägismaa?; Mis on mäestik?; Orud ja nõod ilmestavad pinnamoodi; Mille poolest erineb nõgu orust?; Millised Eesti veekogud asuvad orus?; Miks on mäestikud eriilmelised?; Miks on noorte ja vanade mäestike ilmed erinevad?; Mille poolest erineb noorte ja vanade mäestike välisilme?; Kuidas jaotatakse mäestikke kõrguse järgi?; Mis on Eestile lähim kõrgmäestik?; Inimtegevus mägise pinnamoega aladel; Märgi väited, mis iseloomustavad õigesti põllumajandustingimusi mägedes.; Lisamaterjal. Kuidas mäestikud kuluvad?; Millised riigid ei asu Ida-Euroopa lauskmaal?; Mõisted

## Tasandikud
URL: https://www.opiq.ee/kit/2/chapter/52
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.4
Topics ET: loodusõpetus, tasandikud, asuvad, merepinnast, erineval, kõrgusel, millest, sõltub, tasandike, ilme
Topics RU: природоведение
Topics EN: science
Headings: Tasandikud; Tasandikud asuvad merepinnast erineval kõrgusel; Millest sõltub tasandike ilme?; Mis on alamik?; Mille poolest erinevad mägismaa ja kiltmaa?; Missugusel mandril asuvad antud tasandikud?; Inimtegevus tasase pinnamoega aladel; Mõtle; Märgi väited, mis iseloomustavad õigesti elu- ja majandustingimusi tasandikel.; Mõisted

## Maailmamere põhjareljeef
URL: https://www.opiq.ee/kit/2/chapter/53
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.5
Topics ET: loodusõpetus, maailmamere, põhjareljeef, kuidas, piiritleda, mandreid, ookeaninõgusid, mille, poolest, erineb
Topics RU: природоведение
Topics EN: science
Headings: Maailmamere põhjareljeef; Kuidas piiritleda mandreid ja ookeaninõgusid?; Mille poolest erineb rannikumeri avamerest?; Miks ei ühti ookeaninõo piirid maailmamere piiridega?; Kus on mandrilise ja ookeanilise maakoore piir?; Milline on maailmamere põhjareljeef?; Kus paiknevad süvikud?; Millised neist saartest asuvad ookeani keskmäestiku kohal?; Mõisted

## Maa pinnamood muutub (1)
URL: https://www.opiq.ee/kit/2/chapter/54
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.6
Topics ET: loodusõpetus, pinnamood, muutub, maapind, kerkib, vajub, mõtle, miks, kaardipilt, lääne
Topics RU: природоведение
Topics EN: science
Headings: Maa pinnamood muutub (1); Maapind kerkib ja vajub; Mõtle; Miks on kaardipilt Lääne-Eesti rannikust viimastel sajanditel muutunud?; Miks maapind Läänemere piirkonnas kerkib?; Miks kivimid murenevad?; Miks on murenemine tähtis?; Millised tegurid mõjutavad murenemist?; Kuidas kulutab maapinda vihmavesi?; Millised inimtegevused kiirendavad erosiooni?; Mis on uhtorg?; Mõisted

## Maa pinnamood muutub (2)
URL: https://www.opiq.ee/kit/2/chapter/55
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.7
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, pinnamood, muutub, liustikud, kulutajad, kuhjajad, moreen, märgi, millised, väited
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Maa pinnamood muutub (2); Liustikud on kulutajad ja kuhjajad; Mis on moreen?; Märgi, millised väited kirjeldavad liustike teket.; Miks liustikke uuritakse?; Milliste alade pinnamoodi mõjutab tuul kõige rohkem?; Tuul pinnamoe kujundajana; Millise kliimaga alal on tuule pinnamoodi kujundav tegevus kõige mõjusam?; Milliseid pinnavorme loob inimene?; Mõtle; Kuidas on pinnavormid tekkinud?; Mis on Eesti suurimad tehismäed?

## Kordamine. Pinnamood
URL: https://www.opiq.ee/kit/2/chapter/56
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 4.8
Topics ET: loodusõpetus, kordamine, korda, harjutan, vesi, veeohutus, veekogu, pinnamood, pinnavormid, maakera, suurimad, mida, mõjutab, kujundab, pinnamoe
Topics RU: природоведение, повторение, повтори, тренировка, вода, безопасность на воде, водоём
Topics EN: science, revision, review, practice, water, water safety, body of water
Headings: Kordamine. Pinnamood; 4.1. Pinnavormid ja pinnamood; Mis on maakera suurimad pinnavormid?; Mida mõjutab ja kujundab pinnamood?; 4.2. Pinnamoe kujutamine kaardil; Kui suur on joonisel kujutatud künka horisontaalide lõikevahe?; Millise kõrgusega punkte samakõrgusjoon ühendab?; Milline reljeefi kujutamise viis annab pinnamoest täpseima ettekujutuse?; Mida näitab pinnamoe profiilijoon?; 4.3. Mäestikud ja mägismaad; Mäestike kõrgus; Mille poolest erineb noorte ja vanade mäestike välisilme?; Mis on mägismaa?; Mille poolest erineb nõgu orust?; 4.4. Tasandikud; Missugusel mandril asuvad antud tasandikud?; Ida-Euroopa lauskmaa.; Märgi väited, mis iseloomustavad õigesti elu- ja majandustingimusi tasandikel.; Mis on alamik?; Mille poolest erinevad mägismaa ja kiltmaa?; 4.5. Maailmamere põhjareljeef; Ookeanipõhja pinnamoe elemendid; Mandrid ja ookeanid; Kus paiknevad süvikud?; Kus on mandrilise ja ookeanilise maakoore piir?; 4.6. Maa pinnamood muutub (1); Millised inimtegevused kiirendavad erosiooni?; Sademed ja voolav vesi; Mis põhjustab kivimite murenemist?; 4.7. Maa pinnamood muutub (2); Kuidas on pinnavormid tekkinud?; Mis on moreen?; Tuul pinnamoe kujundajana; Märgi, millised väited kirjeldavad liustike teket.; Mõisted; Ristsõna. Pinnamood

## Riigid maailma kaardil
URL: https://www.opiq.ee/kit/2/chapter/57
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.1
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, riigid, maailma, kaardil, poliitilisel, järjesta, pindala, järgi, mitu, riiki
Topics RU: природоведение, число, числа, цифры, сравнение, сравни, больше, меньше
Topics EN: science, number, numbers, digits, comparison, compare, greater, less
Headings: Riigid maailma kaardil; Mis on maailma poliitilisel kaardil?; Järjesta riigid pindala järgi.; Mitu riiki kuulub Euroopa Liitu; Mitu maakonda on Eestis?; Kuidas võrreldakse riike?; Mis riigid kuuluvad nii kümne suurima rahvaarvu kui ka pindalaga riikide hulka?; Mõtle; Järjesta näitajad selle järgi, kui kõrge on Eesti koht riikide pingereas.; Mis riikide elanikud on maailma tipus nii keskmine eluea kui ka haridustaseme osas?; Enam arenenud ja vähem arenenud riigid?; Millised maailma piirkonnad on majanduslikult edukamad?; Võrdle elektri tarbimise ja arstide arvu tabeleid ning vasta küsimustele.; Lisamaterjal. Big Maci indeks; Big Maci indeks; Mida näitab riigi geograafiline asend?; Märgi, millised tunnused iseloomustavad Eesti geograafilist asendit.; Mõisted

## Maailma rahvastik
URL: https://www.opiq.ee/kit/2/chapter/58
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.2
Topics ET: loodusõpetus, maailma, rahvastik, keeled, märgi, riigid, räägitakse, peamiselt, hispaania, keelt
Topics RU: природоведение
Topics EN: science
Headings: Maailma rahvastik; Maailma keeled; Märgi riigid, kus räägitakse peamiselt hispaania keelt.; Mõtle; Riigikeel ja emakeel; Millises kirjasüsteemis on see geograafia õpik?; Kuidas mõjutab inimest tema kultuuriline päritolu?; Mis tegurid mõjutavad inimese maailmavaadet?; Mis on levinuim usund Eestis?; Mõisted

## Rahvastiku paiknemine (1)
URL: https://www.opiq.ee/kit/2/chapter/59
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.3
Topics ET: loodusõpetus, rahvastiku, paiknemine, miks, mõned, paigad, tihedamalt, asustatud, teised, millised
Topics RU: природоведение
Topics EN: science
Headings: Rahvastiku paiknemine (1); Miks mõned paigad on tihedamalt asustatud kui teised?; Millised tegurid piiravad asustuse kasvu ja arengut?; Kui suur on maailma keskmine rahvastiku tihedus?; Miks on rannikud ja jõgede suudmealad muudest piirkondadest tihemini asustatud?; Kuidas praegune asustus peegeldab riigi ajaloolist arengut?; Asustuse areng; Linnade areng; Mõisted

## Rahvastiku paiknemine (2)
URL: https://www.opiq.ee/kit/2/chapter/60
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.4
Topics ET: loodusõpetus, rahvastiku, paiknemine, millistes, piirkondades, tihedus, suurim, järjesta, maailmajaod, selle
Topics RU: природоведение
Topics EN: science
Headings: Rahvastiku paiknemine (2); Millistes piirkondades on rahvastiku tihedus suurim?; Järjesta maailmajaod selle järgi, kui suur osa maailma rahvastikust neis elab.; Kus elab peamine osa maailma rahvastikust?; Miks Euroopa rahvaarv enam ei kasva?; Mis piirkondadesse on koondunud rahvastik Põhja-Ameerikas?; Mis Aafrika piirkonnad on tihedalt asustatud?; Mis on soodustanud tihedat asustust Ida- ja Lõuna-Aasias?; Kui suur osa maailma rahvastikust elab Aasias?; Miks on enamik Austraaliast sisuliselt inimtühi?

## Rahvaarvu muutumine (1)
URL: https://www.opiq.ee/kit/2/chapter/61
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.5
Topics ET: loodusõpetus, rahvaarvu, muutumine, millest, sõltub, miks, vähem, arenenud, riikides, suur
Topics RU: природоведение
Topics EN: science
Headings: Rahvaarvu muutumine (1); Millest sõltub rahvaarvu muutumine?; Miks on vähem arenenud riikides suur suremus?; Miks on sündimus vähem arenenud maades kõrge?; Mida võib järeldada rahvaarvu kasvutempo diagrammi vaadates?; Kuidas on maailma rahvaarv muutunud?; Miks algas möödunud sajandil rahvastik plahvatuslikult kasvama?; Millised muutused inimkonna ajaloos on toonud kaasa rahvaarvu kiirema kasvu võrreldes eelneva perioodiga?; Mõtle

## Rahvaarvu muutumine (2)
URL: https://www.opiq.ee/kit/2/chapter/62
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.6
Topics ET: loodusõpetus, rahvaarvu, muutumine, milliseid, probleeme, toob, kaasa, kiire, kasv, millisele
Topics RU: природоведение
Topics EN: science
Headings: Rahvaarvu muutumine (2); Milliseid probleeme toob kaasa rahvaarvu kiire kasv?; Millisele piirkonnale prognoositakse lähikümnendeil suurimat rahvaarvu kasvu?; Miks eelistatakse Hiinas poisslapsi?; Lisamaterjal. Robert Malthus; Miks ei läinud Malthuse ennustus toidu lõppemisest täide?; Mõtle; Miks inimesed elukohta vahetavad?; Mis riikidesse on rännatud Euroopast?; Mis põhjustel on inimesed sunnitud oma kodukohast lahkuma?

## Linnad ja linnastumine
URL: https://www.opiq.ee/kit/2/chapter/63
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.7
Topics ET: loodusõpetus, linnad, linnastumine, tekkisid, esimesed, kuhu, kujunesid, vanasti, kuidas, linna
Topics RU: природоведение
Topics EN: science
Headings: Linnad ja linnastumine; Kus tekkisid esimesed linnad?; Kuhu kujunesid vanasti esimesed linnad?; Kuidas linna määratleda?; Miks ei ole linna täpne piiritlemine päris võimalik?; Kui suured on maailma suuremad linnad?; Millised muutused on toimunud maailma suurlinnade osas alates 21. sajandi keskpaigast?; Kuidas tekivad linnastud?; Mis on linnastumine?; Millised on linnastumise trendid praegu?; Mis on põhjustanud linnastumist?; Millised probleemid kaasnevad linnastumisega?; Miks esineb linnastumisega kaasnevaid probleeme kõige enam vähem arenenud riikides?; Mõtle; Lisamaterjal. Napoli prügitüli; Mõisted

## Kordamine. Rahvastik
URL: https://www.opiq.ee/kit/2/chapter/64
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 5.8
Topics ET: loodusõpetus, kordamine, korda, harjutan, rahvastik, riigid, maailma, kaardil, enam, vähem, arenenud, riigi
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Rahvastik; 5.1. Riigid maailma kaardil; Enam ja vähem arenenud riigid; Riigi tunnused; Geograafiline asend; Millisesse kaardirühma kuuluvad poliitilised kaardid?; 5.2. Maailma rahvastik; Mis on levinuim usund Eestis?; Riigi- ja emakeel; Mis tegurid mõjutavad inimese maailmavaadet?; 5.3. Rahvastiku paiknemine (1 ja 2); Maailma rahvastik ja selle paiknemine (4); Maailma rahvastik ja selle paiknemine (1); Maailma rahvastik ja selle paiknemine (2); Maailma rahvastik ja selle paiknemine (3); Miks on rannikud ja jõgede suudmealad muudest piirkondadest tihemini asustatud?; Millised tegurid piiravad asustuse kasvu ja arengut?; 5.4. Rahvastiku paiknemine (2); Järjesta maailmajaod selle järgi, kui suur osa maailma rahvastikust neis elab.; Kus elab peamine osa maailma rahvastikust?; Mis maailmajagude rahvaarv on suurim?; 5.5. Rahvaarvu muutumine (1); Miks algas möödunud sajandil rahvastik plahvatuslikult kasvama?; Miks on sündimus vähem arenenud maades kõrge?; Miks on vähem arenenud riikides suur suremus?; 5.6. Rahvaarvu muutumine (2); Mis piirkonnas kasvab rahvaarv praegu kõige kiiremini?; Mis põhjustel võtavad inimesed ette rändeid?; 5.7. Linnad ja linnastumine; Miks esineb linnastumisega kaasnevaid probleeme kõige enam vähem arenenud riikides?; Linnastumine tänapäeval; Kuhu kujunesid vanasti esimesed linnad?; Miks ei ole linna täpne piiritlemine päris võimalik?; Mis on põhjustanud linnastumist?; Mõisted; Ristsõna. Rahvastik

## Eesti ülevaatekaart
URL: https://www.opiq.ee/kit/2/chapter/67
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 6.1
Topics ET: loodusõpetus, eesti, ülevaatekaart
Topics RU: природоведение
Topics EN: science
Headings: Eesti ülevaatekaart

## Maailma looduskaart
URL: https://www.opiq.ee/kit/2/chapter/68
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 6.2
Topics ET: loodusõpetus, maailma, looduskaart, põhja, ameerika, lõuna, euroopa, aafrika, aasia, austraalia
Topics RU: природоведение
Topics EN: science
Headings: Maailma looduskaart; Põhja-Ameerika; Lõuna-Ameerika; Euroopa ja Aafrika; Aasia; Austraalia ja Okeaania

## Maailma poliitiline kaart
URL: https://www.opiq.ee/kit/2/chapter/69
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 6.3
Topics ET: loodusõpetus, maailma, poliitiline, kaart, põhja, ameerika, euroopa, aasia, austraalia, okeaania
Topics RU: природоведение
Topics EN: science
Headings: Maailma poliitiline kaart; Põhja-Ameerika; Euroopa; Aasia; Austraalia ja Okeaania; Aafrika; Lõuna-Ameerika

## Diagrammi koostamine
URL: https://www.opiq.ee/kit/2/chapter/1279
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 6.4
Topics ET: loodusõpetus, diagrammi, koostamine, rakenduse, avamine, andmete, sisestamine, valimine, täiustamine, salvestamine
Topics RU: природоведение
Topics EN: science
Headings: Diagrammi koostamine; Rakenduse avamine; Andmete sisestamine; Diagrammi valimine; Diagrammi täiustamine; Diagrammi salvestamine

## 3D-fotod
URL: https://www.opiq.ee/kit/2/chapter/22056
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 6.5
Topics ET: loodusõpetus, fotod, foto
Topics RU: природоведение
Topics EN: science
Headings: 3D-fotod; Foto 1; Foto 2; Foto 3; Foto 4; Foto 5

## Mõisted
URL: https://www.opiq.ee/kit/2/chapter/12297
Book: Loodus ja inimtegevus
Class: 7
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 7k__geograafia_loodus_avita_est
Chapter ID: 6.6
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted
