## Arvjuhitavad seadmed (CNC) – Opiq
URL: https://www.opiq.ee/Kit/Details/476
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1
Topics ET: matemaatika, arvjuhitavad, seadmed, opiq
Topics RU: математика
Topics EN: mathematics

## Arvjuhitavad seadmed (CNC) – Opiq
URL: https://www.opiq.ee/Kit/Details/476
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 25
Topics ET: matemaatika, arvjuhitavad, seadmed, opiq
Topics RU: математика
Topics EN: mathematics

## Tervitus Snapmakerilt
URL: https://www.opiq.ee/kit/476/chapter/26054
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.1
Topics ET: matemaatika, tervitus, snapmakerilt, uuenduslik, meisterdamine, kuidas, seda, raamatut, kasutada
Topics RU: математика
Topics EN: mathematics
Headings: Tervitus Snapmakerilt; Uuenduslik meisterdamine; Kuidas seda raamatut kasutada?

## Test
URL: https://www.opiq.ee/kit/476/chapter/26053
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.10
Topics ET: matemaatika, test, teadmiste, kontroll
Topics RU: математика
Topics EN: mathematics
Headings: Test; Teadmiste kontroll

## Sissejuhatus 3D-printimisse, laser­graveerimisse ja arvjuhtimisega freesimisse
URL: https://www.opiq.ee/kit/476/chapter/26055
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.2
Topics ET: matemaatika, sissejuhatus, printimisse, laser, graveerimisse, arvjuhtimisega, freesimisse, printimine, lasergraveerimine, freesimine
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus 3D-printimisse, laser­graveerimisse ja arvjuhtimisega freesimisse; 3D-printimine; Lasergraveerimine; CNC-freesimine (arvjuhtimisega freesimine)

## Tunne oma Snapmakerit: kolm-ühes 3D-printer
URL: https://www.opiq.ee/kit/476/chapter/26056
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.3
Topics ET: matemaatika, tunne, snapmakerit, kolm, ühes, printer, snapmaker, kastis, vahetatavat, funktsionaalset
Topics RU: математика
Topics EN: mathematics
Headings: Tunne oma Snapmakerit: kolm-ühes 3D-printer; Snapmaker; Mis on kastis?; Kolm vahetatavat funktsionaalset moodulit

## Miks kasutada Snapmakerit koolitunnis?
URL: https://www.opiq.ee/kit/476/chapter/26057
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.4
Topics ET: matemaatika, miks, kasutada, snapmakerit, koolitunnis, snapmakeri, kasutusalad, eelised
Topics RU: математика
Topics EN: mathematics
Headings: Miks kasutada Snapmakerit koolitunnis?; Snapmakeri kasutusalad; Snapmakeri eelised

## Kuidas Snapmakerit kasutada?
URL: https://www.opiq.ee/kit/476/chapter/26058
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.5
Topics ET: matemaatika, kuidas, snapmakerit, kasutada, printimine, lasergraveerimine, freesimine
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas Snapmakerit kasutada?; 3D-printimine; Lasergraveerimine; CNC-freesimine

## Õppimise ökosüsteem
URL: https://www.opiq.ee/kit/476/chapter/26059
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.6
Topics ET: matemaatika, õppimise, ökosüsteem
Topics RU: математика
Topics EN: mathematics
Headings: Õppimise ökosüsteem

## Kasutajate lood
URL: https://www.opiq.ee/kit/476/chapter/26060
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.7
Topics ET: matemaatika, kasutajate, lood
Topics RU: математика
Topics EN: mathematics
Headings: Kasutajate lood

## Populaarsed platvormid, mis toetavad erinevate kooliprojektide elluviimist
URL: https://www.opiq.ee/kit/476/chapter/26061
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.8
Topics ET: matemaatika, populaarsed, platvormid, toetavad, erinevate, kooliprojektide, elluviimist, platvormide, tutvustus
Topics RU: математика
Topics EN: mathematics
Headings: Populaarsed platvormid, mis toetavad erinevate kooliprojektide elluviimist; Platvormide tutvustus

## Populaarne projekteerimis­tarkvara
URL: https://www.opiq.ee/kit/476/chapter/26062
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 1.9
Topics ET: matemaatika, populaarne, projekteerimis, tarkvara, modelleerimine, graafika
Topics RU: математика
Topics EN: mathematics
Headings: Populaarne projekteerimis­tarkvara; 3D-modelleerimine; 2D graafika

## 3D-printimine — tuuleturbiin
URL: https://www.opiq.ee/kit/476/chapter/26063
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 2.1
Topics ET: matemaatika, printimine, tuuleturbiin, sissejuhatus, õpieesmärgid, tööetapid, märkus
Topics RU: математика
Topics EN: mathematics
Headings: 3D-printimine — tuuleturbiin; Sissejuhatus; Õpieesmärgid; Tööetapid; Märkus

## 3D-printimine — õhupall­mootoriga auto
URL: https://www.opiq.ee/kit/476/chapter/26064
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 2.2
Topics ET: matemaatika, printimine, õhupall, mootoriga, auto, sissejuhatus, õpieesmärgid, tööetapid
Topics RU: математика
Topics EN: mathematics
Headings: 3D-printimine — õhupall­mootoriga auto; Sissejuhatus; Õpieesmärgid; Tööetapid

## Laser­graveerimine ja -lõikamine – kella kujundus
URL: https://www.opiq.ee/kit/476/chapter/26065
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 2.3
Topics ET: matemaatika, laser, graveerimine, lõikamine, kella, kujundus, sissejuhatus, õpieesmärgid, tööetapid
Topics RU: математика
Topics EN: mathematics
Headings: Laser­graveerimine ja -lõikamine – kella kujundus; Sissejuhatus; Õpieesmärgid; Tööetapid

## Laser­graveerimine ja -lõikamine — omatehtud tempel
URL: https://www.opiq.ee/kit/476/chapter/26066
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 2.4
Topics ET: matemaatika, laser, graveerimine, lõikamine, omatehtud, tempel, sissejuhatus, õpieesmärgid, tööetapid, märkus
Topics RU: математика
Topics EN: mathematics
Headings: Laser­graveerimine ja -lõikamine — omatehtud tempel; Sissejuhatus; Õpieesmärgid; Tööetapid; Märkus

## Arvjuhtimisega freesimine — puitlabürint
URL: https://www.opiq.ee/kit/476/chapter/26067
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 2.5
Topics ET: matemaatika, arvjuhtimisega, freesimine, puitlabürint, sissejuhatus, õpieesmärgid, vajalikud, vahendid, tööetapid, märkus
Topics RU: математика
Topics EN: mathematics
Headings: Arvjuhtimisega freesimine — puitlabürint; Sissejuhatus; Õpieesmärgid; Vajalikud vahendid; Tööetapid; Märkus; Nõuanded

## Arvjuhtimisega freesimine — kuusnurkne hoidik
URL: https://www.opiq.ee/kit/476/chapter/26068
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 2.6
Topics ET: matemaatika, arvjuhtimisega, freesimine, kuusnurkne, hoidik, sissejuhatus, õpieesmärgid, tööetapid, märkus, nõuanded
Topics RU: математика
Topics EN: mathematics
Headings: Arvjuhtimisega freesimine — kuusnurkne hoidik; Sissejuhatus; Õpieesmärgid; Tööetapid; Märkus; Nõuanded

## Siilikujulise pliiatsihoidja valmistamine
URL: https://www.opiq.ee/kit/476/chapter/26069
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 3.1
Topics ET: matemaatika, siilikujulise, pliiatsihoidja, valmistamine, vajalikud, vahendid, tööetapid
Topics RU: математика
Topics EN: mathematics
Headings: Siilikujulise pliiatsihoidja valmistamine; Vajalikud vahendid; Tööetapid

## Ruumilise maastiku­maketi tegemine
URL: https://www.opiq.ee/kit/476/chapter/26070
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 3.2
Topics ET: matemaatika, ruumilise, maastiku, maketi, tegemine, vajalikud, vahendid, tööetapid
Topics RU: математика
Topics EN: mathematics
Headings: Ruumilise maastiku­maketi tegemine; Vajalikud vahendid; Tööetapid

## Mida kujutab endast disainipõhine õpe?
URL: https://www.opiq.ee/kit/476/chapter/26071
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 3.3
Topics ET: matemaatika, mida, kujutab, endast, disainipõhine
Topics RU: математика
Topics EN: mathematics
Headings: Mida kujutab endast disainipõhine õpe?; Disainipõhine õpe

## Miks valida disainipõhine õpe?
URL: https://www.opiq.ee/kit/476/chapter/26072
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 3.4
Topics ET: matemaatika, miks, valida, disainipõhine
Topics RU: математика
Topics EN: mathematics
Headings: Miks valida disainipõhine õpe?

## Snapmakeri disainipõhise tunnikava mall
URL: https://www.opiq.ee/kit/476/chapter/26073
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 3.5
Topics ET: matemaatika, snapmakeri, disainipõhise, tunnikava, mall
Topics RU: математика
Topics EN: mathematics
Headings: Snapmakeri disainipõhise tunnikava mall

## Standardid
URL: https://www.opiq.ee/kit/476/chapter/26074
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 3.6
Topics ET: matemaatika, standardid, printimine, tuuleturbiin, õhupallmootoriga, auto, lasergraveerimine, lõikamine, kella, kujundus
Topics RU: математика
Topics EN: mathematics
Headings: Standardid; 3D-printimine — tuuleturbiin; 3D-printimine — õhupallmootoriga auto; Lasergraveerimine ja -lõikamine – kella kujundus; Lasergraveerimine ja -lõikamine — omatehtud tempel; Arvjuhtimisega freesimine — puitlabürint; Arvjuhtimisega freesimine — kuusnurkne hoidik

## Mõisted
URL: https://www.opiq.ee/kit/476/chapter/26075
Book: tehnologia 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: arvjuhitavad_seadmed_(cnc)
Chapter ID: 4.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted
