## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/200
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/200
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 87
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Tööks vajalikud materjalid
URL: https://www.opiq.ee/kit/200/chapter/11374
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.1
Topics ET: matemaatika, tööks, vajalikud, materjalid
Topics RU: математика
Topics EN: mathematics
Headings: Tööks vajalikud materjalid

## Kuidas teha kaardile raami
URL: https://www.opiq.ee/kit/200/chapter/11375
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.2
Topics ET: matemaatika, kuidas, teha, kaardile, raami, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha kaardile raami; 1. võimalus; 2. võimalus

## Kuidas teha kaardile lehti
URL: https://www.opiq.ee/kit/200/chapter/11376
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.3
Topics ET: matemaatika, kuidas, teha, kaardile, lehti, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha kaardile lehti; 1. võimalus; 2. võimalus; 3. võimalus; 4. võimalus; 5. võimalus

## Volditud lips
URL: https://www.opiq.ee/kit/200/chapter/11377
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.1
Topics ET: matemaatika, volditud, lips
Topics RU: математика
Topics EN: mathematics
Headings: Volditud lips

## Volditud vest
URL: https://www.opiq.ee/kit/200/chapter/11378
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.2
Topics ET: matemaatika, volditud, vest
Topics RU: математика
Topics EN: mathematics
Headings: Volditud vest

## Lihtne volditud särk
URL: https://www.opiq.ee/kit/200/chapter/11379
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.3
Topics ET: matemaatika, lihtne, volditud, särk
Topics RU: математика
Topics EN: mathematics
Headings: Lihtne volditud särk

## Volditud särk
URL: https://www.opiq.ee/kit/200/chapter/11380
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.4
Topics ET: matemaatika, volditud, särk
Topics RU: математика
Topics EN: mathematics
Headings: Volditud särk

## Kikilipsuga kaart
URL: https://www.opiq.ee/kit/200/chapter/11381
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.5
Topics ET: matemaatika, kikilipsuga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kikilipsuga kaart

## Purjekaga kaart
URL: https://www.opiq.ee/kit/200/chapter/11382
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.6
Topics ET: matemaatika, purjekaga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Purjekaga kaart

## Autodega kaart
URL: https://www.opiq.ee/kit/200/chapter/11383
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.7
Topics ET: matemaatika, autodega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Autodega kaart

## Õmmeldud kaart
URL: https://www.opiq.ee/kit/200/chapter/11384
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.8
Topics ET: matemaatika, õmmeldud, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Õmmeldud kaart

## Joonistatud lipsud
URL: https://www.opiq.ee/kit/200/chapter/11385
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.9
Topics ET: matemaatika, joonistatud, lipsud
Topics RU: математика
Topics EN: mathematics
Headings: Joonistatud lipsud

## Võrguga kaart
URL: https://www.opiq.ee/kit/200/chapter/11386
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.1
Topics ET: matemaatika, võrguga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Võrguga kaart

## Erineva suurusega küünlad
URL: https://www.opiq.ee/kit/200/chapter/11395
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.10
Topics ET: matemaatika, erineva, suurusega, küünlad
Topics RU: математика
Topics EN: mathematics
Headings: Erineva suurusega küünlad

## Lainepapist küünlad
URL: https://www.opiq.ee/kit/200/chapter/11396
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.11
Topics ET: matemaatika, lainepapist, küünlad
Topics RU: математика
Topics EN: mathematics
Headings: Lainepapist küünlad

## Pabernöörist küünal
URL: https://www.opiq.ee/kit/200/chapter/11397
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.12
Topics ET: matemaatika, pabernöörist, küünal, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Pabernöörist küünal; 1. võimalus; 2. võimalus

## Pop-up-tehnikas kollaaž
URL: https://www.opiq.ee/kit/200/chapter/11398
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.13
Topics ET: matemaatika, tehnikas, kollaaž
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kollaaž

## Pop-up-tehnikas kaart
URL: https://www.opiq.ee/kit/200/chapter/11399
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.14
Topics ET: matemaatika, tehnikas, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kaart

## Pop-up-tehnikas kera
URL: https://www.opiq.ee/kit/200/chapter/11400
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.15
Topics ET: matemaatika, tehnikas, kera
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kera

## Kalkapaberist jõuluehted
URL: https://www.opiq.ee/kit/200/chapter/11401
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.16
Topics ET: matemaatika, kalkapaberist, jõuluehted
Topics RU: математика
Topics EN: mathematics
Headings: Kalkapaberist jõuluehted

## Joonistatud kuusk
URL: https://www.opiq.ee/kit/200/chapter/11402
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.17
Topics ET: matemaatika, joonistatud, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Joonistatud kuusk

## Kahekordse kolmnurgaga kuusk
URL: https://www.opiq.ee/kit/200/chapter/11403
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.18
Topics ET: matemaatika, kahekordse, kolmnurgaga, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Kahekordse kolmnurgaga kuusk

## Kihiline kuusk
URL: https://www.opiq.ee/kit/200/chapter/11404
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.19
Topics ET: matemaatika, kihiline, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Kihiline kuusk

## Sinepituubist kaart
URL: https://www.opiq.ee/kit/200/chapter/11387
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.2
Topics ET: matemaatika, sinepituubist, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Sinepituubist kaart

## Pooleks volditud ringidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11405
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.20
Topics ET: matemaatika, pooleks, volditud, ringidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pooleks volditud ringidest kuusk

## Ribastatud paberist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11406
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.21
Topics ET: matemaatika, ribastatud, paberist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ribastatud paberist kuusk

## Nöörist või traadist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11407
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.22
Topics ET: matemaatika, nöörist, traadist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Nöörist või traadist kuusk

## Risti punutud paela või traadiga kuusk
URL: https://www.opiq.ee/kit/200/chapter/11408
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.23
Topics ET: matemaatika, risti, punutud, paela, traadiga, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Risti punutud paela või traadiga kuusk

## Pitsilisest paberist, paberiribadest või paeltest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11409
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.24
Topics ET: matemaatika, pitsilisest, paberist, paberiribadest, paeltest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilisest paberist, paberiribadest või paeltest kuusk

## Punutud kuusk
URL: https://www.opiq.ee/kit/200/chapter/11410
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.25
Topics ET: matemaatika, punutud, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Punutud kuusk

## Tikkimisriidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11411
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.26
Topics ET: matemaatika, tikkimisriidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Tikkimisriidest kuusk

## Erinevat värvi kuused
URL: https://www.opiq.ee/kit/200/chapter/11412
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.27
Topics ET: matemaatika, erinevat, värvi, kuused
Topics RU: математика
Topics EN: mathematics
Headings: Erinevat värvi kuused

## Nööpidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11413
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.28
Topics ET: matemaatika, nööpidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Nööpidest kuusk

## Ruumiline kuusk
URL: https://www.opiq.ee/kit/200/chapter/11414
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.29
Topics ET: matemaatika, ruumiline, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline kuusk

## Teeküünlatopsist kaart
URL: https://www.opiq.ee/kit/200/chapter/11388
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.3
Topics ET: matemaatika, teeküünlatopsist, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Teeküünlatopsist kaart

## Ribadest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11415
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.30
Topics ET: matemaatika, ribadest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ribadest kuusk

## PVA liimi, metallipuru ja tähekestega kaart
URL: https://www.opiq.ee/kit/200/chapter/11416
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.31
Topics ET: matemaatika, liimi, metallipuru, tähekestega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: PVA liimi, metallipuru ja tähekestega kaart

## Traadi või pärlitega ja PVA liimiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11417
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.32
Topics ET: matemaatika, traadi, pärlitega, liimiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Traadi või pärlitega ja PVA liimiga kaart

## Paberiribadest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11418
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.33
Topics ET: matemaatika, paberiribadest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Paberiribadest kuusk

## Siksak-tehnikas kuusk
URL: https://www.opiq.ee/kit/200/chapter/11419
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.34
Topics ET: matemaatika, siksak, tehnikas, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Siksak-tehnikas kuusk

## Pitsilisest koogipaberist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11420
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.35
Topics ET: matemaatika, pitsilisest, koogipaberist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilisest koogipaberist kuusk

## Elupuuoksast kuusk
URL: https://www.opiq.ee/kit/200/chapter/11421
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.36
Topics ET: matemaatika, elupuuoksast, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Elupuuoksast kuusk

## Samblikuga kaart
URL: https://www.opiq.ee/kit/200/chapter/11389
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.4
Topics ET: matemaatika, samblikuga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Samblikuga kaart

## Kingipakkidega kaart
URL: https://www.opiq.ee/kit/200/chapter/11390
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.5
Topics ET: matemaatika, kingipakkidega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kingipakkidega kaart

## Kahepoolse teibiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11391
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.6
Topics ET: matemaatika, kahepoolse, teibiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kahepoolse teibiga kaart

## Tagasipööratud äärega kaart
URL: https://www.opiq.ee/kit/200/chapter/11392
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.7
Topics ET: matemaatika, tagasipööratud, äärega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Tagasipööratud äärega kaart

## Pabernöörist jõulupärg
URL: https://www.opiq.ee/kit/200/chapter/11393
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.8
Topics ET: matemaatika, pabernöörist, jõulupärg
Topics RU: математика
Topics EN: mathematics
Headings: Pabernöörist jõulupärg

## Ringidest jõulupärg ja kuusk
URL: https://www.opiq.ee/kit/200/chapter/11394
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.9
Topics ET: matemaatika, ringidest, jõulupärg, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ringidest jõulupärg ja kuusk

## Erikujulised südamed
URL: https://www.opiq.ee/kit/200/chapter/11422
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.1
Topics ET: matemaatika, erikujulised, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Erikujulised südamed

## Ruumiline süda
URL: https://www.opiq.ee/kit/200/chapter/11423
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.2
Topics ET: matemaatika, ruumiline, süda
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline süda

## Rullitud paberiribadest südamed
URL: https://www.opiq.ee/kit/200/chapter/11424
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.3
Topics ET: matemaatika, rullitud, paberiribadest, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Rullitud paberiribadest südamed

## Pitsiga südamed
URL: https://www.opiq.ee/kit/200/chapter/11425
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.4
Topics ET: matemaatika, pitsiga, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Pitsiga südamed

## Lahtikäiv kaart
URL: https://www.opiq.ee/kit/200/chapter/11426
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.1
Topics ET: matemaatika, lahtikäiv, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Lahtikäiv kaart

## Üllatuskaart
URL: https://www.opiq.ee/kit/200/chapter/11427
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.2
Topics ET: matemaatika, üllatuskaart
Topics RU: математика
Topics EN: mathematics
Headings: Üllatuskaart

## Valik kevadpühade kaarte
URL: https://www.opiq.ee/kit/200/chapter/11428
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.3
Topics ET: matemaatika, valik, kevadpühade, kaarte
Topics RU: математика
Topics EN: mathematics
Headings: Valik kevadpühade kaarte

## Pop-up-tehnikas kaart
URL: https://www.opiq.ee/kit/200/chapter/11429
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.4
Topics ET: matemaatika, tehnikas, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kaart

## Lehvikust lill
URL: https://www.opiq.ee/kit/200/chapter/11430
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.1
Topics ET: matemaatika, taim, taimed, puu, lill, lehvikust
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lehvikust lill

## Muffinivormidest kaart
URL: https://www.opiq.ee/kit/200/chapter/11439
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.10
Topics ET: matemaatika, muffinivormidest, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Muffinivormidest kaart

## Tagasipööratud äärtega lill
URL: https://www.opiq.ee/kit/200/chapter/11440
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.11
Topics ET: matemaatika, taim, taimed, puu, lill, tagasipööratud, äärtega
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Tagasipööratud äärtega lill

## Pop-up-tehnikas lilledega kaardid
URL: https://www.opiq.ee/kit/200/chapter/11441
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.12
Topics ET: matemaatika, tehnikas, lilledega, kaardid
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas lilledega kaardid

## Pop-up-tehnikas lillepotid
URL: https://www.opiq.ee/kit/200/chapter/11442
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.13
Topics ET: matemaatika, tehnikas, lillepotid
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas lillepotid

## Tulbikaart
URL: https://www.opiq.ee/kit/200/chapter/11443
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.14
Topics ET: matemaatika, tulbikaart
Topics RU: математика
Topics EN: mathematics
Headings: Tulbikaart

## Lumikellukesed
URL: https://www.opiq.ee/kit/200/chapter/11444
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.15
Topics ET: matemaatika, lumikellukesed
Topics RU: математика
Topics EN: mathematics
Headings: Lumikellukesed

## Volditud lill
URL: https://www.opiq.ee/kit/200/chapter/11445
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.16
Topics ET: matemaatika, taim, taimed, puu, lill, volditud
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Volditud lill

## Volditud lill
URL: https://www.opiq.ee/kit/200/chapter/11446
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.17
Topics ET: matemaatika, taim, taimed, puu, lill, volditud
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Volditud lill

## Paberiribadest lill
URL: https://www.opiq.ee/kit/200/chapter/11447
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.18
Topics ET: matemaatika, taim, taimed, puu, lill, paberiribadest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Paberiribadest lill

## Venivast krepp-paberist lilled
URL: https://www.opiq.ee/kit/200/chapter/11448
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.19
Topics ET: matemaatika, venivast, krepp, paberist, lilled
Topics RU: математика
Topics EN: mathematics
Headings: Venivast krepp-paberist lilled

## Pabernöörist lill
URL: https://www.opiq.ee/kit/200/chapter/11431
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.2
Topics ET: matemaatika, taim, taimed, puu, lill, pabernöörist
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pabernöörist lill

## Rullitud paberiribadest lilled
URL: https://www.opiq.ee/kit/200/chapter/11432
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.3
Topics ET: matemaatika, rullitud, paberiribadest, lilled
Topics RU: математика
Topics EN: mathematics
Headings: Rullitud paberiribadest lilled

## Pooleks volditud ringidest lill
URL: https://www.opiq.ee/kit/200/chapter/11433
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.4
Topics ET: matemaatika, taim, taimed, puu, lill, pooleks, volditud, ringidest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pooleks volditud ringidest lill

## Lainepapist lill
URL: https://www.opiq.ee/kit/200/chapter/11434
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.5
Topics ET: matemaatika, taim, taimed, puu, lill, lainepapist
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lainepapist lill

## Pooleks volditud südametest lill
URL: https://www.opiq.ee/kit/200/chapter/11435
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.6
Topics ET: matemaatika, taim, taimed, puu, lill, pooleks, volditud, südametest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pooleks volditud südametest lill

## Ringidest lill
URL: https://www.opiq.ee/kit/200/chapter/11436
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.7
Topics ET: matemaatika, taim, taimed, puu, lill, ringidest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Ringidest lill

## Tulbid
URL: https://www.opiq.ee/kit/200/chapter/11437
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.8
Topics ET: matemaatika, tulbid
Topics RU: математика
Topics EN: mathematics
Headings: Tulbid

## Tulbid potis
URL: https://www.opiq.ee/kit/200/chapter/11438
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.9
Topics ET: matemaatika, tulbid, potis
Topics RU: математика
Topics EN: mathematics
Headings: Tulbid potis

## Liivakaart
URL: https://www.opiq.ee/kit/200/chapter/11449
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.1
Topics ET: matemaatika, liivakaart
Topics RU: математика
Topics EN: mathematics
Headings: Liivakaart

## Volditud liblikaga kaart
URL: https://www.opiq.ee/kit/200/chapter/11458
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.10
Topics ET: matemaatika, volditud, liblikaga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Volditud liblikaga kaart

## Nööbikaart
URL: https://www.opiq.ee/kit/200/chapter/11450
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.2
Topics ET: matemaatika, nööbikaart
Topics RU: математика
Topics EN: mathematics
Headings: Nööbikaart

## Punutud kaart
URL: https://www.opiq.ee/kit/200/chapter/11451
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.3
Topics ET: matemaatika, punutud, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Punutud kaart

## Pitsilise koogipaberiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11452
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.4
Topics ET: matemaatika, pitsilise, koogipaberiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilise koogipaberiga kaart

## Pildiraamid
URL: https://www.opiq.ee/kit/200/chapter/11453
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.5
Topics ET: matemaatika, pildiraamid
Topics RU: математика
Topics EN: mathematics
Headings: Pildiraamid

## Pitsilise paberiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11454
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.6
Topics ET: matemaatika, pitsilise, paberiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilise paberiga kaart

## Värvilaikudega kaart
URL: https://www.opiq.ee/kit/200/chapter/11455
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.7
Topics ET: matemaatika, värvilaikudega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Värvilaikudega kaart

## Täpikaart
URL: https://www.opiq.ee/kit/200/chapter/11456
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.8
Topics ET: matemaatika, täpikaart
Topics RU: математика
Topics EN: mathematics
Headings: Täpikaart

## Kujundirauaga tehtud kaardid
URL: https://www.opiq.ee/kit/200/chapter/11457
Book: Käsitöötuba – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.9
Topics ET: matemaatika, kujundirauaga, tehtud, kaardid
Topics RU: математика
Topics EN: mathematics
Headings: Kujundirauaga tehtud kaardid
