## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/192
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 88
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/192
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 178
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Ruumilised seened (kortsutamine)
URL: https://www.opiq.ee/kit/192/chapter/10881
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.1
Topics ET: matemaatika, ruumilised, seened, kortsutamine
Topics RU: математика
Topics EN: mathematics
Headings: Ruumilised seened (kortsutamine)

## Kaart ruumilise kuusega
URL: https://www.opiq.ee/kit/192/chapter/10890
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.10
Topics ET: matemaatika, kaart, ruumilise, kuusega
Topics RU: математика
Topics EN: mathematics
Headings: Kaart ruumilise kuusega

## Ruumiline kuusk
URL: https://www.opiq.ee/kit/192/chapter/10891
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.11
Topics ET: matemaatika, ruumiline, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline kuusk

## Võrguga jõulukaart
URL: https://www.opiq.ee/kit/192/chapter/10892
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.12
Topics ET: matemaatika, võrguga, jõulukaart
Topics RU: математика
Topics EN: mathematics
Headings: Võrguga jõulukaart

## Tikkimisriidest kaart
URL: https://www.opiq.ee/kit/192/chapter/10893
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.13
Topics ET: matemaatika, tikkimisriidest, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Tikkimisriidest kaart

## Jõulukaartidest kollaaž
URL: https://www.opiq.ee/kit/192/chapter/10894
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.14
Topics ET: matemaatika, jõulukaartidest, kollaaž
Topics RU: математика
Topics EN: mathematics
Headings: Jõulukaartidest kollaaž

## Lillepärg (rühmatöö)
URL: https://www.opiq.ee/kit/192/chapter/10895
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.15
Topics ET: matemaatika, lillepärg, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Lillepärg (rühmatöö)

## Lillepael
URL: https://www.opiq.ee/kit/192/chapter/10896
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.16
Topics ET: matemaatika, lillepael
Topics RU: математика
Topics EN: mathematics
Headings: Lillepael

## Lill
URL: https://www.opiq.ee/kit/192/chapter/10897
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.17
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill

## Lumikellukesed
URL: https://www.opiq.ee/kit/192/chapter/10898
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.18
Topics ET: matemaatika, lumikellukesed
Topics RU: математика
Topics EN: mathematics
Headings: Lumikellukesed

## Päevalilled (rühmatöö)
URL: https://www.opiq.ee/kit/192/chapter/10899
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.19
Topics ET: matemaatika, päevalilled, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Päevalilled (rühmatöö); 1.; 2.

## Õun (rebimine)
URL: https://www.opiq.ee/kit/192/chapter/10882
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.2
Topics ET: matemaatika, rebimine
Topics RU: математика
Topics EN: mathematics
Headings: Õun (rebimine)

## Rebimine
URL: https://www.opiq.ee/kit/192/chapter/10900
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.20
Topics ET: matemaatika, rebimine
Topics RU: математика
Topics EN: mathematics
Headings: Rebimine

## Lillespiraal
URL: https://www.opiq.ee/kit/192/chapter/10901
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.21
Topics ET: matemaatika, lillespiraal
Topics RU: математика
Topics EN: mathematics
Headings: Lillespiraal

## Ruumiline kaart
URL: https://www.opiq.ee/kit/192/chapter/10883
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.3
Topics ET: matemaatika, ruumiline, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline kaart

## Kass ja krokodill (ribatehnika)
URL: https://www.opiq.ee/kit/192/chapter/10884
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.4
Topics ET: matemaatika, kass, krokodill, ribatehnika
Topics RU: математика
Topics EN: mathematics
Headings: Kass ja krokodill (ribatehnika)

## Portree
URL: https://www.opiq.ee/kit/192/chapter/10885
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.5
Topics ET: matemaatika, portree
Topics RU: математика
Topics EN: mathematics
Headings: Portree

## Kuusk (ühistöö)
URL: https://www.opiq.ee/kit/192/chapter/10886
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.6
Topics ET: matemaatika, kuusk, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Kuusk (ühistöö)

## Leevike
URL: https://www.opiq.ee/kit/192/chapter/10887
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.7
Topics ET: matemaatika, leevike
Topics RU: математика
Topics EN: mathematics
Headings: Leevike

## Jõuluvana
URL: https://www.opiq.ee/kit/192/chapter/10888
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.8
Topics ET: matemaatika, jõuluvana
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluvana

## Quilling
URL: https://www.opiq.ee/kit/192/chapter/10889
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 1.9
Topics ET: matemaatika, quilling
Topics RU: математика
Topics EN: mathematics
Headings: Quilling

## Lehepärg
URL: https://www.opiq.ee/kit/192/chapter/10902
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.1
Topics ET: matemaatika, lehepärg
Topics RU: математика
Topics EN: mathematics
Headings: Lehepärg

## Ilutulestik (puhumistehnika)
URL: https://www.opiq.ee/kit/192/chapter/10911
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.10
Topics ET: matemaatika, ilutulestik, puhumistehnika
Topics RU: математика
Topics EN: mathematics
Headings: Ilutulestik (puhumistehnika); 1.; 2.

## Talv (värvusõpetus)
URL: https://www.opiq.ee/kit/192/chapter/10912
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.11
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, värvusõpetus
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Talv (värvusõpetus)

## Talv
URL: https://www.opiq.ee/kit/192/chapter/10913
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.12
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Talv

## Leevikesed ja rasvatihased
URL: https://www.opiq.ee/kit/192/chapter/10914
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.13
Topics ET: matemaatika, leevikesed, rasvatihased
Topics RU: математика
Topics EN: mathematics
Headings: Leevikesed ja rasvatihased

## Leevikesed
URL: https://www.opiq.ee/kit/192/chapter/10915
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.14
Topics ET: matemaatika, leevikesed
Topics RU: математика
Topics EN: mathematics
Headings: Leevikesed

## Tulp
URL: https://www.opiq.ee/kit/192/chapter/10916
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.15
Topics ET: matemaatika, tulp
Topics RU: математика
Topics EN: mathematics
Headings: Tulp

## Lill
URL: https://www.opiq.ee/kit/192/chapter/10917
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.16
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill

## Eri värvi kuused
URL: https://www.opiq.ee/kit/192/chapter/10918
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.17
Topics ET: matemaatika, värvi, kuused
Topics RU: математика
Topics EN: mathematics
Headings: Eri värvi kuused

## Piltide trükkimine
URL: https://www.opiq.ee/kit/192/chapter/10919
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.18
Topics ET: matemaatika, piltide, trükkimine
Topics RU: математика
Topics EN: mathematics
Headings: Piltide trükkimine

## Plastkaartidega maalimine
URL: https://www.opiq.ee/kit/192/chapter/10920
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.19
Topics ET: matemaatika, plastkaartidega, maalimine
Topics RU: математика
Topics EN: mathematics
Headings: Plastkaartidega maalimine

## Värviring
URL: https://www.opiq.ee/kit/192/chapter/10903
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.2
Topics ET: matemaatika, värviring
Topics RU: математика
Topics EN: mathematics
Headings: Värviring

## Värvusõpetus
URL: https://www.opiq.ee/kit/192/chapter/10904
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.3
Topics ET: matemaatika, värvusõpetus
Topics RU: математика
Topics EN: mathematics
Headings: Värvusõpetus

## Sügisene puu (svammitrükk)
URL: https://www.opiq.ee/kit/192/chapter/10905
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.4
Topics ET: matemaatika, taim, taimed, puu, lill, sügisene, svammitrükk
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Sügisene puu (svammitrükk)

## Puuviljad (värvusõpetus)
URL: https://www.opiq.ee/kit/192/chapter/10906
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.5
Topics ET: matemaatika, puuviljad, värvusõpetus
Topics RU: математика
Topics EN: mathematics
Headings: Puuviljad (värvusõpetus)

## Õunapuu (korgitrükk)
URL: https://www.opiq.ee/kit/192/chapter/10907
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.6
Topics ET: matemaatika, õunapuu, korgitrükk
Topics RU: математика
Topics EN: mathematics
Headings: Õunapuu (korgitrükk)

## Küünal
URL: https://www.opiq.ee/kit/192/chapter/10908
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.7
Topics ET: matemaatika, küünal
Topics RU: математика
Topics EN: mathematics
Headings: Küünal

## Tuisupoiss piilub aknast (värvusõpetus)
URL: https://www.opiq.ee/kit/192/chapter/10909
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.8
Topics ET: matemaatika, tuisupoiss, piilub, aknast, värvusõpetus
Topics RU: математика
Topics EN: mathematics
Headings: Tuisupoiss piilub aknast (värvusõpetus)

## Talvine mets (puhumistehnika)
URL: https://www.opiq.ee/kit/192/chapter/10910
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 2.9
Topics ET: matemaatika, talvine, mets, puhumistehnika
Topics RU: математика
Topics EN: mathematics
Headings: Talvine mets (puhumistehnika)

## Elevant ja kaelkirjak
URL: https://www.opiq.ee/kit/192/chapter/10921
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.1
Topics ET: matemaatika, elevant, kaelkirjak
Topics RU: математика
Topics EN: mathematics
Headings: Elevant ja kaelkirjak

## Spoonist jõuluehted
URL: https://www.opiq.ee/kit/192/chapter/10930
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.10
Topics ET: matemaatika, spoonist, jõuluehted
Topics RU: математика
Topics EN: mathematics
Headings: Spoonist jõuluehted

## Krõll (narmaste sõlmimine)
URL: https://www.opiq.ee/kit/192/chapter/10931
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.11
Topics ET: matemaatika, krõll, narmaste, sõlmimine
Topics RU: математика
Topics EN: mathematics
Headings: Krõll (narmaste sõlmimine)

## Ruumiline aknakaunistus papptaldrikutest
URL: https://www.opiq.ee/kit/192/chapter/10932
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.12
Topics ET: matemaatika, ruumiline, aknakaunistus, papptaldrikutest
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline aknakaunistus papptaldrikutest

## Papist rullist kalad
URL: https://www.opiq.ee/kit/192/chapter/10933
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.13
Topics ET: matemaatika, papist, rullist, kalad
Topics RU: математика
Topics EN: mathematics
Headings: Papist rullist kalad

## Nublu
URL: https://www.opiq.ee/kit/192/chapter/10934
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.14
Topics ET: matemaatika, nublu
Topics RU: математика
Topics EN: mathematics
Headings: Nublu

## Munatops
URL: https://www.opiq.ee/kit/192/chapter/10935
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.15
Topics ET: matemaatika, munatops
Topics RU: математика
Topics EN: mathematics
Headings: Munatops

## Muna
URL: https://www.opiq.ee/kit/192/chapter/10936
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.16
Topics ET: matemaatika, muna
Topics RU: математика
Topics EN: mathematics
Headings: Muna

## Lind
URL: https://www.opiq.ee/kit/192/chapter/10937
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.17
Topics ET: matemaatika, lind
Topics RU: математика
Topics EN: mathematics
Headings: Lind

## Kuused
URL: https://www.opiq.ee/kit/192/chapter/10938
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.18
Topics ET: matemaatika, kuused
Topics RU: математика
Topics EN: mathematics
Headings: Kuused

## Lumememm ja jänku (õmblemine)
URL: https://www.opiq.ee/kit/192/chapter/10939
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.19
Topics ET: matemaatika, lumememm, jänku, õmblemine
Topics RU: математика
Topics EN: mathematics
Headings: Lumememm ja jänku (õmblemine)

## Siilid
URL: https://www.opiq.ee/kit/192/chapter/10922
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.2
Topics ET: matemaatika, siilid
Topics RU: математика
Topics EN: mathematics
Headings: Siilid; 1.; 2.

## Volditud lumememm
URL: https://www.opiq.ee/kit/192/chapter/10940
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.20
Topics ET: matemaatika, volditud, lumememm
Topics RU: математика
Topics EN: mathematics
Headings: Volditud lumememm

## Jõululatern
URL: https://www.opiq.ee/kit/192/chapter/10941
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.21
Topics ET: matemaatika, jõululatern
Topics RU: математика
Topics EN: mathematics
Headings: Jõululatern

## Pajupõõsas
URL: https://www.opiq.ee/kit/192/chapter/10942
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.22
Topics ET: matemaatika, pajupõõsas
Topics RU: математика
Topics EN: mathematics
Headings: Pajupõõsas

## Pikk Hermann
URL: https://www.opiq.ee/kit/192/chapter/10943
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.23
Topics ET: matemaatika, pikk, hermann
Topics RU: математика
Topics EN: mathematics
Headings: Pikk Hermann

## Põrsas (värvusõpetus)
URL: https://www.opiq.ee/kit/192/chapter/10944
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.24
Topics ET: matemaatika, põrsas, värvusõpetus
Topics RU: математика
Topics EN: mathematics
Headings: Põrsas (värvusõpetus)

## Veealune maailm
URL: https://www.opiq.ee/kit/192/chapter/10945
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.25
Topics ET: matemaatika, veealune, maailm
Topics RU: математика
Topics EN: mathematics
Headings: Veealune maailm

## Nööbi õmblemine
URL: https://www.opiq.ee/kit/192/chapter/10946
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.26
Topics ET: matemaatika, nööbi, õmblemine
Topics RU: математика
Topics EN: mathematics
Headings: Nööbi õmblemine

## Sokihiir
URL: https://www.opiq.ee/kit/192/chapter/10947
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.27
Topics ET: matemaatika, sokihiir
Topics RU: математика
Topics EN: mathematics
Headings: Sokihiir

## Muffinivormidest kaart
URL: https://www.opiq.ee/kit/192/chapter/10948
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.28
Topics ET: matemaatika, muffinivormidest, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Muffinivormidest kaart

## Nahast kaelakee
URL: https://www.opiq.ee/kit/192/chapter/10949
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.29
Topics ET: matemaatika, nahast, kaelakee
Topics RU: математика
Topics EN: mathematics
Headings: Nahast kaelakee

## Tibu ja liblikas
URL: https://www.opiq.ee/kit/192/chapter/10923
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.3
Topics ET: matemaatika, tibu, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Tibu ja liblikas

## Piimapakist kotike
URL: https://www.opiq.ee/kit/192/chapter/10950
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.30
Topics ET: matemaatika, piimapakist, kotike
Topics RU: математика
Topics EN: mathematics
Headings: Piimapakist kotike

## Kiletrükk
URL: https://www.opiq.ee/kit/192/chapter/10951
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.31
Topics ET: matemaatika, kiletrükk
Topics RU: математика
Topics EN: mathematics
Headings: Kiletrükk

## Mullikiletrükk
URL: https://www.opiq.ee/kit/192/chapter/10952
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.32
Topics ET: matemaatika, mullikiletrükk
Topics RU: математика
Topics EN: mathematics
Headings: Mullikiletrükk

## Reljeefsed pildid
URL: https://www.opiq.ee/kit/192/chapter/10924
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.4
Topics ET: matemaatika, reljeefsed, pildid
Topics RU: математика
Topics EN: mathematics
Headings: Reljeefsed pildid

## Kuivatatud puulehtedest pilt
URL: https://www.opiq.ee/kit/192/chapter/10925
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.5
Topics ET: matemaatika, kuivatatud, puulehtedest, pilt
Topics RU: математика
Topics EN: mathematics
Headings: Kuivatatud puulehtedest pilt

## Lehepärg (ühistöö)
URL: https://www.opiq.ee/kit/192/chapter/10926
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.6
Topics ET: matemaatika, lehepärg, ühistöö
Topics RU: математика
Topics EN: mathematics
Headings: Lehepärg (ühistöö)

## Looduslikest vahenditest loomad
URL: https://www.opiq.ee/kit/192/chapter/10927
Book: Käsitöötuba – Opiq
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, looduslikest, vahenditest
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Looduslikest vahenditest loomad

## Õmmeldud pilt
URL: https://www.opiq.ee/kit/192/chapter/10928
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.8
Topics ET: matemaatika, õmmeldud, pilt
Topics RU: математика
Topics EN: mathematics
Headings: Õmmeldud pilt

## Siil
URL: https://www.opiq.ee/kit/192/chapter/10929
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 3.9
Topics ET: matemaatika, siil
Topics RU: математика
Topics EN: mathematics
Headings: Siil

## Jõuluingel
URL: https://www.opiq.ee/kit/192/chapter/10953
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.1
Topics ET: matemaatika, jõuluingel
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluingel

## Lilled
URL: https://www.opiq.ee/kit/192/chapter/10962
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.10
Topics ET: matemaatika, lilled
Topics RU: математика
Topics EN: mathematics
Headings: Lilled; 1.; 2.; 3.; 4.

## Lillepott
URL: https://www.opiq.ee/kit/192/chapter/10963
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.11
Topics ET: matemaatika, lillepott
Topics RU: математика
Topics EN: mathematics
Headings: Lillepott

## Lilledega kübar
URL: https://www.opiq.ee/kit/192/chapter/10964
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.12
Topics ET: matemaatika, lilledega, kübar
Topics RU: математика
Topics EN: mathematics
Headings: Lilledega kübar

## Pildiraam
URL: https://www.opiq.ee/kit/192/chapter/10965
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.13
Topics ET: matemaatika, pildiraam
Topics RU: математика
Topics EN: mathematics
Headings: Pildiraam

## Lill
URL: https://www.opiq.ee/kit/192/chapter/10966
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.14
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill

## Purjekas
URL: https://www.opiq.ee/kit/192/chapter/10967
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.15
Topics ET: matemaatika, purjekas
Topics RU: математика
Topics EN: mathematics
Headings: Purjekas

## Lill
URL: https://www.opiq.ee/kit/192/chapter/10968
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.16
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill

## Liblikas
URL: https://www.opiq.ee/kit/192/chapter/10969
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.17
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas

## Jõululind
URL: https://www.opiq.ee/kit/192/chapter/10954
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.2
Topics ET: matemaatika, jõululind
Topics RU: математика
Topics EN: mathematics
Headings: Jõululind

## Lill
URL: https://www.opiq.ee/kit/192/chapter/10955
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.3
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill

## Mask
URL: https://www.opiq.ee/kit/192/chapter/10956
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.4
Topics ET: matemaatika, mask
Topics RU: математика
Topics EN: mathematics
Headings: Mask

## Tulp
URL: https://www.opiq.ee/kit/192/chapter/10957
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.5
Topics ET: matemaatika, tulp
Topics RU: математика
Topics EN: mathematics
Headings: Tulp

## Tulp alusega
URL: https://www.opiq.ee/kit/192/chapter/10958
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.6
Topics ET: matemaatika, tulp, alusega
Topics RU: математика
Topics EN: mathematics
Headings: Tulp alusega

## Kahekordne kolmnurk
URL: https://www.opiq.ee/kit/192/chapter/10959
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.7
Topics ET: matemaatika, kahekordne, kolmnurk
Topics RU: математика
Topics EN: mathematics
Headings: Kahekordne kolmnurk

## Liblikas
URL: https://www.opiq.ee/kit/192/chapter/10960
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.8
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas

## Lill emale
URL: https://www.opiq.ee/kit/192/chapter/10961
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._2._osa
Chapter ID: 4.9
Topics ET: matemaatika, taim, taimed, puu, lill, emale
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lill emale

## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/200
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Käsitöötuba – Opiq
URL: https://www.opiq.ee/Kit/Details/200
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 87
Topics ET: matemaatika, käsitöötuba, opiq
Topics RU: математика
Topics EN: mathematics

## Tööks vajalikud materjalid
URL: https://www.opiq.ee/kit/200/chapter/11374
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.1
Topics ET: matemaatika, tööks, vajalikud, materjalid
Topics RU: математика
Topics EN: mathematics
Headings: Tööks vajalikud materjalid

## Kuidas teha kaardile raami
URL: https://www.opiq.ee/kit/200/chapter/11375
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.2
Topics ET: matemaatika, kuidas, teha, kaardile, raami, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha kaardile raami; 1. võimalus; 2. võimalus

## Kuidas teha kaardile lehti
URL: https://www.opiq.ee/kit/200/chapter/11376
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 1.3
Topics ET: matemaatika, kuidas, teha, kaardile, lehti, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha kaardile lehti; 1. võimalus; 2. võimalus; 3. võimalus; 4. võimalus; 5. võimalus

## Volditud lips
URL: https://www.opiq.ee/kit/200/chapter/11377
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.1
Topics ET: matemaatika, volditud, lips
Topics RU: математика
Topics EN: mathematics
Headings: Volditud lips

## Volditud vest
URL: https://www.opiq.ee/kit/200/chapter/11378
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.2
Topics ET: matemaatika, volditud, vest
Topics RU: математика
Topics EN: mathematics
Headings: Volditud vest

## Lihtne volditud särk
URL: https://www.opiq.ee/kit/200/chapter/11379
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.3
Topics ET: matemaatika, lihtne, volditud, särk
Topics RU: математика
Topics EN: mathematics
Headings: Lihtne volditud särk

## Volditud särk
URL: https://www.opiq.ee/kit/200/chapter/11380
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.4
Topics ET: matemaatika, volditud, särk
Topics RU: математика
Topics EN: mathematics
Headings: Volditud särk

## Kikilipsuga kaart
URL: https://www.opiq.ee/kit/200/chapter/11381
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.5
Topics ET: matemaatika, kikilipsuga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kikilipsuga kaart

## Purjekaga kaart
URL: https://www.opiq.ee/kit/200/chapter/11382
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.6
Topics ET: matemaatika, purjekaga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Purjekaga kaart

## Autodega kaart
URL: https://www.opiq.ee/kit/200/chapter/11383
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.7
Topics ET: matemaatika, autodega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Autodega kaart

## Õmmeldud kaart
URL: https://www.opiq.ee/kit/200/chapter/11384
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.8
Topics ET: matemaatika, õmmeldud, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Õmmeldud kaart

## Joonistatud lipsud
URL: https://www.opiq.ee/kit/200/chapter/11385
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 2.9
Topics ET: matemaatika, joonistatud, lipsud
Topics RU: математика
Topics EN: mathematics
Headings: Joonistatud lipsud

## Võrguga kaart
URL: https://www.opiq.ee/kit/200/chapter/11386
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.1
Topics ET: matemaatika, võrguga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Võrguga kaart

## Erineva suurusega küünlad
URL: https://www.opiq.ee/kit/200/chapter/11395
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.10
Topics ET: matemaatika, erineva, suurusega, küünlad
Topics RU: математика
Topics EN: mathematics
Headings: Erineva suurusega küünlad

## Lainepapist küünlad
URL: https://www.opiq.ee/kit/200/chapter/11396
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.11
Topics ET: matemaatika, lainepapist, küünlad
Topics RU: математика
Topics EN: mathematics
Headings: Lainepapist küünlad

## Pabernöörist küünal
URL: https://www.opiq.ee/kit/200/chapter/11397
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.12
Topics ET: matemaatika, pabernöörist, küünal, võimalus
Topics RU: математика
Topics EN: mathematics
Headings: Pabernöörist küünal; 1. võimalus; 2. võimalus

## Pop-up-tehnikas kollaaž
URL: https://www.opiq.ee/kit/200/chapter/11398
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.13
Topics ET: matemaatika, tehnikas, kollaaž
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kollaaž

## Pop-up-tehnikas kaart
URL: https://www.opiq.ee/kit/200/chapter/11399
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.14
Topics ET: matemaatika, tehnikas, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kaart

## Pop-up-tehnikas kera
URL: https://www.opiq.ee/kit/200/chapter/11400
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.15
Topics ET: matemaatika, tehnikas, kera
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kera

## Kalkapaberist jõuluehted
URL: https://www.opiq.ee/kit/200/chapter/11401
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.16
Topics ET: matemaatika, kalkapaberist, jõuluehted
Topics RU: математика
Topics EN: mathematics
Headings: Kalkapaberist jõuluehted

## Joonistatud kuusk
URL: https://www.opiq.ee/kit/200/chapter/11402
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.17
Topics ET: matemaatika, joonistatud, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Joonistatud kuusk

## Kahekordse kolmnurgaga kuusk
URL: https://www.opiq.ee/kit/200/chapter/11403
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.18
Topics ET: matemaatika, kahekordse, kolmnurgaga, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Kahekordse kolmnurgaga kuusk

## Kihiline kuusk
URL: https://www.opiq.ee/kit/200/chapter/11404
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.19
Topics ET: matemaatika, kihiline, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Kihiline kuusk

## Sinepituubist kaart
URL: https://www.opiq.ee/kit/200/chapter/11387
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.2
Topics ET: matemaatika, sinepituubist, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Sinepituubist kaart

## Pooleks volditud ringidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11405
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.20
Topics ET: matemaatika, pooleks, volditud, ringidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pooleks volditud ringidest kuusk

## Ribastatud paberist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11406
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.21
Topics ET: matemaatika, ribastatud, paberist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ribastatud paberist kuusk

## Nöörist või traadist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11407
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.22
Topics ET: matemaatika, nöörist, traadist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Nöörist või traadist kuusk

## Risti punutud paela või traadiga kuusk
URL: https://www.opiq.ee/kit/200/chapter/11408
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.23
Topics ET: matemaatika, risti, punutud, paela, traadiga, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Risti punutud paela või traadiga kuusk

## Pitsilisest paberist, paberiribadest või paeltest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11409
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.24
Topics ET: matemaatika, pitsilisest, paberist, paberiribadest, paeltest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilisest paberist, paberiribadest või paeltest kuusk

## Punutud kuusk
URL: https://www.opiq.ee/kit/200/chapter/11410
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.25
Topics ET: matemaatika, punutud, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Punutud kuusk

## Tikkimisriidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11411
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.26
Topics ET: matemaatika, tikkimisriidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Tikkimisriidest kuusk

## Erinevat värvi kuused
URL: https://www.opiq.ee/kit/200/chapter/11412
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.27
Topics ET: matemaatika, erinevat, värvi, kuused
Topics RU: математика
Topics EN: mathematics
Headings: Erinevat värvi kuused

## Nööpidest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11413
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.28
Topics ET: matemaatika, nööpidest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Nööpidest kuusk

## Ruumiline kuusk
URL: https://www.opiq.ee/kit/200/chapter/11414
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.29
Topics ET: matemaatika, ruumiline, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline kuusk

## Teeküünlatopsist kaart
URL: https://www.opiq.ee/kit/200/chapter/11388
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.3
Topics ET: matemaatika, teeküünlatopsist, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Teeküünlatopsist kaart

## Ribadest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11415
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.30
Topics ET: matemaatika, ribadest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ribadest kuusk

## PVA liimi, metallipuru ja tähekestega kaart
URL: https://www.opiq.ee/kit/200/chapter/11416
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.31
Topics ET: matemaatika, liimi, metallipuru, tähekestega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: PVA liimi, metallipuru ja tähekestega kaart

## Traadi või pärlitega ja PVA liimiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11417
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.32
Topics ET: matemaatika, traadi, pärlitega, liimiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Traadi või pärlitega ja PVA liimiga kaart

## Paberiribadest kuusk
URL: https://www.opiq.ee/kit/200/chapter/11418
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.33
Topics ET: matemaatika, paberiribadest, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Paberiribadest kuusk

## Siksak-tehnikas kuusk
URL: https://www.opiq.ee/kit/200/chapter/11419
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.34
Topics ET: matemaatika, siksak, tehnikas, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Siksak-tehnikas kuusk

## Pitsilisest koogipaberist kuusk
URL: https://www.opiq.ee/kit/200/chapter/11420
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.35
Topics ET: matemaatika, pitsilisest, koogipaberist, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilisest koogipaberist kuusk

## Elupuuoksast kuusk
URL: https://www.opiq.ee/kit/200/chapter/11421
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.36
Topics ET: matemaatika, elupuuoksast, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Elupuuoksast kuusk

## Samblikuga kaart
URL: https://www.opiq.ee/kit/200/chapter/11389
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.4
Topics ET: matemaatika, samblikuga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Samblikuga kaart

## Kingipakkidega kaart
URL: https://www.opiq.ee/kit/200/chapter/11390
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.5
Topics ET: matemaatika, kingipakkidega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kingipakkidega kaart

## Kahepoolse teibiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11391
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.6
Topics ET: matemaatika, kahepoolse, teibiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Kahepoolse teibiga kaart

## Tagasipööratud äärega kaart
URL: https://www.opiq.ee/kit/200/chapter/11392
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.7
Topics ET: matemaatika, tagasipööratud, äärega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Tagasipööratud äärega kaart

## Pabernöörist jõulupärg
URL: https://www.opiq.ee/kit/200/chapter/11393
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.8
Topics ET: matemaatika, pabernöörist, jõulupärg
Topics RU: математика
Topics EN: mathematics
Headings: Pabernöörist jõulupärg

## Ringidest jõulupärg ja kuusk
URL: https://www.opiq.ee/kit/200/chapter/11394
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 3.9
Topics ET: matemaatika, ringidest, jõulupärg, kuusk
Topics RU: математика
Topics EN: mathematics
Headings: Ringidest jõulupärg ja kuusk

## Erikujulised südamed
URL: https://www.opiq.ee/kit/200/chapter/11422
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.1
Topics ET: matemaatika, erikujulised, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Erikujulised südamed

## Ruumiline süda
URL: https://www.opiq.ee/kit/200/chapter/11423
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.2
Topics ET: matemaatika, ruumiline, süda
Topics RU: математика
Topics EN: mathematics
Headings: Ruumiline süda

## Rullitud paberiribadest südamed
URL: https://www.opiq.ee/kit/200/chapter/11424
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.3
Topics ET: matemaatika, rullitud, paberiribadest, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Rullitud paberiribadest südamed

## Pitsiga südamed
URL: https://www.opiq.ee/kit/200/chapter/11425
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 4.4
Topics ET: matemaatika, pitsiga, südamed
Topics RU: математика
Topics EN: mathematics
Headings: Pitsiga südamed

## Lahtikäiv kaart
URL: https://www.opiq.ee/kit/200/chapter/11426
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.1
Topics ET: matemaatika, lahtikäiv, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Lahtikäiv kaart

## Üllatuskaart
URL: https://www.opiq.ee/kit/200/chapter/11427
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.2
Topics ET: matemaatika, üllatuskaart
Topics RU: математика
Topics EN: mathematics
Headings: Üllatuskaart

## Valik kevadpühade kaarte
URL: https://www.opiq.ee/kit/200/chapter/11428
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.3
Topics ET: matemaatika, valik, kevadpühade, kaarte
Topics RU: математика
Topics EN: mathematics
Headings: Valik kevadpühade kaarte

## Pop-up-tehnikas kaart
URL: https://www.opiq.ee/kit/200/chapter/11429
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 5.4
Topics ET: matemaatika, tehnikas, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas kaart

## Lehvikust lill
URL: https://www.opiq.ee/kit/200/chapter/11430
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.1
Topics ET: matemaatika, taim, taimed, puu, lill, lehvikust
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lehvikust lill

## Muffinivormidest kaart
URL: https://www.opiq.ee/kit/200/chapter/11439
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.10
Topics ET: matemaatika, muffinivormidest, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Muffinivormidest kaart

## Tagasipööratud äärtega lill
URL: https://www.opiq.ee/kit/200/chapter/11440
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.11
Topics ET: matemaatika, taim, taimed, puu, lill, tagasipööratud, äärtega
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Tagasipööratud äärtega lill

## Pop-up-tehnikas lilledega kaardid
URL: https://www.opiq.ee/kit/200/chapter/11441
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.12
Topics ET: matemaatika, tehnikas, lilledega, kaardid
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas lilledega kaardid

## Pop-up-tehnikas lillepotid
URL: https://www.opiq.ee/kit/200/chapter/11442
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.13
Topics ET: matemaatika, tehnikas, lillepotid
Topics RU: математика
Topics EN: mathematics
Headings: Pop-up-tehnikas lillepotid

## Tulbikaart
URL: https://www.opiq.ee/kit/200/chapter/11443
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.14
Topics ET: matemaatika, tulbikaart
Topics RU: математика
Topics EN: mathematics
Headings: Tulbikaart

## Lumikellukesed
URL: https://www.opiq.ee/kit/200/chapter/11444
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.15
Topics ET: matemaatika, lumikellukesed
Topics RU: математика
Topics EN: mathematics
Headings: Lumikellukesed

## Volditud lill
URL: https://www.opiq.ee/kit/200/chapter/11445
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.16
Topics ET: matemaatika, taim, taimed, puu, lill, volditud
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Volditud lill

## Volditud lill
URL: https://www.opiq.ee/kit/200/chapter/11446
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.17
Topics ET: matemaatika, taim, taimed, puu, lill, volditud
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Volditud lill

## Paberiribadest lill
URL: https://www.opiq.ee/kit/200/chapter/11447
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.18
Topics ET: matemaatika, taim, taimed, puu, lill, paberiribadest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Paberiribadest lill

## Venivast krepp-paberist lilled
URL: https://www.opiq.ee/kit/200/chapter/11448
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.19
Topics ET: matemaatika, venivast, krepp, paberist, lilled
Topics RU: математика
Topics EN: mathematics
Headings: Venivast krepp-paberist lilled

## Pabernöörist lill
URL: https://www.opiq.ee/kit/200/chapter/11431
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.2
Topics ET: matemaatika, taim, taimed, puu, lill, pabernöörist
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pabernöörist lill

## Rullitud paberiribadest lilled
URL: https://www.opiq.ee/kit/200/chapter/11432
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.3
Topics ET: matemaatika, rullitud, paberiribadest, lilled
Topics RU: математика
Topics EN: mathematics
Headings: Rullitud paberiribadest lilled

## Pooleks volditud ringidest lill
URL: https://www.opiq.ee/kit/200/chapter/11433
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.4
Topics ET: matemaatika, taim, taimed, puu, lill, pooleks, volditud, ringidest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pooleks volditud ringidest lill

## Lainepapist lill
URL: https://www.opiq.ee/kit/200/chapter/11434
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.5
Topics ET: matemaatika, taim, taimed, puu, lill, lainepapist
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Lainepapist lill

## Pooleks volditud südametest lill
URL: https://www.opiq.ee/kit/200/chapter/11435
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.6
Topics ET: matemaatika, taim, taimed, puu, lill, pooleks, volditud, südametest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pooleks volditud südametest lill

## Ringidest lill
URL: https://www.opiq.ee/kit/200/chapter/11436
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.7
Topics ET: matemaatika, taim, taimed, puu, lill, ringidest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Ringidest lill

## Tulbid
URL: https://www.opiq.ee/kit/200/chapter/11437
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.8
Topics ET: matemaatika, tulbid
Topics RU: математика
Topics EN: mathematics
Headings: Tulbid

## Tulbid potis
URL: https://www.opiq.ee/kit/200/chapter/11438
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 6.9
Topics ET: matemaatika, tulbid, potis
Topics RU: математика
Topics EN: mathematics
Headings: Tulbid potis

## Liivakaart
URL: https://www.opiq.ee/kit/200/chapter/11449
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.1
Topics ET: matemaatika, liivakaart
Topics RU: математика
Topics EN: mathematics
Headings: Liivakaart

## Volditud liblikaga kaart
URL: https://www.opiq.ee/kit/200/chapter/11458
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.10
Topics ET: matemaatika, volditud, liblikaga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Volditud liblikaga kaart

## Nööbikaart
URL: https://www.opiq.ee/kit/200/chapter/11450
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.2
Topics ET: matemaatika, nööbikaart
Topics RU: математика
Topics EN: mathematics
Headings: Nööbikaart

## Punutud kaart
URL: https://www.opiq.ee/kit/200/chapter/11451
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.3
Topics ET: matemaatika, punutud, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Punutud kaart

## Pitsilise koogipaberiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11452
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.4
Topics ET: matemaatika, pitsilise, koogipaberiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilise koogipaberiga kaart

## Pildiraamid
URL: https://www.opiq.ee/kit/200/chapter/11453
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.5
Topics ET: matemaatika, pildiraamid
Topics RU: математика
Topics EN: mathematics
Headings: Pildiraamid

## Pitsilise paberiga kaart
URL: https://www.opiq.ee/kit/200/chapter/11454
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.6
Topics ET: matemaatika, pitsilise, paberiga, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Pitsilise paberiga kaart

## Värvilaikudega kaart
URL: https://www.opiq.ee/kit/200/chapter/11455
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.7
Topics ET: matemaatika, värvilaikudega, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Värvilaikudega kaart

## Täpikaart
URL: https://www.opiq.ee/kit/200/chapter/11456
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.8
Topics ET: matemaatika, täpikaart
Topics RU: математика
Topics EN: mathematics
Headings: Täpikaart

## Kujundirauaga tehtud kaardid
URL: https://www.opiq.ee/kit/200/chapter/11457
Book: Käsitöötuba – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kunsti-_ja_tööõpetus._4._osa._tähtpäeva­kaardid
Chapter ID: 7.9
Topics ET: matemaatika, kujundirauaga, tehtud, kaardid
Topics RU: математика
Topics EN: mathematics
Headings: Kujundirauaga tehtud kaardid

## Творческая мастерская – Opiq
URL: https://www.opiq.ee/Kit/Details/371
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 179
Topics ET: matemaatika, opiq
Topics RU: математика, творческая, мастерская
Topics EN: mathematics

## Творческая мастерская – Opiq
URL: https://www.opiq.ee/Kit/Details/371
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 269
Topics ET: matemaatika, opiq
Topics RU: математика, творческая, мастерская
Topics EN: mathematics

## Объемные грибы (работа с мятой бумагой)
URL: https://www.opiq.ee/kit/371/chapter/20257
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, объемные, грибы, работа, мятой, бумагой
Topics EN: mathematics
Headings: Объемные грибы (работа с мятой бумагой)

## Открытка с объемной елочкой
URL: https://www.opiq.ee/kit/371/chapter/20266
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.10
Topics ET: matemaatika
Topics RU: математика, открытка, объемной, елочкой
Topics EN: mathematics
Headings: Открытка с объемной елочкой

## Объемная елочка
URL: https://www.opiq.ee/kit/371/chapter/20267
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.11
Topics ET: matemaatika
Topics RU: математика, объемная, елочка
Topics EN: mathematics
Headings: Объемная елочка

## Рождественская открытка с сеткой
URL: https://www.opiq.ee/kit/371/chapter/20268
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.12
Topics ET: matemaatika
Topics RU: математика, рождественская, открытка, сеткой
Topics EN: mathematics
Headings: Рождественская открытка с сеткой

## Открытка из ткани
URL: https://www.opiq.ee/kit/371/chapter/20269
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.13
Topics ET: matemaatika
Topics RU: математика, открытка, ткани
Topics EN: mathematics
Headings: Открытка из ткани

## Коллаж из рождественских открыток
URL: https://www.opiq.ee/kit/371/chapter/20270
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.14
Topics ET: matemaatika
Topics RU: математика, коллаж, рождественских, открыток
Topics EN: mathematics
Headings: Коллаж из рождественских открыток

## Венок из цветов (групповая работа)
URL: https://www.opiq.ee/kit/371/chapter/20271
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.15
Topics ET: matemaatika
Topics RU: математика, венок, цветов, групповая, работа
Topics EN: mathematics
Headings: Венок из цветов (групповая работа)

## Гирлянда из цветов
URL: https://www.opiq.ee/kit/371/chapter/20272
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.16
Topics ET: matemaatika
Topics RU: математика, гирлянда, цветов
Topics EN: mathematics
Headings: Гирлянда из цветов

## Цветы
URL: https://www.opiq.ee/kit/371/chapter/20273
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.17
Topics ET: matemaatika
Topics RU: математика, цветы
Topics EN: mathematics
Headings: Цветы

## Подснежники
URL: https://www.opiq.ee/kit/371/chapter/20274
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.18
Topics ET: matemaatika
Topics RU: математика, подснежники
Topics EN: mathematics
Headings: Подснежники

## Подсолнухи (групповая работа)
URL: https://www.opiq.ee/kit/371/chapter/20275
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.19
Topics ET: matemaatika
Topics RU: математика, подсолнухи, групповая, работа
Topics EN: mathematics
Headings: Подсолнухи (групповая работа); 1.; 2.

## Яблоко (работа с рваной бумагой)
URL: https://www.opiq.ee/kit/371/chapter/20258
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, яблоко, работа, рваной, бумагой
Topics EN: mathematics
Headings: Яблоко (работа с рваной бумагой)

## Картина из рваной бумаги
URL: https://www.opiq.ee/kit/371/chapter/20276
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.20
Topics ET: matemaatika
Topics RU: математика, картина, рваной, бумаги
Topics EN: mathematics
Headings: Картина из рваной бумаги

## Цветочная спираль
URL: https://www.opiq.ee/kit/371/chapter/20277
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.21
Topics ET: matemaatika
Topics RU: математика, цветочная, спираль
Topics EN: mathematics
Headings: Цветочная спираль

## Объемная открытка
URL: https://www.opiq.ee/kit/371/chapter/20259
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, объемная, открытка
Topics EN: mathematics
Headings: Объемная открытка

## Кот и крокодил (плетение из бумажных полосок)
URL: https://www.opiq.ee/kit/371/chapter/20260
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, крокодил, плетение, бумажных, полосок
Topics EN: mathematics
Headings: Кот и крокодил (плетение из бумажных полосок)

## Портрет
URL: https://www.opiq.ee/kit/371/chapter/20261
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, портрет
Topics EN: mathematics
Headings: Портрет

## Елка (совместная работа)
URL: https://www.opiq.ee/kit/371/chapter/20262
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, елка, совместная, работа
Topics EN: mathematics
Headings: Елка (совместная работа)

## Снегирь
URL: https://www.opiq.ee/kit/371/chapter/20263
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.7
Topics ET: matemaatika
Topics RU: математика, снегирь
Topics EN: mathematics
Headings: Снегирь

## Дед Мороз
URL: https://www.opiq.ee/kit/371/chapter/20264
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.8
Topics ET: matemaatika
Topics RU: математика, мороз
Topics EN: mathematics
Headings: Дед Мороз

## Квиллинг (бумагокручение)
URL: https://www.opiq.ee/kit/371/chapter/20265
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 1.9
Topics ET: matemaatika
Topics RU: математика, квиллинг, бумагокручение
Topics EN: mathematics
Headings: Квиллинг (бумагокручение)

## Венок из листьев
URL: https://www.opiq.ee/kit/371/chapter/20278
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, венок, листьев
Topics EN: mathematics
Headings: Венок из листьев

## Салют (техника сдувания)
URL: https://www.opiq.ee/kit/371/chapter/20287
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.10
Topics ET: matemaatika
Topics RU: математика, салют, техника, сдувания
Topics EN: mathematics
Headings: Салют (техника сдувания); 1.; 2.

## Зима (цветоведение)
URL: https://www.opiq.ee/kit/371/chapter/20288
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.11
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, цветоведение
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Зима (цветоведение)

## Зима
URL: https://www.opiq.ee/kit/371/chapter/20289
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.12
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Зима

## Снегири и синицы
URL: https://www.opiq.ee/kit/371/chapter/20290
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.13
Topics ET: matemaatika
Topics RU: математика, снегири, синицы
Topics EN: mathematics
Headings: Снегири и синицы

## Снегири
URL: https://www.opiq.ee/kit/371/chapter/20291
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.14
Topics ET: matemaatika
Topics RU: математика, снегири
Topics EN: mathematics
Headings: Снегири

## Тюльпан
URL: https://www.opiq.ee/kit/371/chapter/20292
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.15
Topics ET: matemaatika
Topics RU: математика, тюльпан
Topics EN: mathematics
Headings: Тюльпан

## Цветок
URL: https://www.opiq.ee/kit/371/chapter/20293
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.16
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Цветок

## Разноцветные елочки
URL: https://www.opiq.ee/kit/371/chapter/20294
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.17
Topics ET: matemaatika
Topics RU: математика, разноцветные, елочки
Topics EN: mathematics
Headings: Разноцветные елочки

## Печатание картинок
URL: https://www.opiq.ee/kit/371/chapter/20295
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.18
Topics ET: matemaatika
Topics RU: математика, печатание, картинок
Topics EN: mathematics
Headings: Печатание картинок

## Рисование пластиковой картой
URL: https://www.opiq.ee/kit/371/chapter/20296
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.19
Topics ET: matemaatika
Topics RU: математика, рисование, пластиковой, картой
Topics EN: mathematics
Headings: Рисование пластиковой картой

## Цветовой круг (цветоведение)
URL: https://www.opiq.ee/kit/371/chapter/20279
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, цветовой, круг, цветоведение
Topics EN: mathematics
Headings: Цветовой круг (цветоведение)

## Зонтик (цветоведение)
URL: https://www.opiq.ee/kit/371/chapter/20280
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, зонтик, цветоведение
Topics EN: mathematics
Headings: Зонтик (цветоведение)

## Осеннее дерево (оттиски губкой)
URL: https://www.opiq.ee/kit/371/chapter/20281
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.4
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, осеннее, оттиски, губкой
Topics EN: mathematics, plant, plants, tree, flower
Headings: Осеннее дерево (оттиски губкой)

## Фрукты (цветоведение)
URL: https://www.opiq.ee/kit/371/chapter/20282
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, фрукты, цветоведение
Topics EN: mathematics
Headings: Фрукты (цветоведение)

## Яблоня (оттиски пробкой)
URL: https://www.opiq.ee/kit/371/chapter/20283
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, яблоня, оттиски, пробкой
Topics EN: mathematics
Headings: Яблоня (оттиски пробкой)

## Свеча
URL: https://www.opiq.ee/kit/371/chapter/20284
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, свеча
Topics EN: mathematics
Headings: Свеча

## Заснеженное окно (цветоведение)
URL: https://www.opiq.ee/kit/371/chapter/20285
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, заснеженное, окно, цветоведение
Topics EN: mathematics
Headings: Заснеженное окно (цветоведение)

## Зимний лес (техника сдувания)
URL: https://www.opiq.ee/kit/371/chapter/20286
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика, зимний, техника, сдувания
Topics EN: mathematics
Headings: Зимний лес (техника сдувания)

## Слон и жираф
URL: https://www.opiq.ee/kit/371/chapter/20297
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, слон, жираф
Topics EN: mathematics
Headings: Слон и жираф

## Рождественские украшения из шпона
URL: https://www.opiq.ee/kit/371/chapter/20306
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.10
Topics ET: matemaatika
Topics RU: математика, рождественские, украшения, шпона
Topics EN: mathematics
Headings: Рождественские украшения из шпона

## Крыль (плетение)
URL: https://www.opiq.ee/kit/371/chapter/20307
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.11
Topics ET: matemaatika
Topics RU: математика, крыль, плетение
Topics EN: mathematics
Headings: Крыль (плетение)

## Объемное украшение для окна из бумажной тарелки
URL: https://www.opiq.ee/kit/371/chapter/20308
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.12
Topics ET: matemaatika
Topics RU: математика, объемное, украшение, окна, бумажной, тарелки
Topics EN: mathematics
Headings: Объемное украшение для окна из бумажной тарелки

## Рыбки из картонной втулки
URL: https://www.opiq.ee/kit/371/chapter/20309
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.13
Topics ET: matemaatika
Topics RU: математика, рыбки, картонной, втулки
Topics EN: mathematics
Headings: Рыбки из картонной втулки

## Нублик
URL: https://www.opiq.ee/kit/371/chapter/20310
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.14
Topics ET: matemaatika
Topics RU: математика, нублик
Topics EN: mathematics
Headings: Нублик

## Подставка для яйца
URL: https://www.opiq.ee/kit/371/chapter/20311
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.15
Topics ET: matemaatika
Topics RU: математика, подставка, яйца
Topics EN: mathematics
Headings: Подставка для яйца

## Яйцо
URL: https://www.opiq.ee/kit/371/chapter/20312
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.16
Topics ET: matemaatika
Topics RU: математика, яйцо
Topics EN: mathematics
Headings: Яйцо

## Птица
URL: https://www.opiq.ee/kit/371/chapter/20313
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.17
Topics ET: matemaatika
Topics RU: математика, птица
Topics EN: mathematics
Headings: Птица

## Елочки
URL: https://www.opiq.ee/kit/371/chapter/20314
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.18
Topics ET: matemaatika
Topics RU: математика, елочки
Topics EN: mathematics
Headings: Елочки

## Снеговик и зайчик (шитье)
URL: https://www.opiq.ee/kit/371/chapter/20315
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.19
Topics ET: matemaatika
Topics RU: математика, снеговик, зайчик, шитье
Topics EN: mathematics
Headings: Снеговик и зайчик (шитье)

## Ежики
URL: https://www.opiq.ee/kit/371/chapter/20298
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, ежики
Topics EN: mathematics
Headings: Ежики; 1.; 2.

## Снеговик из бумаги гармошкой
URL: https://www.opiq.ee/kit/371/chapter/20316
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.20
Topics ET: matemaatika
Topics RU: математика, снеговик, бумаги, гармошкой
Topics EN: mathematics
Headings: Снеговик из бумаги гармошкой

## Рождественский фонарик
URL: https://www.opiq.ee/kit/371/chapter/20317
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.21
Topics ET: matemaatika
Topics RU: математика, рождественский, фонарик
Topics EN: mathematics
Headings: Рождественский фонарик

## Куст вербы
URL: https://www.opiq.ee/kit/371/chapter/20318
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.22
Topics ET: matemaatika
Topics RU: математика, куст, вербы
Topics EN: mathematics
Headings: Куст вербы

## Длинный Герман
URL: https://www.opiq.ee/kit/371/chapter/20319
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.23
Topics ET: matemaatika
Topics RU: математика, длинный, герман
Topics EN: mathematics
Headings: Длинный Герман

## Поросенок (цветоведение)
URL: https://www.opiq.ee/kit/371/chapter/20320
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.24
Topics ET: matemaatika
Topics RU: математика, поросенок, цветоведение
Topics EN: mathematics
Headings: Поросенок (цветоведение)

## Подводный мир
URL: https://www.opiq.ee/kit/371/chapter/20321
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.25
Topics ET: matemaatika
Topics RU: математика, подводный
Topics EN: mathematics
Headings: Подводный мир

## Пришивание пуговиц
URL: https://www.opiq.ee/kit/371/chapter/20322
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.26
Topics ET: matemaatika
Topics RU: математика, пришивание, пуговиц
Topics EN: mathematics
Headings: Пришивание пуговиц

## Мышка из носка
URL: https://www.opiq.ee/kit/371/chapter/20323
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.27
Topics ET: matemaatika
Topics RU: математика, мышка, носка
Topics EN: mathematics
Headings: Мышка из носка

## Открытка из формочек для маффинов
URL: https://www.opiq.ee/kit/371/chapter/20324
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.28
Topics ET: matemaatika
Topics RU: математика, открытка, формочек, маффинов
Topics EN: mathematics
Headings: Открытка из формочек для маффинов

## Ожерелье из кожи
URL: https://www.opiq.ee/kit/371/chapter/20325
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.29
Topics ET: matemaatika
Topics RU: математика, ожерелье, кожи
Topics EN: mathematics
Headings: Ожерелье из кожи

## Цыпленок и бабочка
URL: https://www.opiq.ee/kit/371/chapter/20299
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, цыпленок, бабочка
Topics EN: mathematics
Headings: Цыпленок и бабочка

## Сумочка из молочного пакета
URL: https://www.opiq.ee/kit/371/chapter/20326
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.30
Topics ET: matemaatika
Topics RU: математика, сумочка, молочного, пакета
Topics EN: mathematics
Headings: Сумочка из молочного пакета

## Оттиски пленкой
URL: https://www.opiq.ee/kit/371/chapter/20327
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.31
Topics ET: matemaatika
Topics RU: математика, оттиски, пленкой
Topics EN: mathematics
Headings: Оттиски пленкой

## Оттиски пузырчатой пленкой
URL: https://www.opiq.ee/kit/371/chapter/20328
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.32
Topics ET: matemaatika
Topics RU: математика, оттиски, пузырчатой, пленкой
Topics EN: mathematics
Headings: Оттиски пузырчатой пленкой

## Рельефные картинки
URL: https://www.opiq.ee/kit/371/chapter/20300
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, рельефные, картинки
Topics EN: mathematics
Headings: Рельефные картинки

## Картинка из сухих листьев
URL: https://www.opiq.ee/kit/371/chapter/20301
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, картинка, сухих, листьев
Topics EN: mathematics
Headings: Картинка из сухих листьев

## Венок из листьев (совместная работа)
URL: https://www.opiq.ee/kit/371/chapter/20302
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика, венок, листьев, совместная, работа
Topics EN: mathematics
Headings: Венок из листьев (совместная работа)

## Животные из природных материалов
URL: https://www.opiq.ee/kit/371/chapter/20303
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.7
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, природных, материалов
Topics EN: mathematics, animal, animals, birds, insects
Headings: Животные из природных материалов

## Вышитая картинка
URL: https://www.opiq.ee/kit/371/chapter/20304
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика, вышитая, картинка
Topics EN: mathematics
Headings: Вышитая картинка

## Ежик
URL: https://www.opiq.ee/kit/371/chapter/20305
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 3.9
Topics ET: matemaatika
Topics RU: математика, ежик
Topics EN: mathematics
Headings: Ежик

## Рождественский ангел
URL: https://www.opiq.ee/kit/371/chapter/20329
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, рождественский, ангел
Topics EN: mathematics
Headings: Рождественский ангел

## Цветы
URL: https://www.opiq.ee/kit/371/chapter/20338
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.10
Topics ET: matemaatika
Topics RU: математика, цветы
Topics EN: mathematics
Headings: Цветы; 1.; 2.; 3.; 4.

## Цветочный горшок
URL: https://www.opiq.ee/kit/371/chapter/20339
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика, цветочный, горшок
Topics EN: mathematics
Headings: Цветочный горшок

## Шляпа с цветами
URL: https://www.opiq.ee/kit/371/chapter/20340
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.12
Topics ET: matemaatika
Topics RU: математика, шляпа, цветами
Topics EN: mathematics
Headings: Шляпа с цветами

## Рама для фотографии
URL: https://www.opiq.ee/kit/371/chapter/20341
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.13
Topics ET: matemaatika
Topics RU: математика, рама, фотографии
Topics EN: mathematics
Headings: Рама для фотографии

## Цветок
URL: https://www.opiq.ee/kit/371/chapter/20342
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.14
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Цветок

## Парусник
URL: https://www.opiq.ee/kit/371/chapter/20343
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.15
Topics ET: matemaatika
Topics RU: математика, парусник
Topics EN: mathematics
Headings: Парусник

## Цветок
URL: https://www.opiq.ee/kit/371/chapter/20344
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.16
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Цветок

## Бабочка
URL: https://www.opiq.ee/kit/371/chapter/20345
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.17
Topics ET: matemaatika
Topics RU: математика, бабочка
Topics EN: mathematics
Headings: Бабочка

## Рождественская птица
URL: https://www.opiq.ee/kit/371/chapter/20330
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, рождественская, птица
Topics EN: mathematics
Headings: Рождественская птица

## Цветок
URL: https://www.opiq.ee/kit/371/chapter/20331
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.3
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Цветок

## Маска
URL: https://www.opiq.ee/kit/371/chapter/20332
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, маска
Topics EN: mathematics
Headings: Маска

## Тюльпан
URL: https://www.opiq.ee/kit/371/chapter/20333
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, тюльпан
Topics EN: mathematics
Headings: Тюльпан

## Подставка для тюльпана
URL: https://www.opiq.ee/kit/371/chapter/20334
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, подставка, тюльпана
Topics EN: mathematics
Headings: Подставка для тюльпана

## Двойной треугольник
URL: https://www.opiq.ee/kit/371/chapter/20335
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика, двойной, треугольник
Topics EN: mathematics
Headings: Двойной треугольник

## Бабочка
URL: https://www.opiq.ee/kit/371/chapter/20336
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика, бабочка
Topics EN: mathematics
Headings: Бабочка

## Цветок для мамы
URL: https://www.opiq.ee/kit/371/chapter/20337
Book: Творческая мастерская – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: трудовое_обучение_и_искусство._2_часть
Chapter ID: 4.9
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, мамы
Topics EN: mathematics, plant, plants, tree, flower
Headings: Цветок для мамы
