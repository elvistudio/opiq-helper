## РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
URL: https://www.opiq.ee/Kit/Details/504
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 1
Topics ET: matemaatika, opiq
Topics RU: математика, русское, слово, чтение
Topics EN: mathematics

## РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
URL: https://www.opiq.ee/Kit/Details/504
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 57
Topics ET: matemaatika, opiq
Topics RU: математика, русское, слово, чтение
Topics EN: mathematics

## ИВАН БУНИН. Листопад
URL: https://www.opiq.ee/kit/504/chapter/27658
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, иван, бунин, листопад, давай, обсудим
Topics EN: mathematics
Headings: ИВАН БУНИН. Листопад; Давай обсудим; Задания

## АПОЛЛОН МАЙКОВ. Осень
URL: https://www.opiq.ee/kit/504/chapter/27659
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 1.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, аполлон, майков, давай, обсудим
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: АПОЛЛОН МАЙКОВ. Осень; Давай обсудим; Задания

## СЕРГЕЙ ЕСЕНИН. Нивы сжаты, рощи голы…
URL: https://www.opiq.ee/kit/504/chapter/27660
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, сергей, есенин, нивы, сжаты, рощи, голы, давай, обсудим
Topics EN: mathematics
Headings: СЕРГЕЙ ЕСЕНИН. Нивы сжаты, рощи голы…; Давай обсудим; Задания

## ИВАН СОКОЛОВ-МИКИТОВ. Осень в лесу
URL: https://www.opiq.ee/kit/504/chapter/27661
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 1.4
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, иван, соколов, микитов, лесу, улетают, журавли, давай, обсудим
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: ИВАН СОКОЛОВ-МИКИТОВ. Осень в лесу; Улетают журавли; Давай обсудим

## МИХАИЛ ПРИШВИН. Листопад
URL: https://www.opiq.ee/kit/504/chapter/27662
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, михаил, пришвин, листопад, давай, обсудим
Topics EN: mathematics
Headings: МИХАИЛ ПРИШВИН. Листопад; Давай обсудим; Задания

## СЕРГЕЙ КОЗЛОВ. Мы будем приходить и дышать
URL: https://www.opiq.ee/kit/504/chapter/27663
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, сергей, козлов, будем, приходить, дышать, давай, обсудим
Topics EN: mathematics
Headings: СЕРГЕЙ КОЗЛОВ. Мы будем приходить и дышать; Давай обсудим; Задания

## НИКОЛАЙ НОСОВ. Витя Малеев в школе и дома
URL: https://www.opiq.ee/kit/504/chapter/27664
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, николай, носов, витя, малеев, школе, дома, давай, обсудим
Topics EN: mathematics
Headings: НИКОЛАЙ НОСОВ. Витя Малеев в школе и дома; Давай обсудим; Задания

## ЮННА МОРИЦ. Это очень интересно
URL: https://www.opiq.ee/kit/504/chapter/27665
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, юнна, мориц, очень, интересно, давай, обсудим
Topics EN: mathematics
Headings: ЮННА МОРИЦ. Это очень интересно; Давай обсудим; Задания

## ВИКТОР ДРАГУНСКИЙ. Главные реки
URL: https://www.opiq.ee/kit/504/chapter/27666
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, виктор, драгунский, главные, реки, давай, обсудим
Topics EN: mathematics
Headings: ВИКТОР ДРАГУНСКИЙ. Главные реки; Давай обсудим; Задания

## ВИКТОР ГОЛЯВКИН. Путешественник
URL: https://www.opiq.ee/kit/504/chapter/27667
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, виктор, голявкин, путешественник, давай, обсудим
Topics EN: mathematics
Headings: ВИКТОР ГОЛЯВКИН. Путешественник; Давай обсудим; Задания

## ИРИНА ПИВОВАРОВА. Сочинение
URL: https://www.opiq.ee/kit/504/chapter/27668
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, ирина, пивоварова, сочинение, давай, обсудим
Topics EN: mathematics
Headings: ИРИНА ПИВОВАРОВА. Сочинение; Давай обсудим; Задания

## ЛЕОНИД КАМИНСКИЙ. Чего только не случилось…
URL: https://www.opiq.ee/kit/504/chapter/27669
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, леонид, каминский, чего, только, случилось, давай, обсудим
Topics EN: mathematics
Headings: ЛЕОНИД КАМИНСКИЙ. Чего только не случилось…; Давай обсудим; Задания

## УЛЬФ СТАРК. Умеешь ли ты свистеть, Йоханна?
URL: https://www.opiq.ee/kit/504/chapter/27670
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, ульф, старк, умеешь, свистеть, йоханна, давай, обсудим
Topics EN: mathematics
Headings: УЛЬФ СТАРК. Умеешь ли ты свистеть, Йоханна?; Давай обсудим; Задания

## ЮННА МОРИЦ. Сто фантазий
URL: https://www.opiq.ee/kit/504/chapter/27671
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, юнна, мориц, фантазий, давай, обсудим
Topics EN: mathematics
Headings: ЮННА МОРИЦ. Сто фантазий; Давай обсудим; Задания

## ЛАЗАРЬ ЛАГИН. Старик Хоттабыч
URL: https://www.opiq.ee/kit/504/chapter/27672
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, лазарь, лагин, старик, хоттабыч, таинственная, бутылка, приключение, метро, давай
Topics EN: mathematics
Headings: ЛАЗАРЬ ЛАГИН. Старик Хоттабыч; Таинственная бутылка; Старик Хоттабыч; Приключение в метро; Давай обсудим; Задания

## ТАТЬЯНА ПОНОМАРЁВА. Автобус
URL: https://www.opiq.ee/kit/504/chapter/27673
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, татьяна, пономар, автобус, давай, обсудим
Topics EN: mathematics
Headings: ТАТЬЯНА ПОНОМАРЁВА. Автобус; Давай обсудим; Задания

## ТАМАРА КРЮКОВА. Дом вверх дном
URL: https://www.opiq.ee/kit/504/chapter/27674
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, тамара, крюкова, вверх, дном, глава, первая, тришка, давай, обсудим
Topics EN: mathematics
Headings: ТАМАРА КРЮКОВА. Дом вверх дном; ГЛАВА ПЕРВАЯ. Тришка; Давай обсудим; Задания; ГЛАВА ВОСЬМАЯ. Озоновая дыра, или Спасение человечества

## КЕЙТ ДИКАМИЛЛО. Удивительное путешествие кролика Эдварда
URL: https://www.opiq.ee/kit/504/chapter/27675
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, кейт, дикамилло, удивительное, путешествие, кролика, эдварда, давай, обсудим
Topics EN: mathematics
Headings: КЕЙТ ДИКАМИЛЛО. Удивительное путешествие кролика Эдварда; * * *; Давай обсудим; Задания; Удивительное путешествие кролика Эдварда (2); * * *​; Удивительное путешествие кролика Эдварда (3); Удивительное путешествие кролика Эдварда (4); Удивительное путешествие кролика Эдварда (5)

## АГНИЯ БАРТО. Посторонняя кошка
URL: https://www.opiq.ee/kit/504/chapter/27676
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, агния, барто, посторонняя, кошка, давай, обсудим
Topics EN: mathematics
Headings: АГНИЯ БАРТО. Посторонняя кошка; Давай обсудим; Задания

## ГАВРИИЛ ТРОЕПОЛЬСКИЙ. Белый Бим Чёрное ухо
URL: https://www.opiq.ee/kit/504/chapter/27677
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, гавриил, троепольский, белый, рное, двое, одной, комнате, давай, обсудим
Topics EN: mathematics
Headings: ГАВРИИЛ ТРОЕПОЛЬСКИЙ. Белый Бим Чёрное ухо; Двое в одной комнате; * * *; Давай обсудим; Задания

## ДМИТРИЙ МАМИН-СИБИРЯК. Приёмыш
URL: https://www.opiq.ee/kit/504/chapter/27678
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, дмитрий, мамин, сибиряк, давай, обсудим
Topics EN: mathematics
Headings: ДМИТРИЙ МАМИН-СИБИРЯК. Приёмыш; Давай обсудим; Задания

## АНТОН ХАНСЕН ТАММСААРЕ. Наш лисёнок
URL: https://www.opiq.ee/kit/504/chapter/27679
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, антон, хансен, таммсааре, давай, обсудим
Topics EN: mathematics
Headings: АНТОН ХАНСЕН ТАММСААРЕ. Наш лисёнок; * * *; Давай обсудим; Задания

## ТАТЬЯНА ПОНОМАРЁВА. Лето в чайнике
URL: https://www.opiq.ee/kit/504/chapter/27680
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 4.5
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, татьяна, пономар, чайнике, давай, обсудим
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: ТАТЬЯНА ПОНОМАРЁВА. Лето в чайнике; Давай обсудим; Задания

## МАША ВАЙСМАН. Лучший друг медуз
URL: https://www.opiq.ee/kit/504/chapter/27681
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, маша, вайсман, лучший, друг, медуз, давай, обсудим
Topics EN: mathematics
Headings: МАША ВАЙСМАН. Лучший друг медуз; Давай обсудим; Задания

## АЛЕКСАНДР ПУШКИН. Вот север, тучи нагоняя…
URL: https://www.opiq.ee/kit/504/chapter/27682
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, александр, пушкин, север, тучи, нагоняя, давай, обсудим
Topics EN: mathematics
Headings: АЛЕКСАНДР ПУШКИН. Вот север, тучи нагоняя…; * * *; Давай обсудим

## ВИКТОР КРОТОВ. Сказочный дворец
URL: https://www.opiq.ee/kit/504/chapter/27691
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.10
Topics ET: matemaatika
Topics RU: математика, виктор, кротов, сказочный, дворец, давай, обсудим
Topics EN: mathematics
Headings: ВИКТОР КРОТОВ. Сказочный дворец; Давай обсудим; Задания

## СЕРГЕЙ ЕСЕНИН. Поёт зима – аукает…
URL: https://www.opiq.ee/kit/504/chapter/27683
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, сергей, есенин, аукает, давай, обсудим
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: СЕРГЕЙ ЕСЕНИН. Поёт зима – аукает…; Давай обсудим; Задания

## ИВАН СОКОЛОВ-МИКИТОВ. Зимняя ночь
URL: https://www.opiq.ee/kit/504/chapter/27684
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, иван, соколов, микитов, зимняя, ночь, давай, обсудим
Topics EN: mathematics
Headings: ИВАН СОКОЛОВ-МИКИТОВ. Зимняя ночь; Давай обсудим

## САША ЧЁРНЫЙ. Снежная баба
URL: https://www.opiq.ee/kit/504/chapter/27685
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, саша, рный, снежная, баба, давай, обсудим
Topics EN: mathematics
Headings: САША ЧЁРНЫЙ. Снежная баба; Давай обсудим; Задания

## СЕРГЕЙ МИХАЛКОВ. Новогодняя быль
URL: https://www.opiq.ee/kit/504/chapter/27686
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.5
Topics ET: matemaatika
Topics RU: математика, сергей, михалков, новогодняя, быль, давай, обсудим
Topics EN: mathematics
Headings: СЕРГЕЙ МИХАЛКОВ. Новогодняя быль; Давай обсудим; Задания

## ВИКТОР ДРАГУНСКИЙ. Кот в сапогах
URL: https://www.opiq.ee/kit/504/chapter/27687
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.6
Topics ET: matemaatika
Topics RU: математика, виктор, драгунский, сапогах, давай, обсудим
Topics EN: mathematics
Headings: ВИКТОР ДРАГУНСКИЙ. Кот в сапогах; Давай обсудим; Задания

## ТАТЬЯНА ПОНОМАРЁВА. Прогноз погоды
URL: https://www.opiq.ee/kit/504/chapter/27688
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.7
Topics ET: matemaatika
Topics RU: математика, татьяна, пономар, прогноз, погоды, давай, обсудим
Topics EN: mathematics
Headings: ТАТЬЯНА ПОНОМАРЁВА. Прогноз погоды; Давай обсудим; Задания

## АНДРУС КИВИРЯХК. Хендрик и лыжи
URL: https://www.opiq.ee/kit/504/chapter/27689
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.8
Topics ET: matemaatika
Topics RU: математика, андрус, кивиряхк, хендрик, лыжи, давай, обсудим
Topics EN: mathematics
Headings: АНДРУС КИВИРЯХК. Хендрик и лыжи; Давай обсудим; Задания

## ВИКТОР КРОТОВ. Норка насквозь
URL: https://www.opiq.ee/kit/504/chapter/27690
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 5.9
Topics ET: matemaatika
Topics RU: математика, виктор, кротов, норка, насквозь, давай, обсудим
Topics EN: mathematics
Headings: ВИКТОР КРОТОВ. Норка насквозь; Давай обсудим; Задания

## ГАНС ХРИСТИАН АНДЕРСЕН. Стойкий оловянный солдатик
URL: https://www.opiq.ee/kit/504/chapter/27692
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, ганс, христиан, андерсен, стойкий, оловянный, солдатик, давай, обсудим
Topics EN: mathematics
Headings: ГАНС ХРИСТИАН АНДЕРСЕН. Стойкий оловянный солдатик; Давай обсудим; Задания

## СЕЛЬМА ЛАГЕРЛЁФ. Чудесное путешествие Нильса с дикими гусями
URL: https://www.opiq.ee/kit/504/chapter/27693
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, сельма, лагерл, чудесное, путешествие, нильса, дикими, гусями, глава, первая
Topics EN: mathematics
Headings: СЕЛЬМА ЛАГЕРЛЁФ. Чудесное путешествие Нильса с дикими гусями; ГЛАВА ПЕРВАЯ. Лесной гном; Давай обсудим; Задания; ГЛАВА ПЕРВАЯ. Лесной гном (2); ГЛАВА ВТОРАЯ. Верхом на гусе; ГЛАВА ВТОРАЯ. Верхом на гусе (2); ГЛАВА ТРЕТЬЯ. Ночной вор

## ИВАН КРЫЛОВ. Басни
URL: https://www.opiq.ee/kit/504/chapter/27694
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, иван, крылов, басни, кукушка, петух, давай, обсудим, лебедь
Topics EN: mathematics
Headings: ИВАН КРЫЛОВ. Басни; Кукушка и Петух; Давай обсудим; Задания; Лебедь, Щука и Рак; Чиж и Голубь

## СЕРГЕЙ МИХАЛКОВ. Услужливый заяц
URL: https://www.opiq.ee/kit/504/chapter/27695
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 6.4
Topics ET: matemaatika
Topics RU: математика, сергей, михалков, услужливый, заяц, давай, обсудим
Topics EN: mathematics
Headings: СЕРГЕЙ МИХАЛКОВ. Услужливый заяц; Давай обсудим; Задания

## ЕВГЕНИЙ ПЕРМЯК. О принце в голубой короне
URL: https://www.opiq.ee/kit/504/chapter/27696
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 7.1
Topics ET: matemaatika
Topics RU: математика, евгений, пермяк, принце, голубой, короне, давай, обсудим
Topics EN: mathematics
Headings: ЕВГЕНИЙ ПЕРМЯК. О принце в голубой короне; Давай обсудим; Задания

## ЕВГЕНИЙ ПЕРМЯК. Иголкины братья
URL: https://www.opiq.ee/kit/504/chapter/27697
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 7.2
Topics ET: matemaatika
Topics RU: математика, евгений, пермяк, иголкины, братья, давай, обсудим
Topics EN: mathematics
Headings: ЕВГЕНИЙ ПЕРМЯК. Иголкины братья; Давай обсудим; Задания

## АНДРЕЙ УСАЧЁВ. На чём держится земля?
URL: https://www.opiq.ee/kit/504/chapter/27698
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 7.3
Topics ET: matemaatika
Topics RU: математика, андрей, усач, держится, земля, давай, обсудим
Topics EN: mathematics
Headings: АНДРЕЙ УСАЧЁВ. На чём держится земля?; Давай обсудим; Задания

## ЮРИЙ НИКИФОРОВ. О монетах и кладах
URL: https://www.opiq.ee/kit/504/chapter/27699
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 7.4
Topics ET: matemaatika
Topics RU: математика, юрий, никифоров, монетах, кладах, давай, обсудим
Topics EN: mathematics
Headings: ЮРИЙ НИКИФОРОВ. О монетах и кладах; Давай обсудим; Задания

## БОРИС ЗАХОДЕР. История гусеницы
URL: https://www.opiq.ee/kit/504/chapter/27700
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 7.5
Topics ET: matemaatika
Topics RU: математика, борис, заходер, история, гусеницы, давай, обсудим
Topics EN: mathematics
Headings: БОРИС ЗАХОДЕР. История гусеницы; Давай обсудим; Задания; История гусеницы (2); * * *; История гусеницы (3); История гусеницы (4)

## Весна, весна красная!
URL: https://www.opiq.ee/kit/504/chapter/27701
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 8.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, красная, давай, обсудим
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Весна, весна красная!; Давай обсудим; Задания

## САМУИЛ МАРШАК. Снег теперь уже не тот…
URL: https://www.opiq.ee/kit/504/chapter/27702
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 8.2
Topics ET: matemaatika
Topics RU: математика, самуил, маршак, снег, теперь, давай, обсудим
Topics EN: mathematics
Headings: САМУИЛ МАРШАК. Снег теперь уже не тот…; Давай обсудим; Задания

## ФЁДОР ТЮТЧЕВ. Весенняя гроза
URL: https://www.opiq.ee/kit/504/chapter/27703
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 8.3
Topics ET: matemaatika
Topics RU: математика, тютчев, весенняя, гроза, давай, обсудим
Topics EN: mathematics
Headings: ФЁДОР ТЮТЧЕВ. Весенняя гроза; Давай обсудим; Задания

## МИХАИЛ ПРИШВИН. Времена года
URL: https://www.opiq.ee/kit/504/chapter/27704
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 8.4
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, михаил, пришвин, времена, года, давай, обсудим
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: МИХАИЛ ПРИШВИН. Времена года; Весна; * * *; Давай обсудим; Задания

## ЮРИЙ СОТНИК. Как меня спасали
URL: https://www.opiq.ee/kit/504/chapter/27705
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 8.5
Topics ET: matemaatika
Topics RU: математика, юрий, сотник, меня, спасали, давай, обсудим
Topics EN: mathematics
Headings: ЮРИЙ СОТНИК. Как меня спасали; Давай обсудим; Задания

## САША ЧЁРНЫЙ. Невероятная история
URL: https://www.opiq.ee/kit/504/chapter/27706
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 8.6
Topics ET: matemaatika
Topics RU: математика, саша, рный, невероятная, история, давай, обсудим
Topics EN: mathematics
Headings: САША ЧЁРНЫЙ. Невероятная история; * * *; Давай обсудим; Задания

## ЕЛИЗАВЕТА СТЮАРТ. Так проснулся ясный день…
URL: https://www.opiq.ee/kit/504/chapter/27707
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 9.1
Topics ET: matemaatika
Topics RU: математика, елизавета, стюарт, проснулся, ясный, день, давай, обсудим
Topics EN: mathematics
Headings: ЕЛИЗАВЕТА СТЮАРТ. Так проснулся ясный день…; Давай обсудим; Задания

## ИРИНА ТОКМАКОВА. Брусничный гном
URL: https://www.opiq.ee/kit/504/chapter/27708
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 9.2
Topics ET: matemaatika
Topics RU: математика, ирина, токмакова, брусничный, гном, давай, обсудим
Topics EN: mathematics
Headings: ИРИНА ТОКМАКОВА. Брусничный гном; Давай обсудим; Задания

## НИКОЛАЙ СЛАДКОВ. Родник
URL: https://www.opiq.ee/kit/504/chapter/27709
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 9.3
Topics ET: matemaatika
Topics RU: математика, николай, сладков, родник, давай, обсудим
Topics EN: mathematics
Headings: НИКОЛАЙ СЛАДКОВ. Родник; Давай обсудим; Задания

## ВИКТОР АСТАФЬЕВ. Капалуха
URL: https://www.opiq.ee/kit/504/chapter/27710
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 9.4
Topics ET: matemaatika
Topics RU: математика, виктор, астафьев, капалуха, давай, обсудим
Topics EN: mathematics
Headings: ВИКТОР АСТАФЬЕВ. Капалуха; Давай обсудим; Задания

## МАРИЯ ПАРР. Вафельное сердце
URL: https://www.opiq.ee/kit/504/chapter/27711
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 9.5
Topics ET: matemaatika
Topics RU: математика, мария, парр, вафельное, сердце, дыра, живой, изгороди, давай, обсудим
Topics EN: mathematics
Headings: МАРИЯ ПАРР. Вафельное сердце; Дыра в живой изгороди; Давай обсудим; Задания; Дружище Трилле и соседская кнопка; День рождения; Пожар

## САША ЧЁРНЫЙ. Мамина песня
URL: https://www.opiq.ee/kit/504/chapter/27712
Book: РУССКОЕ СЛОВО. Чтение для 3 клacca – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: русское_слово._чтение_для_3_клacca
Chapter ID: 9.6
Topics ET: matemaatika
Topics RU: математика, саша, рный, мамина, песня, давай, обсудим
Topics EN: mathematics
Headings: САША ЧЁРНЫЙ. Мамина песня; Давай обсудим; Задания
