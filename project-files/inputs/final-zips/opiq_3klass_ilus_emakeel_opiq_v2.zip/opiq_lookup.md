## ILUS EMAKEEL – Opiq
URL: https://www.opiq.ee/Kit/Details/135
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 182
Topics ET: matemaatika, ilus, emakeel, opiq
Topics RU: математика
Topics EN: mathematics

## ILUS EMAKEEL – Opiq
URL: https://www.opiq.ee/Kit/Details/135
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 368
Topics ET: matemaatika, ilus, emakeel, opiq
Topics RU: математика
Topics EN: mathematics

## Peatükis „Kes targaks tahab saada”
URL: https://www.opiq.ee/kit/135/chapter/7358
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.1
Topics ET: matemaatika, peatükis, targaks, tahab, saada
Topics RU: математика
Topics EN: mathematics
Headings: Peatükis „Kes targaks tahab saada”

## Miks on tähestik arvuti klahvistikul segi?
URL: https://www.opiq.ee/kit/135/chapter/7349
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.10
Topics ET: matemaatika, miks, tähestik, arvuti, klahvistikul, segi
Topics RU: математика
Topics EN: mathematics
Headings: Miks on tähestik arvuti klahvistikul segi?

## HÄÄLIKUÜHENDID
URL: https://www.opiq.ee/kit/135/chapter/7362
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.11
Topics ET: matemaatika, häälikuühendid
Topics RU: математика
Topics EN: mathematics
Headings: HÄÄLIKUÜHENDID

## Kassid tulevad
URL: https://www.opiq.ee/kit/135/chapter/7363
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.12
Topics ET: matemaatika, kassid, tulevad
Topics RU: математика
Topics EN: mathematics
Headings: Kassid tulevad

## Kodukas ja kodukass
URL: https://www.opiq.ee/kit/135/chapter/7350
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.13
Topics ET: matemaatika, kodukas, kodukass, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kodukas ja kodukass; Lisaülesanne 10

## Mis on arvuti?
URL: https://www.opiq.ee/kit/135/chapter/7351
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.14
Topics ET: matemaatika, inimene, keha, meeled, tervis, arvuti, tähtsamaid, fakte, arvutite, ajaloost, post, oskab, tõlkida, internet, lisaülesanne
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Mis on arvuti?; TÄHTSAMAID FAKTE ARVUTITE AJALOOST; Mis on e-post?; Kas arvuti oskab tõlkida?; Mis on internet?; Arvuti ja tervis; Lisaülesanne 11; Lisaülesanne 12

## Napakas jutt number kaheksateist
URL: https://www.opiq.ee/kit/135/chapter/7352
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.15
Topics ET: matemaatika, arv, arvud, arvu, numbrid, napakas, jutt, kaheksateist, lisaülesanne
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Napakas jutt number kaheksateist; Lisaülesanne 13; Lisaülesanne 14; Lisaülesanne 15

## Tunnikontroll 1
URL: https://www.opiq.ee/kit/135/chapter/20806
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.16
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 1

## Tulevikukool
URL: https://www.opiq.ee/kit/135/chapter/7353
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.17
Topics ET: matemaatika, tulevikukool, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Tulevikukool; k, p, t ja g, b, d; Lisaülesanne 16; Lisaülesanne 17

## VÕÕRSÕNAD
URL: https://www.opiq.ee/kit/135/chapter/7354
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.18
Topics ET: matemaatika, võõrsõnad
Topics RU: математика
Topics EN: mathematics
Headings: VÕÕRSÕNAD

## OMASÕNAD
URL: https://www.opiq.ee/kit/135/chapter/7364
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.19
Topics ET: matemaatika, omasõnad
Topics RU: математика
Topics EN: mathematics
Headings: OMASÕNAD

## Emakeel on kõigil oma
URL: https://www.opiq.ee/kit/135/chapter/7359
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.2
Topics ET: matemaatika, emakeel, kõigil, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Emakeel on kõigil oma; Lisaülesanne 1; Lisaülesanne 2

## Kummi-Tarzan
URL: https://www.opiq.ee/kit/135/chapter/7355
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.20
Topics ET: matemaatika, kummi, tarzan
Topics RU: математика
Topics EN: mathematics
Headings: Kummi-Tarzan; 1.; 2.

## Nunnunäütüs
URL: https://www.opiq.ee/kit/135/chapter/7365
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.21
Topics ET: matemaatika, nunnunäütüs, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Nunnunäütüs; Lisaülesanne 18

## Sõna „nutma”
URL: https://www.opiq.ee/kit/135/chapter/7356
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.22
Topics ET: matemaatika, sõna, nutma
Topics RU: математика
Topics EN: mathematics
Headings: Sõna „nutma”

## Kõik, mis juhtub ja ei juhtu
URL: https://www.opiq.ee/kit/135/chapter/7366
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.23
Topics ET: matemaatika, kõik, juhtub, juhtu
Topics RU: математика
Topics EN: mathematics
Headings: Kõik, mis juhtub ja ei juhtu

## Tunnikontroll 2
URL: https://www.opiq.ee/kit/135/chapter/20807
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.24
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 2

## Tähti ommaq raamaduq otsast otsani täüs
URL: https://www.opiq.ee/kit/135/chapter/7367
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.25
Topics ET: matemaatika, tähti, ommaq, raamaduq, otsast, otsani, täüs, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Tähti ommaq raamaduq otsast otsani täüs; Lisaülesanne 19

## Kevade
URL: https://www.opiq.ee/kit/135/chapter/7357
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.26
Topics ET: matemaatika, kevade, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kevade; 1.; 2.; 3.; 4.; 5.; 6.; Lisaülesanne 20; Lisaülesanne 21; Lisaülesanne 22

## Kontrolltöö 1
URL: https://www.opiq.ee/kit/135/chapter/20808
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.27
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 1

## Mitu keelt on maailmas?
URL: https://www.opiq.ee/kit/135/chapter/7360
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.3
Topics ET: matemaatika, mitu, keelt, maailmas, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Mitu keelt on maailmas?; Lisaülesanne 3; Lisaülesanne 4

## TÄHESTIK
URL: https://www.opiq.ee/kit/135/chapter/7344
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.4
Topics ET: matemaatika, tähestik
Topics RU: математика
Topics EN: mathematics
Headings: TÄHESTIK

## TÄHESTIKULINE JÄRJEKORD
URL: https://www.opiq.ee/kit/135/chapter/7345
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.5
Topics ET: matemaatika, tähestikuline, järjekord, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: TÄHESTIKULINE JÄRJEKORD; Lisaülesanne 5; Lisaülesanne 6

## Igal sügisel
URL: https://www.opiq.ee/kit/135/chapter/7346
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.6
Topics ET: matemaatika, igal, sügisel, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Igal sügisel; Lisaülesanne 7; Lisaülesanne 8

## ASTRID LINDGREN
URL: https://www.opiq.ee/kit/135/chapter/7361
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.7
Topics ET: matemaatika, astrid, lindgren, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: ASTRID LINDGREN; Lisaülesanne 9

## Jälle kooli
URL: https://www.opiq.ee/kit/135/chapter/7347
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.8
Topics ET: matemaatika, jälle, kooli
Topics RU: математика
Topics EN: mathematics
Headings: Jälle kooli

## Atu võetakse kooli
URL: https://www.opiq.ee/kit/135/chapter/7348
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 1.9
Topics ET: matemaatika, võetakse, kooli
Topics RU: математика
Topics EN: mathematics
Headings: Atu võetakse kooli; 1.; 2.

## Peatükis „Õpi elamise tarvis”
URL: https://www.opiq.ee/kit/135/chapter/7378
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.1
Topics ET: matemaatika, peatükis, elamise, tarvis
Topics RU: математика
Topics EN: mathematics
Headings: Peatükis „Õpi elamise tarvis”

## Sügis
URL: https://www.opiq.ee/kit/135/chapter/7383
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.10
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Sügis

## Sõit-sõit läbi salu
URL: https://www.opiq.ee/kit/135/chapter/7371
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.11
Topics ET: matemaatika, sõit, läbi, salu
Topics RU: математика
Topics EN: mathematics
Headings: Sõit-sõit läbi salu

## Kunksmoor
URL: https://www.opiq.ee/kit/135/chapter/7372
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.12
Topics ET: matemaatika, kunksmoor
Topics RU: математика
Topics EN: mathematics
Headings: Kunksmoor

## Varese reis soojale maale
URL: https://www.opiq.ee/kit/135/chapter/7373
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.13
Topics ET: matemaatika, varese, reis, soojale, maale
Topics RU: математика
Topics EN: mathematics
Headings: Varese reis soojale maale

## Tunnikontroll 4
URL: https://www.opiq.ee/kit/135/chapter/20810
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.14
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 4

## Käes on helkurite aeg!
URL: https://www.opiq.ee/kit/135/chapter/7384
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.15
Topics ET: matemaatika, aeg, kell, kalender, käes, helkurite, lisaülesanne
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Käes on helkurite aeg!; Lisaülesanne 28

## Liiklemine pimedal ajal
URL: https://www.opiq.ee/kit/135/chapter/7374
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.16
Topics ET: matemaatika, liiklemine, pimedal, ajal, kuhu, helkur, kinnitada, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Liiklemine pimedal ajal; Kuhu helkur kinnitada?; Lisaülesanne 29

## Kahekesi läbi õhtuse linna
URL: https://www.opiq.ee/kit/135/chapter/7375
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.17
Topics ET: matemaatika, kahekesi, läbi, õhtuse, linna, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kahekesi läbi õhtuse linna; Lisaülesanne 30

## Huvitavaid fakte
URL: https://www.opiq.ee/kit/135/chapter/7376
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.18
Topics ET: matemaatika, huvitavaid, fakte, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Huvitavaid fakte; Lisaülesanne 31; Lisaülesanne 32

## Härra Huu sõidab linna
URL: https://www.opiq.ee/kit/135/chapter/7377
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.19
Topics ET: matemaatika, härra, sõidab, linna, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Härra Huu sõidab linna; Lisaülesanne 33

## Vana aja koolitüdruk
URL: https://www.opiq.ee/kit/135/chapter/7379
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.2
Topics ET: matemaatika, vana, koolitüdruk, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Vana aja koolitüdruk; Lisaülesanne 23; Lisaülesanne 24

## Tunnikontroll 5
URL: https://www.opiq.ee/kit/135/chapter/20811
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.20
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 5

## SILBITAMINE JA POOLITAMINE
URL: https://www.opiq.ee/kit/135/chapter/7380
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.3
Topics ET: matemaatika, silbitamine, poolitamine
Topics RU: математика
Topics EN: mathematics
Headings: SILBITAMINE JA POOLITAMINE

## Teele, teele, kurekesed!
URL: https://www.opiq.ee/kit/135/chapter/7381
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.4
Topics ET: matemaatika, teele, kurekesed
Topics RU: математика
Topics EN: mathematics
Headings: Teele, teele, kurekesed!

## Supikool
URL: https://www.opiq.ee/kit/135/chapter/7368
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.5
Topics ET: matemaatika, supikool, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Supikool; Lisaülesanne 25

## Mida vahetundides vanal ajal tehti
URL: https://www.opiq.ee/kit/135/chapter/7369
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.6
Topics ET: matemaatika, mida, vahetundides, vanal, ajal, tehti, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Mida vahetundides vanal ajal tehti; Lisaülesanne 26

## Tunnikontroll 3
URL: https://www.opiq.ee/kit/135/chapter/20809
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.7
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 3

## LAUSELÕPUMÄRGID
URL: https://www.opiq.ee/kit/135/chapter/7382
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.8
Topics ET: matemaatika, lauselõpumärgid
Topics RU: математика
Topics EN: mathematics
Headings: LAUSELÕPUMÄRGID

## Lehed ja okkad
URL: https://www.opiq.ee/kit/135/chapter/7370
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 2.9
Topics ET: matemaatika, lehed, okkad, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Lehed ja okkad; Lisaülesanne 27

## Peatükis „Mina ise”
URL: https://www.opiq.ee/kit/135/chapter/7396
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.1
Topics ET: matemaatika, peatükis, mina
Topics RU: математика
Topics EN: mathematics
Headings: Peatükis „Mina ise”

## Sirli, Siim ja saladused
URL: https://www.opiq.ee/kit/135/chapter/7388
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.10
Topics ET: matemaatika, sirli, siim, saladused, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Sirli, Siim ja saladused; Lisaülesanne 35

## Jutt vasakukäelistest
URL: https://www.opiq.ee/kit/135/chapter/7389
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.11
Topics ET: matemaatika, jutt, vasakukäelistest, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Jutt vasakukäelistest; Lisaülesanne 36

## Kontrolltöö 2
URL: https://www.opiq.ee/kit/135/chapter/20813
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.12
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 2

## Nõiutud linn
URL: https://www.opiq.ee/kit/135/chapter/7390
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.13
Topics ET: matemaatika, nõiutud, linn, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Nõiutud linn; 1.; 2.; 3.; Lisaülesanne 37; Lisaülesanne 38

## Nõiutud Tuks
URL: https://www.opiq.ee/kit/135/chapter/7391
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.14
Topics ET: matemaatika, nõiutud, tuks, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Nõiutud Tuks; 1.; 2.; 3.; Lisaülesanne 39

## SÕNA JA KÜSIMUS
URL: https://www.opiq.ee/kit/135/chapter/7392
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.15
Topics ET: matemaatika, sõna, küsimus, skeem
Topics RU: математика
Topics EN: mathematics
Headings: SÕNA JA KÜSIMUS; Skeem

## Koeralugu
URL: https://www.opiq.ee/kit/135/chapter/7401
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.16
Topics ET: matemaatika, koeralugu, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Koeralugu; Lisaülesanne 40; Lisaülesanne 41

## Mure ja amour
URL: https://www.opiq.ee/kit/135/chapter/7402
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.17
Topics ET: matemaatika, mure, amour
Topics RU: математика
Topics EN: mathematics
Headings: Mure ja amour

## Koerapoeg Pätt
URL: https://www.opiq.ee/kit/135/chapter/7393
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.18
Topics ET: matemaatika, koerapoeg, pätt, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Koerapoeg Pätt; 1.; 2.; 3.; Lisaülesanne 42; Lisaülesanne 43

## Kiigelaud
URL: https://www.opiq.ee/kit/135/chapter/7403
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.19
Topics ET: matemaatika, kiigelaud, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kiigelaud; Lisaülesanne 44

## I JA J
URL: https://www.opiq.ee/kit/135/chapter/7397
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: I JA J

## Kääbuspapagoid
URL: https://www.opiq.ee/kit/135/chapter/7394
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.20
Topics ET: matemaatika, kääbuspapagoid
Topics RU: математика
Topics EN: mathematics
Headings: Kääbuspapagoid; 1.; 2.; 3.

## Trollitalv
URL: https://www.opiq.ee/kit/135/chapter/7395
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.21
Topics ET: matemaatika, trollitalv, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Trollitalv; Lisaülesanne 45

## Mina koosnen...
URL: https://www.opiq.ee/kit/135/chapter/7398
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.3
Topics ET: matemaatika, mina, koosnen
Topics RU: математика
Topics EN: mathematics
Headings: Mina koosnen...

## Kes ma olen?
URL: https://www.opiq.ee/kit/135/chapter/7399
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.4
Topics ET: matemaatika, olen
Topics RU: математика
Topics EN: mathematics
Headings: Kes ma olen?

## Kui ma ükskord nurgas seisin
URL: https://www.opiq.ee/kit/135/chapter/7385
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.5
Topics ET: matemaatika, ükskord, nurgas, seisin
Topics RU: математика
Topics EN: mathematics
Headings: Kui ma ükskord nurgas seisin

## TIIA TOOMET
URL: https://www.opiq.ee/kit/135/chapter/7400
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.6
Topics ET: matemaatika, tiia, toomet
Topics RU: математика
Topics EN: mathematics
Headings: TIIA TOOMET

## Kaur mõtleb
URL: https://www.opiq.ee/kit/135/chapter/7386
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.7
Topics ET: matemaatika, kaur, mõtleb, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kaur mõtleb; Lisaülesanne 34

## Mina ise
URL: https://www.opiq.ee/kit/135/chapter/7387
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.8
Topics ET: matemaatika, mina
Topics RU: математика
Topics EN: mathematics
Headings: Mina ise

## Tunnikontroll 6
URL: https://www.opiq.ee/kit/135/chapter/20812
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 3.9
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 6

## Peatükis „Küünlad kuusel säravad”
URL: https://www.opiq.ee/kit/135/chapter/7412
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.1
Topics ET: matemaatika, peatükis, küünlad, kuusel, säravad
Topics RU: математика
Topics EN: mathematics
Headings: Peatükis „Küünlad kuusel säravad”

## Meie pere jõulud
URL: https://www.opiq.ee/kit/135/chapter/7410
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.10
Topics ET: matemaatika, meie, pere, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: Meie pere jõulud

## Häid jõulupühi!
URL: https://www.opiq.ee/kit/135/chapter/7411
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.11
Topics ET: matemaatika, häid, jõulupühi
Topics RU: математика
Topics EN: mathematics
Headings: Häid jõulupühi!

## Ime
URL: https://www.opiq.ee/kit/135/chapter/7404
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ime

## Klaasist paabulind
URL: https://www.opiq.ee/kit/135/chapter/7405
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.3
Topics ET: matemaatika, klaasist, paabulind, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Klaasist paabulind; 1.; 2.; 3.; Lisaülesanne 46; Lisaülesanne 47; Lisaülesanne 48

## Tunnikontroll 7
URL: https://www.opiq.ee/kit/135/chapter/20814
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.4
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 7

## Lepatriinude jõulud
URL: https://www.opiq.ee/kit/135/chapter/7406
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.5
Topics ET: matemaatika, lepatriinude, jõulud, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Lepatriinude jõulud; Lisaülesanne 49

## Jõuluvalgus
URL: https://www.opiq.ee/kit/135/chapter/7407
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.6
Topics ET: matemaatika, jõuluvalgus, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluvalgus; Lisaülesanne 50

## Väike jõululugu
URL: https://www.opiq.ee/kit/135/chapter/7408
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.7
Topics ET: matemaatika, väike, jõululugu, pilt
Topics RU: математика
Topics EN: mathematics
Headings: Väike jõululugu; I pilt; II pilt

## Kontrolltöö 3
URL: https://www.opiq.ee/kit/135/chapter/20815
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.8
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 3

## Piparkoogisüda
URL: https://www.opiq.ee/kit/135/chapter/7409
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 4.9
Topics ET: matemaatika, piparkoogisüda, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Piparkoogisüda; Lisaülesanne 51

## Peatükis „Õige sõber kaalub enam kui kuld”
URL: https://www.opiq.ee/kit/135/chapter/7431
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.1
Topics ET: matemaatika, peatükis, õige, sõber, kaalub, enam, kuld
Topics RU: математика
Topics EN: mathematics
Headings: Peatükis „Õige sõber kaalub enam kui kuld”

## Suur ja seisev, ripub seinal
URL: https://www.opiq.ee/kit/135/chapter/7419
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.10
Topics ET: matemaatika, suur, seisev, ripub, seinal, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Suur ja seisev, ripub seinal; Lisaülesanne 59

## Seebilugu
URL: https://www.opiq.ee/kit/135/chapter/7420
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.11
Topics ET: matemaatika, seebilugu
Topics RU: математика
Topics EN: mathematics
Headings: Seebilugu

## Kontrolltöö 4
URL: https://www.opiq.ee/kit/135/chapter/20817
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.12
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 4

## Miks hakati kasutama ühist ajaarvamist?
URL: https://www.opiq.ee/kit/135/chapter/7421
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.13
Topics ET: matemaatika, miks, hakati, kasutama, ühist, ajaarvamist, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Miks hakati kasutama ühist ajaarvamist?; Lisaülesanne 60

## KÜSISÕNAD
URL: https://www.opiq.ee/kit/135/chapter/7433
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.14
Topics ET: matemaatika, küsisõnad
Topics RU: математика
Topics EN: mathematics
Headings: KÜSISÕNAD

## Kes avastas aja?
URL: https://www.opiq.ee/kit/135/chapter/7422
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.15
Topics ET: matemaatika, avastas
Topics RU: математика
Topics EN: mathematics
Headings: Kes avastas aja?

## Ainulaadne elevandilaps
URL: https://www.opiq.ee/kit/135/chapter/7423
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.16
Topics ET: matemaatika, ainulaadne, elevandilaps, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Ainulaadne elevandilaps; Lisaülesanne 61

## Kirjad tulevad
URL: https://www.opiq.ee/kit/135/chapter/7424
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.17
Topics ET: matemaatika, kirjad, tulevad
Topics RU: математика
Topics EN: mathematics
Headings: Kirjad tulevad

## Valentinipäev, sõbrapäev – 14. veebruar
URL: https://www.opiq.ee/kit/135/chapter/7434
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.18
Topics ET: matemaatika, valentinipäev, sõbrapäev, veebruar
Topics RU: математика
Topics EN: mathematics
Headings: Valentinipäev, sõbrapäev – 14. veebruar

## SÕNADE LÜHIVORMID
URL: https://www.opiq.ee/kit/135/chapter/7425
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.19
Topics ET: matemaatika, sõnade, lühivormid
Topics RU: математика
Topics EN: mathematics
Headings: SÕNADE LÜHIVORMID

## Kelgutamas
URL: https://www.opiq.ee/kit/135/chapter/7413
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.2
Topics ET: matemaatika, kelgutamas, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kelgutamas; Lisaülesanne 52

## Mõnda huvitavat postiteenuse ajaloost
URL: https://www.opiq.ee/kit/135/chapter/7426
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.20
Topics ET: matemaatika, mõnda, huvitavat, postiteenuse, ajaloost, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Mõnda huvitavat postiteenuse ajaloost; Lisaülesanne 62

## Rohutirts ja sipelgas
URL: https://www.opiq.ee/kit/135/chapter/7427
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.21
Topics ET: matemaatika, rohutirts, sipelgas, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Rohutirts ja sipelgas; Lisaülesanne 63

## Kes see Leonhard on?
URL: https://www.opiq.ee/kit/135/chapter/7428
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.22
Topics ET: matemaatika, leonhard, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kes see Leonhard on?; 1.; 2.; Lisaülesanne 64; Lisaülesanne 65

## Tunnikontroll 9
URL: https://www.opiq.ee/kit/135/chapter/20818
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.23
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 9

## Härra Huu
URL: https://www.opiq.ee/kit/135/chapter/7429
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.24
Topics ET: matemaatika, härra
Topics RU: математика
Topics EN: mathematics
Headings: Härra Huu

## Isekas hiiglane
URL: https://www.opiq.ee/kit/135/chapter/7430
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.25
Topics ET: matemaatika, isekas, hiiglane, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Isekas hiiglane; 1.; 2.; Lisaülesanne 66

## OMADUSSÕNA, NIMISÕNA, TEGUSÕNA
URL: https://www.opiq.ee/kit/135/chapter/7414
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.3
Topics ET: matemaatika, omadussõna, nimisõna, tegusõna
Topics RU: математика
Topics EN: mathematics
Headings: OMADUSSÕNA, NIMISÕNA, TEGUSÕNA

## Miks näib lumi valge?
URL: https://www.opiq.ee/kit/135/chapter/7432
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.4
Topics ET: matemaatika, miks, näib, lumi, valge, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Miks näib lumi valge?; Lisaülesanne 53

## Virmalised
URL: https://www.opiq.ee/kit/135/chapter/7415
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.5
Topics ET: matemaatika, virmalised, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Virmalised; Lisaülesanne 54

## Rahalaul
URL: https://www.opiq.ee/kit/135/chapter/7416
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.6
Topics ET: matemaatika, rahalaul, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Rahalaul; Lisaülesanne 55

## Raha minu elus
URL: https://www.opiq.ee/kit/135/chapter/7417
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.7
Topics ET: matemaatika, raha, euro, sent, elus
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: Raha minu elus

## Ausalt teenitud münt
URL: https://www.opiq.ee/kit/135/chapter/7418
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.8
Topics ET: matemaatika, ausalt, teenitud, münt, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Ausalt teenitud münt; 1.; 2.; 3.; 4.; Lisaülesanne 57; Lisaülesanne 58

## Tunnikontroll 8
URL: https://www.opiq.ee/kit/135/chapter/20816
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 5.9
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 8

## Peatükis „Kodumaa on kõige kodusem maa…”
URL: https://www.opiq.ee/kit/135/chapter/7465
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.1
Topics ET: matemaatika, peatükis, kodumaa, kõige, kodusem
Topics RU: математика
Topics EN: mathematics
Headings: Peatükis „Kodumaa on kõige kodusem maa…”

## Tunnikontroll 10
URL: https://www.opiq.ee/kit/135/chapter/20819
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.10
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 10

## Lõokese laul
URL: https://www.opiq.ee/kit/135/chapter/7442
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.11
Topics ET: matemaatika, lõokese, laul, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Lõokese laul; Lisaülesanne 71

## Paabeli segadus
URL: https://www.opiq.ee/kit/135/chapter/7443
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.12
Topics ET: matemaatika, paabeli, segadus, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Paabeli segadus; Lisaülesanne 72

## Kontrolltöö 5
URL: https://www.opiq.ee/kit/135/chapter/20820
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.13
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 5

## Lapse kõne ema ja isaga
URL: https://www.opiq.ee/kit/135/chapter/7467
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.14
Topics ET: matemaatika, lapse, kõne, isaga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Lapse kõne ema ja isaga; Lisaülesanne 73

## Sõida tasa üle silla
URL: https://www.opiq.ee/kit/135/chapter/7444
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.15
Topics ET: matemaatika, sõida, tasa, silla, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Sõida tasa üle silla; Lisaülesanne 74

## Emakeelepäev – 14. märts
URL: https://www.opiq.ee/kit/135/chapter/7468
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.16
Topics ET: matemaatika, emakeelepäev, märts
Topics RU: математика
Topics EN: mathematics
Headings: Emakeelepäev – 14. märts

## Sõnategu
URL: https://www.opiq.ee/kit/135/chapter/7469
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.17
Topics ET: matemaatika, sõnategu
Topics RU: математика
Topics EN: mathematics
Headings: Sõnategu

## Jorutus. Pähklid ja paiglid
URL: https://www.opiq.ee/kit/135/chapter/7445
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.18
Topics ET: matemaatika, jorutus, pähklid, paiglid
Topics RU: математика
Topics EN: mathematics
Headings: Jorutus. Pähklid ja paiglid; Jorutus; Pähklid ja paiglid

## Vanasõnad
URL: https://www.opiq.ee/kit/135/chapter/7446
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.19
Topics ET: matemaatika, vanasõnad, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Vanasõnad; Lisaülesanne 75

## Kodulaul
URL: https://www.opiq.ee/kit/135/chapter/7435
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.2
Topics ET: matemaatika, kodulaul
Topics RU: математика
Topics EN: mathematics
Headings: Kodulaul

## Tunnikontroll 11
URL: https://www.opiq.ee/kit/135/chapter/20821
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.20
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 11

## Pinni-peni kiri
URL: https://www.opiq.ee/kit/135/chapter/7447
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.21
Topics ET: matemaatika, pinni, peni, kiri, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Pinni-peni kiri; Lisaülesanne 76

## Kas loomad räägivad?
URL: https://www.opiq.ee/kit/135/chapter/7470
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.22
Topics ET: matemaatika, loom, loomad, linnud, putukad, räägivad
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Kas loomad räägivad?

## Millisel loomal on kõige rohkem hüüdnimesid?
URL: https://www.opiq.ee/kit/135/chapter/7448
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.23
Topics ET: matemaatika, millisel, loomal, kõige, rohkem, hüüdnimesid, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Millisel loomal on kõige rohkem hüüdnimesid?; Lisaülesanne 77

## Haldjas Heldeke
URL: https://www.opiq.ee/kit/135/chapter/7449
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.24
Topics ET: matemaatika, haldjas, heldeke
Topics RU: математика
Topics EN: mathematics
Headings: Haldjas Heldeke

## Koer poiss sõitis jänest
URL: https://www.opiq.ee/kit/135/chapter/7471
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.25
Topics ET: matemaatika, koer, poiss, sõitis, jänest
Topics RU: математика
Topics EN: mathematics
Headings: Koer poiss sõitis jänest

## Miks me nii räägime?
URL: https://www.opiq.ee/kit/135/chapter/7450
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.26
Topics ET: matemaatika, miks, räägime, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Miks me nii räägime?; Lisaülesanne 78

## Tunnikontroll 12
URL: https://www.opiq.ee/kit/135/chapter/20822
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.27
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 12

## Arvutihull
URL: https://www.opiq.ee/kit/135/chapter/7451
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.28
Topics ET: matemaatika, arvutihull, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Arvutihull; Lisaülesanne 79

## SUUR ALGUSTÄHT
URL: https://www.opiq.ee/kit/135/chapter/7472
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.29
Topics ET: matemaatika, suur, algustäht
Topics RU: математика
Topics EN: mathematics
Headings: SUUR ALGUSTÄHT

## Eesti kaart
URL: https://www.opiq.ee/kit/135/chapter/7436
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.3
Topics ET: matemaatika, eesti, kaart, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Eesti kaart; Lisaülesanne 67

## Kuidas eestlased endale perekonnanimed said?
URL: https://www.opiq.ee/kit/135/chapter/7452
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.30
Topics ET: matemaatika, kuidas, eestlased, endale, perekonnanimed, said, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas eestlased endale perekonnanimed said?; Lisaülesanne 80; Lisaülesanne 81

## Liisu hakkab kuulsaks kirjanikuks
URL: https://www.opiq.ee/kit/135/chapter/7453
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.31
Topics ET: matemaatika, liisu, hakkab, kuulsaks, kirjanikuks
Topics RU: математика
Topics EN: mathematics
Headings: Liisu hakkab kuulsaks kirjanikuks

## Lapsed endast
URL: https://www.opiq.ee/kit/135/chapter/7473
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.32
Topics ET: matemaatika, lapsed, endast
Topics RU: математика
Topics EN: mathematics
Headings: Lapsed endast

## Maailma maad
URL: https://www.opiq.ee/kit/135/chapter/7454
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.33
Topics ET: matemaatika, maailma, maad
Topics RU: математика
Topics EN: mathematics
Headings: Maailma maad

## Orienteerumine ehk asukohast arusaamine
URL: https://www.opiq.ee/kit/135/chapter/7474
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.34
Topics ET: matemaatika, orienteerumine, asukohast, arusaamine, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Orienteerumine ehk asukohast arusaamine; Lisaülesanne 82

## Tunnikontroll 13
URL: https://www.opiq.ee/kit/135/chapter/20823
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.35
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 13

## KOMA LOETELUS
URL: https://www.opiq.ee/kit/135/chapter/7455
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.36
Topics ET: matemaatika, koma, loetelus
Topics RU: математика
Topics EN: mathematics
Headings: KOMA LOETELUS

## Minek
URL: https://www.opiq.ee/kit/135/chapter/7456
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.37
Topics ET: matemaatika, minek, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Minek; Lisaülesanne 83

## Kuidas Eestimaad kokku pressiti
URL: https://www.opiq.ee/kit/135/chapter/7457
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.38
Topics ET: matemaatika, liitmine, liida, summa, kokku, kuidas, eestimaad, pressiti, lisaülesanne
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Kuidas Eestimaad kokku pressiti; Lisaülesanne 84

## Saladuslikud kujud Lihavõttesaarel
URL: https://www.opiq.ee/kit/135/chapter/7475
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.39
Topics ET: matemaatika, saladuslikud, kujud, lihavõttesaarel
Topics RU: математика
Topics EN: mathematics
Headings: Saladuslikud kujud Lihavõttesaarel

## Eestimaa sünd
URL: https://www.opiq.ee/kit/135/chapter/7437
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.4
Topics ET: matemaatika, eestimaa, sünd, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Eestimaa sünd; Lisaülesanne 68

## Siiditee
URL: https://www.opiq.ee/kit/135/chapter/7476
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.40
Topics ET: matemaatika, siiditee
Topics RU: математика
Topics EN: mathematics
Headings: Siiditee

## Kui pikk on Hiina müür?
URL: https://www.opiq.ee/kit/135/chapter/7477
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.41
Topics ET: matemaatika, pikk, hiina, müür
Topics RU: математика
Topics EN: mathematics
Headings: Kui pikk on Hiina müür?

## Milline on Antarktise manner?
URL: https://www.opiq.ee/kit/135/chapter/7458
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.42
Topics ET: matemaatika, milline, antarktise, manner, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Milline on Antarktise manner?; Lisaülesanne 85

## ANDRUS KIVIRÄHK
URL: https://www.opiq.ee/kit/135/chapter/7478
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.43
Topics ET: matemaatika, andrus, kivirähk
Topics RU: математика
Topics EN: mathematics
Headings: ANDRUS KIVIRÄHK

## Vapper keefir
URL: https://www.opiq.ee/kit/135/chapter/7459
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.44
Topics ET: matemaatika, vapper, keefir
Topics RU: математика
Topics EN: mathematics
Headings: Vapper keefir

## Tunnikontroll 14
URL: https://www.opiq.ee/kit/135/chapter/20824
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.45
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 14

## VÄIKE ALGUSTÄHT
URL: https://www.opiq.ee/kit/135/chapter/7479
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.46
Topics ET: matemaatika, väike, algustäht, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: VÄIKE ALGUSTÄHT; Lisaülesanne 86

## Aprillipäev, naljapäev – 1. aprill
URL: https://www.opiq.ee/kit/135/chapter/7480
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.47
Topics ET: matemaatika, aprillipäev, naljapäev, aprill
Topics RU: математика
Topics EN: mathematics
Headings: Aprillipäev, naljapäev – 1. aprill

## Naljapäevad
URL: https://www.opiq.ee/kit/135/chapter/7460
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.48
Topics ET: matemaatika, naljapäevad
Topics RU: математика
Topics EN: mathematics
Headings: Naljapäevad

## Lapsesuu ei valeta
URL: https://www.opiq.ee/kit/135/chapter/7481
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.49
Topics ET: matemaatika, lapsesuu, valeta
Topics RU: математика
Topics EN: mathematics
Headings: Lapsesuu ei valeta

## Eesti Vabariigi väljakuulutamine
URL: https://www.opiq.ee/kit/135/chapter/7438
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.5
Topics ET: matemaatika, eesti, vabariigi, väljakuulutamine
Topics RU: математика
Topics EN: mathematics
Headings: Eesti Vabariigi väljakuulutamine

## Munakuu
URL: https://www.opiq.ee/kit/135/chapter/7461
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.50
Topics ET: matemaatika, munakuu, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Munakuu; Lisaülesanne 87

## Hea õnn
URL: https://www.opiq.ee/kit/135/chapter/7462
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.51
Topics ET: matemaatika, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Hea õnn; Lisaülesanne 88

## HANS CHRISTIAN ANDERSEN
URL: https://www.opiq.ee/kit/135/chapter/7482
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.52
Topics ET: matemaatika, hans, christian, andersen, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: HANS CHRISTIAN ANDERSEN; Lisaülesanne 89

## Keisri uued rõivad
URL: https://www.opiq.ee/kit/135/chapter/7463
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.53
Topics ET: matemaatika, keisri, uued, rõivad, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Keisri uued rõivad; Lisaülesanne 90

## Praetud kala friikartulitega
URL: https://www.opiq.ee/kit/135/chapter/7464
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.54
Topics ET: matemaatika, praetud, kala, friikartulitega, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Praetud kala friikartulitega; Lisaülesanne 91

## Kontrolltöö 6
URL: https://www.opiq.ee/kit/135/chapter/20825
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.55
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 6

## Undi ja jänese talvekortel
URL: https://www.opiq.ee/kit/135/chapter/7439
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.6
Topics ET: matemaatika, undi, jänese, talvekortel, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Undi ja jänese talvekortel; Lisaülesanne 69

## Kes mängida veel ei oska...
URL: https://www.opiq.ee/kit/135/chapter/7440
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.7
Topics ET: matemaatika, mängida, veel, oska
Topics RU: математика
Topics EN: mathematics
Headings: Kes mängida veel ei oska...

## KOMAGA JA KOMATA SIDESÕNAD
URL: https://www.opiq.ee/kit/135/chapter/7466
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.8
Topics ET: matemaatika, komaga, komata, sidesõnad, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: KOMAGA JA KOMATA SIDESÕNAD; Komaga sidesõnad; Komata sidesõnad; Lisaülesanne 70

## Lumememm, lumememm, vahva mees!
URL: https://www.opiq.ee/kit/135/chapter/7441
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 6.9
Topics ET: matemaatika, lumememm, vahva, mees
Topics RU: математика
Topics EN: mathematics
Headings: Lumememm, lumememm, vahva mees!; 1.; 2.

## Peatükis „Kevade on sala tulnud…”
URL: https://www.opiq.ee/kit/135/chapter/7497
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.1
Topics ET: matemaatika, peatükis, kevade, sala, tulnud
Topics RU: математика
Topics EN: mathematics
Headings: Peatükis „Kevade on sala tulnud…”

## Portree
URL: https://www.opiq.ee/kit/135/chapter/7488
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.10
Topics ET: matemaatika, portree, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Portree; Lisaülesanne 98; Lisaülesanne 99

## Mõista, mõista, veike vader
URL: https://www.opiq.ee/kit/135/chapter/7489
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.11
Topics ET: matemaatika, mõista, veike, vader, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Mõista, mõista, veike vader; Lisaülesanne 100

## Tunnikontroll 16
URL: https://www.opiq.ee/kit/135/chapter/20827
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.12
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 16

## Oh sina paha peavalu...
URL: https://www.opiq.ee/kit/135/chapter/7500
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.13
Topics ET: matemaatika, sina, paha, peavalu, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Oh sina paha peavalu...; Lisaülesanne 101

## LÜHENDID
URL: https://www.opiq.ee/kit/135/chapter/7501
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.14
Topics ET: matemaatika, lühendid, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: LÜHENDID; Lisaülesanne 102

## Kunksmoori köharohu retsept
URL: https://www.opiq.ee/kit/135/chapter/7502
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.15
Topics ET: matemaatika, kunksmoori, köharohu, retsept, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kunksmoori köharohu retsept; Lisaülesanne 103

## Kunksmoori haigus
URL: https://www.opiq.ee/kit/135/chapter/7490
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.16
Topics ET: matemaatika, kunksmoori, haigus
Topics RU: математика
Topics EN: mathematics
Headings: Kunksmoori haigus

## Kohandatud harjutusprogramm
URL: https://www.opiq.ee/kit/135/chapter/7491
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.17
Topics ET: matemaatika, kohandatud, harjutusprogramm
Topics RU: математика
Topics EN: mathematics
Headings: Kohandatud harjutusprogramm

## Tunnikontroll 17
URL: https://www.opiq.ee/kit/135/chapter/20828
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.18
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 17

## Pisike puu
URL: https://www.opiq.ee/kit/135/chapter/7503
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.19
Topics ET: matemaatika, taim, taimed, puu, lill, pisike
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Pisike puu

## Kevad
URL: https://www.opiq.ee/kit/135/chapter/7498
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, lisaülesanne
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Kevad; Lisaülesanne 92

## Õlikatk
URL: https://www.opiq.ee/kit/135/chapter/7492
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.20
Topics ET: matemaatika, õlikatk, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Õlikatk; Lisaülesanne 104; Lisaülesanne 105

## Võime
URL: https://www.opiq.ee/kit/135/chapter/7493
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.21
Topics ET: matemaatika, võime, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Võime; 1.; 2.; Lisaülesanne 106

## Ämblik
URL: https://www.opiq.ee/kit/135/chapter/7494
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.22
Topics ET: matemaatika, ämblik, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Ämblik; Lisaülesanne 107; Lisaülesanne 108

## Nahavärv
URL: https://www.opiq.ee/kit/135/chapter/7495
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.23
Topics ET: matemaatika, nahavärv
Topics RU: математика
Topics EN: mathematics
Headings: Nahavärv

## Soe klassipilt
URL: https://www.opiq.ee/kit/135/chapter/7496
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.24
Topics ET: matemaatika, klassipilt
Topics RU: математика
Topics EN: mathematics
Headings: Soe klassipilt; 1.; 2.

## Kontrolltöö 7
URL: https://www.opiq.ee/kit/135/chapter/20829
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.25
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 7

## Kevade on tulnud
URL: https://www.opiq.ee/kit/135/chapter/7499
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.3
Topics ET: matemaatika, kevade, tulnud, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Kevade on tulnud; Lisaülesanne 93

## Tunnikontroll 15
URL: https://www.opiq.ee/kit/135/chapter/20826
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.4
Topics ET: matemaatika, tunnikontroll
Topics RU: математика
Topics EN: mathematics
Headings: Tunnikontroll 15

## Vareste jutt
URL: https://www.opiq.ee/kit/135/chapter/7483
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.5
Topics ET: matemaatika, vareste, jutt, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Vareste jutt; Lisaülesanne 94

## Inetu pardipoeg
URL: https://www.opiq.ee/kit/135/chapter/7484
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.6
Topics ET: matemaatika, inetu, pardipoeg, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Inetu pardipoeg; 1.; 3.; Lisaülesanne 95

## Rebase-onu ja Jänku-onu
URL: https://www.opiq.ee/kit/135/chapter/7485
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.7
Topics ET: matemaatika, rebase, jänku, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: Rebase-onu ja Jänku-onu; Lisaülesanne 96

## Karuemal on karupoisid...
URL: https://www.opiq.ee/kit/135/chapter/7486
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.8
Topics ET: matemaatika, karuemal, karupoisid
Topics RU: математика
Topics EN: mathematics
Headings: Karuemal on karupoisid...

## LIITSÕNA
URL: https://www.opiq.ee/kit/135/chapter/7487
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 7.9
Topics ET: matemaatika, liitsõna, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: LIITSÕNA; Lisaülesanne 97

## Sõnaseletused
URL: https://www.opiq.ee/kit/135/chapter/7504
Book: ILUS EMAKEEL – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 3._klassi_eesti_keel
Chapter ID: 8.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## KOOS ON VAHVA. Sõprade seiklused – Opiq
URL: https://www.opiq.ee/Kit/Details/140
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 369
Topics ET: matemaatika, koos, vahva, sõprade, seiklused, opiq
Topics RU: математика
Topics EN: mathematics

## KOOS ON VAHVA. Sõprade seiklused – Opiq
URL: https://www.opiq.ee/Kit/Details/140
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 424
Topics ET: matemaatika, koos, vahva, sõprade, seiklused, opiq
Topics RU: математика
Topics EN: mathematics

## Sissejuhatus
URL: https://www.opiq.ee/kit/140/chapter/7780
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 1.1
Topics ET: matemaatika, sissejuhatus
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus

## Tere jälle, armas sõber!
URL: https://www.opiq.ee/kit/140/chapter/7775
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 1.2
Topics ET: matemaatika, tere, jälle, armas, sõber, vasta, küsimustele, luuletust, tunniplaan, kolmanda
Topics RU: математика
Topics EN: mathematics
Headings: Tere jälle, armas sõber!; 1. VASTA KÜSIMUSTELE!; 2. LOE LUULETUST!; Tere!; 3. TUNNIPLAAN; Minu kolmanda klassi tunniplaan:; 4. VAATA PIIA TUNNIPLAANI JA RÄÄGI!; 5. RÄÄGI!; 6. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Aitame väiksemaid
URL: https://www.opiq.ee/kit/140/chapter/7776
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 1.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, aitame, väiksemaid, esita, küsimusi, luuletust, esimesel, koolipäeval, kirjuta
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Aitame väiksemaid; 1. ESITA KÜSIMUSI!; 2. LOE LUULETUST!; Esimesel koolipäeval; 3. KIRJUTA!; 4. E-ÜLESANNE; E-ül; 5. LOE! JÄTA MEELDE!; 6. VÕRDLE!; 7. VAATA PILTI. VASTA KÜSIMUSTELE!; 8. E-ÜLESANNE; 9. VAATA PILTE.; 10. RÄÄGI SÕBRAGA!

## Sööklas
URL: https://www.opiq.ee/kit/140/chapter/7777
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 1.4
Topics ET: matemaatika, sööklas, valesti, milline, sõna, sobi, teiste, hulka, jäta, meelde
Topics RU: математика
Topics EN: mathematics
Headings: Sööklas; 1. MIS ON VALESTI?; E-ül; 2. MILLINE SÕNA EI SOBI TEISTE HULKA?; 3. LOE! JÄTA MEELDE!; 4. LOE!; 5. VAADAKE KINGITUSI. ESITAGE KÜSIMUSI JA VASTAKE!; 6. VAATA MÕISTEKAARTI JA RÄÄGI!; 7. RÄÄGI SÕBRAGA!; 8. E-ÜLESANNE

## Kristiina Kass „Nõianeiu Nöbinina”
URL: https://www.opiq.ee/kit/140/chapter/7778
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 1.5
Topics ET: matemaatika, kristiina, kass, nõianeiu, nöbinina, saame, tuttavaks, eesti, kirjanikuga, vasta
Topics RU: математика
Topics EN: mathematics
Headings: Kristiina Kass „Nõianeiu Nöbinina”; SAAME TUTTAVAKS EESTI KIRJANIKUGA – KRISTIINA KASS; NÕIANEIU NÖBININA; 1. VASTA KÜSIMUSTELE!; 2. JUTUSTA!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7779
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 1.6
Topics ET: matemaatika, nüüd, oskan, räägi, vaata, pilte, kirjuta, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1 RÄÄGI!; 2. LOE!; 3. VAATA PILTE JA RÄÄGI!; 4. KIRJUTA!; 5. RÄÄGI SÕBRAGA!; 6. E-ÜLESANNE; E-ül

## Spordipäev
URL: https://www.opiq.ee/kit/140/chapter/7781
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 2.1
Topics ET: matemaatika, spordipäev, õige, vale, mida, lapsed, teevad, vaata, pilte, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Spordipäev; 1. ÕIGE VÕI VALE?; E-ül; 2. MIDA LAPSED TEEVAD? VAATA PILTE JA RÄÄGI!; 3. MILLEGA SINA KOOLI / KOJU / METSA / VANAEMA JA VANAISA JUURDE / TRENNI / … SÕIDAD?; 4. RÄÄGI SÕBRAGA!; 5. KIRJUTA!; 6. AINSUS JA MITMUS; 7. LOE!; 8. RÄÄGI!; 9. E-ÜLESANNE

## Matk
URL: https://www.opiq.ee/kit/140/chapter/7782
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 2.2
Topics ET: matemaatika, matk, lõpeta, laused, luuletust, mets, räägi, seda, tohib
Topics RU: математика
Topics EN: mathematics
Headings: Matk; 1. LÕPETA LAUSED!; 2. E-ÜLESANNE; E-ül; 3. LOE LUULETUST!; Mets; 4. RÄÄGI!; 5. LOE JA RÄÄGI!; 6. KAS SEDA TOHIB VÕI EI TOHI METSAS TEHA?; 7. KAS TOHIB VÕI EI TOHI?; 8. TEEME RÜHMATÖÖD!; 9. RÄÄGI SÕBRAGA!; 10. E-ÜLESANNE; 11. E-ÜLESANNE

## Lähme rattaga sõitma! I
URL: https://www.opiq.ee/kit/140/chapter/7783
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 2.3
Topics ET: matemaatika, lähme, rattaga, sõitma, jutusta, räägi, moodusta, lauseid, mida, teed
Topics RU: математика
Topics EN: mathematics
Headings: Lähme rattaga sõitma! I; LÄHME RATTAGA SÕITMA!​I; 1. JUTUSTA!; 2. RÄÄGI!; 3. MOODUSTA LAUSEID!; 4. MIDA SA TEED KOOS … ? LÕPETA LAUSED!; 5. E-ÜLESANNE; E-ül

## Lähme rattaga sõitma! II
URL: https://www.opiq.ee/kit/140/chapter/7784
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 2.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, lähme, rattaga, sõitma, mõtle, põhjal, välja, kolm, küsimust, ainsus
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Lähme rattaga sõitma! II; LÄHME RATTAGA SÕITMA!​II; 1. MÕTLE LOO PÕHJAL VÄLJA KOLM KÜSIMUST!; 2. AINSUS JA MITMUS. LOE JA VÕRDLE!; 3. E-ÜLESANNE; E-ül; 4. KIRJUTA ALLAJOONITUD SÕNU MITMUSES!; 5. RÄÄGI SÕBRAGA!

## Leelo Tungal
URL: https://www.opiq.ee/kit/140/chapter/7785
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 2.5
Topics ET: matemaatika, leelo, tungal, saame, tuttavaks, eesti, kirjanikuga, lugege, koos, luuletusi
Topics RU: математика
Topics EN: mathematics
Headings: Leelo Tungal; SAAME TUTTAVAKS EESTI KIRJANIKUGA – LEELO TUNGAL; 1. LUGEGE KOOS LUULETUSI.; Saapameri; Kui ma …; 2. TEEME RÜHMATÖÖD!; 3. E-ÜLESANNE; E-ül; 4. E-ÜLESANNE; LISAÜLESANNE 1

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7786
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 2.6
Topics ET: matemaatika, nüüd, oskan, räägi, kirjuta, allajoonitud, sõnad, mitmuses, ütle, tegusõna
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. LOE JA KIRJUTA ALLAJOONITUD SÕNAD MITMUSES!; E-ül; 3. ÜTLE JA KIRJUTA TEGUSÕNA JOOKSMA VÕI SÕITMA ÕIGE VORM!; 4. RÄÄGI!; 5. E-ÜLESANNE

## Janno saab varsti õe
URL: https://www.opiq.ee/kit/140/chapter/7787
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 3.1
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, janno, saab, varsti, vasta, küsimustele, räägi, küsi, sõbralt, küsimusi
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Janno saab varsti õe; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI!; 3. KÜSI SÕBRALT KÜSIMUSI! VASTA!; 4. E-ÜLESANNE; E-ül; 5. VAATA! LOE JA VÕRDLE!; 6. MISSUGUNE? LOE JA VÕRDLE!; 7. E-ÜLESANNE; 8. TÄIDA LÜNGAD!; 9. RÄÄGI SÕBRAGA!

## Palun aita mind!
URL: https://www.opiq.ee/kit/140/chapter/7788
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 3.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, palun, aita, mind, valesti, toad, sinu, kodus, räägi, luuletust
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Palun aita mind!; 1. MIS ON VALESTI?; E-ül; 2. MIS TOAD ON SINU KODUS?; 3. RÄÄGI!; 4. LOE LUULETUST!; Tigu[sõnaseletus: tigu – улитка]; LISAÜLESANNE 1; 5. KIRJELDA PILTI!; 6. KIRJUTA!; 7. VAATA, LOE JA VÕRDLE!; 8. MISSUGUNE? LOE JA VÕRDLE!; 9. LÕPETA LAUSED!; 10. TEEME RÜHMATÖÖD!; 11. E-ÜLESANNE; 12. E-ÜLESANNE

## Jagatud mure on pool muret
URL: https://www.opiq.ee/kit/140/chapter/7789
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 3.3
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, võrdlemine, võrdle, suurem, väiksem, jagatud, mure, muret, lisaülesanne, esita, küsimusi, miks, tohi
Topics RU: математика, деление, раздели, частное, половина, сравнение, сравни, больше, меньше
Topics EN: mathematics, division, divide, quotient, half, comparison, compare, greater, less
Headings: Jagatud mure on pool muret; LISAÜLESANNE 1; 1. ESITA KÜSIMUSI!; 2. MIKS EI TOHI TUNDI SEGADA? JUTUSTA!; 3. JUTUSTA!; 4. E-ÜLESANNE; E-ül; 5. MISSUGUNE?; 6. ANTONÜÜMID. LOE JA VÕRDLE!; 7. KIRJUTA!; 8. MIS SÕNA SOBIB LÜNKA? KASUTA OMADUSSÕNU ÜLESANDEST 5!; 9. LOE LUULETUST!; Pahur laps; 10. E-ÜLESANNE

## Ilmar Tomusk „Volli on lind”
URL: https://www.opiq.ee/kit/140/chapter/7790
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 3.4
Topics ET: matemaatika, ilmar, tomusk, volli, lind, saame, tuttavaks, eesti, kirjanikuga, vasta
Topics RU: математика
Topics EN: mathematics
Headings: Ilmar Tomusk „Volli on lind”; SAAME TUTTAVAKS EESTI KIRJANIKUGA – ILMAR TOMUSK; VOLLI ON LIND; 1. VASTA KÜSIMUSTELE! RÄÄGI!; 2. TEEME PAARISTÖÖD!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1; Kava

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7791
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 3.5
Topics ET: matemaatika, nüüd, oskan, räägi, täida, lüngad, sulgudes, olevate, sõnade, asemel
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. TÄIDA LÜNGAD!; E-ül; 3. LOE! SULGUDES OLEVATE SÕNADE ASEMEL KASUTA ANTONÜÜMI!; 4. LOE TEKSTI JA TÄIDA LÜNGAD!; 5. RÄÄGI!

## Mulle meeldib raamatuid lugeda
URL: https://www.opiq.ee/kit/140/chapter/7792
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 4.1
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, mulle, meeldib, raamatuid, lugeda, õige, vale, räägi, jäta
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Mulle meeldib raamatuid lugeda; 1. ÕIGE VÕI VALE?; E-ül; 2. RÄÄGI!; 3. LOE, VÕRDLE JA JÄTA MEELDE! KELLELE?; 4. VALI ÕIGE. LOE!; 5. LÕPETA LAUSED!; 6. LOE! LISA LÜNKA SOBIV OMADUSSÕNA!; 7. KIRJUTA LÜNKA SOBIV TEGUSÕNA TAHTMA VORM!; 8. TEEME RÜHMATÖÖD!; 9. RÄÄGI SÕBRAGA!

## Mis seal sees on? I
URL: https://www.opiq.ee/kit/140/chapter/7793
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 4.2
Topics ET: matemaatika, seal, sees, lõpeta, laused, vaata, jäta, meelde, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Mis seal sees on? I; MIS SEAL SEES ON?​I; 1. LÕPETA LAUSED!; 2. VAATA JA JÄTA MEELDE!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## Mis seal sees on? II
URL: https://www.opiq.ee/kit/140/chapter/7794
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 4.3
Topics ET: matemaatika, seal, sees, jutusta, lugu, luuletust, tramburai, vasta, küsimustele, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Mis seal sees on? II; MIS SEAL SEES ON?​II; 1. JUTUSTA LUGU „MIS SEAL SEES ON?”!; 2. LOE LUULETUST!; Tramburai; 3. VASTA KÜSIMUSTELE!; 4. KIRJUTA!; 5. E-ÜLESANNE; E-ül

## Piia on päkapikk
URL: https://www.opiq.ee/kit/140/chapter/7795
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 4.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, piia, päkapikk, mõtle, teksti, põhjal, välja, kolm, küsimust
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Piia on päkapikk; 1. MÕTLE TEKSTI PÕHJAL VÄLJA KOLM KÜSIMUST!; 2. LOE, VÕRDLE JA JÄTA MEELDE!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Aino Pervik „Koolijõulupuu”
URL: https://www.opiq.ee/kit/140/chapter/7796
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 4.5
Topics ET: matemaatika, aino, pervik, koolijõulupuu, saame, tuttavaks, eesti, kirjanikuga, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Aino Pervik „Koolijõulupuu”; SAAME TUTTAVAKS EESTI KIRJANIKUGA – AINO PERVIK; KOOLIJÕULUPUU; 1. RÄÄGI!; 2. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7797
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 4.6
Topics ET: matemaatika, nüüd, oskan, räägi, lõpeta, laused, kirjuta, lünka, tegussõna, tahtma
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. LÕPETA LAUSED!; 3. KIRJUTA LÜNKA TEGUSSÕNA TAHTMA ÕIGE VORM.; E-ül; 4. LOE LUULETUST JA VASTA KÜSIMUSTELE!; Muri saba liputab; 5. RÄÄGI!

## Kõigil on kogu aeg kiire
URL: https://www.opiq.ee/kit/140/chapter/7798
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 5.1
Topics ET: matemaatika, aeg, kell, kalender, kõigil, kogu, kiire, esita, küsimusi, ankeete, janno, kohta
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Kõigil on kogu aeg kiire; 1. ESITA KÜSIMUSI!; 2. LOE ANKEETE JANNO EMA JA ISA KOHTA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1; Ema ja isa; 4. RÄÄGI!; 5. KUHU? KUS? KUST?; 6. VALI PAKSUS KIRJAS SÕNADE KOHTA ÕIGE KÜSIMUS!; 7. E-ÜLESANNE; 8. MOODUSTA LAUSEID!; 9. LOE LUULETUST!; Vaikne lumi; 10. TEEME RÜHMATÖÖD!

## Kui öösel ei tule und
URL: https://www.opiq.ee/kit/140/chapter/7799
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 5.2
Topics ET: matemaatika, öösel, tule, valesti, harjuta, kirjuta, joonista, kuhu, kust, lõpeta
Topics RU: математика
Topics EN: mathematics
Headings: Kui öösel ei tule und; 1. MIS ON VALESTI?; E-ül; 2. LOE JA HARJUTA!; 3. KIRJUTA JA JOONISTA!; 4. KUHU? KUS? KUST?; 5. LÕPETA LAUSED!; 6. VAATA PILTE! RÄÄGI!; 7. TÄIDA LÜNGAD!; 8. RÄÄGI SÕBRAGA!; 9. E-ÜLESANNE

## Tüdrukute mängud ja poiste mängud I
URL: https://www.opiq.ee/kit/140/chapter/7800
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 5.3
Topics ET: matemaatika, tüdrukute, mängud, poiste, lõpeta, laused, räägi, sõbraga, kirjuta, jutt
Topics RU: математика
Topics EN: mathematics
Headings: Tüdrukute mängud ja poiste mängud I; TÜDRUKUTE MÄNGUD JA POISTE MÄNGUD​I; 1. LÕPETA LAUSED!; 2. RÄÄGI SÕBRAGA!; 3. RÄÄGI!; 4. KIRJUTA JUTT!; 5. E-ÜLESANNE; E-ül

## Tüdrukute mängud ja poiste mängud II
URL: https://www.opiq.ee/kit/140/chapter/7801
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 5.4
Topics ET: matemaatika, tüdrukute, mängud, poiste, jutusta, lugu, täida, lüngad, luuletust, vasta
Topics RU: математика
Topics EN: mathematics
Headings: Tüdrukute mängud ja poiste mängud II; TÜDRUKUTE MÄNGUD JA POISTE MÄNGUD​II; 1. JUTUSTA LUGU „TÜDRUKUTE MÄNGUD JA POISTE MÄNGUD”!; 2. TÄIDA LÜNGAD!; E-ül; 3. LOE LUULETUST JA VASTA KÜSIMUSTELE!; Onu Heino – tore mees

## Mõtelda on mõnus
URL: https://www.opiq.ee/kit/140/chapter/7802
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 5.5
Topics ET: matemaatika, mõtelda, mõnus, lisaülesanne, kirjuta, teeme, näidendit, mida, sina, hommikusöögiks
Topics RU: математика
Topics EN: mathematics
Headings: Mõtelda on mõnus; LISAÜLESANNE 1; 1. KIRJUTA!; 2. TEEME NÄIDENDIT!; 3. MIDA SINA HOMMIKUSÖÖGIKS SÖÖD JA JOOD?; 4. MIDA SA SÖÖD JA JOOD LÕUNA- JA ÕHTUSÖÖGIKS?; 5. LOE LUULETUST!; 6. VASTA KÜSIMUSTELE!; 7. E-ÜLESANNE; E-ül; 8. LOE JA KIRJUTA!; 9. TEEME RÜHMATÖÖD!; 10. RÄÄGI SÕBRAGA!; 11. KIRJUTA!; 12. E-ÜLESANNE

## Heljo Mänd „Viis kirja”
URL: https://www.opiq.ee/kit/140/chapter/7803
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 5.6
Topics ET: matemaatika, heljo, mänd, viis, kirja, saame, tuttavaks, eesti, kirjanikuga, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Heljo Mänd „Viis kirja”; SAAME TUTTAVAKS EESTI KIRJANIKUGA – HELJO MÄND; VIIS KIRJA; 1. KIRJUTA!; 2. VASTA KÜSIMUSTELE!; 3. VAATA MÕISTEKAARTI JA JUTUSTA, MILLEST RÄÄKIS JUTT „VIIS KIRJA”!; 4. E-ÜLESANNE; E-ül

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7804
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 5.7
Topics ET: matemaatika, nüüd, oskan, räägi, vasta, küsimustele, täida, lüngad
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. VASTA KÜSIMUSTELE!; 3. LOE JA TÄIDA LÜNGAD!; E-ül; 4. RÄÄGI!; 5. E-ÜLESANNE

## Villule meeldib kihutada
URL: https://www.opiq.ee/kit/140/chapter/7805
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 6.1
Topics ET: matemaatika, villule, meeldib, kihutada, vasta, küsimustele, luuletust, trollid, trollibussis, mõiste
Topics RU: математика
Topics EN: mathematics
Headings: Villule meeldib kihutada; 1. VASTA KÜSIMUSTELE!; 2. LOE LUULETUST!; Trollid trollibussis[mõiste: troll – mäevaim, kuri haldjas]; 3. RÄÄGI SÕBRAGA!; 4. VAATA JA JÄTA MEELDE!; 5. VAATA PILTI JA RÄÄGI!; 6. KUIDAS SINA TÄNAVAL LIIKLED? RÄÄGI!; 7. E-ÜLESANNE; E-ül; 8. MOODUSTA LAUSEID!; 9. E-ÜLESANNE

## Piia õpib salakeelt
URL: https://www.opiq.ee/kit/140/chapter/7806
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 6.2
Topics ET: matemaatika, piia, õpib, salakeelt, esita, küsimusi, allajoonitud, sõnade, kohta, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Piia õpib salakeelt; 1. ESITA KÜSIMUSI!; 2. ESITA ALLAJOONITUD SÕNADE KOHTA KÜSIMUSED!; 3. PANE SÕNAD ÕIGESSE JÄRJEKORDA! VASTA KÜSIMUSTELE!; 4. RÄÄGI SÕBRAGA!; 5. RÄÄGI!; 6. VAATA KAARTI JA VASTA KÜSIMUSTELE!; 7. RÄÄGI SÕBRAGA!; 8. E-ÜLESANNE; E-ül; 9. VAATA KAARTI ÜLESANDES 6. RÄÄGI!; 10. LOE LUULETUST!; 11. E-ÜLESANNE; 12. RÄÄGI!; 13. E-ÜLESANNE; LISAÜLESANNE 1

## Birgitil on sünnipäev I
URL: https://www.opiq.ee/kit/140/chapter/7807
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 6.3
Topics ET: matemaatika, birgitil, sünnipäev, vali, õige, variant, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Birgitil on sünnipäev I; BIRGITIL ON SÜNNIPÄEV​I; 1. VALI ÕIGE VARIANT!; E-ül; 2 RÄÄGI!; 3. RÄÄGI

## Birgitil on sünnipäev II
URL: https://www.opiq.ee/kit/140/chapter/7808
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 6.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, birgitil, sünnipäev, vasta, küsimustele, kirjalikult, vihikusse, kutset, kirjuta, koos
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Birgitil on sünnipäev II; BIRGITIL ON SÜNNIPÄEV​​II; 1. VASTA KÜSIMUSTELE KIRJALIKULT VIHIKUSSE!; 2. LOE KUTSET! VASTA KÜSIMUSTELE!; 3. KIRJUTA KOOS ÕPETAJAGA!; 4. VÕRDLE!; 5. E-ÜLESANNE; E-ül

## Hambaarsti juures
URL: https://www.opiq.ee/kit/140/chapter/7809
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 6.5
Topics ET: matemaatika, hambaarsti, juures, õige, vale, luuletust, doktor, irma, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Hambaarsti juures; 1. ÕIGE VÕI VALE?; E-ül; 2. LOE LUULETUST!; Doktor Irma; 3. RÄÄGI SÕBRAGA!; 4. MIDA ARST TEEB? VAATA JA LOE!; 5. VASTA KÜSIMUSTELE!; 6. Vali õige variant!; 7. E-ÜLESANNE; 8. TÄIDA LÜNGAD!; 9. LOE JA HARJUTA KLASSIKAASLASEGA!

## Andrus Kivirähk „Karneval ja kartulisalat”
URL: https://www.opiq.ee/kit/140/chapter/7810
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 6.6
Topics ET: matemaatika, andrus, kivirähk, karneval, kartulisalat, saame, tuttavaks, eesti, kirjanikuga, jutusta
Topics RU: математика
Topics EN: mathematics
Headings: Andrus Kivirähk „Karneval ja kartulisalat”; SAAME TUTTAVAKS EESTI KIRJANIKUGA –ANDRUS KIVIRÄHK; KARNEVAL JA KARTULISALAT; 1. JUTUSTA!; 2. TEEME RÜHMATÖÖD!; 3. E-ÜLESANNE; E-ül

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7811
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 6.7
Topics ET: matemaatika, nüüd, oskan, räägi, kuidas, sina, tänaval, liikled, vali, õige
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. KUIDAS SINA TÄNAVAL LIIKLED? RÄÄGI!; 3. VALI ÕIGE VARIANT. LOE.; E-ül; 4. RÄÄGI!; 5. E-ÜLESANNE

## Telefonitarkus
URL: https://www.opiq.ee/kit/140/chapter/7812
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 7.1
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, telefonitarkus, lõpeta, laused, moodusta, lauseid, räägi, mida, peab
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Telefonitarkus; 1. LÕPETA LAUSED!; 2. MOODUSTA LAUSEID!; 3. RÄÄGI!; 4. LOE JA VÕRDLE!; 5. MIDA PEAB TEGEMA? ÜTLE!; 6. LOE KÄSKE! KES VÕIKS NEID ÖELDA?; 7. LOE JA VÕRDLE!; 8. E-ÜLESANNE; E-ül; 9. TÄIDA LÜNGAD! KASUTA ÄRA-VORMI!; 10. RÄÄGI SÕBRAGA!; 11. E-ÜLESANNE

## Rahakassa
URL: https://www.opiq.ee/kit/140/chapter/7813
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 7.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, rahakassa, valesti, kirjuta, lünka, sõna, pühkima, õige, vorm, räägi
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Rahakassa; 1. MIS ON VALESTI?; E-ül; 2. KIRJUTA LÜNKA SÕNA PÜHKIMA ÕIGE VORM!; 3. RÄÄGI!; 4. MIS NEED ON? LOE!; 5. MIDA SA NENDEGA TEED? RÄÄGI!; 6. RÄÄGI!; 7. LOE LUULETUST!; Talv kõhus; 8. MOODUSTA KÄSKIVAID LAUSEID!; 9. RÄÄGI SÕBRAGA!; 10. E-ÜLESANNE

## Oota mind ka!
URL: https://www.opiq.ee/kit/140/chapter/7814
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 7.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, oota, mind, vasta, küsimustele, teeme, rühmatööd, kirjuta, sõna, sobi
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Oota mind ka!; 1. VASTA KÜSIMUSTELE!; 2. TEEME RÜHMATÖÖD!; 3. KIRJUTA!; 4. MIS SÕNA EI SOBI RITTA? MIKS?; E-ül; 5. LOE JA VÕRDLE!; 6. LÕPETA LAUSED!; 7. VALI ÕIGE VORM! LOE!; 8. TÄIDA LÜNGAD!; 9. RÄÄGI SÕBRAGA!; 10. KIRJUTA!; 11. E-ÜLESANNE

## Kui palju sõpru sul on? I
URL: https://www.opiq.ee/kit/140/chapter/7815
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 7.4
Topics ET: matemaatika, palju, sõpru, vali, loetud, teksti, põhjal, õige, variant, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Kui palju sõpru sul on? I; KUI PALJU SÕPRU SUL ON?​I; 1. VALI LOETUD TEKSTI PÕHJAL ÕIGE VARIANT!; E-ül; 2. RÄÄGI!; 3. LOE LUULETUST!

## Kui palju sõpru sul on? II
URL: https://www.opiq.ee/kit/140/chapter/7816
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 7.5
Topics ET: matemaatika, palju, sõpru, vaata, mõttekaarti, jutusta, lugu, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Kui palju sõpru sul on? II; KUI PALJU SÕPRU SUL ON?​II; 1. E-ÜLESANNE; E-ül; 2. VAATA MÕTTEKAARTI JA JUTUSTA LUGU „KUI PALJU SÕPRU SUL ON?”; 3. RÄÄGI SÕBRAGA!

## Piret Raud „Kartlik mobiiltelefon”
URL: https://www.opiq.ee/kit/140/chapter/7817
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 7.6
Topics ET: matemaatika, piret, raud, kartlik, mobiiltelefon, saame, tuttavaks, eesti, kirjanikuga, mõiste
Topics RU: математика
Topics EN: mathematics
Headings: Piret Raud „Kartlik mobiiltelefon”; SAAME TUTTAVAKS EESTI KIRJANIKUGA – PIRET RAUD; KARTLIK[mõiste: kartlik – arg] MOBIILTELEFON; 1. VASTA KÜSIMUSTELE!; 2. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7818
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 7.7
Topics ET: matemaatika, nüüd, oskan, räägi, need, mida, nendega, teed, arvad, võib
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. MIS NEED ON? MIDA SA NENDEGA TEED?; 3. MIS SA ARVAD, KES VÕIB NII ÖELDA? MILLAL?; 4. TEE EELMISE ÜLESANDE LAUSED ÜMBER!; 5. RÄÄGI SÕBRAGA!; 6. E-ÜLESANNE; E-ül

## Põnevad hetked
URL: https://www.opiq.ee/kit/140/chapter/7819
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.1
Topics ET: matemaatika, aeg, kell, kalender, põnevad, hetked, õige, vale, teksti, asenda, pildid, sõnadega, räägi
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Põnevad hetked; 1. ÕIGE VÕI VALE?; E-ül; 2. LOE TEKSTI! ASENDA PILDID SÕNADEGA!; 3. RÄÄGI SÕBRAGA!; 4. KORDAME!; 5. MOODUSTA LAUSEID! KASUTA SÕNU TABELIST!; 6. TÄIDA LÜNGAD!; 7. RÄÄGI PINGINAABRILE, MIS KELL SINA MIDAGI TEED JA KUULA, MIDA TEMA SULLE RÄÄGIB!; 8. KIRJUTA!

## Antiigipoes
URL: https://www.opiq.ee/kit/140/chapter/7820
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.2
Topics ET: matemaatika, antiigipoes, vasta, küsimustele, kirjalikult, vihikusse, luuletust, tule, meiega, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Antiigipoes; 1. VASTA KÜSIMUSTELE KIRJALIKULT VIHIKUSSE!; 2. LOE LUULETUST!; Tule meiega; 3. RÄÄGI!; 4. KIRJUTA LÜNKA SOBIV TEGUSÕNA HOIDMA VORM!; E-ül; 5. KORDAME! MUUDA ALLAJOONITUD SÕNA VASTUPIDISEKS!; 6. RÄÄGI SÕBRALE OMA EMAST JA KUULA, MIDA TEMA OMA EMA KOHTA ÜTLEB!; 7. VALI ÕIGE VARIANT!; 8. RÄÄGI SÕBRAGA!; 9. KIRJUTA!

## Muki ajab asju I
URL: https://www.opiq.ee/kit/140/chapter/7821
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.3
Topics ET: matemaatika, muki, ajab, asju, esita, küsimusi, lõpeta, laused, vaata, kuulutust
Topics RU: математика
Topics EN: mathematics
Headings: Muki ajab asju I; MUKI AJAB ASJU​I; 1. ESITA KÜSIMUSI!; 2. LÕPETA LAUSED!; E-ül; 3. VAATA KUULUTUST JA VASTA KÜSIMUSTELE!; 4. RÄÄGI!

## Muki ajab asju II
URL: https://www.opiq.ee/kit/140/chapter/7822
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.4
Topics ET: matemaatika, muki, ajab, asju, koosta, kava, jutusta, kirjuta, lünka, sobiv
Topics RU: математика
Topics EN: mathematics
Headings: Muki ajab asju II; MUKI AJAB ASJU​I​I; 1. KOOSTA KAVA!; 2. JUTUSTA!; 3. KIRJUTA LÜNKA SOBIV TEGUSÕNA LEIDMA VORM!; E-ül; 4. RÄÄGI SÕBRAGA!

## Ootan suve I
URL: https://www.opiq.ee/kit/140/chapter/7823
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.5
Topics ET: matemaatika, ootan, suve, valesti, räägi, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Ootan suve I; OOTAN SUVE​I; 1. MIS ON VALESTI?; E-ül; 2. RÄÄGI!; 3. KIRJUTA!

## Ootan suve II
URL: https://www.opiq.ee/kit/140/chapter/7824
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.6
Topics ET: matemaatika, ootan, suve, suveii, vasta, küsimustele, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Ootan suve II; OOTAN SUVEII; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## Ellen Niit „Võilill” ja „Kati karu”
URL: https://www.opiq.ee/kit/140/chapter/7825
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.7
Topics ET: matemaatika, ellen, niit, võilill, kati, karu, saame, tuttavaks, eesti, kirjanikuga
Topics RU: математика
Topics EN: mathematics
Headings: Ellen Niit „Võilill” ja „Kati karu”; SAAME TUTTAVAKS EESTI KIRJANIKUGA – ELLEN NIIT; 1. LUGEGE KOOS LUULETUSI!; Võilill; Kati karu; 2. TEEME PAARISTÖÖD!; 3. E-ÜLESANNE; E-ül

## Nüüd ma oskan
URL: https://www.opiq.ee/kit/140/chapter/7826
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 8.8
Topics ET: matemaatika, nüüd, oskan, räägi, luuletust, suverõõm
Topics RU: математика
Topics EN: mathematics
Headings: Nüüd ma oskan; 1. RÄÄGI!; 2. E-ÜLESANNE; E-ül; 3. LOE LUULETUST!; Suverõõm

## Sõnaseletused
URL: https://www.opiq.ee/kit/140/chapter/7827
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 9.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Sõnastik
URL: https://www.opiq.ee/kit/140/chapter/7828
Book: KOOS ON VAHVA. Sõprade seiklused – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_teise_keelena_3._klassile
Chapter ID: 9.2
Topics ET: matemaatika, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Sõnastik

## Eesti keele õpik 3. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/179
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1
Topics ET: matemaatika, eesti, keele, õpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Eesti keele õpik 3. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/179
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 181
Topics ET: matemaatika, eesti, keele, õpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## I osa. Tere tulemast emakeele tundi!
URL: https://www.opiq.ee/kit/179/chapter/10003
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1.1
Topics ET: matemaatika, tere, tulemast, emakeele, tundi, mida, õpid, osas
Topics RU: математика
Topics EN: mathematics
Headings: I osa. Tere tulemast emakeele tundi!; Mida õpid I osas?

## Taas kooli
URL: https://www.opiq.ee/kit/179/chapter/9993
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1.2
Topics ET: matemaatika, aeg, kell, kalender, taas, kooli, september, harjutus, presidendi, kõne, mõtle, tegutse, edasi
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Taas kooli; September; Harjutus 1; Mis aeg see on?; Harjutus 2; Presidendi kõne; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Koolirahuleping

## Tegijal juhtub
URL: https://www.opiq.ee/kit/179/chapter/9994
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1.3
Topics ET: matemaatika, tegijal, juhtub, kõigil, äpardusi, harjutus, kiri, arvutis, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Tegijal juhtub; Kõigil juhtub äpardusi; Harjutus 1; Kiri arvutis; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3

## Mis on kirjandus?
URL: https://www.opiq.ee/kit/179/chapter/9995
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1.4
Topics ET: matemaatika, kirjandus, kõik, kirjapandu, ongi, harjutus, mõtle, tegutse, edasi, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Mis on kirjandus?; Kõik kirjapandu ongi kirjandus; Harjutus 1b; Harjutus 1a; Harjutus 2b; Harjutus 2a; Harjutus 3; Harjutus 3b; Harjutus 3a; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 4b; Harjutus 4a; Arutle

## Miks me loeme?
URL: https://www.opiq.ee/kit/179/chapter/9996
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1.5
Topics ET: matemaatika, miks, loeme, vaja, lugeda, harjutus, arutle, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Miks me loeme?; Miks on vaja lugeda?; Harjutus 1; Harjutus 2; Arutle; Mõtle ja tegutse edasi; Harjutus 3

## Mis on keel?
URL: https://www.opiq.ee/kit/179/chapter/9997
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1.6
Topics ET: matemaatika, keel, palju, maailmas, keeli, harjutus, kõnekeel, mida, kõneleme, kirjakeel
Topics RU: математика
Topics EN: mathematics
Headings: Mis on keel?; Kui palju on maailmas keeli?; Harjutus 1; Kõnekeel on see, mida me kõneleme; Harjutus 2; Harjutus 3; Kirjakeel on see, mida kirjutame; Mõtle ja tegutse edasi; Harjutus 4; Arutle

## Miks on vaja õigesti kirjutada?
URL: https://www.opiq.ee/kit/179/chapter/9998
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 1.7
Topics ET: matemaatika, miks, vaja, õigesti, kirjutada, emakeele, tund, harjutus, sattus, juku
Topics RU: математика
Topics EN: mathematics
Headings: Miks on vaja õigesti kirjutada?; Emakeele tund; Harjutus 1; Miks sattus Juku politseisse?; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 3c; Harjutus 3a; Harjutus 3b; Harjutus 4; Harjutus 4b; Harjutus 4a; Harjutus 5; Harjutus 6b; Harjutus 6a; Harjutus 6; Harjutus 5b; Harjutus 5a

## Sibulad ja šokolaad. Andrus Kivirähk
URL: https://www.opiq.ee/kit/179/chapter/10039
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 10.1
Topics ET: matemaatika, sibulad, šokolaad, andrus, kivirähk, kivirähki, lastenäidendid, vapper, keefir, näidend
Topics RU: математика
Topics EN: mathematics
Headings: Sibulad ja šokolaad. Andrus Kivirähk; Andrus Kivirähki lastenäidendid; Vapper Keefir; Näidend ühes vaatuses; Täiesti asustamata laud; Laual on tegelikult palju; Töö tekstiga; Harjutus 1; Harjutus 1b; Harjutus 1a; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Rühmatöö

## Tegelaste kõne näidendis
URL: https://www.opiq.ee/kit/179/chapter/10040
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 10.2
Topics ET: matemaatika, tegelaste, kõne, näidendis, mida, ütleb, kuidas, seda, harjutus, paaristöö
Topics RU: математика
Topics EN: mathematics
Headings: Tegelaste kõne näidendis; Kes mida ütleb?; Kuidas ta seda ütleb?; Harjutus 1; Paaristöö 1; Mõtle ja tegutse edasi; Paaristöö 2

## Loetelu
URL: https://www.opiq.ee/kit/179/chapter/10041
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 10.3
Topics ET: matemaatika, loetelu, kuidas, kirjutada, harjutus, loetelud, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Loetelu; Kuidas kirjutada loetelu?; Harjutus 1; Harjutus 2; Loetelud; Harjutus 3; Harjutus 4; Harjutus 3c; Harjutus 3a; Harjutus 3b; Harjutus 5; Mõtle ja tegutse edasi; Harjutus 6; Harjutus 5b; Harjutus 5a; Harjutus 7

## Kuidas näidendit lavastada?
URL: https://www.opiq.ee/kit/179/chapter/10042
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 10.4
Topics ET: matemaatika, kuidas, näidendit, lavastada, laval, harjutus, sulgudes, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas näidendit lavastada?; Mis on laval?; Harjutus 1; Harjutus 2; Mis on sulgudes?; Mõtle ja tegutse edasi; Joonista

## Tom Gatesi äge maailm (1). Liz Pichon
URL: https://www.opiq.ee/kit/179/chapter/10034
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 11.1
Topics ET: matemaatika, gatesi, maailm, pichon, pichoni, gates, tomi, päevik, arutle, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Tom Gatesi äge maailm (1). Liz Pichon; Liz Pichoni Tom Gates; Tomi päevik; Arutle; Mõtle ja tegutse edasi; Joonista

## Liidame lauseid
URL: https://www.opiq.ee/kit/179/chapter/10043
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 11.2
Topics ET: matemaatika, liidame, lauseid, mitu, tegusõna, lause, harjutus, lihtlause, liitlause, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Liidame lauseid; Mitu tegusõna, aga üks lause; Harjutus 1a; Harjutus 1b; Harjutus 1c; Lihtlause + lihtlause = liitlause; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 4b; Harjutus 4a; Harjutus 5

## Tegelaste kõne
URL: https://www.opiq.ee/kit/179/chapter/10044
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 11.3
Topics ET: matemaatika, tegelaste, kõne, jutustamine, pane, tähele, kahekõne, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Tegelaste kõne; Jutustamine või tegelaste kõne; Pane tähele!; Kahekõne; Harjutus 1a; Harjutus 1b; Harjutus 2; Mõtle ja tegutse edasi; Rühmatöö; Kirjuta

## Tom Gatesi äge maailm (2)
URL: https://www.opiq.ee/kit/179/chapter/10045
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 11.4
Topics ET: matemaatika, gatesi, maailm, tomi, päevik, arutleme, koos, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Tom Gatesi äge maailm (2); Tomi päevik; Arutleme koos; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 1b; Harjutus 1a; Kirjuta

## Ootamatu lõpplahendus ehk puänt
URL: https://www.opiq.ee/kit/179/chapter/10046
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 11.5
Topics ET: matemaatika, ootamatu, lõpplahendus, puänt, arutle, jutusta, sama, laps, harjutus, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Ootamatu lõpplahendus ehk puänt; Mis on puänt?; Arutle; Jutusta; Sama laps; Harjutus 1; Harjutus 1b; Harjutus 1a; Mõtle ja tegutse edasi

## Minu ema on võimatu. Anne Fine
URL: https://www.opiq.ee/kit/179/chapter/10047
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 12.1
Topics ET: matemaatika, võimatu, anne, fine, minna, paaristöö, tuleb, valmis, seada, jutusta
Topics RU: математика
Topics EN: mathematics
Headings: Minu ema on võimatu. Anne Fine; Anne Fine’i Minna; Minu ema on võimatu; Paaristöö; Ema tuleb valmis seada; Jutusta; Töö tekstiga; Harjutus 1; Harjutus 2; Harjutus 2b; Harjutus 2a; Mõtle ja tegutse edasi; Harjutus 3; Rühmatöö

## Loo jutustamine erinevast vaatenurgast
URL: https://www.opiq.ee/kit/179/chapter/10049
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 12.2
Topics ET: matemaatika, jutustamine, erinevast, vaatenurgast, erinevad, vaatenurgad, arutle, kaks, täiesti, erinevat
Topics RU: математика
Topics EN: mathematics
Headings: Loo jutustamine erinevast vaatenurgast; Erinevad vaatenurgad; Arutle; Kaks täiesti erinevat päeva; Mõtle ja tegutse edasi

## Koma lauses
URL: https://www.opiq.ee/kit/179/chapter/10050
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 12.3
Topics ET: matemaatika, koma, lauses, kuidas, inimesed, aastat, tagasi, sõid, reeglid, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Koma lauses; Kuidas inimesed 700 aastat tagasi sõid?; Reeglid; Harjutus 1; Harjutus 2; Liitlaused; Harjutus 3b; Harjutus 3a; Harjutus 4b; Harjutus 4a; Harjutus 5; Mõtle ja tegutse edasi; Kirjuta; Kirjuta c; Kirjuta a; Kirjuta b

## Kordamine. Loeme luuletusi
URL: https://www.opiq.ee/kit/179/chapter/10051
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 12.4
Topics ET: matemaatika, kordamine, korda, harjutan, aastaajad, kevad, suvi, sügis, talv, loeme, luuletusi, mine, lumekene, talvehommik, miks, tule
Topics RU: математика, повторение, повтори, тренировка, времена года, весна, лето, осень, зима
Topics EN: mathematics, revision, review, practice, seasons, spring, summer, autumn, winter
Headings: Kordamine. Loeme luuletusi; Talv; Mine, mine, lumekene; Talvehommik; Miks ei tule ükskord tali?; Arutle; Harjutus 1; Sügis; Koerailm; Hilissügise õhtul; Mõnus sajuilm; Imerohi; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b

## Mõttekoguja. Monika Feth
URL: https://www.opiq.ee/kit/179/chapter/10052
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 13.1
Topics ET: matemaatika, mõttekoguja, monika, feth, fethi, härra, tusane, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Mõttekoguja. Monika Feth; Monika Fethi härra Tusane; Härra Tusane; Mõttekoguja; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 2

## Omadussõnad
URL: https://www.opiq.ee/kit/179/chapter/10053
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 13.2
Topics ET: matemaatika, omadussõnad, mida, väljendab, omadussõna, harjutus, härra, willy, wonka, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Omadussõnad; Mida väljendab omadussõna?; Harjutus 1; Härra Willy Wonka; Harjutus 3; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 4; Kirjuta

## Kirjeldamine
URL: https://www.opiq.ee/kit/179/chapter/10054
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 13.3
Topics ET: matemaatika, kirjeldamine, miks, kirjeldame, kuidas, kirjeldada, harjutus, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Kirjeldamine; Miks me kirjeldame?; Kuidas kirjeldada?; Harjutus 1e; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Paaristöö

## Sõnavara
URL: https://www.opiq.ee/kit/179/chapter/10055
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 13.4
Topics ET: matemaatika, sõnavara, millised, härra, tusase, mõtted, harjutus, värve, palju, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Sõnavara; Millised on härra Tusase mõtted?; Harjutus 1a; Harjutus 1b; Värve on palju; Harjutus 2b; Harjutus 2a; Harjutus 3b; Harjutus 3a; Mõtle ja tegutse edasi; Harjutus 4; Kirjuta

## Vastand­tähen­dusega sõnad ehk antonüümid
URL: https://www.opiq.ee/kit/179/chapter/10056
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 13.5
Topics ET: matemaatika, vastand, tähen, dusega, sõnad, antonüümid, vastandtähendusega, harjutus, meeles, naljakad
Topics RU: математика
Topics EN: mathematics
Headings: Vastand­tähen­dusega sõnad ehk antonüümid; Vastandtähendusega sõnad; Harjutus 1c; Harjutus 1a; Harjutus 1b; Pea meeles!; Naljakad mõtted; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4

## Tulipunane vihmavari. Betti Alver
URL: https://www.opiq.ee/kit/179/chapter/10057
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 13.6
Topics ET: matemaatika, tulipunane, vihmavari, betti, alver, harjutus, mõtle, tegutse, edasi, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Tulipunane vihmavari. Betti Alver; Tulipunane vihmavari; Harjutus 1b; Harjutus 1a; Mõtle ja tegutse edasi; Rühmatöö; Harjutus 2

## Mina, Amber Brown. Paula Danziger
URL: https://www.opiq.ee/kit/179/chapter/10048
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 14.1
Topics ET: matemaatika, mina, amber, brown, paula, danziger, danzigeri, kahed, pühad, kingid
Topics RU: математика
Topics EN: mathematics
Headings: Mina, Amber Brown. Paula Danziger; Paula Danzigeri Amber Brown; Kahed pühad, kahed kingid; Mida kinkida?; Mis on kotis?; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 3; Kirjuta

## Kordamine. Jõuluaeg
URL: https://www.opiq.ee/kit/179/chapter/10058
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 14.2
Topics ET: matemaatika, kordamine, korda, harjutan, jõuluaeg, harjutus, liht, liitlause, loetelu, vastandsõnad, kirjeldamine, omadussõna
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine. Jõuluaeg; Jõuluaeg; Harjutus 1; Liht- ja liitlause; Harjutus 2a; Harjutus 2c; Harjutus 2b; Loetelu; Harjutus 3; Harjutus 4; Harjutus 4b; Vastandsõnad; Kirjeldamine. Omadussõna; Harjutus 5; Mõtle ja tegutse edasi; Tee ise kinkekarp; Harjutus 6

## Suur päkapiku­raamat
URL: https://www.opiq.ee/kit/179/chapter/10059
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 14.3
Topics ET: matemaatika, suur, päkapiku, raamat, päkapikkude, elupaigad, levik, eestis, harjutus, ajaarvamine
Topics RU: математика
Topics EN: mathematics
Headings: Suur päkapiku­raamat; Päkapikkude elupaigad; Päkapikkude levik Eestis; Harjutus 1; Harjutus 1c; Harjutus 1a; Harjutus 1b; Ajaarvamine; Jalajäljed; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3

## Luuletused
URL: https://www.opiq.ee/kit/179/chapter/10060
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 15.1
Topics ET: matemaatika, luuletused, jõulud, harjutus, jõululuuletused, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Luuletused; Jõulud; Harjutus 1; Jõululuuletused; Jõululuuletused 2; Jõululuuletused 3; Jõululuuletused 4; Jõululuuletused 5; Jõululuuletused 6; Jõululuuletused 7; Harjutus 2; Arutle

## Pähklipureja (1)
URL: https://www.opiq.ee/kit/179/chapter/10061
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 15.2
Topics ET: matemaatika, pähklipureja, kõige, tuntum, jõululugu, vaatus, harjutus, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Pähklipureja (1); Kõige tuntum jõululugu; I vaatus; II vaatus; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Harjutus 1e; Harjutus 1f; Harjutus 1g; Mõtle ja tegutse edasi; Rühmatöö

## Pähklipureja (2)
URL: https://www.opiq.ee/kit/179/chapter/10062
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 15.3
Topics ET: matemaatika, pähklipureja, peoõhtu, maagiline, jutusta, mõtle, tegutse, edasi, arutle, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Pähklipureja (2); Pähklipureja; Peoõhtu; Maagiline öö; Jutusta; Mõtle ja tegutse edasi; Arutle; Kirjuta

## Aastavahetuse luuletus
URL: https://www.opiq.ee/kit/179/chapter/10063
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 15.4
Topics ET: matemaatika, aastavahetuse, luuletus, aasta, sõna, kodustamine
Topics RU: математика
Topics EN: mathematics
Headings: Aastavahetuse luuletus; Uus aasta; Sõna kodustamine

## III osa. Ilukirjandus
URL: https://www.opiq.ee/kit/179/chapter/10078
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 16.1
Topics ET: matemaatika, ilukirjandus, mida, õpid, osas
Topics RU: математика
Topics EN: mathematics
Headings: III osa. Ilukirjandus; Mida õpid III osas?

## Väike nõid. Otfried Preussler
URL: https://www.opiq.ee/kit/179/chapter/10064
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 16.2
Topics ET: matemaatika, väike, nõid, otfried, preussler, preussleri, sissejuhatus, tegevustik, sündmustik, kokkuvõte
Topics RU: математика
Topics EN: mathematics
Headings: Väike nõid. Otfried Preussler; Otfried Preussleri „Väike nõid“; Sissejuhatus; Loo tegevustik ehk sündmustik; Kokkuvõte ehk lõpetus; Arutleme koos; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3a; Harjutus 3b; Mida ei tohi teistele teha?

## Loo tegevustik ehk sündmustik
URL: https://www.opiq.ee/kit/179/chapter/10065
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 16.3
Topics ET: matemaatika, tegevustik, sündmustik, igas, loos, mitu, tegevust, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Loo tegevustik ehk sündmustik; Igas loos on mitu tegevust; Harjutus 1; Harjutus 2d; Harjutus 2a; Harjutus 2b; Harjutus 2c; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Asesõnad
URL: https://www.opiq.ee/kit/179/chapter/10066
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 16.4
Topics ET: matemaatika, asesõnad, sõnad, asendavad, teisi, sõnu, harjutus, mida, asesõna, märgib
Topics RU: математика
Topics EN: mathematics
Headings: Asesõnad; Sõnad, mis asendavad teisi sõnu; Harjutus 1b; Harjutus 1a; Mida asesõna märgib?; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5

## Väike nõid (2)
URL: https://www.opiq.ee/kit/179/chapter/10067
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 16.5
Topics ET: matemaatika, väike, nõid, nõianõukogu, harjutus, väikse, nõia, teod, arutleme, koos
Topics RU: математика
Topics EN: mathematics
Headings: Väike nõid (2); Nõianõukogu ees; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Väikse nõia teod; Harjutus 1e; Harjutus 1f; Harjutus 1g; Arutleme koos; Harjutus 1; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3; Harjutus 4

## Nukitsamees. Oskar Luts
URL: https://www.opiq.ee/kit/179/chapter/10068
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 17.1
Topics ET: matemaatika, nukitsamees, oskar, luts, lutsu, kusti, eksivad, metsa, harjutus, vahepealsed
Topics RU: математика
Topics EN: mathematics
Headings: Nukitsamees. Oskar Luts; Oskar Lutsu „Nukitsamees“; Kusti ja Iti eksivad metsa; Harjutus 1c; Harjutus 1a; Harjutus 1b; Harjutus 2; Vahepealsed sündmused; Harjutus 3; Lapsehoidja hirm; Harjutus 4b; Harjutus 4a; Harjutus 5; Nukitsamees tahab kooli minna; Mõtle ja tegutse edasi; Harjutus 6; Kirjuta

## Sõnade muutmine. Käändsõnad
URL: https://www.opiq.ee/kit/179/chapter/10070
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 17.2
Topics ET: matemaatika, sõnade, muutmine, käändsõnad, sõnu, vaja, muuta, harjutus, pane, tähele
Topics RU: математика
Topics EN: mathematics
Headings: Sõnade muutmine. Käändsõnad; Sõnu on vaja muuta; Harjutus 1; Pane tähele!; Neliteist emakeelset käänet; Harjutus 2; Harjutus 2d; Harjutus 2a; Harjutus 2b; Harjutus 2c; Jäta meelde!; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4

## Kuidas lisada loole põnevust?
URL: https://www.opiq.ee/kit/179/chapter/10069
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 17.3
Topics ET: matemaatika, kuidas, lisada, loole, põnevust, mida, põnevuseks, tarvis, harjutus, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas lisada loole põnevust?; Mida on põnevuseks tarvis?; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Sõnavara. Piltlikud väljendid
URL: https://www.opiq.ee/kit/179/chapter/10071
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 17.4
Topics ET: matemaatika, sõnavara, piltlikud, väljendid, kuidas, teksti, ilmestada, harjutus, tähendust, peab
Topics RU: математика
Topics EN: mathematics
Headings: Sõnavara. Piltlikud väljendid; Kuidas teksti ilmestada?; Harjutus 1a; Harjutus 1b; Tähendust peab teadma; Harjutus 2; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Arutle; Harjutus 5; Harjutus 5c; Harjutus 5a; Harjutus 5b

## Cosette. Victor Hugo
URL: https://www.opiq.ee/kit/179/chapter/10072
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 18.1
Topics ET: matemaatika, cosette, victor, hugo, harjutus, mida, väljas, näeb, allikani, pikk
Topics RU: математика
Topics EN: mathematics
Headings: Cosette. Victor Hugo; Victor Hugo; Cosette; Harjutus 1; Harjutus 2; Mida Cosette väljas näeb?; Harjutus 3; Allikani on pikk tee; Harjutus 4; Kohtumine tundmatuga; Harjutus 5; Harjutus 6d; Harjutus 6a; Harjutus 6b; Harjutus 6c; Mõtle ja tegutse edasi; Harjutus 7; Harjutus 8

## Kuidas kirjeldada tegelast või eset? (1)
URL: https://www.opiq.ee/kit/179/chapter/10074
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 18.2
Topics ET: matemaatika, kuidas, kirjeldada, tegelast, eset, kõrtsiemand, cosette, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas kirjeldada tegelast või eset? (1); Kõrtsiemand ja Cosette; Harjutus 1; Harjutus 2b; Harjutus 2a; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Kuidas kirjeldada tegelast või eset? (2)
URL: https://www.opiq.ee/kit/179/chapter/10073
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 18.3
Topics ET: matemaatika, kuidas, kirjeldada, tegelast, eset, saab, võrreldes, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas kirjeldada tegelast või eset? (2); Kirjeldada saab võrreldes; Harjutus 1; Mõtle ja tegutse edasi; Harjutus 2

## Sama­tähendus­likud sõnad ehk sünonüümid
URL: https://www.opiq.ee/kit/179/chapter/10075
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 18.4
Topics ET: matemaatika, sama, tähendus, likud, sõnad, sünonüümid, rikastavad, keelt, harjutus, milliseid
Topics RU: математика
Topics EN: mathematics
Headings: Sama­tähendus­likud sõnad ehk sünonüümid; Sünonüümid rikastavad keelt; Harjutus 1; Harjutus 2; Harjutus 4c; Harjutus 4a; Harjutus 4b; Milliseid sünonüüme kasutada?; Harjutus 3; Harjutus 3b; Harjutus 3a; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5

## Vilgukivioru Tonje (1). Maria Parr
URL: https://www.opiq.ee/kit/179/chapter/10076
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 19.1
Topics ET: matemaatika, vilgukivioru, tonje, maria, parr, parri, vilgukiviorg, harjutus, õigel, teel
Topics RU: математика
Topics EN: mathematics
Headings: Vilgukivioru Tonje (1). Maria Parr; Maria Parri Tonje; Vilgukiviorg; Harjutus 1c; Harjutus 1a; Harjutus 1b; Õigel teel; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4

## Vilgukivioru Tonje (2)
URL: https://www.opiq.ee/kit/179/chapter/10077
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 19.2
Topics ET: matemaatika, vilgukivioru, tonje, peatükk, läheb, lahti, roolikelgu, proovisõit, harjutus, sõit
Topics RU: математика
Topics EN: mathematics
Headings: Vilgukivioru Tonje (2); 3. peatükk, kus läheb lahti roolikelgu proovisõit nr 1; Harjutus 1; Sõit läheb lahti; Harjutus 2; Harjutus 3; Arutleme koos; Mõtle ja tegutse edasi; Joonista; Kirjuta

## Tegevuskoht
URL: https://www.opiq.ee/kit/179/chapter/12555
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 19.3
Topics ET: matemaatika, tegevuskoht, tegevuskoha, kirjeldus, harjutus, mõnikord, saab, tegevus, kohta, väljendada
Topics RU: математика
Topics EN: mathematics
Headings: Tegevuskoht; Tegevuskoha kirjeldus; Harjutus 1; Harjutus 1e; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Mõnikord saab tegevus­kohta väljendada hoopis pildiga; Harjutus 2; Arutle; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Sisse-, sees- ja seestütlev kääne
URL: https://www.opiq.ee/kit/179/chapter/12556
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 19.4
Topics ET: matemaatika, sisse, sees, seestütlev, kääne, mida, tonje, teeb, harjutus, veel
Topics RU: математика
Topics EN: mathematics
Headings: Sisse-, sees- ja seestütlev kääne; Mida Tonje teeb?; Harjutus 1; Harjutus 2; Veel natuke Tonje seiklustest; Harjutus 3; Pane tähele!; Mõtle ja tegutse edasi; Harjutus 4

## Hobune ja eesel
URL: https://www.opiq.ee/kit/179/chapter/9999
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 2.1
Topics ET: matemaatika, hobune, eesel, valm, kuidas, juttu, lugeda, harjutus, miks, vaja
Topics RU: математика
Topics EN: mathematics
Headings: Hobune ja eesel; Valm; Kuidas juttu lugeda?; Harjutus A; Harjutus C; Harjutus B; Miks on vaja lugeda?; Harjutus E; Harjutus D; Harjutus F; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 2

## Kuidas juttu lugeda?
URL: https://www.opiq.ee/kit/179/chapter/10004
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 2.2
Topics ET: matemaatika, kuidas, juttu, lugeda, lõvi, rebane, harjutus, lind, putukas, sipelgas
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas juttu lugeda?; Lõvi ja rebane; Harjutus 1; Lind ja putukas; Harjutus 2; c. Sipelgas ja tuvi; a. Sääsk ja kotkas; b. Lepatriinu ja kakk; Mõtle ja tegutse edasi; Harjutus 3

## Suur algustäht
URL: https://www.opiq.ee/kit/179/chapter/10005
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 2.3
Topics ET: matemaatika, suur, algustäht, juhtus, raamaturiiulis, harjutus, millal, kasutame, suurt, algustähte
Topics RU: математика
Topics EN: mathematics
Headings: Suur algustäht; Mis juhtus raamaturiiulis?; Harjutus 1; Millal kasutame suurt algustähte?; Harjutus 2; Harjutus 3; Harjutus 3c; Harjutus 3a; Harjutus 3b; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5

## Liiv ja ahvid. Tiibeti muinasjutt
URL: https://www.opiq.ee/kit/179/chapter/10006
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 2.4
Topics ET: matemaatika, liiv, ahvid, tiibeti, muinasjutt, harjutus, teine, lahkub, edasi, saab
Topics RU: математика
Topics EN: mathematics
Headings: Liiv ja ahvid. Tiibeti muinasjutt; Liiv ja ahvid; Harjutus 1; Teine lahkub; Harjutus 2; Mis edasi saab?; Arutleme koos; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Väike rüütel Rikardo. Henno Käo
URL: https://www.opiq.ee/kit/179/chapter/12557
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 20.1
Topics ET: matemaatika, väike, rüütel, rikardo, henno, arutle, teine, lugu, läheb, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Väike rüütel Rikardo. Henno Käo; Henno Käo „Väike rüütel Rikardo“; Arutle; Teine lugu,; Teine lugu läheb edasi; Harjutus 1; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Joonista; Paaristöö; Jutusta

## Alale-, alal- ja alaltütlev kääne
URL: https://www.opiq.ee/kit/179/chapter/12558
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 20.2
Topics ET: matemaatika, alale, alal, alaltütlev, kääne, mida, ronk, teeb, harjutus, vaade
Topics RU: математика
Topics EN: mathematics
Headings: Alale-, alal- ja alaltütlev kääne; Mida ronk teeb?; Harjutus 1; Harjutus 2b; Harjutus 2a; Vaade müürilt; Harjutus 3; Harjutus 4b; Harjutus 4a; Kohakäänete kokkuvõte; Jäta meelde!; Harjutus 5; Harjutus 5a; Harjutus 5b; Harjutus 5c; Mõtle ja tegutse edasi; Harjutus 6; Harjutus 7

## Väike rüütel Rikardo (2)
URL: https://www.opiq.ee/kit/179/chapter/12559
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 20.3
Topics ET: matemaatika, väike, rüütel, rikardo, kolmas, lugu, harjutus, arutleme, koos, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Väike rüütel Rikardo (2); Kolmas lugu,; Harjutus 1; Harjutus 2; Arutleme koos; Mõtle ja tegutse edasi; Harjutus 3; Jutusta; Kirjuta; Raamatud

## Kirjeldame tegevuskohta (1)
URL: https://www.opiq.ee/kit/179/chapter/12560
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 20.4
Topics ET: matemaatika, kirjeldame, tegevuskohta, hobune, roosi, rohi, harjutus, joonista, mets, miks
Topics RU: математика
Topics EN: mathematics
Headings: Kirjeldame tegevuskohta (1); Hobune Roosi ja rohi; Harjutus 1; Joonista; Mets on ...; Harjutus 2; Harjutus 3; Miks on valgus hea?; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Kirjuta

## Kirjeldame tegevuskohta (2)
URL: https://www.opiq.ee/kit/179/chapter/12561
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 20.5
Topics ET: matemaatika, kirjeldame, tegevuskohta, veider, hurtsik, tegusõnu, palju, harjutus, kodumaa, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Kirjeldame tegevuskohta (2); Mis veider hurtsik!; Tegusõnu on palju; Harjutus 1; Harjutus 2; Kodumaa; Harjutus 4a; Harjutus 4b; Harjutus 4c; Harjutus 4d; Mõtle ja tegutse edasi; Harjutus 5; Harjutus 6b; Harjutus 6a

## Salaaed. Frances Hodgson Burnett
URL: https://www.opiq.ee/kit/179/chapter/12562
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 21.1
Topics ET: matemaatika, salaaed, frances, hodgson, burnett, burnetti, teose, ajajoon, jutustuse, tegelased
Topics RU: математика
Topics EN: mathematics
Headings: Salaaed. Frances Hodgson Burnett; Frances Hodgson Burnetti „Salaaed“; Teose „Salaaed“ ajajoon; Jutustuse tegelased; Harjutus 1b; Harjutus 1a; Harjutus 2; Mida arvavad tegelased üksteisest?; Mõtle ja tegutse edasi; Harjutus 3; Kirjuta

## Tegelaste tunded
URL: https://www.opiq.ee/kit/179/chapter/12563
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 21.2
Topics ET: matemaatika, tegelaste, tunded, milline, nõmm, harjutus, sõnadega, väljendatud, suhtumine, võib
Topics RU: математика
Topics EN: mathematics
Headings: Tegelaste tunded; Milline on nõmm?; Harjutus 1a; Harjutus 1b; Sõnadega väljendatud tunded; Harjutus 2; Harjutus 2b; Harjutus 2a; Harjutus 3; Harjutus 4; Suhtumine võib muutuda; Harjutus 5; Mõtle ja tegutse edasi; Harjutus 6; Kirjuta

## Kaasa- ja ilmaütlev kääne
URL: https://www.opiq.ee/kit/179/chapter/12564
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 21.3
Topics ET: matemaatika, kaasa, ilmaütlev, kääne, mõista, harjutus, juba, vanarahvas, teadis, rääkida
Topics RU: математика
Topics EN: mathematics
Headings: Kaasa- ja ilmaütlev kääne; Mõista, mõista!; Harjutus 1; Harjutus 2a; Harjutus 2b; Juba vanarahvas teadis rääkida; Harjutus 3b; Harjutus 3a; Harjutus 4; Käändelõpp ja loetelu; Harjutus 5; Ka sõnade järjekord on tähtis; Harjutus 6; Harjutus 7; Mõtle ja tegutse edasi; Harjutus 8

## Salaaed (2)
URL: https://www.opiq.ee/kit/179/chapter/12565
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 21.4
Topics ET: matemaatika, salaaed, mary, leiab, salaaia, harjutus, kohtub, dickoniga, arutleme, koos
Topics RU: математика
Topics EN: mathematics
Headings: Salaaed (2); Mary leiab salaaia; Harjutus 1c; Harjutus 1a; Harjutus 1b; Mary kohtub Dickoniga; Harjutus 2; Harjutus 3; Arutleme koos; Mõtle ja tegutse edasi; Harjutus 4; Joonista; Harjutus 5

## Veel üks Lotte. Erich Kästner
URL: https://www.opiq.ee/kit/179/chapter/12566
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 22.1
Topics ET: matemaatika, veel, lotte, erich, kästner, kästneri, luise, laste, suvelaagrisse, saabub
Topics RU: математика
Topics EN: mathematics
Headings: Veel üks Lotte. Erich Kästner; Erich Kästneri Lotte ja Luise; Laste suvelaagrisse saabub buss kahekümne uue elanikuga; Söögisaalis; Harjutus 1; Esimene öö laagris; Harjutus 2b; Harjutus 2a; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5

## Häälikute märkimine kirjas. Täishäälikud
URL: https://www.opiq.ee/kit/179/chapter/12567
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 22.2
Topics ET: matemaatika, häälikute, märkimine, kirjas, täishäälikud, millised, tuleta, meelde, lühikesed, pikad
Topics RU: математика
Topics EN: mathematics
Headings: Häälikute märkimine kirjas. Täishäälikud; Millised on täishäälikud?; Tuleta meelde!; Lühikesed ja pikad täishäälikud; Harjutus 1b; Harjutus 1a; Kuidas hääldame?; Harjutus 2a; Harjutus 2c; Harjutus 2b; Sõnamängud; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Arutle

## Suluta kaashäälikute pikkus (l, m, n, r, s)
URL: https://www.opiq.ee/kit/179/chapter/12568
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 22.3
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, suluta, kaashäälikute, millised, kaashäälikud, tuleta, meelde, lühikesed, pikad
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Suluta kaashäälikute pikkus (l, m, n, r, s); Millised on kaashäälikud?; Tuleta meelde!; Lühikesed ja pikad kaashäälikud; Harjutus 1; Kuidas hääldame?; Harjutus 2a; Harjutus 2b; Sõnamängud; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5a; Harjutus 5b; Kirjuta

## Seosed tekstis
URL: https://www.opiq.ee/kit/179/chapter/12569
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 22.4
Topics ET: matemaatika, seosed, tekstis, midagi, valesti, harjutus, sobi, istutasin, riidepuu, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Seosed tekstis; Midagi on valesti ...; Harjutus 1; Mis ei sobi?; Harjutus 2; Istutasin riidepuu; Harjutus 3; Mõtle ja tegutse edasi; Joonista; Kirjuta

## Veel üks Lotte (2)
URL: https://www.opiq.ee/kit/179/chapter/12570
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 22.5
Topics ET: matemaatika, veel, lotte, söögitoas, harjutus, segadus, saab, lahenduse, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Veel üks Lotte (2); Söögitoas; Harjutus 1; Segadus saab lahenduse; Mõtle ja tegutse edasi; Rühmatöö

## Luuletused vanadest ja noortest (1)
URL: https://www.opiq.ee/kit/179/chapter/12571
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 23.1
Topics ET: matemaatika, luuletused, vanadest, noortest, vana, vahva, lasteaed, harjutus, arutleme, koos
Topics RU: математика
Topics EN: mathematics
Headings: Luuletused vanadest ja noortest (1); Vana vahva lasteaed; Harjutus 1; Arutleme koos; Vanad päevikud; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Luuletused vanadest ja noortest (2)
URL: https://www.opiq.ee/kit/179/chapter/12572
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 23.2
Topics ET: matemaatika, luuletused, vanadest, noortest, kasvatatud, harjutus, laps, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Luuletused vanadest ja noortest (2); Kasvatatud; Harjutus 1; Mu laps; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Kirjuta; Harjutus 5

## Silbitamine ja poolitamine
URL: https://www.opiq.ee/kit/179/chapter/12573
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 23.3
Topics ET: matemaatika, silbitamine, poolitamine, harjutus, pane, tähele, meeles, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Silbitamine ja poolitamine; Silbitamine; Harjutus 1; Harjutus 2; Pane tähele!; Harjutus 3; Poolitamine; Pea meeles!; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Harjutus 6; Harjutus 6a; Harjutus 6b; Harjutus 7

## Rütm ja riim. Kuidas kirjutada luuletust?
URL: https://www.opiq.ee/kit/179/chapter/12574
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 23.4
Topics ET: matemaatika, rütm, riim, kuidas, kirjutada, luuletust, harjutus, rütmi, riimi, luua
Topics RU: математика
Topics EN: mathematics
Headings: Rütm ja riim. Kuidas kirjutada luuletust?; Mis on rütm?; Harjutus 1a; Harjutus 1b; Mis on riim?; Harjutus 2; Kuidas ise rütmi ja riimi luua?; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Harjutus 5h; Harjutus 5a; Harjutus 5b; Harjutus 5c; Harjutus 5d; Harjutus 5e; Harjutus 5f; Harjutus 5g; Harjutus 6

## Tuli ja Metsatukk
URL: https://www.opiq.ee/kit/179/chapter/12575
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 23.5
Topics ET: matemaatika, tuli, metsatukk, arutleme, koos, harjutus, erinevad, žanrid, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Tuli ja Metsatukk; Arutleme koos; Harjutus 1; Harjutus 2; Erinevad žanrid; Harjutus 3a; Harjutus 3b; Mõtle ja tegutse edasi; Jutusta; Kirjuta

## IV osa. Teatmeteosed
URL: https://www.opiq.ee/kit/179/chapter/12595
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 24.1
Topics ET: matemaatika, teatmeteosed, mida, õpid, osas
Topics RU: математика
Topics EN: mathematics
Headings: IV osa. Teatmeteosed; Mida õpid IV osas?

## Vanaema Huldi raamatukogu (1). Þórarinn Leifsson
URL: https://www.opiq.ee/kit/179/chapter/12576
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 24.2
Topics ET: matemaatika, vanaema, huldi, raamatukogu, rarinn, leifsson, leifssoni, huld, harjutus, arnheidur
Topics RU: математика
Topics EN: mathematics
Headings: Vanaema Huldi raamatukogu (1). Þórarinn Leifsson; Þórarinn Leifssoni vanaema Huld; Harjutus 1; Arnheidur Huld; Harjutus 2; Ma ei suuda seda uskuda!; Harjutus 3; Arutle; Mõtle ja tegutse edasi; Harjutus 4; Kirjuta

## Sulghääliku pikkus kirjas
URL: https://www.opiq.ee/kit/179/chapter/12578
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 24.3
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, sulghääliku, kirjas, millised, sulghäälikud, tuleta, meelde, harjutus, kuidas
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Sulghääliku pikkus kirjas; Millised on sulghäälikud?; Tuleta meelde!; Harjutus 1; Kuidas hääldame ja kirjutame?; Harjutus 2b; Harjutus 2a; Lühikesed ja pikad sulghäälikud; Harjutus 3; Harjutus 4; Sõnamängud; Harjutus 5; Harjutus 6; Mõtle ja tegutse edasi; Joonista

## Vanaema Huldi raamatukogu (2)
URL: https://www.opiq.ee/kit/179/chapter/12577
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 24.4
Topics ET: matemaatika, vanaema, huldi, raamatukogu, tuleta, meelde, harjutus, mida, raamatuga, teha
Topics RU: математика
Topics EN: mathematics
Headings: Vanaema Huldi raamatukogu (2); Tuleta meelde!; Harjutus 2; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Mida raamatuga teha?; Arutle; Mõtle ja tegutse edasi; Kirjuta

## Mis on teabekirjandus? Teatmeteosed
URL: https://www.opiq.ee/kit/179/chapter/12579
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 24.5
Topics ET: matemaatika, teabekirjandus, teatmeteosed, ilukirjandus, harjutus, mõtle, tegutse, edasi, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Mis on teabekirjandus? Teatmeteosed; Teabekirjandus ja ilukirjandus; Teabekirjandus; Harjutus 1; Teatmeteosed; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Vaata ja mõtle

## Mis on teabekirjandus? Aimekirjandus
URL: https://www.opiq.ee/kit/179/chapter/12580
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 24.6
Topics ET: matemaatika, teabekirjandus, aimekirjandus, hiiglaslikud, galaktikad, teatmeteosed, harjutus, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Mis on teabekirjandus? Aimekirjandus; Hiiglaslikud galaktikad; Aimekirjandus ja teatmeteosed; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3

## Entsüklopeediad
URL: https://www.opiq.ee/kit/179/chapter/12581
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 25.1
Topics ET: matemaatika, entsüklopeediad, looduskaitse, hävimisohus, liigid, teabetekstid, võivad, olla, erinevad, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Entsüklopeediad; Looduskaitse ja hävimisohus liigid; Teabetekstid võivad olla erinevad; Harjutus 1; Harjutus 1a; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 3; Harjutus 3d; Harjutus 3a; Harjutus 3b; Harjutus 3c

## Kuidas teabetekste lugeda?
URL: https://www.opiq.ee/kit/179/chapter/12582
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 25.2
Topics ET: matemaatika, loom, loomad, linnud, putukad, kuidas, teabetekste, lugeda, loeme, koos, kõige, unisem, arutle
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Kuidas teabetekste lugeda?; Loeme koos; KÕIGE UNISEM LOOM; Arutle; Mida said teada?; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4

## Täishääliku­ühend
URL: https://www.opiq.ee/kit/179/chapter/12583
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 25.3
Topics ET: matemaatika, täishääliku, ühend, täishäälikuühend, harjutus, tuleta, meelde, mõista, tegevus, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Täishääliku­ühend; Täishäälikuühend; Harjutus 1; Tuleta meelde!; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Mõista, mõista, mis see on!; Harjutus 3; Tegevus 2; Tegevus 2b; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Rühmatöö; Uuri

## Loomalapsed
URL: https://www.opiq.ee/kit/179/chapter/12584
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 25.4
Topics ET: matemaatika, loomalapsed, liblikate, arengukäik, rabakonn, jutusta, mõtle, tegutse, edasi, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Loomalapsed; Liblikate arengukäik; Rabakonn; Jutusta; Mõtle ja tegutse edasi; Kirjuta; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Joonista

## Ei või olla
URL: https://www.opiq.ee/kit/179/chapter/12585
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 25.5
Topics ET: matemaatika, olla, harjutus, röövik, arutle, teabetekst, ilukirjandus, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Ei või olla; Harjutus Röövik; Harjutus 1; Arutle; Teabetekst ja ilukirjandus; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Rühmatöö

## Sulghäälik pika täishääliku ja täishääliku­ühendi järel
URL: https://www.opiq.ee/kit/179/chapter/19331
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 25.6
Topics ET: matemaatika, sulghäälik, pika, täishääliku, ühendi, järel, pane, tähele, mitmekülgne, lehmatädi
Topics RU: математика
Topics EN: mathematics
Headings: Sulghäälik pika täishääliku ja täishääliku­ühendi järel; Sulghäälik pika täishääliku järel; Pane tähele!; Mitmekülgne lehmatädi; Harjutus 1; Harjutus 2; Harjutus 3; Sulghäälik täishäälikuühendi järel; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5

## Hukkunud linnad. Rainer Crummenerl
URL: https://www.opiq.ee/kit/179/chapter/12586
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 26.1
Topics ET: matemaatika, hukkunud, linnad, rainer, crummenerl, crummenerli, huvitanud, harjutus, mida, ütleb
Topics RU: математика
Topics EN: mathematics
Headings: Hukkunud linnad. Rainer Crummenerl; Rainer Crummenerli huvitanud hukkunud linnad; Harjutus 1; Mida ütleb eessõna?; Arutle; Uuri sisukorda; Harjutus 2b; Harjutus 2a; Uuri registrit; Harjutus 3; Harjutus 3b; Harjutus 3a; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5; Kirjuta

## Kaashääliku­ühend
URL: https://www.opiq.ee/kit/179/chapter/12588
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 26.2
Topics ET: matemaatika, kaashääliku, ühend, kordamiseks, harjutus, kaashäälikuühend, tuleta, meelde, harjutusi, sõnamängud
Topics RU: математика
Topics EN: mathematics
Headings: Kaashääliku­ühend; Kordamiseks; Harjutus 1; Harjutus 2; Harjutus 3; Kaashäälikuühend; Tuleta meelde!; Harjutusi; Harjutus 4b; Harjutus 4a; Harjutus 5; Harjutus 6; Sõnamängud; Harjutus 7; Harjutus 8; Pane tähele!; Mõtle ja tegutse edasi; Harjutus 9; Kirjuta

## Miks on vaja diagramme?
URL: https://www.opiq.ee/kit/179/chapter/12587
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 26.3
Topics ET: matemaatika, miks, vaja, diagramme, info, teksti, kaudu, harjutus, tekst, diagramm
Topics RU: математика
Topics EN: mathematics
Headings: Miks on vaja diagramme?; Info teksti kaudu; Harjutus 1; Harjutus 1a; Tekst ja diagramm koos; Harjutus 2; Harjutus 2a; Harjutus 2c; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4; Harjutus 5

## Meie ja meie lugu. Yvan Pommaux ja Christophe Ylla-Somers
URL: https://www.opiq.ee/kit/179/chapter/12589
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 26.4
Topics ET: matemaatika, aeg, kell, kalender, meie, lugu, yvan, pommaux, christophe, ylla, somers, inimeste, kujunemise
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Meie ja meie lugu. Yvan Pommaux ja Christophe Ylla-Somers; Inimeste kujunemise lugu; Aeg enne inimesi; Harjutus 1b; Harjutus 1a; 2 miljardit aastat tagasi; Inimesed arenevad; 140 000 aastat tagasi; 20 000 aastat tagasi; Paikse eluviisi algus; 9000 aastat tagasi; Harjutus 2b; Harjutus 2a; 4000 aastat tagasi; Elu Skandinaavias; 900 aastat tagasi; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5; Harjutus 6

## Petronella Õnneseen (1). Dorothea Flechsig
URL: https://www.opiq.ee/kit/179/chapter/12590
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 27.1
Topics ET: matemaatika, petronella, õnneseen, dorothea, flechsig, flechsigi, tõeline, uurimislabor, vihmaussid, purkides
Topics RU: математика
Topics EN: mathematics
Headings: Petronella Õnneseen (1). Dorothea Flechsig; Dorothea Flechsigi Petronella; Tõeline uurimislabor; Vihmaussid purkides; Harjutus 1; Arutle; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Petronella Õnneseen (2)
URL: https://www.opiq.ee/kit/179/chapter/12591
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 27.2
Topics ET: matemaatika, petronella, õnneseen, hiireskelett, nööri, otsas, vaat, juhtus, harjutus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Petronella Õnneseen (2); Hiireskelett nööri otsas; „Vaat mis juhtus!“; Harjutus 1; Arutle; Mõtle ja tegutse edasi; Harjutus 2; Kirjuta

## Sulghäälikud s-i ja h kõrval
URL: https://www.opiq.ee/kit/179/chapter/12593
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 27.3
Topics ET: matemaatika, sulghäälikud, kõrval, kordamiseks, tuleta, meelde, harjutus, sulghäälik, meeles, sulghääliku
Topics RU: математика
Topics EN: mathematics
Headings: Sulghäälikud s-i ja h kõrval; Kordamiseks; Tuleta meelde!; Harjutus 1; Harjutus 2; Harjutus 3; Sulghäälik s-i ja h kõrval; Pea meeles!; Harjutus 4; Harjutus 5; Sulghääliku õigekirja erandid; Harjutus 6; Harjutus 7a; Harjutus 7b; Harjutus 7c; Mõtle ja tegutse edasi; Harjutus 8; Kirjuta

## Kuidas teha katseid?
URL: https://www.opiq.ee/kit/179/chapter/12592
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 27.4
Topics ET: matemaatika, kuidas, teha, katseid, mida, uurida, miks, esemeid, ujub, upub
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha katseid?; Mida uurida?; MIKS OSA ESEMEID UJUB JA OSA UPUB?; Teeme ise katset!; Katse kirjeldus; Kuidas katset üles kirjutada?; Jäta meelde!; Vihmavee kogumine; Mõõtmistulemused; Mõtle ja tegutse edasi; Harjutus 1; Kirjuta

## Paabeli torn
URL: https://www.opiq.ee/kit/179/chapter/12766
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 28.1
Topics ET: matemaatika, paabeli, torn, miks, maailmas, palju, erinevaid, keeli, harjutus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Paabeli torn; Miks on maailmas nii palju erinevaid keeli?; Harjutus 1b; Harjutus 1a; Harjutus 2b; Harjutus 2a; Arutle; Mõtle ja tegutse edasi; Harjutus 3

## Mida teha? (da-vormi õigekiri)
URL: https://www.opiq.ee/kit/179/chapter/12765
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 28.2
Topics ET: matemaatika, mida, teha, vormi, õigekiri, mõtelda, mõnus, harjutus, keerulised, kuid
Topics RU: математика
Topics EN: mathematics
Headings: Mida teha? (da-vormi õigekiri); Mõtelda on mõnus; Harjutus 1; Keerulised, kuid tavalised sõnad; Häälda ja mõtle; Pane tähele!; Harjutus 2; Mida teha?; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5

## Sõnaraamatud
URL: https://www.opiq.ee/kit/179/chapter/12761
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 28.3
Topics ET: matemaatika, sõnaraamatud, õigekeelsus, sõnaraamat, harjutus, mõtle, tegutse, edasi, uuri
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaraamatud; Õigekeelsus­sõnaraamat ehk ÕS; Harjutus 1; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5b; Harjutus 5a; Uuri

## Hunt ja hobune
URL: https://www.opiq.ee/kit/179/chapter/12762
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 28.4
Topics ET: matemaatika, hunt, hobune, harjutus, mõtle, tegutse, edasi, joonista
Topics RU: математика
Topics EN: mathematics
Headings: Hunt ja hobune; Harjutus 1b; Harjutus 1a; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Joonista

## Kuidas sõnaraamatut kasutada?
URL: https://www.opiq.ee/kit/179/chapter/12763
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 28.5
Topics ET: matemaatika, kuidas, sõnaraamatut, kasutada, sõnaraamatu, vorm, harjutus, lühendid, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas sõnaraamatut kasutada?; Sõnaraamatu vorm; Harjutus 1c; Harjutus 1a; Harjutus 1b; Lühendid; Harjutus 2; Harjutus 3a; Harjutus 3b; Mõtle ja tegutse edasi; Harjutus 3; Uuri

## Üks sõna, mitu tähendust
URL: https://www.opiq.ee/kit/179/chapter/12764
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 28.6
Topics ET: matemaatika, sõna, mitu, tähendust, ühel, sõnal, erinevaid, tähendusi, harjutus, tähendus
Topics RU: математика
Topics EN: mathematics
Headings: Üks sõna, mitu tähendust; Ühel sõnal on erinevaid tähendusi; Harjutus 1; Sõna tähendus sõltub lausest; Harjutus 2; Lõuna; Harjutus 2a; Harjutus 2b; Tõnu sõnu; Tegevus 3; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4

## Reisiraamatud
URL: https://www.opiq.ee/kit/179/chapter/12767
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 29.1
Topics ET: matemaatika, reisiraamatud, pariis, laste, reisijuht, valguse, linn, harjutus, pariisi, tuntumad
Topics RU: математика
Topics EN: mathematics
Headings: Reisiraamatud; Pariis. Laste reisijuht; Valguse linn; Harjutus 1b; Harjutus 1a; Harjutus 2b; Harjutus 2a; Pariisi tuntumad ehitised; Eiffeli torn; Harjutus 3a; Harjutus 3b; Harjutus 3c; Jumalaema kirik ehk ​Notre-Dame’i[sõnaseletus: Notre-Dame – loe: notre dam] katedraal; Harjutus 4; Louvre[sõnaseletus: Louvre – loe: luuvr]; Harjutus 5a; Harjutus 5b; Harjutus 5c; Arutle; Mõtle ja tegutse edasi; Harjutus 6; Harjutus 6a; Harjutus 6b; Harjutus 6c; Harjutus 6d; Harjutus 6e; Harjutus 6f; Harjutus 6g; Harjutus 6h; Harjutus 7

## Kust leida vastuseid?
URL: https://www.opiq.ee/kit/179/chapter/12768
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 29.2
Topics ET: matemaatika, kust, leida, vastuseid, tead, harjutus, kuidas, olukorda, lahendada, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Kust leida vastuseid?; Kas tead vastuseid?; Harjutus 1; Harjutus 1b; Harjutus 1a; Kuidas olukorda lahendada?; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Mõtle ja tegutse edasi; Harjutus 3; Arutle

## i ja j-i õigekiri
URL: https://www.opiq.ee/kit/179/chapter/12769
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 29.3
Topics ET: matemaatika, õigekiri, asub, täht, harjutus, sõnamängud, mida, tahetakse, öelda, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: i ja j-i õigekiri; Kus asub j, kus i-täht?; Harjutus 1B; Harjutus 1a; Sõnamängud; Harjutus 2; Harjutus 3; Mida tahetakse öelda?; Harjutus 4; Harjutus 5; Harjutus 6; Mõtle ja tegutse edasi; Kirjuta

## Uus-Meremaa sõnas ja pildis. Aime Hansen
URL: https://www.opiq.ee/kit/179/chapter/12770
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 29.4
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, meremaa, sõnas, pildis, aime, hansen, raamat, meremaast, kõik, teisiti
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Uus-Meremaa sõnas ja pildis. Aime Hansen; Raamat Uus-Meremaast; Kõik on teisiti!; Tagurpidi aastaajad; Kõik on roheline; Harjutus 1c; Harjutus 1a; Harjutus 1b; Uus-Meremaa looduse imed; Rotorua; Milford Sound; Eriline mets; Gray mets; Arutle; Mõtle ja tegutse edasi; Harjutus 2; Kirjuta

## Tsatsiki ise (1). Moni Nilsson-Brännström
URL: https://www.opiq.ee/kit/179/chapter/10007
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 3.1
Topics ET: matemaatika, tsatsiki, moni, nilsson, brännström, brännströmi, kutse, õhtusöögile, harjutus, restoranis
Topics RU: математика
Topics EN: mathematics
Headings: Tsatsiki ise (1). Moni Nilsson-Brännström; Moni Nilsson-Brännströmi Tsatsiki; Kutse õhtusöögile; Harjutus 1c; Harjutus 1a; Harjutus 1b; Restoranis; Arutleme koos; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Kirjuta

## Tsatsiki ise (2)
URL: https://www.opiq.ee/kit/179/chapter/10008
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 3.2
Topics ET: matemaatika, aeg, kell, kalender, tsatsiki, midagi, romantilist, harjutus, venib, arutleme, koos, mõtle, tegutse
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Tsatsiki ise (2); Midagi romantilist; Harjutus 1; Harjutus 2b; Harjutus 2a; Aeg venib; Arutleme koos; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5

## Kuidas lugu ümber jutustada? (1)
URL: https://www.opiq.ee/kit/179/chapter/10009
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 3.3
Topics ET: matemaatika, kuidas, lugu, ümber, jutustada, millist, võtet, kasutada, harjutus, jutustamine
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas lugu ümber jutustada? (1); Millist võtet kasutada?; Harjutus 1; Harjutus 2; Harjutus 3; Jutustamine; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Harjutus 6

## Kuidas lauset lõpetada?
URL: https://www.opiq.ee/kit/179/chapter/10010
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 3.4
Topics ET: matemaatika, kuidas, lauset, lõpetada, tsatsiki, üllatus, harjutus, punkt, küsimärk, hüüumärk
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas lauset lõpetada?; Tsatsiki üllatus; Harjutus 1c; Harjutus 1a; Harjutus 1b; Harjutus 2; Punkt, küsimärk, hüüumärk; Harjutus 3; Harjutus 4b; Harjutus 4a; Mõtle ja tegutse edasi; Harjutus 5; Harjutus 6

## Kuidas lugu ümber jutustada? (2)
URL: https://www.opiq.ee/kit/179/chapter/10011
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 3.5
Topics ET: matemaatika, kuidas, lugu, ümber, jutustada, värvikad, laused, harjutus, olla, värvikam
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas lugu ümber jutustada? (2); Värvikad laused; Harjutus 1; Harjutus 2; Kuidas olla värvikam?; Harjutus 3; Harjutus 3b; Harjutus 3a; Harjutus 4; Harjutus 4d; Harjutus 4a; Harjutus 4b; Harjutus 4c; Mõtle ja tegutse edasi; Harjutus 5

## Mis on elulugu?
URL: https://www.opiq.ee/kit/179/chapter/12772
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 30.1
Topics ET: matemaatika, elulugu, helilooja, arvo, pärdi, harjutus, pärt, välismaal, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Mis on elulugu?; Helilooja Arvo Pärdi elulugu; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arvo Pärt välismaal; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Kirjuta

## Ühe luuletuse lugu
URL: https://www.opiq.ee/kit/179/chapter/12775
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 30.2
Topics ET: matemaatika, luuletuse, lugu, õpilase, mõtle, tegutse, edasi, harjutus, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Ühe luuletuse lugu; Õpilase õe lugu; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 2; Kirjuta

## h sõna alguses
URL: https://www.opiq.ee/kit/179/chapter/12773
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 30.3
Topics ET: matemaatika, sõna, alguses, kuidas, palun, õigekiri, oleneb, tähendusest, harjutus, hääldame
Topics RU: математика
Topics EN: mathematics
Headings: h sõna alguses; Kuidas palun?; Õigekiri oleneb tähendusest; Harjutus 1b; Harjutus 1a; Hääldame h sõna algul välja; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Joonista; Jutusta

## Sulghäälik sõna alguses
URL: https://www.opiq.ee/kit/179/chapter/12774
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 30.4
Topics ET: matemaatika, sulghäälik, sõna, alguses, omasõna, võõrsõna, sõnamängud, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Sulghäälik sõna alguses; Sulghäälik omasõna alguses; Sulghäälik võõrsõna alguses; Sõnamängud; Harjutus 1; Mõtle ja tegutse edasi; Harjutus 2; Kirjuta

## Rosinad. Lood lastekirjanike lapsepõlvest
URL: https://www.opiq.ee/kit/179/chapter/12776
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 30.5
Topics ET: matemaatika, rosinad, lood, lastekirjanike, lapsepõlvest, laste, kirjanike, suved, maal, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Rosinad. Lood lastekirjanike lapsepõlvest; Rosinad. Lood laste­kirjanike lapsepõlvest; Suved maal; Harjutus 1a; Harjutus 1; Linnalehmapiim; Arutle; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Luuletusi ajakirjast Täheke
URL: https://www.opiq.ee/kit/179/chapter/12777
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 30.6
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, luuletusi, ajakirjast, täheke, luuletused, kevadest, päike, lepatriinu, mõtle
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Luuletusi ajakirjast Täheke; Luuletused kevadest; Päike; Kevad; Lepatriinu; Mõtle ja tegutse edasi

## V osa. Kordamine
URL: https://www.opiq.ee/kit/179/chapter/12793
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 31.1
Topics ET: matemaatika, kordamine, korda, harjutan, mida, õpid, osas
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: V osa. Kordamine; Mida õpid V osas?

## Ajakirjad
URL: https://www.opiq.ee/kit/179/chapter/12786
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 31.2
Topics ET: matemaatika, ajakirjad, harjutus, ajakirja, ülesehitus, arutle, mõtle, tegutse, edasi, uuri
Topics RU: математика
Topics EN: mathematics
Headings: Ajakirjad; Harjutus 1; Harjutus 1a; Ajakirja ülesehitus; Harjutus 2; Arutle; Mõtle ja tegutse edasi; Uuri; Harjutus 4

## Kuidas ajakirja lugeda?
URL: https://www.opiq.ee/kit/179/chapter/12787
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 31.3
Topics ET: matemaatika, kuidas, ajakirja, lugeda, millist, artiklit, harjutus, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas ajakirja lugeda?; Millist artiklit lugeda?; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 3b; Harjutus 3c; Harjutus 3d; Harjutus 3e; Mõtle ja tegutse edasi; Harjutus 4a; Harjutus 4; Harjutus 5; Harjutus 6; Harjutus 7; Harjutus 4b

## Kuidas artiklit kirjutada?
URL: https://www.opiq.ee/kit/179/chapter/12788
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 31.4
Topics ET: matemaatika, kuidas, artiklit, kirjutada, pealkiri, tähtis, harjutus, tutvustus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas artiklit kirjutada?; Pealkiri on tähtis; Harjutus 1; Harjutus 1a; Harjutus 1b; Harjutus 1c; Tutvustus; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Kirjuta

## Loomad, kes vahetavad värvi
URL: https://www.opiq.ee/kit/179/chapter/12789
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 31.5
Topics ET: matemaatika, loom, loomad, linnud, putukad, vahetavad, värvi, harjutus, arutle, mõtle, tegutse, edasi, kirjuta
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Loomad, kes vahetavad värvi; Harjutus 1c; Harjutus 1a; Harjutus 1b; Arutle; Mõtle ja tegutse edasi; Harjutus 2; Kirjuta

## Intervjuu
URL: https://www.opiq.ee/kit/179/chapter/12790
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 32.1
Topics ET: matemaatika, intervjuu, ajaloohuvilisega, harjutus, vanasõnad, mõtle, tegutse, edasi, uuri
Topics RU: математика
Topics EN: mathematics
Headings: Intervjuu; Intervjuu ajaloohuvilisega; Harjutus 1; Harjutus 2; Vanasõnad; Harjutus 3; Harjutus 4; Harjutus 4a; Harjutus 4b; Harjutus 4c; Mõtle ja tegutse edasi; Harjutus 5; Uuri

## Kuidas teha intervjuud? (1)
URL: https://www.opiq.ee/kit/179/chapter/12791
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 32.2
Topics ET: matemaatika, kuidas, teha, intervjuud, mida, küsida, küsiti, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha intervjuud? (1); Mida küsida?; Mida küsiti?; Harjutus 1; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Kuidas teha intervjuud? (2)
URL: https://www.opiq.ee/kit/179/chapter/12792
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 32.3
Topics ET: matemaatika, kuidas, teha, intervjuud, intervjuu, ettevalmistus, harjutus, vorm, pane, tähele
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teha intervjuud? (2); Intervjuu ettevalmistus; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Intervjuu vorm; Pane tähele!; Mõtle ja tegutse edasi

## Teeme klassi ajakirja!
URL: https://www.opiq.ee/kit/179/chapter/12794
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 32.4
Topics ET: matemaatika, teeme, klassi, ajakirja, korraldage, koosolek, valime, teemad, sobivad, tekstivormid
Topics RU: математика
Topics EN: mathematics
Headings: Teeme klassi ajakirja!; Korraldage koosolek; Valime teemad ja sobivad tekstivormid; Teemad; Tekstid; Paneme paika toimetuse; Peatoimetaja; Ajakirjanikud, toimetajad; Fotograaf; Keeletoimetaja; Kujundajad; Minu ülesanded

## Väike Tjorven, Pootsman ja Mooses (1). Astrid Lindgren
URL: https://www.opiq.ee/kit/179/chapter/20099
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 33.1
Topics ET: matemaatika, väike, tjorven, pootsman, mooses, astrid, lindgren, lindgreni, ühel, juunikuu
Topics RU: математика
Topics EN: mathematics
Headings: Väike Tjorven, Pootsman ja Mooses (1). Astrid Lindgren; Astrid Lindgreni väike Tjorven; Ühel juunikuu päeval; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5; Mõtle ja tegutse edasi; Uuri

## Väike Tjorven, Pootsman ja Mooses (2)
URL: https://www.opiq.ee/kit/179/chapter/12778
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 33.2
Topics ET: matemaatika, väike, tjorven, pootsman, mooses, millised, selle, teose, tegelased, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Väike Tjorven, Pootsman ja Mooses (2); Millised on selle teose tegelased?; Arutle; Töötame tekstiga; Harjutus 1; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Kirjuta

## Sõnaliigid
URL: https://www.opiq.ee/kit/179/chapter/12779
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 33.3
Topics ET: matemaatika, sõnaliigid, kordame, õpitud, sõnaliike, nimisõna, harjutus, nimisõnad, tegusõna, tegusõnad
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaliigid; Kordame õpitud sõnaliike; NIMISÕNA; Harjutus 1a. Nimisõnad; TEGUSÕNA; Harjutus 1b. Tegusõnad; OMADUSSÕNA; Harjutus 1c. Omadussõnad; ASESÕNA; Harjutus 1d. Asesõnad; Harjutus 2; Onu Melker turnib katusel; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Arutle

## Lause
URL: https://www.opiq.ee/kit/179/chapter/12780
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 33.4
Topics ET: matemaatika, lause, laused, jagunevad, kaheks, pelle, tähistaevas, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Lause; Laused jagunevad kaheks; Pelle ja tähistaevas; Harjutus 1; Harjutus 2; Harjutus 2a; Harjutus 2b; Harjutus 3; Mõtle ja tegutse edasi; Kirjuta; Harjutus 4

## Tegevuskoht. Käänamine
URL: https://www.opiq.ee/kit/179/chapter/12781
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 33.5
Topics ET: matemaatika, tegevuskoht, käänamine, malini, mõtted, soolavaresest, tekstiga, harjutus, aastal, õpitud
Topics RU: математика
Topics EN: mathematics
Headings: Tegevuskoht. Käänamine; Malini mõtted Soolavaresest; Käänamine – töö tekstiga; Harjutus 1c; Harjutus 1a; Harjutus 1b; Sel aastal õpitud käänded; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Joonista

## Tegevuskoht. Pööramine
URL: https://www.opiq.ee/kit/179/chapter/12782
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 33.6
Topics ET: matemaatika, tegevuskoht, pööramine, soolavares, talvel, harjutus, tekstiga, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Tegevuskoht. Pööramine; Soolavares talvel; Harjutus 1b; Harjutus 1a; Pööramine – töö tekstiga; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Kirjuta

## Väike Tjorven, Pootsman ja Mooses (3)
URL: https://www.opiq.ee/kit/179/chapter/12783
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 34.1
Topics ET: matemaatika, aeg, kell, kalender, väike, tjorven, pootsman, mooses, sõua, kalalaiule, mismoodi, inimesed, küll
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Väike Tjorven, Pootsman ja Mooses (3); Sõua, sõua Kalalaiule; Mismoodi inimesed küll oma paate kinnitavad; Mõni aeg hiljem; Arutle; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3

## Algustähe õigekiri
URL: https://www.opiq.ee/kit/179/chapter/20376
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 34.2
Topics ET: matemaatika, algustähe, õigekiri, milline, täht, harjutus, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Algustähe õigekiri; Milline täht?; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Mõtle ja tegutse edasi; Harjutus 5; Harjutus 6

## Häälikute õigekiri (1)
URL: https://www.opiq.ee/kit/179/chapter/12784
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 34.3
Topics ET: matemaatika, häälikute, õigekiri, kordame, õigekirja, harjutus, harjutame, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Häälikute õigekiri (1); Kordame õigekirja; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5; Harjutame; Harjutus 6; Harjutus 7; Mõtle ja tegutse edasi; Harjutus 8; Harjutus 6a; Harjutus 6b; Harjutus 6c; Harjutus 9

## Häälikute õigekiri (2)
URL: https://www.opiq.ee/kit/179/chapter/12785
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 34.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, häälikute, õigekiri, kõige, tursk, harjutus, harjutame, mõtle, tegutse
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Häälikute õigekiri (2); Kõige suurem tursk; Harjutus 1; Harjutame; Harjutus 2; Harjutus 1i; Harjutus 1a; Harjutus 1b; Harjutus 1c; Harjutus 1d; Harjutus 1e; Harjutus 1f; Harjutus 1g; Harjutus 1h; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Jutusta

## Vincent van Gogh
URL: https://www.opiq.ee/kit/179/chapter/12771
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.1
Topics ET: matemaatika, vincent, gogh, noorusiga, harjutus, prantsusmaal, üksildus, arutle, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Vincent van Gogh; Vincent van Gogh (1853–1890); Noorusiga; Harjutus 1; Elu Prantsusmaal; Harjutus 2c; Harjutus 2a; Harjutus 2b; Üksildus; Harjutus 3; Arutle; Mõtle ja tegutse edasi; Harjutus 4

## Kuidas Maa hingab? Tiit Kändler
URL: https://www.opiq.ee/kit/179/chapter/12594
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.10
Topics ET: matemaatika, kuidas, hingab, tiit, kändler, mõtle, tegutse, edasi, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas Maa hingab? Tiit Kändler; Kuidas Maa hingab?; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 2; Harjutus 3

## Mängud õues. Marju Kõivupuu
URL: https://www.opiq.ee/kit/179/chapter/20100
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.11
Topics ET: matemaatika, mängud, õues, marju, kõivupuu, pärandiaabits
Topics RU: математика
Topics EN: mathematics
Headings: Mängud õues. Marju Kõivupuu; Pärandiaabits; Mängud õues

## Ninja Timmy ja varastatud naer. Henrik Tamm
URL: https://www.opiq.ee/kit/179/chapter/20101
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.12
Topics ET: matemaatika, ninja, timmy, varastatud, naer, henrik, tamm, tema
Topics RU: математика
Topics EN: mathematics
Headings: Ninja Timmy ja varastatud naer. Henrik Tamm; Henrik Tamm ja tema ninja Timmy; Varastatud naer

## Caspar ja Unustuse Meister. Stefanie Taschinski
URL: https://www.opiq.ee/kit/179/chapter/20102
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.13
Topics ET: matemaatika, caspar, unustuse, meister, stefanie, taschinski, unustatud, väikevend
Topics RU: математика
Topics EN: mathematics
Headings: Caspar ja Unustuse Meister. Stefanie Taschinski; Stefanie Taschinski Caspar; Unustatud väikevend

## Eks ole. Ellen Niit
URL: https://www.opiq.ee/kit/179/chapter/17654
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.2
Topics ET: matemaatika, ellen, niit
Topics RU: математика
Topics EN: mathematics
Headings: Eks ole. Ellen Niit; Eks ole

## Koletised ja pimedus. Katarina Mazetti
URL: https://www.opiq.ee/kit/179/chapter/15375
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.3
Topics ET: matemaatika, koletised, pimedus, katarina, mazetti, millal, siis, kummitused, tulevad
Topics RU: математика
Topics EN: mathematics
Headings: Koletised ja pimedus. Katarina Mazetti; Koletised ja pimedus; Millal siis kummitused tulevad?

## Suur segadus vampiiri ja muumia osavõtul. Markus Saksatamm
URL: https://www.opiq.ee/kit/179/chapter/15376
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.4
Topics ET: matemaatika, suur, segadus, vampiiri, muumia, osavõtul, markus, saksatamm, kambajõmmid
Topics RU: математика
Topics EN: mathematics
Headings: Suur segadus vampiiri ja muumia osavõtul. Markus Saksatamm; Suur segadus vampiiri ja muumia osavõtul; Vampiiri kambajõmmid

## Elli kirjad. Pille Arnek
URL: https://www.opiq.ee/kit/179/chapter/15377
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.5
Topics ET: matemaatika, elli, kirjad, pille, arnek, keegi, nagu, istub, seal, trepi
Topics RU: математика
Topics EN: mathematics
Headings: Elli kirjad. Pille Arnek; Elli kirjad; Keegi nagu istub seal trepi peal; Kinkide avamine

## Virumaa vanad lastemängud. Mall Hiiemäe
URL: https://www.opiq.ee/kit/179/chapter/15378
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.6
Topics ET: matemaatika, virumaa, vanad, lastemängud, mall, hiiemäe, proua, kinkis, sada, rubla
Topics RU: математика
Topics EN: mathematics
Headings: Virumaa vanad lastemängud. Mall Hiiemäe; Proua kinkis sada rubla; Ei ja jaa võib vastata; Must mees

## Heasüdamlik ring. Piret Raud
URL: https://www.opiq.ee/kit/179/chapter/15379
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.7
Topics ET: matemaatika, heasüdamlik, ring, piret, raud, veeres, ringil, meel
Topics RU: математика
Topics EN: mathematics
Headings: Heasüdamlik ring. Piret Raud; Heasüdamlik ring; Ring veeres ja veeres; Ringil oli hea meel

## Vahetund. Leelo Tungal
URL: https://www.opiq.ee/kit/179/chapter/15380
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.8
Topics ET: matemaatika, vahetund, leelo, tungal
Topics RU: математика
Topics EN: mathematics
Headings: Vahetund. Leelo Tungal; Vahetund

## Linnarott ja maarott. Jean de la Fontaine
URL: https://www.opiq.ee/kit/179/chapter/14679
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 35.9
Topics ET: matemaatika, linnarott, maarott, jean, fontaine, harjutus, mõtle, tegutse, edasi, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Linnarott ja maarott. Jean de la Fontaine; Linnarott ja maarott; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Kirjuta

## Sõnaseletused
URL: https://www.opiq.ee/kit/179/chapter/10079
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 36.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/179/chapter/15373
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 36.2
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Põhivara animatsioonid
URL: https://www.opiq.ee/kit/179/chapter/25877
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 36.3
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, põhivara, animatsioonid, tähestik, sassis, sulghääliku, suur, algustäht, kuhu
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Põhivara animatsioonid; Tähestik; Sassis tähestik; Sulghääliku pikkus; Suur algustäht; Kuhu käib suur täht?; Lauselõpumärgid; Punkt, hüüumärk või küsimärk?; Sidesõnad; Komaga või komata?; Silbitamine ja poolitamine; Õppeained; i ja j; Sõnaliigid; Mis liiki sõnad need on?

## Viplala lood (1). Annie M. G. Schmidt
URL: https://www.opiq.ee/kit/179/chapter/10000
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 4.1
Topics ET: matemaatika, viplala, lood, annie, schmidt, tema, parm, kellegi, kinni, võtnud
Topics RU: математика
Topics EN: mathematics
Headings: Viplala lood (1). Annie M. G. Schmidt; Annie M. G. Schmidt ja tema Viplala; Parm on kellegi kinni võtnud; Kelle Parm siis kätte sai?; Harjutus 1b; Harjutus 1a; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Viplala lood (2)
URL: https://www.opiq.ee/kit/179/chapter/10012
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 4.2
Topics ET: matemaatika, viplala, lood, kivistunud, parm, harjutus, arutleme, koos, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Viplala lood (2); Kivistunud Parm; Harjutus 1; Arutleme koos; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Millest lugu koosneb?
URL: https://www.opiq.ee/kit/179/chapter/10001
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 4.3
Topics ET: matemaatika, millest, lugu, koosneb, algus, lõpetus, mõtle, tegutse, edasi, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Millest lugu koosneb?; Algus; Loo sisu; Lõpetus; Mõtle ja tegutse edasi; Harjutus 1

## Kuidas loo sisu üles ehitada?
URL: https://www.opiq.ee/kit/179/chapter/10013
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 4.4
Topics ET: matemaatika, kuidas, üles, ehitada, luiskaja, liisa, harjutus, liigendamine, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas loo sisu üles ehitada?; Luiskaja Liisa; Harjutus 1; Loo liigendamine; Harjutus 2b; Harjutus 2a; Mõtle ja tegutse edasi; Harjutus 3

## Nimetused
URL: https://www.opiq.ee/kit/179/chapter/10002
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 4.5
Topics ET: matemaatika, nimetused, nimetus, harjutus, kuidas, kirjutame, pane, tähele, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Nimetused; Mis on nimetus?; Harjutus 1c; Harjutus 1a; Harjutus 1b; Kuidas kirjutame nimetused?; Pane tähele!; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4

## Zadig ehk Saatus. Voltaire
URL: https://www.opiq.ee/kit/179/chapter/10014
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 5.1
Topics ET: matemaatika, zadig, saatus, voltaire, tema, rahandusminister, arutleme, koos, olulised, osad
Topics RU: математика
Topics EN: mathematics
Headings: Zadig ehk Saatus. Voltaire; Voltaire ja tema Zadig; Aus rahandusminister; Arutleme koos; Loo olulised osad; Harjutus 1; Harjutus 2e; Harjutus 2a; Harjutus 2b; Harjutus 2c; Harjutus 2d; Mõtle ja tegutse edasi; Harjutus 3; Kirjuta

## Sisu jaotamine osadeks (1)
URL: https://www.opiq.ee/kit/179/chapter/10025
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 5.2
Topics ET: matemaatika, geomeetria, kujund, kujundid, sirge, lõik, jaotamine, osadeks, harjutus, mida, lõigu, kohta, küsida, milliste
Topics RU: математика, геометрия, фигура, фигуры, прямая, отрезок
Topics EN: mathematics, geometry, shape, shapes, line, segment
Headings: Sisu jaotamine osadeks (1); Mis on lõik?; Harjutus 1; Mida lõigu kohta küsida?; Harjutus 2a; Harjutus 2b; Harjutus 2c; Harjutus 3; Harjutus 4a; Harjutus 4b; Milliste sõnadega lõiku alustada?; Pane tähele!; Harjutus 5a; Harjutus 5b; Harjutus 6; Mõtle ja tegutse edasi; Harjutus 7; Kirjuta

## Kuidas me sõnu muudame?
URL: https://www.opiq.ee/kit/179/chapter/10015
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 5.3
Topics ET: matemaatika, kuidas, sõnu, muudame, miks, vaja, muuta, harjutus, mõtle, tegutse
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas me sõnu muudame?; Miks on vaja sõnu muuta?; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5; Mõtle ja tegutse edasi; Harjutus 6

## Sisu jaotamine osadeks (2)
URL: https://www.opiq.ee/kit/179/chapter/10016
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 5.4
Topics ET: matemaatika, jaotamine, osadeks, markus, saksatamme, lõbusad, jutud, karu, liitub, feisbukiga
Topics RU: математика
Topics EN: mathematics
Headings: Sisu jaotamine osadeks (2); Markus Saksatamme lõbusad jutud; Karu liitub Feisbukiga; Jaotame sisu osadeks; Harjutus 1; Mõtle ja tegutse edasi; Harjutus 2; Kirjuta

## Detektiiv Triibik loomaaias (1). Reeli Reinaus
URL: https://www.opiq.ee/kit/179/chapter/10017
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 6.1
Topics ET: matemaatika, detektiiv, triibik, loomaaias, reeli, reinaus, tema, sünnipäevakutse, kõige, tobedam
Topics RU: математика
Topics EN: mathematics
Headings: Detektiiv Triibik loomaaias (1). Reeli Reinaus; Reeli Reinaus ja tema Triibik; Sünnipäevakutse; Kõige tobedam asi; Arutleme koos; Töö tekstiga; Harjutus 1; Harjutus 2; Harjutus 3; Mõtle ja tegutse edasi; Riie ei riku meest; Harjutus 4b; Harjutus 4a; Harjutus 5

## Jutu algus ja lõpp
URL: https://www.opiq.ee/kit/179/chapter/10018
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 6.2
Topics ET: matemaatika, jutu, algus, lõpp, kuidas, lugu, alustada, harjutus, lõpetada, lõputa
Topics RU: математика
Topics EN: mathematics
Headings: Jutu algus ja lõpp; Kuidas lugu alustada?; Harjutus 1; Kuidas lugu lõpetada?; Lõputa jutt; Harjutus 2; Harjutus 3b; Harjutus 3a; Mõtle ja tegutse edasi; Jutusta; Kirjuta

## Nimisõna
URL: https://www.opiq.ee/kit/179/chapter/10026
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 6.3
Topics ET: matemaatika, nimisõna, mida, näitab, harjutus, milliseid, nimisõnu, ainsuses, mitmuses, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Nimisõna; Mida näitab nimisõna?; Harjutus 1; Harjutus 2; Milliseid nimisõnu on?; Harjutus 3; Harjutus 4; Harjutus 5; Nimisõna ainsuses ja mitmuses; Harjutus 6; Harjutus 7; Harjutus 8; Mõtle ja tegutse edasi; Arutle; Joonista

## Detektiiv Triibik loomaaias (2)
URL: https://www.opiq.ee/kit/179/chapter/10019
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 6.4
Topics ET: matemaatika, detektiiv, triibik, loomaaias, enne, lugemist, jutusta, võtab, südame, rindu
Topics RU: математика
Topics EN: mathematics
Headings: Detektiiv Triibik loomaaias (2); Enne lugemist; Jutusta; Triibik võtab südame rindu; Mis loeb kõige rohkem?; Arutleme koos; Töö tekstiga; Harjutus 2; Harjutus 1; Mõtle ja tegutse edasi; Harjutus 3

## Vahvlist südamed. Noa laev (1). Maria Parr
URL: https://www.opiq.ee/kit/179/chapter/10020
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 7.1
Topics ET: matemaatika, aeg, kell, kalender, vahvlist, südamed, laev, maria, parr, trille, lena, tori, kalapaat
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Vahvlist südamed. Noa laev (1). Maria Parr; Trille ja Lena; Onu Tori kalapaat; Harjutus 1; Harjutus 2; Käes on väiksemate olendite aeg; Harjutus 3; Töö tekstiga; Harjutus 5; Harjutus 4; Mõtle ja tegutse edasi; Rühmatöö

## Tegusõnad
URL: https://www.opiq.ee/kit/179/chapter/10021
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 7.2
Topics ET: matemaatika, tegusõnad, mida, näitab, tegusõna, harjutus, tuleta, meelde, muutuvad, tegusõnade
Topics RU: математика
Topics EN: mathematics
Headings: Tegusõnad; Mida näitab tegusõna?; Harjutus 1b; Harjutus 1a; Tuleta meelde!; Harjutus 2; Harjutus 3c; Harjutus 3a; Harjutus 3b; Tegusõnad muutuvad; Harjutus 4a; Harjutus 4b; Harjutus 5; Tegusõnade pööramine; Pööramine; Harjutus 6b; Harjutus 6a; Harjutus 7; Mõtle ja tegutse edasi; Harjutus 8; Harjutus 9

## Jutustame minavormis
URL: https://www.opiq.ee/kit/179/chapter/10022
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 7.3
Topics ET: matemaatika, jutustame, minavormis, jutustaja, vaatepunkt, harjutus, kordame, tegevuse, tegijaid, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Jutustame minavormis; Jutustaja vaatepunkt; Harjutus 1; Kordame tegevuse tegijaid; Harjutus 2; Harjutus 3a; Harjutus 3b; Mõtle ja tegutse edasi; Harjutus 4

## Vahvlist südamed. Noa laev (2)
URL: https://www.opiq.ee/kit/179/chapter/10027
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 7.4
Topics ET: matemaatika, vahvlist, südamed, laev, harjutus, tagajärgedega, tuleb, silmitsi, seista, arutleme
Topics RU: математика
Topics EN: mathematics
Headings: Vahvlist südamed. Noa laev (2); Noa laev II; Harjutus 1; Tagajärgedega tuleb silmitsi seista; Arutleme koos; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 3

## Inglid kuuendas B-s. Ilmar Tomusk
URL: https://www.opiq.ee/kit/179/chapter/10023
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 8.1
Topics ET: matemaatika, inglid, kuuendas, ilmar, tomusk, tomuski, kuues, nutika, tuvi, lugu
Topics RU: математика
Topics EN: mathematics
Headings: Inglid kuuendas B-s. Ilmar Tomusk; Ilmar Tomuski kuues B; Nutika tuvi lugu. Kolmas B klass; Õpime selgroogseid lähemalt!; Töö tekstiga; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 3; Harjutus 5b; Harjutus 5a

## Võtame loo lühidalt kokku
URL: https://www.opiq.ee/kit/179/chapter/10028
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 8.2
Topics ET: matemaatika, liitmine, liida, summa, kokku, võtame, lühidalt, olulised, tegelased, sündmused, harjutus, kokkuvõte, rühmatöö
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Võtame loo lühidalt kokku; Olulised tegelased ja sündmused; Harjutus 1; Kokkuvõte; Harjutus 2; Rühmatöö; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4; Harjutus 5b; Harjutus 5a; Harjutus 6

## Kuidas raamatut tutvustada?
URL: https://www.opiq.ee/kit/179/chapter/10024
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 8.3
Topics ET: matemaatika, kuidas, raamatut, tutvustada, raamatu, tutvustus, harjutus, kutsub, lugema, tutvustust
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas raamatut tutvustada?; Raamatu tutvustus; Harjutus 1; Mis kutsub lugema?; Harjutus 2a; Harjutus 2b; Kuidas raamatu tutvustust leida?; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5; Harjutus 6

## Lihtlause
URL: https://www.opiq.ee/kit/179/chapter/10029
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 8.4
Topics ET: matemaatika, lihtlause, kuidas, sõnadest, saab, lause, harjutus, laiendamine, tegevus, lihtlauseid
Topics RU: математика
Topics EN: mathematics
Headings: Lihtlause; Kuidas sõnadest saab lause?; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Lihtlause laiendamine; Harjutus 5; Tegevus 1; Lihtlauseid saab laiendada.; H5; Harjutus 6; Harjutus 7; Mõtle ja tegutse edasi; Harjutus 8; Harjutus 9b; Harjutus 9a

## Kordamine. Maakaart. Leelo Tungal
URL: https://www.opiq.ee/kit/179/chapter/10030
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 8.5
Topics ET: matemaatika, kordamine, korda, harjutan, maakaart, leelo, tungal, harjutus, mõtle, tegutse, edasi
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine. Maakaart. Leelo Tungal; Maakaart; Harjutus 1c; Harjutus 1a; Harjutus 1b; Mõtle ja tegutse edasi; Harjutus 2; Harjutus 2e; Harjutus 2a; Harjutus 2b; Harjutus 2c; Harjutus 2d; Harjutus 3

## Valmimeister Aisopos
URL: https://www.opiq.ee/kit/179/chapter/10031
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 8.6
Topics ET: matemaatika, valmimeister, aisopos, arutleme, koos, mõtle, tegutse, edasi, harjutus, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Valmimeister Aisopos; Arutleme koos; Mõtle ja tegutse edasi; Harjutus 1; Harjutus 2; Kirjuta

## II osa. Rahvaluule ja näidendid
URL: https://www.opiq.ee/kit/179/chapter/10035
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 9.1
Topics ET: matemaatika, rahvaluule, näidendid, mida, õpid, osas
Topics RU: математика
Topics EN: mathematics
Headings: II osa. Rahvaluule ja näidendid; Mida õpid II osas?

## Muistendid
URL: https://www.opiq.ee/kit/179/chapter/10032
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 9.2
Topics ET: matemaatika, muistendid, koit, hämarik, ebatavaline, soov, arutleme, koos, tekstiga, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Muistendid; Koit ja Hämarik; Ebatavaline soov; Arutleme koos; Töö tekstiga; Harjutus 1; Harjutus 2c; Harjutus 2a; Harjutus 2b; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 4; H4

## Tegusõna. Olevik ja minevik (1)
URL: https://www.opiq.ee/kit/179/chapter/10033
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 9.3
Topics ET: matemaatika, tegusõna, olevik, minevik, harjutus, pööramine, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Tegusõna. Olevik ja minevik (1); Olevik ja minevik; Harjutus 1c; Harjutus 1a; Harjutus 1b; Tegusõna pööramine; Harjutus 2; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 3; Mõtle ja tegutse edasi; Harjutus 4; Harjutus 5; Harjutus 6

## Tegusõna. Olevik ja minevik (2)
URL: https://www.opiq.ee/kit/179/chapter/10036
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 9.4
Topics ET: matemaatika, loom, loomad, linnud, putukad, tegusõna, olevik, minevik, olemas, erinevaid, aegu, harjutus, keda
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Tegusõna. Olevik ja minevik (2); Olemas on erinevaid aegu; Harjutus 1; Loomad, keda enam pole; Harjutus 2; Harjutus 3; Mõni loom jäi siiski alles; Harjutus 4; Harjutus 2c; Harjutus 2a; Harjutus 2b; Harjutus 5; Harjutus 3b; Harjutus 3a; Mõtle ja tegutse edasi; Harjutus 6; Rühmatöö

## Lenni ja Tallinn. Riina Kasser, Ave Teeääre
URL: https://www.opiq.ee/kit/179/chapter/10037
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 9.5
Topics ET: matemaatika, lenni, tallinn, riina, kasser, teeääre, minevikus, tänapäeval, viru, värav
Topics RU: математика
Topics EN: mathematics
Headings: Lenni ja Tallinn. Riina Kasser, Ave Teeääre; Tallinn minevikus ja tänapäeval; Viru värav; Enne ja nüüd; Harjutus 1; Harjutus 2a; Harjutus 2b; Harjutus 2c; Harjutus 2d; Mõtle ja tegutse edasi; Harjutus 3a; Harjutus 3b

## Sündmuste toimumise aeg
URL: https://www.opiq.ee/kit/179/chapter/10038
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 9.6
Topics ET: matemaatika, aeg, kell, kalender, sündmuste, toimumise, millal, sündmused, toimuvad, harjutus, minevik, olevik, tulevik
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Sündmuste toimumise aeg; Millal sündmused toimuvad?; Harjutus 1; Harjutus 1a; Harjutus 1b; Harjutus 1c; Minevik, olevik või tulevik?; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 4b; Harjutus 4a; Mõtle ja tegutse edasi; Harjutus 5; Kirjuta

## Eitus
URL: https://www.opiq.ee/kit/179/chapter/15374
Book: Eesti keele õpik 3. klassile – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keele_õpik_3._klassile
Chapter ID: 9.7
Topics ET: matemaatika, eitus, miks, harjutus, mõtle, tegutse, edasi
Topics RU: математика
Topics EN: mathematics
Headings: Eitus; Miks; Harjutus 1; Harjutus 2; Mõtle ja tegutse edasi; Harjutus 3; Harjutus 3b; Harjutus 3a

## Mina loen ja kirjutan 3 – Opiq
URL: https://www.opiq.ee/Kit/Details/590
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 425
Topics ET: matemaatika, mina, loen, kirjutan, opiq
Topics RU: математика
Topics EN: mathematics

## Mina loen ja kirjutan 3 – Opiq
URL: https://www.opiq.ee/Kit/Details/590
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 426
Topics ET: matemaatika, mina, loen, kirjutan, opiq
Topics RU: математика
Topics EN: mathematics
