## Ma õpin eesti keeles. II osa. Я учусь на эстонском языке. Часть II – Opiq
URL: https://www.opiq.ee/Kit/Details/554
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 152
Topics ET: matemaatika, õpin, eesti, keeles, opiq
Topics RU: математика, учусь, эстонском, языке, часть
Topics EN: mathematics

## KORDAME TÄHTI
URL: https://www.opiq.ee/kit/554/chapter/30948
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.1
Topics ET: matemaatika, kordame, tähti, tunnen, märgi, tähed, tähistavad, täishäälikuid
Topics RU: математика, знаю, буквы
Topics EN: mathematics
Headings: KORDAME TÄHTI; MA TUNNEN TÄHTI; Märgi tähed, mis tähistavad täishäälikuid.; Я знаю буквы; Отметь буквы, которые обозначают гласные звуки.

## PÄEV JA ÖÖ. MUUTUSED LOODUSES
URL: https://www.opiq.ee/kit/554/chapter/30913
Book: KORDAME TÄHTI
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.10
Topics ET: loodusõpetus, päev, muutused, looduses, värvid, värvitoonid, millised, sobivad
Topics RU: природоведение
Topics EN: science
Headings: PÄEV JA ÖÖ. MUUTUSED LOODUSES; VÄRVID; Värvitoonid; MILLISED VÄRVITOONID SOBIVAD?; PÄEV; ÖÖ

## ÖINE TAEVAS
URL: https://www.opiq.ee/kit/554/chapter/30952
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.11
Topics ET: matemaatika, öine, taevas, õpin, pildi, järgi, jutustama, mida, võib, öösel
Topics RU: математика
Topics EN: mathematics
Headings: ÖINE TAEVAS; ÕPIN PILDI JÄRGI JUTUSTAMA; MIDA VÕIB ÖÖSEL TAEVAS NÄHA? MÄRGI ÄRA.; MINU VÄIKE KALLIS PLANEET

## VÕRDLE JA ARVUTA
URL: https://www.opiq.ee/kit/554/chapter/30914
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.12
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, arvuta, õpin, loendama, võrdlema, pane, võrdsed, hulgad
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры, сравнение, сравни, больше, меньше
Topics EN: mathematics, addition, add, sum, number, numbers, digits, comparison, compare, greater, less
Headings: VÕRDLE JA ARVUTA; ÕPIN LOENDAMA; ...; ...2; ÕPIN VÕRDLEMA; Pane kokku võrdsed hulgad paaridesse; ÕPIN ARVE LIITMA; ÕPIN ARVE VÕRDLEMA; MÄRGI PILV, KUS ON SUUREM ARV.4; MÄRGI PILV, KUS ON SUUREM ARV.1; MÄRGI PILV, KUS ON SUUREM ARV.2; MÄRGI PILV, KUS ON SUUREM ARV.3

## Буква Я
URL: https://www.opiq.ee/kit/554/chapter/30915
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.13
Topics ET: matemaatika
Topics RU: математика, буква, первая, слова, читаем, найди, пару, соедини, картинку, подходящее
Topics EN: mathematics
Headings: Буква Я; Первая буква слова; Буква Я 3; Буква Я 1; Буква Я 2; Читаем слова; Найди пару. Соедини картинку и подходящее слово.; Читаем предложения; Прочитай. Напиши ответ на вопрос.

## Буква Ю
URL: https://www.opiq.ee/kit/554/chapter/30916
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.14
Topics ET: matemaatika
Topics RU: математика, буква, словах, если, слове, есть, напечатай, квадратике, превращение, слов
Topics EN: mathematics
Headings: Буква Ю; Буква Ю в словах; Если в слове есть буква Ю, то напечатай её в квадратике.2; Если в слове есть буква Ю, то напечатай её в квадратике.1; Превращение слов; Запиши новое слово.; Собираем слова; Собери имена детей. 4; Собери имена детей. 1; Собери имена детей. 2; Собери имена детей. 3

## KAHEKSA
URL: https://www.opiq.ee/kit/554/chapter/30953
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.15
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kaheksa, vali, õige, kuidas, saada, kirjuta, lahendus
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: KAHEKSA; Arv 8; VALI ÕIGE ARV.; KUIDAS SAADA ARVU 8?; KIRJUTA LAHENDUS.; число восемь; MILLEST KOOSNEB ARV 8?; ...; ÕPIN ÜLESANNET KOOSTAMA JA LAHENDAMA; VAATA, KUIDAS KIRJUTATAKSE NUMBRIT 8; NUPUTA!; KUULA JA MÄRGI ÕIGE PILT.2; KUULA JA MÄRGI ÕIGE PILT. 1

## TÄHT Ü
URL: https://www.opiq.ee/kit/554/chapter/30917
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.16
Topics ET: matemaatika, täht, õpin, kirjutama, sõna, kirjuta, tühja, ruutu, kuula, hääldamist
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT Ü; ÕPIN KIRJUTAMA; TÄHT JA SÕNA; Kirjuta tühja ruutu Ü-täht.​ 1; KAS U VÕI Ü?; Kuula sõna hääldamist. Vali õige täht (tähed). 3; Kuula sõna. Vali õige täht (tähed). 1; Kuula sõna. Vali õige täht (tähed). 2; MOODUSTAN SILPIDEST SÕNU; OE SILPE JA MOODUSTA SÕNAD.

## OMADUSSÕNAD
URL: https://www.opiq.ee/kit/554/chapter/30918
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.17
Topics ET: matemaatika, omadussõnad, mida, näitab, omadussõna, valin, sobivad, sõnad, vali, sobiv
Topics RU: математика
Topics EN: mathematics
Headings: OMADUSSÕNAD; MIDA NÄITAB OMADUSSÕNA?; 4.; 1.; 2.; 3.; VALIN SOBIVAD SÕNAD; VALI SOBIV SÕNA. 3; VALI SOBIV SÕNA. 1; VALI SOBIV SÕNA. 2

## ÜHEKSA
URL: https://www.opiq.ee/kit/554/chapter/30954
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.18
Topics ET: matemaatika, arv, arvud, arvu, numbrid, üheksa, vali, õige, märgi, lepatriinu, kellel, täppi, puuduvad
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: ÜHEKSA; 9.; ARV 9; VALI ÕIGE ARV 3; VALI ÕIGE ARV 1; VALI ÕIGE ARV 2; MÄRGI LEPATRIINU, KELLEL ON ÜHEKSA TÄPPI.; PUUDUVAD ARVUD; KIRJUTA PUUDUVAD ARVUD.; ...; MILLEST KOOSNEB ARV 9?; KIRJUTA VAJALIKUD ARVUD.; VAATA, KUIDAS KIRJUTATAKSE NUMBRIT 9

## Мягкий знак Ь
URL: https://www.opiq.ee/kit/554/chapter/30919
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.19
Topics ET: matemaatika
Topics RU: математика, мягкий, знак, словах, отметь, каждой, картинкой, подходящее, слово, закончи
Topics EN: mathematics
Headings: Мягкий знак Ь; Мягкий знак в словах; Отметь под каждой картинкой подходящее слово.2; Отметь под каждой картинкой подходящее слово.1; Закончи слово подходящими буквами.4; Закончи слово подходящими буквами.1; Закончи слово подходящими буквами.2; Закончи слово подходящими буквами.3; Читаем слова; Напечатай мягкий знак только в те слова, где он должен быть.2; Напечатай мягкий знак только в те слова, где он должен быть.1; Читаем предложения; Перетащи в предложение подходящее слово.; Собираем и записываем слова; Собери слова и запиши их.; Кто это? Напиши слово.3; Кто это? Напиши слово.1; Кто это? Напиши слово.2

## ARVUD 1, 2, 3, 4, 5, 6
URL: https://www.opiq.ee/kit/554/chapter/30949
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.2
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, tunnen, arve, prindi, puuduvad, järjesta, järjekorda, oskan
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры, сравнение, сравни, больше, меньше
Topics EN: mathematics, addition, add, sum, number, numbers, digits, comparison, compare, greater, less
Headings: ARVUD 1, 2, 3, 4, 5, 6; 1.; 2.; 3.; 4.; 5.; 6.; MA TUNNEN ARVE; PRINDI PUUDUVAD NUMBRID. 2; PRINDI PUUDUVAD NUMBRID. 1; JÄRJESTA ARVUD JÄRJEKORDA.; MA OSKAN LOENDADA; LOE KOKKU, MITU MÄNGUASJA IGASUGUSED ON TABELIS, JA VALI ÕIGE ARV.2; LOE KOKKU, MITU MÄNGUASJA IGASUGUSED ON TABELIS, JA VALI ÕIGE ARV.; MA OSKAN VÕRRELDA; LOE JA VÕRDLE. VALI ÕIGED ARVUD JA MÄRK. 3; LOE JA VÕRDLE. VALI ÕIGED ARVUD JA MÄRK. 1; LOE JA VÕRDLE. VALI ÕIGED ARVUD JA MÄRK. 2

## JÄRGARVUD. VASTLAPÄEV
URL: https://www.opiq.ee/kit/554/chapter/30955
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.20
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, järgarvud, vastlapäev, kuklite, õpin, jutustama, vastlakuklid, kukkel
Topics RU: математика, деление, раздели, частное, половина
Topics EN: mathematics, division, divide, quotient, half
Headings: JÄRGARVUD. VASTLAPÄEV; JÄRGARVUD; Kuklite jagamine; ÕPIN JUTUSTAMA; VASTLAKUKLID; kukkel

## ARVU NAABRID
URL: https://www.opiq.ee/kit/554/chapter/30920
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.21
Topics ET: matemaatika, arv, arvud, arvu, numbrid, naabrid, arvutan, üheksa, piires, kirjuta, puuduvad, lumepallimäng
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: ARVU NAABRID; ARVUTAN ÜHEKSA PIIRES; KIRJUTA PUUDUVAD ARVUD.2; KIRJUTA PUUDUVAD ARVUD.1; LUMEPALLIMÄNG; KIRJUTA NAABERARVUD. 3; KIRJUTA NAABERARVUD. 1; KIRJUTA NAABERARVUD. 2; LASTE NIMED; REASTA TÄHED ÕIGES NUMBRITE JÄRJEKORRAS 2; REASTA TÄHED ÕIGES NUMBRITE JÄRJEKORRAS 1

## RING JA KERA
URL: https://www.opiq.ee/kit/554/chapter/30956
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.22
Topics ET: matemaatika, ring, kera, mitu, ringi, leiad, pildilt, vali, õige, vastu
Topics RU: математика
Topics EN: mathematics
Headings: RING JA KERA; RING; MITU RINGI LEIAD PILDILT? VALI ÕIGE VASTU.; RINGID RITTA; ...; VÕRDLEN RINGI JA KERA; KAS RING VÕI KERA?; MILLISED ASJAD ON RINGI MOODI? MÄRGI NEED ASJAD.; PLANEEDID ON KERA MOODI

## NULL
URL: https://www.opiq.ee/kit/554/chapter/30921
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.23
Topics ET: matemaatika, arv, arvud, arvu, numbrid, null, mitu, lumepalli, alles, kirjuta, hoonet, vaata, kuidas
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: NULL; MITU LUMEPALLI JÄI ALLES?; KIRJUTA ARVUD.; MITU HOONET?; ...4; ...; ...3; VAATA, KUIDAS KIRJUTATAKSE NUMBRIT 0

## KÜMME
URL: https://www.opiq.ee/kit/554/chapter/30957
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.24
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kümme, kirjuta, märgi, joonlauale, kuni, puuduvad, eset, esimesed
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: KÜMME; ARV 10; KIRJUTA ARV 3; KIRJUTA ARV 1; KIRJUTA ARV 2; MÄRGI JOONLAUALE ÄRA ARVUD 0 KUNI 10.; PUUDUVAD ARVUD; KIRJUTA PUUDUVAD ARVUD.2; KIRJUTA PUUDUVAD ARVUD.1; KIRJUTA PUUDUVAD ARVUD.3; KÜMME ESET; MÄRGI IGA REA ESIMESED KÜMME ESET. MÄRGI ÜKSTEISE JÄREL, ALUSTADES ESIMESEST.; MILLEST KOOSNEB ARV 9?; MITU KOLLAST? AGA MITU ROHELIST?

## RAHA
URL: https://www.opiq.ee/kit/554/chapter/30922
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.25
Topics ET: matemaatika, raha, euro, sent, kuulan, jätan, meelde, eurod, loen, saab, osta, pileti
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: RAHA; KUULAN JA JÄTAN MEELDE; EUROD; LOEN RAHA; KES SAAB OSTA PILETI?; piletiraha; KUI PALJU MISKI MAKSAB?; Palju maksab?4; Palju maksab?1; Palju maksab?2; Palju maksab?3; LABÜRINT; Hoiupõrsas

## TÄHT P
URL: https://www.opiq.ee/kit/554/chapter/30923
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.26
Topics ET: matemaatika, liitmine, liida, summa, kokku, täht, õpin, kirjutama, sõna, pane, tähtedest, sõnad, loen
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: TÄHT P; ÕPIN KIRJUTAMA; TÄHT JA SÕNA; Pane tähtedest kokku sõnad. 2; Pane tähtedest kokku sõnad. 1; LOEN LAUSEID; Loe lauset. Märgi sobiv pilt. 2; Loe lauset. Märgi sobiv pilt. 1; ​Märgi õige pilt. 2; Lohista lausenumbriga ring vastava pildi juurde.

## Буква П
URL: https://www.opiq.ee/kit/554/chapter/30924
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.27
Topics ET: matemaatika
Topics RU: математика, буква, словах, если, названии, предмета, есть, отметь, картинку, составляем
Topics EN: mathematics
Headings: Буква П; Буква П в словах; Если в названии предмета есть буква П, то отметь эту картинку.; Составляем и читаем слоги; Напечатай слоги 3; Напечатай слоги 1; Напечатай слоги 2; Перетащи под картинку первые буквы слова.3; Перетащи под картинку первые буквы слова.1; Перетащи под картинку первые буквы слова.2; Превращение слов; Добавь букву П. Запиши новое слово.2; Добавь букву П. Запиши новое слово.1

## VASAK JA PAREM
URL: https://www.opiq.ee/kit/554/chapter/30925
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.28
Topics ET: matemaatika, vasak, parem, käsi, king, vasakule, paremale, õpin, jutustama, kummale
Topics RU: математика
Topics EN: mathematics
Headings: VASAK JA PAREM; KAS VASAK VÕI PAREM?; VASAK KÄSI; PAREM KING; VASAKULE; ...; PAREMALE; ÕPIN JUTUSTAMA; KUMMALE POOLE?; LOHISTA SÕNA ÕIGES SUUNAS.; MÄNGUASJADE RIIUL; KUULA JA LOHISTA MÄNGUASJAD ÕIGESSE KOHTA.; LAULA JA MÄNGI!

## Буква З
URL: https://www.opiq.ee/kit/554/chapter/30926
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.29
Topics ET: matemaatika
Topics RU: математика, буква, словах, если, названии, предмета, есть, напиши, квадратик, превращение
Topics EN: mathematics
Headings: Буква З; Буква З в словах; Если в названии предмета есть буква З, то напиши её в квадратик.3; Если в названии предмета есть буква З, то напиши её в квадратик.1; Если в названии предмета есть буква З, то напиши её в квадратик.2; Превращение слов; Запиши новое слово.2; Запиши новое слово.1; Учимся читать; Напиши букву З около тех животных, в названиях которых она есть.; Собери пары.

## Буква E
URL: https://www.opiq.ee/kit/554/chapter/30908
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, буква, словах, названия, каких, предметов, начинаются, букву, отметь, картинки
Topics EN: mathematics
Headings: Буква E; Буква Е в словах; Названия каких предметов начинаются на букву Е? Отметь эти картинки.; Читаем слоги; Впиши букву Е. Прочитай слоги сверху-вниз и снизу-вверх.; Назови предметы на картинках. С какого слога начинается слово? Перетащи его к подходящей картинке.; Читаем предложения; Рассмотри картинки. Прочитай предложения. Перетащи номер предложения к подходящей картинке.

## ASUTUSED: TEATER, MUUSEUM, LOOMAAED (ZOO)
URL: https://www.opiq.ee/kit/554/chapter/30958
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.30
Topics ET: matemaatika, asutused, teater, muuseum, loomaaed, õige, teatris, teatrilava
Topics RU: математика
Topics EN: mathematics
Headings: ASUTUSED: TEATER, MUUSEUM, LOOMAAED (ZOO); ASUTUSED; õige tee; TEATRIS; Teatrilava

## ÜKSTEIST
URL: https://www.opiq.ee/kit/554/chapter/30927
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.31
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, üksteist, kirjuta, mitu, tehe, arvuta, liidan, lahutan
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: ÜKSTEIST; ARV 11; KIRJUTA ARV 3; KIRJUTA ARV 1; KIRJUTA ARV 2; MITU ON KOKKU?; Kirjuta tehe ja arvuta.; LIIDAN JA LAHUTAN; arvuta

## POESKÄIK
URL: https://www.opiq.ee/kit/554/chapter/30959
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.32
Topics ET: matemaatika, poeskäik, mida, keegi, ostab, palju, tuleb, maksta, väike, kallis
Topics RU: математика
Topics EN: mathematics
Headings: POESKÄIK; MIDA KEEGI OSTAB?; KUI PALJU TULEB MAKSTA?; KUI PALJU TULEB MAKSTA?1; MINU VÄIKE KALLIS PLANEET

## TÄHT B
URL: https://www.opiq.ee/kit/554/chapter/30928
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.33
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, õpin, kirjutama, mida, teeb, vali, pildi, jaoks, sobiv
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT B; ÕPIN KIRJUTAMA; MIDA TEEB?; VALI PILDI JAOKS SOBIV SÕNA JA TRÜKI PILDI ALLA.; LOEN LAUSEID; Vali iga pildi juurde vastav lause number. 1

## Буква Б
URL: https://www.opiq.ee/kit/554/chapter/30929
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.34
Topics ET: matemaatika
Topics RU: математика, буква, первая, слова, ребусы, запиши, слово, отгадку, лабиринт
Topics EN: mathematics
Headings: Буква Б; Первая буква слова; Первая буква; Ребусы; Запиши слово-отгадку.2; Запиши слово-отгадку.1; Лабиринт

## LÜHIKE JA ÜLIPIKK HÄÄLIK
URL: https://www.opiq.ee/kit/554/chapter/30960
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.35
Topics ET: matemaatika, lühike, ülipikk, häälik, kaks, tähte, kirjuta, tühjadesse, ruutudesse, täht
Topics RU: математика
Topics EN: mathematics
Headings: LÜHIKE JA ÜLIPIKK HÄÄLIK; KAS ÜKS VÕI KAKS A-TÄHTE?; Kirjuta tühjadesse ruutudesse A-täht 2; Kirjuta tühjadesse ruutudesse A-täht 1; KUULAN JA LOEN; KUULA JA MÄRGI ÕIGE SÕNA.4; KUULA JA MÄRGI ÕIGE SÕNA.1; KUULA JA MÄRGI ÕIGE SÕNA.2; KUULA JA MÄRGI ÕIGE SÕNA.3; KAS ÜKS VÕI KAKS E-TÄHTE?

## MILLEST MISKI ON TEHTUD?
URL: https://www.opiq.ee/kit/554/chapter/30930
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.36
Topics ET: matemaatika, millest, miski, tehtud, materjalid, väike, kallis, planeet
Topics RU: математика
Topics EN: mathematics
Headings: MILLEST MISKI ON TEHTUD?; MATERJALID; millest miski on tehtud?2; MINU VÄIKE KALLIS PLANEET

## TÄHT D
URL: https://www.opiq.ee/kit/554/chapter/30931
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.37
Topics ET: matemaatika, täht, õpin, kirjutama, tähed, sõnad, sõna, need, pildil, märgi
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT D; ÕPIN KIRJUTAMA; TÄHED JA SÕNAD; Täht ja sõna; SEE ON – NEED ON; Mis on pildil? 4; Mis on pildil?; Mis on pildil? 2; Mis on pildil? 3; Märgi sõnad, mis näitavad, et asju on mitu (palju).; LOEN SÕNU; Vali raamatu pealkiri.

## Буква Д
URL: https://www.opiq.ee/kit/554/chapter/30932
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.38
Topics ET: matemaatika
Topics RU: математика, буква, начале, слова, читаем, предложения, перетащи, картинку, нужные, места
Topics EN: mathematics
Headings: Буква Д; Буква Д в начале слова; Читаем предложения; Читаем слова; Перетащи слова на картинку в нужные места.

## RUUT JA KUUP
URL: https://www.opiq.ee/kit/554/chapter/30961
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.39
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, geomeetria, kujund, kujundid, sirge, lõik, aeg, kell, kalender, ruut, kuup, märgi, ruudukujuline, mitu, ruutu, igas, kujundis
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры, геометрия, фигура, фигуры, прямая, отрезок, время, часы, календарь
Topics EN: mathematics, addition, add, sum, number, numbers, digits, geometry, shape, shapes, line, segment, time, clock, calendar
Headings: RUUT JA KUUP; RUUT; MÄRGI RUUDUKUJULINE KELL.; MITU RUUTU ON IGAS KUJUNDIS? KIRJUTA RUUTUDE ARV.; MILLIST KUJUNDIT ON PUUDU?; LOHISTA KÕIGEPEALT ÕIGE KUJUND. SEEJÄREL LOE, MITU RUUTU ON KOKKU.; MILLE POOLEST ERINEVAD KUUP JA RUUT?; MIS ON KUUBI JA MIS RUUDU MOODI?; ...

## Буква Ё
URL: https://www.opiq.ee/kit/554/chapter/30909
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, буква, читаем, слоги, прочитай, отметь, буквой, слова, соедини, слово
Topics EN: mathematics
Headings: Буква Ё; Читаем слоги; Прочитай и отметь слоги с буквой Ё.; Читаем слова; Соедини слово и картинку.; Собираем слова; Буква Е решила сходить в гости к своей сестрёнке букве Ё. Помоги ей добраться до домика буквы Ё. Проложи маршрут. Собери слова.

## JOONLAUD. SENTIMEETER
URL: https://www.opiq.ee/kit/554/chapter/30933
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.40
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, joonlaud, sentimeeter, kõige, pikem, riba, lühem, märgi, ribasid, õpin
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: JOONLAUD. SENTIMEETER; KÕIGE PIKEM RIBA JA KÕIGE LÜHEM RIBA; MÄRGI ÄRA KÕIGE PIKEM JA KÕIGE LÜHEM RIBASID.; ÕPIN MÕÕTMA; KIRJUTA PIKKUS.; mõõda joonlauaga; MILLEKS ON VAJA PIKKUS⋅ÜHIKUID?; MINU VÄIKE KALLIS PLANEET

## TÄHT G
URL: https://www.opiq.ee/kit/554/chapter/30934
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.41
Topics ET: matemaatika, täht, õpin, kirjutama, koostan, sõnu, koosta, sõnad, need, ette
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT G; ÕPIN KIRJUTAMA; KOOSTAN SÕNU; Koosta sõnad ja loe need ette. 3; Koosta sõnad ja loe need ette. 1; Koosta sõnad ja loe need ette. 2; OTSIN TÄHTEDE SEAST SÕNU; Leia sõnast reast ja kliki iga tähele selle sõnas. 4; Leia sõnast reast ja kliki iga tähele selle sõnas. 1; Leia sõnast reast ja kliki iga tähele selle sõnas. 2; Leia sõnast reast ja kliki iga tähele selle sõnas. 3; LOEN SÕNU; Kuidas sina tavaliselt lasteaeda, poodi või külla lähed? Märgi.

## Буква Г
URL: https://www.opiq.ee/kit/554/chapter/30935
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.42
Topics ET: matemaatika
Topics RU: математика, буква, первая, слове, если, слово, начинается, букву, напиши, квадратик
Topics EN: mathematics
Headings: Буква Г; Первая буква в слове; Если слово начинается на букву Г, то напиши её в квадратик.; Читаем слова; "Кликни" на эти слова.; Читаем предложения; У КО-ТА ГРИ-МА ГОС-ТИ.; ЭТО ГНО-МЫ.; У ГНО-МОВ ПИ-РО-ГИ.; Перетащи номер вопроса к картинке-ответу.

## KAKSTEIST
URL: https://www.opiq.ee/kit/554/chapter/30962
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.43
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, kaksteist, millest, koosneb, mitu, õuna, märgi, kõik, figuurid
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: KAKSTEIST; MILLEST KOOSNEB ARV 12?; MITU ÕUNA KOKKU?; MÄRGI KÕIK FIGUURID, MILLEL ON ARV 12.; LOENDAN KUNI KAHETEISTKÜMNENI; MÄRGI JÄRJEST KAKSTEIST KOLMNURKA. ALUSTA ESIMESEST KOLMNURGAST.; KIRJUTA ARV.3; KIRJUTA ARV.1; KIRJUTA ARV.2; loendamine; PUUDUVAD ARVUD; TRÜKI PUUDUVAD ARVUD.4; TRÜKI PUUDUVAD ARVUD.1; TRÜKI PUUDUVAD ARVUD.2; TRÜKI PUUDUVAD ARVUD.3; KIRJUTA LAHENDUS.

## SÕNAÜHENDID
URL: https://www.opiq.ee/kit/554/chapter/30936
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.44
Topics ET: matemaatika, sõnaühendid, oskan, lugeda, vajuta, õigele, pildile, väike, kallis, planeet
Topics RU: математика
Topics EN: mathematics
Headings: SÕNAÜHENDID; OSKAN LUGEDA; VAJUTA ÕIGELE PILDILE.6; VAJUTA ÕIGELE PILDILE.1; VAJUTA ÕIGELE PILDILE.2; VAJUTA ÕIGELE PILDILE.3; VAJUTA ÕIGELE PILDILE.4; VAJUTA ÕIGELE PILDILE.5; MINU VÄIKE KALLIS PLANEET

## KUJUNDLIKUD VÄLJENDID
URL: https://www.opiq.ee/kit/554/chapter/30963
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.45
Topics ET: matemaatika, kujundlikud, väljendid, õpin, lugema, saama
Topics RU: математика
Topics EN: mathematics
Headings: KUJUNDLIKUD VÄLJENDID; ÕPIN LUGEMA JA ARU SAAMA; kujundlikud väljendid 2

## TÄHT H
URL: https://www.opiq.ee/kit/554/chapter/30937
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.46
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, õpin, kirjutama, tähed, sõnad, lohista, sõnadesse, loen, lauseid
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT H; ÕPIN KIRJUTAMA; TÄHED JA SÕNAD; Lohista tähed sõnadesse. 4; Lohista tähed sõnadesse. 1; Lohista tähed sõnadesse. 2; Lohista tähed sõnadesse. 3; LOEN LAUSEID; Vali iga pildi juurde lause number. 3; Vali iga pildi juurde lause number.1; Vali iga pildi juurde lause number. 2

## Буква Х
URL: https://www.opiq.ee/kit/554/chapter/30938
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.47
Topics ET: matemaatika
Topics RU: математика, буква, слово, соедини, картинку, подходящей, схемой, словосочетание, перетащи, подходящее
Topics EN: mathematics
Headings: Буква Х; Слово; Соедини картинку с подходящей схемой. 2; Соедини картинку с подходящей схемой. 1; Словосочетание; Перетащи подходящее слово.; Предложение; Напиши последнее слово в предложении.; выбери номер подходящего предложения.3; выбери номер подходящего предложения.1; выбери номер подходящего предложения.2

## ROHKEM, VÄHEM, VÕRDSELT
URL: https://www.opiq.ee/kit/554/chapter/30988
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.48
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, rohkem, vähem, võrdselt, kuidas, võrdleme, oskan, võrrelda
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: ROHKEM, VÄHEM, VÕRDSELT; KUIDAS ME VÕRDLEME?; MA OSKAN VÕRRELDA; VÕRDLEMINE1; VÕRDLEMINE

## LIHAVÕTTED
URL: https://www.opiq.ee/kit/554/chapter/30989
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.49
Topics ET: matemaatika, lihavõtted, kuula, mustrid, ühesugune, muster
Topics RU: математика
Topics EN: mathematics
Headings: LIHAVÕTTED; KUULA JA LOE; MUSTRID; ühesugune muster

## LINNUD JA LOOMAD TALVEL
URL: https://www.opiq.ee/kit/554/chapter/30950
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.5
Topics ET: matemaatika, loom, loomad, linnud, putukad, talvel, kuidas, talve, veedab, uruloomad, jäljed, väike
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: LINNUD JA LOOMAD TALVEL; KES KUIDAS TALVE VEEDAB?; Uruloomad; JÄLJED; MINU VÄIKE KALLIS PLANEET

## TÄHT F
URL: https://www.opiq.ee/kit/554/chapter/30939
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.50
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, õpin, kirjutama, loen, sõnu, märgi, sõnad, sobivad, menüüsse
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT F; ÕPIN KIRJUTAMA; LOEN SÕNU; Märgi sõnad, mis sobivad menüüsse.; LOEN LAUSEID; Kirjuta iga pildi juurde sobiva lause number.; Ühenda lause algus ja lõpp ning loe.

## Буква Ф
URL: https://www.opiq.ee/kit/554/chapter/30940
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.51
Topics ET: matemaatika
Topics RU: математика, буква, словах, названии, каких, предметов, есть, отметь, картинки, учимся
Topics EN: mathematics
Headings: Буква Ф; Буква Ф в словах; В названии каких предметов есть буква Ф? Отметь эти картинки.; Учимся читать; Перетащи под картинку подходящее слово.4; Перетащи под картинку подходящее слово.1; Перетащи под картинку подходящее слово.2; Перетащи под картинку подходящее слово.3

## AASTAAJAD JA KUUD
URL: https://www.opiq.ee/kit/554/chapter/30990
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.52
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, kuud, sünnipäev, vali, õige, vastus
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: AASTAAJAD JA KUUD; AASTAAJAD; KUUD; MINU SÜNNIPÄEV; VALI ÕIGE VASTUS.

## LAHUTAMINE
URL: https://www.opiq.ee/kit/554/chapter/30991
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.53
Topics ET: matemaatika, liitmine, liida, summa, kokku, lahutamine, lahuta, vahe, oskan, lahutada, neli, auku, vähem, kaks, lille, kolm
Topics RU: математика, сложение, сложи, сумма, вычитание, вычти, разность
Topics EN: mathematics, addition, add, sum, subtraction, subtract, difference
Headings: LAHUTAMINE; MA OSKAN LAHUTADA; NELI AUKU VÄHEM; KAKS LILLE VÄHEM; KOLM LEHTE VÄHEM; MITU ON KOKKU?; TRÜKI.

## VIISAKUS­REEGLID
URL: https://www.opiq.ee/kit/554/chapter/30992
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.54
Topics ET: matemaatika, viisakus, reeglid, viisakad, sõnad, lohista, mullidesse, sobivad, õpin, lugema
Topics RU: математика
Topics EN: mathematics
Headings: VIISAKUS­REEGLID; VIISAKAD SÕNAD; LOHISTA MULLIDESSE SOBIVAD SÕNAD.; ÕPIN LUGEMA JA ARU SAAMA; KEDA KUIDAS KUTSUTAKSE? LOHISTA POISTE NIMED.

## Буква Ж
URL: https://www.opiq.ee/kit/554/chapter/30993
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.55
Topics ET: matemaatika
Topics RU: математика, буква, словах, отметь, съела, жаба, жанна, слоги, составь, запиши
Topics EN: mathematics
Headings: Буква Ж; Буква Ж в словах; Отметь, что съела жаба Жанна.; Слоги; Составь, запиши и прочитай слоги.; Слова; Рассмотри картинки. Закончи слово.2; Рассмотри картинки. Закончи слово.; Названия птиц; Распутай ниточки и запиши названия птиц.

## ÜLDNIMI EHK NIMETUS
URL: https://www.opiq.ee/kit/554/chapter/30994
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.56
Topics ET: matemaatika, üldnimi, nimetus, tunnen, lilli, puid, loomi, linde, lohista, sobiv
Topics RU: математика
Topics EN: mathematics
Headings: ÜLDNIMI EHK NIMETUS; MA TUNNEN LILLI; MA TUNNEN PUID; MA TUNNEN LOOMI; MA TUNNEN LINDE; LOHISTA SOBIV SÕNA 4; LOHISTA SOBIV SÕNA 1; LOHISTA SOBIV SÕNA 2; LOHISTA SOBIV SÕNA 3; 4.; 1.; 2.; 3.

## MUUSIKA­RIISTAD
URL: https://www.opiq.ee/kit/554/chapter/30995
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.57
Topics ET: matemaatika, muusika, riistad, tunnen, pille, pillide, nimetused, vajuta, igal, sõna
Topics RU: математика
Topics EN: mathematics
Headings: MUUSIKA­RIISTAD; TUNNEN PILLE; ...; PILLIDE NIMETUSED; VAJUTA IGAL SÕNA TÄHEL. 5; VAJUTA IGAL SÕNA TÄHEL. 1; VAJUTA IGAL SÕNA TÄHEL. 2; VAJUTA IGAL SÕNA TÄHEL. 3; VAJUTA IGAL SÕNA TÄHEL. 4; KUULA JA LAULA KAASA!; KUULA JA TEE KAASA!

## Буква Ц
URL: https://www.opiq.ee/kit/554/chapter/30996
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.58
Topics ET: matemaatika
Topics RU: математика, буква, слове, напечатай, нужном, квадратике, составляем, слова, узнай, названия
Topics EN: mathematics
Headings: Буква Ц; Буква Ц в слове; Напечатай Ц в нужном квадратике.3; Напечатай Ц в нужном квадратике.; Напечатай Ц в нужном квадратике.2; Составляем слова; Узнай названия птиц. Запиши слова.; Составь слово из букв. 2; Составь слово из букв. 1

## KEVADE MÄRGID LOODUSES
URL: https://www.opiq.ee/kit/554/chapter/30997
Book: KORDAME TÄHTI
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.59
Topics ET: loodusõpetus, kevade, märgid, looduses, pilt, sobib, kevadega, saabumine, seadke, pildid
Topics RU: природоведение
Topics EN: science
Headings: KEVADE MÄRGID LOODUSES; KEVADE MÄRGID; MIS PILT SOBIB KEVADEGA?; KEVADE SAABUMINE; SEADKE PILDID ÕIGESSE JÄRJEKORDA.

## MAAL JA JOONISTUS
URL: https://www.opiq.ee/kit/554/chapter/30910
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.6
Topics ET: matemaatika, loom, loomad, linnud, putukad, maal, joonistus, märgi, jäävad, talvel, talveunne
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: MAAL JA JOONISTUS; MAAL; JOONISTUS; MÄRGI LOOMAD, KES JÄÄVAD TALVEL TALVEUNNE.

## TÄHT, SÕNA, LAUSE
URL: https://www.opiq.ee/kit/554/chapter/30998
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.60
Topics ET: matemaatika, täht, sõna, lause, mida, kirjutas, ütle, kirjuta, tekst
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT, SÕNA, LAUSE; KES MIDA KIRJUTAS?; Ütle üks lause; kirjuta; TEKST

## Буква, слово, предложение
URL: https://www.opiq.ee/kit/554/chapter/30999
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.61
Topics ET: matemaatika, loom, loomad, linnud, putukad, ütle, lause
Topics RU: математика, животное, животные, птицы, насекомые, буква, слово, предложение, написал, текст
Topics EN: mathematics, animal, animals, birds, insects
Headings: Буква, слово, предложение; Кто что написал?; ütle üks lause; ЖИВОТНОЕ; Текст

## Буква Ч
URL: https://www.opiq.ee/kit/554/chapter/31000
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.62
Topics ET: matemaatika
Topics RU: математика, буква, слове, если, названии, предмета, есть, напиши, квадратик, собираем
Topics EN: mathematics
Headings: Буква Ч; Буква Ч в слове; Если в названии предмета есть буква Ч, то напиши её в квадратик.; Собираем слова; подпиши картинки 1; Читаем

## Буква Щ
URL: https://www.opiq.ee/kit/554/chapter/31001
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.63
Topics ET: matemaatika
Topics RU: математика, буква, слове, если, названии, предмета, есть, перетащи, квадратик, слоги
Topics EN: mathematics
Headings: Буква Щ; Буква Щ в слове; Если в названии предмета есть буква Щ, то перетащи её в квадратик.2; Если в названии предмета есть буква Щ, то перетащи её в квадратик.; Слоги; Собери и запиши слоги.; Слова; Соедини начало слова с подходящей картинкой.; 1.

## LINNUD
URL: https://www.opiq.ee/kit/554/chapter/31002
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.64
Topics ET: matemaatika, loom, loomad, linnud, putukad, oksal, maapinnal, kohamäärus, elab, leia, igale, linnule, pesa
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: LINNUD; LINNUD OKSAL JA MAAPINNAL; kohamäärus; KES KUS ELAB?; leia igale linnule pesa; KUULA JA LOE!

## MEELED
URL: https://www.opiq.ee/kit/554/chapter/31003
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.65
Topics ET: matemaatika, inimene, keha, meeled, tervis, inimese, viis, meelt, kuula, laula, kaasa, milline
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MEELED; INIMESE VIIS MEELT; meeled 1; KUULA JA LAULA KAASA!; MIS ON MILLINE?; meeled 2

## PUTUKAD JA ÄMBLIKUD
URL: https://www.opiq.ee/kit/554/chapter/31004
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.66
Topics ET: matemaatika, loom, loomad, linnud, putukad, ämblikud, lendab, mitte, märgi, elab, ühenda, pildid, võib
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: PUTUKAD JA ÄMBLIKUD; KES LENDAB, KES MITTE?; MÄRGI, KES LENDAB.; KES KUS ELAB?; ühenda pildid; KES VÕIB INIMESELE KAHJU TEHA?; MÄRGI ÄRA.

## NUPUTA JA ARVUTA
URL: https://www.opiq.ee/kit/554/chapter/31005
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.67
Topics ET: matemaatika, nuputa, arvuta, oskan, võrrelda, rohkem, lahutada
Topics RU: математика
Topics EN: mathematics
Headings: NUPUTA JA ARVUTA; MA OSKAN VÕRRELDA; KUS ON ROHKEM?4; KUS ON ROHKEM?1; KUS ON ROHKEM?2; KUS ON ROHKEM?3; MA OSKAN LAHUTADA; ARVUTA

## KELL. TÄISTUND
URL: https://www.opiq.ee/kit/554/chapter/31006
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.68
Topics ET: matemaatika, arv, arvud, arvu, numbrid, aeg, kell, kalender, täistund, puuduvad, kuula, laula, kaasa, osutid
Topics RU: математика, число, числа, цифры, время, часы, календарь
Topics EN: mathematics, number, numbers, digits, time, clock, calendar
Headings: KELL. TÄISTUND; PUUDUVAD ARVUD; puuduvad numbrid; KUULA JA LAULA KAASA!; MIS KELL ON?; osutid2; osutid1; MIS KELL ON? KIRJUTA; mis kell on

## HOMMIK, PÄEV, ÕHTU, ÖÖ
URL: https://www.opiq.ee/kit/554/chapter/31007
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.69
Topics ET: matemaatika, hommik, päev, õhtu, ööpäeva, osad, ühenda
Topics RU: математика, соедини, слово, картинку
Topics EN: mathematics
Headings: HOMMIK, PÄEV, ÕHTU, ÖÖ; ÖÖPÄEVA OSAD; Соедини слово и картинку.; ÜHENDA SÕNA JA PILT.; MIDA MA MILLAL TEEN?; Что мы обычно делаем утром, днём, вечером, ночью? Выбери нужное слово.; MILLISEID KELLI ON?; Перетащи название часов под подходящую картинку.; LOHISTA KELLA NIMI ÕIGE PILDI ALLA.

## SEITSE
URL: https://www.opiq.ee/kit/554/chapter/30951
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.7
Topics ET: matemaatika, arv, arvud, arvu, numbrid, seitse, mitu, päkapikku, kirjuta, puuduvad, ühest, seitsmeni
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: SEITSE; 1.; 2.; 3.; 4.; 5.; 6.; 7.; ARV 7; LOE, MITU PÄKAPIKKU ON. KIRJUTA PUUDUVAD NUMBRID.; ARVUD ÜHEST SEITSMENI; ÕPIN ÜLESANDEID LAHENDAMA; JUTUSTA JA ARVUTA. Lohista õiged arvud.2; JUTUSTA JA ARVUTA. Lohista õiged arvud.; MILLEST KOOSNEB ARV 7?; Kogu hulgad.; MITU? VALI SOBIVAD ARVUD JA KIRJUTA TEHE.3; MITU? VALI SOBIVAD ARVUD JA KIRJUTA TEHE.1; MITU? VALI SOBIVAD ARVUD JA KIRJUTA TEHE.2; VAATA, KUIDAS KIRJUTATAKSE NUMBRIT 7

## ELUKUTSED
URL: https://www.opiq.ee/kit/554/chapter/31008
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.70
Topics ET: matemaatika, elukutsed, mida, tööks, vajab, vali, sobiv, ameti, nimetus, amet
Topics RU: математика
Topics EN: mathematics
Headings: ELUKUTSED; KES MIDA TÖÖKS VAJAB?; VALI SOBIV AMETI NIMETUS. 3; VALI SOBIV AMET. 1; VALI SOBIV AMETI NIMETUS. 2; ÕPIN TUNDMA ELUKUTSEID

## SPORDIALAD
URL: https://www.opiq.ee/kit/554/chapter/31009
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.71
Topics ET: matemaatika, spordialad, palli, mängud, leia, igale, pallile, paariline, ühenda, tean
Topics RU: математика
Topics EN: mathematics
Headings: SPORDIALAD; PALLI•MÄNGUD; LEIA IGALE PALLILE PAARILINE. ÜHENDA.; MA TEAN SPORDIALASID; MÄÄRA SPORDIALA JA VALI ÕIGE SÕNA.2; MÄÄRA SPORDIALA JA VALI ÕIGE SÕNA.1

## Учимся читать и рассказывать. ДРУЖБА
URL: https://www.opiq.ee/kit/554/chapter/31010
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.72
Topics ET: matemaatika
Topics RU: математика, учимся, читать, рассказывать, дружба, слушаем, читаем, расположи, картинки, правильном
Topics EN: mathematics
Headings: Учимся читать и рассказывать. ДРУЖБА; Слушаем и читаем; Учимся рассказывать; Расположи картинки в правильном порядке; Учимся составлять рассказ по картинкам

## LUULETUS JA MUINAS­JUTT
URL: https://www.opiq.ee/kit/554/chapter/31011
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.73
Topics ET: matemaatika, luuletus, muinas, jutt, sarnased, sõnad, lugu, piltidega, liisu, muinasjutt
Topics RU: математика
Topics EN: mathematics
Headings: LUULETUS JA MUINAS­JUTT; SARNASED SÕNAD; ...4; ...1; ...2; ...3; LUGU JA LUULETUS PILTIDEGA; Liisu muinasjutt

## SUVI
URL: https://www.opiq.ee/kit/554/chapter/31012
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.74
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, mida, suvel, vaja, märgi, metsa, marjad, milliseid, marju
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: SUVI; MIDA ON SUVEL VAJA?; MIDA ON SUVEL VAJA? MÄRGI.; METSA•MARJAD; MILLISEID MARJU SAAB METSAST KORJATA? MÄRGI ÄRA.; ÜKS ON LIIGNE; IGAS REAS ON ÜKS ÜLELIIGNE. MÄRGI SEE ÄRA. 2; IGAS REAS ON ÜKS ÜLELIIGNE. MÄRGI SEE ÄRA. 1

## ROBOTID. LISA
URL: https://www.opiq.ee/kit/554/chapter/31013
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.75
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, robotid, lisa, leia, roboti, teine, lohista, robot
Topics RU: математика, деление, раздели, частное, половина
Topics EN: mathematics, division, divide, quotient, half
Headings: ROBOTID. LISA; LEIA ROBOTI TEINE POOL. LOHISTA; ROBOT

## TÄHT Ä
URL: https://www.opiq.ee/kit/554/chapter/30911
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.8
Topics ET: matemaatika, täht, õpin, kirjutama, laulame, koos, sõna, kirjuta, asemel, saad
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT Ä; ÕPIN KIRJUTAMA; LAULAME KOOS; TÄHT JA SÕNA; Kirjuta A asemel Ä. Mis sõna saad? Kirjuta. 3; Kirjuta A asemel Ä. Mis sõna saad? Kirjuta. 1; KAS Õ VÕI Ä?; Vali õige täht.; OTSIN TÄHTEDE SEAST SÕNU; LEIA REAST SÕNA. VAJUTA IGALE TÄHELE.

## TÄHT Ö
URL: https://www.opiq.ee/kit/554/chapter/30912
Book: KORDAME TÄHTI
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_avita_est
Chapter ID: 1.9
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, täht, õpin, kirjutama, laulame, koos, koostan, sõnu, pane, tähtedest
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: TÄHT Ö; ÕPIN KIRJUTAMA; LAULAME KOOS; KOOSTAN SÕNU; Pane tähtedest kokku sõnad ja loe.; LOEN LAUSEID; Lohista lause number sobivale pildile.

## Ma õpin eesti keeles. I osa. Я учусь на эстонском языке. Часть I – Opiq
URL: https://www.opiq.ee/Kit/Details/538
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 76
Topics ET: matemaatika, õpin, eesti, keeles, opiq
Topics RU: математика, учусь, эстонском, языке, часть
Topics EN: mathematics

## TÄHT A
URL: https://www.opiq.ee/kit/538/chapter/29786
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.1
Topics ET: matemaatika, täht, häälik, kuula, sõna, ütle, välja, vaata, kuidas, kirjutatakse
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT A; HÄÄLIK A; 1.; KUULA SÕNA JA ÜTLE SEE VÄLJA. 2; KUULA SÕNA JA ÜTLE SEE VÄLJA. 1; VAATA, KUIDAS KIRJUTATAKSE A-TÄHTE; TRÜKI KASTI ÜKS A-TÄHT; TRÜKI; KAS OSKAD?

## PUU- JA KÖÖGIVILJAD. MARJAD
URL: https://www.opiq.ee/kit/538/chapter/29795
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.10
Topics ET: matemaatika, taim, taimed, puu, lill, köögiviljad, marjad, puuviljad, saak, värvi
Topics RU: математика, растение, растения, дерево, цветок, отметь, фрукты, ягоды, собирает
Topics EN: mathematics, plant, plants, tree, flower
Headings: PUU- JA KÖÖGIVILJAD. MARJAD; KÖÖGIVILJAD; Отметь 1; PUUVILJAD; Фрукты; MARJAD; Отметь ягоды; SAAK; Кто что собирает?; Ира; Рон; MIS VÄRVI ON MARI VÕI KÖÖGIVILI?; ...

## TÄHT O
URL: https://www.opiq.ee/kit/538/chapter/29796
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.11
Topics ET: matemaatika, täht, hääli, mitmes, häälik, tean, neid, tähti, pildil, vaata
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT O; HÄÄLI!; MITMES HÄÄLIK ON O?; MA TEAN NEID TÄHTI; Mis on pildil? Hääli. 3; Mis on pildil? Hääli. 2; Mis on pildil? Hääli. 1; VAATA, KUIDAS KIRJUTATAKSE O-TÄHTE; TRÜKI KASTI ÜKS O-TÄHT; O-täht; KIRJUTA IGASSE MAJAKESSE ÕIGE TÄHT; KIRJUTA TÄHT ÕIGESSE MAJAKESSE.

## Буква О о
URL: https://www.opiq.ee/kit/538/chapter/29797
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.12
Topics ET: matemaatika
Topics RU: математика, буква, звук, отметь, буквы, печатаем, букву, ищем, место, слове
Topics EN: mathematics
Headings: Буква О о; Звук О; Звук 0 3; Звук о 1; Звук 0 2; Буква О; Отметь все буквы О о; Печатаем букву О; Ищем место буквы в слове; Перетащи букву О в слова 2; Перетащи букву О в слова 1; Перетащи буквы А и О; Учимся читать; 3Б; 3А; Какая карта приведёт тебя к каждой из картинок? Собери пары.; Я умею; С какой буквы начинается слово? 2; С какой буквы начинается слово? 1; Лабиринт; Кто где живёт? Напечатай букву в нужном домике.

## LAI, KITSAS
URL: https://www.opiq.ee/kit/538/chapter/29798
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.13
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, geomeetria, kujund, kujundid, sirge, lõik, kitsas, võrdleme, laiust
Topics RU: математика, сравнение, сравни, больше, меньше, геометрия, фигура, фигуры, прямая, отрезок, шире, всего, кому, какая, дорога
Topics EN: mathematics, comparison, compare, greater, less, geometry, shape, shapes, line, segment
Headings: LAI, KITSAS; VÕRDLEMINE; VÕRDLEME LAIUST; Что шире всего?; Кому какая дорога подойдёт? Собери пары.; KITSAS, LAI. SIRGE, KÕVER; Послушай задание и отметь нужную дорогу. 4; Послушай задание и отметь нужную дорогу. 1; Послушай задание и отметь нужную дорогу. 2; Послушай задание и отметь нужную дорогу. 3

## PIKK JA LÜHIKE. SUUR JA VÄIKE
URL: https://www.opiq.ee/kit/538/chapter/29799
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.14
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, pikk, lühike, suur, väike, õpime, võrdlema, kõrge
Topics RU: математика, сравнение, сравни, больше, меньше, пеэтер
Topics EN: mathematics, comparison, compare, greater, less
Headings: PIKK JA LÜHIKE. SUUR JA VÄIKE; VÕRDLEMINE; ÕPIME VÕRDLEMA; Пеэтер 3; Пеэтер 1; Пеэтер 2; KÕRGE JA MADAL; Начни с самой низкой ёлочки

## TÄHT I
URL: https://www.opiq.ee/kit/538/chapter/29800
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.15
Topics ET: matemaatika, täht, valime, tähe, millise, häälikuga, sõna, algab, märgi, pildid
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT I; VALIME TÄHE. KAS A VÕI I?; MILLISE HÄÄLIKUGA SÕNA ALGAB? 4; MILLISE HÄÄLIKUGA SÕNA ALGAB? 1; MILLISE HÄÄLIKUGA SÕNA ALGAB? 2; MILLISE HÄÄLIKUGA SÕNA ALGAB? 3; LOE; SÕNA AI; MÄRGI PILDID, MILLE JUURDE NEED SOBIVAD SÕNAD AI ai; VAATA, KUIDAS KIRJUTATAKSE I-TÄHTE; TRÜKI KASTI SÕNA AI; TRÜKI

## Буква И и
URL: https://www.opiq.ee/kit/538/chapter/29801
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.16
Topics ET: matemaatika
Topics RU: математика, буква, звук, печатаем, букву, учимся, читать, определи, схема
Topics EN: mathematics
Headings: Буква И и; Звук И; Звук и 4; Звук и 1; Звук и 2; Звук и 3; Буква И; Печатаем букву И; ...; Учимся читать; 3В; 3А; 3Б; Определи, схема какого слова здесь дана. Отметь подходящую картинку 3; Определи, схема какого слова здесь дана. Отметь подходящую картинку 1; Определи, схема какого слова здесь дана. Отметь подходящую картинку 2; Я умею; С какой буквы начинается название предмета? Отметь эту букву 1; С какой буквы начинается название предмета?Отметь эту букву 1
Task examples: Найди и отметь в алфавите буквы "Ии".; Прочитай стихотворение. Отметь слово, которое повторяется.

## ROHKEM, VÄHEM, SAMA PALJU
URL: https://www.opiq.ee/kit/538/chapter/29802
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.17
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, rohkem, vähem, sama, palju, mida
Topics RU: математика, сравнение, сравни, больше, меньше, столько, чего
Topics EN: mathematics, comparison, compare, greater, less
Headings: ROHKEM, VÄHEM, SAMA PALJU; Больше, меньше, столько же; MIDA ON ROHKEM? MIDA ON VÄHEM?; Чего больше? Чего меньше?; SAMA PALJU; Отметь столько же груш, сколько и детей. ​Отмечай груши по порядку.; KAS KÕIGILE LASTELE JÄTKUB ÕUNU?; Сколько яблок не хватает? Отметь.; KUMMAL PILDIL ON ROHKEM ASJU?; ...

## MITU? LOENDAME
URL: https://www.opiq.ee/kit/538/chapter/29803
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.18
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, mitu, loendame, triipu
Topics RU: математика, сравнение, сравни, больше, меньше, отметь, столько, квадратиков, каком, шарфе, полосок
Topics EN: mathematics, comparison, compare, greater, less
Headings: MITU? LOENDAME; MITU TRIIPU?; Отметь столько же квадратиков 2; Отметь столько же квадратиков.; На каком шарфе полосок больше?; MITU KORRUST?; Сколько этажей? 2; Сколько этажей? 1; MITU ÕUNA?; Сколько яблок?; MITU HERNETERA?; Сколько горошин?

## PUUD
URL: https://www.opiq.ee/kit/538/chapter/29804
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.19
Topics ET: matemaatika, taim, taimed, puu, lill, puud, puude, nimetused, kuula, laula, kaasa, puuoksad, lohista, oksake
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: PUUD; PUUDE NIMETUSED; MIS PUU SEE ON?; 6.; 1.; 2.; 3.; 4.; 5.; KUULA JA LAULA KAASA!; PUUOKSAD; LOHISTA OKSAKE ÕIGE PUU JUURDE 2.; LOHISTA OKSAKE ÕIGE PUU JUURDE.; PUUDE LEHED; MILLISE PUU LEHT SEE ON?; SÜGISESED MEISTERDUSED; Из чего что сделано? Ühenda paarid.; MINU VÄIKE KALLIS PLANEET

## Буква А а
URL: https://www.opiq.ee/kit/538/chapter/29787
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, буква, звук, отмечаем, букву, отметь, буквы, печатаем, напечатай
Topics EN: mathematics
Headings: Буква А а; Звук А; Звук а 4; Звук а 1; Буква А; Отмечаем букву А а; Отметь все буквы А, а.; Печатаем букву; Напечатай.; Учимся читать; Перетащи букву а; Лиса, акула; 3А; Пройди лабиринт
Task examples: Отметь предметы, названия которых начинаются с буквы "Аа".; Найди одинаковые группы букв. Собери пары.

## TÄHT Õ
URL: https://www.opiq.ee/kit/538/chapter/29805
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.20
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, mitmes, häälik, vajuta, õigele, mummule, vaata
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT Õ; KUULA JA KORDA; MITMES HÄÄLIK ON Õ? VAJUTA ÕIGELE MUMMULE. 3; MITMES HÄÄLIK ON Õ? VAJUTA ÕIGELE MUMMULE. 4; MITMES HÄÄLIK ON Õ? VAJUTA ÕIGELE MUMMULE. 1; MITMES HÄÄLIK ON Õ? VAJUTA ÕIGELE MUMMULE. 2; VAATA, KUIDAS KIRJUTATAKSE Õ-TÄHTE; KUI SÕNAS ON TÄHT Õ, SIIS KIRJUTA SEE RUUDUKESSE. 3; KUI SÕNAS ON TÄHT Õ, SIIS KIRJUTA SEE RUUDUKESSE. 1; KUI SÕNAS ON TÄHT Õ, SIIS KIRJUTA SEE RUUDUKESSE. 2; MA TEAN NEID TÄHTI; VAJUTA NEILE TÄHTEDELE. 2; VAJUTA NEILE TÄHTEDELE. 1

## Буква Ы
URL: https://www.opiq.ee/kit/538/chapter/29806
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.21
Topics ET: matemaatika
Topics RU: математика, буква, звук, печатаем, букву, напечатай, словах, конце, слова
Topics EN: mathematics
Headings: Буква Ы; Звук ы; Звук ы 4; Звук ы 1; Звук ы 2; Звук ы 3; Печатаем букву; Напечатай.; Буква ы в словах; Напечатай букву ы 2; Напечатай букву ы 1; Ы в конце слова 2; Ы в конце слова 1; Один – много; Собери пары; Напечатай букву "ы" рядом с тем словом, которое на неё оканчивается. 3; Напечатай букву "ы" рядом с тем словом, которое на неё оканчивается. 1; Напечатай букву "ы" рядом с тем словом, которое на неё оканчивается. 2; Учимся читать; Отгадай слово. Перетащи картинку под подходящую схему.; Отгадай слово. Перетащи картинку под подходящую схему. 2
Task examples: Найди и отметь в алфавите букву "ы" .

## KOHAL, ALL. TAGA, EES. VAHEL
URL: https://www.opiq.ee/kit/538/chapter/29807
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.22
Topics ET: matemaatika, kohal, taga, vahel, kuulame, jätame, meelde, kuula, lohista, õigesse
Topics RU: математика
Topics EN: mathematics
Headings: KOHAL, ALL. TAGA, EES. VAHEL; KUULAME JA JÄTAME MEELDE!; KUULA JA LOHISTA ÕIGESSE KOHTA; Послушай и перетащи в нужное место.; MIDA ÜTLES FOTOGRAAF?; VAJUTA PILDILE, KUS SASS SEISAB ÕIGES KOHAS.; MIS ON EES? MIS ON TAGA?; ...4; ...1; ...2; ...3

## ESIMENE, VIIMANE, EELVIIMANE
URL: https://www.opiq.ee/kit/538/chapter/29808
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.23
Topics ET: matemaatika, esimene, viimane, eelviimane, kuulame, jätame, meelde, tean, kuula, märgi
Topics RU: математика
Topics EN: mathematics
Headings: ESIMENE, VIIMANE, EELVIIMANE; KUULAME JA JÄTAME MEELDE!; MA TEAN; Kuula ja märgi ära 4; Kuula ja märgi ära 1; Kuula ja märgi ära 2; Kuula ja märgi ära 3; UURI PILTE JA TÄIDA ÜLESANDED; MA TEAN JA OSKAN; Eelviimane õun; Esimene õun; Viimane õun; Kuula ja aseta õigesse järjekorda.

## VALGUS JA SOOJUS
URL: https://www.opiq.ee/kit/538/chapter/29809
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.24
Topics ET: matemaatika, valgus, soojus, märgi, asjad, annavad, valgust, soojust, kellel, vaja
Topics RU: математика
Topics EN: mathematics
Headings: VALGUS JA SOOJUS; VALGUS; Märgi asjad, mis annavad valgust.; SOOJUS; Märgi asjad, mis annavad soojust.; KELLEL ON VAJA VALGUST JA SOOJUST?; Kellele on vaja valgust ja soojust? Märgi sobivad pildid.

## KODUMASINAD
URL: https://www.opiq.ee/kit/538/chapter/29810
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.25
Topics ET: matemaatika, kodumasinad, tead, masinad, need, tean, kodumasinaid, kuula, märgi, sobiv
Topics RU: математика
Topics EN: mathematics
Headings: KODUMASINAD; KAS SA TEAD, MIS MASINAD NEED ON?; MA TEAN KODUMASINAID; Kuula ja märgi sobiv pilt. 1; MILLEKS ON VAJA KODUMASINAID?; ...; ..; ELEKTRISEADMED; Millised seadmed töötavad elektri abil? Märgi need.; TEEME PANNKOOKE; Milliseid asju on vaja, et teha pannkooke? Märgi need ära.; MINU VÄIKE KALLIS PLANEET

## TÄHT E
URL: https://www.opiq.ee/kit/538/chapter/29811
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.26
Topics ET: matemaatika, täht, häälik, mitmes, tähe, kirjutamine, sõna, kirjuta, nende, piltide
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT E; HÄÄLIK E; MITMES HÄÄLIK ON E? 4; MITMES HÄÄLIK ON E? 1; MITMES HÄÄLIK ON E?2; MITMES HÄÄLIK ON E? 3; E-TÄHE KIRJUTAMINE; LOE; SÕNA EI; KIRJUTA NENDE PILTIDE ALLA SÕNA EI; MA OSKAN; põder; elevant; karu; lõvi; koer; orav; siil; ilves

## Буква Э э
URL: https://www.opiq.ee/kit/538/chapter/29812
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.27
Topics ET: matemaatika
Topics RU: математика, буква, звук, печатаем, букву, напечатай, учимся, читать, если
Topics EN: mathematics
Headings: Буква Э э; Звук Э; Звук ы 2; Звук ы 1; Печатаем букву Э; Напечатай.; Учимся читать; Если в названии предмета есть буква "ы", то напечатай её в квадратике. 2; Если в названии предмета есть буква "ы", то напечатай её в квадратике. 1; 3Б; 3А; Эхо; Я умею; С какой буквы начинается название предмета? Отметь эту букву. 2; С какой буквы начинается название предмета? Отметь эту букву. 1
Task examples: Найди и отметь в алфавите буквы "Ээ".

## Читалочка
URL: https://www.opiq.ee/kit/538/chapter/31626
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.28
Topics ET: matemaatika
Topics RU: математика, читалочка, работа, картинкам, попробуй, пропеть, говорит, соедини, слово, схема
Topics EN: mathematics
Headings: Читалочка; Работа по картинкам; Попробуй пропеть; Кто что говорит?; Кто что говорит? Соедини.; Слово и его схема; Слово и схема 1; Буквы в слове; улитка; глобус; арбуз; бананы; сливы; алоэ; тыква; грибы; малина

## TÄHT M
URL: https://www.opiq.ee/kit/538/chapter/31627
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.29
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, järele, mitmes, häälik, vaata, kuidas, kirjutatakse
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT M; KUULA JA KORDA JÄRELE; MITMES HÄÄLIK ON M? 3; MITMES HÄÄLIK ON M?; MITMES HÄÄLIK ON M? 2; VAATA, KUIDAS KIRJUTATAKSE M-TÄHTE; ÕPIME LUGEMA; Koosta "pusle" 2; Koosta "pusle" 1; Lohista silbid õigesse kohta. 2; Lohista silbid õigesse kohta. 1; Loe sõnad ette. Ühenda need sobiva pildiga. 2; Loe sõnad ette. Ühenda need sobiva pildiga. 1

## VÄRVUS, KUJU, SUURUS
URL: https://www.opiq.ee/kit/538/chapter/29788
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.3
Topics ET: matemaatika, geomeetria, kujund, kujundid, sirge, lõik, värvus, kuju, suurus, meie, ümber
Topics RU: математика, геометрия, фигура, фигуры, прямая, отрезок, цвет, форма, размер
Topics EN: mathematics, geometry, shape, shapes, line, segment
Headings: VÄRVUS, KUJU, SUURUS; Цвет, форма, размер; MATEMAATIKA MEIE ÜMBER; VASTUS; RING, KOLMNURK JA NELINURK; MA TEAN NEID KUJUNDEID; Как называются фигуры? 3; Как называются фигуры? 1; Kuula ja paiguta kujundid järjekorda.; MIS KUJUNDIT MEENUTAVAD NEED ESEMED?; OVAAL; Kolmnurk; ristkülik; ring

## Буква М м
URL: https://www.opiq.ee/kit/538/chapter/31628
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.30
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, какая, отметь, печатаем, букву, напечатай
Topics EN: mathematics
Headings: Буква М м; Слушаем и произносим; Какая буква м по счёту? Отметь. 1; Печатаем букву; Напечатай.; Буква М в слове; Если в названии предмета есть буква "м", то напечатай её в квадратике. 1; Читаем слоги; Собери "пазл". Перетащи нужную букву и прочитай слоги. 2; Собери "пазл". Перетащи нужную букву и прочитай слоги. 1; Собери и прочитай слоги "наоборот". Напечатай слоги. 2; Собери и прочитай слоги "наоборот". Напечатай слоги. 1; Читаем слова; Перетащи цветочек к подходящей картинке. 2; Перетащи цветочек к подходящей картинке. 1; Назови предмет. Перетащи картинку к подходящей схеме.; Я умею; Прочитай. Собери пары.
Task examples: Найди и отметь буквы "Мм" в алфавите.

## ÜKS
URL: https://www.opiq.ee/kit/538/chapter/31629
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.31
Topics ET: matemaatika, arv, arvud, arvu, numbrid, mitu, mida, pildil, vajuta, kastikesele, vaata, kuidas, kirjutatakse
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: ÜKS; MITU? ÜKS; MIDA ON PILDIL ÜKS?; Mida on pildil üks? Vajuta kastikesele.; VAATA, KUIDAS KIRJUTATAKSE NUMBER ÜHTE

## HULGAD
URL: https://www.opiq.ee/kit/538/chapter/29813
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.32
Topics ET: matemaatika, hulgad, üleliigne, leia, märgi, igas, grupis, liigne, eseme, hulk
Topics RU: математика
Topics EN: mathematics
Headings: HULGAD; ÜLELIIGNE ESE; Leia ja märgi igas grupis üks liigne ese. 4; Leia ja märgi igas grupis üks liigne eseme. 1; Leia ja märgi igas grupis üks liigne ese 2; Leia ja märgi igas grupis üks üleliigne ese. 3; MIS ON HULK?; MOODUSTAME HULGAD; Leia ühesuguste asjade hulgad. Lohista.; Sügissaak; lk 28/1

## SEENED
URL: https://www.opiq.ee/kit/538/chapter/31630
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.33
Topics ET: matemaatika, seened, kuidas, seeni, nimetatakse, tean, neid, kuula, märgi, õige
Topics RU: математика
Topics EN: mathematics
Headings: SEENED; KUIDAS SEENI NIMETATAKSE?; MA TEAN NEID SEENI; Kuula ja märgi õige vastus. 1; SÖÖDAVAD JA MITTE•SÖÖDAVAD SEENED; Millist seent ei sööda? Märgi.; KES MIDA SÖÖB? ÜHENDA PAARID; Kes mida sööb? Ühenda paarid.; OTSIME TÄPSELT SAMASUGUST SEENT; ...; ...2; ...3

## TERAVILJAD
URL: https://www.opiq.ee/kit/538/chapter/31631
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.34
Topics ET: matemaatika, teraviljad, õpin, vahet, tegema, kuula, märgi, laula, kaasa, tean
Topics RU: математика
Topics EN: mathematics
Headings: TERAVILJAD; MA ÕPIN VAHET TEGEMA; Kuula ja märgi 4; Kuula ja märgi 1; Kuula ja märgi 2; Kuula ja märgi 3; KUULA JA LAULA KAASA; MA TEAN; TERAVILJA•TOOTED; MILLISTE TOITUDE TEGEMISEKS ON KASUTATUD TERAVILJU?; MINU VÄIKE KALLIS PLANEET

## TÄHT N
URL: https://www.opiq.ee/kit/538/chapter/31632
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.35
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, häälda, vaata, kuidas, kirjutatakse, tähte, sõnades
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT N; KUULA JA KORDA; Kuula ja häälda! 2; Kuula ja häälda! 1; VAATA, KUIDAS KIRJUTATAKSE N-TÄHTE; N-TÄHT SÕNADES; TÄHT N SÕNADES 3; TÄHT N SÕNADES 1; TÄHT N SÕNADES 2; KOGUME SÕNU; KOGUME SÕNU 4; KOGUME SÕNU 1; KOGUME SÕNU 2; KOGUME SÕNU 3; ÕPIME LUGEMA; Kes või mis on pildil? Vajuta õigele sõnale.; TRÜKI KASTI SÕNA NINA; ...

## Буква Н н
URL: https://www.opiq.ee/kit/538/chapter/31633
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.36
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, послушай, произнеси, слово, какая, нажми, нужный
Topics EN: mathematics
Headings: Буква Н н; Слушаем и произносим; Послушай и произнеси слово. Какая по счёту буква "н"? Нажми на нужный кружок. 2; Послушай и произнеси слово. Какая по счёту буква "н"? Нажми на нужный кружок. 1; Буква Н; Отметь букву Н; Печатаем букву Н; Составляем и читаем слоги; Буква Н в словах; Договори до слова; Читаем слова; Соедини слово и картинку.
Task examples: Найди и отметь буквы "Нн" в алфавите.

## PUNKT, SIRGJOON, KÕVERJOON. JOONLAUD
URL: https://www.opiq.ee/kit/538/chapter/31634
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.37
Topics ET: matemaatika, punkt, sirgjoon, kõverjoon, joonlaud, märgista, objektid, kumerate, joonte, kujulised
Topics RU: математика
Topics EN: mathematics
Headings: PUNKT, SIRGJOON, KÕVERJOON. JOONLAUD; SIRGJOON, KÕVERJOON; Märgista objektid, mis on kumerate joonte kujulised.; MA TEAN JA OSKAN; MÄRGI KÕIK KÕVERJOONED.; Märgi kõik sirged jooned.; KUIDAS JOONESTADA SIRGET JOONT?

## HAMMASTE TERVIS. HÜGIEEN
URL: https://www.opiq.ee/kit/538/chapter/31635
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.38
Topics ET: matemaatika, liitmine, liida, summa, kokku, inimene, keha, meeled, tervis, hammaste, hügieen, tervise, eest, hoolitsemine, isikliku, hügieeni, tarbed
Topics RU: математика, сложение, сложи, сумма, человек, тело, чувства, здоровье
Topics EN: mathematics, addition, add, sum, human, body, senses, health
Headings: HAMMASTE TERVIS. HÜGIEEN; TERVISE EEST HOOLITSEMINE; Tervise hoolitsemine; ISIKLIKU HÜGIEENI TARBED; ...; MIKS NEED PILDID KOKKU SOBIVAD?; MINU VÄIKE KALLIS PLANEET

## TÄHT S
URL: https://www.opiq.ee/kit/538/chapter/31636
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.39
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, vaata, kuidas, kirjutatakse, tähte, õpime, lugema
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT S; KUULA JA KORDA; S-täht 4; S-täht 1; S-täht 2; S-täht 3; VAATA, KUIDAS KIRJUTATAKSE S-TÄHTE; ÕPIME LUGEMA; Kirjuta kastidesse s-täht 7; Kirjuta kastidesse s-täht 8; Kirjuta kastidesse s-täht 1; Kirjuta kastidesse s-täht 2; Kirjuta kastidesse s-täht 3; Kirjuta kastidesse s-täht 4; Kirjuta kastidesse s-täht 5; Kirjuta kastidesse s-täht 6; KUULA SÕNA. VALI ÕIGED TÄHED. 2; KUULA SÕNA. VALI ÕIGED TÄHED. 1

## LASTEAED
URL: https://www.opiq.ee/kit/538/chapter/29789
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.4
Topics ET: matemaatika, lasteaed, kool, kodu, kuula, lohista, käib, käitumis, reeglid, laste
Topics RU: математика
Topics EN: mathematics
Headings: LASTEAED; LASTEAED, KOOL, KODU; Kuula ja lohista! Lasteaed, kool, kodu; ​KES KUS KÄIB?; ...; KÄITUMIS•REEGLID LASTE•AIAS; Отметь верный ответ. VALI ÕIGE VASTUS 2; Отметь верный ответ. VALI ÕIGE VASTUS 1; VÄRVID; Kuula ja märki2.; Kuula ja märki1.; MIS VÄRVI?; KAS OSKAD?

## Буква С с
URL: https://www.opiq.ee/kit/538/chapter/31637
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.40
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, послушай, произнеси, слово, какая, нажми, нужный
Topics EN: mathematics
Headings: Буква С с; Слушаем и произносим; Послушай и произнеси слово. Какая по счёту буква "с"? Нажми на нужный кружок 1; Буква С; Печатаем букву С; Буква С в словах; Если в слове есть буква с, то напечатай её в квадратике 3; Если в слове есть буква с, то напечатай её в квадратике 1; Если в слове есть буква с, то напечатай её в квадратике 2; Собираем и читаем слоги; Слоги; Читаем слова; Читаем слова 2; Читаем слова 1; Один – много; Соедини слово с подходящей картинкой.2; Соедини слово с подходящей картинкой.; Ребусы; Rebus
Task examples: Найди в алфавите и отметь буквы "Сс".

## KAKS. PAAR
URL: https://www.opiq.ee/kit/538/chapter/31638
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.41
Topics ET: matemaatika, arv, arvud, arvu, numbrid, inimene, keha, meeled, tervis, kaks, paar, mida, vajuta, pildile, millest, koosneb, koosseis
Topics RU: математика, число, числа, цифры, человек, тело, чувства, здоровье, сколько
Topics EN: mathematics, number, numbers, digits, human, body, senses, health
Headings: KAKS. PAAR; 1.; 2.; ARV 2 (KAKS); Сколько (6); Сколько (3); Сколько (2); MIDA ON KAKS? VAJUTA PILDILE.; MILLEST ARV 2 KOOSNEB?; Koosseis number kaks; INIMENE; MITU KEHAOSA ON? 4; MITU KEHAOSA ON?; MITU KEHAOSA ON? 2; MITU KEHAOSA ON? 3; PAAR; 3.; 5.; VAATA, KUIDAS KIRJUTATAKSE NUMBER KAHTE; TRÜKI KAKS A-TÄHTE; ...

## KEHAOSAD
URL: https://www.opiq.ee/kit/538/chapter/31639
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.42
Topics ET: matemaatika, kehaosad, kuidas, kehaosi, nimetatakse, tean
Topics RU: математика
Topics EN: mathematics
Headings: KEHAOSAD; KUIDAS KEHAOSI NIMETATAKSE?; MA TEAN KEHAOSI; Ma tean 1

## TUNDED
URL: https://www.opiq.ee/kit/538/chapter/31640
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.43
Topics ET: matemaatika, tunded, tean, kuidas, nimetatakse, tundeid, mida, lapsed, tunnevad, väike
Topics RU: математика
Topics EN: mathematics
Headings: TUNDED; MIS ON TUNDED?; MA TEAN, KUIDAS NIMETATAKSE TUNDEID; Ma tean 2; Ma tean 1; MIDA LAPSED TUNNEVAD?; 2.; 1.; MINU VÄIKE KALLIS PLANEET

## TÄHT K
URL: https://www.opiq.ee/kit/538/chapter/31641
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.44
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, vaata, kuidas, kirjutatakse, tähte, õpime, lugema
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT K; KUULA JA KORDA; K-täht 4; k-täht 1; K-täht 2; K-täht3; VAATA, KUIDAS KIRJUTATAKSE K‑TÄHTE; ÕPIME LUGEMA; Kirjuta kastidesse K-täht 5; Kirjuta kastidesse K-täht 4; Kirjuta kastidesse K-täht 1; Kirjuta kastidesse K-täht 2; Kirjuta kastidesse K-täht 3; Vali vajalikud tähed.3; Vali vajalikud tähed. 1; Vali vajalikud tähed.2; RISTSÕNA; Kes või mis? Lahenda ristsõna.

## Буква К к
URL: https://www.opiq.ee/kit/538/chapter/31642
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.45
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, послушай, произнеси, слово, какая, нажми, нужный
Topics EN: mathematics
Headings: Буква К к; Слушаем и произносим; Послушай и произнеси слово. Какая по счёту буква "к"? Нажми на нужный кружок 2; Послушай и произнеси слово. Какая по счёту буква "к"? Нажми на нужный кружок 1; Буква К; Печатаем букву К; Напечатай в квадратике букву К.; Буква К в словах; Отметь только те предметы, в названии которых есть буква "к".; Договори до слова; Прочитай слоги. Соедини их с подходящей картинкой.; Читаем слова; Собери слова; Соедини слово и картинку; Читаем и пишем слова; Соедини слоги. Напиши и прочитай слова. 2; Соедини слоги. Напиши и прочитай слова. 1; Назови предмет. Закончи слово.
Task examples: Найди и отметь в алфавите буквы "Кк".

## TÄHT T
URL: https://www.opiq.ee/kit/538/chapter/31643
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.46
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, mitmes, häälik, vajuta, õigele, mummule, vaata
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT T; KUULA JA KORDA; Mitmes häälik on t? Vajuta õigele mummule. 2; Mitmes häälik on t? Vajuta õigele mummule. 1; VAATA, KUIDAS KIRJUTATAKSE T‑TÄHTE; TRÜKI ÜKS T-TÄHT; Trüki kasti t; ÕPIME SÕNU LUGEMA; ÕPIME SÕNU LUGEMA. 2; ÕPIME SÕNU LUGEMA. 1; LEIA TÄHERÄGASTIKUST SÕNAD; Leia sõnad

## Буква Т т
URL: https://www.opiq.ee/kit/538/chapter/31644
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.47
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, печатаем, букву, напечатай, квадратике, словах
Topics EN: mathematics
Headings: Буква Т т; Слушаем и произносим; 3.; 4.; 1.; 2.; Буква К; Печатаем букву Т; Напечатай в квадратике букву Т.; Буква Т в словах; Разгадай слово.; Назови предметы. Если в слове есть буква т, то напечатай её в квадратике. 4; Назови предметы. Если в слове есть буква т, то напечатай её в квадратике. 1; Назови предметы. Если в слове есть буква т, то напечатай её в квадратике. 2; Назови предметы. Если в слове есть буква т, то напечатай её в квадратике. 3; Составляем и читаем слова; Составь, прочитай и напиши слова 2; Составь, прочитай и напиши слова 1; Подписываем картинки; Подпиши картинку 3; Подпиши картинку 4; Подпиши картинку 1; Подпиши картинку 2; Учимся читать и понимать; Собери пары
Task examples: Найди и отметь в алфавите буквы "Тт".

## Читалочка
URL: https://www.opiq.ee/kit/538/chapter/31645
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.48
Topics ET: matemaatika
Topics RU: математика, читалочка, собираем, слогов, слова, читаем, прочитай, соедини, слово, картинку
Topics EN: mathematics
Headings: Читалочка; Собираем из слогов слова; Собираем из слогов слова (2); Читаем слова; Прочитай слова. Соедини слово и картинку 3; Прочитай слова. Соедини слово и картинку 1; Прочитай слова. Соедини слово и картинку 2; Как зовут детей? Допиши пропущенные буквы и слог.; Как зовут детей?; Читаем текст

## KOLM
URL: https://www.opiq.ee/kit/538/chapter/29814
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.49
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kolm, mitu, trüki, millest, koosneb, vaata, pilte, puuduvad
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: KOLM; ARV 3 (KOLM); KAS 1, 2 VÕI 3?; Mitu on? Trüki 1, 2 või 3. - 2; Mitu on? Trüki 1, 2 või 3. - 1; MILLEST ARV 3 KOOSNEB?; Vaata pilte. Trüki puuduvad numbrid. 1; Trüki ringidesse vajalikud numbrid.; MA TEAN, MILLEST ARV 3 KOOSNEB; Maja; LAHENDAME ÜLESANDEID; 1.; 2.; VAATA, KUIDAS KIRJUTATAKSE NUMBER KOLME; TRÜKI KOLM K-TÄHTE; TRÜKI KOLM K-TÄHTE.

## KODU, PERE
URL: https://www.opiq.ee/kit/538/chapter/29790
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.5
Topics ET: matemaatika, liitmine, liida, summa, kokku, kodu, pere, kuula, märki, värvi, majas, keegi, elab, esemed
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: KODU, PERE; PERE; Kuula ja märki! 3; Kuula ja märki! 1; Kodu; MIS VÄRVI MAJAS KEEGI ELAB?; Esemed ja asjad (1); ...; Esemed ja asjad (2); MIS EI SOBI TEISTEGA KOKKU? MIKS?; MINU VÄIKE KALLIS PLANEET

## KOLMNURK
URL: https://www.opiq.ee/kit/538/chapter/31647
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.50
Topics ET: matemaatika, kolmnurk, laulame, koos, sarnaneb, kolmnurgaga, vajuta, piltidele, kolmnurga, moodi
Topics RU: математика
Topics EN: mathematics
Headings: KOLMNURK; LAULAME KOOS; MIS SARNANEB KOLMNURGAGA?; VAJUTA PILTIDELE, MIS ON KOLMNURGA MOODI?; Märgi ära iga kolmas kolmnurk.; MITU KÜLGE ON KOLMNURGAL? TIPPU? MÄRGI ÄRA KÕIK KOLMNURGAD.; KOLMNURK JA RING; ....

## LIIKLEME OHUTULT
URL: https://www.opiq.ee/kit/538/chapter/31648
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.51
Topics ET: matemaatika, liikleme, ohutult, turvavahendid, olulised, liiklusreeglid, kuula, laula, kaasa, väike
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLEME OHUTULT; TURVAVAHENDID; OLULISED LIIKLUSREEGLID; ...; KUULA JA LAULA KAASA; MINU VÄIKE KALLIS PLANEET

## OHT JA OHUTUS
URL: https://www.opiq.ee/kit/538/chapter/31649
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.52
Topics ET: matemaatika, arv, arvud, arvu, numbrid, ohutus, jäta, meelde, pääste, ameti, telefoni, ohtlikud, esemed
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: OHT JA OHUTUS; JÄTA MEELDE PÄÄSTE•AMETI TELEFONI•NUMBER.; OHTLIKUD ESEMED; oht; TRÜKI PÄÄSTE•AMETI TELEFONI•NUMBER; ...

## LIIDAME
URL: https://www.opiq.ee/kit/538/chapter/31650
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.53
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, taim, taimed, puu, lill, liidame, kuidas, liita, kirjuta, puuduvad, märk
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры, растение, растения, дерево, цветок
Topics EN: mathematics, addition, add, sum, number, numbers, digits, plant, plants, tree, flower
Headings: LIIDAME; KUIDAS LIITA?; MIS ON LIITMINE?; LIIDA. KIRJUTA PUUDUVAD ARVUD JA MÄRK.2; LIIDA. KIRJUTA PUUDUVAD ARVUD JA MÄRK.; TEE LIITMIST. KIRJUTA PUUDUVAD ARVUD JA MÄRK – 2; ÕPIME ÜLESANDEID LAHENDAMA; VAATA PILTE. JUTUSTA, MIS TOIMUB. LOHISTA LILL SOBIVALE PILDILE. 1; ME LÄHEME POODI; TEE LIITMIST. KIRJUTA PUUDUVAD ARVUD - 3; TEE LIITMIST. KIRJUTA PUUDUVAD ARVUD - 1; TEE LIITMIST. KIRJUTA PUUDUVAD ARVUD - 2

## METSLOOMAD JA KODULOOMAD
URL: https://www.opiq.ee/kit/538/chapter/31651
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.54
Topics ET: matemaatika, loom, loomad, linnud, putukad, metsloomad, koduloomad, kuula, ütles, lohista, märgi, keda, fotograaf
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: METSLOOMAD JA KODULOOMAD; KUULA VÕI LOE; KES NII ÜTLES? LOHISTA.; METSLOOMAD; MÄRGI LOOMAD, KEDA FOTOGRAAF VÕIB EESTI METSADES PILDISTADA.; KODULOOMAD; LOOMADE VARJUD.; MIDA SAAME KODULOOMADELT? MOODUSTA PAARID.; MA TEAN METSLOOMI JA KODULOOMI; KES ON ÜLELIIGNE? MÄRGI ÄRA. PÕHJENDA OMA VALIKUT. 2; KES ON ÜLELIIGNE? MÄRGI ÄRA. PÕHJENDA OMA VALIKUT. 1; MINU VÄIKE KALLIS PLANEET

## TÄHT L
URL: https://www.opiq.ee/kit/538/chapter/31652
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.55
Topics ET: matemaatika, liitmine, liida, summa, kokku, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, mitmes, häälik, vajuta, õigele, mummule, õpime
Topics RU: математика, сложение, сложи, сумма, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, addition, add, sum, multiplication, multiply, product, revision, review, practice
Headings: TÄHT L; KUULA JA KORDA; MITMES HÄÄLIK ON L? VAJUTA ÕIGELE MUMMULE 2; MITMES HÄÄLIK ON L? VAJUTA ÕIGELE MUMMULE 1; ÕPIME LUGEMA; LOE SÕNU. VAJUTA ÕIGELE PILDILE - 2; LOE SÕNU. VAJUTA ÕIGELE PILDILE - 1; VAATA, KUIDAS KIRJUTATAKSE L-TÄHTE; TRÜKI KASTI KAKS L-TÄHTE; TRÜKI KAKS L-TÄHTE.; MÄNGUD TÄHTEDE JA SÕNADEGA; Kirjuta piltidele allkiri.; KIRJUTA IGA SÕNA ALGUSTÄHT RUUTU. MIS SÕNA KOKKU SAID?

## Буква Л л
URL: https://www.opiq.ee/kit/538/chapter/31653
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.56
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, какая, нажми, нужные, кружки, квадратики, алфавите
Topics EN: mathematics
Headings: Буква Л л; Слушаем и произносим; Какая по счёту буква Л? Нажми на нужные кружки или квадратики. 2; Какая по счёту буква Л? Нажми на нужные кружки или квадратики. 1; Буква Л в алфавите; Печатаем букву Л; Напечатай слово луна.; Буква Л в словах; Названия каких животных начинаются на букву "л"? Отметь эти картинки.; Перетащи листик к подходящей картинке.; Собираем и читаем слова; Распутай ниточки. Напиши слово.; Собираем слово из слогов - 4; Собери слово из слогов - 1; Собираем слово из слогов - 2; Собираем слово из слогов - 3; Читаем текст
Task examples: Найди и отметь в алфавите буквы "Лл".

## LAHUTAME
URL: https://www.opiq.ee/kit/538/chapter/31654
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.57
Topics ET: matemaatika, lahutamine, lahuta, vahe, arv, arvud, arvu, numbrid, taim, taimed, puu, lill, lahutame, kuidas, lahutada, kirjuta, puuduvad, vali
Topics RU: математика, вычитание, вычти, разность, число, числа, цифры, растение, растения, дерево, цветок
Topics EN: mathematics, subtraction, subtract, difference, number, numbers, digits, plant, plants, tree, flower
Headings: LAHUTAME; KUIDAS LAHUTADA?; MIS ON LAHUTAMINE?; Lahuta. Kirjuta puuduvad arvud ja vali õiged märgid.2; Lahuta. Kirjuta puuduvad arvud ja vali õiged märgid. 1; TEE LAHUTAMINE. LOHISTA VAJALIKUD ARVUD JA MÄRGID. 3; TEE LAHUTAMINE. LOHISTA VAJALIKUD ARVUD JA MÄRGID. 1; TEE LAHUTAMINE. LOHISTA VAJALIKUD ARVUD JA MÄRGID. 2; ÕPIME ÜLESANDEID LAHENDAMA; VAATA PILTE. RÄGI, MIS JUHTUS. VASTA KÜSIMUSTELE. KIRJUTA NUMBER.; LOHISTA LILL SOBIVALE PILDILE.; ME LÄHEME POODI; KIRJUTA PUUDUVAD NUMBRID 2; KIRJUTA PUUDUVAD NUMBRID 3; KIRJUTA PUUDUVAD NUMBRID. 1

## TÄHT R
URL: https://www.opiq.ee/kit/538/chapter/31655
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.58
Topics ET: matemaatika, täht, koostame, sõnu, koosta, riikide, nimed, ristsõna, lahenda, vaata
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT R; KOOSTAME SÕNU; KOOSTA 2; KOOSTA 1; RIIKIDE NIMED; RISTSÕNA; LAHENDA RISTSÕNA.; VAATA, KUIDAS KIRJUTATAKSE R-TÄHTE

## Буква Р р
URL: https://www.opiq.ee/kit/538/chapter/31656
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.59
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, нажми, нужные, кружки, квадратики, напечатай
Topics EN: mathematics
Headings: Буква Р р; Слушаем и произносим; Нажми на нужные кружки или квадратики.; Буква Р; Напечатай слово РАК; Буква Р в словах; Буква Р в словах 2; Буква Р в словах 1; Договариваем до слова; Перетащи репку к подходящей картинке.; Собираем слова из слогов; Прочитай слова и напиши их 2; Прочитай слова и напиши их 1; Учимся читать слова; Распутай ниточки. Напиши слово.
Task examples: Найди и отметь в алфавите буквы "Рр".

## Täht U u
URL: https://www.opiq.ee/kit/538/chapter/29791
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.6
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kuula, järele, sõna, algab, tähega, kirjuta, esimesse
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Täht U u; KUULA JA KORDA JÄRELE; KUI SÕNA ALGAB TÄHEGA U, KIRJUTA SEE ESIMESSE RUUTU, KUI LÕPEB, SIIS VIIMASESSE. 2; KUI SÕNA ALGAB TÄHEGA U, KIRJUTA SEE ESIMESSE RUUTU, KUI LÕPEB, SIIS VIIMASESSE. 1; HÄÄLIK U; KAS U VÕI UU?; KUULA SÕNA. VALI ÕIGED TÄHED.3; KUULA SÕNA. VALI ÕIGED TÄHED.; KUULA SÕNA. VALI ÕIGED TÄHED.2; VAATA, KUIDAS KIRJUTATAKSE U-TÄHTE; TRÜKI KASTI SÕNA AU

## NELI
URL: https://www.opiq.ee/kit/538/chapter/31657
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.60
Topics ET: matemaatika, arv, arvud, arvu, numbrid, neli, kaks, kolm, esimene, teine, kolmas, neljas, mitu, kuupi
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: NELI; 1 ​ÜKS; 2 ​KAKS; 3 ​KOLM; 4 ​NELI; 1.​ESIMENE; 2. ​TEINE; 3. ​KOLMAS; 4. ​NELJAS; MITU?; MITU KUUPI IGAS VEERUS? VALI ÕIGED NUMBRID 1; MILLEST ARV 4 KOOSNEB?; UURI PILTE. VALI ÕIGED NUMBRID. 3; UURI PILTE. VALI ÕIGED NUMBRID. 1; UURI PILTE. VALI ÕIGED NUMBRID. 2; TÄIENDI NELJANI. LOHISTA ÕIGE ARV ESEMEID. 4; TÄIENDI NELJANI. LOHISTA ÕIGE ARV ESEMEID. 1; TÄIENDI NELJANI. LOHISTA ÕIGE ARV ESEMEID. 2; TÄIENDI NELJANI. LOHISTA ÕIGE ARV ESEMEID. 3; ÕPIME LIITMA JA LAHUTAMA; KIRJUTA PUUDUVAD ARVUD JA MÄRGID. 4; KIRJUTA PUUDUVAD ARVUD JA MÄRGID. 1; KIRJUTA PUUDUVAD ARVUD JA MÄRGID. 2; KIRJUTA PUUDUVAD ARVUD JA MÄRGID. 3; LAHENDAME ÜLESANDEID; VALI ÕIGED MÄRGID JA NUMBRID. 2; VALI ÕIGED MÄRGID JA NUMBRID. 1; MA TEAN, MILLEST ARV NELI KOOSNEB; KIRJUTA ARVU NELJA KOOSTIS.; VAATA, KUIDAS KIRJUTATAKSE NUMBER NELJA; TRÜKI NELI N-TÄHTE; ...

## NELINURK. RUUT
URL: https://www.opiq.ee/kit/538/chapter/31658
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.61
Topics ET: matemaatika, nelinurk, ruut, ring, kolmnurk, märgista, neljast
Topics RU: математика
Topics EN: mathematics
Headings: NELINURK. RUUT; RING, KOLMNURK JA NELINURK; ...; MIS ON RUUT?; MÄRGISTA IGA NELJAST RUUT.; RUUT ON NELINURK

## AASTAAJAD
URL: https://www.opiq.ee/kit/538/chapter/31659
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.62
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, neli, aastaaega, tean, aastaaegade, nimetusi, kuula, märgi, sobiv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: AASTAAJAD; NELI AASTAAEGA; MA TEAN AASTAAEGADE NIMETUSI; KUULA JA MÄRGI SOBIV PILT 4; KUULA JA MÄRGI SOBIV PILT 1; KUULA JA MÄRGI SOBIV PILT 2; KUULA JA MÄRGI SOBIV PILT 3; ÕPIME JUTUSTAMA; Jutusta 3; Jutusta 1; Jutusta 2; PUUD SÜGISEL; ...; KUULA JA LAULA KAASA

## ELUS JA ELUTA
URL: https://www.opiq.ee/kit/538/chapter/31660
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.63
Topics ET: matemaatika, taim, taimed, puu, lill, inimene, keha, meeled, tervis, elus, eluta, kuidas, kasvab, laps, pane, pildid, õigesse, järjekorda
Topics RU: математика, растение, растения, дерево, цветок, человек, тело, чувства, здоровье
Topics EN: mathematics, plant, plants, tree, flower, human, body, senses, health
Headings: ELUS JA ELUTA; KUIDAS KASVAB LAPS JA KUIDAS KASVAB PUU?; KUIDAS KASVAB PUU? PANE PILDID ÕIGESSE JÄRJEKORDA.; KUIDAS KASVAB INIMENE? PANE PILDID ÕIGESSE JÄRJEKORDA.; MÄRGI PILDID, KUS ON KUJUTATUD ELUSOLENDID.; MINU VÄIKE KALLIS PLANEET

## TÄHT V
URL: https://www.opiq.ee/kit/538/chapter/31661
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.64
Topics ET: matemaatika, täht, koostame, sõnu, koosta, muudame, tähte, sõna, otsime, vaata
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT V; KOOSTAME SÕNU; KOOSTA 1; KOOSTA 2; MUUDAME TÄHTE – MUUDAME SÕNA; MUUDAME TÄHTE – MUUDAME SÕNA 3; MUUDAME TÄHTE – MUUDAME SÕNA 1; OTSIME SÕNA; 3.; 1.; 2.; 1.1; VAATA, KUIDAS KIRJUTATAKSE V‑TÄHTE

## Буква В в
URL: https://www.opiq.ee/kit/538/chapter/31662
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.65
Topics ET: matemaatika
Topics RU: математика, буква, слушаем, произносим, если, стоит, начале, слова, напиши, первом
Topics EN: mathematics
Headings: Буква В в; Слушаем и произносим; Если "в" стоит в начале слова, то напиши её в первом квадратике, если в середине слова – то во втором. 2; Если "в" стоит в начале слова, то напиши её в первом квадратике, если в середине слова – то во втором. 1; Слово и слог; Перетащи подходящий слог, чтобы получилось слово 3; Перетащи подходящий слог, чтобы получилось слово 1; Перетащи подходящий слог, чтобы получилось слово 2; Собираем слова; Прочитай слова и напиши их 2; Прочитай слова и напиши их 1; Как зовут мальчиков? Собери и напиши имена.; Читаем предложения; Прочитай предложения. Перетащи номер к подходящей картинке.; Читаем текст

## TÄHELEPANU JA LOOGIKA
URL: https://www.opiq.ee/kit/538/chapter/31663
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.66
Topics ET: matemaatika, tähelepanu, loogika, mida, laps, teeb, märgi, sobiv, vari, aita
Topics RU: математика
Topics EN: mathematics
Headings: TÄHELEPANU JA LOOGIKA; MIDA LAPS TEEB?; Märgi sobiv vari. 5; Märgi sobiv vari. 1; Märgi sobiv vari. 2; Märgi sobiv vari. 3; Märgi sobiv vari. 4; AITA UURIJAT; MÄRGI JÄLJED, MIDA DETEKTIIV UURIB.; KAS KAUSIS ON KOLM KOMMI?; ...; ARVUTA, MITU ON; MÕISTATUSED; VALI ÕIGE VASTUS 1; VALI ÕIGE VASTUS 2

## VEEKOGUD JA VEESÕIDUKID
URL: https://www.opiq.ee/kit/538/chapter/29815
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.67
Topics ET: matemaatika, veekogud, veesõidukid, kogud, tean, kogusid, kuula, märgi, õige, pilt
Topics RU: математика
Topics EN: mathematics
Headings: VEEKOGUD JA VEESÕIDUKID; VEE•KOGUD; MA TEAN VEE•KOGUSID; KUULA JA MÄRGI ÕIGE PILT 3; KUULA JA MÄRGI ÕIGE PILT 1; KUULA JA MÄRGI ÕIGE PILT 2; VEE•SÕIDUKID; MA TEAN VEE•SÕIDUKEID; KUULA JA MÄRGI ÕIGE PILT 6; KUULA JA MÄRGI ÕIGE PILT 4; KUULA JA MÄRGI ÕIGE PILT 5; KUULA JA LAULA KAASA!; VEE•SÕIDUKID JA VEE•KOGUD; MILLISEL VEEKOGUL SAAVAD NEED VEESÕIDUKID SÕITA? (2); MILLISEL VEEKOGUL SAAVAD NEED VEESÕIDUKID SÕITA? (1); VEELOOMAD; EESTI VEELOOMAD; järjesta; MINU VÄIKE KALLIS PLANEET

## VESI
URL: https://www.opiq.ee/kit/538/chapter/31664
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.68
Topics ET: matemaatika, vesi, veeohutus, veekogu, elusolendid, märgi, vajab, vett, õiged, pildid, joogivesi, toit
Topics RU: математика, вода, безопасность на воде, водоём
Topics EN: mathematics, water, water safety, body of water
Headings: VESI; ELUSOLENDID; MÄRGI ELUSOLENDID.; KES VAJAB VETT?; KES VAJAB VETT? MÄRGI ÕIGED PILDID.; JOOGIVESI; toit ja vesi; KUULA VÕI LOE; MUST⋅RÄSTA TARKUS; MINU VÄIKE KALLIS PLANEET

## SUUREM, VÄIKSEM, VÕRDNE. MÄRGID >, <, =
URL: https://www.opiq.ee/kit/538/chapter/31665
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.69
Topics ET: matemaatika, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, võrdne, märgid, uuri, märke, õpin, võrdlema
Topics RU: математика, число, числа, цифры, сравнение, сравни, больше, меньше
Topics EN: mathematics, number, numbers, digits, comparison, compare, greater, less
Headings: SUUREM, VÄIKSEM, VÕRDNE. MÄRGID >, <, =; VÕRDLE JA UURI MÄRKE; MA ÕPIN VÕRDLEMA; KIRJUTA ÕIGED NUMBRID.; VALI ÕIGED NUMBRID JA VÕRDLE. 2; VALI ÕIGED NUMBRID JA VÕRDLE. 1; MA OSKAN VÕRRELDA; VÕRDLE ESEMETA HULKA. VALI ÕIGED ARVUD JA MÄRGID 3; VÕRDLE ESEMETA HULKA. VALI ÕIGED ARVUD JA MÄRGID 1; VÕRDLE ESEMETA HULKA. VALI ÕIGED ARVUD JA MÄRGID 2; VÕRDLE NUMBREID. VALI ÕIGE MÄRK 2; VÕRDLE NUMBREID. VALI ÕIGE MÄRK 1; MA LOENDAN; MÄRGI ÜKSI ESE ROHKEM. MÄRGI JÄRJESTIKKU 2; MÄRGI ÜKSI ESE ROHKEM. MÄRGI JÄRJESTIKKU 1; MÄRGI ÜKSI ESE VÄHEM. MÄRGI JÄRJESTIKKU 2; MÄRGI ÜKSI ESE VÄHEM. MÄRGI JÄRJESTIKKU 1; MA LAHENDAN ÜLESANDEID; KIRJUTA TEHTED. ARVUTA. 2; KIRJUTA TEHTED. ARVUTA. 1; MA LIIDAN JA LAHUTAN; VALI ÕIGED ARVUD JA MÄRGID. ARVUTA.

## Буква У у
URL: https://www.opiq.ee/kit/538/chapter/29792
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.7
Topics ET: matemaatika
Topics RU: математика, буква, звук, отметь, буквы, печатаем, букву, напечатай, ищем, место
Topics EN: mathematics
Headings: Буква У у; Звук У; Звук у 4; Звук а 1; Звук а 2; Звук e 3; Отметь все буквы У; Печатаем букву У; Напечатай букву У; Ищем место буквы в слове; Перетащи букву "у" в слова (2); Перетащи букву "у" в слова (1); Перетащи буквы "а" и "у" в слова 2; Перетащи буквы "а" и "у" в слова 1; 3Б; 3А; Учимся читать; Кто что говорит?; Составляем предложение

## Буква Ш, ш
URL: https://www.opiq.ee/kit/538/chapter/31666
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.70
Topics ET: matemaatika
Topics RU: математика, буква, слове, назови, предмет, какая, нажми, нужные, кружки, слоги
Topics EN: mathematics
Headings: Буква Ш, ш; Буква Ш в слове; Назови предмет. Какая по счёту буква Ш? Нажми на нужные кружки. 1; Слоги с буквой Ш; Составь слоги. Запиши их и прочитай. 2; Составь слоги. Запиши их и прочитай. 1; Буква и слово; Отметь в домике буквы, которые есть в данном слове. 2; Отметь в домике буквы, которые есть в данном слове. 1; Слог и слово; Назови предмет. Перетащи в слово нужный слог.2; Назови предмет. Перетащи в слово нужный слог. 1; Собираем и читаем слова; Собери слова. Напиши их и прочитай. 2; Собери слова. Напиши их и прочитай. 1; Собери и прочитай слова посложнее. 2; Собери и прочитай слова посложнее. 1; Читаем предложения; Перетащи предложение к подходящей картинке.

## VIIS
URL: https://www.opiq.ee/kit/538/chapter/31667
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.71
Topics ET: matemaatika, arv, arvud, arvu, numbrid, viis, pildil, mitu, neid, vali, õige, märgi, viies
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: VIIS; ARV 5 (VIIS); MIS ON PILDIL? MITU NEID ON? VALI ÕIGE NUMBER. 2; MIS ON PILDIL? MITU NEID ON? VALI ÕIGE NUMBER. 1; Märgi iga viies viisnurk; MILLEST ARV 5 KOOSNEB?; viis-kolm; 1.1; viis-neli; UURI PILTE. LOHISTA ÕIGED NUMBRID. 2; UURI PILTE. LOHISTA ÕIGED NUMBRID. 1; LOHISTA MAJJA SOBIVAD NUMBRID.; MA OSKAN VÕRRELDA ARVE; VALI ÕIGED ARVUD JA MÄRGID. 3; VALI ÕIGED ARVUD JA MÄRGID. 1; VALI ÕIGED ARVUD JA MÄRGID. 2; MA LAHENDAN ÜLESANDEID; MA ÕPIN ÜLESANDEID LAHENDAMA; MA LIIDAN JA LAHUTAN; MA LIIDAN JA LAHUTAN.; MA TEAN, MILLEST ARV VIIS KOOSNEB; MA TEAN ARVU VIIE KOOSTIST.; VAATA, KUIDAS KIRJUTATAKSE NUMBER VIIT; TRÜKI VIIS V‑TÄHTE; ...

## Читалочка
URL: https://www.opiq.ee/kit/538/chapter/31646
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.72
Topics ET: matemaatika
Topics RU: математика, читалочка, читаем, слова, текст, саши, вовы, киви, перетащи, имена
Topics EN: mathematics
Headings: Читалочка; Читаем слова; Читаем текст; У Иры мо-ло-ко, мас-ло и сыр.; Ал-ла на-шла аст-ры и ли-ли-и.; О-ко-ло Саши ма-шин-ки, ​ша-ри-ки и кук-лы.; У Вовы а-на-нас и киви.; Перетащи имена.

## TÄHT J j
URL: https://www.opiq.ee/kit/538/chapter/31668
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.73
Topics ET: matemaatika, liitmine, liida, summa, kokku, korrutamine, korruta, korrutis, korda, aeg, kell, kalender, kordamine, harjutan, täht, koostame, sõnu, kuula, sõna, pane, tähtedest
Topics RU: математика, сложение, сложи, сумма, умножение, умножь, произведение, время, часы, календарь, повторение, повтори, тренировка
Topics EN: mathematics, addition, add, sum, multiplication, multiply, product, time, clock, calendar, revision, review, practice
Headings: TÄHT J j; KOOSTAME SÕNU; KUULA JA KORDA SÕNA. PANE SEE KOKKU TÄHTEDEST. 2; KUULA JA KORDA SÕNA. PANE SEE KOKKU TÄHTEDEST. 1; KALENDER; LEIA KUUDE NIMED, KUS ESINEB TÄHT J. MÄRGI NEED.; MÕISTAME SÕNA; jOONISTUS; ÕPIME LUGEMA; VAATA, KUIDAS KIRJUTATAKSE J‑TÄHTE

## Буква Й й
URL: https://www.opiq.ee/kit/538/chapter/31669
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.74
Topics ET: matemaatika
Topics RU: математика, буква, слове, отметь, какая, названиях, каких, предметов, есть, нужные
Topics EN: mathematics
Headings: Буква Й й; Буква Й в слове; Отметь, какая по счёт у буква й 2; Отметь, какая по счёт у буква й 1; В названиях каких предметов есть буква "й"? Отметь нужные картинки.; Составляем слоги; Изучи таблицу и составь слоги. Перетащи нужные буквы.; Читаем слова; Перетащи кружок с номером к подходящему шарику.; "Найди пару".

## KUUS
URL: https://www.opiq.ee/kit/538/chapter/31670
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.75
Topics ET: matemaatika, arv, arvud, arvu, numbrid, võrdlemine, võrdle, suurem, väiksem, kuus, kuidas, saadi, kirjuta, puuduv, õpin, arvutama, vali
Topics RU: математика, число, числа, цифры, сравнение, сравни, больше, меньше
Topics EN: mathematics, number, numbers, digits, comparison, compare, greater, less
Headings: KUUS; ARV 6 (KUUS); 1.; 2.; 3.; KUIDAS SAADI ARV 6 (KUUS)?; KIRJUTA PUUDUV NUMBER.; MA ÕPIN ARVUTAMA; VALI ÕIGE ARV.; KIRJUTA PUUDUVAD ARVUD.; MA VÕRDLEN ARVE; VÕRDLE ARVE; MILLEST ARV KUUS KOOSNEB?; ARVUTA.KIRJUTA VASTUS.; MA KOOSTAN ÜLESANNET; KOOSTA JUTT PILDI PÕHJAL. VASTA HIIREKESE KÜSIMUSELE.

## VÄRV, KUJU, SUURUS
URL: https://www.opiq.ee/kit/538/chapter/29793
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.8
Topics ET: matemaatika, geomeetria, kujund, kujundid, sirge, lõik, värv, kuju, suurus
Topics RU: математика, геометрия, фигура, фигуры, прямая, отрезок, какая, следующая, расположи, размеру
Topics EN: mathematics, geometry, shape, shapes, line, segment
Headings: VÄRV, KUJU, SUURUS; KUJU; ...; KUJU, SUURUS VÕI VÄRV?; Какая фигура следующая?; Расположи по размеру (2); Расположи по размеру (1); KUJUNDID; Отметь 2; Отметь 1

## SÜGIS. ENNE JA PÄRAST
URL: https://www.opiq.ee/kit/538/chapter/29794
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: 1k_eesti_keel_esiopetus_tooraamat_avita_est
Chapter ID: 1.9
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, enne, pärast, sügise, helid, sügispilt, sobib
Topics RU: математика, времена года, весна, лето, осень, зима, было, раньше
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: SÜGIS. ENNE JA PÄRAST; ENNE, PÄRAST; Что было раньше? 4; Что было раньше? 1; Что было раньше? 2; Что было раньше? 3; SÜGISE HELID; SÜGISPILT; SÜGIS; MIS SOBIB SÜGISEGA?
