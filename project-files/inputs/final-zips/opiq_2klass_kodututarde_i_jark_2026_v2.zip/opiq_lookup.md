## Kodutütarde I järk (2026) – Opiq
URL: https://www.opiq.ee/Kit/Details/593
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Kodutütarde I järk (2026) – Opiq
URL: https://www.opiq.ee/Kit/Details/593
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 33
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Kodutütarde VI järk – Opiq
URL: https://www.opiq.ee/Kit/Details/357
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 34
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Kodutütarde VI järk – Opiq
URL: https://www.opiq.ee/Kit/Details/357
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 38
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Oskab selgitada, kes on kodu­tütar
URL: https://www.opiq.ee/kit/357/chapter/19747
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.1
Topics ET: matemaatika, oskab, selgitada, kodu, tütar, kodutütred, millega, tegelevad, kodutütarde, tegevused
Topics RU: математика
Topics EN: mathematics
Headings: Oskab selgitada, kes on kodu­tütar; Kes on kodutütred?; Kodutütred; Millega tegelevad kodutütred?; Kodutütarde tegevused; Kodutütarde ja noorkotkaste laager

## Teab kodutütarde tõotust
URL: https://www.opiq.ee/kit/357/chapter/19748
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.2
Topics ET: matemaatika, teab, kodutütarde, tõotust, pühalik, tõotus
Topics RU: математика
Topics EN: mathematics
Headings: Teab kodutütarde tõotust; Kodutütarde pühalik tõotus; Tõotus

## Teab kodutütarde juhtsõna ja tervitust
URL: https://www.opiq.ee/kit/357/chapter/19749
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.3
Topics ET: matemaatika, teab, kodutütarde, juhtsõna, tervitust, tervitus, kodutütre, tervituse, tähendus, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: Teab kodutütarde juhtsõna ja tervitust; Juhtsõna; Kodutütarde tervitus; Kodutütre tervituse tähendus; Kodutütre tervitus; Kuidas tervitust anda?; Tervituse andmine

## Oskab oma sõnadega selgitada kodutütre seaduseid
URL: https://www.opiq.ee/kit/357/chapter/19750
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.4
Topics ET: matemaatika, oskab, sõnadega, selgitada, kodutütre, seaduseid, kodutütarde, seadused
Topics RU: математика
Topics EN: mathematics
Headings: Oskab oma sõnadega selgitada kodutütre seaduseid; Kodutütarde seadused; Kodutütre seadused

## Teab oma rühmajuhti, rühmavanemat, rühma reegleid
URL: https://www.opiq.ee/kit/357/chapter/19751
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.5
Topics ET: matemaatika, teab, rühmajuhti, rühmavanemat, rühma, reegleid, rühmavanem, rühm, reeglid
Topics RU: математика
Topics EN: mathematics
Headings: Teab oma rühmajuhti, rühmavanemat, rühma reegleid; Rühmavanem; Minu rühm; Rühma reeglid

## Oskab nimetada vormi­elemente ja kandmise põhimõtteid
URL: https://www.opiq.ee/kit/357/chapter/19752
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.6
Topics ET: matemaatika, oskab, nimetada, vormi, elemente, kandmise, põhimõtteid, kodutütarde, pidulik, vorm
Topics RU: математика
Topics EN: mathematics
Headings: Oskab nimetada vormi­elemente ja kandmise põhimõtteid; Kodutütarde pidulik vorm; Kodutütre pidulik vorm; Kodutütre vormi kandmine; Vormi kandmine

## Oskab kirjeldada mütsimärki
URL: https://www.opiq.ee/kit/357/chapter/19753
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.7
Topics ET: matemaatika, oskab, kirjeldada, mütsimärki, mütsimärk, kotkamärgi, elemendid, kotkamärk, mütsimärgi, kandmine
Topics RU: математика
Topics EN: mathematics
Headings: Oskab kirjeldada mütsimärki; Mütsimärk; Kotkamärgi elemendid; Kotkamärk; Mütsimärgi kandmine

## Teab, mis on Kaitseliit
URL: https://www.opiq.ee/kit/357/chapter/19755
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.8
Topics ET: matemaatika, teab, kaitseliit, kaitseliidu, allorganisatsioonid
Topics RU: математика
Topics EN: mathematics
Headings: Teab, mis on Kaitseliit; Kaitseliit; Kaitseliidu allorganisatsioonid

## Teab rivikäsklusi ning oskab nende järgi liikuda
URL: https://www.opiq.ee/kit/593/chapter/33595
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 1.9
Topics ET: matemaatika, teab, rivikäsklusi, ning, oskab, nende, järgi, liikuda, riviõpe, harjuta
Topics RU: математика
Topics EN: mathematics
Headings: Teab rivikäsklusi ning oskab nende järgi liikuda; Riviõpe; Riviõpe 1; Riviõpe 2; Harjuta!; Viirg ja kolonn; Viirg ja kolonn 1; Viirg ja kolonn 2

## Teab, mis on matkamine
URL: https://www.opiq.ee/kit/357/chapter/28710
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 2.1
Topics ET: matemaatika, teab, matkamine, kõige, tähtsam, matkamise, juures, matkavarustus
Topics RU: математика
Topics EN: mathematics
Headings: Teab, mis on matkamine; Matkamine; Kõige tähtsam matkamise juures; Matkavarustus

## Oskab teha kingapaela­sõlme
URL: https://www.opiq.ee/kit/593/chapter/33599
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 2.2
Topics ET: matemaatika, oskab, teha, kingapaela, sõlme, kingapaelasõlm, arutle, harjuta, kingapaelasõlme, sidumist
Topics RU: математика
Topics EN: mathematics
Headings: Oskab teha kingapaela­sõlme; Kingapaelasõlm; Arutle!; Harjuta kingapaelasõlme sidumist!; Lisa!

## Osaleb koos juhendajaga rahulikus tempos matkal
URL: https://www.opiq.ee/kit/593/chapter/33597
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 2.3
Topics ET: matemaatika, osaleb, koos, juhendajaga, rahulikus, tempos, matkal, matkamine, matkavarustus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Osaleb koos juhendajaga rahulikus tempos matkal; Matkamine; Matkavarustus; Arutle sõbraga!; Lisa!

## On osalenud laagris
URL: https://www.opiq.ee/kit/593/chapter/33598
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 2.4
Topics ET: matemaatika, osalenud, laagris, kodutütarde, laagrid, korra, hoidmine, oluline, teada, hügieen
Topics RU: математика
Topics EN: mathematics
Headings: On osalenud laagris; Kodutütarde laagrid; Korra hoidmine laagris; Oluline on teada!; Hügieen; Sinu hügieenikombed; Hügieenitarbed

## Teab hädaabinumbrit
URL: https://www.opiq.ee/kit/357/chapter/19756
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 3.1
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, hädaabinumbrit, helistamine, häirekeskusesse, häirekeskuse, hädaabi
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab hädaabinumbrit; Helistamine häirekeskusesse – 112; Häirekeskuse number; Hädaabi number

## Teab looduslikke ohte
URL: https://www.opiq.ee/kit/357/chapter/19757
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 3.2
Topics ET: loodusõpetus, teab, looduslikke, ohte, looduslikud, ohud, looduslik, looduslikest, ohtudest, hoidumine
Topics RU: природоведение
Topics EN: science
Headings: Teab looduslikke ohte; Looduslikud ohud; Looduslik oht; Looduslikest ohtudest hoidumine

## Oskab selgitada ohutu käitumise reegleid veekogu ääres
URL: https://www.opiq.ee/kit/357/chapter/19758
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 3.3
Topics ET: matemaatika, vesi, veeohutus, veekogu, oskab, selgitada, ohutu, käitumise, reegleid, ääres, ohutus
Topics RU: математика, вода, безопасность на воде, водоём
Topics EN: mathematics, water, water safety, body of water
Headings: Oskab selgitada ohutu käitumise reegleid veekogu ääres; Ohutus veekogu ääres

## Oskab nimetada olulisemaid liiklusreegleid
URL: https://www.opiq.ee/kit/357/chapter/19759
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 3.4
Topics ET: matemaatika, oskab, nimetada, olulisemaid, liiklusreegleid, liiklusreeglid, ohutuse, luuletus, liiklusmärgid, valgusfoor
Topics RU: математика
Topics EN: mathematics
Headings: Oskab nimetada olulisemaid liiklusreegleid; Liiklusreeglid; Ohutuse luuletus; Liiklusmärgid; Valgusfoor

## Oskab hoida puhtust ja korda
URL: https://www.opiq.ee/kit/357/chapter/19760
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 3.5
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, oskab, hoida, puhtust, puhtus, kord, kodus, kodu, korrashoid
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Oskab hoida puhtust ja korda; Puhtus ja kord kodus; Kodu korrashoid; Puhtus ja kord laagris; Korra hoidmine laagris

## Teab oma kodu­aadressi ja vanema kontakt­andmeid
URL: https://www.opiq.ee/kit/593/chapter/33605
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 3.6
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, kodu, aadressi, vanema, kontakt, andmeid, aadress, kodutütre, telefoninumbri
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab oma kodu­aadressi ja vanema kontakt­andmeid; Minu kodu aadress; Kodutütre aadress; Minu aadress; Vanema telefoninumbri teadmine; Õpi number selgeks!

## Tunneb kodukoha loodust
URL: https://www.opiq.ee/kit/357/chapter/19761
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 4.1
Topics ET: loodusõpetus, loodus, keskkond, tunneb, kodukoha, loodust, sinu, kodu, ümbruses, jalutuskäik, kodukohas
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Tunneb kodukoha loodust; Loodus sinu kodu ümbruses; Loodus minu kodu ümbruses; Jalutuskäik kodukohas; Loodus sinu kooli ümbruses; Loodus minu kooli ümbruses

## Oskab nimetada aastaajalisi muutusi looduses
URL: https://www.opiq.ee/kit/357/chapter/28709
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 4.2
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, oskab, nimetada, aastaajalisi, muutusi, looduses, praegune, aastaaeg
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Oskab nimetada aastaajalisi muutusi looduses; Aastaajad; Praegune aastaaeg

## Tunneb Eesti lippu
URL: https://www.opiq.ee/kit/593/chapter/33608
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 4.3
Topics ET: matemaatika, tunneb, eesti, lippu, vabariigi, lipp, lipuvärvid, valge, sinine, must
Topics RU: математика
Topics EN: mathematics
Headings: Tunneb Eesti lippu; Eesti Vabariigi lipp; Eesti lipuvärvid; Eesti lipp; VALGE; SININE; MUST; Lipuvärvi tähendused

## Laulab koos kaaslastega Eesti Vaba­riigi hümni
URL: https://www.opiq.ee/kit/593/chapter/33609
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 4.4
Topics ET: matemaatika, laulab, koos, kaaslastega, eesti, vaba, riigi, hümni, hümn, meeles
Topics RU: математика
Topics EN: mathematics
Headings: Laulab koos kaaslastega Eesti Vaba­riigi hümni; Eesti hümn; Pea meeles!; Eesti Vabariigi hümn; Lisaks!

## Nimetab Eesti Vabariigi presidendi
URL: https://www.opiq.ee/kit/593/chapter/33610
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 4.5
Topics ET: matemaatika, nimetab, eesti, vabariigi, presidendi, president
Topics RU: математика
Topics EN: mathematics
Headings: Nimetab Eesti Vabariigi presidendi; Eesti Vabariigi president; Eesti president

## On osalenud riiklike tähtpäevade tähistamisel
URL: https://www.opiq.ee/kit/593/chapter/33611
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 4.6
Topics ET: matemaatika, osalenud, riiklike, tähtpäevade, tähistamisel, riiklikud, tähtpäevad, riikliku, tähtpäeva, tähistamine
Topics RU: математика
Topics EN: mathematics
Headings: On osalenud riiklike tähtpäevade tähistamisel; Riiklikud tähtpäevad; Riikliku tähtpäeva tähistamine

## Teab oma kodu aadressi
URL: https://www.opiq.ee/kit/357/chapter/19764
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 5.1
Topics ET: matemaatika, teab, kodu, aadressi, aadress, kodutütre
Topics RU: математика
Topics EN: mathematics
Headings: Teab oma kodu aadressi; Minu kodu aadress; Kodutütre aadress; Minu aadress

## Teab Eesti Vabariigi vappi ja lippu
URL: https://www.opiq.ee/kit/357/chapter/19762
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 5.2
Topics ET: matemaatika, teab, eesti, vabariigi, vappi, lippu, vapp, suur, väike, riigivapp
Topics RU: математика
Topics EN: mathematics
Headings: Teab Eesti Vabariigi vappi ja lippu; Eesti Vabariigi vapp; Suur ja väike riigivapp; Suure riigivapi elemendid; Eesti Vabariigi lipp; Eesti lipuvärvid; Eesti lipp

## Oskab laulda Eesti Vabariigi hümni
URL: https://www.opiq.ee/kit/357/chapter/19754
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 5.3
Topics ET: matemaatika, oskab, laulda, eesti, vabariigi, hümni, hümn, soovitused
Topics RU: математика
Topics EN: mathematics
Headings: Oskab laulda Eesti Vabariigi hümni; Eesti hümn; Eesti Vabariigi hümn; Soovitused

## Teab Eesti rahvus­sümboleid
URL: https://www.opiq.ee/kit/357/chapter/19765
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 5.4
Topics ET: matemaatika, teab, eesti, rahvus, sümboleid, rahvussümbolid, millised, pildil, rahvussümbol
Topics RU: математика
Topics EN: mathematics
Headings: Teab Eesti rahvus­sümboleid; Eesti rahvussümbolid; Millised rahvussümbolid on pildil?; Rahvussümbol

## Oskab nimetada Eesti Vabariigi presidenti
URL: https://www.opiq.ee/kit/357/chapter/19763
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 5.5
Topics ET: matemaatika, oskab, nimetada, eesti, vabariigi, presidenti, president
Topics RU: математика
Topics EN: mathematics
Headings: Oskab nimetada Eesti Vabariigi presidenti; Eesti Vabariigi president; Eesti president

## Oskab tervitada ja pöörduda inimeste poole
URL: https://www.opiq.ee/kit/357/chapter/19766
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 6.1
Topics ET: matemaatika, oskab, tervitada, pöörduda, inimeste, poole, tervitamine, viisakusreeglid, pöördumine, vestluse
Topics RU: математика
Topics EN: mathematics
Headings: Oskab tervitada ja pöörduda inimeste poole; Tervitamine; Viisakusreeglid; Inimeste poole pöördumine; Vestluse alustamine

## On meisterdanud pisiasja
URL: https://www.opiq.ee/kit/357/chapter/19767
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 6.2
Topics ET: matemaatika, meisterdanud, pisiasja, meisterdamine, meisterdus
Topics RU: математика
Topics EN: mathematics
Headings: On meisterdanud pisiasja; Meisterdamine; Minu meisterdus

## Lisamaterjal rühmavanemale
URL: https://www.opiq.ee/kit/357/chapter/22538
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 7.1
Topics ET: matemaatika, lisamaterjal, rühmavanemale
Topics RU: математика
Topics EN: mathematics
Headings: Lisamaterjal rühmavanemale

## Lisamaterjal rühmavanemale
URL: https://www.opiq.ee/kit/593/chapter/33617
Book: Kodutütarde I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_kodutütard_2_et
Chapter ID: 8.1
Topics ET: matemaatika, lisamaterjal, rühmavanemale
Topics RU: математика
Topics EN: mathematics
Headings: Lisamaterjal rühmavanemale

## Koduõpe – Opiq
URL: https://www.opiq.ee/Kit/Details/231
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 68
Topics ET: matemaatika, koduõpe, opiq
Topics RU: математика
Topics EN: mathematics

## Koduõpe – Opiq
URL: https://www.opiq.ee/Kit/Details/231
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 96
Topics ET: matemaatika, koduõpe, opiq
Topics RU: математика
Topics EN: mathematics

## Koduõppe korraldus
URL: https://www.opiq.ee/kit/231/chapter/13171
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 1.1
Topics ET: matemaatika, koduõppe, korraldus, koroonaviirus, õpilastega, arutlemiseks, tunniplaan, õpilane, tunni, ettevalmistamine
Topics RU: математика
Topics EN: mathematics
Headings: Koduõppe korraldus; Mis on koroonaviirus?; Õpilastega arutlemiseks; Tunniplaan; Õpilane; Õpetaja; Tunni ettevalmistamine; Tunni käik; Ideed; Olge terved!

## Организация домашнего обучения
URL: https://www.opiq.ee/kit/231/chapter/13172
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, организация, домашнего, обучения, расписание, учитель, ученик, подготовка, уроку, урока
Topics EN: mathematics
Headings: Организация домашнего обучения; Расписание; Учитель; Ученик; Подготовка к уроку; Ход урока; Идеи; Берегите себя!

## 1. klass. Eesti keel
URL: https://www.opiq.ee/kit/231/chapter/13173
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 2.1
Topics ET: matemaatika, klass, eesti, keel, soovitused, õppesisu
Topics RU: математика
Topics EN: mathematics
Headings: 1. klass. Eesti keel; Soovitused; Õppesisu

## 2. klass. Loodus- ja inimeseõpetus
URL: https://www.opiq.ee/kit/231/chapter/13174
Book: Koduõpe 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, loodus, keskkond, taim, taimed, puu, lill, klass, inimeseõpetus, näidistund, rohttaimed, opiqus, üheaastased, kordamisülesanded
Topics RU: природоведение, природа, окружающая среда, растение, растения, дерево, цветок
Topics EN: science, nature, environment, plant, plants, tree, flower
Headings: 2. klass. Loodus- ja inimeseõpetus; Näidistund. Rohttaimed, Opiqus ptk 2.22; 1. Rohttaimed, 15 min; 2. Üheaastased taimed, 12 min; 3. Kordamisülesanded, 18 min; Koduse uurimuse soovitus; Ideid I kooliastme kodustesse loodusõpetuse tundidesse

## Природоведение для 2 класса
URL: https://www.opiq.ee/kit/231/chapter/13175
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 2.3
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, taim, taimed, puu, lill
Topics RU: математика, природа, природоведение, окружающая среда, растение, растения, дерево, цветок, класса, травянистые, однолетние, домашнее, рекомендации, идеи
Topics EN: mathematics, nature, science, environment, plant, plants, tree, flower
Headings: Природоведение для 2 класса; 1. Травянистые растения, 20 мин; 2. Однолетние растения, 15 мин; 3. Домашнее задание, 10 мин; Рекомендации и идеи домашнего обучения

## 3. klass. Matemaatika
URL: https://www.opiq.ee/kit/231/chapter/13176
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 2.4
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, geomeetria, kujund, kujundid, sirge, lõik, klass, sissejuhatav, veerand, kolmveerand, murd, suur
Topics RU: математика, деление, раздели, частное, половина, геометрия, фигура, фигуры, прямая, отрезок
Topics EN: mathematics, division, divide, quotient, half, geometry, shape, shapes, line, segment
Headings: 3. klass. Matemaatika; Sissejuhatav ülesanne; Veerand, pool, kolmveerand; Mis on murd?; Kui suur osa koogist?; Kui suur osa?; Mitu jääb alles?; Kuidas lugeda murde?; Osaliselt värvitud kujundid

## Математика для 3 класса
URL: https://www.opiq.ee/kit/231/chapter/13177
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 2.5
Topics ET: matemaatika, jagamine, jaga, jagatis, pool
Topics RU: математика, деление, раздели, частное, половина, класса, вводное, четверть, четверти, такое, дробь
Topics EN: mathematics, division, divide, quotient, half
Headings: Математика для 3 класса; Вводное задание; Четверть, половина, три четверти; Что такое дробь?; Какая часть пирога?; Какая часть?; Сколько осталось?; Как правильно прочитать дробь?; Закрашенные части фигур

## Русский язык для 3 класса
URL: https://www.opiq.ee/kit/231/chapter/13178
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 2.6
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, русский, язык, класса, мобилизующий, этап, введение, знакомство, значениями, врем
Topics EN: mathematics, time, clock, calendar
Headings: Русский язык для 3 класса; Мобилизующий этап; Введение; Знакомство со значениями времён; Работа с текстом правила; Объясняем названия времён; Учимся определять время глагола; Проверь себя!; Заключение и обратная связь

## 4. klass. Matemaatika
URL: https://www.opiq.ee/kit/231/chapter/13181
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 3.1
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, klass, kahekohalise, arvuga, opiq
Topics RU: математика, деление, раздели, частное, половина
Topics EN: mathematics, division, divide, quotient, half
Headings: 4. klass. Matemaatika; Jagamine kahekohalise arvuga, Opiq, ptk 9.1

## Математика для 4 класса
URL: https://www.opiq.ee/kit/231/chapter/13182
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 3.2
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, arv, arvud, arvu, numbrid, opiq
Topics RU: математика, деление, раздели, частное, половина, число, числа, цифры, класса, двузначное, параграф
Topics EN: mathematics, division, divide, quotient, half, number, numbers, digits
Headings: Математика для 4 класса; Деление на двузначное число, параграф 9.1 в Opiq

## 5. klass. Eesti keel
URL: https://www.opiq.ee/kit/231/chapter/13179
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 3.3
Topics ET: matemaatika, klass, eesti, keel, sissejuhatus, õppetüki, läbitöötamine, harjutamine
Topics RU: математика
Topics EN: mathematics
Headings: 5. klass. Eesti keel; Sissejuhatus; Õppetüki läbitöötamine; Harjutamine

## 6. klass. Ajalugu
URL: https://www.opiq.ee/kit/231/chapter/13183
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 3.4
Topics ET: matemaatika, klass, ajalugu, sissejuhatavad, kordamisküsimused, minutit, küsimused, kuidas, octavianusest, jumalik
Topics RU: математика
Topics EN: mathematics
Headings: 6. klass. Ajalugu; 1. Sissejuhatavad kordamisküsimused (5 minutit); Sissejuhatavad küsimused; 2. Kuidas Octavianusest sai jumalik keiser Augustus? (12 minutit); 3. Mille poolest erines Rooma keisririik vabariigist? (12 minutit); 3. Mis on Rooma õigus? (7 minutit); 4. Rooma riik oma vägevuse tipul (7 minutit); Kodune ülesanne

## История для 6 класса
URL: https://www.opiq.ee/kit/231/chapter/13184
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, история, класса, введение, тему, октавиан, стал, священным, императором, августом
Topics EN: mathematics
Headings: История для 6 класса; 1. Введение в тему (5 мин); 2. Как Октавиан стал священным императором Августом? (12 мин); 3. Чем государственное устройство в Римской империи отличалось от республиканского? (12 мин); 3. Что такое Римское право? (7 мин); 4. Римская империя на вершине могущества (7 мин); Домашнее задание

## 6. klass. Kirjandus
URL: https://www.opiq.ee/kit/231/chapter/13180
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 3.6
Topics ET: matemaatika, klass, kirjandus, neli, näidistundi, tund, lugemislubadus, kuidas, kodus, õpin
Topics RU: математика
Topics EN: mathematics
Headings: 6. klass. Kirjandus; Neli näidistundi; 1. tund; Lugemislubadus; 2. tund; Kuidas ma kodus õpin?; 3. tund; 4. tund; Lugemissoovitus; Veel; Vestelge!; Arutlege!; Tehke midagi muud!; Koostage ise õppevara!

## 7. klass. Bioloogia
URL: https://www.opiq.ee/kit/231/chapter/13188
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, klass, bioloogia, miks, sissejuhatus, materjali, omandamine, katseta, uuri
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: 7. klass. Bioloogia; Ptk 3.5. Miks on hea, kui keha on soe; Sissejuhatus; Uue materjali omandamine; Katseta või uuri; Tagasiside

## 9. klass. Füüsika
URL: https://www.opiq.ee/kit/231/chapter/13194
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.10
Topics ET: matemaatika, klass, füüsika
Topics RU: математика
Topics EN: mathematics
Headings: 9. klass. Füüsika

## Физика для 9 класса
URL: https://www.opiq.ee/kit/231/chapter/13195
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика, физика, класса
Topics EN: mathematics
Headings: Физика для 9 класса

## 9. klass. Keemia
URL: https://www.opiq.ee/kit/231/chapter/13196
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.12
Topics ET: matemaatika, klass, keemia, toit, energiaallikas, teema, õppimine, kinnistamine, rakendamine, kodutöö
Topics RU: математика
Topics EN: mathematics
Headings: 9. klass. Keemia; Toit kui energiaallikas; Uue teema õppimine (u 25 min); Teema kinnistamine ja rakendamine (u 20 min); Kodutöö/lisaülesanne

## Химия для 9 класса
URL: https://www.opiq.ee/kit/231/chapter/13197
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.13
Topics ET: matemaatika
Topics RU: математика, химия, класса, пища, источник, энергии, изучение, новой, темы, примерно
Topics EN: mathematics
Headings: Химия для 9 класса; Пища как источник энергии; Изучение новой темы (примерно 25 мин); Закрепление и применение изученного (примерно 20 мин); Домашнее/дополнительное задание

## Биология для 7 класса
URL: https://www.opiq.ee/kit/231/chapter/13189
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, биология, класса, введение, изучение, нового, материала, исследуй, обратная, связь
Topics EN: mathematics
Headings: Биология для 7 класса; Введение; Изучение нового материала; Исследуй!; Обратная связь

## 8. klass. Ühiskonnaõpetus
URL: https://www.opiq.ee/kit/231/chapter/13190
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.3
Topics ET: matemaatika, klass, ühiskonnaõpetus, näidistund, eesti, välispoliitika, ühiskonnast, üldisemalt
Topics RU: математика
Topics EN: mathematics
Headings: 8. klass. Ühiskonnaõpetus; Näidistund. Ptk 9.2, „Eesti välispoliitika“; Ühiskonnast üldisemalt

## Обществоведение для 8 класса
URL: https://www.opiq.ee/kit/231/chapter/13191
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, обществоведение, класса, внешняя, политика, эстонии, образец, урока
Topics EN: mathematics
Headings: Обществоведение для 8 класса; § 9.2 Внешняя политика Эстонии. Образец урока

## 9. klass. Geograafia
URL: https://www.opiq.ee/kit/231/chapter/13192
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.5
Topics ET: matemaatika, klass, geograafia, distantsõpe, geograafias, näidispeatüki, alusel, iseseisev, tunnitöö, opiqus
Topics RU: математика
Topics EN: mathematics
Headings: 9. klass. Geograafia; Distantsõpe geograafias näidispeatüki alusel; Iseseisev tunnitöö Opiqus; Ideid geograafia distantsõppe mitmekesistamiseks; Kuidas alternatiivseid töid ja ülesandeid õpilastele Opiqus edastada?

## География для 9 класса
URL: https://www.opiq.ee/kit/231/chapter/13193
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.6
Topics ET: matemaatika, opiq
Topics RU: математика, география, класса, самостоятельная, работа, идеи, проведения, дистанционного, обучения
Topics EN: mathematics
Headings: География для 9 класса; Самостоятельная работа в Opiq; Идеи проведения дистанционного обучения; Как передать альтернативные работы и задания ученикам в Opiq?

## 9. klass. Muusika
URL: https://www.opiq.ee/kit/231/chapter/13185
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.7
Topics ET: matemaatika, klass, muusika, näidistund, soovitused, iseseisvaks, tööks
Topics RU: математика
Topics EN: mathematics
Headings: 9. klass. Muusika; Näidistund. Soovitused iseseisvaks tööks; Näidistund; Soovitused iseseisvaks tööks

## Matemaatika 7.–9. klass
URL: https://www.opiq.ee/kit/231/chapter/13186
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.8
Topics ET: matemaatika, klass, metoodilisi, näpunäiteid, tund, trapetsi, pindala, vasta, trapets
Topics RU: математика
Topics EN: mathematics
Headings: Matemaatika 7.–9. klass; Metoodilisi näpunäiteid; 4. tund Trapetsi pindala; VASTA; 1. tund Trapets; Märka; 2. tund Trapetsi nurgad ja küljed; 3. tund Trapetsi pindala; Hüprbooli kujutamine sirgete kaudu; Õpetajale; Tunni kirjeldus; Silinder meie küljes

## Математика для 7–9 класса
URL: https://www.opiq.ee/kit/231/chapter/13187
Book: Koduõpe 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Kaitseliit
Book ID: kaitseliit_koduõpe_2_et
Chapter ID: 4.9
Topics ET: matemaatika
Topics RU: математика, класса, методические, рекомендации, изображение, гиперболы, помощи, прямых, план
Topics EN: mathematics
Headings: Математика для 7–9 класса; Методические рекомендации; Изображение гиперболы при помощи прямых; План урока; Учителю; Цилиндр у нас на голове

## Noorte Kotkaste I järk (2026) – Opiq
URL: https://www.opiq.ee/Kit/Details/594
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 39
Topics ET: matemaatika, noorte, kotkaste, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Noorte Kotkaste I järk (2026) – Opiq
URL: https://www.opiq.ee/Kit/Details/594
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 67
Topics ET: matemaatika, noorte, kotkaste, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Nimetab noorkotkaste piduliku esindusvormi elemente ja kandmise põhimõtteid
URL: https://www.opiq.ee/kit/594/chapter/33620
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.1
Topics ET: matemaatika, nimetab, noorkotkaste, piduliku, esindusvormi, elemente, kandmise, põhimõtteid, noorkotka, pidulik
Topics RU: математика
Topics EN: mathematics
Headings: Nimetab noorkotkaste piduliku esindusvormi elemente ja kandmise põhimõtteid; Noorkotka pidulik vorm; Noorkotka vormielemendid; Pidulik vorm; Piduliku vormi kandmine; Pea meeles!; Pidulik vorm 3; Pidulik vorm 1; Pidulik vorm 2; Kuidas peaks noorkotkas käituma?; Soovitused

## Teab, kes on tema rühma­pealik ja oskab temaga kontaktee­ruda
URL: https://www.opiq.ee/kit/594/chapter/33621
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.2
Topics ET: matemaatika, teab, tema, rühma, pealik, oskab, temaga, kontaktee, ruda, sinu
Topics RU: математика
Topics EN: mathematics
Headings: Teab, kes on tema rühma­pealik ja oskab temaga kontaktee­ruda; Kes on sinu rühmapealik?; Minu rühm; Noortejuht; Rühmapealikuga kontakteeru­mine; Hea idee!; Pea meeles!; Telefonikõne rühmapealikuga; Lisa! Kokkulepped rühmas

## Selgitab, kes on noor­kotkas
URL: https://www.opiq.ee/kit/594/chapter/33622
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.3
Topics ET: matemaatika, selgitab, noor, kotkas, noored, kotkad, millega, tegelevad, noorkotkad, noorte
Topics RU: математика
Topics EN: mathematics
Headings: Selgitab, kes on noor­kotkas; Noored Kotkad; Millega tegelevad noorkotkad?; Noorte Kotkaste tegevus; Noorte Kotkaste laager; Noorkotkaste tegevused

## Selgitab ea­kohaselt, mis on Kaitse­liit ning teab, kes kuuluvad Kaitseliitu
URL: https://www.opiq.ee/kit/594/chapter/33623
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.4
Topics ET: matemaatika, selgitab, kohaselt, kaitse, liit, ning, teab, kuuluvad, kaitseliitu, kaitseliit
Topics RU: математика
Topics EN: mathematics
Headings: Selgitab ea­kohaselt, mis on Kaitse­liit ning teab, kes kuuluvad Kaitseliitu; Mis on Kaitseliit?; Kaitseliit; Kes kuuluvad Kaitseliitu?; Uuri lisaks!; Kaitseliidu allüksused

## Ütleb peast noor­kotkaste tõotuse ja arutleb selle tähenduse üle
URL: https://www.opiq.ee/kit/594/chapter/33624
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.5
Topics ET: matemaatika, ütleb, peast, noor, kotkaste, tõotuse, arutleb, selle, tähenduse, noorkotkaste
Topics RU: математика
Topics EN: mathematics
Headings: Ütleb peast noor­kotkaste tõotuse ja arutleb selle tähenduse üle; Noorkotkaste pühalik tõotus; Tõotus 1; Tõotus 2; Tõotuse tähendus; Tõotuse tähendus 1; Tõotuse tähendus 2

## Tunneb noor­kotkaste kombeid
URL: https://www.opiq.ee/kit/594/chapter/33625
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.6
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, tunneb, noor, kotkaste, kombeid, noorkotkaste, kombed, noorkotka
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Tunneb noor­kotkaste kombeid; Noorkotkaste kombed; Noorkotka kombed; Noorkotkaste kombed korda!

## Kirjeldab Noorte Kotkaste sümboolikat
URL: https://www.opiq.ee/kit/594/chapter/33626
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.7
Topics ET: matemaatika, kirjeldab, noorte, kotkaste, sümboolikat, kotkamärk, kotkamärgi, elemendid, elementide, tähendused
Topics RU: математика
Topics EN: mathematics
Headings: Kirjeldab Noorte Kotkaste sümboolikat; Kotkamärk; Kotkamärgi elemendid; Kotkamärgi elementide tähendused; Noorte Kotkaste lipp

## Teab noor­kotkaste tervitust ja selgitab selle tähendust
URL: https://www.opiq.ee/kit/594/chapter/33627
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.8
Topics ET: matemaatika, teab, noor, kotkaste, tervitust, selgitab, selle, tähendust, noorkotkaste, tervitus
Topics RU: математика
Topics EN: mathematics
Headings: Teab noor­kotkaste tervitust ja selgitab selle tähendust; Noorkotkaste tervitus; Noorkotka tervituse tähendus; Tervituse kasutamine; Noorkotka tervitus; Kuidas tervitust anda?; Juhtlause

## Teab rivi­käsklusi ning oskab nende järgi liikuda
URL: https://www.opiq.ee/kit/594/chapter/33628
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 1.9
Topics ET: matemaatika, teab, rivi, käsklusi, ning, oskab, nende, järgi, liikuda, riviõpe
Topics RU: математика
Topics EN: mathematics
Headings: Teab rivi­käsklusi ning oskab nende järgi liikuda; Riviõpe; Riviõpe 1; Riviõpe 2; Harjuta!; Viirg ja kolonn; Viirg ja kolonn 1; Viirg ja kolonn 2

## Teab, mis on matka­mine
URL: https://www.opiq.ee/kit/594/chapter/33629
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 2.1
Topics ET: matemaatika, teab, matka, mine, matkamine, matkaliigid, ööbimisvõimalused, matkal, metsas, lisaks
Topics RU: математика
Topics EN: mathematics
Headings: Teab, mis on matka­mine; Matkamine; Matkaliigid; Ööbimisvõimalused matkal; Ööbimisvõimalused metsas; Lisaks!

## Oskab teha kingapaela­sõlme
URL: https://www.opiq.ee/kit/594/chapter/33633
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 2.2
Topics ET: matemaatika, oskab, teha, kingapaela, sõlme, kingapaelasõlm, arutle, harjuta, kingapaelasõlme, sidumist
Topics RU: математика
Topics EN: mathematics
Headings: Oskab teha kingapaela­sõlme; Kingapaelasõlm; Arutle!; Harjuta kingapaelasõlme sidumist!; Lisa!

## Osaleb koos juhendajaga rahulikus tempos matkal
URL: https://www.opiq.ee/kit/594/chapter/33630
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 2.3
Topics ET: matemaatika, osaleb, koos, juhendajaga, rahulikus, tempos, matkal, matkamine, matkavarustus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Osaleb koos juhendajaga rahulikus tempos matkal; Matkamine; Matkavarustus; Arutle sõbraga!; Lisa!

## On osalenud laagris
URL: https://www.opiq.ee/kit/594/chapter/33631
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 2.4
Topics ET: matemaatika, osalenud, laagris, noorte, kotkaste, laagrid, korra, hoidmine, oluline, teada
Topics RU: математика
Topics EN: mathematics
Headings: On osalenud laagris; Noorte Kotkaste laagrid; Korra hoidmine laagris; Oluline on teada!; Hügieen; Sinu hügieenikombed; Hügieenitarbed

## Tunneb ära ja nimetab kolm erinevat puud, põõsast, rohttaime, looma ning seent
URL: https://www.opiq.ee/kit/594/chapter/33632
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 2.5
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, taim, taimed, puu, lill, loom, loomad, linnud, putukad, tunneb, nimetab, kolm, erinevat, puud, põõsast, rohttaime, looma, ning, seent
Topics RU: математика, природа, природоведение, окружающая среда, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: mathematics, nature, science, environment, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Tunneb ära ja nimetab kolm erinevat puud, põõsast, rohttaime, looma ning seent; Loodus sinu ümber; Loodus minu kodu ümbruses; Jalutuskäik kodukohas; Tuntumad taimed; Puud ja põõsad; Rohttaimed; Söödavad seened; Tuntumad loomad; Levinumad linnud; Linnud; Soovitused

## Teab häire­keskuse numbrit ja oskab edastada hädaabi­kutset
URL: https://www.opiq.ee/kit/594/chapter/33634
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 3.1
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, häire, keskuse, numbrit, oskab, edastada, hädaabi, kutset, helistamine
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab häire­keskuse numbrit ja oskab edastada hädaabi­kutset; Helistamine häirekeskusesse – 112; Häirekeskuse number on 112.; Pea meeles!; Hädaabi number; Helistamine häirekeskusesse; Häirekeskuse number; Õnnetuse hindamine; Esmaabi andmine; Hea teada!

## Oskab anda esmaabi pisi­haavade ja ninavere­jooksu korral
URL: https://www.opiq.ee/kit/594/chapter/33635
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 3.2
Topics ET: matemaatika, oskab, anda, esmaabi, pisi, haavade, ninavere, jooksu, korral, pisihaavad
Topics RU: математика
Topics EN: mathematics
Headings: Oskab anda esmaabi pisi­haavade ja ninavere­jooksu korral; Pisihaavad; Esmaabi pisihaava korral; Esmased sidumisvõtted; Ninaverejooks; Esmaabi ninaverejooksu korral

## Oskab käituda linna­ruumis ja avalikes kohtades
URL: https://www.opiq.ee/kit/594/chapter/33636
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 3.3
Topics ET: matemaatika, oskab, käituda, linna, ruumis, avalikes, kohtades, liiklusreeglid, ohutuse, luuletus
Topics RU: математика
Topics EN: mathematics
Headings: Oskab käituda linna­ruumis ja avalikes kohtades; Liiklusreeglid; Ohutuse luuletus; Liiklusmärgid; Valgusfoor; Liiklusohutusnõuded ja reeglid; Liiklejad; Pea meeles!; Käitumine linnas eksimise korral; PLANEERI; SEISATA; TUTVU; ORIENTEERU; Hea teada!; Lisaks!

## Järgib looduses viibides turvalise käitumise põhi­mõtteid
URL: https://www.opiq.ee/kit/594/chapter/33637
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 3.4
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, järgib, looduses, viibides, turvalise, käitumise, põhi, mõtteid, mida, teha
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Järgib looduses viibides turvalise käitumise põhi­mõtteid; Mida teha, kui oled eksinud?; Hoia sooja!; Jää paigale!; Ole kuuldav ja nähtav!; Metsas eksimisel; Metsas eksimise korral 1; Metsas eksimise korral 2; Metsas eksimise korral 3; Ohutus veekogu ääres; Pea meeles!; Ohutult lõkke süütamine; Ohutus lõkke tegemisel; Looduslikud ohud; Looduslik oht; Looduslikest ohtudest hoidumine

## Teab, kuidas käituda tule­kahju korral
URL: https://www.opiq.ee/kit/594/chapter/33638
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 3.5
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, kuidas, käituda, tule, kahju, korral, tulekahju, tekkimine, uuri
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab, kuidas käituda tule­kahju korral; Tulekahju tekkimine; Uuri lisaks!; Tulekahju tekkepõhjused; Käitumine tulekahju korral; Häirekeskuse number; Pea meeles!; Hoonest ei saa väljuda; Lisaks!

## Teab oma kodu­aadressi ja vanema kontakt­andmeid
URL: https://www.opiq.ee/kit/594/chapter/33639
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 3.6
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, kodu, aadressi, vanema, kontakt, andmeid, aadress, noorkotka, telefoninumbri
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab oma kodu­aadressi ja vanema kontakt­andmeid; Minu kodu aadress; Noorkotka aadress; Minu aadress; Vanema telefoninumbri teadmine; Õpi number selgeks!

## Tunneb Eesti Vabariigi sümboleid (vapp ja rahvus­sümbolid)
URL: https://www.opiq.ee/kit/594/chapter/33640
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 4.1
Topics ET: matemaatika, tunneb, eesti, vabariigi, sümboleid, vapp, rahvus, sümbolid, suur, väike
Topics RU: математика
Topics EN: mathematics
Headings: Tunneb Eesti Vabariigi sümboleid (vapp ja rahvus­sümbolid); Eesti Vabariigi vapp; Suur ja väike riigivapp; Suure riigivapi elemendid; Eesti rahvussümbolid; Millised rahvussümbolid on pildil?; Rahvussümbol

## Teab, millal on Eesti ise­seisvus­päev
URL: https://www.opiq.ee/kit/594/chapter/33641
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 4.2
Topics ET: matemaatika, teab, millal, eesti, seisvus, päev, vabariigi, aastapäev, tegevused, aastapäeval
Topics RU: математика
Topics EN: mathematics
Headings: Teab, millal on Eesti ise­seisvus­päev; Eesti Vabariigi aastapäev; Tegevused Eesti Vabariigi aastapäeval

## Tunneb Eesti lippu
URL: https://www.opiq.ee/kit/594/chapter/33642
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 4.3
Topics ET: matemaatika, tunneb, eesti, lippu, vabariigi, lipp, lipuvärvid, valge, sinine, must
Topics RU: математика
Topics EN: mathematics
Headings: Tunneb Eesti lippu; Eesti Vabariigi lipp; Eesti lipuvärvid; Eesti lipp; VALGE; SININE; MUST; Lipuvärvi tähendused

## Laulab koos kaaslastega Eesti Vaba­riigi hümni
URL: https://www.opiq.ee/kit/594/chapter/33643
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 4.4
Topics ET: matemaatika, laulab, koos, kaaslastega, eesti, vaba, riigi, hümni, hümn, meeles
Topics RU: математика
Topics EN: mathematics
Headings: Laulab koos kaaslastega Eesti Vaba­riigi hümni; Eesti hümn; Pea meeles!; Eesti Vabariigi hümn; Lisaks!

## Nimetab Eesti Vabariigi presidendi
URL: https://www.opiq.ee/kit/594/chapter/33644
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 4.5
Topics ET: matemaatika, nimetab, eesti, vabariigi, presidendi, president
Topics RU: математика
Topics EN: mathematics
Headings: Nimetab Eesti Vabariigi presidendi; Eesti Vabariigi president; Eesti president

## On osalenud riiklike tähtpäevade tähistamisel
URL: https://www.opiq.ee/kit/594/chapter/33645
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 4.6
Topics ET: matemaatika, osalenud, riiklike, tähtpäevade, tähistamisel, riiklikud, tähtpäevad, riikliku, tähtpäeva, tähistamine
Topics RU: математика
Topics EN: mathematics
Headings: On osalenud riiklike tähtpäevade tähistamisel; Riiklikud tähtpäevad; Riikliku tähtpäeva tähistamine

## Tuleb vähemalt kolmele välja­õppeüritusele jala või osaleb rühmas kolmel kehalist aktiivsust nõudval tegevusel
URL: https://www.opiq.ee/kit/594/chapter/33646
Book: Noorte Kotkaste I järk (2026) 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kaitseliit_noorte_kot_2_et
Chapter ID: 5.1
Topics ET: matemaatika, tuleb, vähemalt, kolmele, välja, õppeüritusele, jala, osaleb, rühmas, kolmel, kehalist, aktiivsust, nõudval, tegevusel
Topics RU: математика
Topics EN: mathematics
Headings: Tuleb vähemalt kolmele välja­õppeüritusele jala või osaleb rühmas kolmel kehalist aktiivsust nõudval tegevusel; Liikumine on oluline; Liikumis­harjumus; Liikumine Noorte Kotkaste üritusele; Head ideed noortejuhile!; Pea meeles!

## Kodutütarde I järk (2026) – Opiq
URL: https://www.opiq.ee/Kit/Details/593
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 123
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Kodutütarde I järk (2026) – Opiq
URL: https://www.opiq.ee/Kit/Details/593
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 155
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Nimetab kodutütarde piduliku esindus­vormi elemente ja kandmise põhi­mõtteid
URL: https://www.opiq.ee/kit/593/chapter/33587
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.1
Topics ET: matemaatika, nimetab, kodutütarde, piduliku, esindus, vormi, elemente, kandmise, põhi, mõtteid
Topics RU: математика
Topics EN: mathematics
Headings: Nimetab kodutütarde piduliku esindus­vormi elemente ja kandmise põhi­mõtteid; Kodutütarde pidulik vorm; Vormielemendid 1; Vormielemendid 2; Kodutütre pidulik vorm; Kodutütre vormi kandmine; Vormi kandmine 3; Vormi kandmine 1; Vormi kandmine 2; Vormielemendid; Hea teada!; Lisaks!

## Teab, kes on tema rühma­vanem ja oskab temaga kontaktee­ruda
URL: https://www.opiq.ee/kit/593/chapter/33588
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.2
Topics ET: matemaatika, teab, tema, rühma, vanem, oskab, temaga, kontaktee, ruda, rühmavanem
Topics RU: математика
Topics EN: mathematics
Headings: Teab, kes on tema rühma­vanem ja oskab temaga kontaktee­ruda; Rühmavanem; Minu rühm; Noortejuht; Rühma­vanemaga kontakteeru­mine; Hea idee!; Pea meeles!; Telefonikõne rühmavanemaga; Lisa!

## Selgitab, kes on kodu­tütar
URL: https://www.opiq.ee/kit/593/chapter/33589
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.3
Topics ET: matemaatika, selgitab, kodu, tütar, kodutütred, millega, tegelevad, kodutütarde, tegevused, noorkotkaste
Topics RU: математика
Topics EN: mathematics
Headings: Selgitab, kes on kodu­tütar; Kes on kodutütred?; Kodutütred; Millega tegelevad kodutütred?; Kodutütarde tegevused; Kodutütarde ja noorkotkaste laager; Vaata lisaks!

## Selgitab ea­kohaselt, mis on Kaitse­liit ning teab, kes kuuluvad Kaitseliitu
URL: https://www.opiq.ee/kit/593/chapter/33590
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.4
Topics ET: matemaatika, selgitab, kohaselt, kaitse, liit, ning, teab, kuuluvad, kaitseliitu, kaitseliit
Topics RU: математика
Topics EN: mathematics
Headings: Selgitab ea­kohaselt, mis on Kaitse­liit ning teab, kes kuuluvad Kaitseliitu; Mis on Kaitseliit?; Kaitseliit; Kes kuuluvad Kaitseliitu?; Uuri lisaks!; Kaitseliidu allüksused

## Ütleb peast kodu­tütarde tõotuse ja arutleb selle tähenduse üle
URL: https://www.opiq.ee/kit/593/chapter/33591
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.5
Topics ET: matemaatika, ütleb, peast, kodu, tütarde, tõotuse, arutleb, selle, tähenduse, kodutütarde
Topics RU: математика
Topics EN: mathematics
Headings: Ütleb peast kodu­tütarde tõotuse ja arutleb selle tähenduse üle; Kodutütarde pühalik tõotus; Tõotus; Tõotuse tähendus; Tõotuse tähendus 1; Tõotuse tähendus 2

## Tunneb kodu­tütarde seadusi
URL: https://www.opiq.ee/kit/593/chapter/33592
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.6
Topics ET: matemaatika, tunneb, kodu, tütarde, seadusi, kodutütarde, seadused, kodutütre
Topics RU: математика
Topics EN: mathematics
Headings: Tunneb kodu­tütarde seadusi; Kodutütarde seadused; Kodutütre seadused

## Kirjeldab Kodu­tütarde sümboolikat
URL: https://www.opiq.ee/kit/593/chapter/33593
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.7
Topics ET: matemaatika, kirjeldab, kodu, tütarde, sümboolikat, kotkamärk, kotkamärgi, elemendid, elementide, tähendused
Topics RU: математика
Topics EN: mathematics
Headings: Kirjeldab Kodu­tütarde sümboolikat; Kotkamärk; Kotkamärgi elemendid; Kotkamärgi elementide tähendused; Ristikuleht; Ristikulehe kasutamine; Ristikumärk; Kodutütarde lipp; Lisa! Kotkamärk vormi­elemendina; Mütsimärgi kandmine

## Teab kodu­tütarde tervitust ja selgitab selle tähendust
URL: https://www.opiq.ee/kit/593/chapter/33594
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.8
Topics ET: matemaatika, teab, kodu, tütarde, tervitust, selgitab, selle, tähendust, kodutütarde, tervitus
Topics RU: математика
Topics EN: mathematics
Headings: Teab kodu­tütarde tervitust ja selgitab selle tähendust; Kodutütarde tervitus; Kodutütre tervituse tähendus; Tervituse kasutamine; Kodutütre tervitus; Kuidas tervitust anda?; Tervituse andmine; Juhtsõna

## Teab rivikäsklusi ning oskab nende järgi liikuda
URL: https://www.opiq.ee/kit/593/chapter/33595
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 1.9
Topics ET: matemaatika, teab, rivikäsklusi, ning, oskab, nende, järgi, liikuda, riviõpe, harjuta
Topics RU: математика
Topics EN: mathematics
Headings: Teab rivikäsklusi ning oskab nende järgi liikuda; Riviõpe; Riviõpe 1; Riviõpe 2; Harjuta!; Viirg ja kolonn; Viirg ja kolonn 1; Viirg ja kolonn 2

## Teab, mis on matka­mine
URL: https://www.opiq.ee/kit/593/chapter/33596
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 2.1
Topics ET: matemaatika, teab, matka, mine, matkamine, matkaliigid, ööbimisvõimalused, matkal, metsas, lisaks
Topics RU: математика
Topics EN: mathematics
Headings: Teab, mis on matka­mine; Matkamine; Matkaliigid; Ööbimisvõimalused matkal; Ööbimisvõimalused metsas; Lisaks!

## Oskab teha kingapaela­sõlme
URL: https://www.opiq.ee/kit/593/chapter/33599
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 2.2
Topics ET: matemaatika, oskab, teha, kingapaela, sõlme, kingapaelasõlm, arutle, harjuta, kingapaelasõlme, sidumist
Topics RU: математика
Topics EN: mathematics
Headings: Oskab teha kingapaela­sõlme; Kingapaelasõlm; Arutle!; Harjuta kingapaelasõlme sidumist!; Lisa!

## Osaleb koos juhendajaga rahulikus tempos matkal
URL: https://www.opiq.ee/kit/593/chapter/33597
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 2.3
Topics ET: matemaatika, osaleb, koos, juhendajaga, rahulikus, tempos, matkal, matkamine, matkavarustus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Osaleb koos juhendajaga rahulikus tempos matkal; Matkamine; Matkavarustus; Arutle sõbraga!; Lisa!

## On osalenud laagris
URL: https://www.opiq.ee/kit/593/chapter/33598
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 2.4
Topics ET: matemaatika, osalenud, laagris, kodutütarde, laagrid, korra, hoidmine, oluline, teada, hügieen
Topics RU: математика
Topics EN: mathematics
Headings: On osalenud laagris; Kodutütarde laagrid; Korra hoidmine laagris; Oluline on teada!; Hügieen; Sinu hügieenikombed; Hügieenitarbed

## Teab häire­keskuse numbrit ja oskab edastada hädaabi­kutset
URL: https://www.opiq.ee/kit/593/chapter/33600
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 3.1
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, häire, keskuse, numbrit, oskab, edastada, hädaabi, kutset, helistamine
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab häire­keskuse numbrit ja oskab edastada hädaabi­kutset; Helistamine häirekeskusesse – 112; Häirekeskuse number on 112.; Pea meeles!; Hädaabi number; Helistamine häirekeskusesse; Häirekeskuse number; Õnnetuse hindamine; Esmaabi andmine; Hea teada!

## Oskab anda esmaabi pisi­haavade ja ninavere­jooksu korral
URL: https://www.opiq.ee/kit/593/chapter/33601
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 3.2
Topics ET: matemaatika, oskab, anda, esmaabi, pisi, haavade, ninavere, jooksu, korral, pisihaavad
Topics RU: математика
Topics EN: mathematics
Headings: Oskab anda esmaabi pisi­haavade ja ninavere­jooksu korral; Pisihaavad; Esmaabi pisihaava korral; Esmased sidumisvõtted; Ninaverejooks; Esmaabi ninaverejooksu korral

## Oskab käituda linna­ruumis ja avalikes kohtades
URL: https://www.opiq.ee/kit/593/chapter/33602
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 3.3
Topics ET: matemaatika, oskab, käituda, linna, ruumis, avalikes, kohtades, liiklusreeglid, ohutuse, luuletus
Topics RU: математика
Topics EN: mathematics
Headings: Oskab käituda linna­ruumis ja avalikes kohtades; Liiklusreeglid; Ohutuse luuletus; Liiklusmärgid; Valgusfoor; Liiklusohutusnõuded ja reeglid; Liiklejad; Pea meeles!; Käitumine linnas eksimise korral; PLANEERI; SEISATA; TUTVU; ORIENTEERU; Hea teada!; Lisaks!

## Järgib looduses viibides turvalise käitumise põhi­mõtteid
URL: https://www.opiq.ee/kit/593/chapter/33603
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 3.4
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, järgib, looduses, viibides, turvalise, käitumise, põhi, mõtteid, mida, teha
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Järgib looduses viibides turvalise käitumise põhi­mõtteid; Mida teha, kui oled eksinud?; Hoia sooja!; Jää paigale!; Ole kuuldav ja nähtav!; Metsas eksimisel; Metsas eksimise korral 1; Metsas eksimise korral 2; Metsas eksimise korral 3; Ohutus veekogu ääres; Pea meeles!; Ohutult lõkke süütamine; Ohutus lõkke tegemisel; Looduslikud ohud; Looduslik oht; Looduslikest ohtudest hoidumine

## Teab, kuidas käituda tule­kahju korral
URL: https://www.opiq.ee/kit/593/chapter/33604
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 3.5
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, kuidas, käituda, tule, kahju, korral, tulekahju, tekkimine, uuri
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab, kuidas käituda tule­kahju korral; Tulekahju tekkimine; Uuri lisaks!; Tulekahju tekkepõhjused; Käitumine tulekahju korral; Häirekeskuse number; Pea meeles!; Hoonest ei saa väljuda; Lisaks!

## Teab oma kodu­aadressi ja vanema kontakt­andmeid
URL: https://www.opiq.ee/kit/593/chapter/33605
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 3.6
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, kodu, aadressi, vanema, kontakt, andmeid, aadress, kodutütre, telefoninumbri
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab oma kodu­aadressi ja vanema kontakt­andmeid; Minu kodu aadress; Kodutütre aadress; Minu aadress; Vanema telefoninumbri teadmine; Õpi number selgeks!

## Tunneb Eesti Vabariigi sümboleid (vapp ja rahvus­sümbolid)
URL: https://www.opiq.ee/kit/593/chapter/33606
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 4.1
Topics ET: matemaatika, tunneb, eesti, vabariigi, sümboleid, vapp, rahvus, sümbolid, suur, väike
Topics RU: математика
Topics EN: mathematics
Headings: Tunneb Eesti Vabariigi sümboleid (vapp ja rahvus­sümbolid); Eesti Vabariigi vapp; Suur ja väike riigivapp; Suure riigivapi elemendid; Eesti rahvussümbolid; Millised rahvussümbolid on pildil?; Rahvussümbol

## Teab, millal on Eesti ise­seisvus­päev
URL: https://www.opiq.ee/kit/593/chapter/33607
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 4.2
Topics ET: matemaatika, teab, millal, eesti, seisvus, päev, vabariigi, aastapäev, tegevused, aastapäeval
Topics RU: математика
Topics EN: mathematics
Headings: Teab, millal on Eesti ise­seisvus­päev; Eesti Vabariigi aastapäev; Tegevused Eesti Vabariigi aastapäeval

## Tunneb Eesti lippu
URL: https://www.opiq.ee/kit/593/chapter/33608
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 4.3
Topics ET: matemaatika, tunneb, eesti, lippu, vabariigi, lipp, lipuvärvid, valge, sinine, must
Topics RU: математика
Topics EN: mathematics
Headings: Tunneb Eesti lippu; Eesti Vabariigi lipp; Eesti lipuvärvid; Eesti lipp; VALGE; SININE; MUST; Lipuvärvi tähendused

## Laulab koos kaaslastega Eesti Vaba­riigi hümni
URL: https://www.opiq.ee/kit/593/chapter/33609
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 4.4
Topics ET: matemaatika, laulab, koos, kaaslastega, eesti, vaba, riigi, hümni, hümn, meeles
Topics RU: математика
Topics EN: mathematics
Headings: Laulab koos kaaslastega Eesti Vaba­riigi hümni; Eesti hümn; Pea meeles!; Eesti Vabariigi hümn; Lisaks!

## Nimetab Eesti Vabariigi presidendi
URL: https://www.opiq.ee/kit/593/chapter/33610
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 4.5
Topics ET: matemaatika, nimetab, eesti, vabariigi, presidendi, president
Topics RU: математика
Topics EN: mathematics
Headings: Nimetab Eesti Vabariigi presidendi; Eesti Vabariigi president; Eesti president

## On osalenud riiklike tähtpäevade tähistamisel
URL: https://www.opiq.ee/kit/593/chapter/33611
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 4.6
Topics ET: matemaatika, osalenud, riiklike, tähtpäevade, tähistamisel, riiklikud, tähtpäevad, riikliku, tähtpäeva, tähistamine
Topics RU: математика
Topics EN: mathematics
Headings: On osalenud riiklike tähtpäevade tähistamisel; Riiklikud tähtpäevad; Riikliku tähtpäeva tähistamine

## Tunneb ära ja nimetab kolm erinevat puud, põõsast, rohttaime, looma ning seent
URL: https://www.opiq.ee/kit/593/chapter/33612
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 5.1
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, taim, taimed, puu, lill, loom, loomad, linnud, putukad, tunneb, nimetab, kolm, erinevat, puud, põõsast, rohttaime, looma, ning, seent
Topics RU: математика, природа, природоведение, окружающая среда, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: mathematics, nature, science, environment, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Tunneb ära ja nimetab kolm erinevat puud, põõsast, rohttaime, looma ning seent; Loodus sinu ümber; Loodus minu kodu ümbruses; Jalutuskäik kodukohas; Tuntumad taimed; Puud ja põõsad; Rohttaimed; Söödavad seened; Tuntumad loomad; Levinumad linnud; Linnud; Soovitused

## Tunneb ära viis paiga­lindu oma kodukohas
URL: https://www.opiq.ee/kit/593/chapter/33613
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 5.2
Topics ET: matemaatika, loom, loomad, linnud, putukad, tunneb, viis, paiga, lindu, kodukohas, eesti, paigalinnud, paigalindude
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Tunneb ära viis paiga­lindu oma kodukohas; Eesti linnud; Paigalinnud; Paigalindude toitmine talvel; Hea teada!; Lindude toitmine talvel; Lisaks!

## Käitub kodutütrele sobivalt
URL: https://www.opiq.ee/kit/593/chapter/33614
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 6.1
Topics ET: matemaatika, käitub, kodutütrele, sobivalt, vormikandmine, vormi, elemendid, meeles, järk, kodutütarde
Topics RU: математика
Topics EN: mathematics
Headings: Käitub kodutütrele sobivalt; Vormikandmine; Vormi­elemendid; Pea meeles!; I järk; Kodutütarde seadused igapäeva­elus; Kodutütarde seadused minu iga­päevaselus

## Esitab loovalt Kodutütarde seadusi
URL: https://www.opiq.ee/kit/593/chapter/33615
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 6.2
Topics ET: matemaatika, esitab, loovalt, kodutütarde, seadusi, seadused
Topics RU: математика
Topics EN: mathematics
Headings: Esitab loovalt Kodutütarde seadusi; Kodutütarde seadused

## Tuleb vähemalt kolmele välja­õppeüritusele jala või osaleb rühmas kolmel kehalist aktiivsust nõudval tegevusel
URL: https://www.opiq.ee/kit/593/chapter/33616
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 7.1
Topics ET: matemaatika, tuleb, vähemalt, kolmele, välja, õppeüritusele, jala, osaleb, rühmas, kolmel, kehalist, aktiivsust, nõudval, tegevusel
Topics RU: математика
Topics EN: mathematics
Headings: Tuleb vähemalt kolmele välja­õppeüritusele jala või osaleb rühmas kolmel kehalist aktiivsust nõudval tegevusel; Liikumine on oluline; Liikumis­harjumus; Liikumine Kodutütarde üritusele; Head ideed noortejuhile!; Pea meeles!

## Lisamaterjal rühmavanemale
URL: https://www.opiq.ee/kit/593/chapter/33617
Book: Kodutütarde I järk (2026) – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_i_järk_(2026)
Chapter ID: 8.1
Topics ET: matemaatika, lisamaterjal, rühmavanemale
Topics RU: математика
Topics EN: mathematics
Headings: Lisamaterjal rühmavanemale

## Kodutütarde VI järk – Opiq
URL: https://www.opiq.ee/Kit/Details/357
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 97
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Kodutütarde VI järk – Opiq
URL: https://www.opiq.ee/Kit/Details/357
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 122
Topics ET: matemaatika, kodutütarde, järk, opiq
Topics RU: математика
Topics EN: mathematics

## Oskab selgitada, kes on kodu­tütar
URL: https://www.opiq.ee/kit/357/chapter/19747
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.1
Topics ET: matemaatika, oskab, selgitada, kodu, tütar, kodutütred, millega, tegelevad, kodutütarde, tegevused
Topics RU: математика
Topics EN: mathematics
Headings: Oskab selgitada, kes on kodu­tütar; Kes on kodutütred?; Kodutütred; Millega tegelevad kodutütred?; Kodutütarde tegevused; Kodutütarde ja noorkotkaste laager

## Teab kodutütarde tõotust
URL: https://www.opiq.ee/kit/357/chapter/19748
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.2
Topics ET: matemaatika, teab, kodutütarde, tõotust, pühalik, tõotus
Topics RU: математика
Topics EN: mathematics
Headings: Teab kodutütarde tõotust; Kodutütarde pühalik tõotus; Tõotus

## Teab kodutütarde juhtsõna ja tervitust
URL: https://www.opiq.ee/kit/357/chapter/19749
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.3
Topics ET: matemaatika, teab, kodutütarde, juhtsõna, tervitust, tervitus, kodutütre, tervituse, tähendus, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: Teab kodutütarde juhtsõna ja tervitust; Juhtsõna; Kodutütarde tervitus; Kodutütre tervituse tähendus; Kodutütre tervitus; Kuidas tervitust anda?; Tervituse andmine

## Oskab oma sõnadega selgitada kodutütre seaduseid
URL: https://www.opiq.ee/kit/357/chapter/19750
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.4
Topics ET: matemaatika, oskab, sõnadega, selgitada, kodutütre, seaduseid, kodutütarde, seadused
Topics RU: математика
Topics EN: mathematics
Headings: Oskab oma sõnadega selgitada kodutütre seaduseid; Kodutütarde seadused; Kodutütre seadused

## Teab oma rühmajuhti, rühmavanemat, rühma reegleid
URL: https://www.opiq.ee/kit/357/chapter/19751
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.5
Topics ET: matemaatika, teab, rühmajuhti, rühmavanemat, rühma, reegleid, rühmavanem, rühm, reeglid
Topics RU: математика
Topics EN: mathematics
Headings: Teab oma rühmajuhti, rühmavanemat, rühma reegleid; Rühmavanem; Minu rühm; Rühma reeglid

## Oskab nimetada vormi­elemente ja kandmise põhimõtteid
URL: https://www.opiq.ee/kit/357/chapter/19752
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.6
Topics ET: matemaatika, oskab, nimetada, vormi, elemente, kandmise, põhimõtteid, kodutütarde, pidulik, vorm
Topics RU: математика
Topics EN: mathematics
Headings: Oskab nimetada vormi­elemente ja kandmise põhimõtteid; Kodutütarde pidulik vorm; Kodutütre pidulik vorm; Kodutütre vormi kandmine; Vormi kandmine

## Oskab kirjeldada mütsimärki
URL: https://www.opiq.ee/kit/357/chapter/19753
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.7
Topics ET: matemaatika, oskab, kirjeldada, mütsimärki, mütsimärk, kotkamärgi, elemendid, kotkamärk, mütsimärgi, kandmine
Topics RU: математика
Topics EN: mathematics
Headings: Oskab kirjeldada mütsimärki; Mütsimärk; Kotkamärgi elemendid; Kotkamärk; Mütsimärgi kandmine

## Teab, mis on Kaitseliit
URL: https://www.opiq.ee/kit/357/chapter/19755
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 1.8
Topics ET: matemaatika, teab, kaitseliit, kaitseliidu, allorganisatsioonid
Topics RU: математика
Topics EN: mathematics
Headings: Teab, mis on Kaitseliit; Kaitseliit; Kaitseliidu allorganisatsioonid

## Teab, mis on matkamine
URL: https://www.opiq.ee/kit/357/chapter/28710
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 2.1
Topics ET: matemaatika, teab, matkamine, kõige, tähtsam, matkamise, juures, matkavarustus
Topics RU: математика
Topics EN: mathematics
Headings: Teab, mis on matkamine; Matkamine; Kõige tähtsam matkamise juures; Matkavarustus

## Teab hädaabinumbrit
URL: https://www.opiq.ee/kit/357/chapter/19756
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 3.1
Topics ET: matemaatika, arv, arvud, arvu, numbrid, teab, hädaabinumbrit, helistamine, häirekeskusesse, häirekeskuse, hädaabi
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Teab hädaabinumbrit; Helistamine häirekeskusesse – 112; Häirekeskuse number; Hädaabi number

## Teab looduslikke ohte
URL: https://www.opiq.ee/kit/357/chapter/19757
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 3.2
Topics ET: loodusõpetus, teab, looduslikke, ohte, looduslikud, ohud, looduslik, looduslikest, ohtudest, hoidumine
Topics RU: природоведение
Topics EN: science
Headings: Teab looduslikke ohte; Looduslikud ohud; Looduslik oht; Looduslikest ohtudest hoidumine

## Oskab selgitada ohutu käitumise reegleid veekogu ääres
URL: https://www.opiq.ee/kit/357/chapter/19758
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 3.3
Topics ET: matemaatika, vesi, veeohutus, veekogu, oskab, selgitada, ohutu, käitumise, reegleid, ääres, ohutus
Topics RU: математика, вода, безопасность на воде, водоём
Topics EN: mathematics, water, water safety, body of water
Headings: Oskab selgitada ohutu käitumise reegleid veekogu ääres; Ohutus veekogu ääres

## Oskab nimetada olulisemaid liiklusreegleid
URL: https://www.opiq.ee/kit/357/chapter/19759
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 3.4
Topics ET: matemaatika, oskab, nimetada, olulisemaid, liiklusreegleid, liiklusreeglid, ohutuse, luuletus, liiklusmärgid, valgusfoor
Topics RU: математика
Topics EN: mathematics
Headings: Oskab nimetada olulisemaid liiklusreegleid; Liiklusreeglid; Ohutuse luuletus; Liiklusmärgid; Valgusfoor

## Oskab hoida puhtust ja korda
URL: https://www.opiq.ee/kit/357/chapter/19760
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 3.5
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, oskab, hoida, puhtust, puhtus, kord, kodus, kodu, korrashoid
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Oskab hoida puhtust ja korda; Puhtus ja kord kodus; Kodu korrashoid; Puhtus ja kord laagris; Korra hoidmine laagris

## Tunneb kodukoha loodust
URL: https://www.opiq.ee/kit/357/chapter/19761
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 4.1
Topics ET: loodusõpetus, loodus, keskkond, tunneb, kodukoha, loodust, sinu, kodu, ümbruses, jalutuskäik, kodukohas
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Tunneb kodukoha loodust; Loodus sinu kodu ümbruses; Loodus minu kodu ümbruses; Jalutuskäik kodukohas; Loodus sinu kooli ümbruses; Loodus minu kooli ümbruses

## Oskab nimetada aastaajalisi muutusi looduses
URL: https://www.opiq.ee/kit/357/chapter/28709
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 4.2
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, oskab, nimetada, aastaajalisi, muutusi, looduses, praegune, aastaaeg
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Oskab nimetada aastaajalisi muutusi looduses; Aastaajad; Praegune aastaaeg

## Teab oma kodu aadressi
URL: https://www.opiq.ee/kit/357/chapter/19764
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 5.1
Topics ET: matemaatika, teab, kodu, aadressi, aadress, kodutütre
Topics RU: математика
Topics EN: mathematics
Headings: Teab oma kodu aadressi; Minu kodu aadress; Kodutütre aadress; Minu aadress

## Teab Eesti Vabariigi vappi ja lippu
URL: https://www.opiq.ee/kit/357/chapter/19762
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 5.2
Topics ET: matemaatika, teab, eesti, vabariigi, vappi, lippu, vapp, suur, väike, riigivapp
Topics RU: математика
Topics EN: mathematics
Headings: Teab Eesti Vabariigi vappi ja lippu; Eesti Vabariigi vapp; Suur ja väike riigivapp; Suure riigivapi elemendid; Eesti Vabariigi lipp; Eesti lipuvärvid; Eesti lipp

## Oskab laulda Eesti Vabariigi hümni
URL: https://www.opiq.ee/kit/357/chapter/19754
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 5.3
Topics ET: matemaatika, oskab, laulda, eesti, vabariigi, hümni, hümn, soovitused
Topics RU: математика
Topics EN: mathematics
Headings: Oskab laulda Eesti Vabariigi hümni; Eesti hümn; Eesti Vabariigi hümn; Soovitused

## Teab Eesti rahvus­sümboleid
URL: https://www.opiq.ee/kit/357/chapter/19765
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 5.4
Topics ET: matemaatika, teab, eesti, rahvus, sümboleid, rahvussümbolid, millised, pildil, rahvussümbol
Topics RU: математика
Topics EN: mathematics
Headings: Teab Eesti rahvus­sümboleid; Eesti rahvussümbolid; Millised rahvussümbolid on pildil?; Rahvussümbol

## Oskab nimetada Eesti Vabariigi presidenti
URL: https://www.opiq.ee/kit/357/chapter/19763
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 5.5
Topics ET: matemaatika, oskab, nimetada, eesti, vabariigi, presidenti, president
Topics RU: математика
Topics EN: mathematics
Headings: Oskab nimetada Eesti Vabariigi presidenti; Eesti Vabariigi president; Eesti president

## Oskab tervitada ja pöörduda inimeste poole
URL: https://www.opiq.ee/kit/357/chapter/19766
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 6.1
Topics ET: matemaatika, oskab, tervitada, pöörduda, inimeste, poole, tervitamine, viisakusreeglid, pöördumine, vestluse
Topics RU: математика
Topics EN: mathematics
Headings: Oskab tervitada ja pöörduda inimeste poole; Tervitamine; Viisakusreeglid; Inimeste poole pöördumine; Vestluse alustamine

## On meisterdanud pisiasja
URL: https://www.opiq.ee/kit/357/chapter/19767
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 6.2
Topics ET: matemaatika, meisterdanud, pisiasja, meisterdamine, meisterdus
Topics RU: математика
Topics EN: mathematics
Headings: On meisterdanud pisiasja; Meisterdamine; Minu meisterdus

## Lisamaterjal rühmavanemale
URL: https://www.opiq.ee/kit/357/chapter/22538
Book: Kodutütarde VI järk – Opiq
Class: 2
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Kaitseliit
Book ID: kodutütarde_vi_järk
Chapter ID: 7.1
Topics ET: matemaatika, lisamaterjal, rühmavanemale
Topics RU: математика
Topics EN: mathematics
Headings: Lisamaterjal rühmavanemale
