## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/187
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 1
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/187
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 114
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Kallis sõber!
URL: https://www.opiq.ee/kit/187/chapter/10464
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 1.1
Topics ET: matemaatika, kallis, sõber, koduke
Topics RU: математика
Topics EN: mathematics
Headings: Kallis sõber!; KUS ON MINU KODUKE
Task examples: JOONISTA TÖÖVIHIKUSSE LK 1 ENDA PILT. TÄIDA LÜNGAD.

## Laula, laula, lapsuke
URL: https://www.opiq.ee/kit/187/chapter/10465
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 1.2
Topics ET: matemaatika, laula, lapsuke, lapsukene
Topics RU: математика
Topics EN: mathematics
Headings: Laula, laula, lapsuke; LAULA, LAULA, LAPSUKENE

## Tere
URL: https://www.opiq.ee/kit/187/chapter/10466
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 1.3
Topics ET: matemaatika, tere
Topics RU: математика
Topics EN: mathematics
Headings: Tere

## Sünnipäev
URL: https://www.opiq.ee/kit/187/chapter/10467
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 1.4
Topics ET: matemaatika, sünnipäev, õnnitluslaul, sünnipäevalaul
Topics RU: математика
Topics EN: mathematics
Headings: Sünnipäev; ÕNNITLUSLAUL; SÜNNIPÄEVALAUL
Task examples: VALMISTA SÜNNIPÄEVAKUTSE. TÄIDA LÜNGAD.; KELLELE SOBIVAD NEED KINGITUSED? LOHISTA ÕIGED VASTUSED PILDILE. VÄRVI PILT TÖÖVIHIKUS:

## Jõululaul
URL: https://www.opiq.ee/kit/187/chapter/10505
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.1
Topics ET: matemaatika, jõululaul
Topics RU: математика
Topics EN: mathematics
Headings: Jõululaul

## Jõulutaadi ootel
URL: https://www.opiq.ee/kit/187/chapter/10506
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.2
Topics ET: matemaatika, jõulutaadi, ootel
Topics RU: математика
Topics EN: mathematics
Headings: Jõulutaadi ootel
Task examples: JÄTKA KIRJUTAMIST TÖÖVIHIKUS.

## Kes elab metsa sees
URL: https://www.opiq.ee/kit/187/chapter/10507
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.3
Topics ET: matemaatika, elab, metsa, sees
Topics RU: математика
Topics EN: mathematics
Headings: Kes elab metsa sees
Task examples: LEIA JA KIRJUTA MI-ASTE TÖÖVIHIKUSSE. LAULA.; LAULA ASTMENIMEDEGA JA NÄITA KAASA KÄEMÄRKE. KIRJUTA VIIS NOODIJOONESTIKULE TÖÖVIHIKUS. VÄRVI.

## Päkapikula
URL: https://www.opiq.ee/kit/187/chapter/10508
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.4
Topics ET: matemaatika, päkapikula
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikula
Task examples: LEIA JA KIRJUTA PÄKAPIKKUDELE NIMED TÖÖVIHIKUS. ESITA NIMERÜTMID KEHAPILLIL. VÄRVI.

## Päkapiku jõulud
URL: https://www.opiq.ee/kit/187/chapter/10509
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.5
Topics ET: matemaatika, päkapiku, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: Päkapiku jõulud
Task examples: LEIA SÕNAD, MIS KUULUVAD „MUUSIKAMAA” JUURDE.

## Kingisoov
URL: https://www.opiq.ee/kit/187/chapter/10510
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.6
Topics ET: matemaatika, kingisoov
Topics RU: математика
Topics EN: mathematics
Headings: Kingisoov

## Igal lapsel oma ingel
URL: https://www.opiq.ee/kit/187/chapter/10511
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.7
Topics ET: matemaatika, igal, lapsel, ingel
Topics RU: математика
Topics EN: mathematics
Headings: Igal lapsel oma ingel

## Jõulukellad
URL: https://www.opiq.ee/kit/187/chapter/10512
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.8
Topics ET: matemaatika, jõulukellad
Topics RU: математика
Topics EN: mathematics
Headings: Jõulukellad

## Läbi lume sahiseva
URL: https://www.opiq.ee/kit/187/chapter/10513
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 10.9
Topics ET: matemaatika, läbi, lume, sahiseva, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Läbi lume sahiseva; TÄHESEGADIK
Task examples: ÜHENDA TÖÖVIHIKUS SÕNA ÕIGE RÜTMIGA. ESITA RÜTMID. VÄRVI PILDID.

## Lumepolka
URL: https://www.opiq.ee/kit/187/chapter/10514
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.1
Topics ET: matemaatika, lumepolka
Topics RU: математика
Topics EN: mathematics
Headings: Lumepolka
Task examples: Pane tähestikulõigud õigesse järjekorda. Moodusta tähestik. Esita tähelõike lauldes.

## Lumepallilaul
URL: https://www.opiq.ee/kit/187/chapter/10515
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.2
Topics ET: matemaatika, lumepallilaul
Topics RU: математика
Topics EN: mathematics
Headings: Lumepallilaul
Task examples: Loe ja kirjuta sõnade rütm töövihikus. Esitage rütmiread erinevatel pillidel korraga.

## Lumehelbeke
URL: https://www.opiq.ee/kit/187/chapter/10516
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.3
Topics ET: matemaatika, lumehelbeke
Topics RU: математика
Topics EN: mathematics
Headings: Lumehelbeke
Task examples: Kirjuta töövihikusse pildi juurde sobiv märk. Värvi. Nimeta veel esemeid, mis muudavad hääle tugevust.; Esita luuletus a) valjenedes, b) vaibudes. Itimehel pea on paks, mudib näppe naks ja naks. Arvutil on kukkund kiirus, arvutis vist möllab viirus. Kirjuta luuletuse rütm töövihikusse ja esita see kehapillil.

## Kelgusõit
URL: https://www.opiq.ee/kit/187/chapter/10517
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.4
Topics ET: matemaatika, kelgusõit
Topics RU: математика
Topics EN: mathematics
Headings: Kelgusõit
Task examples: Kirjuta töövihikusse noodid ja noodivarred.

## Uisutamas
URL: https://www.opiq.ee/kit/187/chapter/10518
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.5
Topics ET: matemaatika, uisutamas
Topics RU: математика
Topics EN: mathematics
Headings: Uisutamas
Task examples: Esitage rütm koos pinginaabriga kehapillil või erinevatel pillidel.

## Karumõmmi unelaul
URL: https://www.opiq.ee/kit/187/chapter/10519
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.6
Topics ET: matemaatika, karumõmmi, unelaul
Topics RU: математика
Topics EN: mathematics
Headings: Karumõmmi unelaul

## Mürakarud
URL: https://www.opiq.ee/kit/187/chapter/10520
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.7
Topics ET: matemaatika, mürakarud
Topics RU: математика
Topics EN: mathematics
Headings: Mürakarud
Task examples: Kirjuta rütm töövihikusse. Plaksuta ja loe rütmisilpe kaasa.; Leia ja kirjuta SO-aste töövihikusse. Laula koos käemärkidega.

## Marsilaul
URL: https://www.opiq.ee/kit/187/chapter/10521
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 11.8
Topics ET: matemaatika, marsilaul, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Marsilaul; Tähesegadik
Task examples: Arvuta ja kirjuta vastused töövihikusse.

## Üks, kaks, alati
URL: https://www.opiq.ee/kit/187/chapter/10522
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 12.1
Topics ET: matemaatika, kaks, alati
Topics RU: математика
Topics EN: mathematics
Headings: Üks, kaks, alati
Task examples: Tõmba taktijooned töövihikusse. Esita rütm, ütle rütmisilpe kaasa.; Kirjuta töövihikus pildi rütm taktidesse. Esita rütm. Värvi.

## Dirigent
URL: https://www.opiq.ee/kit/187/chapter/10523
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 12.2
Topics ET: matemaatika, dirigent
Topics RU: математика
Topics EN: mathematics
Headings: Dirigent

## Põdra maja
URL: https://www.opiq.ee/kit/187/chapter/10524
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 13.1
Topics ET: matemaatika, põdra, maja
Topics RU: математика
Topics EN: mathematics
Headings: Põdra maja

## Matkalaul
URL: https://www.opiq.ee/kit/187/chapter/10525
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 13.2
Topics ET: matemaatika, matkalaul
Topics RU: математика
Topics EN: mathematics
Headings: Matkalaul
Task examples: Kirjuta sõnad tagurpidi. Märgi nende rütm töövihikus. Esita.; Jaga rütm taktidesse, kirjuta töövihikus astmed noodijoonestikule. Laula viisi edasi-tagasi.

## Soss-soss-soss
URL: https://www.opiq.ee/kit/187/chapter/10526
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 13.3
Topics ET: matemaatika, soss
Topics RU: математика
Topics EN: mathematics
Headings: Soss-soss-soss
Task examples: Vali ringidest viisilõigud. Kirjuta need noodijoonestikule töövihikus. Esita viisid.

## Kurjad kuked
URL: https://www.opiq.ee/kit/187/chapter/10527
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 13.4
Topics ET: matemaatika, kurjad, kuked
Topics RU: математика
Topics EN: mathematics
Headings: Kurjad kuked
Task examples: Leia ja kirjuta RA-aste töövihikus. Laula koos käemärkidega.; Leia ja kirjuta töövihikus RA-aste. Jaga viisid taktidesse. Laula.

## Salajutt
URL: https://www.opiq.ee/kit/187/chapter/10528
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 13.5
Topics ET: matemaatika, salajutt
Topics RU: математика
Topics EN: mathematics
Headings: Salajutt
Task examples: Kirjuta õpikust lk 88 laul „LIIGUN NII” noodijoonestikule töövihikus. Laula.

## Mu isamaa, mu õnn ja rõõm
URL: https://www.opiq.ee/kit/187/chapter/10529
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 14.1
Topics ET: matemaatika, isamaa, rõõm, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Mu isamaa, mu õnn ja rõõm; Tähesegadik

## Pesapuu
URL: https://www.opiq.ee/kit/187/chapter/10530
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 14.2
Topics ET: matemaatika, pesapuu
Topics RU: математика
Topics EN: mathematics
Headings: Pesapuu
Task examples: Värvi pilt töövihikus. Leia Eestimaa sümbolid. Nimeta need.

## Kallis koht
URL: https://www.opiq.ee/kit/187/chapter/10531
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 14.3
Topics ET: matemaatika, kallis, koht
Topics RU: математика
Topics EN: mathematics
Headings: Kallis koht
Task examples: Lahenda ristsõna. Saad teada laulu „Karumõmmi unelaul” helilooja perekonnanime.

## Vastlalaul
URL: https://www.opiq.ee/kit/187/chapter/10532
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 15.1
Topics ET: matemaatika, vastlalaul
Topics RU: математика
Topics EN: mathematics
Headings: Vastlalaul
Task examples: Kirjuta töövihikusse taktimõõt ja astmenimed. Mõtle viisile sõnad. Esita oma laul.

## Vastlapäeval
URL: https://www.opiq.ee/kit/187/chapter/10533
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 15.2
Topics ET: matemaatika, vastlapäeval
Topics RU: математика
Topics EN: mathematics
Headings: Vastlapäeval
Task examples: Leia luuletuse igale reale õige rütm. Ühenda need joonega töövihikus. Mõtle luuletusele viis, kasutades SO- ja MI-astmeid.

## Elujutt
URL: https://www.opiq.ee/kit/187/chapter/10534
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 16.1
Topics ET: matemaatika, elujutt
Topics RU: математика
Topics EN: mathematics
Headings: Elujutt
Task examples: Tõmba taktijooned töövihikus. Koputa ja ütle rütmisilpe kaasa.; Joonista töövihikusse õpiku lk 97 muinasjutule lõpp. Jutusta.

## Kokkutulek
URL: https://www.opiq.ee/kit/187/chapter/10535
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 16.2
Topics ET: matemaatika, kokkutulek
Topics RU: математика
Topics EN: mathematics
Headings: Kokkutulek

## Nõiamäng
URL: https://www.opiq.ee/kit/187/chapter/10536
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 16.3
Topics ET: matemaatika, nõiamäng
Topics RU: математика
Topics EN: mathematics
Headings: Nõiamäng
Task examples: Leia ja kirjuta luuletuse rütm. Taktis on 3 pulsilööki. Tõmba taktijooned töövihikus. Esita luuletuse rütm kehapillil, rõhutades meetrumit. Karuott on unekott, talvel magab nagu nott, oota suve, siis näed Otti tantsitama

## Tudu, tudu, mu kallis
URL: https://www.opiq.ee/kit/187/chapter/10537
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 16.4
Topics ET: matemaatika, tudu, kallis
Topics RU: математика
Topics EN: mathematics
Headings: Tudu, tudu, mu kallis

## Roosa jänku rokk
URL: https://www.opiq.ee/kit/187/chapter/10538
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 16.5
Topics ET: matemaatika, roosa, jänku, rokk
Topics RU: математика
Topics EN: mathematics
Headings: Roosa jänku rokk
Task examples: Tõmba taktijooned töövihikus. Esita rütm kehapillil.

## Pipi laul
URL: https://www.opiq.ee/kit/187/chapter/10539
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 16.6
Topics ET: matemaatika, pipi, laul
Topics RU: математика
Topics EN: mathematics
Headings: Pipi laul
Task examples: Vali iga tegelase juurde raamatu pealkiri. Värvi pilt töövihikus.

## Meistrimehed
URL: https://www.opiq.ee/kit/187/chapter/10540
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 17.1
Topics ET: matemaatika, meistrimehed
Topics RU: математика
Topics EN: mathematics
Headings: Meistrimehed

## Uhke meremees
URL: https://www.opiq.ee/kit/187/chapter/10541
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 17.2
Topics ET: matemaatika, uhke, meremees
Topics RU: математика
Topics EN: mathematics
Headings: Uhke meremees

## Kevade vihm
URL: https://www.opiq.ee/kit/187/chapter/10542
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 18.1
Topics ET: matemaatika, kevade, vihm, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Kevade vihm; Tähesegadik
Task examples: Leia ja kirjuta JO-aste töövihikus. Laula koos käemärkidega

## Kevade hällilaul
URL: https://www.opiq.ee/kit/187/chapter/10543
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 18.2
Topics ET: matemaatika, kevade, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kevade hällilaul

## Lumelaps, kust tuled?
URL: https://www.opiq.ee/kit/187/chapter/10544
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 18.3
Topics ET: matemaatika, lumelaps, kust, tuled
Topics RU: математика
Topics EN: mathematics
Headings: Lumelaps, kust tuled?
Task examples: Mitu JO-võtit on pildil? Värvi need töövihikus.; Kirjuta JO-aste töövihikus.

## Kevade ootel
URL: https://www.opiq.ee/kit/187/chapter/10545
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 18.4
Topics ET: matemaatika, kevade, ootel
Topics RU: математика
Topics EN: mathematics
Headings: Kevade ootel
Task examples: Tõmba taktijooned töövihikus ja laula. Kirjuta astmed noodijoonestikule.

## Kevadel
URL: https://www.opiq.ee/kit/187/chapter/10546
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 18.5
Topics ET: matemaatika, kevadel
Topics RU: математика
Topics EN: mathematics
Headings: Kevadel
Task examples: Tõmba taktijooned töövihikus. Kirjuta astmenimed ja laula.

## Väike jänku
URL: https://www.opiq.ee/kit/187/chapter/10547
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 18.6
Topics ET: matemaatika, väike, jänku
Topics RU: математика
Topics EN: mathematics
Headings: Väike jänku

## Munade koks
URL: https://www.opiq.ee/kit/187/chapter/10548
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 18.7
Topics ET: matemaatika, munade, koks
Topics RU: математика
Topics EN: mathematics
Headings: Munade koks
Task examples: Kirjuta ise viis ja sõnad töövihikusse. Laula.

## Nädalapäevad
URL: https://www.opiq.ee/kit/187/chapter/10549
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 19.1
Topics ET: matemaatika, nädalapäevad
Topics RU: математика
Topics EN: mathematics
Headings: Nädalapäevad
Task examples: Kirjuta luuletuse viis töövihikus noodijoonestikule. Jaga taktidesse. Esita lauluna. Millisest raamatust on need 7 sõpra?

## Kellakägu
URL: https://www.opiq.ee/kit/187/chapter/10550
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 19.2
Topics ET: matemaatika, kellakägu
Topics RU: математика
Topics EN: mathematics
Headings: Kellakägu
Task examples: Täida taktid töövihikus vastavalt taktimõõdule.

## Valgusfoor
URL: https://www.opiq.ee/kit/187/chapter/10468
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 2.1
Topics ET: matemaatika, valgusfoor, kolm, sõpra
Topics RU: математика
Topics EN: mathematics
Headings: Valgusfoor; KOLM SÕPRA

## Kooliteel
URL: https://www.opiq.ee/kit/187/chapter/10469
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 2.2
Topics ET: matemaatika, kooliteel
Topics RU: математика
Topics EN: mathematics
Headings: Kooliteel
Task examples: VALI IGA LIIKLUSMÄRGI JUURDE TÄHENDUS. VÄRVI LIIKLUSMÄRGID TÖÖVIHIKUS:; KES KÄITUB LIIKLUSES ÕIGESTI? VÄRVI PILT TÖÖVIHIKUS:

## Pärg
URL: https://www.opiq.ee/kit/187/chapter/10551
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 20.1
Topics ET: matemaatika, pärg
Topics RU: математика
Topics EN: mathematics
Headings: Pärg

## Emadepäeva laul
URL: https://www.opiq.ee/kit/187/chapter/10552
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 20.2
Topics ET: matemaatika, emadepäeva, laul
Topics RU: математика
Topics EN: mathematics
Headings: Emadepäeva laul

## Ema pole kodus
URL: https://www.opiq.ee/kit/187/chapter/10553
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 20.3
Topics ET: matemaatika, pole, kodus
Topics RU: математика
Topics EN: mathematics
Headings: Ema pole kodus

## Nuku hällilaul
URL: https://www.opiq.ee/kit/187/chapter/10554
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 20.4
Topics ET: matemaatika, nuku, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Nuku hällilaul
Task examples: Leia paar ja ühenda töövihikus.

## Metsamuusika
URL: https://www.opiq.ee/kit/187/chapter/10555
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 21.1
Topics ET: matemaatika, metsamuusika
Topics RU: математика
Topics EN: mathematics
Headings: Metsamuusika
Task examples: Märgi õiged vastused.

## Kevadeaeg
URL: https://www.opiq.ee/kit/187/chapter/10556
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 21.2
Topics ET: matemaatika, kevadeaeg, kevadaeg
Topics RU: математика
Topics EN: mathematics
Headings: Kevadeaeg; KEVADAEG

## Võilill
URL: https://www.opiq.ee/kit/187/chapter/10557
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 21.3
Topics ET: matemaatika, võilill
Topics RU: математика
Topics EN: mathematics
Headings: Võilill

## Kurg ja konn
URL: https://www.opiq.ee/kit/187/chapter/10558
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 22.1
Topics ET: matemaatika, kurg, konn
Topics RU: математика
Topics EN: mathematics
Headings: Kurg ja konn

## Kaks kalameest
URL: https://www.opiq.ee/kit/187/chapter/10559
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 22.2
Topics ET: matemaatika, kaks, kalameest
Topics RU: математика
Topics EN: mathematics
Headings: Kaks kalameest

## Väike luiskaja
URL: https://www.opiq.ee/kit/187/chapter/10560
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 22.3
Topics ET: matemaatika, väike, luiskaja, katkend
Topics RU: математика
Topics EN: mathematics
Headings: Väike luiskaja; (katkend)

## Liblikas
URL: https://www.opiq.ee/kit/187/chapter/10561
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 22.4
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas
Task examples: Leia ja kirjuta rütm ning astmenimed töövihikus. Laula. Värvi.

## Triinud
URL: https://www.opiq.ee/kit/187/chapter/10562
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 22.5
Topics ET: matemaatika, triinud
Topics RU: математика
Topics EN: mathematics
Headings: Triinud

## Pilvepildid
URL: https://www.opiq.ee/kit/187/chapter/10563
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 22.6
Topics ET: matemaatika, pilvepildid
Topics RU: математика
Topics EN: mathematics
Headings: Pilvepildid
Task examples: Värvi asjad töövihikus, mida Tuut, Pin, Sisi ja Mira vajavad matkal.

## Tervituslaul
URL: https://www.opiq.ee/kit/187/chapter/10564
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.1
Topics ET: matemaatika, tervituslaul
Topics RU: математика
Topics EN: mathematics
Headings: Tervituslaul

## Tädi
URL: https://www.opiq.ee/kit/187/chapter/10573
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.10
Topics ET: matemaatika, tädi
Topics RU: математика
Topics EN: mathematics
Headings: Tädi

## Mängulaul
URL: https://www.opiq.ee/kit/187/chapter/10574
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.11
Topics ET: matemaatika, mängulaul
Topics RU: математика
Topics EN: mathematics
Headings: Mängulaul

## Ti-ti-li-ti-lei
URL: https://www.opiq.ee/kit/187/chapter/10575
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.12
Topics ET: matemaatika, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Ti-ti-li-ti-lei; TI-TI-LIT-TI-LEI; Tähesegadik

## Hea tuju laul
URL: https://www.opiq.ee/kit/187/chapter/10565
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.2
Topics ET: matemaatika, tuju, laul
Topics RU: математика
Topics EN: mathematics
Headings: Hea tuju laul

## Valgusfoori värvid
URL: https://www.opiq.ee/kit/187/chapter/10566
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.3
Topics ET: matemaatika, valgusfoori, värvid
Topics RU: математика
Topics EN: mathematics
Headings: Valgusfoori värvid

## Lapaduu
URL: https://www.opiq.ee/kit/187/chapter/10567
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.4
Topics ET: matemaatika, lapaduu
Topics RU: математика
Topics EN: mathematics
Headings: Lapaduu

## Kes aias?
URL: https://www.opiq.ee/kit/187/chapter/10568
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.5
Topics ET: matemaatika, aias
Topics RU: математика
Topics EN: mathematics
Headings: Kes aias?

## Kükita
URL: https://www.opiq.ee/kit/187/chapter/10569
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.6
Topics ET: matemaatika, kükita
Topics RU: математика
Topics EN: mathematics
Headings: Kükita

## Tantsulaul
URL: https://www.opiq.ee/kit/187/chapter/10570
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.7
Topics ET: matemaatika, tantsulaul
Topics RU: математика
Topics EN: mathematics
Headings: Tantsulaul

## Tantsuhoos
URL: https://www.opiq.ee/kit/187/chapter/10571
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.8
Topics ET: matemaatika, tantsuhoos
Topics RU: математика
Topics EN: mathematics
Headings: Tantsuhoos

## Las plaksutab nüüd iga laps
URL: https://www.opiq.ee/kit/187/chapter/10572
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 23.9
Topics ET: matemaatika, plaksutab, nüüd, laps
Topics RU: математика
Topics EN: mathematics
Headings: Las plaksutab nüüd iga laps

## Meie kiisul kriimud silmad
URL: https://www.opiq.ee/kit/187/chapter/10470
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 3.1
Topics ET: matemaatika, meie, kiisul, kriimud, silmad
Topics RU: математика
Topics EN: mathematics
Headings: Meie kiisul kriimud silmad

## Algab kooliaasta uus
URL: https://www.opiq.ee/kit/187/chapter/10471
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 3.2
Topics ET: matemaatika, algab, kooliaasta
Topics RU: математика
Topics EN: mathematics
Headings: Algab kooliaasta uus

## Kui su nime algustäht on ...
URL: https://www.opiq.ee/kit/187/chapter/10472
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 3.3
Topics ET: matemaatika, nime, algustäht
Topics RU: математика
Topics EN: mathematics
Headings: Kui su nime algustäht on ...; KUI SU NIME ALGUSTÄHT ON …
Task examples: JOONISTA JA VÄRVI TÖÖVIHIKUS NOODID PUNASEKS, TRÜKITÄHED ROHELISEKS, KIRJATÄHED SINISEKS JA TAEVATÄHED KOLLASEKS.

## Küll on tähed
URL: https://www.opiq.ee/kit/187/chapter/10473
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 3.4
Topics ET: matemaatika, küll, tähed
Topics RU: математика
Topics EN: mathematics
Headings: Küll on tähed

## Paha pliiats
URL: https://www.opiq.ee/kit/187/chapter/10474
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 3.5
Topics ET: matemaatika, paha, pliiats
Topics RU: математика
Topics EN: mathematics
Headings: Paha pliiats
Task examples: MOODUSTA SEGAMINI TÄHTEDEST NIMED. VÄRVI PILDID TÖÖVIHIKUS.

## Koer Muki
URL: https://www.opiq.ee/kit/187/chapter/10475
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 3.6
Topics ET: matemaatika, koer, muki
Topics RU: математика
Topics EN: mathematics
Headings: Koer Muki

## Pulss
URL: https://www.opiq.ee/kit/187/chapter/10476
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 4.1
Topics ET: matemaatika, pulss, mängi, hääli, kaasa, leia, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Pulss; MÄNGI JA HÄÄLI KAASA; LEIA PULSS; TÄHESEGADIK

## Poisid, ritta!
URL: https://www.opiq.ee/kit/187/chapter/10477
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 4.2
Topics ET: matemaatika, poisid, ritta
Topics RU: математика
Topics EN: mathematics
Headings: Poisid, ritta!

## Elevandimarss
URL: https://www.opiq.ee/kit/187/chapter/10478
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 4.3
Topics ET: matemaatika, elevandimarss
Topics RU: математика
Topics EN: mathematics
Headings: Elevandimarss

## Sügise laul
URL: https://www.opiq.ee/kit/187/chapter/10479
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.1
Topics ET: matemaatika, sügise, laul
Topics RU: математика
Topics EN: mathematics
Headings: Sügise laul

## Õpetajale
URL: https://www.opiq.ee/kit/187/chapter/10480
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.2
Topics ET: matemaatika, õpetajale
Topics RU: математика
Topics EN: mathematics
Headings: Õpetajale

## Kõlapikkus
URL: https://www.opiq.ee/kit/187/chapter/10481
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.3
Topics ET: matemaatika, kõlapikkus, laula, jookse
Topics RU: математика
Topics EN: mathematics
Headings: Kõlapikkus; LAULA JA JOOKSE
Task examples: KIRJUTA TÖÖVIHIKUSSE NIMED. LOE JA PLAKSUTA NENDE RÜTMI.; JÄTKA NIMEDE KIRJUTAMIST TÖÖVIHIKUS. LOE JA KOPUTA RÜTM.

## Kehapill
URL: https://www.opiq.ee/kit/187/chapter/10482
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.4
Topics ET: matemaatika, kehapill
Topics RU: математика
Topics EN: mathematics
Headings: Kehapill
Task examples: KIRJUTA TÖÖVIHIKUSSE RÜTM JA MÄNGI KEHAPILLI. VÄRVI PILT.

## Mõistata
URL: https://www.opiq.ee/kit/187/chapter/10483
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.5
Topics ET: matemaatika, mõistata
Topics RU: математика
Topics EN: mathematics
Headings: Mõistata
Task examples: RÜTMISTA TÖÖVIHIKUS SÜGISE MÄRGID. KIRJUTA NEID JUURDE.

## Sügis
URL: https://www.opiq.ee/kit/187/chapter/10484
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.6
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Sügis
Task examples: KIRJUTA LAULU „KUS ON MINU KODUKE” RÜTM TÖÖVIHIKUSSE (ÕPIK LK 3).

## Sügis, vahva mees
URL: https://www.opiq.ee/kit/187/chapter/10485
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.7
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, vahva, mees
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Sügis, vahva mees
Task examples: KIRJUTA LUULETUSE RÜTM TÖÖVIHIKUSSE. LOE LUULETUST JA MÄNGI KAASA KEHAPILLIL.

## Minul on vihmamantel
URL: https://www.opiq.ee/kit/187/chapter/10486
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.8
Topics ET: matemaatika, minul, vihmamantel
Topics RU: математика
Topics EN: mathematics
Headings: Minul on vihmamantel

## Seeneralli
URL: https://www.opiq.ee/kit/187/chapter/10487
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 5.9
Topics ET: matemaatika, seeneralli
Topics RU: математика
Topics EN: mathematics
Headings: Seeneralli
Task examples: LEIA LAULUST „SEENERALLI” SEENTE NIMED JA LOHISTA NEED PILDILE. TÖÖVIHIKUS LISA RÜTMID JA VÄRVI PILT.

## Rütmipillid
URL: https://www.opiq.ee/kit/187/chapter/10488
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 6.1
Topics ET: matemaatika, rütmipillid
Topics RU: математика
Topics EN: mathematics
Headings: Rütmipillid

## Pillilaul
URL: https://www.opiq.ee/kit/187/chapter/10489
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 6.2
Topics ET: matemaatika, pillilaul, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Pillilaul; TÄHESEGADIK
Task examples: KIRJUTA TÖÖVIHIKUS IGALE RÜTMILE SOBIV PILLI NIMI.

## Isaga on julgem
URL: https://www.opiq.ee/kit/187/chapter/10490
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.1
Topics ET: matemaatika, isaga, julgem
Topics RU: математика
Topics EN: mathematics
Headings: Isaga on julgem
Task examples: LEIA PILLI NIMI. VÄRVI PILT TÖÖVIHIKUS.

## Riidemäng
URL: https://www.opiq.ee/kit/187/chapter/10499
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.10
Topics ET: matemaatika, riidemäng
Topics RU: математика
Topics EN: mathematics
Headings: Riidemäng
Task examples: NIMETA KLASSIS OLEVAID ASJU. KIRJUTA JA RÜTMISTA NENDE NIMED TÖÖVIHIKUS.

## Padjasõja laul
URL: https://www.opiq.ee/kit/187/chapter/10491
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.2
Topics ET: matemaatika, padjasõja, laul
Topics RU: математика
Topics EN: mathematics
Headings: Padjasõja laul
Task examples: KIRJUTA TÖÖVIHIKUSSE VASTUSE RÜTM JA ESITA KOOS PINGINAABRIGA.

## Kodulaul
URL: https://www.opiq.ee/kit/187/chapter/10492
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.3
Topics ET: matemaatika, kodulaul
Topics RU: математика
Topics EN: mathematics
Headings: Kodulaul

## Paus
URL: https://www.opiq.ee/kit/187/chapter/10493
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.4
Topics ET: matemaatika, paus, seisata
Topics RU: математика
Topics EN: mathematics
Headings: Paus; SEISATA
Task examples: LEIA PILTIDELT RÜTM. KIRJUTA RÜTM TÖÖVIHIKUSSE JA ESITA. VÄRVI PILT.; JÄTKA KIRJUTAMIST TÖÖVIHIKUS.

## Mardilaul
URL: https://www.opiq.ee/kit/187/chapter/10494
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.5
Topics ET: matemaatika, mardilaul, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Mardilaul; TÄHESEGADIK
Task examples: VALMISTA MARDIMASK (VÕID KASUTADA ERINEVAID MATERJALE: LÕNG, RIIE, PUULEHED).

## Sokukene
URL: https://www.opiq.ee/kit/187/chapter/10495
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.6
Topics ET: matemaatika, sokukene
Topics RU: математика
Topics EN: mathematics
Headings: Sokukene

## Tere, Toomas
URL: https://www.opiq.ee/kit/187/chapter/10496
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.7
Topics ET: matemaatika, tere, toomas
Topics RU: математика
Topics EN: mathematics
Headings: Tere, Toomas
Task examples: MÄNGI ÕPITUD LAULU RÜTM. JOONISTA JA VÄRVI VIHMAVARJUD TÖÖVIHIKUS.

## Kadrilaul
URL: https://www.opiq.ee/kit/187/chapter/10497
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.8
Topics ET: matemaatika, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kadrilaul

## Tiiu, talutütrekene
URL: https://www.opiq.ee/kit/187/chapter/10498
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 7.9
Topics ET: matemaatika, tiiu, talutütrekene
Topics RU: математика
Topics EN: mathematics
Headings: Tiiu, talutütrekene
Task examples: JOONISTA JA VÄRVI PILDID TÖÖVIHIKUS. KIRJUTA SÕNA RÜTM JA KOPUTA.

## Sõit, sõit sinna
URL: https://www.opiq.ee/kit/187/chapter/10500
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 8.1
Topics ET: matemaatika, sõit, sinna
Topics RU: математика
Topics EN: mathematics
Headings: Sõit, sõit sinna
Task examples: HÄÄLITSE PILDI JÄRGI. TEHKE TEGELASTE HÄÄLI ÜHEAEGSELT.; VÄRVI JA JOONISTA HÄÄLED TÖÖVIHIKUS. ESITA HÄÄLED.

## Sügislinnuke
URL: https://www.opiq.ee/kit/187/chapter/10501
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 8.2
Topics ET: matemaatika, sügislinnuke
Topics RU: математика
Topics EN: mathematics
Headings: Sügislinnuke
Task examples: TEE HÄÄLI (KARU, HIIR, ÄIKE, LEHM, ÖÖBIK, POLITSEIAUTO, SÄÄSK, LAEV). JAOTA NEED MAJADESSE HÄÄLE KÕRGUSE JÄRGI.; KIRJUTA TÖÖVIHIKUSSE ASTMENIMED. LAULA. VÄRVI.

## Kiisu läks kõndima
URL: https://www.opiq.ee/kit/187/chapter/10502
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 8.3
Topics ET: matemaatika, kiisu, läks, kõndima, noodijoonestik
Topics RU: математика
Topics EN: mathematics
Headings: Kiisu läks kõndima; NOODIJOONESTIK
Task examples: LISA TÖÖVIHIKUS JUURDE OMA RÜTM JA ESITA KEHAPILLIL.; MILLEGA SAAB ENNAST RAVIDA? VÄRVI TÖÖVIHIKUS.

## Talveootus
URL: https://www.opiq.ee/kit/187/chapter/10503
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 9.1
Topics ET: matemaatika, talveootus
Topics RU: математика
Topics EN: mathematics
Headings: Talveootus
Task examples: RÜTMISTA TALVE MÄRGID TÖÖVIHIKUS. ESITA RÜTMID.

## Lapsed, tuppa!
URL: https://www.opiq.ee/kit/187/chapter/10504
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus
Chapter ID: 9.2
Topics ET: matemaatika, lapsed, tuppa, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Lapsed, tuppa!; TÄHESEGADIK
Task examples: MÄNGI DOOMINOT TÖÖVIHIKUS. TÄIDA LÜNGAD SOBIVATE KLOTSIDEGA.

## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/551
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 115
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikamaa – Opiq
URL: https://www.opiq.ee/Kit/Details/551
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 229
Topics ET: matemaatika, muusikamaa, opiq
Topics RU: математика
Topics EN: mathematics

## Leppemärgid
URL: https://www.opiq.ee/kit/551/chapter/30268
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 1.1
Topics ET: matemaatika, leppemärgid
Topics RU: математика
Topics EN: mathematics
Headings: Leppemärgid

## Tere, hea sõber!
URL: https://www.opiq.ee/kit/551/chapter/30265
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 1.2
Topics ET: matemaatika, tere, sõber
Topics RU: математика
Topics EN: mathematics
Headings: Tere, hea sõber!; Ülesanded
Task examples: JOONISTA TÖÖVIHIKUSSE LK 1 ENDA PILT. TÄIDA LÜNGAD.

## Laula, laula, lapsuke
URL: https://www.opiq.ee/kit/551/chapter/30266
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 1.3
Topics ET: matemaatika, laula, lapsuke
Topics RU: математика
Topics EN: mathematics
Headings: Laula, laula, lapsuke; Ülesanded
Task examples: KUULA JA JOONISTA TÖÖVIHIKUSSE LK 1 MUUSIKAT. MÕTLE PILDILE PEALKIRI.

## Kus on minu koduke
URL: https://www.opiq.ee/kit/551/chapter/30269
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 1.4
Topics ET: matemaatika, koduke
Topics RU: математика
Topics EN: mathematics
Headings: Kus on minu koduke

## Tere
URL: https://www.opiq.ee/kit/551/chapter/30270
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 1.5
Topics ET: matemaatika, tere
Topics RU: математика
Topics EN: mathematics
Headings: Tere

## Õnnitluslaul
URL: https://www.opiq.ee/kit/551/chapter/30271
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 1.6
Topics ET: matemaatika, õnnitluslaul
Topics RU: математика
Topics EN: mathematics
Headings: Õnnitluslaul

## Sünnipäevaks
URL: https://www.opiq.ee/kit/551/chapter/30267
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 1.7
Topics ET: matemaatika, sünnipäevaks
Topics RU: математика
Topics EN: mathematics
Headings: Sünnipäevaks; Ülesanded
Task examples: VALMISTA SÜNNIPÄEVAKUTSE. TÄIDA LÜNGAD.; KELLELE SOBIVAD NEED KINGITUSED (VANAEMA, EMA, SÕBER, ISA, VANAISA, KOER)? KIRJUTA ÕIGED VASTUSED PILDILE. VÄRVI PILT TÖÖVIHIKUS.

## Lumepallilaul
URL: https://www.opiq.ee/kit/551/chapter/30320
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 10.1
Topics ET: matemaatika, lumepallilaul, talverõõmud
Topics RU: математика
Topics EN: mathematics
Headings: Lumepallilaul; TALVERÕÕMUD; Ülesanded
Task examples: Pane tähestikulõigud õigesse järjekorda. Moodusta tähestik. Esita tähelõike lauldes.; Loe ja kirjuta sõnade rütm (TA, TI-TI või kopeeri siit: 𝄀, ⊓). Esitage rütmiread erinevatel pillidel korraga.

## Lumehelbeke
URL: https://www.opiq.ee/kit/551/chapter/30321
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 10.2
Topics ET: matemaatika, lumehelbeke
Topics RU: математика
Topics EN: mathematics
Headings: Lumehelbeke; Ülesanded
Task examples: Kirjuta töövihikusse pildi juurde sobiv märk. Värvi.; Kirjuta luuletuse rütm (TA, TI-TI või kopeeri siit: 𝄀, ⊓) ja esita see kehapillil. Loe luuletus a) valjenedes, b) vaibudes.

## Kelgusõit
URL: https://www.opiq.ee/kit/551/chapter/30322
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 10.3
Topics ET: matemaatika, kelgusõit
Topics RU: математика
Topics EN: mathematics
Headings: Kelgusõit
Task examples: Kirjuta töövihikusse noodid ja noodivarred.

## Uisutamas
URL: https://www.opiq.ee/kit/551/chapter/30323
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 10.4
Topics ET: matemaatika, uisutamas
Topics RU: математика
Topics EN: mathematics
Headings: Uisutamas
Task examples: Esitage rütm koos pinginaabriga kehapillil või erinevatel pillidel.

## Karumõmmi unelaul
URL: https://www.opiq.ee/kit/551/chapter/30326
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 10.5
Topics ET: matemaatika, karumõmmi, unelaul
Topics RU: математика
Topics EN: mathematics
Headings: Karumõmmi unelaul; 𝆏; 𝆑

## Mürakarud
URL: https://www.opiq.ee/kit/551/chapter/30324
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 10.6
Topics ET: matemaatika, mürakarud
Topics RU: математика
Topics EN: mathematics
Headings: Mürakarud; 𝆏; Ülesanded
Task examples: Kirjuta rütm töövihikusse. Plaksuta ja loe rütmisilpe kaasa.; Leia ja kirjuta SO-aste töövihikusse.

## Marsilaul
URL: https://www.opiq.ee/kit/551/chapter/30325
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 10.7
Topics ET: matemaatika, marsilaul, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Marsilaul; Ülesanded; Tähesegadik
Task examples: Arvuta ja kirjuta vastused.

## Takt. Taktimõõt. Taktijoon
URL: https://www.opiq.ee/kit/551/chapter/30327
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 11.1
Topics ET: matemaatika, takt, taktimõõt, taktijoon
Topics RU: математика
Topics EN: mathematics
Headings: Takt. Taktimõõt. Taktijoon
Task examples: Tõmba taktijooned töövihikusse. Esita rütm, ütle rütmisilpe kaasa.

## Kükita
URL: https://www.opiq.ee/kit/551/chapter/30329
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 11.2
Topics ET: matemaatika, kükita
Topics RU: математика
Topics EN: mathematics
Headings: Kükita

## Lapaduu
URL: https://www.opiq.ee/kit/551/chapter/30330
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 11.3
Topics ET: matemaatika, lapaduu, mängu, kirjeldus
Topics RU: математика
Topics EN: mathematics
Headings: Lapaduu; Mängu kirjeldus

## Üks, kaks, alati
URL: https://www.opiq.ee/kit/551/chapter/30328
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 11.4
Topics ET: matemaatika, kaks, alati
Topics RU: математика
Topics EN: mathematics
Headings: Üks, kaks, alati
Task examples: Kirjuta töövihikus pildi rütm taktidesse. Esita rütm. värvi.

## Põdra maja
URL: https://www.opiq.ee/kit/551/chapter/30335
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 12.1
Topics ET: matemaatika, põdra, maja
Topics RU: математика
Topics EN: mathematics
Headings: Põdra maja

## Matkalaul
URL: https://www.opiq.ee/kit/551/chapter/30336
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 12.2
Topics ET: matemaatika, matkalaul
Topics RU: математика
Topics EN: mathematics
Headings: Matkalaul

## Soss-soss-soss
URL: https://www.opiq.ee/kit/551/chapter/30331
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 12.3
Topics ET: matemaatika, soss
Topics RU: математика
Topics EN: mathematics
Headings: Soss-soss-soss; Ülesanded
Task examples: Kirjuta sõnad tagurpidi ja märgi nende rütm töövihikus. Esita.; Tõmba töövihikus taktijooned, kirjuta astmed noodijoonestikule. Laula viisi edasi-tagasi.

## Kurjad kuked
URL: https://www.opiq.ee/kit/551/chapter/30332
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 12.4
Topics ET: matemaatika, kurjad, kuked, vigurvänt
Topics RU: математика
Topics EN: mathematics
Headings: Kurjad kuked; VIGURVÄNT
Task examples: Vali ringidest viisilõigud. Kirjuta need töövihikus noodijoonestikule. Esita viisid.

## RA-aste
URL: https://www.opiq.ee/kit/551/chapter/30333
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 12.5
Topics ET: matemaatika, aste, liigun
Topics RU: математика
Topics EN: mathematics
Headings: RA-aste; LIIGUN NII; Ülesanded
Task examples: Leia ja kirjuta RA-aste töövihikus.; Leia ja kirjuta RA-aste töövihikus. Tõmba harjutustele takti- ja lõpujooned. Laula.

## Tihane
URL: https://www.opiq.ee/kit/551/chapter/30334
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 12.6
Topics ET: matemaatika, tihane, tutiga, müts
Topics RU: математика
Topics EN: mathematics
Headings: Tihane; TUTIGA MÜTS
Task examples: Kirjuta laul „LIIGUN NII” noodijoonestikule töövihikus. Laula.

## Mu isamaa, mu õnn ja rõõm
URL: https://www.opiq.ee/kit/551/chapter/30337
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 13.1
Topics ET: matemaatika, isamaa, rõõm, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Mu isamaa, mu õnn ja rõõm; Tähesegadik

## Pesapuu
URL: https://www.opiq.ee/kit/551/chapter/30338
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 13.2
Topics ET: matemaatika, pesapuu
Topics RU: математика
Topics EN: mathematics
Headings: Pesapuu
Task examples: Värvi pilt töövihikus. Leia Eestimaa sümbolid. Nimeta need.

## Kallis koht
URL: https://www.opiq.ee/kit/551/chapter/30339
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 13.3
Topics ET: matemaatika, kallis, koht
Topics RU: математика
Topics EN: mathematics
Headings: Kallis koht
Task examples: Lahenda ristsõna. Saad teada laulu „Karumõmmi unelaul” helilooja perekonnanime.

## Mängime kannelt
URL: https://www.opiq.ee/kit/551/chapter/30342
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 14.1
Topics ET: matemaatika, mängime, kannelt
Topics RU: математика
Topics EN: mathematics
Headings: Mängime kannelt

## Vastlalaul
URL: https://www.opiq.ee/kit/551/chapter/30340
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 14.2
Topics ET: matemaatika, vastlalaul
Topics RU: математика
Topics EN: mathematics
Headings: Vastlalaul
Task examples: Kirjuta töövihikusse taktimõõt ja astmenimed. Mõtle ja kirjuta viisile sõnad. Esita oma laul.

## Vastlapäeval
URL: https://www.opiq.ee/kit/551/chapter/30341
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 14.3
Topics ET: matemaatika, vastlapäeval
Topics RU: математика
Topics EN: mathematics
Headings: Vastlapäeval
Task examples: Leia luuletuse igale reale õige rütm ja ühenda joonega töövihikus. Mõtle luuletusele viis, kasutades SO- ja MI-astmeid. Laula.

## Ludimäng
URL: https://www.opiq.ee/kit/551/chapter/30343
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 14.4
Topics ET: matemaatika, ludimäng
Topics RU: математика
Topics EN: mathematics
Headings: Ludimäng

## Tantsulaul
URL: https://www.opiq.ee/kit/551/chapter/30344
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 14.5
Topics ET: matemaatika, tantsulaul
Topics RU: математика
Topics EN: mathematics
Headings: Tantsulaul

## Kokkutulek
URL: https://www.opiq.ee/kit/551/chapter/30349
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 15.1
Topics ET: matemaatika, kokkutulek
Topics RU: математика
Topics EN: mathematics
Headings: Kokkutulek

## 3-osaline taktimõõt. Elujutt
URL: https://www.opiq.ee/kit/551/chapter/30345
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 15.2
Topics ET: matemaatika, osaline, taktimõõt, elujutt
Topics RU: математика
Topics EN: mathematics
Headings: 3-osaline taktimõõt. Elujutt; ELUJUTT; Ülesanded
Task examples: Tõmba harjutustele takti- ja lõpujooned töövihikus. Koputa ja ütle rütmisilpe kaasa.; Joonista töövihikusse pildil olevale muinasjutule lõpp. Jutusta.

## Tudu, tudu, mu kallis
URL: https://www.opiq.ee/kit/551/chapter/30346
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 15.3
Topics ET: matemaatika, tudu, kallis, laul, heleroosast, toast
Topics RU: математика
Topics EN: mathematics
Headings: Tudu, tudu, mu kallis; LAUL HELEROOSAST TOAST
Task examples: Leia ja kirjuta töövihikusse luuletuse igale reale rütm. Tõmba taktijooned. Esita luuletuse rütm kehapillil, rõhutades takti esimest pulsilööki.

## Roosa jänku rokk
URL: https://www.opiq.ee/kit/551/chapter/30347
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 15.4
Topics ET: matemaatika, roosa, jänku, rokk
Topics RU: математика
Topics EN: mathematics
Headings: Roosa jänku rokk
Task examples: Tõmba taktijooned töövihikus. Esita rütm kehapillil.

## Pipi laul
URL: https://www.opiq.ee/kit/551/chapter/30348
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 15.5
Topics ET: matemaatika, pipi, laul
Topics RU: математика
Topics EN: mathematics
Headings: Pipi laul
Task examples: Vali iga tegelase juurde raamatu pealkiri. Värvi pildid töövihikus.

## Meistrimehed
URL: https://www.opiq.ee/kit/551/chapter/30350
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 16.1
Topics ET: matemaatika, meistrimehed
Topics RU: математика
Topics EN: mathematics
Headings: Meistrimehed

## Uhke meremees
URL: https://www.opiq.ee/kit/551/chapter/30351
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 16.2
Topics ET: matemaatika, uhke, meremees
Topics RU: математика
Topics EN: mathematics
Headings: Uhke meremees

## Jo-aste. Kevade vihm
URL: https://www.opiq.ee/kit/551/chapter/30352
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 17.1
Topics ET: matemaatika, aste, kevade, vihm, tulek, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Jo-aste. Kevade vihm; KEVADE TULEK; KEVADE VIHM; Ülesanded; Tähesegadik
Task examples: Leia ja kirjuta JO-aste töövihikus.

## Kevade hällilaul
URL: https://www.opiq.ee/kit/551/chapter/30356
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 17.2
Topics ET: matemaatika, kevade, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kevade hällilaul

## JO-võti. Hommikul
URL: https://www.opiq.ee/kit/551/chapter/30353
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 17.3
Topics ET: matemaatika, võti, hommikul
Topics RU: математика
Topics EN: mathematics
Headings: JO-võti. Hommikul; HOMMIKUL; Ülesanded
Task examples: Mitu JO-võtit on pildil? Värvi need töövihikus.; Kirjuta JO-aste töövihikus.

## Kevade ootel
URL: https://www.opiq.ee/kit/551/chapter/30354
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 17.4
Topics ET: matemaatika, kevade, ootel
Topics RU: математика
Topics EN: mathematics
Headings: Kevade ootel
Task examples: Tõmba taktijooned ja kirjuta viis noodijoonestikule. Laula.

## Kevadel
URL: https://www.opiq.ee/kit/551/chapter/30355
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 17.5
Topics ET: matemaatika, kevadel
Topics RU: математика
Topics EN: mathematics
Headings: Kevadel
Task examples: Tõmba taktijooned töövihikus. Kirjuta astmenimed ja laula.

## Väike jänku
URL: https://www.opiq.ee/kit/551/chapter/30357
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 18.1
Topics ET: matemaatika, väike, jänku, jänes
Topics RU: математика
Topics EN: mathematics
Headings: Väike jänku; JÄNES

## Tantsuhoos
URL: https://www.opiq.ee/kit/551/chapter/30358
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 18.2
Topics ET: matemaatika, tantsuhoos
Topics RU: математика
Topics EN: mathematics
Headings: Tantsuhoos

## Munade koks
URL: https://www.opiq.ee/kit/551/chapter/30359
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 18.3
Topics ET: matemaatika, munade, koks
Topics RU: математика
Topics EN: mathematics
Headings: Munade koks

## Nädalapäevad
URL: https://www.opiq.ee/kit/551/chapter/30360
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 19.1
Topics ET: matemaatika, nädalapäevad
Topics RU: математика
Topics EN: mathematics
Headings: Nädalapäevad; Ülesanded
Task examples: Kirjuta ise sõnu juurde. Laula klassikaaslastega.; Kirjuta viis töövihikus noodijoonestikule. Tõmba taktijooned ja lõpujoon. Esita laul.

## Kellakägu
URL: https://www.opiq.ee/kit/551/chapter/30361
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 19.2
Topics ET: matemaatika, kellakägu
Topics RU: математика
Topics EN: mathematics
Headings: Kellakägu
Task examples: Täida taktid töövihikus vastavalt taktimõõdule. Esita rütmid.

## Valgusfoor
URL: https://www.opiq.ee/kit/551/chapter/30275
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.1
Topics ET: matemaatika, valgusfoor, kolm, sõpra
Topics RU: математика
Topics EN: mathematics
Headings: Valgusfoor; KOLM SÕPRA

## Kooliteel
URL: https://www.opiq.ee/kit/551/chapter/30272
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.2
Topics ET: matemaatika, kooliteel
Topics RU: математика
Topics EN: mathematics
Headings: Kooliteel; Ülesanded
Task examples: VALI IGA LIIKLUSMÄRGI JUURDE TÄHENDUS. VÄRVI LIIKLUSMÄRGID TÖÖVIHIKUS:; KES KÄITUB LIIKLUSES ÕIGESTI? VÄRVI PILT TÖÖVIHIKUS:

## Meie kiisul kriimud silmad
URL: https://www.opiq.ee/kit/551/chapter/30276
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.3
Topics ET: matemaatika, meie, kiisul, kriimud, silmad
Topics RU: математика
Topics EN: mathematics
Headings: Meie kiisul kriimud silmad

## Tervituslaul
URL: https://www.opiq.ee/kit/551/chapter/30277
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.4
Topics ET: matemaatika, tervituslaul
Topics RU: математика
Topics EN: mathematics
Headings: Tervituslaul

## Kui su nime algustäht on …
URL: https://www.opiq.ee/kit/551/chapter/30273
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.5
Topics ET: matemaatika, nime, algustäht
Topics RU: математика
Topics EN: mathematics
Headings: Kui su nime algustäht on …; Ülesanded
Task examples: JOONISTA JA VÄRVI TÖÖVIHIKUS NOODID PUNASEKS, KIRJATÄHED SINISEKS JA TAEVATÄHED KOLLASEKS.

## Küll on tähed
URL: https://www.opiq.ee/kit/551/chapter/30278
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.6
Topics ET: matemaatika, küll, tähed
Topics RU: математика
Topics EN: mathematics
Headings: Küll on tähed

## Paha pliiats
URL: https://www.opiq.ee/kit/551/chapter/30274
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.7
Topics ET: matemaatika, paha, pliiats
Topics RU: математика
Topics EN: mathematics
Headings: Paha pliiats; Ülesanded
Task examples: MOODUSTA SEGAMINI TÄHTEDEST NIMED. VÄRVI PILDID TÖÖVIHIKUS.

## Laulan ma
URL: https://www.opiq.ee/kit/551/chapter/30279
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.8
Topics ET: matemaatika, laulan
Topics RU: математика
Topics EN: mathematics
Headings: Laulan ma

## Läks lahti
URL: https://www.opiq.ee/kit/551/chapter/30280
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 2.9
Topics ET: matemaatika, läks, lahti
Topics RU: математика
Topics EN: mathematics
Headings: Läks lahti; MINU ÕPETAJA

## Pärg
URL: https://www.opiq.ee/kit/551/chapter/30365
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 20.1
Topics ET: matemaatika, pärg
Topics RU: математика
Topics EN: mathematics
Headings: Pärg

## Emadepäeva laul
URL: https://www.opiq.ee/kit/551/chapter/30362
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 20.2
Topics ET: matemaatika, emadepäeva, laul
Topics RU: математика
Topics EN: mathematics
Headings: Emadepäeva laul

## Ti-ti-lit-ti-lei
URL: https://www.opiq.ee/kit/551/chapter/30363
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 20.3
Topics ET: matemaatika, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Ti-ti-lit-ti-lei; Tähesegadik

## Nuku hällilaul
URL: https://www.opiq.ee/kit/551/chapter/30364
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 20.4
Topics ET: matemaatika, nuku, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Nuku hällilaul

## Metsamuusika
URL: https://www.opiq.ee/kit/551/chapter/30369
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 21.1
Topics ET: matemaatika, metsamuusika
Topics RU: математика
Topics EN: mathematics
Headings: Metsamuusika

## Kevadaeg
URL: https://www.opiq.ee/kit/551/chapter/30366
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 21.2
Topics ET: matemaatika, kevadaeg
Topics RU: математика
Topics EN: mathematics
Headings: Kevadaeg
Task examples: Märgi õiged vastused.

## Võilill
URL: https://www.opiq.ee/kit/551/chapter/30367
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 21.3
Topics ET: matemaatika, võilill
Topics RU: математика
Topics EN: mathematics
Headings: Võilill

## Mängulaul
URL: https://www.opiq.ee/kit/551/chapter/30368
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 21.4
Topics ET: matemaatika, mängulaul, kõik, kõige, targemad
Topics RU: математика
Topics EN: mathematics
Headings: Mängulaul; KÕIK ON KÕIGE TARGEMAD

## Las plaksutab nüüd iga laps
URL: https://www.opiq.ee/kit/551/chapter/30370
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 21.5
Topics ET: matemaatika, plaksutab, nüüd, laps
Topics RU: математика
Topics EN: mathematics
Headings: Las plaksutab nüüd iga laps

## Kurg ja konn
URL: https://www.opiq.ee/kit/551/chapter/30371
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 22.1
Topics ET: matemaatika, kurg, konn, konna, perekond
Topics RU: математика
Topics EN: mathematics
Headings: Kurg ja konn; KONNA PEREKOND
Task examples: Leia ja kirjuta rütm ning astmenimed töövihikus. Laula. Värvi.

## Kaks kalameest
URL: https://www.opiq.ee/kit/551/chapter/30375
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 22.2
Topics ET: matemaatika, kaks, kalameest
Topics RU: математика
Topics EN: mathematics
Headings: Kaks kalameest

## Väike luiskaja
URL: https://www.opiq.ee/kit/551/chapter/30372
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 22.3
Topics ET: matemaatika, väike, luiskaja
Topics RU: математика
Topics EN: mathematics
Headings: Väike luiskaja
Task examples: Värvi asjad töövihikus, mida Tuut, Pin, Sisi ja Mira vajavad matkal.

## Liblikas
URL: https://www.opiq.ee/kit/551/chapter/30373
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 22.4
Topics ET: matemaatika, liblikas
Topics RU: математика
Topics EN: mathematics
Headings: Liblikas
Task examples: Kuula ja joonista muusikat töövihikus. Mõtle pildile pealkiri.

## Triinud
URL: https://www.opiq.ee/kit/551/chapter/30376
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 22.5
Topics ET: matemaatika, triinud
Topics RU: математика
Topics EN: mathematics
Headings: Triinud

## Pilvepildid
URL: https://www.opiq.ee/kit/551/chapter/30374
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 22.6
Topics ET: matemaatika, pilvepildid
Topics RU: математика
Topics EN: mathematics
Headings: Pilvepildid
Task examples: Kirjuta esimese klassi lemmiklaulude pealkirjad.

## Sõnaseletused
URL: https://www.opiq.ee/kit/551/chapter/30377
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 23.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Pulss
URL: https://www.opiq.ee/kit/551/chapter/30281
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 3.1
Topics ET: matemaatika, pulss, leia, muusika, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Pulss; LEIA MUUSIKA PULSS!; Ülesanded; TÄHESEGADIK

## Poisid, ritta!
URL: https://www.opiq.ee/kit/551/chapter/30282
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 3.2
Topics ET: matemaatika, poisid, ritta
Topics RU: математика
Topics EN: mathematics
Headings: Poisid, ritta!

## Elevandimarss
URL: https://www.opiq.ee/kit/551/chapter/30283
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 3.3
Topics ET: matemaatika, elevandimarss
Topics RU: математика
Topics EN: mathematics
Headings: Elevandimarss; Ülesanded

## Kõlapikkus (TA)
URL: https://www.opiq.ee/kit/551/chapter/30284
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 3.4
Topics ET: matemaatika, kõlapikkus
Topics RU: математика
Topics EN: mathematics
Headings: Kõlapikkus (TA); Ülesanded
Task examples: KIRJUTA NIMED. LOE JA PLAKSUTA NENDE RÜTM.

## Kõlapikkus (TI-TI)
URL: https://www.opiq.ee/kit/551/chapter/30285
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 3.5
Topics ET: matemaatika, kõlapikkus
Topics RU: математика
Topics EN: mathematics
Headings: Kõlapikkus (TI-TI); Ülesanded
Task examples: JÄTKA NIMEDE KIRJUTAMIST. LOE JA KOPUTA RÜTM.; JÄTKA RÜTMIDE KIRJUTAMIST TÖÖVIHIKUS.

## Mõistata
URL: https://www.opiq.ee/kit/551/chapter/30287
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 3.6
Topics ET: matemaatika, mõistata
Topics RU: математика
Topics EN: mathematics
Headings: Mõistata

## Kehapill
URL: https://www.opiq.ee/kit/551/chapter/30286
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 3.7
Topics ET: matemaatika, kehapill
Topics RU: математика
Topics EN: mathematics
Headings: Kehapill; Ülesanded
Task examples: VALI ÕIGE RÜTM JA MÄNGI KEHAPILLIL. VÄRVI PILDID TÖÖVIHIKUS.

## Sügis
URL: https://www.opiq.ee/kit/551/chapter/30288
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 4.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, sügise, värvid
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Sügis; SÜGISE VÄRVID; Ülesanded
Task examples: RÜTMISTA TÖÖVIHIKUS SÜGISE MÄRGID. KIRJUTA NEID JUURDE.

## Koer Muki
URL: https://www.opiq.ee/kit/551/chapter/30289
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 4.2
Topics ET: matemaatika, koer, muki
Topics RU: математика
Topics EN: mathematics
Headings: Koer Muki; Ülesanded
Task examples: KIRJUTA LAULU „KUS ON MINU KODUKE” RÜTM TÖÖVIHIKUSSE.

## Sügis, vahva mees
URL: https://www.opiq.ee/kit/551/chapter/30290
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 4.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, vahva, mees
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Sügis, vahva mees; Ülesanded
Task examples: KIRJUTA LUULETUSE RÜTM TÖÖVIHIKUSSE. LOE LUULETUST JA MÄNGI KAASA KEHAPILLIL.

## Minul on vihmamantel
URL: https://www.opiq.ee/kit/551/chapter/30292
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 4.4
Topics ET: matemaatika, minul, vihmamantel
Topics RU: математика
Topics EN: mathematics
Headings: Minul on vihmamantel

## Seeneralli
URL: https://www.opiq.ee/kit/551/chapter/30291
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 4.5
Topics ET: matemaatika, seeneralli
Topics RU: математика
Topics EN: mathematics
Headings: Seeneralli; Ülesanded
Task examples: LEIA LAULUST „SEENERALLI” SEENTE NIMED JA LOHISTA NEED PILDILE. TÖÖVIHIKUS LISA RÜTMID JA VÄRVI PILT.

## Rütmipillid
URL: https://www.opiq.ee/kit/551/chapter/30293
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 5.1
Topics ET: matemaatika, rütmipillid
Topics RU: математика
Topics EN: mathematics
Headings: Rütmipillid

## Pillilaul
URL: https://www.opiq.ee/kit/551/chapter/30294
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 5.2
Topics ET: matemaatika, pillilaul, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Pillilaul; Ülesanded; TÄHESEGADIK
Task examples: KIRJUTA IGALE RÜTMILE SOBIV PILLI NIMI (KULJUSED, TAMBURIIN, MARAKAD, GUIRO, TRIANGEL, VÕRUTRUMM, JAURAM, KRAAPLAUD, KASTANJETID, KÕLAPULGAD, AGOOGO, TALDRIK, KÕLAKARP).

## Isaga on julgem
URL: https://www.opiq.ee/kit/551/chapter/30295
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.1
Topics ET: matemaatika, isaga, julgem
Topics RU: математика
Topics EN: mathematics
Headings: Isaga on julgem; Ülesanded
Task examples: LEIA PILLI NIMI. VÄRVI PILT TÖÖVIHIKUS.

## Riidemäng
URL: https://www.opiq.ee/kit/551/chapter/30301
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.10
Topics ET: matemaatika, riidemäng
Topics RU: математика
Topics EN: mathematics
Headings: Riidemäng; Ülesanded
Task examples: NIMETA KLASSIS OLEVAID ASJU. KIRJUTA JA RÜTMISTA (TA, TI-TI VÕI KOPEERI SIIT: 𝄀, ⊓) NENDE NIMED.

## Padjasõja laul
URL: https://www.opiq.ee/kit/551/chapter/30296
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.2
Topics ET: matemaatika, padjasõja, laul
Topics RU: математика
Topics EN: mathematics
Headings: Padjasõja laul; Ülesanded
Task examples: KIRJUTA TÖÖVIHIKUSSE VASTUSE RÜTM JA ESITA KOOS PINGINAABRIGA.

## Kodulaul
URL: https://www.opiq.ee/kit/551/chapter/30302
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.3
Topics ET: matemaatika, kodulaul
Topics RU: математика
Topics EN: mathematics
Headings: Kodulaul

## Paus. Seisata
URL: https://www.opiq.ee/kit/551/chapter/30297
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.4
Topics ET: matemaatika, paus, seisata, kena, olla, pere, koos
Topics RU: математика
Topics EN: mathematics
Headings: Paus. Seisata; SEISATA; NII KENA ON OLLA, KUI PERE ON KOOS ...; Ülesanded
Task examples: LEIA PILTIDELT RÜTM. KIRJUTA RÜTM TÖÖVIHIKUSSE JA ESITA. VÄRVI PILT.; JÄTKA KIRJUTAMIST TÖÖVIHIKUS.

## Mardilaul
URL: https://www.opiq.ee/kit/551/chapter/30298
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.5
Topics ET: matemaatika, mardilaul, väikese, mardi, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Mardilaul; VÄIKESE MARDI MARDILAUL; Ülesanded; TÄHESEGADIK
Task examples: VALMISTA MARDIMASK (VÕID KASUTADA ERINEVAID MATERJALE: LÕNGA, RIIET, PUULEHTI).

## Sokukene
URL: https://www.opiq.ee/kit/551/chapter/30303
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.6
Topics ET: matemaatika, sokukene
Topics RU: математика
Topics EN: mathematics
Headings: Sokukene

## Tere, Toomas
URL: https://www.opiq.ee/kit/551/chapter/30299
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.7
Topics ET: matemaatika, tere, toomas
Topics RU: математика
Topics EN: mathematics
Headings: Tere, Toomas; Ülesanded
Task examples: PLAKSUTA ÕPITUD LAULU RÜTM. ESITA LAUL.JOONISTA JA VÄRVI VIHMAVARJUD TÖÖVIHIKUS.

## Kadrilaul
URL: https://www.opiq.ee/kit/551/chapter/30304
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.8
Topics ET: matemaatika, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kadrilaul

## Tiiu, talutütrekene
URL: https://www.opiq.ee/kit/551/chapter/30300
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 6.9
Topics ET: matemaatika, tiiu, talutütrekene
Topics RU: математика
Topics EN: mathematics
Headings: Tiiu, talutütrekene; Ülesanded
Task examples: JOONISTA JA VÄRVI PILDID TÖÖVIHIKUS. KIRJUTA SÕNA, SELLE RÜTM (TA, TI-TI VÕI KOPEERI SIIT: 𝄀, ⊓) JA KOPUTA.

## Sõit, sõit sinna
URL: https://www.opiq.ee/kit/551/chapter/30305
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 7.1
Topics ET: matemaatika, sõit, sinna
Topics RU: математика
Topics EN: mathematics
Headings: Sõit, sõit sinna; Ülesanded
Task examples: HÄÄLITSE PILDI JÄRGI. TEHKE TEGELASTE HÄÄLI SÕBRAGA ÜHEAEGSELT.; VÄRVI PILDID TÖÖVIHIKUS. JOONISTA KÕRVALE HÄÄLED JA ESITA NEED.

## Noodijoonestik
URL: https://www.opiq.ee/kit/551/chapter/30306
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 7.2
Topics ET: matemaatika, noodijoonestik
Topics RU: математика
Topics EN: mathematics
Headings: Noodijoonestik; Ülesanded
Task examples: MÄRGI NUMBRITEGA NOODIJOONESTIKU JOONED JA VAHED.; KIRJUTA, KUS ASUB NOOT (JOONEL, VAHES).

## Kiisu läks kõndima
URL: https://www.opiq.ee/kit/551/chapter/30308
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 7.3
Topics ET: matemaatika, kiisu, läks, kõndima
Topics RU: математика
Topics EN: mathematics
Headings: Kiisu läks kõndima

## Sügislinnuke
URL: https://www.opiq.ee/kit/551/chapter/30307
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 7.4
Topics ET: matemaatika, sügislinnuke
Topics RU: математика
Topics EN: mathematics
Headings: Sügislinnuke; Ülesanded
Task examples: LISA TÖÖVIHIKUS OMA RÜTM JA ESITA KEHAPILLIL.; MILLEGA SAAB ENNAST RAVIDA? VÄRVI TÖÖVIHIKUS.

## Talveootus
URL: https://www.opiq.ee/kit/551/chapter/30309
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 8.1
Topics ET: matemaatika, talveootus
Topics RU: математика
Topics EN: mathematics
Headings: Talveootus; Ülesanded
Task examples: RÜTMISTA TALVE MÄRGID TÖÖVIHIKUS. ESITA RÜTMID.

## Lapsed, tuppa
URL: https://www.opiq.ee/kit/551/chapter/30310
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 8.2
Topics ET: matemaatika, lapsed, tuppa, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Lapsed, tuppa; LAPSED, TUPPA!; Ülesanded; TÄHESEGADIK
Task examples: MÄNGI DOOMINOT TÖÖVIHIKUS. TÄIDA LÜNGAD SOBIVATE KLOTSIDEGA.

## Jõululaul
URL: https://www.opiq.ee/kit/551/chapter/30317
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.1
Topics ET: matemaatika, jõululaul
Topics RU: математика
Topics EN: mathematics
Headings: Jõululaul

## Valged jõulud
URL: https://www.opiq.ee/kit/551/chapter/30311
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.2
Topics ET: matemaatika, valged, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: Valged jõulud; Ülesanded
Task examples: JÄTKA NOOTIDE KIRJUTAMIST TÖÖVIHIKUS.

## Kes elab metsa sees
URL: https://www.opiq.ee/kit/551/chapter/30312
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.3
Topics ET: matemaatika, elab, metsa, sees
Topics RU: математика
Topics EN: mathematics
Headings: Kes elab metsa sees; Ülesanded
Task examples: LEIA JA KIRJUTA MI-ASTE TÖÖVIHIKUSSE.; LAULA ASTMENIMEDEGA JA NÄITA KAASA KÄEMÄRKE. KIRJUTA VIIS NOODIJOONESTIKULE TÖÖVIHIKUS. VÄRVI.

## Päkapikula
URL: https://www.opiq.ee/kit/551/chapter/30313
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.4
Topics ET: matemaatika, päkapikula
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikula; Ülesanded
Task examples: LEIA JA KIRJUTA PÄKAPIKKUDELE NIMED. ESITA NIMERÜTMID KEHAPILLIL. VÄRVI TÖÖVIHIKUS.

## Päkapiku jõulud
URL: https://www.opiq.ee/kit/551/chapter/30314
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.5
Topics ET: matemaatika, päkapiku, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: Päkapiku jõulud; Ülesanded
Task examples: LEIA SÕNAD, MIS KUULUVAD „MUUSIKAMAA” JUURDE.

## Kingisoov
URL: https://www.opiq.ee/kit/551/chapter/30318
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.6
Topics ET: matemaatika, kingisoov
Topics RU: математика
Topics EN: mathematics
Headings: Kingisoov

## Igal lapsel oma ingel
URL: https://www.opiq.ee/kit/551/chapter/30319
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.7
Topics ET: matemaatika, igal, lapsel, ingel, meie, palve
Topics RU: математика
Topics EN: mathematics
Headings: Igal lapsel oma ingel; MEIE ISA PALVE

## Jõulukellad
URL: https://www.opiq.ee/kit/551/chapter/30315
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.8
Topics ET: matemaatika, jõulukellad
Topics RU: математика
Topics EN: mathematics
Headings: Jõulukellad

## Läbi lume sahiseva
URL: https://www.opiq.ee/kit/551/chapter/30316
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 1._klassi_muusika­õpetus_(2024)
Chapter ID: 9.9
Topics ET: matemaatika, läbi, lume, sahiseva, kauneid, jõulupühi, tähesegadik
Topics RU: математика
Topics EN: mathematics
Headings: Läbi lume sahiseva; Kauneid jõulupühi!; Ülesanded; TÄHESEGADIK
Task examples: ÜHENDA PILT ÕIGE RÜTMIGA. ESITA RÜTMID. VÄRVI PILDID TÖÖVIHIKUS.

## Muusikaõpik 1. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/197
Book: muusika­õpetus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 230
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikaõpik 1. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/197
Book: muusika­õpetus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 257
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## ALGUS
URL: https://www.opiq.ee/kit/197/chapter/11301
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.1
Topics ET: matemaatika, algus, saame, tuttavaks, koduke, õpime, koos, meie, muusika
Topics RU: математика
Topics EN: mathematics
Headings: ALGUS; SAAME TUTTAVAKS; KUS ON MINU KODUKE?; ÕPIME KOOS; MEIE MUUSIKA
Task examples: UURI LAULU „ÕPIME KOOS“ SÕNU. MIDA LAPSED MUUSIKATUNNIS TEEVAD? MÄRGI ÕIGED VASTUSED.; MIDA KIRJUTATAKSE NOOTIDEGA? MÄRGI ÕIGED VASTUSED.

## Piano, forte
URL: https://www.opiq.ee/kit/197/chapter/11310
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.10
Topics ET: matemaatika, piano, forte, tibutab, ladistab, tasakesi, valjusti, mõiste, kõvasti, valjult
Topics RU: математика
Topics EN: mathematics
Headings: Piano, forte; Tibutab ja ladistab; Tasakesi ja valjusti; f – FORTE[mõiste: forte – kõvasti, valjult] – valjult; p – PIANO[mõiste: piano – tasa, vaikselt] – vaikselt; Sügislauluke; Aiamäng; Kuulamiskool
Task examples: Millised helid on piano’s, millised forte’s? Lohista sõnad õigesse veergu.; Neli sõna loetelus väljendavad vaikset heli. Märgi need.

## Pillimäng
URL: https://www.opiq.ee/kit/197/chapter/11311
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.11
Topics ET: matemaatika, pillimäng, tõistre, tõnul, torupill, sellel, mängib, tirilill, kuulamiskool
Topics RU: математика
Topics EN: mathematics
Headings: Pillimäng; Tõistre Tõnul torupill, sellel mängib tirilill!; Kuulamiskool; Orkester; Mängime koos; Rütmipillid; Trummilugu
Task examples: Milliseid pille sa tead? Ühenda paarid.; Siin pildil on suur pillide kogum – sümfooniaorkester. Vaata pilti ja mõtle, kuidas orkestripille mängitakse: poognaga (keelpillid), puhudes (puhkpillid) või pulkade või nuiaga lüües (löökpillid). Lohista pillirühmade ni

## Talvised laulud
URL: https://www.opiq.ee/kit/197/chapter/11312
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.12
Topics ET: matemaatika, talvised, laulud, lume, lagedale, viib, meid, rõõmus, talvetee, kuud
Topics RU: математика
Topics EN: mathematics
Headings: Talvised laulud; Üle lume lagedale viib meid rõõmus talvetee; Kuud rahvakalendris; Lapsed, tuppa!; Kuulamiskool; Õuemuusika; Ootel; Päkapikk ja suss; Valge laul; Ootsin pühi; Läbi lume sahiseva; Piparkoogimäng; Oh, kuusepuu; Jõulud; Väiksed kellad kõlavad; Kuusebeebi
Task examples: Millised hääled on talvekuudel linnas ja millised maal? Lohista õigesse veergu.; Mida tähistatakse jõuludega kirikus?

## LAULMINE
URL: https://www.opiq.ee/kit/197/chapter/11302
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.2
Topics ET: matemaatika, laulmine, häälepill, kuulamiskool, laulan, mere, maaks, aabits, kärbse
Topics RU: математика
Topics EN: mathematics
Headings: LAULMINE; HÄÄLEPILL; KUULAMISKOOL; LAULAN MERE MAAKS; AABITS; KÄRBSE LAUL; SALAJUTT
Task examples: MIDA TULEB TEHA, ET LAUL KÕLAKS HÄSTI? MÄRGI ÄRA ÕIGED VASTUSED.; KES ON LOONUD LAULU „SALAJUTT“ VIISI?

## RÜTM
URL: https://www.opiq.ee/kit/197/chapter/11303
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.3
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, rütm, kõla, ringmäng, kuulamiskool, marsilaul
Topics RU: математика, измерение, единица измерения, длина, масса, объём
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: RÜTM; KÕLA PIKKUS; RINGMÄNG; KUULAMISKOOL; MARSILAUL
Task examples: PLAKSUTA SÕNADE RÜTMI. LOHISTA KAS PÄIKESE VÕI KUU TULPA.

## ÕUES ON SÜGIS
URL: https://www.opiq.ee/kit/197/chapter/11304
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.4
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, õues, külluslik, kirju, pohla, pori, hingedekuu, kaksteist
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: ÕUES ON SÜGIS; KÜLLUSLIK JA KIRJU; POHLA-, PORI- JA HINGEDEKUU; SÜGIS; KAKSTEIST KUUD; MIDA KEEGI TALVEKS KORJAB?; MARDILAUL; KUULAMISKOOL; KADRILAUL; MÕISTATUS; TIGU HÄDAS MAJAGA
Task examples: LOHISTA LINNA- JA MAAHÄÄLED ÕIGESSE TULPA.; MÕTLE HELI KOHTA VÄLJA UUSI SÕNU. KIRJUTA SÕNAD LÜNKA.

## Meetrum
URL: https://www.opiq.ee/kit/197/chapter/11305
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.5
Topics ET: matemaatika, meetrum, muusika, süda, rütmi, tugi, kaks, meetrumit
Topics RU: математика
Topics EN: mathematics
Headings: Meetrum; Muusika süda; Rütmi tugi; Kaks meetrumit
Task examples: PLAKSUTA SÕNADE RÜTMI. LOHISTA SÕNAD TA- VÕI TI-TI-TULPA.

## Takt
URL: https://www.opiq.ee/kit/197/chapter/11306
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.6
Topics ET: matemaatika, takt, paigutab, rütme, rütmirongi, vagunid, sõit
Topics RU: математика
Topics EN: mathematics
Headings: Takt; Paigutab rütme; Rütmirongi vagunid; Sõit-sõit
Task examples: MILLEKS JAGUNEVAD LAULUD JA MUUSIKAPALAD?; MIDA NÄITAB TAKTIMÕÕT?

## Refrään ja kordusmärgid
URL: https://www.opiq.ee/kit/197/chapter/11307
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.7
Topics ET: matemaatika, refrään, kordusmärgid, aina, tagasi, tikifaa, valgusfoor, kuulamiskool
Topics RU: математика
Topics EN: mathematics
Headings: Refrään ja kordusmärgid; Aina tagasi; Tikifaa; Valgusfoor; Kuulamiskool
Task examples: Kus paikneb laulus refrään?

## Paus
URL: https://www.opiq.ee/kit/197/chapter/11308
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.8
Topics ET: matemaatika, paus, vaikus, muusikast, vaikuse, märk, küll, kuulamiskool
Topics RU: математика
Topics EN: mathematics
Headings: Paus; Vaikus on osa muusikast; Vaikuse märk; Küll on hea; Kuulamiskool

## TA-A-rütm
URL: https://www.opiq.ee/kit/197/chapter/11309
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 1.9
Topics ET: matemaatika, rütm, jääb, seisma, öökull, kahe, löögi, pikkune, vihmapiisad
Topics RU: математика
Topics EN: mathematics
Headings: TA-A-rütm; Jääb seisma; Öökull; Kahe löögi pikkune; Vihmapiisad; Kuulamiskool

## Astmed SO ja MI
URL: https://www.opiq.ee/kit/197/chapter/11313
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.1
Topics ET: matemaatika, astmed, kellade, helin, astmenimed, jaanuari, laul, astmega
Topics RU: математика
Topics EN: mathematics
Headings: Astmed SO ja MI; Kellade helin; Astmenimed; Jaanuari laul; Ülesanded SO ja MI astmega; Kuud
Task examples: Mis on olemas igal astmel?; Mis eristab muusikalisi helisid?

## Muusika kuulamine
URL: https://www.opiq.ee/kit/197/chapter/11322
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.10
Topics ET: matemaatika, muusika, kuulamine, kuula, näed, kuupaistesonaat, kuulamiskool, väike, öömuusika, elevant
Topics RU: математика
Topics EN: mathematics
Headings: Muusika kuulamine; Kuula ja sa näed ...; Hea muusika; „Kuupaistesonaat“; Kuulamiskool; „Väike öömuusika“; Elevant tantsib; Rütmimängud

## Regilaul
URL: https://www.opiq.ee/kit/197/chapter/11314
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, regilaul, teised, järel, saja, uuta, lunda, kuulamiskool, käes
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Regilaul; Üks ees ja teised järel; Saja uuta lunda; Kuulamiskool; Käes on talv; Lumepiknik; Lumememm; Varred
Task examples: Mida laulis koor? Märgi õige vastus.; Mis on regilaul? Märgi õige vastus.

## Noodijoonestik
URL: https://www.opiq.ee/kit/197/chapter/11315
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.3
Topics ET: matemaatika, noodijoonestik, laulude, kodu, viis, joont, neli, vahet, vahedes
Topics RU: математика
Topics EN: mathematics
Headings: Noodijoonestik; Laulude kodu; Viis joont ja neli vahet; Vahedes ja joontel
Task examples: Kus asuvad noodid noodijoonestikul?; Mitu joont on noodijoonestikus?

## Aste RA
URL: https://www.opiq.ee/kit/197/chapter/11316
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.4
Topics ET: matemaatika, aste, ülemine, naaber, talvelaulik, astmetrepil, tihane, talverahu, kuulamiskool
Topics RU: математика
Topics EN: mathematics
Headings: Aste RA; SO ülemine naaber; Talvelaulik; RA astmetrepil; Tihane; Talverahu; Kuulamiskool
Task examples: Mis värvi on RA-aste?; Mis värvi on RA-aste?

## Vastlad
URL: https://www.opiq.ee/kit/197/chapter/11317
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.5
Topics ET: matemaatika, vastlad, täna, liugu, laseme, hõissa, meil, liug, vurr
Topics RU: математика
Topics EN: mathematics
Headings: Vastlad; Täna liugu laseme, hõissa, meil on vastlad!; Liug ja vurr; Vastlalaul; Kuulamiskool; Salajutt; Maiustame
Task examples: Millest valmistati vanasti vurre?; Miks öeldakse, et vastlapäev on liikuv püha? Märgi õige vastus.

## Eesti sünnipäev
URL: https://www.opiq.ee/kit/197/chapter/11318
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.6
Topics ET: matemaatika, eesti, sünnipäev, rukkilill, rahvuslill, isamaa, rõõm, kuulamiskool, jõgi
Topics RU: математика
Topics EN: mathematics
Headings: Eesti sünnipäev; Rukkilill on eesti rahvuslill; Mu isamaa, mu õnn ja rõõm; Kuulamiskool; Jõgi voolab; Pesapuu; Tervituslaul; Üles!; Poisid, ritta; Tiiu, talutütrekene; SO on siin, MI on siin; Mõistatused
Task examples: Mis keel on eesti keel?; Millal on Eesti Vabariigi sünnipäev?

## TA-A-A-rütm
URL: https://www.opiq.ee/kit/197/chapter/11319
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.7
Topics ET: matemaatika, rütm, peatub, kauemaks, teerull, kolme, löögi, pikkune
Topics RU: математика
Topics EN: mathematics
Headings: TA-A-A-rütm; Peatub kauemaks; Teerull; Kolme löögi pikkune

## Tants
URL: https://www.opiq.ee/kit/197/chapter/11320
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.8
Topics ET: matemaatika, tants, heljudes, hüpeldes, tantsustiilid, kuulamiskool, meie, aiaväravas, tilijali
Topics RU: математика
Topics EN: mathematics
Headings: Tants; Heljudes ja hüpeldes; Tantsustiilid; Kuulamiskool; Meie aiaväravas; Tilijali, tulijali
Task examples: Mis tantsu pildil tantsitakse? Vali õige vastus.; Mis tantsu pildil tantsitakse? Vali õige vastus.

## Kevadised viisid
URL: https://www.opiq.ee/kit/197/chapter/11321
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 2.9
Topics ET: matemaatika, kevadised, viisid, juba, linnukesed, väljas, laulavad, kevadel, kuulamiskool
Topics RU: математика
Topics EN: mathematics
Headings: Kevadised viisid; Juba linnukesed väljas laulavad!; Kevadel; Kuulamiskool; Kevade ootel; Jänkude tantsulaul; Jänku; Väike lind
Task examples: Milline on kevad? Märgi õiged vastused.

## Lauluvara
URL: https://www.opiq.ee/kit/197/chapter/11323
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 3.1
Topics ET: matemaatika, lauluvara, kellalaul, imelaegas, jääkaru, hiir, sõidab, metsa, konksulugu, loomade
Topics RU: математика
Topics EN: mathematics
Headings: Lauluvara; Kellalaul; Imelaegas; Jääkaru; Hiir sõidab metsa; Konksulugu; Loomade pidu; Taadi oma saar; Kuldne lugu; Nõiapoisid; Pajupill; Kägu; Üksinda ma kõnnin metsas; Mis sa, sitikas, sirised?; Kuulamiskool; Õnneseen; Ema; Eestimaa lapsed; Idupidu; Sokukene; Vana sokk; Talumehemäng; Aadamal oli seitse poega; Hüüame koos; Harjutused rütmidega; Suvekuud; Haldjate laul

## Laulude tähestikuline loetelu
URL: https://www.opiq.ee/kit/197/chapter/21367
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 3.2
Topics ET: matemaatika, laulude, tähestikuline, loetelu
Topics RU: математика
Topics EN: mathematics
Headings: Laulude tähestikuline loetelu; A – K; L – P; R–Ü

## Mõisted
URL: https://www.opiq.ee/kit/197/chapter/11324
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 3.3
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/197/chapter/18741
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_1._klassile
Chapter ID: 3.4
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Музыка – волшебная страна. 1 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/237
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 258
Topics ET: matemaatika, opiq
Topics RU: математика, музыка, волшебная, страна, класс
Topics EN: mathematics

## Музыка – волшебная страна. 1 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/237
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 349
Topics ET: matemaatika, opiq
Topics RU: математика, музыка, волшебная, страна, класс
Topics EN: mathematics

## Здравствуй, дорогой первоклассник!
URL: https://www.opiq.ee/kit/237/chapter/13359
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, здравствуй, дорогой, первоклассник, обозначения
Topics EN: mathematics
Headings: Здравствуй, дорогой первоклассник!; ОБОЗНАЧЕНИЯ:

## Так уж получилось
URL: https://www.opiq.ee/kit/237/chapter/13360
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, получилось
Topics EN: mathematics
Headings: Так уж получилось

## Seisata
URL: https://www.opiq.ee/kit/237/chapter/13361
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 1.3
Topics ET: matemaatika, seisata
Topics RU: математика, звуки
Topics EN: mathematics
Headings: Seisata; ЗВУКИ
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Закрой глаза и слушай. Все звуки вокруг тебя – это музыка! Нарисуй её.

## Весёлые путешественники
URL: https://www.opiq.ee/kit/237/chapter/13362
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, путешественники
Topics EN: mathematics
Headings: Весёлые путешественники

## Заиграй на каннеле
URL: https://www.opiq.ee/kit/237/chapter/13406
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 10.1
Topics ET: matemaatika
Topics RU: математика, заиграй, каннеле
Topics EN: mathematics
Headings: Заиграй на каннеле
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Рассели нотки в доме по комнатам-тактам (с. 34).

## Tantsuhoos
URL: https://www.opiq.ee/kit/237/chapter/13407
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 10.2
Topics ET: matemaatika, tantsuhoos
Topics RU: математика
Topics EN: mathematics
Headings: Tantsuhoos
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели мелодию на такты. Подпиши ступени под нотами и спой мелодию.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели упражнение на такты, запиши его на нотоносце. Спой мелодию.

## Савка и Гришка
URL: https://www.opiq.ee/kit/237/chapter/13408
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 10.3
Topics ET: matemaatika
Topics RU: математика, савка, гришка
Topics EN: mathematics
Headings: Савка и Гришка
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели мелодию на такты. Сочини и запиши недостающие ступени. Спой мелодию, показывая ступени рукой.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели мелодию на такты. Сочини слова и спой песенку.

## Спи, моя радость, усни
URL: https://www.opiq.ee/kit/237/chapter/13409
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 11.1
Topics ET: matemaatika
Topics RU: математика, радость, усни, спать, пора, полно
Topics EN: mathematics
Headings: Спи, моя радость, усни; СПАТЬ ПОРА; ПОЛНО СПАТЬ
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши мелодию на нотоносце и спой её.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Подпиши ступени и спой мелодию. Придумай слова и спой песенку.

## Ай-я, жу-жу
URL: https://www.opiq.ee/kit/237/chapter/13410
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 11.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ай-я, жу-жу
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели ритм на такты. Сыграйте его с другом на разных музыкальных инструментах.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ.

## Колыбельная
URL: https://www.opiq.ee/kit/237/chapter/13411
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 11.3
Topics ET: matemaatika
Topics RU: математика, колыбельная
Topics EN: mathematics
Headings: Колыбельная
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши ритм слов, сочини и подпиши под ним ступени. Спой песенку.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Допиши ритм, сыграйте его с другом на треугольнике и тамбурине.

## Поём канон
URL: https://www.opiq.ee/kit/237/chapter/13412
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 11.4
Topics ET: matemaatika
Topics RU: математика, канон, ритмический
Topics EN: mathematics
Headings: Поём канон; РИТМИЧЕСКИЙ КАНОН
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Если JО находится на линейке, то МI и SО тоже будут на линейках.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели мелодию на такты и спой её. Запиши эту мелодию на новом нотоносце.

## Hommikul
URL: https://www.opiq.ee/kit/237/chapter/13413
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 11.5
Topics ET: matemaatika, hommikul
Topics RU: математика
Topics EN: mathematics
Headings: Hommikul
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Допиши попевку со с. 95 и спой её.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выполни упражнение со с. 100 и спой его.

## Подарки
URL: https://www.opiq.ee/kit/237/chapter/13414
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 12.1
Topics ET: matemaatika
Topics RU: математика, подарки
Topics EN: mathematics
Headings: Подарки
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выполни упражнение со с. 101 и спой его.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Найди и запиши в каждом ключе ступень JO.

## Muusikat tegema
URL: https://www.opiq.ee/kit/237/chapter/13415
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 12.2
Topics ET: matemaatika, muusikat, tegema
Topics RU: математика
Topics EN: mathematics
Headings: Muusikat tegema
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели мелодию на такты и спой её, показывая ступени рукой.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Определи и запиши размер такта. Выполните упражнение в группах: одна – поёт, другая исполняет ритм на тамбурине.

## Каравай
URL: https://www.opiq.ee/kit/237/chapter/13416
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 12.3
Topics ET: matemaatika
Topics RU: математика, каравай
Topics EN: mathematics
Headings: Каравай
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели ритм на такты. Исполните его с соседом в каноне на разных музыкальных инструментах.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Спой обе мелодии. Исполните их двухголосно в группах.

## Kus on minu koduke?
URL: https://www.opiq.ee/kit/237/chapter/13417
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 12.4
Topics ET: matemaatika, koduke
Topics RU: математика
Topics EN: mathematics
Headings: Kus on minu koduke?
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выполни письменно упражнение со с. 106.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выучи мелодию, придумай слова и спой песенку.

## Позабудем всё, что было
URL: https://www.opiq.ee/kit/237/chapter/13418
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 13.1
Topics ET: matemaatika
Topics RU: математика, позабудем, было
Topics EN: mathematics
Headings: Позабудем всё, что было
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Проведём беседу.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Заполни пустые такты и спой мелодию.

## Kiisu läks kõndima
URL: https://www.opiq.ee/kit/237/chapter/13419
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 13.2
Topics ET: matemaatika, kiisu, läks, kõndima
Topics RU: математика
Topics EN: mathematics
Headings: Kiisu läks kõndima
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Перепиши ритм со с. 111, раздели его на такты. Сочини ступени и спой получившуюся мелодию.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Соедини пары разноцветными линиями.

## Кот Мурлыка
URL: https://www.opiq.ee/kit/237/chapter/13420
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 13.3
Topics ET: matemaatika
Topics RU: математика, мурлыка
Topics EN: mathematics
Headings: Кот Мурлыка
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели мелодию на такты. Спойте её в каноне.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Какая новая ступень появилась на лестнице?

## Tere
URL: https://www.opiq.ee/kit/237/chapter/13421
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 13.4
Topics ET: matemaatika, tere
Topics RU: математика
Topics EN: mathematics
Headings: Tere
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели мелодию на такты. Cпой её, показывая ступени рукой. Прочитай слова и исполни песенку.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Рассели ноты по комнатам-тактам и сыграй ритм на бубне.

## Väike kutsu
URL: https://www.opiq.ee/kit/237/chapter/13422
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 13.5
Topics ET: matemaatika, väike, kutsu
Topics RU: математика
Topics EN: mathematics
Headings: Väike kutsu
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели ритм на такты. Запиши ступени на нотоносце. Допиши слова и спой песенку.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши мелодию песни «Гости» со с. 98 и спой её.

## Matkalaul
URL: https://www.opiq.ee/kit/237/chapter/13423
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 13.6
Topics ET: matemaatika, matkalaul
Topics RU: математика, давай, вспомним
Topics EN: mathematics
Headings: Matkalaul; ДАВАЙ ВСПОМНИМ!
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Продолжи беседу.

## Подснежник
URL: https://www.opiq.ee/kit/237/chapter/13424
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 14.1
Topics ET: matemaatika
Topics RU: математика, подснежник
Topics EN: mathematics
Headings: Подснежник
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Определи и запиши размер такта. Исполни упражнение в группах: одна – поёт, другая исполняет ритм на маракасах.

## Веснянка
URL: https://www.opiq.ee/kit/237/chapter/13425
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 14.2
Topics ET: matemaatika
Topics RU: математика, веснянка
Topics EN: mathematics
Headings: Веснянка
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сочини и запиши мелодию. Спой её.

## Сказки во сне и наяву
URL: https://www.opiq.ee/kit/237/chapter/13426
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 15.1
Topics ET: matemaatika
Topics RU: математика, сказки, наяву, гости
Topics EN: mathematics
Headings: Сказки во сне и наяву; ГОСТИ
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выучи мелодию, сочини вторую строчку слов и спой песенку.

## Кому что снится?
URL: https://www.opiq.ee/kit/237/chapter/13427
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 15.2
Topics ET: matemaatika
Topics RU: математика, кому, снится
Topics EN: mathematics
Headings: Кому что снится?
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели ритм на такты. Придумай к ритму ступени и запиши их на нотоносце. Спой мелодию.

## Сказка-сон
URL: https://www.opiq.ee/kit/237/chapter/13428
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 15.3
Topics ET: matemaatika
Topics RU: математика, сказка
Topics EN: mathematics
Headings: Сказка-сон
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ.

## Игра в колдовство
URL: https://www.opiq.ee/kit/237/chapter/13429
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 15.4
Topics ET: matemaatika
Topics RU: математика, игра, колдовство, колдоство
Topics EN: mathematics
Headings: Игра в колдовство; ИГРА В КОЛДОСТВО
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Спой мелодию. Ритм можешь исполнить на бубне.

## Плим
URL: https://www.opiq.ee/kit/237/chapter/13430
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 15.5
Topics ET: matemaatika
Topics RU: математика, плим
Topics EN: mathematics
Headings: Плим
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Продолжи беседу.

## Вновь солнышко смеётся
URL: https://www.opiq.ee/kit/237/chapter/13431
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 16.1
Topics ET: matemaatika
Topics RU: математика, вновь, солнышко
Topics EN: mathematics
Headings: Вновь солнышко смеётся
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Определи и запиши размер такта. Запиши мелодию на нотоносце. Сочини вторую строчку слов и исполни песенку.

## Lenda, pääsulind
URL: https://www.opiq.ee/kit/237/chapter/13432
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 16.2
Topics ET: matemaatika, lenda, pääsulind
Topics RU: математика
Topics EN: mathematics
Headings: Lenda, pääsulind; LENDA, PÄÄSULIND!
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выучи мелодию и по памяти запиши её на нотоносце.

## Горелки
URL: https://www.opiq.ee/kit/237/chapter/13433
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 16.3
Topics ET: matemaatika
Topics RU: математика, горелки
Topics EN: mathematics
Headings: Горелки
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Найди и запиши повторяющийся ритм слов. Подпиши ступени, спой песенку.

## Tihane
URL: https://www.opiq.ee/kit/237/chapter/13434
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 16.4
Topics ET: matemaatika, tihane
Topics RU: математика
Topics EN: mathematics
Headings: Tihane
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Раздели ритм на такты. Исполните его с другом на разных инструментах.

## Tirilii
URL: https://www.opiq.ee/kit/237/chapter/13435
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 16.5
Topics ET: matemaatika, tirilii
Topics RU: математика
Topics EN: mathematics
Headings: Tirilii
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сочини ритм к мелодии и спой её. Сравни свой ритм с ритмом cвоего соседа.

## Танец утят
URL: https://www.opiq.ee/kit/237/chapter/13436
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 16.6
Topics ET: matemaatika
Topics RU: математика, танец, утят
Topics EN: mathematics
Headings: Танец утят
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Нарисуй музыкальные инструменты. Исполни на одном из них ритм песни «Tihane» (с. 107).

## Kuula, mu linnuke
URL: https://www.opiq.ee/kit/237/chapter/13437
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 16.7
Topics ET: matemaatika, kuula, linnuke
Topics RU: математика
Topics EN: mathematics
Headings: Kuula, mu linnuke
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выучи мелодию и спойте её с другом в каноне. (Понятие канона – на с. 80).

## Солнышко
URL: https://www.opiq.ee/kit/237/chapter/13438
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 17.1
Topics ET: matemaatika
Topics RU: математика, солнышко
Topics EN: mathematics
Headings: Солнышко
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Продолжи беседу.

## Мама
URL: https://www.opiq.ee/kit/237/chapter/13439
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 17.2
Topics ET: matemaatika
Topics RU: математика, мама
Topics EN: mathematics
Headings: Мама
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сочини вторую строчку слов и спой песенку.

## Бабушка
URL: https://www.opiq.ee/kit/237/chapter/13440
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 17.3
Topics ET: matemaatika
Topics RU: математика, бабушка
Topics EN: mathematics
Headings: Бабушка
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Заполни пустые такты и спой мелодию.

## Emakesele
URL: https://www.opiq.ee/kit/237/chapter/13441
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 17.4
Topics ET: matemaatika, emakesele
Topics RU: математика
Topics EN: mathematics
Headings: Emakesele
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прочитай стихотворение и запиши его ритм. Сочини к ритму ступени и спой песенку.

## Зачем светят звёзды?
URL: https://www.opiq.ee/kit/237/chapter/13442
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 18.1
Topics ET: matemaatika
Topics RU: математика, зачем, светят
Topics EN: mathematics
Headings: Зачем светят звёзды?; ЗАЧЕМ СВЕТЯТ ЗВЁЗДЫ
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Спой мелодию и сыграй ритм на тамбурине.

## Metsamuusika
URL: https://www.opiq.ee/kit/237/chapter/13443
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 18.2
Topics ET: matemaatika, metsamuusika
Topics RU: математика
Topics EN: mathematics
Headings: Metsamuusika
Task examples: Разгадай кроссворд – узнаешь имя дедушки Полифона.

## Как у наших у ворот
URL: https://www.opiq.ee/kit/237/chapter/13444
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 18.3
Topics ET: matemaatika
Topics RU: математика, наших, ворот
Topics EN: mathematics
Headings: Как у наших у ворот
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Определи и запиши размер такта. Спойте мелодию в каноне.

## Во поле берёза стояла
URL: https://www.opiq.ee/kit/237/chapter/13445
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 18.4
Topics ET: matemaatika
Topics RU: математика, поле, стояла
Topics EN: mathematics
Headings: Во поле берёза стояла
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прочитай стихотворение и запиши ритм одного четверостишия. Сочини мелодию со ступенями MI-LE-JO и спой песню.

## Самая счастливая
URL: https://www.opiq.ee/kit/237/chapter/13446
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 18.5
Topics ET: matemaatika
Topics RU: математика, самая, счастливая
Topics EN: mathematics
Headings: Самая счастливая
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сочини на заданный ритм мелодию, запиши и спой её.

## Живёт на свете красота
URL: https://www.opiq.ee/kit/237/chapter/13447
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 18.6
Topics ET: matemaatika
Topics RU: математика, свете, красота
Topics EN: mathematics
Headings: Живёт на свете красота
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выучи обе мелодии. Спойте в группах.

## Вместе весело шагать
URL: https://www.opiq.ee/kit/237/chapter/13448
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 18.7
Topics ET: matemaatika
Topics RU: математика, вместе, весело, шагать, давай, вспомним
Topics EN: mathematics
Headings: Вместе весело шагать; ДАВАЙ ВСПОМНИМ!
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прочитай стихотворения. Подпиши под ступенями ритм. Спой ступени, показывая их рукой.

## Дети, в школу собирайтесь!
URL: https://www.opiq.ee/kit/237/chapter/13363
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, дети, школу, собирайтесь
Topics EN: mathematics
Headings: Дети, в школу собирайтесь!
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ.

## Laula, laula, lapsuke
URL: https://www.opiq.ee/kit/237/chapter/13364
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 2.2
Topics ET: matemaatika, laula, lapsuke
Topics RU: математика
Topics EN: mathematics
Headings: Laula, laula, lapsuke
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ.

## Чему учат в школе
URL: https://www.opiq.ee/kit/237/chapter/13365
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, чему, учат, школе
Topics EN: mathematics
Headings: Чему учат в школе

## Песенка про буквы
URL: https://www.opiq.ee/kit/237/chapter/13366
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, песенка, буквы
Topics EN: mathematics
Headings: Песенка про буквы
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прохлопай упражнения. К одному из них придумай слова. Например,

## Школьные частушки
URL: https://www.opiq.ee/kit/237/chapter/13367
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, школьные, частушки
Topics EN: mathematics
Headings: Школьные частушки
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Найди повторяющийся ритм в стихотворении «Дом под крыльцом». Запиши ритм и исполни его на тамбурине.

## Десять лунатиков
URL: https://www.opiq.ee/kit/237/chapter/13368
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, десять, лунатиков
Topics EN: mathematics
Headings: Десять лунатиков

## Наш учитель
URL: https://www.opiq.ee/kit/237/chapter/13369
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, учитель
Topics EN: mathematics
Headings: Наш учитель
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прочитай четверостишие про дрозда на с. 96 учебника и прохлопай его ритм. Запиши ритм первой строчки.

## Marsilaul
URL: https://www.opiq.ee/kit/237/chapter/13370
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 3.1
Topics ET: matemaatika, marsilaul
Topics RU: математика
Topics EN: mathematics
Headings: Marsilaul
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сыграй ритм кружек на треугольнике и запиши его.

## Ходит Ваня
URL: https://www.opiq.ee/kit/237/chapter/13371
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, ходит, ваня
Topics EN: mathematics
Headings: Ходит Ваня
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прочитай стихотворение «Отличные пшеничные» на с. 52 и исполни его ритм на бубне. Найди и запиши повторяющийся ритм.

## Оловянные солдаты
URL: https://www.opiq.ee/kit/237/chapter/13372
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, оловянные, солдаты
Topics EN: mathematics
Headings: Оловянные солдаты
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши ритм своего имени и имён своих друзей.

## Танец
URL: https://www.opiq.ee/kit/237/chapter/13373
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, танец
Topics EN: mathematics
Headings: Танец
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прохлопай ритм, придумай к нему слова и запиши их. Например,

## Laste marss
URL: https://www.opiq.ee/kit/237/chapter/13374
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 3.5
Topics ET: matemaatika, laste, marss
Topics RU: математика
Topics EN: mathematics
Headings: Laste marss
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Смастери инструмент из разных гвоздей и сыграй на нём ритм.

## Осень наступила
URL: https://www.opiq.ee/kit/237/chapter/13375
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 4.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, наступила
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Осень наступила

## Осень
URL: https://www.opiq.ee/kit/237/chapter/13376
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 4.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Осень
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Какая песня («Капельки», «Кто пасётся на лугу?» или «Осень») начинается с этого ритма?

## Капельки
URL: https://www.opiq.ee/kit/237/chapter/13377
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, капельки, старик, годовик
Topics EN: mathematics
Headings: Капельки; СТАРИК-ГОДОВИК

## Времена года
URL: https://www.opiq.ee/kit/237/chapter/13378
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 4.4
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, времена, года
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Времена года
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Найди пульс четверостишия, сильные доли выдели более звонкими хлопками. Запиши повторяющийся ритм.

## Сердце музыки
URL: https://www.opiq.ee/kit/237/chapter/13379
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, сердце, музыки
Topics EN: mathematics
Headings: Сердце музыки

## Кузнец
URL: https://www.opiq.ee/kit/237/chapter/13380
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, кузнец, кроссворд, тактовая, черта
Topics EN: mathematics
Headings: Кузнец; ТАКТОВАЯ ЧЕРТА

## Üks, kaks, alati!
URL: https://www.opiq.ee/kit/237/chapter/13381
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 5.3
Topics ET: matemaatika, kaks, alati
Topics RU: математика
Topics EN: mathematics
Headings: Üks, kaks, alati!
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Нарисуй картинку о дружбе кошки с мышкой.

## Весёлый музыкант
URL: https://www.opiq.ee/kit/237/chapter/13382
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, музыкант, дорогой, друг
Topics EN: mathematics
Headings: Весёлый музыкант; ДОРОГОЙ ДРУГ!
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Выпиши ритм слов первого куплета песни «Ходит Ваня» (с. 20), подчеркни в нём сильные доли.

## Мир похож на цветной луг
URL: https://www.opiq.ee/kit/237/chapter/13383
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, похож, цветной
Topics EN: mathematics
Headings: Мир похож на цветной луг
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прохлопай следующие ритмы, прочитай с одним из них своё любимое стихотворение.

## Лучше папы друга нет
URL: https://www.opiq.ee/kit/237/chapter/13384
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, лучше, папы, друга
Topics EN: mathematics
Headings: Лучше папы друга нет

## Дружат дети всей земли
URL: https://www.opiq.ee/kit/237/chapter/13385
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, дружат, дети, всей, земли
Topics EN: mathematics
Headings: Дружат дети всей земли

## С нами, друг!
URL: https://www.opiq.ee/kit/237/chapter/13386
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 6.4
Topics ET: matemaatika
Topics RU: математика, нами, друг
Topics EN: mathematics
Headings: С нами, друг!
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прочитай два четверостишия – на с. 25 и на с. 73, прохлопай их ритм. Запиши ритм двух первых строчек четверостиший, сравни их.

## Про ослика
URL: https://www.opiq.ee/kit/237/chapter/13387
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.1
Topics ET: matemaatika
Topics RU: математика, ослика
Topics EN: mathematics
Headings: Про ослика
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ.

## Наша песенка простая
URL: https://www.opiq.ee/kit/237/chapter/13388
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.2
Topics ET: matemaatika
Topics RU: математика, наша, песенка, простая
Topics EN: mathematics
Headings: Наша песенка простая
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Научись правильно рисовать паузу ШАГ.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сыграй ритм молотков на пандейре и запиши его.

## Рак-отшельник
URL: https://www.opiq.ee/kit/237/chapter/13389
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.3
Topics ET: matemaatika
Topics RU: математика, отшельник
Topics EN: mathematics
Headings: Рак-отшельник
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Рассели по домикам тех, кто издаёт высокие или низкие звуки: медведь, соловей, мышка, сова, машина скорой помощи, комар, гром, корова.

## Õunake
URL: https://www.opiq.ee/kit/237/chapter/13390
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.4
Topics ET: matemaatika, õunake
Topics RU: математика
Topics EN: mathematics
Headings: Õunake
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сосчитай и отметь линейки нотоносца (с. 59).; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сосчитай и отметь промежутки нотоносца (с. 59).

## Андрей-воробей
URL: https://www.opiq.ee/kit/237/chapter/13391
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.5
Topics ET: matemaatika
Topics RU: математика, андрей, воробей
Topics EN: mathematics
Headings: Андрей-воробей
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Простучи и запиши ритм стишка со с. 50. Сочини его продолжение.

## Барашеньки
URL: https://www.opiq.ee/kit/237/chapter/13392
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.6
Topics ET: matemaatika
Topics RU: математика, барашеньки
Topics EN: mathematics
Headings: Барашеньки; КУ-КУ
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Научись записывать ступени на нотоносце.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Продолжи запись цветными карандашами.

## Sõit, sõit sinna
URL: https://www.opiq.ee/kit/237/chapter/13393
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.7
Topics ET: matemaatika, sõit, sinna
Topics RU: математика, отличные, пшеничные
Topics EN: mathematics
Headings: Sõit, sõit sinna; SO И MI; ОТЛИЧНЫЕ ПШЕНИЧНЫЕ
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Найди и запиши на нотоносце ступени МI цветными карандашами.

## Песенка поварят
URL: https://www.opiq.ee/kit/237/chapter/13394
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 7.8
Topics ET: matemaatika
Topics RU: математика, песенка, поварят
Topics EN: mathematics
Headings: Песенка поварят
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Продолжи запись цветным карандашом. Штили у нот записываются с правой стороны вверх.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши мелодию на нотоносце и спой её.

## Первые снежинки
URL: https://www.opiq.ee/kit/237/chapter/13395
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 8.1
Topics ET: matemaatika
Topics RU: математика, первые, снежинки, снег
Topics EN: mathematics
Headings: Первые снежинки; ЭХО; RA; СНЕГ
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Начиная с третьей линейки ноты переворачиваются вместе со штилями. Теперь штили будут записываться с левой стороны нот вниз. Продолжи запись (штили вверх – красным, вниз – зелёным каран

## Sajab lund
URL: https://www.opiq.ee/kit/237/chapter/13396
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 8.2
Topics ET: matemaatika, sajab, lund
Topics RU: математика
Topics EN: mathematics
Headings: Sajab lund
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Простучи ритм. Спой с ним песню «Sajab lund» (с. 57). Нарисуй снежную бабу.

## Lumemees
URL: https://www.opiq.ee/kit/237/chapter/13397
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 8.3
Topics ET: matemaatika, lumemees
Topics RU: математика
Topics EN: mathematics
Headings: Lumemees
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Спой мелодии, показывай рукой ступени.

## Хоровод снежинок
URL: https://www.opiq.ee/kit/237/chapter/13398
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 8.4
Topics ET: matemaatika
Topics RU: математика, хоровод, снежинок
Topics EN: mathematics
Headings: Хоровод снежинок
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Сыграй ритм на бубне и треугольнике вместе с соседом. Под один из ритмов спойте вместе песню «Ёлочка» (с. 68).

## Põdra maja
URL: https://www.opiq.ee/kit/237/chapter/13399
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 8.5
Topics ET: matemaatika, põdra, maja
Topics RU: математика
Topics EN: mathematics
Headings: Põdra maja
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Найди и запиши цветными карандашами ступени SО.

## Пёстрый колпачок
URL: https://www.opiq.ee/kit/237/chapter/13400
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 8.6
Topics ET: matemaatika
Topics RU: математика, стрый, колпачок, праздник, рождества
Topics EN: mathematics
Headings: Пёстрый колпачок; ПРАЗДНИК РОЖДЕСТВА.
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Прочитай стихотворение на с. 63, найди в нём повторяющийся ритм. Запиши ритм в тетрадь и сыграй его на кастаньетах.

## Igal lapsel oma ingel
URL: https://www.opiq.ee/kit/237/chapter/13401
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 9.1
Topics ET: matemaatika, igal, lapsel, ingel
Topics RU: математика
Topics EN: mathematics
Headings: Igal lapsel oma ingel
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши ступени на нотоносце и спой получившиеся мелодии.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши мелодию эстонской народной песни на нотоносце. Спой её с названием ступеней, затем со словами.

## Зимняя сказка
URL: https://www.opiq.ee/kit/237/chapter/13402
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 9.2
Topics ET: matemaatika
Topics RU: математика, зимняя, сказка
Topics EN: mathematics
Headings: Зимняя сказка
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Простучи ритм двумя руками: одна – по столу, другая – по коленям или исполните ритм в группах.

## Ёлочка
URL: https://www.opiq.ee/kit/237/chapter/13403
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 9.3
Topics ET: matemaatika
Topics RU: математика, лочка, давай, вспомним
Topics EN: mathematics
Headings: Ёлочка; ДАВАЙ ВСПОМНИМ!

## Разноцветная песенка
URL: https://www.opiq.ee/kit/237/chapter/13404
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 9.4
Topics ET: matemaatika
Topics RU: математика, разноцветная, песенка, новым, годом
Topics EN: mathematics
Headings: Разноцветная песенка; С НОВЫМ ГОДОМ!

## Голубые санки
URL: https://www.opiq.ee/kit/237/chapter/13405
Book: muusika­õpetus
Class: 
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: музыка_–_волшебная_страна._1_класс
Chapter ID: 9.5
Topics ET: matemaatika
Topics RU: математика, голубые, санки
Topics EN: mathematics
Headings: Голубые санки
Task examples: ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Найди ступень RА, запиши её на нотоносце. Спой получившуюся мелодию.; ВЫПОЛНИ ЗАДАНИЕ В РАБОЧЕЙ ТЕТРАДИ. Запиши ступени на нотоносце и спой их.
