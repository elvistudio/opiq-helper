## English step by step 1 – Opiq
URL: https://www.opiq.ee/Kit/Details/452
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 107
Topics ET: matemaatika, english, step, opiq
Topics RU: математика
Topics EN: mathematics

## English step by step 1 – Opiq
URL: https://www.opiq.ee/Kit/Details/452
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 197
Topics ET: matemaatika, english, step, opiq
Topics RU: математика
Topics EN: mathematics

## LESSON ONE
URL: https://www.opiq.ee/kit/452/chapter/24569
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 1.1
Topics ET: matemaatika, lesson, back, school, listen, answer, grammar, structures, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON ONE; WE ARE BACK AT SCHOOL; Listen; Lesson 1; Ask and answer; Grammar and structures; Dialogue

## LESSON TEN
URL: https://www.opiq.ee/kit/452/chapter/24578
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 10.1
Topics ET: matemaatika, lesson, listen, answer, grammar, structures, john, singing
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TEN; Listen; Ask and answer; Grammar and structures; IS JOHN SINGING?

## LESSON ELEVEN
URL: https://www.opiq.ee/kit/452/chapter/24579
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 11.1
Topics ET: matemaatika, lesson, eleven, dialogue, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON ELEVEN; Lesson 11; Dialogue; Grammar and structures; Ask and answer

## LESSON TWELVE
URL: https://www.opiq.ee/kit/452/chapter/24580
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 12.1
Topics ET: matemaatika, lesson, twelve, grammar, structures, answer, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWELVE; Lesson 12; Grammar and structures; Ask and answer; Dialogue

## LESSON THIRTEEN
URL: https://www.opiq.ee/kit/452/chapter/24581
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 13.1
Topics ET: matemaatika, lesson, thirteen, grammar, structures, dialogue, what, mary, doing
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTEEN; Lesson 13; Grammar and structures; Dialogue; WHAT IS MARY DOING?

## LESSON FOURTEEN
URL: https://www.opiq.ee/kit/452/chapter/24582
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 14.1
Topics ET: matemaatika, lesson, fourteen, grammar, structures, answer, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FOURTEEN; Lesson 14; Grammar and structures; Ask and answer; Dialogue

## LESSON FIFTEEN
URL: https://www.opiq.ee/kit/452/chapter/24583
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 15.1
Topics ET: matemaatika, lesson, fifteen, listen, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTEEN; Listen; Dialogue; Grammar and structures; ONE, TWO ...

## LESSON SIXTEEN
URL: https://www.opiq.ee/kit/452/chapter/24584
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 16.1
Topics ET: matemaatika, lesson, sixteen, grammar, structures, answer, many, pencils, have
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTEEN; Lesson 16; Grammar and structures; Ask and answer; HOW MANY PENCILS HAVE YOU GOT?

## LESSON SEVENTEEN
URL: https://www.opiq.ee/kit/452/chapter/24585
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 17.1
Topics ET: matemaatika, lesson, seventeen, grammar, structures, dialogue, answer, poem
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTEEN; Lesson 17; Grammar and structures; Dialogue; Ask and answer; POEM

## LESSON EIGHTEEN
URL: https://www.opiq.ee/kit/452/chapter/24586
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 18.1
Topics ET: matemaatika, lesson, eighteen, dialogue, grammar, structures, what, colour
Topics RU: математика
Topics EN: mathematics
Headings: LESSON EIGHTEEN; Lesson 18; Dialogue; Grammar and structures; WHAT COLOUR IS THE BED?

## LESSON NINETEEN
URL: https://www.opiq.ee/kit/452/chapter/24587
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 19.1
Topics ET: matemaatika, lesson, nineteen, listen, grammar, structures, what, colour
Topics RU: математика
Topics EN: mathematics
Headings: LESSON NINETEEN; Listen; Grammar and structures; What colour is it?

## LESSON TWO
URL: https://www.opiq.ee/kit/452/chapter/24570
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 2.1
Topics ET: matemaatika, lesson, listen, grammar, structures, dialogue, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWO; Listen; Grammar and structures; Dialogue; Ask and answer

## LESSON TWENTY
URL: https://www.opiq.ee/kit/452/chapter/24588
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 20.1
Topics ET: matemaatika, lesson, twenty, grammar, structures, dialogue, this, cake, these, cakes
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY; Lesson 20; Grammar and structures; Dialogue; THIS IS A CAKE, THESE ARE CAKES

## LESSON TWENTY-ONE
URL: https://www.opiq.ee/kit/452/chapter/24589
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 21.1
Topics ET: matemaatika, lesson, twenty, grammar, structures, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-ONE; Lesson 21; Grammar and structures; Dialogue

## LESSON TWENTY-TWO
URL: https://www.opiq.ee/kit/452/chapter/24590
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 22.1
Topics ET: matemaatika, lesson, twenty, dialogue, grammar, structures, answer, poem
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-TWO; Lesson 22; Dialogue; Grammar and structures; Ask and answer; POEM

## LESSON TWENTY-THREE
URL: https://www.opiq.ee/kit/452/chapter/24591
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 23.1
Topics ET: matemaatika, lesson, twenty, three, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-THREE; Lesson 23; Dialogue; Grammar and structures

## LESSON TWENTY-FOUR
URL: https://www.opiq.ee/kit/452/chapter/24592
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 24.1
Topics ET: matemaatika, lesson, twenty, four, blacky, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-FOUR; BLACKY; Ask and answer

## LESSON TWENTY-FIVE
URL: https://www.opiq.ee/kit/452/chapter/24593
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 25.1
Topics ET: matemaatika, lesson, twenty, five, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-FIVE; Lesson 25; Dialogue; Grammar and structures

## LESSON TWENTY-SIX
URL: https://www.opiq.ee/kit/452/chapter/24594
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 26.1
Topics ET: matemaatika, lesson, twenty, harry, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-SIX; HARRY; Ask and answer

## LESSON TWENTY-SEVEN
URL: https://www.opiq.ee/kit/452/chapter/24595
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 27.1
Topics ET: matemaatika, lesson, twenty, seven, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-SEVEN; Lesson 27; Ask and answer

## LESSON TWENTY-EIGHT
URL: https://www.opiq.ee/kit/452/chapter/24596
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 28.1
Topics ET: matemaatika, lesson, twenty, eight, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-EIGHT; Lesson 28; Grammar and structures

## LESSON TWENTY-NINE
URL: https://www.opiq.ee/kit/452/chapter/24597
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 29.1
Topics ET: matemaatika, lesson, twenty, nine, three, friends, dialogue, this, bike
Topics RU: математика
Topics EN: mathematics
Headings: LESSON TWENTY-NINE; THREE FRIENDS; Dialogue; THIS IS MY BIKE

## LESSON THREE
URL: https://www.opiq.ee/kit/452/chapter/24571
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 3.1
Topics ET: matemaatika, lesson, three, listen, grammar, structures, answer, dialogue, have
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THREE; Listen; Grammar and structures; Ask and answer; Dialogue; HAVE YOU GOT A CAT?

## LESSON THIRTY
URL: https://www.opiq.ee/kit/452/chapter/24598
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 30.1
Topics ET: matemaatika, lesson, thirty, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY; Lesson 30; Dialogue; Grammar and structures

## LESSON THIRTY-ONE
URL: https://www.opiq.ee/kit/452/chapter/24599
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 31.1
Topics ET: matemaatika, lesson, thirty, classroom, dialogue, answer, this, teacher
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-ONE; OUR CLASSROOM; Dialogue; Ask and answer; THIS IS A TEACHER

## LESSON THIRTY-TWO
URL: https://www.opiq.ee/kit/452/chapter/24600
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 32.1
Topics ET: matemaatika, lesson, thirty, answer, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-TWO; Lesson 32; Ask and answer; Dialogue; Grammar and structures

## LESSON THIRTY-THREE
URL: https://www.opiq.ee/kit/452/chapter/24601
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 33.1
Topics ET: matemaatika, lesson, thirty, three, schoolchildren, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-THREE; WE ARE ALL SCHOOLCHILDREN; Grammar and structures; Ask and answer

## LESSON THIRTY-FOUR
URL: https://www.opiq.ee/kit/452/chapter/24602
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 34.1
Topics ET: matemaatika, lesson, thirty, four, grammar, structures, there, picture, wall
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-FOUR; Lesson 34; Grammar and structures; THERE IS A PICTURE ON THE WALL

## LESSON THIRTY-FIVE
URL: https://www.opiq.ee/kit/452/chapter/24603
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 35.1
Topics ET: matemaatika, lesson, thirty, five, answer, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-FIVE; Lesson 35; Ask and answer; Dialogue; Grammar and structures

## LESSON THIRTY-SIX
URL: https://www.opiq.ee/kit/452/chapter/24604
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 36.1
Topics ET: matemaatika, lesson, thirty, grammar, structures, answer, there, books, desk
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-SIX; Lesson 36; Grammar and structures; Ask and answer; THERE ARE BOOKS ON MY DESK

## LESSON THIRTY-SEVEN
URL: https://www.opiq.ee/kit/452/chapter/24605
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 37.1
Topics ET: matemaatika, lesson, thirty, seven, room, dialogue, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-SEVEN; MY ROOM; Dialogue; Ask and answer

## LESSON THIRTY-EIGHT
URL: https://www.opiq.ee/kit/452/chapter/24606
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 38.1
Topics ET: matemaatika, lesson, thirty, eight, living, room, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-EIGHT; OUR LIVING-ROOM; Grammar and structures; Ask and answer

## LESSON THIRTY-NINE
URL: https://www.opiq.ee/kit/452/chapter/24607
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 39.1
Topics ET: matemaatika, lesson, thirty, nine, answer, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON THIRTY-NINE; Lesson 39; Ask and answer; Dialogue

## LESSON FOUR
URL: https://www.opiq.ee/kit/452/chapter/24572
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 4.1
Topics ET: matemaatika, lesson, four, listen, grammar, structures, answer, what, have
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FOUR; Listen; Grammar and structures; Ask and answer; WHAT HAVE YOU GOT, MEL?

## LESSON FORTY
URL: https://www.opiq.ee/kit/452/chapter/24608
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 40.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, lesson, forty, poem, answer
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: LESSON FORTY; Lesson 40; POEM; Ask and answer; IT IS WINTER

## LESSON FORTY-ONE
URL: https://www.opiq.ee/kit/452/chapter/24609
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 41.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, lesson, forty, grammar, structures, dialogue, answer
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: LESSON FORTY-ONE; WINTER; Grammar and structures; Dialogue; Ask and answer

## LESSON FORTY-TWO
URL: https://www.opiq.ee/kit/452/chapter/24610
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 42.1
Topics ET: matemaatika, lesson, forty, grammar, structures, harry, pencil
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FORTY-TWO; Lesson 42; Grammar and structures; HARRY’S PENCIL IS NEW

## LESSON FORTY-THREE
URL: https://www.opiq.ee/kit/452/chapter/24611
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 43.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, lesson, forty, three, answer
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: LESSON FORTY-THREE; THE BODY; Ask and answer

## LESSON FORTY-FOUR
URL: https://www.opiq.ee/kit/452/chapter/24612
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 44.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, lesson, forty, four, answer, poem
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: LESSON FORTY-FOUR; THE BODY; Ask and answer; POEM

## LESSON FORTY-FIVE
URL: https://www.opiq.ee/kit/452/chapter/24613
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 45.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, lesson, forty, five
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: LESSON FORTY-FIVE; THE BODY

## LESSON FORTY-SIX
URL: https://www.opiq.ee/kit/452/chapter/24614
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 46.1
Topics ET: matemaatika, lesson, forty, grammar, structures, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FORTY-SIX; Lesson 46; Grammar and structures; Dialogue

## LESSON FORTY-SEVEN
URL: https://www.opiq.ee/kit/452/chapter/24615
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 47.1
Topics ET: matemaatika, lesson, forty, seven, dialogue, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FORTY-SEVEN; Lesson 47; Dialogue; Grammar and structures; SAY AND ANSWER!

## LESSON FORTY-EIGHT
URL: https://www.opiq.ee/kit/452/chapter/24616
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 48.1
Topics ET: matemaatika, lesson, forty, eight, family, answer, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FORTY-EIGHT; MEL’S FAMILY; Ask and answer; Dialogue; Grammar and structures

## LESSON FORTY-NINE
URL: https://www.opiq.ee/kit/452/chapter/24617
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 49.1
Topics ET: matemaatika, lesson, forty, nine, family, dialogue, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FORTY-NINE; TOM’S FAMILY; Dialogue; Grammar and structures; Ask and answer

## LESSON FIVE
URL: https://www.opiq.ee/kit/452/chapter/24573
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 5.1
Topics ET: matemaatika, lesson, five, listen, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIVE; Listen; Grammar and structures; Ask and answer

## LESSON FIFTY
URL: https://www.opiq.ee/kit/452/chapter/24618
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 50.1
Topics ET: matemaatika, lesson, fifty, best, friend, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY; MY BEST FRIEND; Ask and answer

## LESSON FIFTY-ONE
URL: https://www.opiq.ee/kit/452/chapter/24619
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 51.1
Topics ET: matemaatika, lesson, fifty, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-ONE; Lesson 51; Ask and answer

## LESSON FIFTY-TWO
URL: https://www.opiq.ee/kit/452/chapter/24620
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 52.1
Topics ET: matemaatika, lesson, fifty, grammar, structures, dialogue, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-TWO; lesson 52; Grammar and structures; Dialogue; Ask and answer; I CAN SAY HI

## LESSON FIFTY-THREE
URL: https://www.opiq.ee/kit/452/chapter/24621
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 53.1
Topics ET: matemaatika, lesson, fifty, three, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-THREE; Lesson 53; Dialogue; Grammar and structures

## LESSON FIFTY-FOUR
URL: https://www.opiq.ee/kit/452/chapter/24622
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 54.1
Topics ET: matemaatika, lesson, fifty, four, walk, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-FOUR; I CAN WALK; Grammar and structures; Ask and answer

## LESSON FIFTY-FIVE
URL: https://www.opiq.ee/kit/452/chapter/24623
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 55.1
Topics ET: matemaatika, lesson, fifty, five, katja, help, grammar, structures, answer, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-FIVE; KATJA CAN HELP; Grammar and structures; Ask and answer; Dialogue

## LESSON FIFTY-SIX
URL: https://www.opiq.ee/kit/452/chapter/24624
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 56.1
Topics ET: matemaatika, lesson, fifty, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-SIX; Lesson 56; Grammar and structures; Ask and answer

## LESSON FIFTY-SEVEN
URL: https://www.opiq.ee/kit/452/chapter/24625
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 57.1
Topics ET: matemaatika, lesson, fifty, seven, breakfa, ready, answer, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-SEVEN; BREAKFA ST IS READY!; Ask and answer; Grammar and structures

## LESSON FIFTY-EIGHT
URL: https://www.opiq.ee/kit/452/chapter/24626
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 58.1
Topics ET: matemaatika, lesson, fifty, eight, tidying, room, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-EIGHT; TIDYING MY ROOM; Dialogue; CAN A PIG WA LK?

## LESSON FIFTY-NINE
URL: https://www.opiq.ee/kit/452/chapter/24627
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 59.1
Topics ET: matemaatika, lesson, fifty, nine, jane, answer, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON FIFTY-NINE; JANE’S DAY; Ask and answer; Grammar and structures

## LESSON SIX
URL: https://www.opiq.ee/kit/452/chapter/24574
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 6.1
Topics ET: matemaatika, lesson, listen, grammar, structures, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIX; Listen; Grammar and structures; Dialogue

## LESSON SIXTY
URL: https://www.opiq.ee/kit/452/chapter/24628
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 60.1
Topics ET: matemaatika, lesson, sixty, polly, grammar, structures, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY; POLLY A ND BEN; Grammar and structures; Ask and answer

## LESSON SIXTY-ONE
URL: https://www.opiq.ee/kit/452/chapter/24629
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 61.1
Topics ET: matemaatika, lesson, sixty, jane, getting, dressed, answer, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-ONE; MEL AND JANE ARE GETTING DRESSED; Ask and answer; Dialogue; Grammar and structures

## LESSON SIXTY-TWO
URL: https://www.opiq.ee/kit/452/chapter/24630
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 62.1
Topics ET: matemaatika, lesson, sixty, what, they, wearing, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-TWO; WHAT ARE THEY WEARING?; Ask and answer

## LESSON SIXTY-THREE
URL: https://www.opiq.ee/kit/452/chapter/24631
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 63.1
Topics ET: matemaatika, lesson, sixty, three, anne, grammar, structures, answer, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-THREE; SAL AND ANNE; Grammar and structures; Ask and answer; Dialogue

## LESSON SIXTY-FOUR
URL: https://www.opiq.ee/kit/452/chapter/24632
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 64.1
Topics ET: matemaatika, aeg, kell, kalender, lesson, sixty, four, what, answer, grammar, structures
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: LESSON SIXTY-FOUR; WHAT ’S THE TIME?; Ask and answer; Grammar and structures

## LESSON SIXTY-FIVE
URL: https://www.opiq.ee/kit/452/chapter/24633
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 65.1
Topics ET: matemaatika, lesson, sixty, five, lsson, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-FIVE; Lsson 65; Grammar and structures

## LESSON SIXTY-SIX
URL: https://www.opiq.ee/kit/452/chapter/24634
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 66.1
Topics ET: matemaatika, lesson, sixty, what, they, doing, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-SIX; WHAT ARE THEY DOING?; Dialogue; Grammar and structures; WHAT ARE YOU DO ING?

## LESSON SIXTY-SEVEN
URL: https://www.opiq.ee/kit/452/chapter/24635
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 67.1
Topics ET: matemaatika, lesson, sixty, seven, listen, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-SEVEN; Listen; Grammar and structures

## LESSON SIXTY-EIGHT
URL: https://www.opiq.ee/kit/452/chapter/24636
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 68.1
Topics ET: matemaatika, lesson, sixty, eight, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-EIGHT; MY DAY; Ask and answer

## LESSON SIXTY-NINE
URL: https://www.opiq.ee/kit/452/chapter/24637
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 69.1
Topics ET: matemaatika, lesson, sixty, nine, garden, answer, dialogue, grammar, structures, read
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SIXTY-NINE; THE GARDEN; Ask and answer; Dialogue; Grammar and structures; DO YOU READ EVERY DAY?

## LESSON SEVEN
URL: https://www.opiq.ee/kit/452/chapter/24575
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 7.1
Topics ET: matemaatika, lesson, seven, grammar, structures, answer, dialogue, this, that
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVEN; Lesson 7; Grammar and structures; Ask and answer; Dialogue; THIS THAT

## LESSON SEVENTY
URL: https://www.opiq.ee/kit/452/chapter/24638
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 70.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, lesson, seventy, grammar, structures, answer, dialogue
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: LESSON SEVENTY; SPRING; Grammar and structures; Ask and answer; Dialogue

## LESSON SEVENTY-ONE
URL: https://www.opiq.ee/kit/452/chapter/24639
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 71.1
Topics ET: matemaatika, lesson, seventy, tell, about, yourself, grammar, structures, dialogue, what
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-ONE; TELL ME ABOUT YOURSELF!; Grammar and structures; Dialogue; WHAT DO YOU DO AT SCHOOL?

## LESSON SEVENTY-TWO
URL: https://www.opiq.ee/kit/452/chapter/24640
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 72.1
Topics ET: matemaatika, lesson, seventy, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-TWO; Lesson 72; Ask and answer

## LESSON SEVENTY-THREE
URL: https://www.opiq.ee/kit/452/chapter/24641
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 73.1
Topics ET: matemaatika, lesson, seventy, three, best, friend, grammar, structures, dialogue, does
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-THREE; MY BEST FRIEND; Grammar and structures; Dialogue; DOES YOUR FRIEND LIKE DOGS?

## LESSON SEVENTY-FOUR
URL: https://www.opiq.ee/kit/452/chapter/24642
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 74.1
Topics ET: matemaatika, lesson, seventy, four, dialogue, answer
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-FOUR; Dialogue; Ask and answer

## LESSON SEVENTY-FIVE
URL: https://www.opiq.ee/kit/452/chapter/24643
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 75.1
Topics ET: matemaatika, lesson, seventy, five, little, eyes, grammar, structures, read
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-FIVE; Lesson 75; TWO LITTLE EYES; Grammar and structures; READ AND SAY!

## LESSON SEVENTY-SIX
URL: https://www.opiq.ee/kit/452/chapter/24644
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 76.1
Topics ET: matemaatika, lesson, seventy, dialogue, grammar, structures, answer, listen
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-SIX; Dialogue; Grammar and structures; Ask and answer; Listen

## LESSON SEVENTY-SEVEN
URL: https://www.opiq.ee/kit/452/chapter/24645
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 77.1
Topics ET: matemaatika, lesson, seventy, seven, dialogue, grammar, structures, answer, what, does
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-SEVEN; Dialogue; Grammar and structures; Ask and answer; WHAT DOES SHE HAVE IN HER ROOM?

## LESSON SEVENTY-EIGHT
URL: https://www.opiq.ee/kit/452/chapter/24646
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 78.1
Topics ET: matemaatika, lesson, seventy, eight, study, finnish, grammar, structures, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-EIGHT; I DON’T STUDY FINNISH ...; Grammar and structures; Dialogue

## LESSON SEVENTY-NINE
URL: https://www.opiq.ee/kit/452/chapter/24647
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 79.1
Topics ET: matemaatika, lesson, seventy, nine, back, street, boys, answer, dialogue
Topics RU: математика
Topics EN: mathematics
Headings: LESSON SEVENTY-NINE; BACK STREET BOYS; Ask and answer; Dialogue

## LESSON EIGHT
URL: https://www.opiq.ee/kit/452/chapter/24576
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 8.1
Topics ET: matemaatika, lesson, eight, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON EIGHT; Lesson 8; Dialogue; Grammar and structures

## LESSON EIGHTY
URL: https://www.opiq.ee/kit/452/chapter/24648
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 80.1
Topics ET: matemaatika, lesson, eighty, sundays, dialogue, what
Topics RU: математика
Topics EN: mathematics
Headings: LESSON EIGHTY; SUNDAYS; Dialogue; WHAT DO YOU DO ...

## HALLOWEEN
URL: https://www.opiq.ee/kit/452/chapter/24649
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.1
Topics ET: matemaatika, halloween, exercise
Topics RU: математика
Topics EN: mathematics
Headings: HALLOWEEN; EXERCISE 1; EXERCISE 2; EXERCISE 3

## CHRISTMAS
URL: https://www.opiq.ee/kit/452/chapter/24650
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.2
Topics ET: matemaatika, christmas, exercise, poem, cards, jingle, bells, wish, merry
Topics RU: математика
Topics EN: mathematics
Headings: CHRISTMAS; EXERCISE 1; A CHRISTMAS POEM; CHRISTMAS CARDS; JINGLE BELLS; WE WISH YOU A MERRY CHRISTMAS; EXERCISE 2.1; EXERCISE 2.2

## VALENTINE’S DAY
URL: https://www.opiq.ee/kit/452/chapter/24651
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.3
Topics ET: matemaatika, valentine, exercise, cards, poem
Topics RU: математика
Topics EN: mathematics
Headings: VALENTINE’S DAY; EXERCISE 1.1; VALENTINE CARDS; VALENTINE’S DAY POEM; EXERCISE 1.2; EXERCISE 2; EXERCISE 3

## EASTER
URL: https://www.opiq.ee/kit/452/chapter/24652
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.4
Topics ET: matemaatika, easter, exercise, bunny, humpty, dumpty
Topics RU: математика
Topics EN: mathematics
Headings: EASTER; EXERCISE 1; THE EASTER BUNNY; HUMPTY DUMPTY; EXERCISE 2; EXERCISE 3

## MOTHER’S DAY
URL: https://www.opiq.ee/kit/452/chapter/24653
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.5
Topics ET: matemaatika, mother, exercise, poem
Topics RU: математика
Topics EN: mathematics
Headings: MOTHER’S DAY; EXERCISE 1; MOTHER’S DAY POEM; EXERCISE 2; EXERCISE 3

## HOLIDAYS REVISION
URL: https://www.opiq.ee/kit/452/chapter/24654
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.6
Topics ET: matemaatika, kordamine, korda, harjutan, holidays, exercise
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: HOLIDAYS REVISION; EXERCISE 1

## READ AND ACT
URL: https://www.opiq.ee/kit/452/chapter/24655
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.7
Topics ET: matemaatika, read, exercise, little, riding, hood
Topics RU: математика
Topics EN: mathematics
Headings: READ AND ACT; EXERCISE 1; LITTLE RED RIDING HOOD; EXERCISE 2

## A PLAY
URL: https://www.opiq.ee/kit/452/chapter/24656
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 81.8
Topics ET: matemaatika, play, scene
Topics RU: математика
Topics EN: mathematics
Headings: A PLAY; Scene 1; Scene 2; Scene 3; Scene 4; Scene 5

## Definitions
URL: https://www.opiq.ee/kit/452/chapter/24657
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 82.1
Topics ET: matemaatika, definitions
Topics RU: математика
Topics EN: mathematics
Headings: Definitions

## LESSON NINE
URL: https://www.opiq.ee/kit/452/chapter/24577
Book: English step by step 1 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: english_step_by_step_1
Chapter ID: 9.1
Topics ET: matemaatika, lesson, nine, listen, answer, dialogue, grammar, structures
Topics RU: математика
Topics EN: mathematics
Headings: LESSON NINE; Listen; Ask and answer; Dialogue; Grammar and structures

## High Five! 3 – Opiq
URL: https://www.opiq.ee/Kit/Details/369
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 1
Topics ET: matemaatika, high, five, opiq
Topics RU: математика
Topics EN: mathematics

## High Five! 3 – Opiq
URL: https://www.opiq.ee/Kit/Details/369
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 106
Topics ET: matemaatika, high, five, opiq
Topics RU: математика
Topics EN: mathematics

## Hello!
URL: https://www.opiq.ee/kit/369/chapter/20206
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 1.1
Topics ET: matemaatika, hello, harjutus, nice, meet, practise, speak
Topics RU: математика
Topics EN: mathematics
Headings: Hello!; Harjutus 1; Nice to meet you!; Harjutus 2; 2D; 2A; 2B; 2C; Let’s practise!; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; Harjutus 6; Harjutus 7; Let’s speak!; Harjutus 8; Harjutus 9

## Colourful London
URL: https://www.opiq.ee/kit/369/chapter/20207
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 1.2
Topics ET: matemaatika, colourful, london, welcome, harjutus, great, britain, symbols, sights, colours
Topics RU: математика
Topics EN: mathematics
Headings: Colourful London; Welcome to London!; Harjutus 1; 1C; 1A; 1B; London and Great Britain symbols and sights; Harjutus 2; 2D; 2A; 2B; 2C; Harjutus 3; 3F; 3A; 3B; 3C; 3D; 3E; Colours are everywhere!; Harjutus 4; 4F; 4A; 4B; 4C; 4D; 4E; Harjutus 5; 5C; 5A; 5B; Harjutus 6; 6B; 6A; Summary; Harjutus 7; 7G; 7A; 7B; 7C; 7D; 7E; 7F; Harjutus 8; 8E; 8A; 8B; 8C; 8D; Harjutus 9; 9B; 9A; Harjutus 10

## Welcome!
URL: https://www.opiq.ee/kit/369/chapter/20208
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 1.3
Topics ET: matemaatika, arv, arvud, arvu, numbrid, welcome, greetings, harjutus
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Welcome!; Greetings; Harjutus 1; 1E; 1A; 1B; 1C; 1D; Harjutus 2; 2E; 2A; 2B; 2C; 2D; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; 5B; 5A; Harjutus 6; 6C; 6A; 6B; Numbers; Harjutus 7; 7B; 7A; Harjutus 8; Harjutus 9; 9A; 9B; 9C; 9D; 9E; 9F; 9G; 9H

## Module 1 Review
URL: https://www.opiq.ee/kit/369/chapter/20209
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 1.4
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kordamine, korda, harjutan, module, countries, characters, harjutus, greetings, colours, õpin
Topics RU: математика, число, числа, цифры, повторение, повтори, тренировка
Topics EN: mathematics, number, numbers, digits, revision, review, practice
Headings: Module 1 Review; Countries and characters; Harjutus 1; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Greetings; Harjutus 5; Harjutus 6; 6B; 6A; Harjutus 7; 7B; 7A; Harjutus 8; 8E; 8A; 8B; 8С; 8D; Colours; Harjutus 9; 9D; 9A; 9B; 9C; Harjutus 10; 10B; 10A; Harjutus 11; 11B; 11A; Numbers; Harjutus 12; 12C; 12A; 12B; Harjutus 13; 13G; 13A; 13B; 13C; 13D; 13E; 13F; Nii õpin inglise keelt!; Harjutus 14

## Aa, Bb, Cc, Dd, Ee, Ff
URL: https://www.opiq.ee/kit/369/chapter/21202
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 10.1
Topics ET: matemaatika, saagem, tuttavaks, inglise, keele, tähestikuga, harjutus, tähed, õpime, tähti
Topics RU: математика
Topics EN: mathematics
Headings: Aa, Bb, Cc, Dd, Ee, Ff; Saagem tuttavaks inglise keele tähestikuga; Harjutus 1; Tähed Aa, Bb, Cc, Dd, Ee, Ff; Harjutus 2; 2B; 2A; Õpime tähti kirjutama; Harjutame; Harjutus 3; 3B; 3A; Harjutus 4; 4C; 4A; 4B; Harjutus 5; 5C; 5A; 5B; Harjutus 6; 6D; 6A; 6B; 6C; Harjuta veel! A, B, C, D, E, F sõnades; Harjutus 7; 7D; 7A; 7B; 7C; Harjutus 8; 8B; 8A

## Gg, Hh, Ii, Jj, Kk, Ll
URL: https://www.opiq.ee/kit/369/chapter/21203
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 10.2
Topics ET: matemaatika, laulame, tähestikulaulu, tähed, harjutus, õpime, tähti, kirjutama, harjutame, harjuta
Topics RU: математика
Topics EN: mathematics
Headings: Gg, Hh, Ii, Jj, Kk, Ll; Laulame tähestikulaulu; Tähed Gg, Hh, Ii, Jj, Kk, Ll; Harjutus 1; 1D; 1A; 1B; 1C; Õpime tähti kirjutama; Harjutame; Harjutus 2; 2C; 2A; 2B; Harjutus 3; 3B; 3A; Harjutus 4; 4C; 4A; 4B; Harjutus 5; 5F; 5A; 5B; 5C; 5D; 5E; Harjutus 6; 6C*; 6A; 6B; Harjuta veel! G, H, I, J, K, L sõnades; Harjutus 7; 7D; 7A; 7B; 7C; Harjutus 8; 8B; 8A

## Mm, Nn, Oo, Pp, Qq
URL: https://www.opiq.ee/kit/369/chapter/21204
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 10.3
Topics ET: matemaatika, laulame, tähestikulaulu, tähed, harjutus, õpime, tähti, kirjutama, harjutame, harjuta
Topics RU: математика
Topics EN: mathematics
Headings: Mm, Nn, Oo, Pp, Qq; Laulame tähestikulaulu; Tähed Mm, Nn, Oo, Pp, Qq; Harjutus 1; 1B; 1A; Õpime tähti kirjutama; Harjutame; Harjutus 2; 2C; 2A; 2B; Harjutus 3; Harjutus 4; 4C; 4A; 4B; Harjutus 5*; Harjutus 6; 6C; 6A; 6B; Harjuta veel! M, N, O, P, Q sõnades; Harjutus 7; 7B; 7A; Harjutus 8; 8B; 8A

## Rr, Ss, Tt, Uu, Vv
URL: https://www.opiq.ee/kit/369/chapter/21205
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 10.4
Topics ET: matemaatika, laulame, tähestikulaulu, tähed, harjutus, õpime, tähti, kirjutama, harjutame, harjuta
Topics RU: математика
Topics EN: mathematics
Headings: Rr, Ss, Tt, Uu, Vv; Laulame tähestikulaulu; Tähed Rr, Ss, Tt, Uu, Vv; Harjutus 1; Õpime tähti kirjutama; Harjutame; Harjutus 2; 2B; 2A; Harjutus 3; 3C; 3A; 3B; Harjutus 4; 4B; 4A; Harjutus 5; 5D; 5A; 5B; 5C; Harjuta veel! R, S, T, U, V sõnades; Harjutus 6; 6B; 6A; Harjutus 7

## Ww, Xx, Yy, Zz
URL: https://www.opiq.ee/kit/369/chapter/21206
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 10.5
Topics ET: matemaatika, kordamine, korda, harjutan, laulame, tähestikulaulu, tähed, harjutus, õpime, tähti, kirjutama, harjutame, harjuta
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Ww, Xx, Yy, Zz; Laulame tähestikulaulu; Tähed Ww, Xx, Yy, Zz; Harjutus 1; 1B; 1A; Õpime tähti kirjutama; Harjutame; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; Harjuta veel! W, X, Y, Z sõnades; Harjutus 4; 4B; 4A; Harjutus 5; Tähestiku kordamine; Harjutus 6; 6B; 6A; Harjutus 7; 7D; 7A; 7B; 7C; Harjutus 8; 8B; 8A; Harjutus 9; Harjutus 10; 10E; 10A; 10B; 10C; 10D; Harjutus 11; 11C; 11A; 11B

## Definitions
URL: https://www.opiq.ee/kit/369/chapter/23950
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 11.1
Topics ET: matemaatika, definitions
Topics RU: математика
Topics EN: mathematics
Headings: Definitions

## Impressum
URL: https://www.opiq.ee/kit/369/chapter/22552
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 11.2
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Chapter 1. Let’s Count!
URL: https://www.opiq.ee/kit/369/chapter/20210
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.1
Topics ET: matemaatika, arv, arvud, arvu, numbrid, chapter, count, little, fingers, practise, harjutus, introducing, myself
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Chapter 1. Let’s Count!; Ten little fingers; Numbers 1–12; Let’s practise!; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4B; 4A; Introducing myself; Harjutus 5; 5B; 5A; Harjutus 6; Summary; Harjutus 7; Harjutus 8; 8C; 8A; 8B; Harjutus 9; Harjutus 10; Harjutus 11; 11B; 11A

## Action! Are You Two?
URL: https://www.opiq.ee/kit/369/chapter/20938
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.10
Topics ET: matemaatika, action, happy, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! Are You Two?; Are you two?; Are you happy?; Harjutus 1; Harjutus 2; 2C; 2A; 2B; Go ahead!; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5

## Chapter 3. Do You Have a Pet?
URL: https://www.opiq.ee/kit/369/chapter/20939
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.11
Topics ET: matemaatika, loom, loomad, linnud, putukad, chapter, have, practise, harjutus
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Chapter 3. Do You Have a Pet?; Do you have a pet?; Animals; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; 4C; 4A; 4B; Harjutus 5; Is it a/an ...?; Do you have...?; Harjutus 6; Harjutus 7; Harjutus 8; 8C; 8A; 8B; Harjutus 9; Harjutus 10; Harjutus 11

## Go Ahead! Animals
URL: https://www.opiq.ee/kit/369/chapter/20940
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.12
Topics ET: matemaatika, loom, loomad, linnud, putukad, ahead, other, practise, harjutus, summary
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Go Ahead! Animals; Other animals; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; Summary; Harjutus 5; 5B; 5A; Harjutus 6; Harjutus 7; Harjutus 8

## So Many Animals!
URL: https://www.opiq.ee/kit/369/chapter/20941
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.13
Topics ET: matemaatika, loom, loomad, linnud, putukad, many, reading, have, raamatust, tulevad, ütleb, kumb
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: So Many Animals!; Reading; Now you have a pet!; Mis loomad raamatust tulevad?; Kes nii ütleb?; Kumb lause on tekstis?; Kuidas said tekstist aru?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21388
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.14
Topics ET: matemaatika, practise, listen, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Listen!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; The more you know

## Action! So Many Balls!
URL: https://www.opiq.ee/kit/369/chapter/20942
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.15
Topics ET: matemaatika, action, many, balls, book, books, pane, tähele, mitu, kontrolli
Topics RU: математика
Topics EN: mathematics
Headings: Action! So Many Balls!; So many balls!; A book? Books!; Pane tähele!; Üks või mitu?; Kontrolli ennast!; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2C; 2A; 2B; Harjutus 3; Harjutus 4; How many...?; Harjutus 5; Harjutus 6; Harjutus 7; Harjutus 8; 8B; 8A

## Chapter 4. Rattingham Palace
URL: https://www.opiq.ee/kit/369/chapter/20943
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.16
Topics ET: matemaatika, chapter, rattingham, palace, welcome, please, come, peaks, pildil, olema
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 4. Rattingham Palace; Welcome to the palace!; Welcome! Please, come in!; Kes peaks pildil olema?; Kuidas on eesti keeles?; Õige järjekord; Kes nii ütleb?; Kuidas said tekstist aru?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21389
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.17
Topics ET: matemaatika, practise, welcome, friend, words, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Welcome, my friend!; Words in use; Harjutus 1; Harjutus 2; Harjutus 3; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; 5C; 5A; 5B; Harjutus 6; 6B; 6A; Harjutus 7

## Module 2 Review
URL: https://www.opiq.ee/kit/369/chapter/20944
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.18
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kordamine, korda, harjutan, module, high, five, characters, olid, tähelepanelik, polite, harjutus
Topics RU: математика, число, числа, цифры, повторение, повтори, тренировка
Topics EN: mathematics, number, numbers, digits, revision, review, practice
Headings: Module 2 Review; High Five! characters; Kas sa olid tähelepanelik?; Be polite!; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Numbers and colours; Harjutus 3; 3B; 3A; Harjutus 4; 4C; 4A; 4B; I have ... / I don’t have ...; Harjutus 5; Harjutus 6; 6E; 6A; 6B; 6C; 6D; He, she or it; Harjutus 7; 7C; 7A; 7B; Harjutus 8; Questions and answers; Harjutus 10; Harjutus 9; 9B; 9A; Harjutus 11; 11C; 11A; 11B; Harjutus 12; 12F; 12A; 12B; 12C; 12D; 12E; My family and I; Tekst „My family“; Harjutus 13; Harjutus 14; 14B; 14A

## Family Members
URL: https://www.opiq.ee/kit/369/chapter/20211
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.2
Topics ET: matemaatika, family, members, practise, harjutus, this, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Family Members; Who is who?; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4B; 4A; My family; This is my...; Harjutus 5; Harjutus 6; 6B; 6A; Harjutus 7; Harjutus 8; Go ahead!; Harjutus 9; 9B; 9A; Harjutus 10; Harjutus 11

## The King Family
URL: https://www.opiq.ee/kit/369/chapter/20212
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.3
Topics ET: matemaatika, king, family, reading, nice, meet, nende, nimed, ütleb, õige
Topics RU: математика
Topics EN: mathematics
Headings: The King Family; Reading; Nice to meet you!; Mis nende nimed on?; Kes nii ütleb?; Õige lause lõpp; Õige järjekord; Kuidas sa tekstist aru said?; Sõnad lauseteks; Kui hästi sa sõnu tead?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21386
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.4
Topics ET: matemaatika, practise, hello, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Hi, hello!; Words in use; Harjutus 1; Harjutus 2; Harjutus 3; Let’s speak!; Harjutus 4; Harjutus 5; 5D; 5A; 5B; 5C; Harjutus 6; 6B; 6A; Harjutus 7; The more you know

## Action! I’m, You’re ...
URL: https://www.opiq.ee/kit/369/chapter/20213
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.5
Topics ET: matemaatika, action, kontrolli, ennast, practise, harjutus, others, ahead, nuputa
Topics RU: математика
Topics EN: mathematics
Headings: Action! I’m, You’re ...; I’m, you’re ...; I’m a rat!; Kontrolli ennast!; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Me and others; Harjutus 4; Go ahead!; Nuputa!; Harjutus 5; 5B; 5A; Harjutus 6; 6C; 6A; 6B

## Chapter 2. Toys and Things
URL: https://www.opiq.ee/kit/369/chapter/20935
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.6
Topics ET: matemaatika, chapter, toys, things, around, harjutus, article, summary
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 2. Toys and Things; Toys and things; Things around us; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3D; 3A; 3B; 3C; Article a/an; Harjutus 4; 4B; 4A; Harjutus 5; Harjutus 6; 6C; 6A; 6B; Summary; Harjutus 7; 7D; 7A; 7B; 7C; Harjutus 8; 8B; 8A

## What’s This? Is It a Present?
URL: https://www.opiq.ee/kit/369/chapter/20936
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.7
Topics ET: matemaatika, what, this, present, monster, harjutus, kontrolli, ennast, game, speak
Topics RU: математика
Topics EN: mathematics
Headings: What’s This? Is It a Present?; It’s a monster; Harjutus 1; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; What’s this?; Harjutus 4; 4B; 4A; Kontrolli ennast!; Is it a game?; Harjutus 5; Harjutus 6; 6C; 6A; 6B; Harjutus 7; Let’s speak!; Harjutus 8; 8D; 8A; 8B; 8C

## Happy Birthday!
URL: https://www.opiq.ee/kit/369/chapter/20937
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.8
Topics ET: matemaatika, happy, birthday, look, your, presents, charlie, here, kuidas, eesti
Topics RU: математика
Topics EN: mathematics
Headings: Happy Birthday!; Look, your presents!; How old is Charlie?; Here you are!; Kuidas on eesti keeles?; Kes nii ütleb?; Milline lause sobib pildiga?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21387
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 2.9
Topics ET: matemaatika, practise, your, birthday, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; It’s your birthday!; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; Let’s speak!; Harjutus 5; 5D; 5A; 5B; 5C; Harjutus 4; 4B; 4A; Harjutus 6; The more you know

## Chapter 5. Chips? Yes, Please.
URL: https://www.opiq.ee/kit/369/chapter/20945
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.1
Topics ET: matemaatika, chapter, chips, please, fast, food, snacks, practise, harjutus, hungry
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 5. Chips? Yes, Please.; Chips? Yes, please.; Fast food and snacks; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5; Harjutus 6; 6C; 6A; 6B; I’m hungry; Harjutus 7; Harjutus 8; 8B; 8A; Harjutus 9; Harjutus 10; Harjutus 11

## Sounds Good! [p] and [b]
URL: https://www.opiq.ee/kit/369/chapter/20952
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.10
Topics ET: matemaatika, sounds, good, transcription, häälduse, kirjapanek, märkimine, kirjas, kumb, häälik
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [p] and [b]; Transcription (häälduse kirjapanek); Häälduse märkimine kirjas; [p] and [b]; Kumb häälik?; Harjutus 1; 1B; 1A; Let’s pronounce!; Harjutus 2; 2B; 2A; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Harjutus 3

## Chapter 7. Where’s the Cat?
URL: https://www.opiq.ee/kit/369/chapter/20953
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.11
Topics ET: matemaatika, chapter, where, house, practise, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 7. Where’s the Cat?; Where’s the cat?; In a house; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; 5C; 5A; 5B; Harjutus 6; 6D; 6A; 6B; 6C; Harjutus 7; Where are you?; Harjutus 8; Harjutus 9; Harjutus 10; Harjutus 11; 11E; 11A; 11B; 11C; 11D

## Go Ahead! In a House
URL: https://www.opiq.ee/kit/369/chapter/20954
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.12
Topics ET: matemaatika, ahead, house, room, practise, harjutus, summary
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! In a House; In a room; Let’s practise!; Harjutus 1; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; Harjutus 5; 5C; 5A; 5B; Harjutus 6; 6D; 6A; 6B; 6C; Summary; Harjutus 7; 7C; 7A; 7B; Harjutus 8; 8C; 8A; 8B; Harjutus 9

## Numbers 13–20
URL: https://www.opiq.ee/kit/369/chapter/20955
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.13
Topics ET: matemaatika, arv, arvud, arvu, numbrid, count, practise, harjutus, summary
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Numbers 13–20; Let’s count!; Let’s practise!; Harjutus 1; Harjutus 2; 2C; 2A; 2B; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; Summary; Harjutus 6; Harjutus 7; 7B; 7A; Harjutus 8; Harjutus 9; Harjutus 10

## Where Are You?
URL: https://www.opiq.ee/kit/369/chapter/20956
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.14
Topics ET: matemaatika, where, reading, castle, ütleb, mida, võib, rüütli, lossist, leida
Topics RU: математика
Topics EN: mathematics
Headings: Where Are You?; Reading; In a castle; Kes nii ütleb?; Mida võib rüütli lossist leida?; Õige lauselõpp; Kuidas said tekstist aru?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21636
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.15
Topics ET: matemaatika, practise, where, words, harjutus, speak, more, know, suurbritannias
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Do, do, do, where are you?; Words in use; Harjutus 2; Harjutus 1; Harjutus 3; Harjutus 4; Let’s speak!; Harjutus 5; Harjutus 6; Harjutus 7; The more you know; Elu Suurbritannias; Harjutus 8; 8C; 8A; 8B

## Sounds Good! [k] and [g]
URL: https://www.opiq.ee/kit/369/chapter/20957
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.16
Topics ET: matemaatika, sounds, good, kumb, häälik, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [k] and [g]; [k] and [g]; Kumb häälik?; Harjutus 1; 1B; 1A; Let’s pronounce!; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Harjutus 5

## Chapter 8. Rosie’s Tea Party
URL: https://www.opiq.ee/kit/369/chapter/20958
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.17
Topics ET: matemaatika, chapter, rosie, party, some, have, cake, please, kuidas, inglise
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 8. Rosie’s Tea Party; Some tea?; Can I have some cake, please?; Kuidas on see inglise keeles?; Kust saad teada?; Kes nii ütleb?; Kuidas said tekstist aru?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21637
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.18
Topics ET: matemaatika, practise, rosie, party, words, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; It is Rosie’s tea party; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Harjutus 4; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; 6C; 6A; 6B

## Module 3 Review
URL: https://www.opiq.ee/kit/369/chapter/20959
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.19
Topics ET: matemaatika, kordamine, korda, harjutan, module, check, yourself, hästi, mäletad, fast, food, snacks
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Module 3 Review; Check yourself!; Kui hästi sa mäletad?; Fast food, snacks and drinks; Harjutus 2; 2B; 2A; Harjutus 1; Harjutus 3; 3B; 3A; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Let’s eat!; Harjutus 5; 5B; 5A; Harjutus 6; Harjutus 7; Harjutus 8; 8B; 8A; In a house; Harjutus 9; Harjutus 10; Harjutus 11; Let’s count!; Harjutus 12; Harjutus 13; Harjutus 14; Sounds good!; Harjutus 15; 15D; 15A; 15B; 15C; Harjutus 16; 16D; 16A; 16B; 16C

## Go Ahead! Food and Drinks
URL: https://www.opiq.ee/kit/369/chapter/20946
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.2
Topics ET: matemaatika, ahead, food, drinks, snacks, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Food and Drinks; Snacks and drinks; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; 4D; 4A; 4B; 4C; Let’s speak!; Harjutus 5; Harjutus 6; 6B; 6A; Harjutus 7

## Blue Juice?
URL: https://www.opiq.ee/kit/369/chapter/20947
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.3
Topics ET: matemaatika, blue, juice, reading, picnic, ütleb, mida, võtab, simon, raamatust
Topics RU: математика
Topics EN: mathematics
Headings: Blue Juice?; Reading; On a picnic; Kes nii ütleb?; Mida võtab Simon raamatust välja?; Charliele maitseb...; Õige järjekord; Kuidas said tekstist aru?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21634
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.4
Topics ET: matemaatika, practise, would, choose, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; If I would choose; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Let’s speak!; Harjutus 5; Harjutus 6; 6C; 6A; 6B; Harjutus 7; 7B; 7A; Harjutus 8; The more you know

## Action! I Like ...
URL: https://www.opiq.ee/kit/369/chapter/20948
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.5
Topics ET: matemaatika, action, like, pane, tähele, practise, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! I Like ...; I like ...; Do you like ...?; Pane tähele!; Let’s practise!; Harjutus 1; Harjutus 2; 2D; 2A; 2B; 2C; Harjutus 3; Harjutus 4; Harjutus 5; Go ahead!; Harjutus 6; Harjutus 7

## Chapter 6. Spaghetti, Please.
URL: https://www.opiq.ee/kit/369/chapter/20949
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.6
Topics ET: matemaatika, chapter, spaghetti, please, chicken, rice, food, drinks, practise, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 6. Spaghetti, Please.; Chicken and rice; Food and drinks; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3D; 3A; 3B; 3C; Harjutus 4; 4B; 4A; Harjutus 5; 5E; 5A; 5B; 5C; 5D; Table etiquette; Harjutus 6; Harjutus 7; 7D; 7A; 7B; 7C; Harjutus 8

## Go Ahead! Carrots or Bananas?
URL: https://www.opiq.ee/kit/369/chapter/20950
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.7
Topics ET: matemaatika, ahead, carrots, bananas, more, food, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Carrots or Bananas?; More food; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4D; 4A; 4B; 4C; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; 6D; 6A; 6B; 6C

## Dinner’s Ready!
URL: https://www.opiq.ee/kit/369/chapter/20951
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.8
Topics ET: matemaatika, dinner, ready, reading, have, seat, please, ütleb, kuidas, inglise
Topics RU: математика
Topics EN: mathematics
Headings: Dinner’s Ready!; Reading; Have a seat, please!; Kes nii ütleb?; Kuidas on inglise keeles?; Millistest söökidest-jookidest tekstis räägiti?; Kas õige või vale?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21635
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 3.9
Topics ET: matemaatika, practise, yummy, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; It was yummy!; Words in use; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; 6E; 6A; 6B; 6C; 6D; Harjutus 7; 7C; 7A; 7B; The more you know

## Chapter 9. What Day Is It Today?
URL: https://www.opiq.ee/kit/369/chapter/20960
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.1
Topics ET: matemaatika, aeg, kell, kalender, chapter, what, today, week, harjutus, practise
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Chapter 9. What Day Is It Today?; The week; Day and time; Harjutus 1; 1B; 1A; Harjutus 2; Let’s practise!; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A; Harjutus 7; What day is it today?; Harjutus 8; Harjutus 9; Harjutus 10; 10D; 10A; 10B; 10C

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21863
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.10
Topics ET: matemaatika, practise, sing, dance, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics, with
Headings: Let’s Practise!; Sing and dance; Words in use; Harjutus 1; Harjutus 2; Harjutus 3; 3B; 3A; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; 5B; 5A; The more you know; Can you dance with me?

## Action! Yes, I Can!
URL: https://www.opiq.ee/kit/369/chapter/20968
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.11
Topics ET: matemaatika, action, sing, practise, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! Yes, I Can!; I can run; Can you sing? – Yes, I can.; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; 4B; 4A; Go ahead!

## Chapter 11. Tick, Tock
URL: https://www.opiq.ee/kit/369/chapter/20969
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.12
Topics ET: matemaatika, chapter, tick, tock, wake, practise, harjutus, when, play, football
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 11. Tick, Tock; Tick, tock; Wake up!; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3E; 3A; 3B; 3C; 3D; Harjutus 4; 4B; 4A; Harjutus 5; When do you play football?; Kontolli ennast!; Harjutus 6; Harjutus 7; 7B; 7A

## Go Ahead! Let’s Play Basketball!
URL: https://www.opiq.ee/kit/369/chapter/20970
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.13
Topics ET: matemaatika, ahead, play, basketball, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Let’s Play Basketball!; Let’s play ...; Let’s practise!; Harjutus 1; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; 5C; 5A; 5B; Let’s speak!; Harjutus 6

## Go, High Five!
URL: https://www.opiq.ee/kit/369/chapter/20971
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.14
Topics ET: matemaatika, high, five, reading, best, ütleb, millest, tekstis, räägiti, õige
Topics RU: математика
Topics EN: mathematics
Headings: Go, High Five!; Reading; High Five is the best!; Kes nii ütleb?; Millest tekstis räägiti?; Kas õige või vale?; Mis lause see on?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21864
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.15
Topics ET: matemaatika, practise, high, five, märgi, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; FC High Five; Märgi ära; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4B; 4A; Let’s speak!; Harjutus 5; Harjutus 6; 6B; 6A; The more you know; Let’s play!

## Sounds Good! [s] and [ʃ]
URL: https://www.opiq.ee/kit/369/chapter/20972
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.16
Topics ET: matemaatika, sounds, good, snake, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [s] and [ʃ]; Snake; [s] and [ʃ]; Harjutus 1; 1C; 1A; 1B; Let’s pronounce!; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5

## Chapter 12. Wake up, Charlie!
URL: https://www.opiq.ee/kit/369/chapter/20973
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.17
Topics ET: matemaatika, chapter, wake, charlie, wednesday, kuidas, eesti, keeles, ütleb, õige
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 12. Wake up, Charlie!; Wake up, Charlie!; Wake me up on Wednesday; Kuidas on eesti keeles?; Kes nii ütleb?; Õige järjekord; Mida me täna teeme?; Kuidas said tekstist aru?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21865
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.18
Topics ET: matemaatika, practise, wake, charlie, words, harjutus, speak, friday, monday, tuesday
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Wake up, Charlie!; Words in use; Harjutus 1; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6; Friday; Monday; Tuesday; Wednesday; Thursday

## Module 4 Review
URL: https://www.opiq.ee/kit/369/chapter/20974
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.19
Topics ET: matemaatika, aeg, kell, kalender, kordamine, korda, harjutan, module, harjutus, swim, when, summary
Topics RU: математика, время, часы, календарь, повторение, повтори, тренировка
Topics EN: mathematics, time, clock, calendar, revision, review, practice
Headings: Module 4 Review; Day and time; Harjutus 1; 1A; 1B; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Harjutus 5; 5C; 5A; 5B; Can you swim?; Harjutus 6; 6B; 6A; Harjutus 7; Harjutus 8; 8C; 8A; 8B; 8E; 8D; When do you go to bed?; Harjutus 9; 9B; 9A; Harjutus 10; Harjutus 11; 11B; 11A; Summary; Harjutus 12; 12B; 12A; Harjutus 13; 13B; 13A; Harjutus 14

## Go Ahead! Just a Minute
URL: https://www.opiq.ee/kit/369/chapter/20961
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.2
Topics ET: matemaatika, aeg, kell, kalender, ahead, just, minute, practise, harjutus, summary
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Go Ahead! Just a Minute; Day and time; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Harjutus 5; 5E; 5A; 5B; 5C; 5D; Summary; Harjutus 6; Harjutus 7; 7B; 7A

## Numbers (10–100)
URL: https://www.opiq.ee/kit/369/chapter/20962
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.3
Topics ET: matemaatika, arv, arvud, arvu, numbrid, count, practise, harjutus, summary
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Numbers (10–100); Let’s count!; Let’s practise!; Harjutus 1; 1С; 1A; 1B; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; Harjutus 5; 5B; 5A; Summary; Harjutus 6; Harjutus 7

## Poor Cuckoo!
URL: https://www.opiq.ee/kit/369/chapter/20963
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.4
Topics ET: matemaatika, poor, cuckoo, reading, what, matter, ütleb, milliseid, numbreid, kuulsid
Topics RU: математика
Topics EN: mathematics
Headings: Poor Cuckoo!; Reading; What’s the matter?; Kes nii ütleb?; Milliseid numbreid sa kuulsid?; Kuidas said tekstist aru?; Mis lause see on?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21862
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.5
Topics ET: matemaatika, aeg, kell, kalender, practise, poor, cuckoo, words, harjutus, speak, more, know
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Let’s Practise!; Poor cuckoo clock; Words in use; Harjutus 1; 1B; 1A; Harjutus 2; 2D; 2A; 2B; 2C; Harjutus 3; 3B; 3A; Let’s speak!; Harjutus 4; 4B; 4A; Harjutus 5; The more you know

## Sounds Good! [t] and [d]
URL: https://www.opiq.ee/kit/369/chapter/20964
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.6
Topics ET: matemaatika, sounds, good, häälik, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [t] and [d]; ​[t] and [d]; Mis häälik?; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Let’s pronounce!; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; 5B; 5A

## Chapter 10. What Can I Do?
URL: https://www.opiq.ee/kit/369/chapter/20965
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.7
Topics ET: matemaatika, chapter, what, practise, harjutus, jump
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 10. What Can I Do?; What can I do?; I can fly; Let’s practise!; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Can you jump?; Harjutus 5; Harjutus 6; Harjutus 7; Harjutus 8; 8B; 8A

## Go Ahead! I Can Cook
URL: https://www.opiq.ee/kit/369/chapter/20966
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.8
Topics ET: matemaatika, ahead, cook, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! I Can Cook; Let’s ski!; Let’s practise!; Harjutus 1; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Let’s speak!; Harjutus 5; Harjutus 6

## Great Dancers
URL: https://www.opiq.ee/kit/369/chapter/20967
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 4.9
Topics ET: matemaatika, great, dancers, reading, dancer, ütleb, õige, lause, lõpp, vale
Topics RU: математика
Topics EN: mathematics
Headings: Great Dancers; Reading; You are a great dancer!; Kes nii ütleb?; Õige lause lõpp; Kas õige või vale?; Mis sõna puudub?

## Chapter 13. Touch Your Nose
URL: https://www.opiq.ee/kit/369/chapter/20975
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, chapter, touch, your, nose, parts, kehaosad, practise, harjutus
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Chapter 13. Touch Your Nose; Touch your nose; Body parts (kehaosad); Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2C; 2A; 2B; Harjutus 3; Harjutus 4; Harjutus 5; 5B; 5A; Harjutus 6; 6C; 6A; 6B; She has long hair; Harjutus 7; 7B; 7A; Harjutus 8; Harjutus 9; 9B; 9A

## Action! Off We Go!
URL: https://www.opiq.ee/kit/369/chapter/21193
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.10
Topics ET: matemaatika, action, they, practise, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! Off We Go!; Off we go!; We’re, you’re, they’re; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; Harjutus 4; 4B; 4A; Harjutus 5; 5C; 5A; 5B; Go ahead!; Harjutus 6; Harjutus 7

## Chapter 15. Let’s Go!
URL: https://www.opiq.ee/kit/369/chapter/21194
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.11
Topics ET: matemaatika, chapter, play, harjutus, practise, skateboarding, kontrolli, ennast
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 15. Let’s Go!; Let’s go!; Let’s play!; Harjutus 1; Let’s practise!; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Harjutus 5; Harjutus 6; Let’s go skateboarding!; Kontrolli ennast!; Harjutus 7; Harjutus 8; 8D; 8A; 8B; 8C

## Go Ahead! Let’s Have a Picnic!
URL: https://www.opiq.ee/kit/369/chapter/21195
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.12
Topics ET: matemaatika, ahead, have, picnic, party, harjutus, practise, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Let’s Have a Picnic!; Let’s have a party!; Harjutus 1; Let’s practise!; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A; Let’s speak!; Harjutus 7; Harjutus 8; 8B; 8A

## An Amazing Day
URL: https://www.opiq.ee/kit/369/chapter/21196
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.13
Topics ET: matemaatika, amazing, reading, travel, ütleb, kumb, lause, tekstis, õige, vastus
Topics RU: математика
Topics EN: mathematics
Headings: An Amazing Day; Reading; Let’s travel a bit!; Kes nii ütleb?; Kumb lause on tekstis?; Õige vastus; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21925
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.14
Topics ET: matemaatika, practise, amazing, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; An amazing day; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Harjutus 3; 3C; 3A; 3B; Harjutus 4; Let’s speak!; Harjutus 5; Harjutus 6; The more you know

## Sounds Good! [θ] and [ð]
URL: https://www.opiq.ee/kit/369/chapter/21197
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.15
Topics ET: matemaatika, sounds, good, here, there, kumb, häälik, harjutus, pronounce
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good! [θ] and [ð]; Here, there; [θ] and [ð]; Kumb häälik?; Harjutus 1; 1B; 1A; Let’s pronounce!; Harjutus 2; Harjutus 3; Harjutus 4; 4B; 4A

## Chapter 16. You Never Know!
URL: https://www.opiq.ee/kit/369/chapter/21198
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.16
Topics ET: matemaatika, chapter, never, know, what, lovely, millest, tekstis, räägiti, ütleb
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 16. You Never Know!; You never know; What a lovely day!; Millest tekstis räägiti?; Kes nii ütleb?; Kust saad teada?; Õige järjekord

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21926
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.17
Topics ET: matemaatika, practise, holiday, words, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; We go on holiday; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2C; 2A; 2B; Harjutus 3; 3B; 3A; Harjutus 4; Let’s speak!; Harjutus 5; 5B; 5A; Harjutus 6

## Module 5 Review
URL: https://www.opiq.ee/kit/369/chapter/21199
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.18
Topics ET: matemaatika, kordamine, korda, harjutan, inimene, keha, meeled, tervis, module, parts, harjutus, mäletad, clothes, swimming, they
Topics RU: математика, повторение, повтори, тренировка, человек, тело, чувства, здоровье
Topics EN: mathematics, revision, review, practice, human, body, senses, health
Headings: Module 5 Review; Body parts; Harjutus 1; 1C; 1A; 1B; Harjutus 2; Harjutus 3; 3B; 3A; Harjutus 4; Kas mäletad?; Clothes; Harjutus 6; Harjutus 5; 5B; 5A; Harjutus 7; 7B; 7A; Let’s go swimming!; Harjutus 8; Harjutus 9; 9B; 9A; They’re there!; Harjutus 10; 10B; 10A; Häälda õigesti!

## Go Ahead! Head, Shoulders, Knees and Toes
URL: https://www.opiq.ee/kit/369/chapter/20976
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.2
Topics ET: matemaatika, ahead, head, shoulders, knees, toes, paws, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Head, Shoulders, Knees and Toes; He has two paws; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; Harjutus 4; 4F; 4A; 4B; 4C; 4D; Let’s speak!; Harjutus 5; Harjutus 6; 6B; 6A

## A Night at the Bookshop
URL: https://www.opiq.ee/kit/369/chapter/20977
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.3
Topics ET: matemaatika, night, bookshop, reading, make, shadows, look, ütleb, millest, tekstis
Topics RU: математика
Topics EN: mathematics
Headings: A Night at the Bookshop; Reading; Let’s make shadows. Look!; Kes nii ütleb?; Millest tekstis räägiti?; Kumb lause on tekstis?; Õige järjekord; Missugune vastus on õige?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21923
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.4
Topics ET: matemaatika, aeg, kell, kalender, practise, sleep, words, harjutus, speak, more, know, monster
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Let’s Practise!; Time to sleep; Words in use; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; Harjutus 4; 4B; 4A; Let’s speak!; Harjutus 5; Harjutus 6; The more you know; A monster in a lake?

## Action! I Have a Tiger, He Has a Lion
URL: https://www.opiq.ee/kit/369/chapter/20978
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.5
Topics ET: matemaatika, action, have, tiger, lion, mouse, practise, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: Action! I Have a Tiger, He Has a Lion; I have a mouse; She has a dog; Let’s practise!; Harjutus 2; Harjutus 1; Harjutus 3; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Harjutus 5; Go ahead!; Harjutus 6; Harjutus 7; 7B; 7A

## Chapter 14. Socks and Shoes
URL: https://www.opiq.ee/kit/369/chapter/21190
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.6
Topics ET: matemaatika, chapter, socks, shoes, clothes, riided, practise, harjutus, whose, shirt
Topics RU: математика
Topics EN: mathematics
Headings: Chapter 14. Socks and Shoes; Socks and shoes; Clothes (riided); Let’s practise!; Harjutus 2; 2B; 2A; Harjutus 1; 1С; 1A; 1B; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; Harjutus 6; Whose T-shirt is this?; Harjutus 7; Harjutus 8; Harjutus 9; 9B; 9A

## Go Ahead! Whose Jacket Is This?
URL: https://www.opiq.ee/kit/369/chapter/21191
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.7
Topics ET: matemaatika, ahead, whose, jacket, this, more, clothes, practise, harjutus, speak
Topics RU: математика
Topics EN: mathematics
Headings: Go Ahead! Whose Jacket Is This?; More clothes; Let’s practise!; Harjutus 1; 1B; 1A; Harjutus 2; Harjutus 3; 3D; 3A; 3B; 3C; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Let’s speak!; Harjutus 5; Harjutus 6; 6D; 6A; 6B; 6C; Kellele asi või ese kuulub?; Harjutus 7

## What a Mess!
URL: https://www.opiq.ee/kit/369/chapter/21192
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.8
Topics ET: matemaatika, what, mess, reading, must, tidy, ütleb, lausesse, sobiv, sõna
Topics RU: математика
Topics EN: mathematics
Headings: What a Mess!; Reading; We must tidy up!; Kes nii ütleb?; Lausesse sobiv sõna; Õige vastus; Kelle riideese see on?

## Let’s Practise!
URL: https://www.opiq.ee/kit/369/chapter/21924
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 5.9
Topics ET: matemaatika, practise, tidy, words, harjutus, speak, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Let’s Practise!; Tidy up!; Words in use; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; 4B; 4A; Let’s speak!; Harjutus 5; Harjutus 6; The more you know

## This Year
URL: https://www.opiq.ee/kit/369/chapter/22048
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 6.1
Topics ET: matemaatika, this, year, here, there, words, everywhere, harjutus, what, today
Topics RU: математика
Topics EN: mathematics
Headings: This Year; Here, there – words everywhere!; Harjutus 1; 1B; 1A; Harjutus 2; 2C; 2A; 2B; Harjutus 3; 3B; 3A; Harjutus 4; 4C; 4A; 4B; What day is it today?; Harjutus 5; Harjutus 6; Harjutus 7; 7B; 7A; Harjutus 8; I’m, you’re...; Harjutus 9; Harjutus 10; Harjutus 11; Harjutus 12; The more you know; Harjutus 13; Harjutus 14; 14B; 14A

## Extra Texts. Tom and Molly
URL: https://www.opiq.ee/kit/369/chapter/22049
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 6.2
Topics ET: matemaatika, extra, texts, molly, from, united, states, kuidas, said, tekstist
Topics RU: математика
Topics EN: mathematics
Headings: Extra Texts. Tom and Molly; Tom; I’m from the United States; Kuidas said tekstist aru?; Milliseid sõnu sa kuulsid?; Missugune vastus on õige?; Molly; She’s from Ireland; Sõna paarid; Milliseid sõnu sa ei kuulnud?; Õige vastus; Tom or Molly?; Kes nii ütleb?

## Extra Texts. Emma and Simon
URL: https://www.opiq.ee/kit/369/chapter/22050
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 6.3
Topics ET: matemaatika, liitmine, liida, summa, kokku, loom, loomad, linnud, putukad, extra, texts, emma, simon, like, milline, sõna, sobib
Topics RU: математика, сложение, сложи, сумма, животное, животные, птицы, насекомые
Topics EN: mathematics, addition, add, sum, animal, animals, birds, insects
Headings: Extra Texts. Emma and Simon; Emma; I like animals; Milline sõna sobib lausesse?; Kuidas said tekstist aru?; Ristsõna; Simon; He likes superheroes; Mis kellega kokku käib?; Milliseid sõnu sa kuulsid?; Kumb lause on õige?; Emma or Simon?; Kes nii ütleb?

## I’m Baking
URL: https://www.opiq.ee/kit/369/chapter/22167
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 6.4
Topics ET: matemaatika, baking, painting, jaatav, lause, reading, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: I’m Baking; He’s painting; Jaatav lause; He’s reading; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; 4C; 4A; 4B; Go ahead!; Harjutus 5

## He’s Not Singing
URL: https://www.opiq.ee/kit/369/chapter/22168
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 6.5
Topics ET: matemaatika, singing, eitav, lause, playing, golf, harjutus, ahead
Topics RU: математика
Topics EN: mathematics
Headings: He’s Not Singing; I’m not singing; Eitav lause; You’re not playing golf; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Go ahead!; Harjutus 5; 5C; 5A; 5B

## Are You Playing the Piano?
URL: https://www.opiq.ee/kit/369/chapter/22169
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 6.6
Topics ET: matemaatika, playing, piano, dancing, küsilause, vastus, going, school, harjutus, summary
Topics RU: математика
Topics EN: mathematics
Headings: Are You Playing the Piano?; Are you dancing?; Küsilause ja vastus; Are you going to school?; Harjutus 1; Harjutus 2; 2D; 2A; 2B; 2С; Harjutus 3; Harjutus 4; 4E; 4A; 4B; 4C; 4D; Harjutus 5; Summary

## Halloween
URL: https://www.opiq.ee/kit/369/chapter/20979
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 7.1
Topics ET: matemaatika, arv, arvud, arvu, numbrid, halloween, symbols, harjutus, guess, millist, pilti, harjutuses, kirjeldatud
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Halloween; Halloween symbols; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2F; 2A; 2B; 2C; 2D; 2E; Harjutus 3; 3F; 3A; 3B; 3C; 3D; 3E; Guess!; Harjutus 4; 4B; 4A; Millist pilti harjutuses 4 ei kirjeldatud?; Harjutus 5; 5F; 5A; 5B; 5C; 5D; 5E; Halloween numbers and colours; Harjutus 6; 6B; 6A; Halloweeni värvid; Go ahead!; Harjutus 7; 7B; 7A; Sinu halloween’i-kostüüm; Harjutus 8; 8C; 8A; 8B; Harjutus 9; 9F; 9A; 9B; 9C; 9D; 9E

## Christmas
URL: https://www.opiq.ee/kit/369/chapter/20980
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 7.2
Topics ET: matemaatika, christmas, wish, merry, symbols, harjutus, ahead, practise, more, know
Topics RU: математика
Topics EN: mathematics
Headings: Christmas; We wish you a Merry Christmas; Christmas symbols; Harjutus 1; 1B; 1A; Harjutus 2; 2B; 2A; Harjutus 3; 3B; 3A; Harjutus 4; Go ahead and practise!; Harjutus 5; 5B; 5A; Harjutus 6; 6B; 6A; Harjutus 7; Harjutus 8; The more you know; Harjutus 9; 9C; 9A; 9B

## Valentine’s Day
URL: https://www.opiq.ee/kit/369/chapter/20981
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 7.3
Topics ET: matemaatika, valentine, symbols, harjutus, play
Topics RU: математика
Topics EN: mathematics
Headings: Valentine’s Day; Valentine’s Day symbols; Harjutus 1; 1B; 1A; Harjutus 2; 2E; 2A; 2B; 2C; 2D; Harjutus 3; 3B; 3A; Harjutus 4; Harjutus 5; Let’s play!; Harjutus 6; Harjutus 7

## Easter
URL: https://www.opiq.ee/kit/369/chapter/20982
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 7.4
Topics ET: matemaatika, easter, fluffy, chicks, symbols, harjutus, play
Topics RU: математика
Topics EN: mathematics
Headings: Easter; Ten fluffy chicks; Easter symbols; Harjutus 1; 1C; 1A; 1B; Harjutus 2; 2B; 2A; Harjutus 3; Harjutus 4; Harjutus 5; Let’s play!; Harjutus 6; Harjutus 7; 7B; 7A; Harjutus 8; 8B; 8A

## Fingertips 1. My Family and I
URL: https://www.opiq.ee/kit/369/chapter/20983
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 8.1
Topics ET: matemaatika, fingertips, family, mina, isikulised, asesõnad, tegusõna, artikkel, nimisõnade, mitmus
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips 1. My Family and I; Mina, minu ... (Isikulised asesõnad); Tegusõna be; Artikkel a/an; Nimisõnade mitmus; Tegusõna have

## Fingertips 2. At Home
URL: https://www.opiq.ee/kit/369/chapter/21200
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 8.2
Topics ET: matemaatika, fingertips, home, tegusõna, like, kust, kuhu, eessõnad
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips 2. At Home; Tegusõna like; Kus? Kust? Kuhu? (Eessõnad)

## Fingertips 3. My Day
URL: https://www.opiq.ee/kit/369/chapter/21201
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 8.3
Topics ET: matemaatika, arv, arvud, arvu, numbrid, aeg, kell, kalender, fingertips, days, modaalne, tegusõna, like
Topics RU: математика, число, числа, цифры, время, часы, календарь
Topics EN: mathematics, number, numbers, digits, time, clock, calendar
Headings: Fingertips 3. My Day; Time and days; Numbrid 20–100; Modaalne tegusõna can; Tegusõna like

## Fingertips 4. My Friends and I
URL: https://www.opiq.ee/kit/369/chapter/21332
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 8.4
Topics ET: matemaatika, fingertips, friends, küsisõnad, kelle, mille, omastav, tegusõna, have
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips 4. My Friends and I; Küsisõnad; Kelle? Mille? (Omastav); Tegusõna be; Tegusõna have

## Fingertips Extra
URL: https://www.opiq.ee/kit/369/chapter/22166
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 8.5
Topics ET: matemaatika, fingertips, extra, mina, teen
Topics RU: математика
Topics EN: mathematics
Headings: Fingertips Extra; Mina teen, mina ei tee ...

## Sounds Good!
URL: https://www.opiq.ee/kit/369/chapter/21646
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 8.6
Topics ET: matemaatika, sounds, good, transcription, häälduse, kirjapanek, märkimine, kirjas, inglise, häälikud
Topics RU: математика
Topics EN: mathematics
Headings: Sounds Good!; Transcription (häälduse kirjapanek); Häälduse märkimine kirjas; Inglise häälikud

## Animations
URL: https://www.opiq.ee/kit/369/chapter/25927
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 8.7
Topics ET: matemaatika, animations, tegusõna, they, oled, õnnelik, olen, olete, oleme, have
Topics RU: математика
Topics EN: mathematics
Headings: Animations; Tegusõna be; Are you two?; I’m, you’re; we’re, you’re, they’re; Kas sa oled õnnelik?; Ma olen, sa oled ...; Te olete, me oleme, nad on ...; Tegusõna have; Mis sõna sobib?; Mul on ...; Modaalne tegusõna can; Kas oskad ...?; Nimisõnade mitmus; Üks või mitu?; Artikkel a/an; a või an?

## Inglise–eesti sõnastik
URL: https://www.opiq.ee/kit/369/chapter/20984
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 9.1
Topics ET: matemaatika, inglise, eesti, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Inglise–eesti sõnastik; Inglise-eesti sõnastik

## Eesti–inglise sõnastik
URL: https://www.opiq.ee/kit/369/chapter/20985
Book: High Five! 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inglise_keel_3._klassile
Chapter ID: 9.2
Topics ET: matemaatika, eesti, inglise, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Eesti–inglise sõnastik; Eesti-inglise sõnastik
