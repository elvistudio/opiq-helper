## Muusikamaa lood – Opiq
URL: https://www.opiq.ee/Kit/Details/206
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1
Topics ET: matemaatika, muusikamaa, lood, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikamaa lood – Opiq
URL: https://www.opiq.ee/Kit/Details/206
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 98
Topics ET: matemaatika, muusikamaa, lood, opiq
Topics RU: математика
Topics EN: mathematics

## Hea sõber!
URL: https://www.opiq.ee/kit/206/chapter/11649
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.1
Topics ET: matemaatika, sõber
Topics RU: математика
Topics EN: mathematics
Headings: Hea sõber!

## Ti-ti-ri ta
URL: https://www.opiq.ee/kit/206/chapter/11658
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.10
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ti-ti-ri ta
Task examples: Moodusta 4-taktiline viis ja kirjuta see noodijoonestikule töövihikus. Esita oma viis.; Leia ja kirjuta laulust „Ti-ti-ri ta” liitsõnad. Tee neid sõnu kasutades räpp ehk kõnesarnane laul. Esita räpp klassikaaslastele.

## Samblalõhnaline laul
URL: https://www.opiq.ee/kit/206/chapter/11650
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.2
Topics ET: matemaatika, samblalõhnaline, laul, rütmivormid, astmed, meetrum, taktimõõt, astmetrepp, astmerida
Topics RU: математика
Topics EN: mathematics
Headings: Samblalõhnaline laul; Rütmivormid ja astmed; Meetrum ja taktimõõt; Astmetrepp ja JO-astmerida; Kandlemängu võtted
Task examples: Joonista kuulatud muusikapalast pilt töövihikusse. Pane pildile pealkiri ja kirjuta pildi järgi väike jutuke.; Leia laulust „Samblalõhnaline laul” liitsõnad ja kirjuta need välja. Aruta pingi naabriga nende tähendust.

## Kellakaanon
URL: https://www.opiq.ee/kit/206/chapter/11651
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.3
Topics ET: matemaatika, kellakaanon, rütmipillid
Topics RU: математика
Topics EN: mathematics
Headings: Kellakaanon; Rütmipillid
Task examples: Märgi taktimõõt ja kirjuta astmenimed nootide alla töövihikus. Esitage harjutus kaanonina.

## Nooditundja
URL: https://www.opiq.ee/kit/206/chapter/11652
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.4
Topics ET: matemaatika, nooditundja, plokkflööt
Topics RU: математика
Topics EN: mathematics
Headings: Nooditundja; Plokkflööt
Task examples: Märgi taktimõõt ja kirjuta viis noodijoonestikule töövihikus. Laula ja näita käemärke kaasa.; Leia ristsõnast 11 pilli nimetused ja tõmba neile värviline joon ümber töövihikus. Mängi igal pillil ja kirjelda selle pilli kõla.

## Kunstnik sügis
URL: https://www.opiq.ee/kit/206/chapter/11653
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.5
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, kunstnik, dünaamilised, varjundid
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Kunstnik sügis; Dünaamilised varjundid
Task examples: Kuula muusikat ja kujuta värvipliiatsite abil pala dünaamikat töövihikus. Lisa oma pildile dünaamika märgid.

## Sügise laul
URL: https://www.opiq.ee/kit/206/chapter/11654
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.6
Topics ET: matemaatika, sügise, laul
Topics RU: математика
Topics EN: mathematics
Headings: Sügise laul
Task examples: Täida skeem vastavate rütmivormidega töövihikus.

## Tahaksin olla
URL: https://www.opiq.ee/kit/206/chapter/11655
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.7
Topics ET: matemaatika, tahaksin, olla
Topics RU: математика
Topics EN: mathematics
Headings: Tahaksin olla
Task examples: Mõtle välja luuletuse „Aastaajalaul” esimesele reale viis ja laula selle viisiga kogu luuletus. Kirjuta rütmi alla astmenimed. Seejärel kirjuta viis noodijoonestikule töövihikus.

## Mihklikuu
URL: https://www.opiq.ee/kit/206/chapter/11656
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.8
Topics ET: matemaatika, mihklikuu, september
Topics RU: математика
Topics EN: mathematics
Headings: Mihklikuu; September
Task examples: Kirjuta rütmiharjutus töövihikusse, kasutades järgmisi rütmivorme:

## Me lähme rukist lõikama
URL: https://www.opiq.ee/kit/206/chapter/11657
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 1.9
Topics ET: matemaatika, lähme, rukist, lõikama, laul, mäng
Topics RU: математика
Topics EN: mathematics
Headings: Me lähme rukist lõikama; Laul „Me lähme rukist lõikama”; Mäng „Me lähme rukist lõikama”
Task examples: Värvi ringi pooled, veerandikud, kaheksandikud ja kuueteistkümnendikud erinevate värvidega. Kirjuta iga osa juurde vastava pikkusega noot töövihikus.

## Eesti kaart
URL: https://www.opiq.ee/kit/206/chapter/11710
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 10.1
Topics ET: matemaatika, eesti, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Eesti kaart
Task examples: Lahenda ristsõna töövihikus. Vastuseks saad kahe Eesti linna nimed (abiks on laulu „Eesti kaart” 1. salm, õpik lk 110).

## Mu isamaa, mu õnn ja rõõm
URL: https://www.opiq.ee/kit/206/chapter/11711
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 10.2
Topics ET: matemaatika, isamaa, rõõm
Topics RU: математика
Topics EN: mathematics
Headings: Mu isamaa, mu õnn ja rõõm

## Eesti lipp
URL: https://www.opiq.ee/kit/206/chapter/11712
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 10.3
Topics ET: matemaatika, eesti, lipp
Topics RU: математика
Topics EN: mathematics
Headings: Eesti lipp
Task examples: Piltidel on Eesti Vabariigi presidendid ja nende ametiajad. Vali iga pildi juurde õige nimi. Arutage klassis, mida te Eesti presidentidest teate.

## Kallis kodu
URL: https://www.opiq.ee/kit/206/chapter/11713
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 10.4
Topics ET: matemaatika, kallis, kodu
Topics RU: математика
Topics EN: mathematics
Headings: Kallis kodu

## Ma vaatan paadist kiikriga
URL: https://www.opiq.ee/kit/206/chapter/11714
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 10.5
Topics ET: matemaatika, vaatan, paadist, kiikriga
Topics RU: математика
Topics EN: mathematics
Headings: Ma vaatan paadist kiikriga
Task examples: Kuula muusikat ja joonista töövihikusse merepilt. Merepilt

## Mere pidu
URL: https://www.opiq.ee/kit/206/chapter/11715
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 10.6
Topics ET: matemaatika, mere, pidu, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Mere pidu; Helilooja
Task examples: Tõmba taktijooned töövihikus. Esita harjutused.

## Vastlalaul
URL: https://www.opiq.ee/kit/206/chapter/11716
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 10.7
Topics ET: matemaatika, vastlalaul
Topics RU: математика
Topics EN: mathematics
Headings: Vastlalaul
Task examples: Heal lapsel mitu nime… Leia iga kuu juurde vanarahva seas tuntud kuude nimetused. Kasuta vajadusel interneti abi.; Märgi töövihikus igale laulule taktimõõt. Laula astmenimede ja käemärkidega. Leia nende tuntud laulude pealkirjad. Kirjuta viisid noodijoonestikule C-duur helistikus. Kirjuta nootide alla tähtnimetused. Laula.

## Laul põhjamaast
URL: https://www.opiq.ee/kit/206/chapter/11717
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 11.1
Topics ET: matemaatika, laul, põhjamaast, muusikal
Topics RU: математика
Topics EN: mathematics
Headings: Laul põhjamaast; Muusikal
Task examples: Uuri oma lähikondsete suhteid muusikaga. Valmista ette muusikateemalise intervjuu küsimused.

## Pipi laul
URL: https://www.opiq.ee/kit/206/chapter/11718
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 11.2
Topics ET: matemaatika, pipi, laul, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Pipi laul; Helilooja
Task examples: Kirjuta töövihikusse ühe pildi põhjal muusikali süžee. Otsi internetist või telefonist sobilik taustamuusika ja esita oma lugu klassikaaslastele.

## Do-re-mi
URL: https://www.opiq.ee/kit/206/chapter/11719
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 11.3
Topics ET: matemaatika, helilooja, helisev, muusika
Topics RU: математика
Topics EN: mathematics
Headings: Do-re-mi; Helilooja; „HELISEV MUUSIKA”

## Minu lemmikud
URL: https://www.opiq.ee/kit/206/chapter/11720
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 11.4
Topics ET: matemaatika, lemmikud
Topics RU: математика
Topics EN: mathematics
Headings: Minu lemmikud
Task examples: Märgi õige vastus ja kirjuta noot noodijoonestikule töövihikus.

## Tantsi, tantsi
URL: https://www.opiq.ee/kit/206/chapter/11721
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 12.1
Topics ET: matemaatika, tantsi
Topics RU: математика
Topics EN: mathematics
Headings: Tantsi, tantsi
Task examples: Tõmba taktijooned ja kirjuta astmenimed töövihikus. Laula astmenimede ja käemärkidega. Esitage laul kaanonina eesti ja saksa keeles. Mis tantsu saab selle muusika järgi tantsida?

## Maddalena
URL: https://www.opiq.ee/kit/206/chapter/11722
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 12.2
Topics ET: matemaatika, maddalena
Topics RU: математика
Topics EN: mathematics
Headings: Maddalena
Task examples: Täida lüngad töövihikus. Vastusteks saad tantsude nimetused.

## Debka hora
URL: https://www.opiq.ee/kit/206/chapter/11723
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 12.3
Topics ET: matemaatika, debka, hora
Topics RU: математика
Topics EN: mathematics
Headings: Debka hora; DEBKA HORA*
Task examples: Kirjuta taktimõõt, astmenimed ja tähtnimetused töövihikusse. Esita laul sõnadega. Mis tantsu saab selle muusika järgi tantsida?

## Kinga-rock
URL: https://www.opiq.ee/kit/206/chapter/11724
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 12.4
Topics ET: matemaatika, kinga, rock
Topics RU: математика
Topics EN: mathematics
Headings: Kinga-rock

## Lapaduu
URL: https://www.opiq.ee/kit/206/chapter/11725
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 12.5
Topics ET: matemaatika, lapaduu
Topics RU: математика
Topics EN: mathematics
Headings: Lapaduu
Task examples: Kirjuta töövihikus „Lapaduu” noodijoonestikule C-duur helistikus. Kirjuta nootide alla tähtnimetused. Laula.

## Rõõmulaul
URL: https://www.opiq.ee/kit/206/chapter/11726
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 13.1
Topics ET: matemaatika, rõõmulaul, kooriliigid
Topics RU: математика
Topics EN: mathematics
Headings: Rõõmulaul; Kooriliigid
Task examples: Kirjuta I ja II hääle nootidele sobiv rütm ja tähtnimetused töövihikusse. Laulge harjutusi kahehäälselt.

## Muhulaste laul
URL: https://www.opiq.ee/kit/206/chapter/11727
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 13.2
Topics ET: matemaatika, muhulaste, laul, eesti, tuntud, koorid, dirigendid
Topics RU: математика
Topics EN: mathematics
Headings: Muhulaste laul; Eesti tuntud koorid ja dirigendid
Task examples: Jaga rütm taktidesse töövihikus. Esita partituur kehapillil.

## Mats alati on tubli mees
URL: https://www.opiq.ee/kit/206/chapter/11728
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 13.3
Topics ET: matemaatika, mats, alati, tubli, mees, eesti, tuntud, koorid, dirigendid
Topics RU: математика
Topics EN: mathematics
Headings: Mats alati on tubli mees; Eesti tuntud koorid ja dirigendid
Task examples: Kirjuta viis töövihikus noodijoonestikule C-duur helistikus. Mõtle juurde liigutused ja esita laul.

## Kiigelaul
URL: https://www.opiq.ee/kit/206/chapter/11729
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 13.4
Topics ET: matemaatika, kiigelaul, eesti, tuntud, koorid, dirgendid
Topics RU: математика
Topics EN: mathematics
Headings: Kiigelaul; Eesti tuntud koorid ja dirgendid
Task examples: Kuula koorilaulu ja joonista sellest pilt töövihikusse. Mõtle pildile pealkiri. Koorilaul

## Kungla rahvas
URL: https://www.opiq.ee/kit/206/chapter/11730
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 13.5
Topics ET: matemaatika, kungla, rahvas, eesti, tuntud, koorid, dirigendid
Topics RU: математика
Topics EN: mathematics
Headings: Kungla rahvas; Eesti tuntud koorid ja dirigendid
Task examples: Leia iga kooriliigi juurde dirigentide nimed. Lisa töövihikus ka oma kooli ja kodukoha kooride dirigendid.

## Noore nõia laul
URL: https://www.opiq.ee/kit/206/chapter/11731
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 14.1
Topics ET: matemaatika, noore, nõia, laul
Topics RU: математика
Topics EN: mathematics
Headings: Noore nõia laul
Task examples: Kirjuta viisid töövihikus lõpuni, kasutades õpitud rütmivorme, astmeid ja helilaade. Laula astme nimede ja käemärkidega.

## Kalagripp
URL: https://www.opiq.ee/kit/206/chapter/11732
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 14.2
Topics ET: matemaatika, kalagripp
Topics RU: математика
Topics EN: mathematics
Headings: Kalagripp

## Heeringas
URL: https://www.opiq.ee/kit/206/chapter/11733
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 14.3
Topics ET: matemaatika, heeringas
Topics RU: математика
Topics EN: mathematics
Headings: Heeringas
Task examples: Laula ja leia viisilõikudest kolm sobivat paari. Kirjuta viisid noodijoonestikule töövihikus. Lisa laulude pealkirjad ja autorid (vt õpik lk 93–141). Esita üks laul.

## Tagurpidimaa
URL: https://www.opiq.ee/kit/206/chapter/11734
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 14.4
Topics ET: matemaatika, tagurpidimaa
Topics RU: математика
Topics EN: mathematics
Headings: Tagurpidimaa
Task examples: Kirjuta sõnad tagurpidi. Tee nendest väike luuletus.

## Lapsel on mure
URL: https://www.opiq.ee/kit/206/chapter/11735
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.1
Topics ET: matemaatika, lapsel, mure, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Lapsel on mure; Helilooja

## Lepatriinu laul
URL: https://www.opiq.ee/kit/206/chapter/11736
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.2
Topics ET: matemaatika, lepatriinu, laul
Topics RU: математика
Topics EN: mathematics
Headings: Lepatriinu laul
Task examples: Lauluviis läks segamini! Aita leida õiged taktid. Kirjuta viis noodijoonestikule töövihikus. Esitage laul kaanonina.

## Vanaema
URL: https://www.opiq.ee/kit/206/chapter/11737
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.3
Topics ET: matemaatika, vanaema
Topics RU: математика
Topics EN: mathematics
Headings: Vanaema

## Õnneseen
URL: https://www.opiq.ee/kit/206/chapter/11738
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.4
Topics ET: matemaatika, õnneseen
Topics RU: математика
Topics EN: mathematics
Headings: Õnneseen
Task examples: Kirjuta taktimõõt, astmenimed ja tähtnimetused töövihikus. Esitage laul kaanonina. Jälgige dünaamika märke.

## Emakesele
URL: https://www.opiq.ee/kit/206/chapter/11739
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.5
Topics ET: matemaatika, emakesele
Topics RU: математика
Topics EN: mathematics
Headings: Emakesele

## Homme on spordipäev
URL: https://www.opiq.ee/kit/206/chapter/11740
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.6
Topics ET: matemaatika, homme, spordipäev
Topics RU: математика
Topics EN: mathematics
Headings: Homme on spordipäev
Task examples: Oled spordipäeva korraldaja. Kujunda ja värvi medalid töövihikus.

## Konnad
URL: https://www.opiq.ee/kit/206/chapter/11741
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.7
Topics ET: matemaatika, konnad
Topics RU: математика
Topics EN: mathematics
Headings: Konnad

## Mu mütsil on kolm nurka
URL: https://www.opiq.ee/kit/206/chapter/11742
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.8
Topics ET: matemaatika, mütsil, kolm, nurka
Topics RU: математика
Topics EN: mathematics
Headings: Mu mütsil on kolm nurka

## On meie keskel suvi
URL: https://www.opiq.ee/kit/206/chapter/11743
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 15.9
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, meie, keskel
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: On meie keskel suvi
Task examples: Disaini muusikateemaline T-särk ja kitarrikott töövihikus.

## Sõnaseletused
URL: https://www.opiq.ee/kit/206/chapter/11744
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 16.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Loomad tööl
URL: https://www.opiq.ee/kit/206/chapter/11659
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 2.1
Topics ET: matemaatika, loom, loomad, linnud, putukad, tööl
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Loomad tööl

## Loomariik
URL: https://www.opiq.ee/kit/206/chapter/11660
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 2.2
Topics ET: matemaatika, loomariik
Topics RU: математика
Topics EN: mathematics
Headings: Loomariik

## Karvast sõpra oodates
URL: https://www.opiq.ee/kit/206/chapter/11661
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 2.3
Topics ET: matemaatika, karvast, sõpra, oodates
Topics RU: математика
Topics EN: mathematics
Headings: Karvast sõpra oodates
Task examples: Kuula muusikat ja kirjuta lugu ühest koerast.

## Pääsukeste sügislaul
URL: https://www.opiq.ee/kit/206/chapter/11662
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 2.4
Topics ET: matemaatika, pääsukeste, sügislaul
Topics RU: математика
Topics EN: mathematics
Headings: Pääsukeste sügislaul
Task examples: Kirjuta „Pääsukeste sügislaul” noodijoonestikule töövihikus. Kirjuta nootide alla astmenimed ja laula.

## Lambad on kadunud
URL: https://www.opiq.ee/kit/206/chapter/11663
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 2.5
Topics ET: matemaatika, lambad, kadunud
Topics RU: математика
Topics EN: mathematics
Headings: Lambad on kadunud

## Loomade karneval
URL: https://www.opiq.ee/kit/206/chapter/11664
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 2.6
Topics ET: matemaatika, loomade, karneval
Topics RU: математика
Topics EN: mathematics
Headings: Loomade karneval
Task examples: Kuula Camille Saint-Saënsi muusikat ja joonista pilt „Loomade karneval” töövihikusse. „Loomade karneval”

## Karulaane jenka
URL: https://www.opiq.ee/kit/206/chapter/11665
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 2.7
Topics ET: matemaatika, karulaane, jenka
Topics RU: математика
Topics EN: mathematics
Headings: Karulaane jenka

## Kui sa leiad suure kivi
URL: https://www.opiq.ee/kit/206/chapter/11666
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 3.1
Topics ET: matemaatika, leiad, suure, kivi, helilooja, duur, helilaad, kolmkõla
Topics RU: математика
Topics EN: mathematics
Headings: Kui sa leiad suure kivi; KUI SA LEIAD; SUURE KIVI; Helilooja; Duur-helilaad ja duur-kolmkõla
Task examples: Kirjuta duur-helilaad ja duur-kolmkõla noodijoonestikule töövihikus. Lisa astmenimed. Märgi värviliselt ½-tooniliste astmevahede asukohad. Laula.

## Kiire lugu
URL: https://www.opiq.ee/kit/206/chapter/11667
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 3.2
Topics ET: matemaatika, kiire, lugu
Topics RU: математика
Topics EN: mathematics
Headings: Kiire lugu

## Aeg
URL: https://www.opiq.ee/kit/206/chapter/11668
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 3.3
Topics ET: matemaatika, aeg, kell, kalender, moll, helilaad, kolmkõla
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Aeg; Moll-helilaad ja moll-kolmkõla
Task examples: Täida ülesanne töövihikus.; Kirjuta moll-helilaad ja moll-kolmkõla ning astmenimed töövihikusse. Märgi värviliselt ½-tooni liste astmevahede asukohad. Laula.

## Varastaja harakas
URL: https://www.opiq.ee/kit/206/chapter/11669
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 3.4
Topics ET: matemaatika, varastaja, harakas, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Varastaja harakas; Helilooja
Task examples: Täida ülesanne töövihikus.

## Õhtu-ilu
URL: https://www.opiq.ee/kit/206/chapter/11670
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 3.5
Topics ET: matemaatika, õhtu
Topics RU: математика
Topics EN: mathematics
Headings: Õhtu-ilu
Task examples: Tõmba taktijooned töövihikusse ja esita rütmiharjutused kahe käega.

## Öö laul
URL: https://www.opiq.ee/kit/206/chapter/11671
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 3.6
Topics ET: matemaatika, laul
Topics RU: математика
Topics EN: mathematics
Headings: Öö laul

## Astub hommik
URL: https://www.opiq.ee/kit/206/chapter/11672
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 3.7
Topics ET: matemaatika, astub, hommik, luuletaja
Topics RU: математика
Topics EN: mathematics
Headings: Astub hommik; Luuletaja
Task examples: Koosta kaks päevaplaani töövihikus.

## Meie elu
URL: https://www.opiq.ee/kit/206/chapter/11673
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 4.1
Topics ET: matemaatika, meie, osaline, lihtvorm
Topics RU: математика
Topics EN: mathematics
Headings: Meie elu; 1-osaline lihtvorm
Task examples: Joonista pilt oma lemmiklaulust töövihikusse. Kirjuta laulu pealkiri. Lemmiklaul

## Isadel on pikad päevad
URL: https://www.opiq.ee/kit/206/chapter/11674
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 4.2
Topics ET: matemaatika, isadel, pikad, päevad
Topics RU: математика
Topics EN: mathematics
Headings: Isadel on pikad päevad
Task examples: Paranda vead punase pliiatsiga töövihikus. Mitu viga oli igas ülesandes?

## Eideratas
URL: https://www.opiq.ee/kit/206/chapter/11675
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 4.3
Topics ET: matemaatika, eideratas
Topics RU: математика
Topics EN: mathematics
Headings: Eideratas

## Mardilaul
URL: https://www.opiq.ee/kit/206/chapter/11676
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 4.4
Topics ET: matemaatika, mardilaul
Topics RU: математика
Topics EN: mathematics
Headings: Mardilaul
Task examples: Kirjuta „Mardilaul” noodijoonestikule töövihikus. Laula.

## Kadrilaul
URL: https://www.opiq.ee/kit/206/chapter/11677
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 4.5
Topics ET: matemaatika, kadrilaul
Topics RU: математика
Topics EN: mathematics
Headings: Kadrilaul
Task examples: Võrdle mardi- ja kadripäeva kombeid. Kirjuta sarnased kombed keskele ja erinevad külgedele töövihikus.

## Karjase laul
URL: https://www.opiq.ee/kit/206/chapter/11678
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 4.6
Topics ET: matemaatika, karjase, laul, osaline, lihtvorm
Topics RU: математика
Topics EN: mathematics
Headings: Karjase laul; 3-osaline lihtvorm
Task examples: Leia igapäevaelust mõni 1-, 2- või 3-osalise vormi näide. Joonista need töövihikusse. 1-osaline vorm2-osaline vorm3-osaline vorm; Kirjuta astmenimed töövihikusse. Laula, püüa katkendite järgi laulud ära tunda. Kirjuta laulude pealkirjad ja vorm (õpik lk 46–55).

## Üles, üles, hellad vennad
URL: https://www.opiq.ee/kit/206/chapter/11679
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 5.1
Topics ET: matemaatika, üles, hellad, vennad, hääleliigid
Topics RU: математика
Topics EN: mathematics
Headings: Üles, üles, hellad vennad; Hääleliigid
Task examples: Tõmba taktijooned ja kirjuta astmenimed töövihikus hääleharjutustele a, b, c. Laula.

## Poisid ja plikad
URL: https://www.opiq.ee/kit/206/chapter/11680
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 5.2
Topics ET: matemaatika, poisid, plikad, hääleliigid
Topics RU: математика
Topics EN: mathematics
Headings: Poisid ja plikad; Hääleliigid
Task examples: Kuula naishääli. Järjesta need kõrguse järgi ja iseloomusta töövihikus.

## Poiste laul
URL: https://www.opiq.ee/kit/206/chapter/11681
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 5.3
Topics ET: matemaatika, poiste, laul, meeshääled
Topics RU: математика
Topics EN: mathematics
Headings: Poiste laul; Meeshääled
Task examples: Täida ülesanne töövihikus.; Esitage partituur vabalt valitud silpidel. Koosta ka ise partituur töövihikusse ja esitage see koos sõpradega.

## Väike ööbik
URL: https://www.opiq.ee/kit/206/chapter/11682
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 5.4
Topics ET: matemaatika, väike, ööbik, meeshääled
Topics RU: математика
Topics EN: mathematics
Headings: Väike ööbik; Meeshääled
Task examples: Kuula meeshääli. Järjesta need kõrguse järgi ja iseloomusta töövihikus.

## Kellamäng
URL: https://www.opiq.ee/kit/206/chapter/11683
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 5.5
Topics ET: matemaatika, kellamäng
Topics RU: математика
Topics EN: mathematics
Headings: Kellamäng
Task examples: Kirjuta Rahvusooper Estonia (www.opera.ee) ja/või teater Vanemuise (www. vanemuine. ee) mängukavast ooperid, mida käesoleval hooajal mängi takse.

## Päkapiku jõululaul
URL: https://www.opiq.ee/kit/206/chapter/11684
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.1
Topics ET: matemaatika, päkapiku, jõululaul
Topics RU: математика
Topics EN: mathematics
Headings: Päkapiku jõululaul
Task examples: Täida lüngad õpitud rütmivormidega töövihikus. Esita harjutused kehapillil.

## Las vihistab
URL: https://www.opiq.ee/kit/206/chapter/11685
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.2
Topics ET: matemaatika, vihistab, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Las vihistab; Helilooja
Task examples: Kuula Arvo Pärdi muusikat ja joonista talvepilt töövihikusse. Pane pildile pealkiri. Talvepilt

## Talve võlumaa
URL: https://www.opiq.ee/kit/206/chapter/11686
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.3
Topics ET: matemaatika, talve, võlumaa
Topics RU: математика
Topics EN: mathematics
Headings: Talve võlumaa
Task examples: Märgi taktimõõt ja kirjuta viis noodijoonestikule. Laula astmenimedega. Lisa ka nende talvelaulude pealkirjad.

## Siis kui minu vanaema
URL: https://www.opiq.ee/kit/206/chapter/11687
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.4
Topics ET: matemaatika, siis, vanaema
Topics RU: математика
Topics EN: mathematics
Headings: Siis kui minu vanaema
Task examples: Ühenda riimuvad sõnad joontega töövihikus. Mõtle sõnu juurde ja kirjuta jõululuuletus. Kingi oma luuletus sõpradele ja sugulastele.

## Väiku latsõ jõulusalm
URL: https://www.opiq.ee/kit/206/chapter/11688
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.5
Topics ET: matemaatika, väiku, latsõ, jõulusalm
Topics RU: математика
Topics EN: mathematics
Headings: Väiku latsõ jõulusalm

## Jõulutäht
URL: https://www.opiq.ee/kit/206/chapter/11689
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.6
Topics ET: matemaatika, jõulutäht
Topics RU: математика
Topics EN: mathematics
Headings: Jõulutäht

## Jõulusoovid
URL: https://www.opiq.ee/kit/206/chapter/11690
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.7
Topics ET: matemaatika, jõulusoovid, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Jõulusoovid; Helilooja
Task examples: Lahenda koodmõistatus töövihikus.

## Gloria in excelsis deo!
URL: https://www.opiq.ee/kit/206/chapter/11691
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.8
Topics ET: matemaatika, gloria, excelsis
Topics RU: математика
Topics EN: mathematics
Headings: Gloria in excelsis deo!; GLORIA IN EXCELSIS DEO!*

## Püha öö
URL: https://www.opiq.ee/kit/206/chapter/11692
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 6.9
Topics ET: matemaatika, püha
Topics RU: математика
Topics EN: mathematics
Headings: Püha öö

## Head uut aastat
URL: https://www.opiq.ee/kit/206/chapter/11693
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 7.1
Topics ET: matemaatika, head, aastat
Topics RU: математика
Topics EN: mathematics
Headings: Head uut aastat; Head uut aastat!
Task examples: Tõmba taktijooned ja kirjuta laulude katkendid noodijoonestikule töövihikus. Laula käemärkidega.

## Mütsitants
URL: https://www.opiq.ee/kit/206/chapter/11694
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 7.2
Topics ET: matemaatika, mütsitants, marakas
Topics RU: математика
Topics EN: mathematics
Headings: Mütsitants; Marakas
Task examples: Tõmba töövihikus maha sõnad, mis ei sobi tulpa. Leia igale tulbale ühisnimetus.

## Kui on selged astmenimed
URL: https://www.opiq.ee/kit/206/chapter/11695
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 7.3
Topics ET: matemaatika, selged, astmenimed
Topics RU: математика
Topics EN: mathematics
Headings: Kui on selged astmenimed
Task examples: Harjuta viiulivõtme kirjutamist töövihikus.; Värvi töövihikus plokkflöödi avad (mänguvõtted) tähtnimetuste järgi (abiks on õpik lk 12). Mängi pillil mõni viis.

## Suusalumi
URL: https://www.opiq.ee/kit/206/chapter/11696
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 7.4
Topics ET: matemaatika, suusalumi, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Suusalumi; Helilooja
Task examples: Kirjuta C-duur helistik ja kolmkõla noodijoonestikule töövihikus. Kirjuta nootide alla astmenimed ja täht nimetused. Laula.; Märgi taktimõõt ja kirjuta astmenimed töövihikus. Laulge kaanonina.

## Karjapoiss
URL: https://www.opiq.ee/kit/206/chapter/11697
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 7.5
Topics ET: matemaatika, karjapoiss
Topics RU: математика
Topics EN: mathematics
Headings: Karjapoiss
Task examples: Kirjuta a-moll helistik ja kolmkõla noodijoonestikule töövihikus. Kirjuta nootide alla astmenimed ja täht nimetused. Laula.; Märgi taktimõõt ja kirjuta astmenimed töövihikus. Laulge kaanonina.

## Muusika
URL: https://www.opiq.ee/kit/206/chapter/11698
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 8.1
Topics ET: matemaatika, muusika
Topics RU: математика
Topics EN: mathematics
Headings: Muusika

## Ood rõõmule
URL: https://www.opiq.ee/kit/206/chapter/11699
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 8.2
Topics ET: matemaatika, rõõmule, helilooja
Topics RU: математика
Topics EN: mathematics
Headings: Ood rõõmule; Helilooja
Task examples: Tõmba töövihikus joon ümber sõnadele, mis on seotud Ludwig van Beethoveni elu ja loominguga.

## Marmotte
URL: https://www.opiq.ee/kit/206/chapter/11700
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 8.3
Topics ET: matemaatika, marmotte
Topics RU: математика
Topics EN: mathematics
Headings: Marmotte
Task examples: Kirjuta „Oodi rõõmule” (õpik lk 93) rütm koos tähtnimetustega töövihikusse. Laula ja „mängi“ seda lugu klaveri klaviatuuri pildil (TV lk 28–29). Võid mängida ka plokk flöödil või plaatpillil.; Kuula ja iseloomusta Ludwig van Beethoveni muusikat. Kirjuta, mis mõtteid ja tundeid see muusika sinus tekitab.

## Puusõdurite marss
URL: https://www.opiq.ee/kit/206/chapter/11701
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 8.4
Topics ET: matemaatika, puusõdurite, marss, helilooja, lastealbum
Topics RU: математика
Topics EN: mathematics
Headings: Puusõdurite marss; Helilooja; „Lastealbum”
Task examples: Mõtle välja Pjotr Tšaikovski laulule „Puusõdurite marss” kaks erinevat rütmi ostinaatot. Esita need koos lauluga. Värvi puusõduri pilt.

## Armastus võidab
URL: https://www.opiq.ee/kit/206/chapter/11702
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 8.5
Topics ET: matemaatika, armastus, võidab, eurovisiooni, lauluvõistlus
Topics RU: математика
Topics EN: mathematics
Headings: Armastus võidab; Eurovisiooni lauluvõistlus
Task examples: Leia ja kirjuta töövihikus tabelisse Eurovisiooni lauluvõistlusel Eestit esindanud laulud, lauljad ja autorid. Kuulake interneti vahendusel Eurovisiooni lauluvõistluse laule ja korraldage ka oma klassis lauluvõistlus.

## Terelaul
URL: https://www.opiq.ee/kit/206/chapter/11703
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 9.1
Topics ET: matemaatika, terelaul
Topics RU: математика
Topics EN: mathematics
Headings: Terelaul
Task examples: Leia ja kirjuta laulust „Terelaul“ erinevates keeltes tervitused. Märgi töövihikus juurde, millise riigi keeles on tervitus ja joonista vastav riigilipp.

## Väike postiljon
URL: https://www.opiq.ee/kit/206/chapter/11704
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 9.2
Topics ET: matemaatika, väike, postiljon
Topics RU: математика
Topics EN: mathematics
Headings: Väike postiljon

## Punapaela laul
URL: https://www.opiq.ee/kit/206/chapter/11705
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 9.3
Topics ET: matemaatika, punapaela, laul
Topics RU: математика
Topics EN: mathematics
Headings: Punapaela laul
Task examples: Täida lüngad töövihikus. Esita harjutused kehapillil või mõnel rütmipillil.

## Nurme nõlval kasekene kasvas
URL: https://www.opiq.ee/kit/206/chapter/11706
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 9.4
Topics ET: matemaatika, nurme, nõlval, kasekene, kasvas
Topics RU: математика
Topics EN: mathematics
Headings: Nurme nõlval kasekene kasvas
Task examples: Tõmba taktijooned töövihikusse. Õpi iga pillipartiid eraldi ja esitage kogu partituur koos klassi kaaslastega.

## Hällilaul
URL: https://www.opiq.ee/kit/206/chapter/11707
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 9.5
Topics ET: matemaatika, hällilaul
Topics RU: математика
Topics EN: mathematics
Headings: Hällilaul

## Tramblanka
URL: https://www.opiq.ee/kit/206/chapter/11708
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 9.6
Topics ET: matemaatika, tramblanka
Topics RU: математика
Topics EN: mathematics
Headings: Tramblanka; TRAMBLANKA*

## Lendas valge tuvi
URL: https://www.opiq.ee/kit/206/chapter/11709
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: 4._klassi_muusika­õpetus
Chapter ID: 9.7
Topics ET: matemaatika, lendas, valge, tuvi
Topics RU: математика
Topics EN: mathematics
Headings: Lendas valge tuvi
Task examples: Kirjuta laul „Lendas valge tuvi” noodijoonestikule töövihikus. Kirjuta nootide alla tähtnimetused. Laula.

## Muusikaõpik 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/174
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 99
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikaõpik 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/174
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 139
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Õpiku tähised
URL: https://www.opiq.ee/kit/174/chapter/9803
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.1
Topics ET: matemaatika, õpiku, tähised, märkide, keel, mängi, kuula
Topics RU: математика
Topics EN: mathematics
Headings: Õpiku tähised; Märkide keel; Mängi ja kuula

## RA-astmerida ehk moll-helilaad
URL: https://www.opiq.ee/kit/174/chapter/9812
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.10
Topics ET: matemaatika, vesi, veeohutus, veekogu, astmerida, moll, helilaad, nukra, kõlaga, helirida, laulab
Topics RU: математика, вода, безопасность на воде, водоём
Topics EN: mathematics, water, water safety, body of water
Headings: RA-astmerida ehk moll-helilaad; Nukra kõlaga helirida; Vesi laulab; Astmerida RA-st RA-ni
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Moll-kolmkõla
URL: https://www.opiq.ee/kit/174/chapter/9813
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.11
Topics ET: matemaatika, moll, kolmkõla, nukker, trio, tuule, laul
Topics RU: математика
Topics EN: mathematics
Headings: Moll-kolmkõla; Nukker trio; RA-JO-MI; Tuule laul
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Uued rütmid TI-TI-RI ja TI-RI-TI
URL: https://www.opiq.ee/kit/174/chapter/9814
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.12
Topics ET: matemaatika, uued, rütmid, tantsusõbrad, peegel, rütmide, moodustamine, ostetud, hääl
Topics RU: математика
Topics EN: mathematics
Headings: Uued rütmid TI-TI-RI ja TI-RI-TI; Tantsusõbrad; Peegel; Rütmide moodustamine; Ostetud hääl; Meie elu
Task examples: Plaksuta ja kuula Eesti kohanimede rütmi. Märgi õiged vastused.; Plaksuta ja kuula Eesti kohanimede rütmi. Märgi õiged vastused.

## Hääl ja selle liigid
URL: https://www.opiq.ee/kit/174/chapter/9815
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.13
Topics ET: matemaatika, hääl, selle, liigid, hüüd, mitmel, moel, hääle, tekitamine, jaotus
Topics RU: математика
Topics EN: mathematics
Headings: Hääl ja selle liigid; Hüüd mitmel moel; Hääle tekitamine ja jaotus; Hääleliigid; Palju hääle kasutamise võimalusi; Koolitatud hääled meil ja mujal
Task examples: Sorteeri nais- ja meeshääled õigesse tulpa.; Riputa hääleliigid kõrguse järjekorras puule.

## Kordamine
URL: https://www.opiq.ee/kit/174/chapter/9818
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.14
Topics ET: matemaatika, kordamine, korda, harjutan, küsimused, sepapoisid, sepahaamer
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Küsimused ja ülesanded; Sepapoisid; Sepahaamer

## Talvelaulud
URL: https://www.opiq.ee/kit/174/chapter/9819
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.15
Topics ET: matemaatika, talvelaulud, pimeda, valgus, lumelaul, pühade, ootamine, lume, päkapiku, jõululaul
Topics RU: математика
Topics EN: mathematics
Headings: Talvelaulud; Pimeda aja valgus; Lumelaul; Pühade ootamine; Lume all; Päkapiku jõululaul; Üle lume lagedale; Püha öö; Ave Maria; Jõulukell; Jõuluvana on tulemas; We Wish You a Merry Christmas; Uue aasta kaanon; Tabatinna; Soe tee kamina ees; Talvehommik

## Astmenimed
URL: https://www.opiq.ee/kit/174/chapter/9804
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.2
Topics ET: matemaatika, astmenimed, laulan, näitan, mäkke, ronimine, käemärgid
Topics RU: математика
Topics EN: mathematics
Headings: Astmenimed; Laulan ja näitan; Mäkke ronimine; Käemärgid
Task examples: Uuri laulu „Mäkke ronimine“ takte 1-4. Lahenda ülesanded.; Märgi silpide loetelus astmenimed.

## Noodi­pikkused
URL: https://www.opiq.ee/kit/174/chapter/9805
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, noodi, pikkused, kõlamõõt, tantsulaul, rütmitabel, rütmimäng
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Noodi­pikkused; Kõlamõõt; Tantsulaul; Rütmitabel; Minu õpetaja; Rütmimäng; Sügis
Task examples: Sorteeri rütmid tulpadesse.; Kuula ja korda meloodia rütmi plaksutades, loe kaasa rütmisilpe. Vali õige laulu pealkiri.

## Taktimõõt
URL: https://www.opiq.ee/kit/174/chapter/9806
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.4
Topics ET: matemaatika, taktimõõt, nootide, korrastaja, tantsuringis, taktimõõdu, kaks, numbrit, miks
Topics RU: математика
Topics EN: mathematics
Headings: Taktimõõt; Nootide korrastaja; Tantsuringis; Taktimõõdu kaks numbrit; Miks?
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Taktimõõt 4/4
URL: https://www.opiq.ee/kit/174/chapter/9807
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.5
Topics ET: matemaatika, taktimõõt, marsitaktis, edasi, tule, sõber, kaasa, neli, lööki, taktis
Topics RU: математика
Topics EN: mathematics
Headings: Taktimõõt 4/4; Marsitaktis edasi; Tule, sõber, kaasa; Neli lööki taktis; Tervenoot ja tervepaus
Task examples: Lausu sõnu silphaaval ja plaksuta rütmi. Kas sõnade rütm koosneb neljast löögist (silbist) või mitte? Vali õige vastus.; Lausu sõnu silphaaval ja plaksuta rütmi. Kas sõnade rütm koosneb neljast löögist (silbist) või mitte? Vali õige vastus.

## JO-astmerida ehk duur-helilaad
URL: https://www.opiq.ee/kit/174/chapter/9808
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.6
Topics ET: matemaatika, astmerida, duur, helilaad, rõõmsa, kõlaga, helirida, kuidas, hakkame, elama
Topics RU: математика
Topics EN: mathematics
Headings: JO-astmerida ehk duur-helilaad; Rõõmsa kõlaga helirida; Kuidas me hakkame elama?; Astmerida JO-st JO'-ni
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Duur-kolmkõla
URL: https://www.opiq.ee/kit/174/chapter/9809
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.7
Topics ET: matemaatika, duur, kolmkõla, rõõmus, trio, sõnaseletus, kolmik, kolmest, esinejast, koosnev, ansambel
Topics RU: математика
Topics EN: mathematics
Headings: Duur-kolmkõla; Rõõmus trio[sõnaseletus: trio – kolmik; kolmest esinejast koosnev ansambel]; JO-MI-SO; Pillerpall; Läksin metsa; Karvast sõpra oodates
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Kaheksandik­paus
URL: https://www.opiq.ee/kit/174/chapter/9810
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.8
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, kaheksandik, paus, asemel, dippido, lööki, vaikust, matkalaul
Topics RU: математика, деление, раздели, частное, половина
Topics EN: mathematics, division, divide, quotient, half
Headings: Kaheksandik­paus; TI asemel; Dippido; Pool lööki vaikust; Matkalaul
Task examples: Ühenda pausid vastavate löökidega.; Ühenda pausid vastavate löökidega.

## Dünaamika
URL: https://www.opiq.ee/kit/174/chapter/9811
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 1.9
Topics ET: matemaatika, dünaamika, kirjeldab, meeleolu, kiigu, liigu, laevukene, kõlatugevuse, tähistus
Topics RU: математика
Topics EN: mathematics
Headings: Dünaamika; Kirjeldab meeleolu; Kiigu, liigu, laevukene; Kõlatugevuse tähistus
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Pillid
URL: https://www.opiq.ee/kit/174/chapter/9820
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.1
Topics ET: matemaatika, pillid, mängurõõm, mitmel, moel, pillikõla, võimalused, igaühel, pill
Topics RU: математика
Topics EN: mathematics
Headings: Pillid; Mängurõõm mitmel moel; Pillikõla võimalused; Igaühel oma pill
Task examples: Ühenda pillirühma nimetus õigete pillidega.; Mõtle, kuidas tekivad pillihelid ja ühenda paarid.

## Kolmeosaline muusikavorm
URL: https://www.opiq.ee/kit/174/chapter/9828
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.10
Topics ET: matemaatika, kolmeosaline, muusikavorm, keskmine, kostab, teisiti, vändra, polka, vorm
Topics RU: математика
Topics EN: mathematics
Headings: Kolmeosaline muusikavorm; Keskmine kostab teisiti; Vändra polka; ABA-vorm
Task examples: Uuri laulu „Kooliaeg käes“ nooti. Leia selle A-osa ja B-osa alguskoht ning pala lõpp. Lohista vastused õigesse kohta.; Vali õiged vastused laulu „Kooliaeg käes“ noodi põhjal.

## Eesti laulud
URL: https://www.opiq.ee/kit/174/chapter/9817
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.11
Topics ET: matemaatika, eesti, laulud, kostke, keeles, isamaa, rõõm, kaart, kodukeel, kuku
Topics RU: математика
Topics EN: mathematics
Headings: Eesti laulud; Kostke, laulud, eesti keeles!; Mu isamaa, mu õnn ja rõõm; Eesti kaart; Kodukeel; Kuku, sa kägu; Õhtu ilu; Mõistatuslaul; Tule koju!; Liisutusmäng; Maakera

## Ludwig van Beethoven
URL: https://www.opiq.ee/kit/174/chapter/9829
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.12
Topics ET: matemaatika, ludwig, beethoven, suur, muusik, rõõmule, kevadele
Topics RU: математика
Topics EN: mathematics
Headings: Ludwig van Beethoven; Suur muusik; Ood rõõmule; Kevadele
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Nootide tähtnimetused
URL: https://www.opiq.ee/kit/174/chapter/9830
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.13
Topics ET: matemaatika, nootide, tähtnimetused, rändurite, päris, kodu, igal, noodil, nimi, klaviatuur
Topics RU: математика
Topics EN: mathematics
Headings: Nootide tähtnimetused; Rändurite päris kodu; Igal noodil oma nimi; Klaviatuur; Viiulivõti; Helihark; Ülesanded; Noodilaul
Task examples: Lohista noodijoonestiku vahedes asuvate nootide tähtnimed klaviatuurile.; Lohista noodijoonestiku joontel asuvate nootide tähtnimed õigetele klahvidele.

## Kordamine
URL: https://www.opiq.ee/kit/174/chapter/9831
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.14
Topics ET: matemaatika, kordamine, korda, harjutan, küsimused
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Küsimused ja ülesanded

## Klahvpillid
URL: https://www.opiq.ee/kit/174/chapter/9821
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.2
Topics ET: matemaatika, klahvpillid, aastaaja, kõla, pillide, jaotus, klahvkeelpillid, klahvpuhkpillid, elektripillid
Topics RU: математика
Topics EN: mathematics
Headings: Klahvpillid; Aastaaja kõla; Pillide jaotus; Klahvkeelpillid; Klahvpuhkpillid; Elektripillid; Ülesanded
Task examples: Jaota klahvpillid tulpadesse.; Märgi õiged vastused.

## Johann Sebastian Bach
URL: https://www.opiq.ee/kit/174/chapter/9822
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.3
Topics ET: matemaatika, johann, sebastian, bach, suurvaim, muusikas, muusikaajaloo, mõjutaja, menuett
Topics RU: математика
Topics EN: mathematics
Headings: Johann Sebastian Bach; Suurvaim muusikas; Muusikaajaloo mõjutaja; Menuett
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Keelpillid
URL: https://www.opiq.ee/kit/174/chapter/9823
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.4
Topics ET: matemaatika, keelpillid, helisev, perekond, sõrmede, poognaga, näppepillid, poogenpillid
Topics RU: математика
Topics EN: mathematics
Headings: Keelpillid; Helisev perekond; Sõrmede ja poognaga; Näppepillid; Poogenpillid; Ülesanded
Task examples: Jaota näppe- ja keelpillid kahte tulpa.; Riputa poogenpillide nimetused kõrguse järjekorras puule.

## Puhkpillid
URL: https://www.opiq.ee/kit/174/chapter/9824
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.5
Topics ET: matemaatika, puhkpillid, kostavad, kaugele, huulte, hingega, puupuhkpillid, vaskpuhkpillid
Topics RU: математика
Topics EN: mathematics
Headings: Puhkpillid; Kostavad kaugele; Huulte ja hingega; Puupuhkpillid; Vaskpuhkpillid; Ülesanded
Task examples: Jaota puhkpillid kahte tulpa.; Märgi õiged vastused.

## Löökpillid
URL: https://www.opiq.ee/kit/174/chapter/9825
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.6
Topics ET: matemaatika, löökpillid, suur, sõbralik, pere, kaks, ametit, meloodiapillid, rütmipillid, trummikomplekt
Topics RU: математика
Topics EN: mathematics
Headings: Löökpillid; Suur ja sõbralik pere; Kaks ametit; Meloodiapillid; Rütmipillid; Trummikomplekt; Ülesanded; Rütmiharjutused; Dubidu-dam; Kontsert
Task examples: Mõtle, millised märksõnad iseloomustav marimbat ja millised trianglit. Lohista sõnad õigesse tulpa.; Jaota löökpillid kahte tulpa.

## Uus rütm TA-I-TI
URL: https://www.opiq.ee/kit/174/chapter/9826
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.7
Topics ET: matemaatika, rütm, tants, viva, musica, muusika, kahe, löögi, sees
Topics RU: математика
Topics EN: mathematics
Headings: Uus rütm TA-I-TI; TA ja TI-TI tants; Viva la musica!; Muusika kahe löögi sees
Task examples: Plaksuta ja kuula. Märgi õiged vastused.; Plaksuta ja kuula. Märgi õiged vastused.

## Eesti rahvapillid
URL: https://www.opiq.ee/kit/174/chapter/9816
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.8
Topics ET: matemaatika, eesti, rahvapillid, igaühel, pill, lusti, tegevuse, saatjad, lõõtspill, keelpillid
Topics RU: математика
Topics EN: mathematics
Headings: Eesti rahvapillid; Igaühel oma pill; Lusti ja tegevuse saatjad; Lõõtspill; Keelpillid; Parmupill; Puhkpillid; Löökpillid; Ülesanded
Task examples: Jaota rahvapillid tulpadesse.; Märgi õiged vastused.

## Kaheosaline muusikavorm. Vastlad
URL: https://www.opiq.ee/kit/174/chapter/9827
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 2.9
Topics ET: matemaatika, kaheosaline, muusikavorm, vastlad, kaks, kõrvuti, vorm, liulaskmise, laul
Topics RU: математика
Topics EN: mathematics
Headings: Kaheosaline muusikavorm. Vastlad; Kaks kõrvuti; Vastlad; AB-vorm; Liulaskmise laul
Task examples: Uuri laulu „Mäkke ronimine“ nooti. Leia selle A-osa ja B-osa alguskoht ning pala lõpp. Lohista vastused õigesse kohta.; Vali õiged vastused laulu „Mäkke ronimine“ noodi põhjal.

## Lauluvara
URL: https://www.opiq.ee/kit/174/chapter/9832
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.1
Topics ET: matemaatika, loom, loomad, linnud, putukad, lauluvara, viisid, igaks, puhuks, kooliaeg, käes, juba, linnukesed, sügismõtted
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Lauluvara; Viisid igaks puhuks; Kooliaeg käes; Juba linnukesed; Sügismõtted; Laulu mõju; Kes võib tuuleta purjeta’; Ilmatu rock; Mardilaul; Kadrilaul; Ühtvalu; Ding-dong; Laulurõõm; Tule tantsima; Kuidas sõita?; Meestel on tubakat; Kingsepaemanda hällilaul; Kaseke; Kukeke; Taat, ära maga; Kehapillimäng; Kui linnud magavad; Mu süda, ärka üles; Hea muusika; Hei, ho!; Tirooli kägu; See on ema; Vitamiiniräpp; Kõnekaanon; Maiasmoka tšatša; Väikese nõia laul; Saatke meile meile; Konna kosjad; Istutasin toominga; Laul sai otsa

## Impressum
URL: https://www.opiq.ee/kit/174/chapter/19531
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.10
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Laulude tähestikuline loetelu
URL: https://www.opiq.ee/kit/174/chapter/22539
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.2
Topics ET: matemaatika, laulude, tähestikuline, loetelu
Topics RU: математика
Topics EN: mathematics
Headings: Laulude tähestikuline loetelu

## Kuuekeelne väikekannel
URL: https://www.opiq.ee/kit/174/chapter/9833
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.3
Topics ET: matemaatika, kuuekeelne, väikekannel, muistne, pill, häälestus, mänguvõtted, laulude, kandlesaated, isamaa
Topics RU: математика
Topics EN: mathematics
Headings: Kuuekeelne väikekannel; Muistne pill; Häälestus ja mänguvõtted; Laulude kandlesaated; Mu isamaa armas

## Plokkflöödi mänguvõtted
URL: https://www.opiq.ee/kit/174/chapter/9834
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.4
Topics ET: matemaatika, plokkflöödi, mänguvõtted, kümme, sõrme, tuhat, tooni, kehahoiak, käte, asend
Topics RU: математика
Topics EN: mathematics
Headings: Plokkflöödi mänguvõtted; Kümme sõrme, tuhat tooni; Kehahoiak; Käte asend pillil; Harjutused ja ülesanded; Ansamblimäng

## Klaverisaated
URL: https://www.opiq.ee/kit/174/chapter/9835
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.5
Topics ET: matemaatika, klaverisaated, kuidas, hakkame, elama, päkapiku, jõululaul, maria, menuett, kevadele
Topics RU: математика
Topics EN: mathematics
Headings: Klaverisaated; Kuidas me hakkame elama?; Päkapiku jõululaul; Ave Maria; Menuett; Kevadele

## Muusika­sõnastik
URL: https://www.opiq.ee/kit/174/chapter/9836
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.6
Topics ET: matemaatika, muusika, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Muusika­sõnastik

## Põhivara animatsioonid
URL: https://www.opiq.ee/kit/174/chapter/25906
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.7
Topics ET: matemaatika, põhivara, animatsioonid, pulss, meetrum, meetrumi, kuulamine, rütm, rütmiülesanne, takt
Topics RU: математика
Topics EN: mathematics
Headings: Põhivara animatsioonid; Pulss. Meetrum; Meetrumi kuulamine; Rütm; Rütmiülesanne; Takt. Taktimõõt; Teeme smuutit!; Noodijoonestik. Viiulivõti. Tähtnimetused; Muusikatähed; Astmenimed; Käemärkide tundmine; Duuri valem; Duuri kuulamise ülesanne; Molli valem; Molli kuulamise ülesanne

## Mõisted
URL: https://www.opiq.ee/kit/174/chapter/9837
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.8
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/174/chapter/9838
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile
Chapter ID: 3.9
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Muusikaõpik 4. klassile 2024 – Opiq
URL: https://www.opiq.ee/Kit/Details/552
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 140
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Muusikaõpik 4. klassile 2024 – Opiq
URL: https://www.opiq.ee/Kit/Details/552
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 180
Topics ET: matemaatika, muusikaõpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Õpiku tähised
URL: https://www.opiq.ee/kit/552/chapter/30665
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.1
Topics ET: matemaatika, õpiku, tähised, märkide, keel, mängi, kuula
Topics RU: математика
Topics EN: mathematics
Headings: Õpiku tähised; Märkide keel; Mängi ja kuula

## RA-astmerida ehk moll-helilaad
URL: https://www.opiq.ee/kit/552/chapter/30661
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.10
Topics ET: matemaatika, vesi, veeohutus, veekogu, astmerida, moll, helilaad, nukra, kõlaga, helirida, laulab
Topics RU: математика, вода, безопасность на воде, водоём
Topics EN: mathematics, water, water safety, body of water
Headings: RA-astmerida ehk moll-helilaad; Nukra kõlaga helirida; Vesi laulab; Astmerida RA-st RA-ni
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Moll-kolmkõla
URL: https://www.opiq.ee/kit/552/chapter/30662
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.11
Topics ET: matemaatika, moll, kolmkõla, nukker, trio, tuule, laul
Topics RU: математика
Topics EN: mathematics
Headings: Moll-kolmkõla; Nukker trio; RA-JO-MI; Tuule laul
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Uued rütmid TI-TI-RI ja TI-RI-TI
URL: https://www.opiq.ee/kit/552/chapter/30663
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.12
Topics ET: matemaatika, uued, rütmid, tantsusõbrad, peegel, rütmide, moodustamine, ostetud, hääl
Topics RU: математика
Topics EN: mathematics
Headings: Uued rütmid TI-TI-RI ja TI-RI-TI; Tantsusõbrad; Peegel; Rütmide moodustamine; Ostetud hääl; Meie elu
Task examples: Plaksuta ja kuula Eesti kohanimede rütmi. Märgi õiged vastused.; Plaksuta ja kuula Eesti kohanimede rütmi. Märgi õiged vastused.

## Hääl ja selle liigid
URL: https://www.opiq.ee/kit/552/chapter/30664
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.13
Topics ET: matemaatika, hääl, selle, liigid, hüüd, mitmel, moel, hääle, tekitamine, jaotus
Topics RU: математика
Topics EN: mathematics
Headings: Hääl ja selle liigid; Hüüd mitmel moel; Hääle tekitamine ja jaotus; Hääleliigid; Palju hääle kasutamise võimalusi; Koolitatud hääled meil ja mujal
Task examples: Sorteeri nais- ja meeshääled õigesse tulpa.; Riputa hääleliigid kõrguse järjekorras puule.

## Kordamine
URL: https://www.opiq.ee/kit/552/chapter/30666
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.14
Topics ET: matemaatika, kordamine, korda, harjutan, küsimused, sepapoisid, sepahaamer
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Küsimused ja ülesanded; Sepapoisid; Sepahaamer

## Talvelaulud
URL: https://www.opiq.ee/kit/552/chapter/30667
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.15
Topics ET: matemaatika, talvelaulud, pimeda, valgus, lumelaul, pühade, ootamine, lume, päkapiku, jõululaul
Topics RU: математика
Topics EN: mathematics
Headings: Talvelaulud; Pimeda aja valgus; Lumelaul; Pühade ootamine; Lume all; Päkapiku jõululaul; Üle lume lagedale; Püha öö; Jõulukell; Jõuluvana on tulemas; We Wish You a Merry Christmas; Uue aasta kaanon; Tabatinna; Kehapillimäng; Soe tee kamina ees; Talvehommik

## Astmenimed
URL: https://www.opiq.ee/kit/552/chapter/30653
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.2
Topics ET: matemaatika, astmenimed, laulan, näitan, mäkke, ronimine, käemärgid
Topics RU: математика
Topics EN: mathematics
Headings: Astmenimed; Laulan ja näitan; Mäkke ronimine; Käemärgid
Task examples: Uuri laulu „Mäkke ronimine“ takte 1–4. Lahenda ülesanded.; Märgi silpide loetelus astmenimed.

## Noodi­pikkused
URL: https://www.opiq.ee/kit/552/chapter/30654
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, noodi, pikkused, kõlamõõt, tantsulaul, rütmitabel, rütmimäng
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Noodi­pikkused; Kõlamõõt; Tantsulaul; Rütmitabel; Minu õpetaja; Rütmimäng; Sügis
Task examples: Sorteeri rütmid tulpadesse.; Kuula ja korda meloodia rütmi plaksutades, loe kaasa rütmisilpe. Vali õige laulu pealkiri.

## Taktimõõt
URL: https://www.opiq.ee/kit/552/chapter/30655
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.4
Topics ET: matemaatika, taktimõõt, nootide, korrastaja, tantsuringis, taktimõõdu, kaks, numbrit, miks
Topics RU: математика
Topics EN: mathematics
Headings: Taktimõõt; Nootide korrastaja; Tantsuringis; Taktimõõdu kaks numbrit; Miks?
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Taktimõõt 4/4
URL: https://www.opiq.ee/kit/552/chapter/30656
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.5
Topics ET: matemaatika, taktimõõt, marsitaktis, edasi, tule, sõber, kaasa, neli, lööki, taktis
Topics RU: математика
Topics EN: mathematics
Headings: Taktimõõt 4/4; Marsitaktis edasi; Tule, sõber, kaasa; Neli lööki taktis; Tervenoot ja tervepaus
Task examples: Lausu sõnu silphaaval ja plaksuta rütmi. Kas sõnade rütm koosneb neljast löögist (silbist) või mitte? Vali õige vastus.; Lausu sõnu silphaaval ja plaksuta rütmi. Kas sõnade rütm koosneb neljast löögist (silbist) või mitte? Vali õige vastus.

## JO-astmerida ehk duur-helilaad
URL: https://www.opiq.ee/kit/552/chapter/30657
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.6
Topics ET: matemaatika, astmerida, duur, helilaad, rõõmsa, kõlaga, helirida, kuidas, hakkame, elama
Topics RU: математика
Topics EN: mathematics
Headings: JO-astmerida ehk duur-helilaad; Rõõmsa kõlaga helirida; Kuidas me hakkame elama?; Astmerida JO-st JO'-ni
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Duur-kolmkõla
URL: https://www.opiq.ee/kit/552/chapter/30658
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.7
Topics ET: matemaatika, duur, kolmkõla, rõõmus, trio, sõnaseletus, kolmik, kolmest, esinejast, koosnev, ansambel
Topics RU: математика
Topics EN: mathematics
Headings: Duur-kolmkõla; Rõõmus trio[sõnaseletus: trio – kolmik; kolmest esinejast koosnev ansambel]; JO-MI-SO; Pillerpall; Läksin metsa; Karvast sõpra oodates
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Kaheksandik­paus
URL: https://www.opiq.ee/kit/552/chapter/30659
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.8
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, kaheksandik, paus, asemel, dippido, lööki, vaikust, matkalaul
Topics RU: математика, деление, раздели, частное, половина
Topics EN: mathematics, division, divide, quotient, half
Headings: Kaheksandik­paus; TI asemel; Dippido; Pool lööki vaikust; Matkalaul
Task examples: Ühenda pausid vastavate löökidega.; Ühenda pausid vastavate löökidega.

## Dünaamika
URL: https://www.opiq.ee/kit/552/chapter/30660
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 1.9
Topics ET: matemaatika, dünaamika, kirjeldab, meeleolu, kiigu, liigu, laevukene, kõlatugevuse, tähistus
Topics RU: математика
Topics EN: mathematics
Headings: Dünaamika; Kirjeldab meeleolu; Kiigu, liigu, laevukene; Kõlatugevuse tähistus
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Pillid
URL: https://www.opiq.ee/kit/552/chapter/30668
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.1
Topics ET: matemaatika, pillid, mängurõõm, mitmel, moel, pillikõla, võimalused, igaühel, pill
Topics RU: математика
Topics EN: mathematics
Headings: Pillid; Mängurõõm mitmel moel; Pillikõla võimalused; Igaühel oma pill
Task examples: Ühenda pillirühma nimetus õigete pillidega.; Mõtle, kuidas tekivad pillihelid ja ühenda paarid.

## Kolmeosaline muusikavorm
URL: https://www.opiq.ee/kit/552/chapter/30677
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.10
Topics ET: matemaatika, kolmeosaline, muusikavorm, keskmine, kostab, teisiti, vändra, polka, vorm
Topics RU: математика
Topics EN: mathematics
Headings: Kolmeosaline muusikavorm; Keskmine kostab teisiti; Vändra polka; ABA-vorm
Task examples: Uuri laulu „Kooliaeg käes“ nooti. Leia selle A-osa ja B-osa alguskoht ning pala lõpp. Lohista vastused õigesse kohta.; Vali õiged vastused laulu „Kooliaeg käes“ noodi põhjal.

## Eesti laulud
URL: https://www.opiq.ee/kit/552/chapter/30680
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.11
Topics ET: matemaatika, eesti, laulud, kostke, keeles, isamaa, rõõm, kaart, kodukeel, kuku
Topics RU: математика
Topics EN: mathematics
Headings: Eesti laulud; Kostke, laulud, eesti keeles!; Mu isamaa, mu õnn ja rõõm; Eesti kaart; Kodukeel; Kuku, sa kägu; Õhtu ilu; Mõistatuslaul; Tootsi ja poiste tantsulugu; Tule koju!; Liisutusmäng; Maakera

## Ludwig van Beethoven
URL: https://www.opiq.ee/kit/552/chapter/30678
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.12
Topics ET: matemaatika, ludwig, beethoven, suur, muusik, rõõmule, kevadele
Topics RU: математика
Topics EN: mathematics
Headings: Ludwig van Beethoven; Suur muusik; Ood rõõmule; Kevadele
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Nootide tähtnimetused
URL: https://www.opiq.ee/kit/552/chapter/30679
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.13
Topics ET: matemaatika, nootide, tähtnimetused, rändurite, päris, kodu, igal, noodil, nimi, klaviatuur
Topics RU: математика
Topics EN: mathematics
Headings: Nootide tähtnimetused; Rändurite päris kodu; Igal noodil oma nimi; Klaviatuur; Viiulivõti; Helihark; Ülesanded; Noodilaul
Task examples: Lohista noodijoonestiku vahedes asuvate nootide tähtnimed klaviatuurile.; Lohista noodijoonestiku joontel asuvate nootide tähtnimed õigetele klahvidele.

## Kordamine
URL: https://www.opiq.ee/kit/552/chapter/30681
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.14
Topics ET: matemaatika, kordamine, korda, harjutan, küsimused
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Küsimused ja ülesanded

## Klahvpillid
URL: https://www.opiq.ee/kit/552/chapter/30669
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.2
Topics ET: matemaatika, klahvpillid, aastaaja, kõla, pillide, jaotus, klahvkeelpillid, klahvpuhkpillid, elektripillid
Topics RU: математика
Topics EN: mathematics
Headings: Klahvpillid; Aastaaja kõla; Pillide jaotus; Klahvkeelpillid; Klahvpuhkpillid; Elektripillid; Ülesanded
Task examples: Jaota klahvpillid tulpadesse.; Märgi õiged vastused.

## Johann Sebastian Bach
URL: https://www.opiq.ee/kit/552/chapter/30670
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.3
Topics ET: matemaatika, johann, sebastian, bach, suurvaim, muusikas, muusikaajaloo, mõjutaja, menuett
Topics RU: математика
Topics EN: mathematics
Headings: Johann Sebastian Bach; Suurvaim muusikas; Muusikaajaloo mõjutaja; Menuett
Task examples: Märgi õiged vastused.; Märgi õiged vastused.

## Keelpillid
URL: https://www.opiq.ee/kit/552/chapter/30671
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.4
Topics ET: matemaatika, keelpillid, helisev, perekond, sõrmede, poognaga, näppepillid, poogenpillid
Topics RU: математика
Topics EN: mathematics
Headings: Keelpillid; Helisev perekond; Sõrmede ja poognaga; Näppepillid; Poogenpillid; Ülesanded
Task examples: Jaota näppe- ja keelpillid kahte tulpa.; Riputa poogenpillide nimetused kõrguse järjekorras puule.

## Puhkpillid
URL: https://www.opiq.ee/kit/552/chapter/30672
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.5
Topics ET: matemaatika, puhkpillid, kostavad, kaugele, huulte, hingega, puupuhkpillid, vaskpuhkpillid
Topics RU: математика
Topics EN: mathematics
Headings: Puhkpillid; Kostavad kaugele; Huulte ja hingega; Puupuhkpillid; Vaskpuhkpillid; Ülesanded
Task examples: Jaota puhkpillid kahte tulpa.; Märgi õiged vastused.

## Löökpillid
URL: https://www.opiq.ee/kit/552/chapter/30673
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.6
Topics ET: matemaatika, löökpillid, suur, sõbralik, pere, kaks, ametit, meloodiapillid, rütmipillid, trummikomplekt
Topics RU: математика
Topics EN: mathematics
Headings: Löökpillid; Suur ja sõbralik pere; Kaks ametit; Meloodiapillid; Rütmipillid; Trummikomplekt; Ülesanded; Rütmiharjutused; Dubidu-dam; Harjutus; Kontsert
Task examples: Mõtle, millised märksõnad iseloomustav marimbat ja millised trianglit. Lohista sõnad õigesse tulpa.; Jaota löökpillid kahte tulpa.

## Uus rütm TA-I-TI
URL: https://www.opiq.ee/kit/552/chapter/30674
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.7
Topics ET: matemaatika, rütm, tants, viva, musica, muusika, kahe, löögi, sees
Topics RU: математика
Topics EN: mathematics
Headings: Uus rütm TA-I-TI; TA ja TI-TI tants; Viva la musica!; Muusika kahe löögi sees
Task examples: Plaksuta ja kuula. Märgi õiged vastused.; Plaksuta ja kuula. Märgi õiged vastused.

## Eesti rahvapillid
URL: https://www.opiq.ee/kit/552/chapter/30675
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.8
Topics ET: matemaatika, eesti, rahvapillid, igaühel, pill, lusti, tegevuse, saatjad, lõõtspill, keelpillid
Topics RU: математика
Topics EN: mathematics
Headings: Eesti rahvapillid; Igaühel oma pill; Lusti ja tegevuse saatjad; Lõõtspill; Keelpillid; Parmupill; Puhkpillid; Löökpillid; Ülesanded
Task examples: Jaota rahvapillid tulpadesse.; Märgi õiged vastused.

## Kaheosaline muusikavorm. Vastlad
URL: https://www.opiq.ee/kit/552/chapter/30676
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 2.9
Topics ET: matemaatika, kaheosaline, muusikavorm, vastlad, kaks, kõrvuti, vorm, liulaskmise, laul
Topics RU: математика
Topics EN: mathematics
Headings: Kaheosaline muusikavorm. Vastlad; Kaks kõrvuti; Vastlad; AB-vorm; Liulaskmise laul
Task examples: Uuri laulu „Mäkke ronimine“ nooti. Leia selle A-osa ja B-osa alguskoht ning pala lõpp. Lohista vastused õigesse kohta.; Vali õiged vastused laulu „Mäkke ronimine“ noodi põhjal.

## Lauluvara
URL: https://www.opiq.ee/kit/552/chapter/30683
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.1
Topics ET: matemaatika, lauluvara, viisid, igaks, puhuks, kooliaeg, käes, juba, linnukesed, laulu
Topics RU: математика
Topics EN: mathematics
Headings: Lauluvara; Viisid igaks puhuks; Kooliaeg käes; Juba linnukesed; Laulu mõju; Kes võib tuuleta purjeta’; Ilmatu rock; Mardilaul; Kadrilaul; Mina lätsi mõtsa; Sügisball; Ühtvalu; Ding-dong; Laulurõõm; Kuidas sõita?; Kingsepaemanda hällilaul; Kaseke; Kukeke; Taat, ära maga; Kehapillikaanon; Mu süda, ärka üles; Hea muusika; Hei-ho!; Tirooli kägu; See on ema; Vitamiiniräpp; Kõnekaanon; Lahtilükkamise laul; Lase kiik käia; Laul Põhjamaast; Maiasmoka tšatša; Rõõm on täitnud maa; Saatke meile meile; Konna kosjad; Istutasin toominga; Laul sai otsa

## Impressum
URL: https://www.opiq.ee/kit/552/chapter/30691
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.10
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Laulude tähestikuline loetelu
URL: https://www.opiq.ee/kit/552/chapter/30684
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.2
Topics ET: matemaatika, laulude, tähestikuline, loetelu
Topics RU: математика
Topics EN: mathematics
Headings: Laulude tähestikuline loetelu

## Kuuekeelne väikekannel
URL: https://www.opiq.ee/kit/552/chapter/30685
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.3
Topics ET: matemaatika, kuuekeelne, väikekannel, muistne, pill, häälestus, mänguvõtted, laulude, kandlesaated, isamaa
Topics RU: математика
Topics EN: mathematics
Headings: Kuuekeelne väikekannel; Muistne pill; Häälestus ja mänguvõtted; Laulude kandlesaated; Mu isamaa armas

## Plokkflöödi mänguvõtted
URL: https://www.opiq.ee/kit/552/chapter/30686
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.4
Topics ET: matemaatika, plokkflöödi, mänguvõtted, kümme, sõrme, tuhat, tooni, kehahoiak, käte, asend
Topics RU: математика
Topics EN: mathematics
Headings: Plokkflöödi mänguvõtted; Kümme sõrme, tuhat tooni; Kehahoiak; Käte asend pillil; Harjutused ja ülesanded; Ansamblimäng

## Klaverisaated
URL: https://www.opiq.ee/kit/552/chapter/30687
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.5
Topics ET: matemaatika, klaverisaated, kuidas, hakkame, elama, päkapiku, jõululaul, maria, menuett, kevadele
Topics RU: математика
Topics EN: mathematics
Headings: Klaverisaated; Kuidas me hakkame elama?; Päkapiku jõululaul; Ave Maria; Menuett; Kevadele

## Muusika­sõnastik
URL: https://www.opiq.ee/kit/552/chapter/30688
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.6
Topics ET: matemaatika, muusika, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Muusika­sõnastik

## Põhivara animatsioonid
URL: https://www.opiq.ee/kit/552/chapter/30682
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.7
Topics ET: matemaatika, põhivara, animatsioonid, pulss, meetrum, meetrumi, kuulamine, rütm, rütmiülesanne, takt
Topics RU: математика
Topics EN: mathematics
Headings: Põhivara animatsioonid; Pulss. Meetrum; Meetrumi kuulamine; Rütm; Rütmiülesanne; Takt. Taktimõõt; Teeme smuutit!; Noodijoonestik. Viiulivõti. Tähtnimetused; Muusikatähed; Astmenimed; Käemärkide tundmine; Duuri valem; Duuri kuulamise ülesanne; Molli valem; Molli kuulamise ülesanne

## Mõisted
URL: https://www.opiq.ee/kit/552/chapter/30689
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.8
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/552/chapter/30690
Book: muusika 4 klass
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: muusikaõpik_4._klassile_2024
Chapter ID: 3.9
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused
