## Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
URL: https://www.opiq.ee/Kit/Details/161
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 1
Topics ET: matemaatika, kehalise, kasvatuse, tööraamat, teisele, kooliastmele, opiq
Topics RU: математика
Topics EN: mathematics

## Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
URL: https://www.opiq.ee/Kit/Details/161
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 24
Topics ET: matemaatika, kehalise, kasvatuse, tööraamat, teisele, kooliastmele, opiq
Topics RU: математика
Topics EN: mathematics

## Sissejuhatus
URL: https://www.opiq.ee/kit/161/chapter/9053
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 1.1
Topics ET: matemaatika, sissejuhatus, kallis, sõber
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus; Kallis sõber!

## Spordi mõiste
URL: https://www.opiq.ee/kit/161/chapter/9054
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 2.1
Topics ET: matemaatika, spordi, mõiste, kirjuta, sõnadega, sinu, arvates, sport
Topics RU: математика
Topics EN: mathematics
Headings: Spordi mõiste; Kirjuta oma sõnadega, mis on sinu arvates sport.

## Tervis ja treening
URL: https://www.opiq.ee/kit/161/chapter/9055
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 2.2
Topics ET: matemaatika, inimene, keha, meeled, tervis, treening, tervislik, seisund, pulss, sporditraumad, esmaabi, tüüpilised, spordivigastused
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Tervis ja treening; MINU TERVISLIK SEISUND; PULSS; SPORDITRAUMAD JA ESMAABI; TÜÜPILISED SPORDIVIGASTUSED; Pane esmaabi võtted õigesse järjekorda.; Mis järjekorras mida teed?; Lihaste krambid; Mida teha lihase valulikkuse korral? Tõmba maha valed vastusevariandid.; KUUMAKAHJUSTUSED; Millised kuumakahjustuse vältimise võtted on valed? Tõmba need maha. Loe uuesti läbi õiged soovitused, jäta need meelde.; KÜLMAKAHJUSTUSED; Tõmba valed soovitused maha; ÜLEKOORMUS

## Sport ja meedia
URL: https://www.opiq.ee/kit/161/chapter/9056
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 2.3
Topics ET: matemaatika, sport, meedia, andke, välja, klassi, spordileht, mõnd, sportlast, spordisündmust, tutvustav, seinaleht, koostage, klassis, ühistööna, sporditeemaline
Topics RU: математика
Topics EN: mathematics
Headings: Sport ja meedia; Andke välja klassi spordileht või mõnd sportlast, spordisündmust või -ala tutvustav seinaleht.; Koostage klassis ühistööna sporditeemaline raamat.

## Sport Eestis
URL: https://www.opiq.ee/kit/161/chapter/9057
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 2.4
Topics ET: matemaatika, sport, eestis, tutvusta, mõnest, teisest, riigist, pärit, spordisõbrale, kodumaad, kujutle, sinu, kodukohas, toimuvad, spordivõistlused
Topics RU: математика
Topics EN: mathematics
Headings: Sport Eestis; Tutvusta mõnest teisest riigist pärit spordisõbrale oma kodumaad.; Kujutle, et sinu kodukohas toimuvad spordivõistlused ...; EESTI SPORTLASED; Kirjuta pildi alla sportlase nimi. Vaata eelmist ülesannet.; Kes ei sobi ritta? Miks?; Nummerda sportlased tähestikulises järjekorras; Kas tunned Eesti sportlasi? Kirjuta pildi alla sportlase nimi ja spordiala.; Sobita spordiala ja olümpiavõitja nimi.

## Mina ja sport
URL: https://www.opiq.ee/kit/161/chapter/9058
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 2.5
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, mina, sport, täida, lemmikspordialade, kohta, tabel, milliste, treeningrühmade, töös, osaled, mitu, nädalas, millistel
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Mina ja sport; Täida ülesanne oma lemmikspordialade kohta.; Täida tabel; Milliste treeningrühmade töös osaled ja mitu korda nädalas?; Millistel võistlustel oled osalenud? Täida tabel.; Kirjuta tabelisse oma parimad sportlikud saavutused.; Kirjuta tabelisse oma lemmiksportlased.; Täienda oma sugupuud.

## Spordialad
URL: https://www.opiq.ee/kit/161/chapter/9062
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.1
Topics ET: matemaatika, spordialad, millised, ürgaja, inimese, tegevused, võisid, olla, tõukeks, järgmiste, spordialade, tekkimisele, vali, eelmisest, ülesandest, tegevus
Topics RU: математика
Topics EN: mathematics
Headings: Spordialad; Millised ürgaja inimese tegevused võisid olla tõukeks järgmiste spordialade tekkimisele?; Vali eelmisest ülesandest üks ürgaja inimese tegevus ning joonista koomiks või kirjuta, kuidas sellest võis kujuneda tänapäevane spordiala. Vajaduse korral kasuta ajaloo- või spordi ajaloo raamatuid.

## Kergejõustik
URL: https://www.opiq.ee/kit/161/chapter/9059
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.2
Topics ET: matemaatika, kergejõustik, kergejõustikualad, vali, spordiala, juurde, õige, reegel
Topics RU: математика
Topics EN: mathematics
Headings: Kergejõustik; KERGEJÕUSTIKUALAD; Vali spordiala juurde õige reegel.

## Pallimängud
URL: https://www.opiq.ee/kit/161/chapter/9060
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.3
Topics ET: matemaatika, pallimängud, jalgpall, jalgpallimäng, paberil, otsi, internetist, eestlastest, jalgpallureid, mängivad
Topics RU: математика
Topics EN: mathematics
Headings: Pallimängud; JALGPALL; Jalgpallimäng paberil.; Otsi internetist eestlastest jalgpallureid, kes mängivad välisriikide klubides. Kirjuta mängija nimi ja klubi, kus ta mängib.; KORVPALL; Tee rist asjade või tegevuste juurde, mis ei sobi korvpallimänguga.; RAHVASTEPALL; Kuues variant

## Ujumine
URL: https://www.opiq.ee/kit/161/chapter/9063
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.4
Topics ET: matemaatika, ujumine, traditsioonilised, võistlusdistantsid, kirjuta, millist, ujumisstiili, pildil, kujutatakse, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: Ujumine; TRADITSIOONILISED VÕISTLUSDISTANTSID; Kirjuta, millist ujumisstiili pildil kujutatakse.; KUIDAS AIDATA HÄDASOLIJAT VEES; Märgi pildil ohtlikud olukorrad punase ristiga. Arutle, mille poolest on iga märgitud olukord ohtlik. Milliseid hädasolija abistamise võtteid kasutaksid? (Vt eelmisi jooniseid.)

## Võimlemine
URL: https://www.opiq.ee/kit/161/chapter/9061
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.5
Topics ET: matemaatika, võimlemine, võistlusvõimlemine
Topics RU: математика
Topics EN: mathematics
Headings: Võimlemine; VÕISTLUSVÕIMLEMINE

## Talialad
URL: https://www.opiq.ee/kit/161/chapter/9064
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: en
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.6
Topics ET: matemaatika, arv, arvud, arvu, numbrid, talialad, talisport, saalis, proovi, järele, kirjuta, pildi, juurde, sobiv, saksakeelse, nimetuse, ülemisse, ingliskeelse, alumisse
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Talialad; Talisport saalis. Proovi järele.; Kirjuta pildi juurde sobiv number. Saksakeelse nimetuse number kirjuta ülemisse, ingliskeelse nimetuse number alumisse ruutu. Kui vaja, kasuta sõnaraamatut. Pildi alla kirjuta ala eestikeelne nimetus.; SUUSATAMINE; Kirjuta pildi alla õige tegevus.; JÄÄHOKI; Täida lüngad.; ILUUISUTAMINE; Kujunda iluuisutaja esinemiskostüüm või jäähokimeeskonna võistlusvorm.

## Ülesandeid spordialade kohta
URL: https://www.opiq.ee/kit/161/chapter/9065
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.7
Topics ET: matemaatika, ülesandeid, spordialade, kohta, kirjuta, moodusta, silpidest, spordialad, need, välja, klassiõhtul, sünnipäevapeol, saab, kaaslastega, korraldada, toredaid
Topics RU: математика
Topics EN: mathematics
Headings: Ülesandeid spordialade kohta; Kirjuta.; Moodusta silpidest spordialad. Kirjuta need välja.; Klassiõhtul või sünnipäevapeol saab kaaslastega korraldada toredaid võistlusi. Kirjuta iga võistluse kirjelduse juurde, milliseid võimeid ja omadusi see arendab.

## Piktogramm
URL: https://www.opiq.ee/kit/161/chapter/9066
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 3.8
Topics ET: matemaatika, piktogramm, kirjuta, piktogrammi, alla, millist, spordiala, sellel, kujutatakse, leia, spordialad, joonista, kohta
Topics RU: математика
Topics EN: mathematics
Headings: Piktogramm; Kirjuta iga piktogrammi alla, millist spordiala sellel kujutatakse.; Leia spordialad. Joonista iga ala kohta oma piktogramm.

## Antiikolümpiamängud
URL: https://www.opiq.ee/kit/161/chapter/9069
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 4.1
Topics ET: matemaatika, antiikolümpiamängud, ühenda, joonega
Topics RU: математика
Topics EN: mathematics
Headings: Antiikolümpiamängud; Ühenda joonega.

## Tänapäevaste olümpiamängude sünnilugu
URL: https://www.opiq.ee/kit/161/chapter/9070
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 4.2
Topics ET: matemaatika, tänapäevaste, olümpiamängude, sünnilugu
Topics RU: математика
Topics EN: mathematics
Headings: Tänapäevaste olümpiamängude sünnilugu

## Olümpialiikumise algus Eestis
URL: https://www.opiq.ee/kit/161/chapter/9071
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 4.3
Topics ET: matemaatika, olümpialiikumise, algus, eestis
Topics RU: математика
Topics EN: mathematics
Headings: Olümpialiikumise algus Eestis

## Olümpialiikumise eesmärgid
URL: https://www.opiq.ee/kit/161/chapter/9067
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 4.4
Topics ET: matemaatika, olümpialiikumise, eesmärgid, huvitavaid, fakte, olümpiamängude, kohta
Topics RU: математика
Topics EN: mathematics
Headings: Olümpialiikumise eesmärgid; HUVITAVAID FAKTE OLÜMPIAMÄNGUDE KOHTA

## Olümpiamängude sümboolika
URL: https://www.opiq.ee/kit/161/chapter/9068
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 4.5
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, olümpiamängude, sümboolika, mõtle, välja, kirjuta, siia, sportlikke, eesmärke, väljendav, juhtlause, deviis, olümpiadeviis, ilukirjas
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Olümpiamängude sümboolika; Mõtle välja ja kirjuta siia oma sportlikke eesmärke väljendav juhtlause e deviis.; Kirjuta olümpiadeviis ilukirjas.; OLÜMPIATULI; Värvi pilt vastavalt numbritele.; HÜMN; Laulge koos muusikaõpetajaga mõnd sporditeemaist laulu. Püüa ise luua oma kooli spordiürituse jaoks laul, näiteks hümn kooliolümpiamängudeks.; OLÜMPIAMASKOTID; OLÜMPIAMÄNGUDE AVA- JA LÕPUTSEREMOONIA; Olümpiavanne ehk tõotus on üks avatseremoonia osadest. Esimest korda kasutati seda 1920. aastal Antverpenis. Olümpiatõotuse annab korraldava maa sportlane. Eraldi tõotuse annavad ka kohtunikud.; Nummerda, millises järjekorras toimub olümpiamängude avatseremoonia.; OLÜMPIAMEDALID; Kujunda ise medali esi- ja tagakülg.; ANTIIKOLÜMPIAMÄNGUDEST NÜÜDISAEGSETE OLÜMPIAMÄNGUDENI; Täida lüngad; Joonista pjedestaalile sportlased. Kujunda esindusdress ja värvi lipp vastavalt sellele, millist riiki sportlane esindab.; Kujunda oma kooli spordimeeskonna T-särk.

## Aus mäng
URL: https://www.opiq.ee/kit/161/chapter/9072
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 5.1
Topics ET: matemaatika, mäng, tõmba, valed, väited, maha
Topics RU: математика
Topics EN: mathematics
Headings: Aus mäng; Tõmba valed väited maha.

## Nuputamist
URL: https://www.opiq.ee/kit/161/chapter/9073
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 5.2
Topics ET: matemaatika, nuputamist, moodusta, sõnaga, sport, võimalikult, palju, liitsõnu, leia, spordivahendit, paiguta, leitud, sõnad, tabelisse, viktoriin, täida
Topics RU: математика
Topics EN: mathematics
Headings: Nuputamist; Moodusta sõnaga sport võimalikult palju liitsõnu.; Leia 37 spordivahendit.; Paiguta leitud sõnad tabelisse.; Viktoriin.; Täida tabel. Lisa ise veel tähti.

## Soovitatav kirjandus
URL: https://www.opiq.ee/kit/161/chapter/9074
Book: Kehalise kasvatuse tööraamat teisele kooliastmele – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: kehalise_kasvatuse_tööraamat_teisele_kooliastmele
Chapter ID: 5.3
Topics ET: matemaatika, soovitatav, kirjandus, ülesannete, seos, teiste, ainetundidega
Topics RU: математика
Topics EN: mathematics
Headings: Soovitatav kirjandus; Ülesannete seos teiste ainetundidega
