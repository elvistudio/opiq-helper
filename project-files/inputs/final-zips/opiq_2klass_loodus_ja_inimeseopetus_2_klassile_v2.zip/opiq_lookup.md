## Loodus- ja inimeseõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/56
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1
Topics ET: loodusõpetus, loodus, keskkond, inimeseõpetus, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodus- ja inimeseõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/56
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 62
Topics ET: loodusõpetus, loodus, keskkond, inimeseõpetus, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Kodu ja naabrid
URL: https://www.opiq.ee/kit/56/chapter/2749
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.1
Topics ET: loodusõpetus, kodu, naabrid, hannese, kiri, erinevad, kodud, mina, nabalinna, plaan
Topics RU: природоведение
Topics EN: science
Headings: Kodu ja naabrid; Hannese kiri; Erinevad kodud; Mina; Nabalinna plaan

## Vee ringlemine
URL: https://www.opiq.ee/kit/56/chapter/2758
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.10
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, ringlemine, ringleb, loigud, pilved, vihm, lisa, emaläte, veekogude
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Vee ringlemine; Vesi ringleb; Loigud; Pilved ja vihm; Lisa. Emaläte; Veekogude kaart

## Ilma ennustamine
URL: https://www.opiq.ee/kit/56/chapter/2759
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.11
Topics ET: loodusõpetus, ilma, ennustamine, tuul, millega, seda, mõõdetakse
Topics RU: природоведение
Topics EN: science
Headings: Ilma ennustamine; Ilm; Tuul; Millega seda mõõdetakse?

## Ilm
URL: https://www.opiq.ee/kit/56/chapter/2760
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.12
Topics ET: loodusõpetus, ilma, iseloomustamine, ilmale, vastav, riietus, ilmagraafikud, ilmamärgid, ilmastikunähtused, ilmamõõteriistad
Topics RU: природоведение
Topics EN: science
Headings: Ilm; Ilma iseloomustamine; Ilmale vastav riietus; Ilmagraafikud; Ilmamärgid; Ilmastikunähtused; Ilmamõõteriistad

## Tervis
URL: https://www.opiq.ee/kit/56/chapter/2761
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.13
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, hannes, haige, haigused, allergia, haiguste, vältimine
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Tervis; Hannes on haige; Haigused ja allergia; Haiguste vältimine

## Esmaabi
URL: https://www.opiq.ee/kit/56/chapter/2762
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.14
Topics ET: loodusõpetus, esmaabi, esialgne, käitumine, õnnetuse, korral
Topics RU: природоведение
Topics EN: science
Headings: Esmaabi; Esmaabi on esialgne abi; Käitumine õnnetuse korral

## Loomad
URL: https://www.opiq.ee/kit/56/chapter/2763
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.15
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, loomariik, imetajad, loomade, kehaosad, vähi
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Loomad; Loomariik; Imetajad; Loomade kehaosad; Vähi kehaosad

## Looma kirjeldamine
URL: https://www.opiq.ee/kit/56/chapter/2764
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.16
Topics ET: loodusõpetus, looma, kirjeldamine, kirjelda, loomade, kehaosi, konna, hobuse, luige, räime
Topics RU: природоведение
Topics EN: science
Headings: Looma kirjeldamine; Kirjelda loomade kehaosi; Kirjelda konna, hobuse, luige ja räime kehaosi.

## Elupaik
URL: https://www.opiq.ee/kit/56/chapter/2765
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.17
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, elupaik, loomade, elupaigad, kodud, millises, kodus, elab, looma
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Elupaik; Loomade elupaigad; Loomade kodud; Millises kodus elab loom?; Looma elupaik; Taimede kasvukohad; Erinevad kasvukohad

## Metsas elavad loomad
URL: https://www.opiq.ee/kit/56/chapter/2766
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.18
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, metsas, elavad, hannes, loomade, tegevusjäljed, kuklased, suur, kirjurähn
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Metsas elavad loomad; Hannes metsas; Loomade tegevusjäljed metsas; Kuklased ja suur-kirjurähn; Kuidas käituda metsas?

## Põder ja metskits
URL: https://www.opiq.ee/kit/56/chapter/2767
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.19
Topics ET: loodusõpetus, põder, metskits, põdra, kehaosad, toidulaud, metskitse
Topics RU: природоведение
Topics EN: science
Headings: Põder ja metskits; Põder; Põdra kehaosad; Põdra toidulaud; Metskits; Metskitse kehaosad

## Maal või linnas?
URL: https://www.opiq.ee/kit/56/chapter/2750
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.2
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, maal, linnas, kodu, milline, võib, olla, linnaelu, lisa
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Maal või linnas?; Kodu; Milline võib kodu olla?; Maa- ja linnaelu võrdlemine; Lisa. Kodud mujal maailmas

## Pruunkaru ja metssiga
URL: https://www.opiq.ee/kit/56/chapter/2768
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.20
Topics ET: loodusõpetus, pruunkaru, metssiga, karu, kehaosad, toidulaud, metssea, toidulaua, sortimine
Topics RU: природоведение
Topics EN: science
Headings: Pruunkaru ja metssiga; Pruunkaru; Karu kehaosad; Karu toidulaud; Metssiga; Metssea kehaosad; Metssea toidulaua sortimine

## Hunt ja rebane
URL: https://www.opiq.ee/kit/56/chapter/2769
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.21
Topics ET: loodusõpetus, hunt, rebane, hundi, kehaosad, keda, sööb, rebase
Topics RU: природоведение
Topics EN: science
Headings: Hunt ja rebane; Hunt; Hundi kehaosad; Keda hunt sööb?; Rebane; Rebase kehaosad

## Loomapark, loomaaed ja lemmikloomad
URL: https://www.opiq.ee/kit/56/chapter/2770
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.22
Topics ET: loodusõpetus, loomapark, loomaaed, lemmikloomad, hannese, kiri, koerte, ametid
Topics RU: природоведение
Topics EN: science
Headings: Loomapark, loomaaed ja lemmikloomad; Hannese kiri; Lemmikloomad; Loomapark ja loomaaed; Koerte ametid

## Jõulud
URL: https://www.opiq.ee/kit/56/chapter/2771
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.23
Topics ET: loodusõpetus, jõulud, jõulude, tähistamine, lisa, jõuluvana, jõulusalm, kõige, ilusam, jõulupuu
Topics RU: природоведение
Topics EN: science
Headings: Jõulud; Jõulude tähistamine; Lisa. Jõuluvana; Jõulusalm; Kõige ilusam jõulupuu; Kirjuta oma jõulusalm.

## Lähedased inimesed
URL: https://www.opiq.ee/kit/56/chapter/2751
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.3
Topics ET: loodusõpetus, lähedased, inimesed, hannese, perekond, sugulased, mõisted, sõbrad
Topics RU: природоведение
Topics EN: science
Headings: Lähedased inimesed; Hannese lähedased; Minu perekond; Hannese sugulased; Mõisted; Sõbrad ja sugulased

## Mets
URL: https://www.opiq.ee/kit/56/chapter/2752
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, mets, hannes, käib, metsas, erinevad, metsad, puud, eesti, lehtpuud
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Mets; Hannes käib metsas; Erinevad metsad; Puud; Eesti lehtpuud; Eesti okaspuud; Puu osad; Leht- ja okaspuu

## Lehtpuud
URL: https://www.opiq.ee/kit/56/chapter/2753
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.5
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, lehtpuud, lehtpuude, tunnused, kask, tamm, metsas
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Lehtpuud; Lehtpuude tunnused; Kask ja tamm; Aastaajad metsas

## Okaspuud
URL: https://www.opiq.ee/kit/56/chapter/2754
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.6
Topics ET: loodusõpetus, okaspuud, okaspuudel, okkad, okaspuu, mõiste, käbid, marikäbid, lisa, aastarõngad
Topics RU: природоведение
Topics EN: science
Headings: Okaspuud; Okaspuudel on okkad; Okaspuu mõiste; Käbid ja marikäbid; Lisa. Aastarõngad; Tüve läbilõige; Leht- ja okaspuud; Tunne Eesti puid; Lehtpuu ja okaspuu

## Põõsad
URL: https://www.opiq.ee/kit/56/chapter/2755
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.7
Topics ET: loodusõpetus, põõsad, põõsal, varred, kibuvits, pähklid
Topics RU: природоведение
Topics EN: science
Headings: Põõsad; Põõsal on varred; Kibuvits; Pähklid

## Puhmad
URL: https://www.opiq.ee/kit/56/chapter/2756
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.8
Topics ET: loodusõpetus, puhmad, puhmas, kääbuspõõsas, pohl, kanarbik, milline, tunned, puhmaid
Topics RU: природоведение
Topics EN: science
Headings: Puhmad; Puhmas on kääbuspõõsas; Pohl ja kanarbik; Milline puhmas? 3; Kas tunned puhmaid?; Milline puhmas? 1; Milline puhmas? 2

## Park
URL: https://www.opiq.ee/kit/56/chapter/2757
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 1.9
Topics ET: loodusõpetus, park, hannes, pargis, pargid, inimeste, rajatud, linnapark
Topics RU: природоведение
Topics EN: science
Headings: Park; Hannes pargis; Pargid on inimeste rajatud; Linnapark

## Raamatud ja raamatukogu
URL: https://www.opiq.ee/kit/56/chapter/3345
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.1
Topics ET: loodusõpetus, raamatud, raamatukogu, raamatukogus, hoitakse, raamatuid, loetud, milliseid, olemas, mida
Topics RU: природоведение
Topics EN: science
Headings: Raamatud ja raamatukogu; Raamatukogus hoitakse raamatuid; Loetud raamatud; Milliseid raamatuid on olemas?; Mida saab raamatukogus teha?; Lauaarvuti

## Mineviku jäljed
URL: https://www.opiq.ee/kit/56/chapter/3477
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.10
Topics ET: loodusõpetus, mineviku, jäljed, nabalinna, sõpruskooli, külaskäik, vana, asjad, õpikukaas
Topics RU: природоведение
Topics EN: science
Headings: Mineviku jäljed; Nabalinna sõpruskooli külaskäik; Vana aja asjad; Vana õpikukaas

## Sõbrad
URL: https://www.opiq.ee/kit/56/chapter/3478
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.11
Topics ET: loodusõpetus, sõbrad, hannese
Topics RU: природоведение
Topics EN: science
Headings: Sõbrad; Hannese sõbrad; Minu sõbrad

## Teater ja kino
URL: https://www.opiq.ee/kit/56/chapter/3479
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.12
Topics ET: loodusõpetus, teater, kino, hannes, teatris, töötab, filmivõtted
Topics RU: природоведение
Topics EN: science
Headings: Teater ja kino; Hannes teatris; Kes töötab teatris?; Teatris; Kino; Filmivõtted

## Post
URL: https://www.opiq.ee/kit/56/chapter/3502
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.13
Topics ET: loodusõpetus, post, kirja, saatmine, ümbriku, vormistamine, postmargid
Topics RU: природоведение
Topics EN: science
Headings: Post; Kirja saatmine; Ümbriku vormistamine; Postmargid

## Transport
URL: https://www.opiq.ee/kit/56/chapter/3503
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.14
Topics ET: loodusõpetus, transport, transpordivahendid, bussijaama, sõiduplaan, rongipilet
Topics RU: природоведение
Topics EN: science
Headings: Transport; Transpordivahendid; Bussijaama sõiduplaan; Rongipilet

## Vabrik
URL: https://www.opiq.ee/kit/56/chapter/3504
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.15
Topics ET: loodusõpetus, vabrik, hannese, töökoht, erinevad, vabrikud, toodeti
Topics RU: природоведение
Topics EN: science
Headings: Vabrik; Hannese ema töökoht; Erinevad vabrikud; Kus see toodeti?

## Turg
URL: https://www.opiq.ee/kit/56/chapter/3505
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.16
Topics ET: loodusõpetus, turg, hannes, turul, sõna
Topics RU: природоведение
Topics EN: science
Headings: Turg; Hannes turul; Turul; Sõna turg

## Raha
URL: https://www.opiq.ee/kit/56/chapter/3611
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.17
Topics ET: loodusõpetus, raha, euro, sent, väärtus, mida, eest, osta, hoitakse, pangas, lisa
Topics RU: природоведение, деньги, евро, цент
Topics EN: science, money, euro, cent
Headings: Raha; Raha väärtus; Mida ei saa raha eest osta?; Euro; Raha hoitakse pangas; Lisa. Raha väärtus

## Kust tulevad asjad?
URL: https://www.opiq.ee/kit/56/chapter/3612
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.18
Topics ET: loodusõpetus, kust, tulevad, asjad, mida, saab, teha, jahust, puuvillast, riieteni
Topics RU: природоведение
Topics EN: science
Headings: Kust tulevad asjad?; Mida saab teha jahust?; Puuvillast riieteni

## Keskkond
URL: https://www.opiq.ee/kit/56/chapter/3613
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.19
Topics ET: loodusõpetus, loodus, keskkond, hannes, hoiab, koduümbruse, korras, kõik, meid, ümbritseb, puhas
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Keskkond; Hannes hoiab koduümbruse korras; Keskkond on kõik, mis meid ümbritseb; Puhas Eestimaa; Koristamine ja korras hoidmine

## Õigus
URL: https://www.opiq.ee/kit/56/chapter/3346
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, õigus, seadused, politsei, kohus
Topics RU: природоведение
Topics EN: science
Headings: Õigus; Seadused; Seadused, politsei ja kohus; Politsei

## Materjalid ja taaskasutus
URL: https://www.opiq.ee/kit/56/chapter/3614
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.20
Topics ET: loodusõpetus, materjalid, taaskasutus, sorteeri, prügi, ohtlikud, jäätmed
Topics RU: природоведение
Topics EN: science
Headings: Materjalid ja taaskasutus; Taaskasutus; Materjalid; Sorteeri prügi; Ohtlikud jäätmed

## Aed
URL: https://www.opiq.ee/kit/56/chapter/7625
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.21
Topics ET: loodusõpetus, aiataimed, taimeosad, tunned, marju
Topics RU: природоведение
Topics EN: science
Headings: Aed; Aiataimed; Taimeosad; Kas tunned marju?

## Rohttaimed
URL: https://www.opiq.ee/kit/56/chapter/7626
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.22
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, rohttaimed, rohttaimede, varred, rohtsed, rohttaim, puittaim, üheaastased
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Rohttaimed; Rohttaimede varred on rohtsed; Rohttaim, puittaim või loom?; Üheaastased taimed; Mõisted rohttaim, puittaim ja üheaastane taim

## Mitmeaastased taimed
URL: https://www.opiq.ee/kit/56/chapter/7627
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.23
Topics ET: loodusõpetus, taim, taimed, puu, lill, mitmeaastased, tulp, maikelluke, tulbi, osad, rukkilill
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Mitmeaastased taimed; Tulp ja maikelluke; Tulbi osad; Tulp, maikelluke ja rukkilill

## Aialoomad
URL: https://www.opiq.ee/kit/56/chapter/7628
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.24
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, aialoomad, vihmaussid, nälkjad, teod, konnad, siil, lisa
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Aialoomad; Vihmaussid; Nälkjad, teod ja konnad; Siil; Linnud ja putukad; Lisa. Päevapaabusilm; Päevapaabusilm

## Botaanikaaed
URL: https://www.opiq.ee/kit/56/chapter/7629
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.25
Topics ET: loodusõpetus, botaanikaaed, hannese, kiri, tartu, toataimed, orhidee
Topics RU: природоведение
Topics EN: science
Headings: Botaanikaaed; Hannese kiri; Tartu botaanikaaed; Toataimed; Hannese ema orhidee

## Põld
URL: https://www.opiq.ee/kit/56/chapter/7701
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.26
Topics ET: loodusõpetus, põld, teraviljad, vali, kõik, mida, kasvatatakse, eestis, talivilja, aastaring
Topics RU: природоведение
Topics EN: science
Headings: Põld; Teraviljad; Vali kõik teraviljad, mida kasvatatakse Eestis.; Talivilja aastaring; Teraviljade mõisted; Teravili on tähtis toit; Teraviljatooted

## Koduloomad
URL: https://www.opiq.ee/kit/56/chapter/7702
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.27
Topics ET: loodusõpetus, koduloomad, koduloomade, nimetamine, mida, koduloomadelt, saame, lisa, meierei, piimatööstus
Topics RU: природоведение
Topics EN: science
Headings: Koduloomad; Koduloomade nimetamine; Mida me koduloomadelt saame?; Lisa. Meierei ehk piimatööstus

## Soo
URL: https://www.opiq.ee/kit/56/chapter/7703
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.28
Topics ET: loodusõpetus, vesine, koht, millised, marjad, kasvavad, soos, iseloomustamine
Topics RU: природоведение
Topics EN: science
Headings: Soo; Soo on vesine koht; Millised marjad kasvavad soos?; Soo iseloomustamine

## Soos elavad loomad
URL: https://www.opiq.ee/kit/56/chapter/7704
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.29
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, soos, elavad, sookured, sookurg, valge, toonekurg, konnad, sääsed
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Soos elavad loomad; Sookured; Sookurg ja valge-toonekurg; Konnad ja sääsed; Eesti konnad

## Muuseum
URL: https://www.opiq.ee/kit/56/chapter/3347
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.3
Topics ET: loodusõpetus, muuseum, muuseumis, hoitakse, väärtuslikke, esemeid, muuseumid
Topics RU: природоведение
Topics EN: science
Headings: Muuseum; Muuseumis hoitakse väärtuslikke esemeid; Muuseumid

## Veekogud
URL: https://www.opiq.ee/kit/56/chapter/7705
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.30
Topics ET: loodusõpetus, veekogud, hannes, ujumas, veekogude, nimetused, tähistamine, lisa, eesti, tuntuimad
Topics RU: природоведение
Topics EN: science
Headings: Veekogud; Hannes ujumas; Veekogude nimetused; Veekogude tähistamine; Lisa. Eesti tuntuimad veekogud; Tunne Eesti veekogusid

## Veetaimed
URL: https://www.opiq.ee/kit/56/chapter/7706
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.31
Topics ET: loodusõpetus, veetaimed
Topics RU: природоведение
Topics EN: science
Headings: Veetaimed

## Veeloomad
URL: https://www.opiq.ee/kit/56/chapter/7707
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.32
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, veeloomad, veeloomade, eesti, kalad
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Veeloomad; Veeloomade keha; Eesti kalad

## Linnuse varemed
URL: https://www.opiq.ee/kit/56/chapter/7708
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.33
Topics ET: loodusõpetus, linnuse, varemed, hannes, vanas, linnuses, lisa, eesti, linnused, kaitsmine
Topics RU: природоведение
Topics EN: science
Headings: Linnuse varemed; Hannes vanas linnuses; Lisa. Eesti linnused; Linnuse kaitsmine

## Nabalinna pilt ja kaart
URL: https://www.opiq.ee/kit/56/chapter/7709
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.34
Topics ET: loodusõpetus, nabalinna, pilt, kaart
Topics RU: природоведение
Topics EN: science
Headings: Nabalinna pilt ja kaart

## Eesti kaart
URL: https://www.opiq.ee/kit/56/chapter/7710
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.35
Topics ET: loodusõpetus, eesti, kaart, tunne, eestimaad
Topics RU: природоведение
Topics EN: science
Headings: Eesti kaart; Tunne Eestimaad

## Tervishoiumuuseum
URL: https://www.opiq.ee/kit/56/chapter/3348
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, tervishoiumuuseum, hannese, kiri, tervishoiumuuseumist, mõõteriistad, miks, tuleb, mõõtmisel
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Tervishoiumuuseum; Hannese kiri tervishoiumuuseumist; Mõõteriistad; Pikkus; Miks tuleb mõõtmisel olla hoolikas?; Lisa. Da Vinci joonistatud inimkeha; Inimkeha joonis

## Mõõtmine
URL: https://www.opiq.ee/kit/56/chapter/3349
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, mõõtühikud, ühikutes, mõõdetakse, teepikkust, eestis, kohupiima, ahjupannkook, tööraamatu
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Mõõtmine; Mõõtühikud; Mis ühikutes mõõdetakse teepikkust Eestis?; Kohupiima-ahjupannkook; Tööraamatu pikkus; Mida saab mõõta?

## Inimene
URL: https://www.opiq.ee/kit/56/chapter/3350
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.6
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis, inimese, gorilla, põlvnemine, tasakaal
Topics RU: природоведение, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье
Topics EN: science, comparison, compare, greater, less, human, body, senses, health
Headings: Inimene; Inimene ja ahv; Inimese ja gorilla võrdlemine; Inimese põlvnemine; Tasakaal

## Inimkeha
URL: https://www.opiq.ee/kit/56/chapter/3351
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.7
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, inimkeha, inimese, kehaosad, osad, lisa, millest, koosneb
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimkeha; Inimese kehaosad; Näo osad; Kehaosad; Lisa. Millest keha koosneb?

## Uus elu
URL: https://www.opiq.ee/kit/56/chapter/3352
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.8
Topics ET: loodusõpetus, hannes, käis, sünnitusmajas, lapse, saab, alguse, kõhus, rasedus, algus
Topics RU: природоведение
Topics EN: science
Headings: Uus elu; Hannes käis sünnitusmajas; Lapse elu saab alguse ema kõhus; Rasedus ja elu algus; Lisa. Ultraheli; Ultraheli

## Tähtsad päevad minevikust
URL: https://www.opiq.ee/kit/56/chapter/3353
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 2.9
Topics ET: loodusõpetus, tähtsad, päevad, minevikust, sünnipäevad, pühad, milliseid, tähtpäevi, tähistab, vaid
Topics RU: природоведение
Topics EN: science
Headings: Tähtsad päevad minevikust; Sünnipäevad; Pühad; Milliseid tähtpäevi tähistab vaid Eesti?; Tähtsad päevad; Milliseid tähtpäevi tähistavad ka teised riigid?

## Impressum
URL: https://www.opiq.ee/kit/56/chapter/2772
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 3.1
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Mõisted
URL: https://www.opiq.ee/kit/56/chapter/2773
Book: Loodus- ja inimeseõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodus-_ja_2_et
Chapter ID: 4.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Loodusõpetus 2. klassile (2022) – Opiq
URL: https://www.opiq.ee/Kit/Details/379
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 235
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 2. klassile (2022) – Opiq
URL: https://www.opiq.ee/Kit/Details/379
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 264
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Tere jälle!
URL: https://www.opiq.ee/kit/379/chapter/20574
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 1.1
Topics ET: loodusõpetus, tere, jälle, mari, tormi, kodud
Topics RU: природоведение
Topics EN: science
Headings: Tere jälle!; Mari ja Tormi; Mari ja Tormi kodud
Task examples: Mis linnud on pildil?; Onni seinal on Looduseuurijate Klubi logo. Mis loom sellel on?

## Aardejaht
URL: https://www.opiq.ee/kit/379/chapter/20575
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.1
Topics ET: loodusõpetus, aardejaht, maastikumäng, kaart
Topics RU: природоведение
Topics EN: science
Headings: Aardejaht; Maastikumäng; Mis on kaart?
Task examples: Uuri kaarti ja pilti. Kus asub aare?; Mida punane rist kaardil tähistab?

## Vooremaal
URL: https://www.opiq.ee/kit/379/chapter/20584
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.10
Topics ET: loodusõpetus, vooremaal, mari, jääajad, vooremaa, lisa, kalevipoja, vormitud, maastik
Topics RU: природоведение
Topics EN: science
Headings: Vooremaal; Mari Vooremaal; Jääajad ja Vooremaa; Lisa. Kalevipoja vormitud maastik

## Loomade kehaosad
URL: https://www.opiq.ee/kit/379/chapter/20585
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.11
Topics ET: loodusõpetus, loomade, kehaosad, tormi, papal, külas
Topics RU: природоведение
Topics EN: science
Headings: Loomade kehaosad; Tormi papal külas
Task examples: Vali lünka õige kehaosa nimetus.; Lohista kehaosa nimetus pildile.

## Kes näris õunapuud?
URL: https://www.opiq.ee/kit/379/chapter/20586
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.12
Topics ET: loodusõpetus, näris, õunapuud, juhtus, jänes, põder, metskits, metssiga
Topics RU: природоведение
Topics EN: science
Headings: Kes näris õunapuud?; Mis juhtus?; Jänes; Põder; Metskits; Metssiga
Task examples: Märgi õiged vastused.; Kuidas nende loomade poegi nimetatakse? Lohista sõna õige looma juurde.

## Kes sõi kana ära?
URL: https://www.opiq.ee/kit/379/chapter/20587
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.13
Topics ET: loodusõpetus, kana, juhtus, rebane, karu, hunt, ilves
Topics RU: природоведение
Topics EN: science
Headings: Kes sõi kana ära?; Mis juhtus?; Rebane; Karu; Hunt; Ilves
Task examples: Märgi tõesed väited.

## Koduloomad
URL: https://www.opiq.ee/kit/379/chapter/20590
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.14
Topics ET: loodusõpetus, koduloomad, kust, tuleb, liha, lemmikloomad, metsloomad, mida, koduloomadelt
Topics RU: природоведение
Topics EN: science
Headings: Koduloomad; Kust tuleb liha?; Koduloomad, lemmikloomad ja metsloomad; Mida me koduloomadelt saame?
Task examples: Vali lünka õige sõna.; Mida me neilt saame? Märgi õiged vastused.

## Inimene
URL: https://www.opiq.ee/kit/379/chapter/20588
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.15
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, mari, kohtub, luukerega, inimese, ehitus, lisa, mitu
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimene; Mari kohtub luukerega; Inimese ehitus; Lisa. Mitu luud inimesel on?
Task examples: Uuri pilti Marist, Tormist ja luukerest. Vali joonisel luudele õiged nimetused.; Lohista kehaosa number pildil õigesse kohta.

## Kuidas olla terve?
URL: https://www.opiq.ee/kit/379/chapter/20589
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.16
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, kuidas, olla, terve, olemise, võistlus, eest, hoolitseda
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Kuidas olla terve?; Terve olemise võistlus; Kuidas oma keha eest hoolitseda?; Miks tuleb hambaid pesta?
Task examples: Mõtle välja 3 tervena püsimise reeglit. Kirjuta need siia.; Sordi toiduained vastavalt sellele, kas need on taimsed või loomsed.

## Tallinnas
URL: https://www.opiq.ee/kit/379/chapter/20591
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.17
Topics ET: loodusõpetus, tallinnas, koolivaheaeg, asulad
Topics RU: природоведение
Topics EN: science
Headings: Tallinnas; Koolivaheaeg Tallinnas; Asulad
Task examples: Vali kõik õiged lauselõpud. Tallinn on ...; Uuri Mari teekonda kaardil. Millistest linnadest sõitis Mari rongiga läbi?

## Veekogud
URL: https://www.opiq.ee/kit/379/chapter/20592
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.18
Topics ET: loodusõpetus, veekogud, toimub, meri, jõgi, järv, eesti, kaardil
Topics RU: природоведение
Topics EN: science
Headings: Veekogud; Mis toimub?; Meri; Jõgi; Järv; Eesti veekogud kaardil
Task examples: Uuri Läänemere kaarti. Märgi riigid, mis asuvad Läänemere ääres.; Vali lünka õige sõna.

## Rõuges
URL: https://www.opiq.ee/kit/379/chapter/20593
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.19
Topics ET: loodusõpetus, rõuges, koht, rõuge, mari, matk, eesti, kõige, kõigemad
Topics RU: природоведение
Topics EN: science
Headings: Rõuges; Mis koht on Rõuge?; Mari matk Rõuges; Eesti kõige-kõigemad
Task examples: Mida Mari Rõuges tegi?; Uuri kaarti. Vali õige vastus.

## Eesti kaart
URL: https://www.opiq.ee/kit/379/chapter/20576
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, eesti, kaart, mari, kaardid, looduskaart, madalikud, kõrgustikud
Topics RU: природоведение
Topics EN: science
Headings: Eesti kaart; Mari ja kaardid; Looduskaart; Madalikud ja kõrgustikud
Task examples: Kas sa tead, kuidas nimetatakse raamatut, kus on palju kaarte?; Otsi üles, kus on Eesti kaardil märgitud ilmakaared. Seejärel lohista ka siin joonisel ilmakaarte nimetused õigetesse kohtadesse.

## Veeloomad ja -taimed
URL: https://www.opiq.ee/kit/379/chapter/20594
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.20
Topics ET: loodusõpetus, taim, taimed, puu, lill, veeloomad, kalapüük, veetaimed
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Veeloomad ja -taimed; Kalapüük; Veeloomad; Veetaimed
Task examples: Mis kaitseb kala keha?; Mis kala Tormi kätte sai?

## Põld
URL: https://www.opiq.ee/kit/379/chapter/20595
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.21
Topics ET: loodusõpetus, põld, traktoriga, põllul, kasvab
Topics RU: природоведение
Topics EN: science
Headings: Põld; Traktoriga põllul; Mis põllul kasvab?
Task examples: Loe Mari jutustust ja vaata pilti. Vasta küsimustele.; Märgi, mis taimi kasvatatakse põllul.

## Putukasõbralik aed
URL: https://www.opiq.ee/kit/379/chapter/20596
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.22
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, putukasõbralik, putukatele, kõik, olendid, vajalikud, miks, tähtsad
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Putukasõbralik aed; Aed putukatele; Kõik olendid on vajalikud; Miks on putukad tähtsad?; Mis on tolmeldamine?
Task examples: Vali lünka õige sõna.

## Aias maa all
URL: https://www.opiq.ee/kit/379/chapter/20597
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.23
Topics ET: loodusõpetus, aias, muld, elusolendeid, täis, looduseuurijate, klubi, putukajahil
Topics RU: природоведение
Topics EN: science
Headings: Aias maa all; Muld on elusolendeid täis; Looduseuurijate Klubi putukajahil
Task examples: Mitu jalga on putukatel?

## Kuidas loodust uuritakse?
URL: https://www.opiq.ee/kit/379/chapter/20598
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.24
Topics ET: loodusõpetus, kuidas, loodust, uuritakse, uurimise, viisid, mari, vihmaussid, teha
Topics RU: природоведение
Topics EN: science
Headings: Kuidas loodust uuritakse?; Uurimise viisid; Mari ja vihmaussid; Kuidas teha katset?
Task examples: Milliseid meeli kasutad, kui lähed kevadhommikul parki linnuvaatlusele?; Kuidas saab Mari teada, kus vihmaussidele elada meeldib?

## Hiiumaal
URL: https://www.opiq.ee/kit/379/chapter/20599
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.25
Topics ET: loodusõpetus, hiiumaal, mereriik, eesti, mari, reis, hiiumaale
Topics RU: природоведение
Topics EN: science
Headings: Hiiumaal; Mereriik Eesti; Mari reis Hiiumaale
Task examples: Leia kaardilt Pärnu laht. Mis saar asub selle juures?; Otsi kaardilt Hiiumaa. Millises Eesti osas see asub?

## Matkatarkused
URL: https://www.opiq.ee/kit/379/chapter/20600
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.26
Topics ET: loodusõpetus, matkatarkused, mari, klassiga, matkamas, kuidas, metsas, käituda, jäta
Topics RU: природоведение
Topics EN: science
Headings: Matkatarkused; Mari klassiga matkamas; Kuidas metsas käituda?; Jäta meelde!
Task examples: Uuri pilti. Millised väited on õiged?

## Soomaal
URL: https://www.opiq.ee/kit/379/chapter/20577
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.3
Topics ET: loodusõpetus, soomaal, mari, välitöödel
Topics RU: природоведение
Topics EN: science
Headings: Soomaal; Mis on soo?; Mari välitöödel
Task examples: Mis värviga on kaardil tähistatud Soomaa rahvuspark?

## Sootaimed
URL: https://www.opiq.ee/kit/379/chapter/20578
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, sootaimed, soos, kasvavad, mari, lihasööjataim, kuidas, liikuda
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Sootaimed; Mis taimed soos kasvavad?; Mari ja lihasööjataim; Kuidas soos liikuda?; Jäta meelde!
Task examples: Miks ei kasva soos suuri puid?; Mis taimi Mari soos nägi?

## Puud
URL: https://www.opiq.ee/kit/379/chapter/20579
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, puud, mari, istutab, puid, lehtpuud, okaspuud, mürgine
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Puud; Mari istutab puid; Lehtpuud; Okaspuud; Mürgine puu
Task examples: Uuri pilti. Mis õunapuu osast hoiab Mari kinni?; Lohista puu osa nimetus pildil õigesse kohta.

## Põõsad
URL: https://www.opiq.ee/kit/379/chapter/20580
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.6
Topics ET: loodusõpetus, põõsad, mari, linnupesa, mürgised
Topics RU: природоведение
Topics EN: science
Headings: Põõsad; Mari ja linnupesa; Mürgised põõsad
Task examples: Miks on põõsad lindudele olulised? Vali õiged vastused.; Kas lause käib puu või põõsa kohta? Vali õige vastus.

## Puhmad ja rohttaimed
URL: https://www.opiq.ee/kit/379/chapter/20581
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.7
Topics ET: loodusõpetus, puhmad, rohttaimed, mari, matkal, puittaimed, mürgised
Topics RU: природоведение
Topics EN: science
Headings: Puhmad ja rohttaimed; Mari matkal; Puhmad; Puittaimed ja rohttaimed; Mürgised rohttaimed
Task examples: Märgi, milliste Mari nähtud taimede marjad on mürgised.; Kas vastus käib pohla, jõhvika või mõlema kohta? Lohista vastus õige pealkirja alla.

## Ilm
URL: https://www.opiq.ee/kit/379/chapter/20582
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.8
Topics ET: loodusõpetus, mari, ilmajaamas, lisa, satelliidid
Topics RU: природоведение
Topics EN: science
Headings: Ilm; Mari ilmajaamas; LISA. Satelliidid
Task examples: Mida pildil olevate mõõteriistaga mõõdetakse? Ühenda paarid.; Uuri ilmakaarti ja vali õige vastus.

## Veeringlus
URL: https://www.opiq.ee/kit/379/chapter/20583
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 2.9
Topics ET: loodusõpetus, veeringlus, mari, allikas, olekud
Topics RU: природоведение
Topics EN: science
Headings: Veeringlus; Mari ja allikas; Vee olekud
Task examples: Uuri joonist. Vali lünka õige sõna.; Kuidas vett mingis olekus nimetatakse? Ühenda paarid.

## Impressum
URL: https://www.opiq.ee/kit/379/chapter/20601
Book: Loodusõpetus 2. klassile (2022) 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: avita_loodusõpet_2_et
Chapter ID: 3.1
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Природа и человек для 2 класса – Opiq
URL: https://www.opiq.ee/Kit/Details/86
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 63
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, inimene, keha, meeled, tervis, opiq
Topics RU: математика, природа, природоведение, окружающая среда, человек, тело, чувства, здоровье, класса
Topics EN: mathematics, nature, science, environment, human, body, senses, health

## Природа и человек для 2 класса – Opiq
URL: https://www.opiq.ee/Kit/Details/86
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 125
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, inimene, keha, meeled, tervis, opiq
Topics RU: математика, природа, природоведение, окружающая среда, человек, тело, чувства, здоровье, класса
Topics EN: mathematics, nature, science, environment, human, body, senses, health

## Дом и соседи
URL: https://www.opiq.ee/kit/86/chapter/4190
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, соседи, письмо, эрика, разные, дома, центр, города
Topics EN: mathematics
Headings: Дом и соседи; Письмо Эрика; Разные дома; Обо мне; Центр города

## Круговорот воды в природе
URL: https://www.opiq.ee/kit/86/chapter/4199
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.10
Topics ET: matemaatika
Topics RU: математика, круговорот, воды, природе, лужи, облака, дождь, дополнительный, материал, родник
Topics EN: mathematics
Headings: Круговорот воды в природе; Круговорот воды; Лужи; Облака и дождь; Дополнительный материал. Родник Эмаляте (Emaläte); Карта водоёмов

## Прогноз погоды
URL: https://www.opiq.ee/kit/86/chapter/4200
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.11
Topics ET: matemaatika
Topics RU: математика, прогноз, погоды, погода, ветер, измеряется, следующее, явления, природы, приборы
Topics EN: mathematics
Headings: Прогноз погоды; Погода; Ветер; Чем измеряется следующее?; Явления природы; Погода. Приборы измерения

## Погода
URL: https://www.opiq.ee/kit/86/chapter/4201
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.12
Topics ET: matemaatika
Topics RU: математика, погода, характеристика, погоды, одежда, погоде, график, условные, обозначения, явлений
Topics EN: mathematics
Headings: Погода; Характеристика погоды; Одежда по погоде; График погоды; Условные обозначения явлений

## Здоровье
URL: https://www.opiq.ee/kit/86/chapter/4202
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.13
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, эрик, заболел, заболевания, аллергия, предотвращение, заболеваний
Topics EN: mathematics, human, body, senses, health
Headings: Здоровье; Эрик заболел; Заболевания и аллергия; Предотвращение заболеваний

## Первая помощь
URL: https://www.opiq.ee/kit/86/chapter/4203
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.14
Topics ET: matemaatika
Topics RU: математика, первая, помощь, срочная, медицинская, поведение, несчастном, случае
Topics EN: mathematics
Headings: Первая помощь; Первая помощь – это срочная медицинская помощь; Поведение при несчастном случае

## Животные
URL: https://www.opiq.ee/kit/86/chapter/4204
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.15
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, царство, животных, млекопитающие, части, тела, рака
Topics EN: mathematics, animal, animals, birds, insects
Headings: Животные; Царство животных; Млекопитающие; Части тела у животных; Части тела рака

## Описание животного
URL: https://www.opiq.ee/kit/86/chapter/4205
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.16
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, описание, животного, описывать, опиши, лягушку, лошадь, лебедя, салаку
Topics EN: mathematics, animal, animals, birds, insects
Headings: Описание животного; Как описывать животное; Опиши лягушку, лошадь, лебедя и салаку

## Места обитания
URL: https://www.opiq.ee/kit/86/chapter/4206
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.17
Topics ET: matemaatika
Topics RU: математика, места, обитания, животных, домики, растений
Topics EN: mathematics
Headings: Места обитания; Места обитания животных; Домики для животных; Места обитания растений

## Лесные животные
URL: https://www.opiq.ee/kit/86/chapter/4207
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.18
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, лесные, эрик, лесу, следы, животных, рыжие, муравьи, большой
Topics EN: mathematics, animal, animals, birds, insects
Headings: Лесные животные; Эрик в лесу; Следы животных; Рыжие лесные муравьи и большой пёстрый дятел; Как вести себя в лесу

## Лось и косуля
URL: https://www.opiq.ee/kit/86/chapter/4208
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.19
Topics ET: matemaatika
Topics RU: математика, лось, косуля, части, тела, лося, питается, косули
Topics EN: mathematics
Headings: Лось и косуля; Лось; Части тела лося; Чем питается лось?; Косуля; Части тела косули

## В деревне или в городе?
URL: https://www.opiq.ee/kit/86/chapter/4191
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, деревне, городе, каким, может, быть, жизнь, дополнительный, материал, необычные
Topics EN: mathematics
Headings: В деревне или в городе?; Дом; Каким может быть дом?; Жизнь в городе и деревне; Дополнительный материал. Необычные дома

## Бурый медведь и кабан
URL: https://www.opiq.ee/kit/86/chapter/4209
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.20
Topics ET: matemaatika
Topics RU: математика, бурый, медведь, кабан, части, тела, медведя, питатеся, кабана, питается
Topics EN: mathematics
Headings: Бурый медведь и кабан; Бурый медведь; Части тела медведя; Чем питатеся медведь?; Кабан; Части тела кабана; Чем питается кабан?

## Волк и лисица
URL: https://www.opiq.ee/kit/86/chapter/4210
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.21
Topics ET: matemaatika
Topics RU: математика, волк, лисица, части, тела, волка, кого, лисицы
Topics EN: mathematics
Headings: Волк и лисица; Волк; Части тела волка; Кого ест волк?; Лисица; Части тела лисицы

## Зоопарк и домашние любимцы
URL: https://www.opiq.ee/kit/86/chapter/4211
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.22
Topics ET: matemaatika
Topics RU: математика, зоопарк, домашние, любимцы, письмо, эрика, профессии, собак
Topics EN: mathematics
Headings: Зоопарк и домашние любимцы; Письмо Эрика; Домашние любимцы; Зоопарк; Профессии собак

## Рождество
URL: https://www.opiq.ee/kit/86/chapter/4212
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.23
Topics ET: matemaatika
Topics RU: математика, рождество, отмечают, дополнительный, материал, санта, клаус, рождественский, стих, напиши
Topics EN: mathematics
Headings: Рождество; Как отмечают рождество; Дополнительный материал. Санта-Клаус; Рождественский стих; Напиши своё рождественское стихотворение.

## Близкие люди
URL: https://www.opiq.ee/kit/86/chapter/4192
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, близкие, люди, эрика, семья, родственники, друзья, определения
Topics EN: mathematics
Headings: Близкие люди; Близкие Эрика; Моя семья; Родственники Эрика; Друзья и родственники; Определения

## Лес
URL: https://www.opiq.ee/kit/86/chapter/4193
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, эрик, разные, леса, деревья, лиственные, эстонии, хвойные, части, деревьев
Topics EN: mathematics
Headings: Лес; Эрик идёт в лес; Разные леса; Деревья; Лиственные деревья Эстонии; Хвойные деревья Эстонии; Части деревьев; Лиственные и хвойные деревья

## Лиственные деревья
URL: https://www.opiq.ee/kit/86/chapter/4194
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.5
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, лиственные, деревья, свойства, лиственных, деревьев, времена, года, лесу
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Лиственные деревья; Свойства лиственных деревьев; Берёза и дуб; Времена года в лесу

## Хвойные деревья
URL: https://www.opiq.ee/kit/86/chapter/4195
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.6
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, хвойные, деревья, покрыты, хвоей, шишки, ягодообразные, понятие, хвойное
Topics EN: mathematics, plant, plants, tree, flower
Headings: Хвойные деревья; Хвойные деревья покрыты хвоей; Шишки и ягодообразные шишки; Понятие "хвойное дерево"; Дополнительный материал. Годичные кольца; Разрез ствола; Лиственные и хвойные деревья; Опознай деревья Эстонии

## Кустарники
URL: https://www.opiq.ee/kit/86/chapter/4196
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.7
Topics ET: matemaatika
Topics RU: математика, кустарники, кустарника, есть, ветви, шиповник, орехи
Topics EN: mathematics
Headings: Кустарники; У кустарника есть ветви; Шиповник; Орехи

## Кустарнички
URL: https://www.opiq.ee/kit/86/chapter/4197
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.8
Topics ET: matemaatika
Topics RU: математика, кустарнички, кустарничек, карликовый, кустарник, брусника, вереск, клюква, черника
Topics EN: mathematics
Headings: Кустарнички; Кустарничек – это карликовый кустарник; Брусника и вереск; Клюква, черника и брусника

## Парк
URL: https://www.opiq.ee/kit/86/chapter/4198
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 1.9
Topics ET: matemaatika
Topics RU: математика, парк, эрик, парке, парки, созданы, людьми
Topics EN: mathematics
Headings: Парк; Эрик в парке; Парки созданы людьми

## Книги и библиотека
URL: https://www.opiq.ee/kit/86/chapter/4213
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, книги, библиотека, библиотеке, хранятся, прочитанные, какие, бывают, можно, заниматься
Topics EN: mathematics
Headings: Книги и библиотека; В библиотеке хранятся книги; Прочитанные книги; Какие бывают книги?; Чем можно заниматься в библиотеке?; Компьютер

## Наследие прошлого
URL: https://www.opiq.ee/kit/86/chapter/4222
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.10
Topics ET: matemaatika
Topics RU: математика, наследие, прошлого, визит, учеников, другой, школы, старинные, постройки, обложка
Topics EN: mathematics
Headings: Наследие прошлого; Визит учеников из другой школы; Старинные постройки; Обложка старого учебника

## Друзья
URL: https://www.opiq.ee/kit/86/chapter/4223
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.11
Topics ET: matemaatika
Topics RU: математика, друзья, эрика
Topics EN: mathematics
Headings: Друзья; Друзья Эрика; Мои друзья

## Театр и кино
URL: https://www.opiq.ee/kit/86/chapter/4224
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.12
Topics ET: matemaatika
Topics RU: математика, театр, кино, эрик, театре, работает, кинотеатр, фильма
Topics EN: mathematics
Headings: Театр и кино; Эрик в театре; Кто работает в театре?; В театре; Кинотеатр; Съёмки фильма

## Почта
URL: https://www.opiq.ee/kit/86/chapter/4225
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.13
Topics ET: matemaatika
Topics RU: математика, почта, получение, письма, подготовка, конверта, почтовые, марки
Topics EN: mathematics
Headings: Почта; Получение письма; Подготовка конверта; Почтовые марки

## Транспорт
URL: https://www.opiq.ee/kit/86/chapter/4226
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.14
Topics ET: matemaatika
Topics RU: математика, транспорт, транспортные, средства, расписание, автовокзала, билет, поезд
Topics EN: mathematics
Headings: Транспорт; Транспортные средства; Расписание автовокзала; Билет на поезд

## Фабрика
URL: https://www.opiq.ee/kit/86/chapter/4227
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.15
Topics ET: matemaatika
Topics RU: математика, фабрика, место, работы, мамы, эрика, было, произведено, разные, фабрики
Topics EN: mathematics
Headings: Фабрика; Место работы мамы Эрика; Где это было произведено?; Разные фабрики

## Рынок
URL: https://www.opiq.ee/kit/86/chapter/4228
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.16
Topics ET: matemaatika
Topics RU: математика, рынок, эрик, рынке, слово
Topics EN: mathematics
Headings: Рынок; Эрик на рынке; Слово рынок

## Деньги
URL: https://www.opiq.ee/kit/86/chapter/4229
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.17
Topics ET: matemaatika, raha, euro, sent
Topics RU: математика, деньги, евро, цент, ценность, денег, нельзя, купить, хранятся, банке, дополнительный
Topics EN: mathematics, money, euro, cent
Headings: Деньги; Ценность денег; Что нельзя купить за деньги?; Евро; Деньги хранятся в банке; Дополнительный материал. Стоимость денег

## Из чего что сделано?
URL: https://www.opiq.ee/kit/86/chapter/4230
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.18
Topics ET: matemaatika
Topics RU: математика, чего, сделано, можно, изготовить, муки, хлопка, одежды
Topics EN: mathematics
Headings: Из чего что сделано?; Что можно изготовить из муки?; От хлопка до одежды

## Окружающая среда
URL: https://www.opiq.ee/kit/86/chapter/4231
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.19
Topics ET: matemaatika, loodus, loodusõpetus, keskkond
Topics RU: математика, природа, природоведение, окружающая среда, окружающая, среда, эрик, прибирается, вокруг, дома, окружает, чистая, эстония
Topics EN: mathematics, nature, science, environment
Headings: Окружающая среда; Эрик прибирается вокруг дома; Окружающая среда – это всё, что нас окружает; Чистая Эстония; Уборка и поддержание чистоты

## Право
URL: https://www.opiq.ee/kit/86/chapter/4214
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, право, законы, полиция
Topics EN: mathematics
Headings: Право; Законы; Законы, полиция и суд; Полиция

## Повторное использование предметов
URL: https://www.opiq.ee/kit/86/chapter/4232
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.20
Topics ET: matemaatika
Topics RU: математика, повторное, использование, предметов, материалы, отсортируй, мусор, опасные, отходы
Topics EN: mathematics
Headings: Повторное использование предметов; Повторное использование; Материалы; Отсортируй мусор; Опасные отходы

## Сад
URL: https://www.opiq.ee/kit/86/chapter/12105
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.21
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, части, узнаешь, ягоды
Topics EN: mathematics, plant, plants, tree, flower
Headings: Сад; Части растения; Узнаешь ягоды?

## Травянистые растения
URL: https://www.opiq.ee/kit/86/chapter/12106
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.22
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, травянистые, стебли, травянистых, растений, травянистое, древесное
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Травянистые растения; Стебли травянистых растений – травянистые; Травянистое растение, древесное растение или животное?; Однолетние растения; Понятия травянистое растение, древесное растение и однолетнее растение

## Многолетние растения
URL: https://www.opiq.ee/kit/86/chapter/12107
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.23
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, многолетние, тюльпан, ландыш, части, тюльпана, васил
Topics EN: mathematics, plant, plants, tree, flower
Headings: Многолетние растения; Тюльпан и ландыш; Части тюльпана; Тюльпан, ландыш и василёк

## Животные сада
URL: https://www.opiq.ee/kit/86/chapter/12108
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.24
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, сада, дождевые, черви, слизни, улитки, лягушки
Topics EN: mathematics, animal, animals, birds, insects
Headings: Животные сада; Дождевые черви; Слизни улитки и лягушки; Ёж; Птицы и насекомые; Дополнительный материал. Дневная бабочка – павлиний глаз; Дневная бабочка – павлиний глаз

## Ботанический сад
URL: https://www.opiq.ee/kit/86/chapter/12109
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.25
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, ботанический, письмо, эрика, тартуский, комнатные, орхидея, мамы
Topics EN: mathematics, plant, plants, tree, flower
Headings: Ботанический сад; Письмо Эрика; Тартуский ботанический сад; Комнатные растения; Орхидея мамы Эрика

## Поле и зерновые культуры
URL: https://www.opiq.ee/kit/86/chapter/12110
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.26
Topics ET: matemaatika
Topics RU: математика, поле, зерновые, культуры, выбери, которые, выращивают, эстонии, выращивание, озимых
Topics EN: mathematics
Headings: Поле и зерновые культуры; Зерновые; Выбери все зерновые, которые выращивают в Эстонии.; Выращивание озимых зерновых; Понятия зерновых; Зерновые являются ценной пищей; Продукты из зерновых

## Домашние животные
URL: https://www.opiq.ee/kit/86/chapter/12111
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.27
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, домашние, название, животных, каких, можно, получить, дополнительный, материал
Topics EN: mathematics, animal, animals, birds, insects
Headings: Домашние животные; Название животных; Что и от каких животных можно получить?; Дополнительный материал. Молочная промышленность

## Болото
URL: https://www.opiq.ee/kit/86/chapter/12112
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.28
Topics ET: matemaatika
Topics RU: математика, болото, очень, водянистое, место, какие, ягоды, растут, болоте, характеристика
Topics EN: mathematics
Headings: Болото; Болото – очень водянистое место; Какие ягоды растут на болоте?; Характеристика болота

## Животные, обитающие на болоте
URL: https://www.opiq.ee/kit/86/chapter/12113
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.29
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, обитающие, болоте, серые, журавли, серый, журавль, белый, аист
Topics EN: mathematics, animal, animals, birds, insects
Headings: Животные, обитающие на болоте; Серые журавли; Серый журавль и белый аист; Лягушки и комары; Лягушки Эстонии

## Музей
URL: https://www.opiq.ee/kit/86/chapter/4215
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, музей, музее, хранятся, ценные, экспонаты, музеи
Topics EN: mathematics
Headings: Музей; В музее хранятся ценные экспонаты; Музеи

## Водоёмы
URL: https://www.opiq.ee/kit/86/chapter/12114
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.30
Topics ET: matemaatika
Topics RU: математика, водо, эрик, пляже, названия, обозначение, дополнительный, материал, крупные, эстонии
Topics EN: mathematics
Headings: Водоёмы; Эрик на пляже; Названия водоёмов; Обозначение водоёмов; Дополнительный материал. Крупные водоёмы Эстонии; Узнай водоёмы Эстонии

## Водные растения
URL: https://www.opiq.ee/kit/86/chapter/12115
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.31
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, водные
Topics EN: mathematics, plant, plants, tree, flower
Headings: Водные растения

## Водные животные
URL: https://www.opiq.ee/kit/86/chapter/12116
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.32
Topics ET: matemaatika, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis
Topics RU: математика, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье, водные, водных, животных, рыбы, эстонии
Topics EN: mathematics, animal, animals, birds, insects, human, body, senses, health
Headings: Водные животные; Тело водных животных; Рыбы Эстонии

## Старинные развалины городов
URL: https://www.opiq.ee/kit/86/chapter/12117
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.33
Topics ET: matemaatika
Topics RU: математика, старинные, развалины, городов, эрик, старом, городе, дополнительный, материал, крепости
Topics EN: mathematics
Headings: Старинные развалины городов; Эрик в старом городе; Дополнительный материал. Крепости Эстонии; Защита крепости

## Картинка и карта родного города Эрика
URL: https://www.opiq.ee/kit/86/chapter/12118
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.34
Topics ET: matemaatika
Topics RU: математика, картинка, карта, родного, города, эрика
Topics EN: mathematics
Headings: Картинка и карта родного города Эрика; Картинка; Карта

## Карта Эстонии
URL: https://www.opiq.ee/kit/86/chapter/12119
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.35
Topics ET: matemaatika
Topics RU: математика, карта, эстонии, работа, карте, знай, эстонию
Topics EN: mathematics
Headings: Карта Эстонии; Работа по карте; Знай Эстонию

## Музей здоровья
URL: https://www.opiq.ee/kit/86/chapter/4216
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.4
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, inimene, keha, meeled, tervis
Topics RU: математика, измерение, единица измерения, длина, масса, объём, человек, тело, чувства, здоровье, музей, здоровья, эрик, рассказал, музее, измерительные, приборы, почему
Topics EN: mathematics, measurement, unit, length, mass, volume, human, body, senses, health
Headings: Музей здоровья; Что Эрик рассказал о музее здоровья; Измерительные приборы; Длина; Почему следует быть точным в замерах?; Дополнительный материал. Человеческое тело, нарисованное Леонардо Да Винчи; Человеческое тело на картинке

## Измерение
URL: https://www.opiq.ee/kit/86/chapter/4217
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.5
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, единицы, измерения, учебника, творожно, яблочный, пирог, можно
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Измерение; Единицы измерения; Длина учебника; Творожно-яблочный пирог; Что можно измерить?; В каких единицах измеряются длины дорог в Эстонии?

## Человек
URL: https://www.opiq.ee/kit/86/chapter/4218
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.6
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis
Topics RU: математика, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье, обезьяна, человека, гориллы, родословная, равновесие
Topics EN: mathematics, comparison, compare, greater, less, human, body, senses, health
Headings: Человек; Человек и обезьяна; Сравнение человека и гориллы; Родословная человека; Равновесие

## Тело человека
URL: https://www.opiq.ee/kit/86/chapter/4219
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.7
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, человека, части, тела, лица, дополнительный, материал, чего, состоит
Topics EN: mathematics, human, body, senses, health
Headings: Тело человека; Части тела человека; Части лица; Части тела; Дополнительный материал. Из чего состоит тело?

## Новая жизнь
URL: https://www.opiq.ee/kit/86/chapter/4220
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, новая, жизнь, эрик, роддоме, начинается, мамы, животе, беременность, начало
Topics EN: mathematics
Headings: Новая жизнь; Эрик был в роддоме; Жизнь ребёнка начинается у мамы в животе; Беременность и начало жизни; Дополнительный материал. Ультразвук; Ультразвук

## Знаменательные даты
URL: https://www.opiq.ee/kit/86/chapter/4221
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика, знаменательные, даты, рождения, праздники, какие, отмечают, только, эстонии, памятные
Topics EN: mathematics
Headings: Знаменательные даты; Дни рождения; Праздники; Какие праздники отмечают только в Эстонии?; Памятные даты; Какие праздники отмечают в других государствах?

## Импрессум
URL: https://www.opiq.ee/kit/86/chapter/12120
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, импрессум
Topics EN: mathematics
Headings: Импрессум

## Понятия
URL: https://www.opiq.ee/kit/86/chapter/12121
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, понятия
Topics EN: mathematics
Headings: Понятия

## Толкование слов
URL: https://www.opiq.ee/kit/86/chapter/4233
Book: Природа и человек для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природа_и__2_ru
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, толкование, слов
Topics EN: mathematics
Headings: Толкование слов

## Loodusõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/570
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 304
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/570
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 329
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Tere jälle!
URL: https://www.opiq.ee/kit/570/chapter/31841
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 1.1
Topics ET: matemaatika, tere, jälle, mari, tormi, kodud
Topics RU: математика, здравствуй, снова
Topics EN: mathematics
Headings: Tere jälle!; Здравствуй снова!; Mari ja Tormi; Mari ja Tormi kodud
Task examples: Mis linnud on pildil?; Onni seinal on Looduseuurijate Klubi logo. Mis loom sellel on?

## Aardejaht
URL: https://www.opiq.ee/kit/570/chapter/31842
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.1
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, aardejaht, maastikumäng, kaart, eesti, keeles
Topics RU: математика, природа, природоведение, окружающая среда, охота, сокровищами
Topics EN: mathematics, nature, science, environment
Headings: Aardejaht; Охота за сокровищами; Maastikumäng; Mis on kaart?; Loodusõpetus eesti keeles
Task examples: Uuri kaarti ja pilti. Kus asub aare?; Mida punane rist kaardil tähistab?

## Vooremaal
URL: https://www.opiq.ee/kit/570/chapter/32086
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.10
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, vooremaal, mari, jääajad, vooremaa
Topics RU: математика, природа, природоведение, окружающая среда, вооремаа, дополнительно, ландшафт, созданный
Topics EN: mathematics, nature, science, environment
Headings: Vooremaal; В Вооремаа; Mari Vooremaal; Jääajad ja Vooremaa; Дополнительно. Ландшафт, созданный Калевипоэгом; Lisa. Kalevipoja vormitud maastik; Loodusõpetus eesti keeles

## Loomade kehaosad
URL: https://www.opiq.ee/kit/570/chapter/32087
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.11
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, loomade, kehaosad, tormi, papal, külas
Topics RU: математика, природа, природоведение, окружающая среда, части, тела, животных
Topics EN: mathematics, nature, science, environment
Headings: Loomade kehaosad; Части тела животных; Tormi papal külas; Loodusõpetus eesti keeles
Task examples: Vali lünka õige kehaosa nimetus.; Lohista kehaosa number pildile.

## Kes näris õunapuud?
URL: https://www.opiq.ee/kit/570/chapter/32088
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.12
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, näris, õunapuud, juhtus, jänes, põder, metskits
Topics RU: математика, природа, природоведение, окружающая среда, погрыз, яблоню
Topics EN: mathematics, nature, science, environment
Headings: Kes näris õunapuud?; Кто погрыз яблоню?; Mis juhtus?; Jänes; Põder; Metskits; Metssiga; Loodusõpetus eesti keeles
Task examples: Märgi õiged vastused.; Kuidas nende loomade poegi nimetatakse? Lohista sõna õige looma juurde.

## Kes sõi kana ära?
URL: https://www.opiq.ee/kit/570/chapter/32089
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.13
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, kana, juhtus, rebane, karu, hunt, ilves
Topics RU: математика, природа, природоведение, окружающая среда, съел, курицу
Topics EN: mathematics, nature, science, environment
Headings: Kes sõi kana ära?; Кто съел курицу?; Mis juhtus?; Rebane; Karu; Hunt; Ilves; Loodusõpetus eesti keeles
Task examples: Märgi tõesed väited.

## Koduloomad
URL: https://www.opiq.ee/kit/570/chapter/33143
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.14
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, loom, loomad, linnud, putukad, koduloomad, kust, tuleb, liha, lemmikloomad, metsloomad
Topics RU: математика, природа, природоведение, окружающая среда, животное, животные, птицы, насекомые, домашние
Topics EN: mathematics, nature, science, environment, animal, animals, birds, insects
Headings: Koduloomad; Домашние животные; Kust tuleb liha?; Koduloomad, lemmikloomad ja metsloomad; Mida me koduloomadelt saame?; Loodusõpetus eesti keeles
Task examples: Vali lünka õige sõna.; Mida me neilt saame? Märgi õiged vastused.

## Inimene
URL: https://www.opiq.ee/kit/570/chapter/33144
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.15
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, inimene, keha, meeled, tervis, mari, kohtub, luukerega, inimese, ehitus
Topics RU: математика, природа, природоведение, окружающая среда, человек, тело, чувства, здоровье, дополнительно
Topics EN: mathematics, nature, science, environment, human, body, senses, health
Headings: Inimene; Человек; Mari kohtub luukerega; Inimese ehitus; Дополнительно. Сколько костей у человека?; Lisa. Mitu luud inimesel on?; Loodusõpetus eesti keeles
Task examples: Uuri pilti Marist, Tormist ja luukerest.Vali joonisel luudele õiged nimetused.; Lohista kehaosa number pildil õigesse kohta.

## Kuidas olla terve?
URL: https://www.opiq.ee/kit/570/chapter/33145
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.16
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, inimene, keha, meeled, tervis, kuidas, olla, terve, olemise, võistlus
Topics RU: математика, природа, природоведение, окружающая среда, человек, тело, чувства, здоровье, быть, здоровым
Topics EN: mathematics, nature, science, environment, human, body, senses, health
Headings: Kuidas olla terve?; Как быть здоровым?; Terve olemise võistlus; Kuidas oma keha eest hoolitseda?; Почему нужно чистить зубы?; Miks tuleb hambaid pesta?; Loodusõpetus eesti keeles
Task examples: Mõtle välja 3 tervena püsimise reeglit. Kirjuta need siia.; Rühmita toiduained vastavalt sellele, kas need on taimsed või loomsed.

## Tallinnas
URL: https://www.opiq.ee/kit/570/chapter/33146
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.17
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, tallinnas, koolivaheaeg, asulad, eesti, keeles
Topics RU: математика, природа, природоведение, окружающая среда, таллинне
Topics EN: mathematics, nature, science, environment
Headings: Tallinnas; В Таллинне; Koolivaheaeg Tallinnas; Asulad; Loodusõpetus eesti keeles
Task examples: Vali kõik õiged lauselõpud. Tallinn on ...; Uuri Mari teekonda kaardil. Millistest linnadest sõitis Mari rongiga läbi?

## Veekogud
URL: https://www.opiq.ee/kit/570/chapter/33147
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.18
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, veekogud, toimub, meri, jõgi, järv, eesti, kaardil
Topics RU: математика, природа, природоведение, окружающая среда, водо
Topics EN: mathematics, nature, science, environment
Headings: Veekogud; Водоёмы; Mis toimub?; Meri; Jõgi; Järv; Eesti veekogud kaardil; Loodusõpetus eesti keeles
Task examples: Uuri Läänemere kaarti. Märgi riigid, mis asuvad Läänemere ääres.; Vali lünka õige sõna.

## Rõuges
URL: https://www.opiq.ee/kit/570/chapter/33148
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.19
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, rõuges, koht, rõuge, mari, matk, eesti, kõige
Topics RU: математика, природа, природоведение, окружающая среда, рыуге
Topics EN: mathematics, nature, science, environment
Headings: Rõuges; В Рыуге; Mis koht on Rõuge?; Mari matk Rõuges; Eesti kõige-kõigemad; Loodusõpetus eesti keeles
Task examples: Mida Mari Rõuges tegi?; Uuri kaarti. Vali õige vastus.

## Eesti kaart
URL: https://www.opiq.ee/kit/570/chapter/31843
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.2
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, eesti, kaart, mari, kaardid, looduskaart, madalikud
Topics RU: математика, природа, природоведение, окружающая среда, карта, эстонии
Topics EN: mathematics, nature, science, environment
Headings: Eesti kaart; Карта Эстонии; Mari ja kaardid; Looduskaart; Madalikud ja kõrgustikud; Loodusõpetus eesti keeles
Task examples: Kas sa tead, kuidas nimetatakse raamatut, kus on palju kaarte?; Otsi üles, kus on Eesti kaardil märgitud ilmakaared. Lohista ka siin joonisel ilma­kaarte nimetused õigetesse kohtadesse.

## Veeloomad ja -taimed
URL: https://www.opiq.ee/kit/570/chapter/33149
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.20
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, taim, taimed, puu, lill, loom, loomad, linnud, putukad, veeloomad, kalapüük, veetaimed
Topics RU: математика, природа, природоведение, окружающая среда, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, водные
Topics EN: mathematics, nature, science, environment, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Veeloomad ja -taimed; Водные животные и растения; Kalapüük; Veeloomad; Veetaimed; Loodusõpetus eesti keeles
Task examples: Mis kaitseb kala keha?; Mis kala Tormi kätte sai?

## Soomaal
URL: https://www.opiq.ee/kit/570/chapter/31844
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.3
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, soomaal, mari, välitöödel, eesti, keeles
Topics RU: математика, природа, природоведение, окружающая среда, соомаа
Topics EN: mathematics, nature, science, environment
Headings: Soomaal; В Соомаа; Mis on soo?; Mari välitöödel; Loodusõpetus eesti keeles
Task examples: Mis värviga on kaardil tähistatud Soomaa rahvuspark?

## Sootaimed
URL: https://www.opiq.ee/kit/570/chapter/31845
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.4
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, taim, taimed, puu, lill, sootaimed, soos, kasvavad, mari, lihasööjataim
Topics RU: математика, природа, природоведение, окружающая среда, растение, растения, дерево, цветок, болотные
Topics EN: mathematics, nature, science, environment, plant, plants, tree, flower
Headings: Sootaimed; Болотные растения; Mis taimed soos kasvavad?; Mari ja lihasööjataim; Kuidas soos liikuda?; Запомни!; Jäta meelde!; Loodusõpetus eesti keeles
Task examples: Miks ei kasva soos suuri puid?; Märgi õiged vastused.

## Puud
URL: https://www.opiq.ee/kit/570/chapter/31846
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.5
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, taim, taimed, puu, lill, puud, mari, istutab, puid, lehtpuud, okaspuud, mürgine
Topics RU: математика, природа, природоведение, окружающая среда, растение, растения, дерево, цветок, деревья
Topics EN: mathematics, nature, science, environment, plant, plants, tree, flower
Headings: Puud; Деревья; Mari istutab puid; Lehtpuud; Okaspuud; Mürgine puu; Loodusõpetus eesti keeles
Task examples: Uuri pilti. Mis õunapuu osast hoiab Mari kinni?; Lohista puu osa nimetus pildil õigesse kohta.

## Põõsad
URL: https://www.opiq.ee/kit/570/chapter/31847
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.6
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, põõsad, mari, linnupesa, mürgised, eesti, keeles
Topics RU: математика, природа, природоведение, окружающая среда, кустарники
Topics EN: mathematics, nature, science, environment
Headings: Põõsad; Кустарники; Mari ja linnupesa; Mürgised põõsad; Loodusõpetus eesti keeles
Task examples: Miks on põõsad lindudele olulised? Vali õiged vastused.; Kas lause käib puu või põõsa kohta? Vali õige vastus.

## Puhmad ja rohttaimed
URL: https://www.opiq.ee/kit/570/chapter/31848
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.7
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, taim, taimed, puu, lill, puhmad, rohttaimed, mari, matkal, puittaimed
Topics RU: математика, природа, природоведение, окружающая среда, растение, растения, дерево, цветок, кустарнички, травянистые
Topics EN: mathematics, nature, science, environment, plant, plants, tree, flower
Headings: Puhmad ja rohttaimed; Кустарнички и травянистые растения; Mari matkal; Puhmad; Puittaimed ja rohttaimed; Mürgised rohttaimed; Loodusõpetus eesti keeles
Task examples: Märgi, milliste Mari nähtud taimede marjad on mürgised.; Kas vastus käib pohla, jõhvika või mõlema kohta? Lohista vastus õige pealkirja alla.

## Ilm
URL: https://www.opiq.ee/kit/570/chapter/32084
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.8
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, mari, ilmajaamas, lisa, satelliidid
Topics RU: математика, природа, природоведение, окружающая среда, погода, дополнительно
Topics EN: mathematics, nature, science, environment
Headings: Ilm; Погода; Mari ilmajaamas; Дополнительно. Cпутники; Lisa. Satelliidid; Loodusõpetus eesti keeles
Task examples: Mida pildil olevate mõõteriistadega mõõdetakse? Ühenda paarid.; Uuri ilmakaarti ja vali õige vastus.

## Veeringlus
URL: https://www.opiq.ee/kit/570/chapter/32085
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 2.9
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, veeringlus, mari, allikas, olekud, eesti
Topics RU: математика, природа, природоведение, окружающая среда, круговорот, воды
Topics EN: mathematics, nature, science, environment
Headings: Veeringlus; Круговорот воды; Mari ja allikas; Vee olekud; Loodusõpetus eesti keeles
Task examples: Uuri joonist. Vali lünka õige sõna.; Kuidas vett mingis olekus nimetatakse? Ühenda paarid.

## Eesti-vene sõnastik
URL: https://www.opiq.ee/kit/570/chapter/31849
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 3.1
Topics ET: matemaatika, eesti, vene, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Eesti-vene sõnastik

## Vene-eesti sõnastik
URL: https://www.opiq.ee/kit/570/chapter/31850
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 3.2
Topics ET: matemaatika, vene, eesti, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Vene-eesti sõnastik

## Impressum
URL: https://www.opiq.ee/kit/570/chapter/31851
Book: Природоведение для 2 класса 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Avita
Book ID: avita_природовед_2_ru
Chapter ID: 3.3
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Loodusõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/121
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 169
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/121
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 234
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Taimeriik
URL: https://www.opiq.ee/kit/121/chapter/6199
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.1
Topics ET: loodusõpetus, taimeriik
Topics RU: природоведение
Topics EN: science
Headings: Taimeriik

## + Umbrohud
URL: https://www.opiq.ee/kit/121/chapter/6208
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.10
Topics ET: loodusõpetus, umbrohud, tähesegadik, probleem
Topics RU: природоведение
Topics EN: science
Headings: + Umbrohud; Tähesegadik; Probleem?

## + Köögiviljad
URL: https://www.opiq.ee/kit/121/chapter/6209
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.11
Topics ET: loodusõpetus, köögiviljad, tunned, neid, köögivilju
Topics RU: природоведение
Topics EN: science
Headings: + Köögiviljad; Kas tunned neid köögivilju?

## Veetaimed ja nende erinevus maismaataimedest
URL: https://www.opiq.ee/kit/121/chapter/6210
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.12
Topics ET: loodusõpetus, taim, taimed, puu, lill, veetaimed, nende, erinevus, maismaataimedest, veetaimi, kaldataimed, põhjataimed, ujulehtedega
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Veetaimed ja nende erinevus maismaataimedest; Veetaimed; Veetaimi; Kaldataimed; Põhjataimed; Ujulehtedega taimed ja ujuvad taimed; Tähesegadik; Probleem?

## + Toataimed
URL: https://www.opiq.ee/kit/121/chapter/6214
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.13
Topics ET: loodusõpetus, toataimed
Topics RU: природоведение
Topics EN: science
Headings: + Toataimed

## Taimede kordamine
URL: https://www.opiq.ee/kit/121/chapter/6215
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.14
Topics ET: loodusõpetus, kordamine, korda, harjutan, taimede, tähesegadik
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Taimede kordamine; Tähesegadik
Task examples: Vaata pilti ja jaota taimed õigetesse rühmadesse.; Kas lause on õige või vale? Märgista tõesed laused.

## Põhiteadmised taimedest
URL: https://www.opiq.ee/kit/121/chapter/6216
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.15
Topics ET: loodusõpetus, põhiteadmised, taimedest
Topics RU: природоведение
Topics EN: science
Headings: Põhiteadmised taimedest

## Maismaataimed
URL: https://www.opiq.ee/kit/121/chapter/6200
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.2
Topics ET: loodusõpetus, taim, taimed, puu, lill, maismaataimed, sarnased, projekt
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Maismaataimed; Sarnased taimed; Projekt

## Taimede välisehitus
URL: https://www.opiq.ee/kit/121/chapter/6201
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.3
Topics ET: loodusõpetus, taimede, välisehitus, taime, osad, katse, kasvamiseks, vajalik, kasvamine, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Taimede välisehitus; Taime osad; Katse; Mis on taimede kasvamiseks vajalik?; Taimede kasvamine; Tähesegadik

## Puud
URL: https://www.opiq.ee/kit/121/chapter/6202
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, puud, osad, õppekäik, probleem, puude, lehed, viljapuud, okaspuud
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Puud; Puu osad; Õppekäik; Probleem?; Puude lehed; Viljapuud; Okaspuud

## Põõsad
URL: https://www.opiq.ee/kit/121/chapter/6203
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.5
Topics ET: loodusõpetus, põõsad, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Põõsad; Tähesegadik

## Marjapõõsad
URL: https://www.opiq.ee/kit/121/chapter/6204
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.6
Topics ET: loodusõpetus, marjapõõsad, põõsaste, rühmitamine, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Marjapõõsad; Põõsaste rühmitamine; Tähesegadik 1; Tähesegadik 2

## Rohttaimed
URL: https://www.opiq.ee/kit/121/chapter/6205
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.7
Topics ET: loodusõpetus, rohttaimed, rohtaime, osad
Topics RU: природоведение
Topics EN: science
Headings: Rohttaimed; Rohtaime osad

## + Teraviljad
URL: https://www.opiq.ee/kit/121/chapter/6206
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.8
Topics ET: loodusõpetus, teraviljad, teraviljatooted, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: + Teraviljad; Teraviljatooted; Tähesegadik 1; Tähesegadik 2

## + Lilled
URL: https://www.opiq.ee/kit/121/chapter/6207
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 1.9
Topics ET: loodusõpetus, lilled
Topics RU: природоведение
Topics EN: science
Headings: + Lilled

## Maismaaloomad
URL: https://www.opiq.ee/kit/121/chapter/6217
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.1
Topics ET: loodusõpetus, maismaaloomad, sarnaste, loomade, paarid, projekt
Topics RU: природоведение
Topics EN: science
Headings: Maismaaloomad; Sarnaste loomade paarid; Projekt

## Kalad
URL: https://www.opiq.ee/kit/121/chapter/6226
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.10
Topics ET: loodusõpetus, kalad, kala, kehaosad, laused, kaladest, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Kalad; Kala kehaosad; Laused kaladest; Tähesegadik

## + Teisi veeloomi
URL: https://www.opiq.ee/kit/121/chapter/6227
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.11
Topics ET: loodusõpetus, teisi, veeloomi, veetaimed, veeloomad
Topics RU: природоведение
Topics EN: science
Headings: + Teisi veeloomi; Veetaimed ja veeloomad

## Koduloomad
URL: https://www.opiq.ee/kit/121/chapter/6228
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.12
Topics ET: loodusõpetus, koduloomad, kana, kits, lehm, lammas, hobune, siga, küülik, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Koduloomad; 1/7 Kana; 2/7 Kits; 3/7 Lehm; 4/7 Lammas; 5/7 Hobune; 6/7 Siga; 7/7 Küülik; Tähesegadik; Probleem?

## Loomade toitumine
URL: https://www.opiq.ee/kit/121/chapter/6229
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.13
Topics ET: loodusõpetus, loomade, toitumine, rühmitamine
Topics RU: природоведение
Topics EN: science
Headings: Loomade toitumine; Rühmitamine

## Loomade kasvamine
URL: https://www.opiq.ee/kit/121/chapter/6230
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.14
Topics ET: loodusõpetus, loomade, kasvamine
Topics RU: природоведение
Topics EN: science
Headings: Loomade kasvamine

## Loomade kordamine
URL: https://www.opiq.ee/kit/121/chapter/6231
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.15
Topics ET: loodusõpetus, kordamine, korda, harjutan, loomade, tähesegadik
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Loomade kordamine; Tähesegadik
Task examples: Jaota loomad kolme rühma.; Millised laused on õiged, millised valed? Märgi õiged laused.

## Põhiteadmised loomadest
URL: https://www.opiq.ee/kit/121/chapter/6232
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.16
Topics ET: loodusõpetus, põhiteadmised, loomadest
Topics RU: природоведение
Topics EN: science
Headings: Põhiteadmised loomadest

## Nuputamiseks
URL: https://www.opiq.ee/kit/121/chapter/6233
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.17
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, nuputamiseks, metsataimed, veetaimed, tähesegadik
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Nuputamiseks; Metsataimed ja -loomad; Veetaimed ja -loomad; Tähesegadik

## Loomade välisehitus
URL: https://www.opiq.ee/kit/121/chapter/6218
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, loomade, välisehitus, looma, kehaosad, kehaosade
Topics RU: природоведение
Topics EN: science
Headings: Loomade välisehitus; Looma kehaosad; Kehaosade ülesanded

## Metsloomad
URL: https://www.opiq.ee/kit/121/chapter/6219
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.3
Topics ET: loodusõpetus, metsloomad, tähesegadik, probleem
Topics RU: природоведение
Topics EN: science
Headings: Metsloomad; Tähesegadik; Probleem?

## + Maod ja sisalikud
URL: https://www.opiq.ee/kit/121/chapter/6220
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.4
Topics ET: loodusõpetus, maod, sisalikud, probleem
Topics RU: природоведение
Topics EN: science
Headings: + Maod ja sisalikud; Probleem?

## + Kahepaiksed
URL: https://www.opiq.ee/kit/121/chapter/6221
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.5
Topics ET: loodusõpetus, kahepaiksed, õige, vale, tähesegadik, probleem
Topics RU: природоведение
Topics EN: science
Headings: + Kahepaiksed; Õige või vale?; Tähesegadik; Probleem?

## Linnud
URL: https://www.opiq.ee/kit/121/chapter/6222
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, linnu, kehaosad, kehaosade, linnule, sobimatu, toit, probleem
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnud; Linnu kehaosad; Kehaosade ülesanded; Linnule sobimatu toit; Probleem?

## Tuntumaid linde
URL: https://www.opiq.ee/kit/121/chapter/6223
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.7
Topics ET: loodusõpetus, tuntumaid, linde, probleem
Topics RU: природоведение
Topics EN: science
Headings: Tuntumaid linde; Probleem?

## Veelinnud
URL: https://www.opiq.ee/kit/121/chapter/6224
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.8
Topics ET: loodusõpetus, veelinnud, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Veelinnud; Tähesegadik 1; Tähesegadik 2

## Veeloomad ja nende erinevus maismaaloomadest
URL: https://www.opiq.ee/kit/121/chapter/6225
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 2.9
Topics ET: loodusõpetus, veeloomad, nende, erinevus, maismaaloomadest, maismaaloomad
Topics RU: природоведение
Topics EN: science
Headings: Veeloomad ja nende erinevus maismaaloomadest; Maismaaloomad ja veeloomad

## Ilma tunnused
URL: https://www.opiq.ee/kit/121/chapter/6234
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.1
Topics ET: loodusõpetus, ilma, tunnused
Topics RU: природоведение
Topics EN: science
Headings: Ilma tunnused

## Õhutemperatuur ja selle mõõtmine
URL: https://www.opiq.ee/kit/121/chapter/6235
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.2
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, õhutemperatuur, selle, termomeetriga, tutvumine, õhutemperatuuri, termomeetri, näit
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Õhutemperatuur ja selle mõõtmine; Termomeetriga tutvumine; Õhutemperatuuri mõõtmine; Termomeetri näit

## Pilvisus
URL: https://www.opiq.ee/kit/121/chapter/6236
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.3
Topics ET: loodusõpetus, pilvisus, tänane
Topics RU: природоведение
Topics EN: science
Headings: Pilvisus; Tänane pilvisus

## Sademed
URL: https://www.opiq.ee/kit/121/chapter/6237
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.4
Topics ET: loodusõpetus, sademed, tänased
Topics RU: природоведение
Topics EN: science
Headings: Sademed; Tänased sademed

## Tuul
URL: https://www.opiq.ee/kit/121/chapter/6238
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.5
Topics ET: loodusõpetus, tuul, tänane
Topics RU: природоведение
Topics EN: science
Headings: Tuul; Tänane ilm

## + Ilmastikunähtused
URL: https://www.opiq.ee/kit/121/chapter/6239
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.6
Topics ET: loodusõpetus, ilmastikunähtused, ilmaennustus, tegelik, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: + Ilmastikunähtused; Ilmaennustus ja tegelik ilm; Tähesegadik

## Teema „Ilm” kordamine
URL: https://www.opiq.ee/kit/121/chapter/6240
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.7
Topics ET: loodusõpetus, kordamine, korda, harjutan, teema, tähesegadik
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Teema „Ilm” kordamine; Tähesegadik
Task examples: Kas termomeetrite alla on kirjutatud õige või vale temperatuur? Vale temperatuuri korral kirjuta lünka õige temperatuur. Õige temperatuuri korral jäta lünk tühjaks.; Vaata pilti ja vasta küsimustele.

## Põhiteadmised ilma kohta
URL: https://www.opiq.ee/kit/121/chapter/6241
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 3.8
Topics ET: loodusõpetus, põhiteadmised, ilma, kohta
Topics RU: природоведение
Topics EN: science
Headings: Põhiteadmised ilma kohta

## Inimene
URL: https://www.opiq.ee/kit/121/chapter/6242
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.1
Topics ET: loodusõpetus, inimene, keha, meeled, tervis
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimene

## Kaalumine
URL: https://www.opiq.ee/kit/121/chapter/6251
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.10
Topics ET: loodusõpetus, kaalumine
Topics RU: природоведение
Topics EN: science
Headings: Kaalumine

## Toidupakendid
URL: https://www.opiq.ee/kit/121/chapter/6252
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.11
Topics ET: loodusõpetus, toidupakendid, teave, pakendil, info, toidupakendil
Topics RU: природоведение
Topics EN: science
Headings: Toidupakendid; Teave pakendil; Info toidupakendil

## Tervislik toitumine
URL: https://www.opiq.ee/kit/121/chapter/6253
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.12
Topics ET: loodusõpetus, tervislik, toitumine, probleem, tervisliku, toitumise, püramiid, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Tervislik toitumine; Probleem?; Tervisliku toitumise püramiid; Tähesegadik 1; Tähesegadik 2

## Toidukorrad
URL: https://www.opiq.ee/kit/121/chapter/6254
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.13
Topics ET: loodusõpetus, toidukorrad, probleem
Topics RU: природоведение
Topics EN: science
Headings: Toidukorrad; Probleem?

## Käitumine söögilauas
URL: https://www.opiq.ee/kit/121/chapter/6255
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.14
Topics ET: loodusõpetus, käitumine, söögilauas, meeles, õige, vale
Topics RU: природоведение
Topics EN: science
Headings: Käitumine söögilauas; Pea meeles!; Õige või vale?

## Pesemine
URL: https://www.opiq.ee/kit/121/chapter/6256
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.15
Topics ET: loodusõpetus, pesemine, probleem
Topics RU: природоведение
Topics EN: science
Headings: Pesemine; Probleem?

## Puhkamine
URL: https://www.opiq.ee/kit/121/chapter/6257
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.16
Topics ET: loodusõpetus, puhkamine, päevaplaan, kasulik, kahjulik
Topics RU: природоведение
Topics EN: science
Headings: Puhkamine; Päevaplaan; Minu päevaplaan; 1/7 Kasulik või kahjulik?; 2/7 Kasulik või kahjulik?; 3/7 Kasulik või kahjulik?; 4/7 Kasulik või kahjulik?; 5/7 Kasulik või kahjulik?; 6/7 Kasulik või kahjulik?; 7/7 Kasulik või kahjulik?

## Kehatemperatuuri mõõtmine
URL: https://www.opiq.ee/kit/121/chapter/6258
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.17
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, kehatemperatuuri, kehatemperatuur, tähesegadik
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Kehatemperatuuri mõõtmine; Minu kehatemperatuur; Tähesegadik 1; Tähesegadik 2

## Inimese ja looduse seosed
URL: https://www.opiq.ee/kit/121/chapter/6259
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.18
Topics ET: loodusõpetus, inimese, looduse, seosed, õige, vale, projekt, prügi, tekkimine, probleem
Topics RU: природоведение
Topics EN: science
Headings: Inimese ja looduse seosed; Õige või vale?; Projekt: prügi tekkimine; Probleem?; Projekt: kooli reovesi

## Linnaelu ja maaelu erinevused
URL: https://www.opiq.ee/kit/121/chapter/6260
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.19
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, linnaelu, maaelu, erinevused, linna, võrdlus, elukoht, õige, vale
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Linnaelu ja maaelu erinevused; Linna- ja maaelu võrdlus; Minu elukoht; Õige või vale?; Inimene ja loodus

## Inimese välisehitus
URL: https://www.opiq.ee/kit/121/chapter/6243
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.2
Topics ET: loodusõpetus, inimese, välisehitus, loomade, võrdlus
Topics RU: природоведение
Topics EN: science
Headings: Inimese välisehitus; Inimese ja loomade võrdlus

## Teema „Inimene” kordamine
URL: https://www.opiq.ee/kit/121/chapter/6261
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.20
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, loodus, keskkond, inimene, keha, meeled, tervis, teema, kehaosad, toidupakendid, päevaplaan, tähesegadik
Topics RU: природоведение, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, comparison, compare, greater, less, measurement, unit, length, mass, volume, revision, review, practice, nature, environment, human, body, senses, health
Headings: Teema „Inimene” kordamine; Kehaosad; Mõõtmine ja võrdlemine; Toidupakendid; Inimene ja keskkond; Päevaplaan; Tähesegadik 1; Tähesegadik 2

## Põhiteadmised inimese kohta
URL: https://www.opiq.ee/kit/121/chapter/6262
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.21
Topics ET: loodusõpetus, põhiteadmised, inimese, kohta
Topics RU: природоведение
Topics EN: science
Headings: Põhiteadmised inimese kohta

## Kere
URL: https://www.opiq.ee/kit/121/chapter/6244
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.3
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, kere, esipool, tagapool
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Kere; Keha esipool ja tagapool

## Pea
URL: https://www.opiq.ee/kit/121/chapter/6245
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.4
Topics ET: loodusõpetus, osad, milliseid, kehaosi, inimesel, pole, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Pea; Näo osad; Milliseid kehaosi inimesel pole?; Tähesegadik 1; Tähesegadik 2

## Käsi ja jalg
URL: https://www.opiq.ee/kit/121/chapter/6246
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.5
Topics ET: loodusõpetus, käsi, jalg, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Käsi ja jalg; Tähesegadik

## Kehaosade kordamine
URL: https://www.opiq.ee/kit/121/chapter/6247
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, kehaosade, pildil, valesti, ristsõna, tähesegadik
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kehaosade kordamine; Mis on pildil valesti?; Ristsõna; Tähesegadik

## Keha mõõtmed
URL: https://www.opiq.ee/kit/121/chapter/6248
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.7
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, mõõtmed, tähesegadik
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Keha mõõtmed; Tähesegadik

## Pikkuste võrdlemine ja mõõtmine
URL: https://www.opiq.ee/kit/121/chapter/6249
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.8
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, pikkuste, pikkuse, katse, probleem, klass, järjekorras
Topics RU: природоведение, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём
Topics EN: science, comparison, compare, greater, less, measurement, unit, length, mass, volume
Headings: Pikkuste võrdlemine ja mõõtmine; Pikkuse võrdlemine; Katse; Probleem?; Minu klass pikkuse järjekorras; Pikkuse mõõtmine; Pikkus ja siruulatus

## Toit ja toiduained
URL: https://www.opiq.ee/kit/121/chapter/6250
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 4.9
Topics ET: loodusõpetus, toit, toiduained, tähesegadik, projekt
Topics RU: природоведение
Topics EN: science
Headings: Toit ja toiduained; Tähesegadik 1; Tähesegadik 2; Projekt

## Metsa või pargi vaatluskaart
URL: https://www.opiq.ee/kit/121/chapter/6263
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 5.1
Topics ET: loodusõpetus, metsa, pargi, vaatluskaart
Topics RU: природоведение
Topics EN: science
Headings: Metsa või pargi vaatluskaart

## Veekogu vaatluskaart
URL: https://www.opiq.ee/kit/121/chapter/6264
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 5.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, vaatluskaart
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Veekogu vaatluskaart

## Loomapargi, loomaaia või talu vaatluskaart
URL: https://www.opiq.ee/kit/121/chapter/6265
Book: Loodusõpetus 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: koolibri_loodusõpet_2_et
Chapter ID: 5.3
Topics ET: loodusõpetus, loomapargi, loomaaia, talu, vaatluskaart
Topics RU: природоведение
Topics EN: science
Headings: Loomapargi, loomaaia või talu vaatluskaart

## Природо­ведение 2 клacc – Opiq
URL: https://www.opiq.ee/Kit/Details/132
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 360
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение
Topics EN: mathematics

## Природо­ведение 2 клacc – Opiq
URL: https://www.opiq.ee/Kit/Details/132
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 428
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение
Topics EN: mathematics

## Растения
URL: https://www.opiq.ee/kit/132/chapter/7069
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.1
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Растения

## Сорные растения (сорняки)
URL: https://www.opiq.ee/kit/132/chapter/7078
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.10
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, сорные, сорняки, вопрос
Topics EN: mathematics, plant, plants, tree, flower
Headings: Сорные растения (сорняки); Вопрос?

## Овощи
URL: https://www.opiq.ee/kit/132/chapter/7079
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.11
Topics ET: matemaatika
Topics RU: математика, овощи
Topics EN: mathematics
Headings: Овощи

## Водные растения и их отличие от наземных растений
URL: https://www.opiq.ee/kit/132/chapter/7080
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.12
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, водные, отличие, наземных, растений
Topics EN: mathematics, plant, plants, tree, flower
Headings: Водные растения и их отличие от наземных растений; Водные растения

## Прибрежные растения
URL: https://www.opiq.ee/kit/132/chapter/7081
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.13
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, прибрежные
Topics EN: mathematics, plant, plants, tree, flower
Headings: Прибрежные растения

## Донные растения
URL: https://www.opiq.ee/kit/132/chapter/7082
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.14
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, донные
Topics EN: mathematics, plant, plants, tree, flower
Headings: Донные растения

## Растения с плавающими листьями и плавающие растения
URL: https://www.opiq.ee/kit/132/chapter/7083
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.15
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, плавающими, листьями, плавающие, вопрос
Topics EN: mathematics, plant, plants, tree, flower
Headings: Растения с плавающими листьями и плавающие растения; Вопрос?

## Комнатные растения
URL: https://www.opiq.ee/kit/132/chapter/7084
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.16
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, комнатные
Topics EN: mathematics, plant, plants, tree, flower
Headings: Комнатные растения

## Повторение темы «Растения»
URL: https://www.opiq.ee/kit/132/chapter/7085
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.17
Topics ET: matemaatika, kordamine, korda, harjutan, taim, taimed, puu, lill
Topics RU: математика, повторение, повтори, тренировка, растение, растения, дерево, цветок, темы
Topics EN: mathematics, revision, review, practice, plant, plants, tree, flower
Headings: Повторение темы «Растения»; Повторение 1; Повторение 2; Повторение 3; Повторение 4; Повторение 5; Повторение 6

## Основные сведения о растениях
URL: https://www.opiq.ee/kit/132/chapter/7086
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.18
Topics ET: matemaatika
Topics RU: математика, основные, сведения, растениях
Topics EN: mathematics
Headings: Основные сведения о растениях

## Наземные растения
URL: https://www.opiq.ee/kit/132/chapter/7070
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.2
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, наземные, похожие, проект
Topics EN: mathematics, plant, plants, tree, flower
Headings: Наземные растения; Похожие растения; Проект

## Внешнее строение растений
URL: https://www.opiq.ee/kit/132/chapter/7071
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.3
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, внешнее, строение, растений, части, опыт, необходимо, растениям, роста
Topics EN: mathematics, plant, plants, tree, flower
Headings: Внешнее строение растений; Части растения; Опыт; Что необходимо растениям для роста?; Рост растений

## Деревья
URL: https://www.opiq.ee/kit/132/chapter/7072
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, деревья, части, дерева, учебная, экскурсия, вопрос, книга, плодовые
Topics EN: mathematics
Headings: Деревья; Части дерева; Учебная экскурсия; Вопрос?; Pабочая книга; Плодовые деревья; Хвойные деревья

## Кустарники
URL: https://www.opiq.ee/kit/132/chapter/7073
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, кустарники
Topics EN: mathematics
Headings: Кустарники

## Ягодные кустарники
URL: https://www.opiq.ee/kit/132/chapter/7074
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, ягодные, кустарники
Topics EN: mathematics
Headings: Ягодные кустарники; Кустарники

## Травянистые растения
URL: https://www.opiq.ee/kit/132/chapter/7075
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.7
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, травянистые, основные, части, травянистых, растений
Topics EN: mathematics, plant, plants, tree, flower
Headings: Травянистые растения; Основные части травянистых растений.

## Злаки
URL: https://www.opiq.ee/kit/132/chapter/7076
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.8
Topics ET: matemaatika
Topics RU: математика, злаки, продукты, злаков
Topics EN: mathematics
Headings: Злаки; Продукты из злаков

## Цветы
URL: https://www.opiq.ee/kit/132/chapter/7077
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 1.9
Topics ET: matemaatika
Topics RU: математика, цветы
Topics EN: mathematics
Headings: Цветы

## Наземные животные
URL: https://www.opiq.ee/kit/132/chapter/7087
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.1
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, наземные, проект
Topics EN: mathematics, animal, animals, birds, insects
Headings: Наземные животные; Проект

## Рыбы
URL: https://www.opiq.ee/kit/132/chapter/7096
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.10
Topics ET: matemaatika
Topics RU: математика, рыбы, части, тела, знаем, рыбах
Topics EN: mathematics
Headings: Рыбы; Части тела рыбы; Что мы знаем о рыбах

## Другие водные животные
URL: https://www.opiq.ee/kit/132/chapter/7097
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.11
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, другие, водные
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Другие водные животные; Водные животные и водные растения

## Домашние животные
URL: https://www.opiq.ee/kit/132/chapter/7098
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.12
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, домашние, питаются, дают, человеку, вопрос
Topics EN: mathematics, animal, animals, birds, insects
Headings: Домашние животные; Чем питаются и что дают человеку домашние животные; Вопрос?

## Питание животных
URL: https://www.opiq.ee/kit/132/chapter/7099
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.13
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, питание, животных, плотоядные, всеядные, травоядные
Topics EN: mathematics, animal, animals, birds, insects
Headings: Питание животных; Плотоядные, всеядные и травоядные животные

## Рост животных
URL: https://www.opiq.ee/kit/132/chapter/7100
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.14
Topics ET: matemaatika
Topics RU: математика, рост, животных
Topics EN: mathematics
Headings: Рост животных

## Повторение темы «Животные»
URL: https://www.opiq.ee/kit/132/chapter/7101
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.15
Topics ET: matemaatika, kordamine, korda, harjutan, loom, loomad, linnud, putukad
Topics RU: математика, повторение, повтори, тренировка, животное, животные, птицы, насекомые, темы
Topics EN: mathematics, revision, review, practice, animal, animals, birds, insects
Headings: Повторение темы «Животные»; Повторение 1; Повторение 2; Повторение 3; Повторение 4

## Основные сведения о животных
URL: https://www.opiq.ee/kit/132/chapter/7102
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.16
Topics ET: matemaatika
Topics RU: математика, основные, сведения, животных
Topics EN: mathematics
Headings: Основные сведения о животных

## Для размышления
URL: https://www.opiq.ee/kit/132/chapter/7103
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.17
Topics ET: matemaatika
Topics RU: математика, размышления
Topics EN: mathematics
Headings: Для размышления

## Внешнее строение животных
URL: https://www.opiq.ee/kit/132/chapter/7088
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, внешнее, строение, животных, части, тела, животного, какая, часть
Topics EN: mathematics
Headings: Внешнее строение животных; Части тела животного; Какая это часть тела?

## Дикие животные
URL: https://www.opiq.ee/kit/132/chapter/7089
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.3
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, дикие
Topics EN: mathematics, animal, animals, birds, insects
Headings: Дикие животные

## Змеи и ящерицы
URL: https://www.opiq.ee/kit/132/chapter/7090
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, змеи, ящерицы
Topics EN: mathematics
Headings: Змеи и ящерицы

## Земноводные
URL: https://www.opiq.ee/kit/132/chapter/7091
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, земноводные, лягушки, вопрос
Topics EN: mathematics
Headings: Земноводные; Лягушки; Вопрос?

## Птицы
URL: https://www.opiq.ee/kit/132/chapter/7092
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.6
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, части, тела, какие, вопрос
Topics EN: mathematics, animal, animals, birds, insects
Headings: Птицы; Части тела птицы; Какие это части тела?; Вопрос?

## Наиболее известные птицы
URL: https://www.opiq.ee/kit/132/chapter/7093
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.7
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, наиболее, известные, вопрос
Topics EN: mathematics, animal, animals, birds, insects
Headings: Наиболее известные птицы; Вопрос?

## Водоплавающие птицы
URL: https://www.opiq.ee/kit/132/chapter/7094
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.8
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, водоплавающие
Topics EN: mathematics, animal, animals, birds, insects
Headings: Водоплавающие птицы

## Водные животные и их отличие от наземных животных
URL: https://www.opiq.ee/kit/132/chapter/7095
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 2.9
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, водные, отличие, наземных, животных, наземные
Topics EN: mathematics, animal, animals, birds, insects
Headings: Водные животные и их отличие от наземных животных; Наземные и водные животные

## Элементы погоды
URL: https://www.opiq.ee/kit/132/chapter/7104
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, элементы, погоды
Topics EN: mathematics
Headings: Элементы погоды

## Температура воздуха и её измерение
URL: https://www.opiq.ee/kit/132/chapter/7105
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.2
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, температура, воздуха, термометр, температуры
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Температура воздуха и её измерение; Термометр; Измерение температуры

## Облачность
URL: https://www.opiq.ee/kit/132/chapter/7106
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, облачность
Topics EN: mathematics
Headings: Облачность

## Осадки
URL: https://www.opiq.ee/kit/132/chapter/7107
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, осадки
Topics EN: mathematics
Headings: Осадки

## Ветер
URL: https://www.opiq.ee/kit/132/chapter/7108
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, ветер
Topics EN: mathematics
Headings: Ветер

## Погодные явления
URL: https://www.opiq.ee/kit/132/chapter/7109
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика, погодные, явления, вопрос
Topics EN: mathematics
Headings: Погодные явления; Вопрос?

## Повторение темы «Погода»
URL: https://www.opiq.ee/kit/132/chapter/7110
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.7
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка, темы, погода
Topics EN: mathematics, revision, review, practice
Headings: Повторение темы «Погода»; Повторение 1; Повторение 2; Повторение 3

## Основные сведения о погоде
URL: https://www.opiq.ee/kit/132/chapter/7111
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика, основные, сведения, погоде
Topics EN: mathematics
Headings: Основные сведения о погоде

## Человек
URL: https://www.opiq.ee/kit/132/chapter/7112
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.1
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Человек

## Взвешивание
URL: https://www.opiq.ee/kit/132/chapter/7121
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.10
Topics ET: matemaatika
Topics RU: математика, взвешивание
Topics EN: mathematics
Headings: Взвешивание

## Упаковки продуктов
URL: https://www.opiq.ee/kit/132/chapter/7122
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика, упаковки, продуктов, написано, пищевых, упаковках
Topics EN: mathematics
Headings: Упаковки продуктов; Что написано на пищевых упаковках

## Здоровое питание
URL: https://www.opiq.ee/kit/132/chapter/7123
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.12
Topics ET: matemaatika
Topics RU: математика, здоровое, питание, пирамида, здорового, питания, полезно, есть, реже, чаще
Topics EN: mathematics
Headings: Здоровое питание; Пирамида здорового питания; Что полезно есть реже, а что – чаще

## Приём пищи
URL: https://www.opiq.ee/kit/132/chapter/7124
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.13
Topics ET: matemaatika
Topics RU: математика, пищи, меню
Topics EN: mathematics
Headings: Приём пищи; Меню

## Поведение за столом
URL: https://www.opiq.ee/kit/132/chapter/7125
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.14
Topics ET: matemaatika
Topics RU: математика, поведение, столом, пища
Topics EN: mathematics
Headings: Поведение за столом; Пища и поведение за столом

## Уход за телом
URL: https://www.opiq.ee/kit/132/chapter/7126
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.15
Topics ET: matemaatika
Topics RU: математика, уход, телом
Topics EN: mathematics
Headings: Уход за телом

## Отдых
URL: https://www.opiq.ee/kit/132/chapter/7127
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.16
Topics ET: matemaatika
Topics RU: математика, отдых, распорядок, полезно, вредно
Topics EN: mathematics
Headings: Отдых; Распорядок дня; Полезно или вредно

## Измерение температуры тела
URL: https://www.opiq.ee/kit/132/chapter/7128
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.17
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, температуры, тела, термометр, температура, карта, понятий
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Измерение температуры тела; Термометр и температура тела; Карта понятий

## Связь человека и природы
URL: https://www.opiq.ee/kit/132/chapter/7129
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.18
Topics ET: matemaatika
Topics RU: математика, связь, человека, природы, проект
Topics EN: mathematics
Headings: Связь человека и природы; Проект

## Различия между жизнью в сельской местности и в городе
URL: https://www.opiq.ee/kit/132/chapter/7130
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.19
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem
Topics RU: математика, сравнение, сравни, больше, меньше, различия, между, жизнью, сельской, местности, городе, жизнь, правильно, неправильно, необходимо, человеку, чего
Topics EN: mathematics, comparison, compare, greater, less
Headings: Различия между жизнью в сельской местности и в городе; Жизнь в сельской местности или в городе; Правильно или неправильно; Что необходимо человеку? Чего больше в городе? Чего больше в сельской местности?

## Наружное строение человека
URL: https://www.opiq.ee/kit/132/chapter/7113
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, наружное, строение, человека, сходства, различия
Topics EN: mathematics
Headings: Наружное строение человека; Сходства и различия

## Повторение темы «Человек»
URL: https://www.opiq.ee/kit/132/chapter/7131
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.20
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, loodus, loodusõpetus, keskkond, inimene, keha, meeled, tervis
Topics RU: математика, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка, природа, природоведение, окружающая среда, человек, тело, чувства, здоровье, темы
Topics EN: mathematics, comparison, compare, greater, less, measurement, unit, length, mass, volume, revision, review, practice, nature, science, environment, human, body, senses, health
Headings: Повторение темы «Человек»; Измерение или сравнение; Человек и природа

## Основные сведения о человеке
URL: https://www.opiq.ee/kit/132/chapter/7132
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.21
Topics ET: matemaatika
Topics RU: математика, основные, сведения, человеке
Topics EN: mathematics
Headings: Основные сведения о человеке

## Карта наблюдений за лесом или парком
URL: https://www.opiq.ee/kit/132/chapter/7133
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.22
Topics ET: matemaatika
Topics RU: математика, карта, наблюдений, лесом, парком
Topics EN: mathematics
Headings: Карта наблюдений за лесом или парком

## Карта наблюдений за водоёмом
URL: https://www.opiq.ee/kit/132/chapter/7134
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.23
Topics ET: matemaatika
Topics RU: математика, карта, наблюдений, водо
Topics EN: mathematics
Headings: Карта наблюдений за водоёмом

## Карта наблюдений в заповеднике, зоопарке или на хуторе
URL: https://www.opiq.ee/kit/132/chapter/7135
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.24
Topics ET: matemaatika
Topics RU: математика, карта, наблюдений, заповеднике, зоопарке, хуторе
Topics EN: mathematics
Headings: Карта наблюдений в заповеднике, зоопарке или на хуторе

## Туловище
URL: https://www.opiq.ee/kit/132/chapter/7114
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, туловище, части, тела
Topics EN: mathematics
Headings: Туловище; Части тела

## Голова
URL: https://www.opiq.ee/kit/132/chapter/7115
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, голова, чего, человека
Topics EN: mathematics
Headings: Голова; Чего нет у человека

## Рука
URL: https://www.opiq.ee/kit/132/chapter/7116
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, рука
Topics EN: mathematics
Headings: Рука

## Нога
URL: https://www.opiq.ee/kit/132/chapter/7117
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, нога, кроссворд
Topics EN: mathematics
Headings: Нога; Кроссворд

## Размеры тела
URL: https://www.opiq.ee/kit/132/chapter/7118
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика, размеры, тела
Topics EN: mathematics
Headings: Размеры тела

## Сравнение и измерение роста
URL: https://www.opiq.ee/kit/132/chapter/7119
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.8
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, сравнение, сравни, больше, меньше, измерение, единица измерения, длина, масса, объём, роста, опыт, вопрос, список, учеников, росту
Topics EN: mathematics, comparison, compare, greater, less, measurement, unit, length, mass, volume
Headings: Сравнение и измерение роста; Опыт; Вопрос?; Список учеников по росту; Измерение роста

## Пища и пищевые продукты
URL: https://www.opiq.ee/kit/132/chapter/7120
Book: Природо­ведение 2 клacc 2 klass
Class: 2
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: koolibri_природо­ве_2_ru
Chapter ID: 4.9
Topics ET: matemaatika
Topics RU: математика, пища, пищевые, продукты
Topics EN: mathematics
Headings: Пища и пищевые продукты

## Loodusõpetus 2. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/501
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 265
Topics ET: loodusõpetus, loodus, keskkond, klassile, lihtsustatud, õppekava, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 2. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/501
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 303
Topics ET: loodusõpetus, loodus, keskkond, klassile, lihtsustatud, õppekava, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Aeg
URL: https://www.opiq.ee/kit/501/chapter/27371
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 1.1
Topics ET: loodusõpetus, aeg, kell, kalender, aastaajad, kevad, suvi, sügis, talv, aasta, ajad, aastaaja, nimetus
Topics RU: природоведение, время, часы, календарь, времена года, весна, лето, осень, зима
Topics EN: science, time, clock, calendar, seasons, spring, summer, autumn, winter
Headings: Aeg; 1. Aasta-ajad; Aastaaja nimetus (talv); Aastaaja nimetus (kevad); Aastaaja nimetus (sügis); Aastaaja nimetus (suvi); 2. Aasta-aegade järjekord; Ülesanne 3.1; 3. Nädal; 4. Eile, täna, homme; 5. Kooli-päevad. Puhke-päevad; 6. Kokkuvõte
Task examples: Aastaaja nimetus (talv) TALVEL KEVADEL SUVEL SÜGISEL : 0 : 0 4. LAPS SUUSATAB … Aastaaja nimetus (kevad) TALVEL KEVADEL SUVEL SÜGISEL : 0 : 0 1. OTT KORJAB SINI-LILLI … Aastaaja nimetus (sügis) TALVEL KEVADEL SUVEL SÜGIS; Ülesanne 3.1 KEVAD TALV SUVI : 0 : 0 Ülesanne 3.1 KEVAD TALV : 0 : 0 Ülesanne 3.1 SUVI SÜGIS KEVAD : 0 : 0 Ülesanne 3.1 KEVAD SÜGIS : 0 : 0 Ülesanne 3.1 KEVAD TALV SUVI : 0 : 0 Ülesanne 3.1 KEVAD TALV : 0 : 0 1234

## Sügis (ilm)
URL: https://www.opiq.ee/kit/501/chapter/27372
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 1.2
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, vesi, veeohutus, veekogu, taevas, päike, pilved, tuul, muld, pind
Topics RU: природоведение, времена года, весна, лето, осень, зима, вода, безопасность на воде, водоём
Topics EN: science, seasons, spring, summer, autumn, winter, water, water safety, body of water
Headings: Sügis (ilm); 1. Sügis; Ülesanne 1, 1.2; 2. Taevas – päike, pilved; 3. Õhk; 4. Tuul; 5. Muld; 6. Maa-pind; Jää; Vesi; Lumi; 7. Kokkuvõte; Tööleht: Sügis
Task examples: 6.PausEsita% puhverdatud00:0000:03Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio element.7.PausEsita% puhverdatud00; 1. MIS RIIDED ON LAPSEL SELJAS? 2. MISSUGUNE ON ÕHK? VALI.

## Kalendrikuu. Sügiskuud
URL: https://www.opiq.ee/kit/501/chapter/27373
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 1.3
Topics ET: loodusõpetus, loodus, keskkond, aastaajad, kevad, suvi, sügis, talv, kalendrikuu, sügiskuud, muutub, nädalapäevad, päevad, kuud
Topics RU: природоведение, природа, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: science, nature, environment, seasons, spring, summer, autumn, winter
Headings: Kalendrikuu. Sügiskuud; 1. Loodus muutub; 2. Nädalapäevad; 3. Üks kuu; 4. Kuu-päevad; 5. Sügis-kuud; 6. Sügiskuud ja tähtsad päevad; 7. Kokkuvõte
Task examples: LOE. LOHISTA PILDID ÕIGESSE JÄRJEKORDA.

## Taimed. Taime osad
URL: https://www.opiq.ee/kit/501/chapter/27374
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, taime, osad, aster, tamm, tüvi
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed. Taime osad; 1. Taimed; 2. Aster on taim; 3. Tamm on taim; 4. Taime osad (LILL); 5. Taime osad (PUU); 6. Puu tüvi, oksad ja koor; 7. Kokkuvõte taimede vaatlusest
Task examples: 5. OKSTE KÜLJES ON LEHED.KÜSIMUS: PausEsita% puhverdatud00:0000:04Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio el

## Lehtpuud
URL: https://www.opiq.ee/kit/501/chapter/27375
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, taim, taimed, puu, lill, lehtpuud, mets, park, lehtpuu, lehes, raagus, erinevad, koor
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Lehtpuud; 1. Mets ja park; 2. Lehtpuu; 3. Lehes puu ja raagus puu; 4. Erinevad lehtpuud; 5. Puu ja puu koor; 6. Puu ja lehed; Pihlakas; Tamm; Vaher; Kask; Kastan; 7. Puude viljad; 8. Kokkuvõte; Puuleht
Task examples: Pihlakas TAMM KASK KASTAN PIHLAKAS : 0 : 0 Tamm TAMM KASTAN VAHER KASK : 0 : 0 Vaher TAMM VAHER KASK KASTAN : 0 : 0 Kask KASK PIHLAKAS KASTAN TAMM : 0 : 0 Kastan KASK VAHER KASTAN TAMM : 0 : 0 Pihlakas TAMM KASK KASTAN P; LOE. LOHISTA PILT SÕNA JUURDE.

## Okaspuud
URL: https://www.opiq.ee/kit/501/chapter/27376
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, aastaajad, kevad, suvi, sügis, talv, okaspuud, okaspuu, erinevad, koor, okkad, käbid, toit, puud
Topics RU: природоведение, растение, растения, дерево, цветок, времена года, весна, лето, осень, зима
Topics EN: science, plant, plants, tree, flower, seasons, spring, summer, autumn, winter
Headings: Okaspuud; 1. Okaspuu; 2. Erinevad okaspuud; 3. Puu ja puu koor; 4. Okkad ja käbid; 5. Käbid on toit; 6. Puud suvel ja talvel; Talv; Suvi; 7. Okaspuu on igi-haljas puu; 8. Kokkuvõte
Task examples: Talv KAUGEL ON KUUSED.KASED. KUUSEL ONEI OLE OKKAD KÜLJES.LÄHEDAL ON KASED.KUUSED. KASED ON RAAGUS.LEHES. : 0 : 0 Suvi LÄHEDAL ON KASED.KUUSED. KASED ON LEHT-PUUD.OKAS-PUUD. KAUGEL ON KUUSED.KASED. KUUSED ON OKAS-PUUD.LE; KORRAGAASEMELELANGEVADKASVAVAD

## Viljapuud ja puuviljad
URL: https://www.opiq.ee/kit/501/chapter/27377
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, viljapuud, puuviljad, puud, aias, viljad, vilja, tekivad, õitest
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Viljapuud ja puuviljad; 1. Puud aias; 2. Puu-viljad; 3. Vilja-puud; 4. Viljad tekivad õitest; 5. Vilja sees on seemned; Viljad 2; Viljad 1; 6. Röövik; 7. Kokkuvõte
Task examples: MIS VILJAD NEED ON? TRÜKI PILDI JUURDE NUMBER.; MIS VILJU SÖÖB INIMENE? VALI PILDID.

## Marjapõõsad ja marjad
URL: https://www.opiq.ee/kit/501/chapter/27378
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, inimene, keha, meeled, tervis, marjapõõsad, marjad, põõsas, erinevad, tekivad, õitest, mida
Topics RU: природоведение, растение, растения, дерево, цветок, человек, тело, чувства, здоровье
Topics EN: science, plant, plants, tree, flower, human, body, senses, health
Headings: Marjapõõsad ja marjad; 1. Puu ja põõsas; 2. Marjapõõsad; 3. Erinevad marjad; 4. Marjad tekivad õitest; 5. Mida inimene teeb marjadega?; 6. Kokkuvõte
Task examples: 1. MIS OSAD ON PUUL? 2. MIS OSAD ON PÕÕSAL? Vali.

## Rohttaimed. Lilled
URL: https://www.opiq.ee/kit/501/chapter/27379
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, rohttaimed, lilled, värske, rohi, ristik, hein, roht
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Rohttaimed. Lilled; 1. Värske rohi; 2. Ristik-hein on roht-taim; 3. Roht-taimed; 4. Lilled on roht-taimed; 5. Lilled; 6. Erinevad lilled; 7. Kokkuvõte
Task examples: Loe. Vali lünka õiged sõnad.; Roht-taimed kasvavad (kus?) … 4 metsas põllul pargis : 0 : 0 1 aias tee ääres : 0 : 0 2 aias metsas : 0 : 0 3 pargis põllul : 0 : 0 4 metsas põllul pargis : 0 : 0 1 aias tee ääres : 0 : 0 1234

## Umbrohud
URL: https://www.opiq.ee/kit/501/chapter/27380
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.7
Topics ET: loodusõpetus, taim, taimed, puu, lill, umbrohud, tööd, aias, mihkli, taimedes, vitamiinid, need
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Umbrohud; 1. Tööd aias; 2. Mihkli töö; 3. Umbrohud; 4. Taimedes on vitamiinid; ÜLESANNE 2 (3); ÜLESANNE 2 (1); ÜLESANNE 2 (2); 5. Mis taimed need on?; 6. Kokkuvõte; ÜL
Task examples: PausEsita% puhverdatud00:0000:05Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio element. ÜLESANNE 2 (3) 3. Ema teeb ; PausEsita% puhverdatud00:0000:05Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio element.Vitamiinid on ... , ... ja .

## Köögiviljad
URL: https://www.opiq.ee/kit/501/chapter/27381
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 2.8
Topics ET: loodusõpetus, taim, taimed, puu, lill, köögiviljad, põld, tomati, kartuli, mida, vajab, kasvamiseks
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Köögiviljad; 1. Aed ja põld; 2. Tomati-taim; 3. Kartuli-taim; 4. Mida vajab taim kasvamiseks?; 5. Taime söödav osa; 6. Kokkuvõte
Task examples: Mis on pildil? Loe. Vali sõnad.; SÕNA-RÄGASTIK: vajuta sõna esimesele ja viimasele tähele.

## Koduloomad, -linnud. Toit
URL: https://www.opiq.ee/kit/501/chapter/27382
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 3.1
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, koduloomad, toit, kukk, koera, hane, välimuse
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Koduloomad, -linnud. Toit; 1. Loomad; 2. Linnud; Kukk; 3. Koera ja hane välimuse võrdlus; 4. Koduloomad ja kodulinnud; ÜLESANNE (2); ÜLESANNE (1); 5. Loomade toit; Ülesanne. Küülik; Ülesanne 5.1; Ülesanne 6.1; 6. Lindude toit; Ülesanne. Hani; Ülesanne. Part; 7. Kokkuvõte
Task examples: ÜLESANNE (2) lambad1sead2küülikud3kanad4pardid5 : 0 : 0 ÜLESANNE (1) KOER1KASS2KUKK3LEHM4HOBUNE5 : 0 : 0 ÜLESANNE (2) lambad1sead2küülikud3kanad4pardid5 : 0 : 0 ÜLESANNE (1) KOER1KASS2KUKK3LEHM4HOBUNE5 : 0 : 0 12; Ülesanne. Küülik : 0 : 0 Ülesanne 5.1 Salvesta Ülesanne : 0 : 0 Ülesanne. Küülik : 0 : 0 Ülesanne 5.1 Salvesta 123

## Koduloomad on vajalikud
URL: https://www.opiq.ee/kit/501/chapter/27383
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 3.2
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, koduloomad, vajalikud, lehm, piim, lammas, vill, hobune, kana
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Koduloomad on vajalikud; 1. Koduloomad; 2. Lehm ja piim; 3. Lammas ja vill; 4. Hobune; 5. Kana ja munad, suled, liha; 6. Inimene hoolitseb looma eest; 7. Kokkuvõte
Task examples: MIDA SINA OLED SÖÖNUD? VALI.

## Lemmikloomad
URL: https://www.opiq.ee/kit/501/chapter/27384
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 3.3
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, lemmikloomad, koduloomad, maril, lemmik, mihklil, sinu, kokkuvõte
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Lemmikloomad; 1. Koduloomad; 2. Lemmikloomad; 3. Maril on lemmik-loom; 4. Mihklil on lemmik-loom; 5. Kes on sinu lemmik-loom?; 6. Kokkuvõte
Task examples: KUULA. ÕIGE või VALE? VALI VASTUS.

## Talv ja talvekuud
URL: https://www.opiq.ee/kit/501/chapter/27385
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 4.1
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, talvekuud, aastaaeg, enne, talve, detsember, jaanuar, veebruar
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Talv ja talvekuud; 1. Aastaaeg enne talve; 2. Talvekuud; DETSEMBER; JAANUAR; VEEBRUAR; 3. Talv võib olla erinev; ÜL 2; Ül 1; Tööleht; 4. Kokkuvõte
Task examples: 1.PausEsita% puhverdatud00:0000:04Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio element.2.PausEsita% puhverdatud00; Lohista sõnad õigesse järjekorda.

## Metsloomad (jänes, kits, põder)
URL: https://www.opiq.ee/kit/501/chapter/27386
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 4.2
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, metsloomad, jänes, kits, põder, jänese, välimus, metskitse
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Metsloomad (jänes, kits, põder); 1. Loomad; 2. Metsloomad; 3. Jänese välimus; 4. Metskitse ja põdra välimus; Ülesanne 5.2; Ülesanne 5.1; 5. Sarved. Sõrad. Jäljed; 6. Loomade toit; 7. Loomad on toiduks teistele; Ülesanne 7.3; Ülesanne 7.1; Ülesanne 7.2; 8. Kokkuvõte
Task examples: Märgi KODU-LOOMADE pildid.; Ülesanne 5.2 PEA KÕRVAD SARVED KERE SABA JALAD : 0 : 0 Ülesanne 5.1 PEA KÕRVAD SARVED KERE SABA JALAD : 0 : 0 Ülesanne 5.2 PEA KÕRVAD SARVED KERE SABA JALAD : 0 : 0 Ülesanne 5.1 PEA KÕRVAD SARVED KERE SABA JALAD : 0 : 0 

## Metsloomad (rebane, hunt)
URL: https://www.opiq.ee/kit/501/chapter/27387
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 4.3
Topics ET: loodusõpetus, metsloomad, rebane, hunt, loomade, välimus, hundiga, rebasega, rebase
Topics RU: природоведение
Topics EN: science
Headings: Metsloomad (rebane, hunt); 1. Metsloomad; 2. Loomade välimus; 3. Rebase toit; 4. Hundi toit; 5. Kokkuvõte; Ülesanne 5.1; Ülesanne 5.2
Task examples: Vali lünka õige sõna.; Ülesanne hundiga PEA KÕRVAD KERE SABA JALAD : 0 : 0 Ülesanne rebasega PEA KERE JALAD SABA KÕRVAD : 0 : 0 Ülesanne hundiga PEA KÕRVAD KERE SABA JALAD : 0 : 0 Ülesanne rebasega PEA KERE JALAD SABA KÕRVAD : 0 : 0 12

## Metsloomad (karu, metssiga)
URL: https://www.opiq.ee/kit/501/chapter/27388
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 4.4
Topics ET: loodusõpetus, metsloomad, karu, metssiga, toit, mets, jahivad, kokkuvõte
Topics RU: природоведение
Topics EN: science
Headings: Metsloomad (karu, metssiga); 1. Metsloomad; 2. Karu toit; 3. Mets-sea toit; 4. Kes jahivad karu ja metssiga?; Kokkuvõte

## Metsloomad talvel
URL: https://www.opiq.ee/kit/501/chapter/27389
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 4.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, metsloomad, talvel, magavad, söövad, enne, talve, varusid
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Metsloomad talvel; 1. Loomad magavad; 2. Loomad söövad enne talve; 3. Loomad söövad talve-varusid; 4. Loomad liiguvad talvel; 5. Loomade karvad talvel; 6. Kokkuvõte
Task examples: ÜLESANNE 7 Nendel loomadel on tugevad jalad.Jalgade otsas on sõrad.küünised. : 0 : 0 ÜLESANNE 6 Nendel loomadel on pehmed käpad.Varvastel on küünised.sõrad. : 0 : 0 ÜLESANNE 7 Nendel loomadel on tugevad jalad.Jalgade ots; Kes magavad talvel? Otsi →. Klõpsa sõna 1. ja viimasel tähel.

## Putukad
URL: https://www.opiq.ee/kit/501/chapter/27390
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 4.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, lepa, triinu, liblikas, putukal, jalga, mesilane, sipelgas
Topics RU: природоведение, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье
Topics EN: science, animal, animals, birds, insects, human, body, senses, health
Headings: Putukad; 1. Lepa-triinu ja liblikas; 2. Putukal on 6 jalga; 3. Mesilane ja sipelgas; 4. Putuka keha-osad; 5. Putukad talvel; 6. Kokkuvõte

## Linnud (ränd- ja paigalinnud)
URL: https://www.opiq.ee/kit/501/chapter/27391
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 4.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, ränd, paigalinnud, linnu, kehaosad, lind, putukas, suvel
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnud (ränd- ja paigalinnud); 1. Linnu kehaosad; 2. Lind ja putukas; 3. Linnud suvel; 4. Ränd-linnud; 5. Linnu-parved; 6. Paiga-linnud; 7. Inimesed toidavad linde; 8. Kokkuvõte
Task examples: rasva-tihaneherilane; ÜLESANNE PääsukeKuld-nokkToone-kurg otsib toitu maast.Tema toit on konnad, hiired, mutid ja ussid. : 0 : 0 ÜLESANNE PääsukeToone-kurgKuld-nokk püüab õhust putukaid. : 0 : 0 ÜLESANNE Toone-kurgKuld-nokkPääsuke otsib maast

## Hingamine
URL: https://www.opiq.ee/kit/501/chapter/27392
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 5.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, hingamine, hingan, hingavad, inimesed, elus, olendid
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Hingamine; 1. Ma hingan; 2. Kes hingavad?; Taimed; Inimesed; Loomad; 3. Elus-olendid; 4. Kokkuvõte
Task examples: maasikas, rukki-lill, sõstra-põõsas, ? ? Taimed : 0 : 0 naine, beebi, mees, ? Inimesed : 0 : 0 rästik, haug, põder, kuld-nokk, ? ? Loomad : 0 : 0 maasikas, rukki-lill, sõstra-põõsas, ? ? Taimed : 0 : 0 naine, beebi, mees

## Paljunemine
URL: https://www.opiq.ee/kit/501/chapter/27393
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 5.2
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, paljunemine, koer, kana, tibud, loomapojad, kutsikas, vasikas
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Paljunemine; 1. Inimene ja koer; 2. Kana ja tibud; 3. Loomapojad (kutsikas, vasikas); ÜLESANNE 2.2; 4. Loomapojad (tall, põrsas, varss); 5. Kokkuvõte
Task examples: 4. Munast koorub[sõnaseletus: KOORUB – TULEB MUNAST VÄLJA] tibu. 1 : 0 : 0 1. Kana istub pesal. 1 : 0 : 0 2. Ta soojendab mune. 1 : 0 : 0 3. Kana haudub[sõnaseletus: HAUDUB – HAUB = SOOJENDAB MUNE] oma poegi. 1 : 0 : 0 4; ÜLESANNE 2 Põdral on vasikas. : 0 : 0 ÜLESANNE 2.2 Rebasel on kutsikat. : 0 : 0 ÜLESANNE 2 Hundil on kutsikat. : 0 : 0 ÜLESANNE 2 Põdral on vasikas. : 0 : 0 ÜLESANNE 2.2 Rebasel on kutsikat. : 0 : 0 123

## Toitumine
URL: https://www.opiq.ee/kit/501/chapter/27394
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 5.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, toitumine, inimesed, toituvad, loomapojad, imevad, piima
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Toitumine; 1. Inimesed; 2. Loomad toituvad; 3. Loomapojad imevad piima; 4. Linnud toituvad; Kana; Part; 5. Taimed toituvad; 6. Kes sööb keda? (toiduahel); Toiduahel; 7. Kokkuvõte; Ülesanne 7.5; Ülesanne 7.1; Ülesanne 7.3; Ülesanne 7.4
Task examples: 3 ___ imeb piima ___ sööb lusikaga ___ sööb noa ja kahvliga : 0 : 0 1 ___ imeb piima ___ sööb lusikaga ___ sööb noa ja kahvliga : 0 : 0 2 ___ imeb piima ___ sööb lusikaga ___ sööb noa ja kahvliga : 0 : 0 3 ___ imeb piima; Kana Pildil on kana-tibud.pardi-tibud.pääsukese pojad. Pesas on poega. : 0 : 0 Kana Pildil on pääsukese pojad.kana-tibud.pardi-tibud. Kanal on tibu. : 0 : 0 Part Pildil on pääsukese pojad.kana-tibud.pardi-tibud. Pardil o

## Kasvamine ja arenemine
URL: https://www.opiq.ee/kit/501/chapter/27395
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 5.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, kasvamine, arenemine, kasvab, taime, seemned
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects, human, body, senses, health
Headings: Kasvamine ja arenemine; 1. Inimene kasvab; 2. Loom kasvab; 3. Taim kasvab (puu); 4. Taime seemned; ÜL; 5. Taime elu; 6. Taime vajadused; Päike; Muld; 7. Kokkuvõte
Task examples: Herne-taime seemned on kauna sees. ÜL Pildil on (mitu?) kauna.Kaunas on seemet. : 0 : 0; Päike 1. Päike annab toitu vett soojust valgust : 0 : 0 Muld 2. Taim võtab mullast valgust soojust vett toitu : 0 : 0

## Liikumine
URL: https://www.opiq.ee/kit/501/chapter/27396
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 5.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, liikumine, inimesed, liiguvad, katse, liigutab, kokkuvõte
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Liikumine; 1. Inimesed liiguvad; 2. Loomad liiguvad; 3. Taimed liiguvad; Katse; Ül; 4. Kes liigutab? Mis liigutab?; 5. Kokkuvõte
Task examples: Katse Taim pöörab lehti kiiresti aeglaselt : 0 : 0 Ül Taim pöörab lehed valguse poole.Lehed pöördusid päevaga. Salvesta; PILDIL ON ... Ülesanne 4 INIMENE TEGI (mis asjad?) … roomab vesi voolab veereb ujub : 0 : 0 Ülesanne 4 INIMENE TEGI (mis asjad?) … sõidab jookseb lendab lendab : 0 : 0 Ülesanne 4 INIMENE TEGI (mis asjad?) … roomab vesi v

## Elus- ja eluta loodus
URL: https://www.opiq.ee/kit/501/chapter/27397
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 5.6
Topics ET: loodusõpetus, loodus, keskkond, elus, eluta, kokkuvõte
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Elus- ja eluta loodus; 1. Loodus; 2. Elus-loodus; 3. Eluta loodus; 4. Elus- ja eluta loodus; ÜLESANNE 5 eluta; ÜLESANNE 5 elus; 5. Kokkuvõte; Ülesanne 8.1.1; Ülesanne 8.2
Task examples: ÜLESANNE 5 eluta ELUTA LOODUS ON ... LIBLIKAS PURAVIK PÄIKE LIIV : 0 : 0 ÜLESANNE 5 elus ELUS-LOODUS ON ... VESI KUKK ja KANAD ROOSID KIVID : 0 : 0 ÜLESANNE 5 eluta ELUTA LOODUS ON ... LIBLIKAS PURAVIK PÄIKE LIIV : 0 : 0; Ülesanne 8.1.1 SARNANE on ... neli jalga sööb porgandit pikad kõrvad kaks silma : 0 : 0 Ülesanne 8.1.1 SARNANE on ... neli jalga kaks silma pehme karv pikad kõrvad : 0 : 0 Ülesanne 8.1.1 SARNANE on ... pehme karv kaks si

## Kevad ja kevadkuud
URL: https://www.opiq.ee/kit/501/chapter/27398
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.1
Topics ET: loodusõpetus, loodus, keskkond, aastaajad, kevad, suvi, sügis, talv, kevadkuud, kevadel, tähtpäevad, kokkuvõte, tööleht
Topics RU: природоведение, природа, окружающая среда, времена года, весна, лето, осень, зима
Topics EN: science, nature, environment, seasons, spring, summer, autumn, winter
Headings: Kevad ja kevadkuud; 1. Aastaajad; ÜL 2; ÜL 1; 2. Kevad; 3. Loodus kevadel; 4. Kevadkuud; 5. Tähtpäevad kevadel; 6. Kokkuvõte; Tööleht
Task examples: ÜL 2 Aasta-aeg on KEVAD.TALV.SÜGIS. : 0 : 0 ÜL 1 Aasta-aeg on KEVAD.TALV.SÜGIS. : 0 : 0 ÜL 2 Aasta-aeg on KEVAD.TALV.SÜGIS. : 0 : 0 ÜL 1 Aasta-aeg on KEVAD.TALV.SÜGIS. : 0 : 0 12; Puu on lehes.Puu all kasvavad ​või-lilled. 3 : 0 : 0 See puu on kask. Kask on raagus.Puu all on veel lund. 1 : 0 : 0 Kase okste küljes on noored lehed.Puu all kasvavad ​paise-lehed. 2 : 0 : 0 Puu on lehes.Puu all kasvava

## Puud ja põõsad kevadel
URL: https://www.opiq.ee/kit/501/chapter/27399
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.2
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, puud, põõsad, kevadel, puude, lehed, pungad
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Puud ja põõsad kevadel; 1. Puude lehed (sügis, talv); 2. Pungad; 3. Lehed ja õied; 4. Urvad; Urvad; 5. Kokkuvõte
Task examples: PAJUKASK Urvad kase-urvad paju-urvad kase-urvad paju-urvad : 0 : 0; KUIDAS OKSAD MUUTUVAD? LOHISTA PILDID ÕIGESSE JÄRJEKORDA.

## Kevadlilled
URL: https://www.opiq.ee/kit/501/chapter/27400
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, kevadlilled, lilled, aias, lille, sibul, metsas, heina, maal
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Kevadlilled; 1. Lilled aias; 2. Lille-sibul; 3. Sibul-lilled; 4. Lilled metsas ja heina-maal; Lilled; 5. Taime osad on mürgised; Tööleht; 6. Või-lill, või-lilled; 7. Kokkuvõte
Task examples: ÜLESANNE tulplumi-kellukemärtsi-kellukenartsiss tulplumi-kellukemärtsi-kellukenartsiss : 0 : 0 ÜLESANNE tulplumi-kellukemärtsi-kellukenartsiss tulplumi-kellukemärtsi-kellukenartsiss : 0 : 0 ÜLESANNE tulplumi-kellukemärts; KUIDAS MUUTUB VÕI-LILL? JÄRJESTA PILDID. (LOHISTA.)

## Kevadtööd
URL: https://www.opiq.ee/kit/501/chapter/27401
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.4
Topics ET: loodusõpetus, kevadtööd, tööd, aias, inimesed, vahendid, pilt, tööleht, põllul
Topics RU: природоведение
Topics EN: science
Headings: Kevadtööd; 1. Tööd aias (inimesed, vahendid); Ül 3; Pilt 1; Ül 2; Tööleht; 2. Tööd aias; ÜLESANNE 1 (2); 3. Tööd põllul; 4. Kokkuvõte; Ül 1
Task examples: 1.PausEsita% puhverdatud00:0000:05Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio element.2.PausEsita% puhverdatud00; ÜLESANNE 1 (2) Lohista vastus siit sobivasse veergu istutab taimi toob vett kastab taimi : 0 : 0 ÜLESANNE 1 MARI MIKK ISA Lohista vastus siit sobivasse veergu lõikab oksi veab prahti riisub prahti lükkab käru : 0 : 0 ÜLE

## Loomad kevadel
URL: https://www.opiq.ee/kit/501/chapter/27402
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, kevadel, väikesed, roomavad, ärkavad, talve, unest
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Loomad kevadel; 1. Loomad; Väikesed loomad (putukad; roomavad); loomad; 2. Loomad ärkavad talve-unest; 3. Loomad vahetavad karva; 4. Loomadel sünnivad pojad; 5. Pojad kasvavad; 6. Kokkuvõte; ÜLESANNE 5 (1)
Task examples: *Klõpsa sõna esimesel tähel ja viimasel tähel.TIGU, MESILANE, VIHMAUSS, SIPELGAS Väikesed loomad (putukad; roomavad) {"data":[["ASIUMNEP"],["VIHMAUSS"],["OPERTUNT"],["MESILANE"],["RLARÜSDI"],["SGLEHMAD"],["KABTIGUR"],["U; ÜLESANNE 5 (1) Jänese kutsikadpojadtalled sünnivad aprillis.Mets-sea vasikadpõrsadtalled sünnivad aprillis.Põdra vasikastallkutsikas sünnib mais.Hundi talledvasikadkutsikad sünnivad aprillis. : 0 : 0 ÜLESANNE 5 (1) Orava

## Linnud kevadel
URL: https://www.opiq.ee/kit/501/chapter/27403
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, kevadel, rändlinnud, paigalinnud, ehitavad, pesa, lind, asukoht
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnud kevadel; 1. Rändlinnud, paigalinnud; 2. Linnud ehitavad pesa; 3. Lind ja pesa asukoht; 4. Linnud munevad; Varese muna; Toonekure muna; Kuldnoka muna; Pääsukese muna; 5. Munast kooruvad pojad; 6. Kokkuvõte; Munade järjestamine
Task examples: 1. Linnu pesa on kõrgel.; Varese muna : 0 : 0 PausEsita% puhverdatud00:0000:05Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio element.Varese m

## Suvi ja suvekuud
URL: https://www.opiq.ee/kit/501/chapter/27404
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.7
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, suvekuud, aasta, ajad, enne, suve, erinev, vikerkaar
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Suvi ja suvekuud; 1. Aasta-ajad enne suve; 2. Suvi; 3. Suvekuud; 4. Erinev ilm; 5. Vikerkaar; 5. Kokkuvõte; Aastaajad, kuud 2; Aastaajad, kuud 1
Task examples: 4 {"data":"<ol><li>Kombain <b>koristab vilja</b>.</li><li>Kombain koristab põllult vilja.</li></ol>"} Kombain koristab vilja. Kombain koristab põllult vilja. : 0 : 0 1 {"data":"<ol><li>Mees <b>sõidab rattaga</b>.</li><li; Aastaajad, kuud 2 KEVAD ja SUVI AUGUST APRILL MAI JUULI JUUNI MÄRTS : 0 : 0 Aastaajad, kuud 1 SÜGIS ja TALV NOVEMBER OKTOOBER SEPTEMBER JAANUAR VEEBRUAR DETSEMBER : 0 : 0 Aastaajad, kuud 2 KEVAD ja SUVI AUGUST APRILL MAI

## Aasta
URL: https://www.opiq.ee/kit/501/chapter/27405
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 6.8
Topics ET: loodusõpetus, kordamine, korda, harjutan, taim, taimed, puu, lill, loom, loomad, linnud, putukad, aastaajad, kevad, suvi, sügis, talv, aasta, aias, ring
Topics RU: природоведение, повторение, повтори, тренировка, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, времена года, весна, лето, осень, зима
Topics EN: science, revision, review, practice, plant, plants, tree, flower, animal, animals, birds, insects, seasons, spring, summer, autumn, winter
Headings: Aasta; 1. Suvi aias; AED; 2. Loomad ja taimed aias; Taimed; Putukad; Linnud; 3. Aasta-ring aias; ÜL 3 (4) kevad; ÜL 3 (1) suvi; ÜL 3 (2) sügis; ÜL 3 (3) talv; 4. Maasikad; Maasika joonis; 5. Mets-maasikad; Tööleht; 6. Kordamine; ÜL (2); ÜL (1); ÜLESANNE 8.2
Task examples: 1.PausEsita% puhverdatud00:0000:07Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser does not support the audio element.2.PausEsita% puhverdatud00; Taimed TAIMED on … {"data":"<p>mulla-hunnik, õuna-puu, maasikas, põõsas</p>"} mulla-hunnik, õuna-puu, maasikas, põõsas : 0 : 0 Putukad PUTUKAD on … {"data":"<p>liblikas, vihma-uss, sipelgas, konn, mesilane</p>"} liblikas

## Metoodiline juhendmaterjal õpetajale
URL: https://www.opiq.ee/kit/501/chapter/27406
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 7.1
Topics ET: loodusõpetus, metoodiline, juhendmaterjal, õpetajale
Topics RU: природоведение
Topics EN: science
Headings: Metoodiline juhendmaterjal õpetajale; ...

## Impressum
URL: https://www.opiq.ee/kit/501/chapter/27407
Book: Loodusõpetus 2. klassile. Lihtsustatud õppekava 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: ministeerium
Book ID: ministeerium_loodusõpet_2_et
Chapter ID: 7.2
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Loodusõpetuse tööraamat 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/387
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 330
Topics ET: loodusõpetus, loodusõpetuse, tööraamat, klassile, opiq
Topics RU: природоведение
Topics EN: science

## Loodusõpetuse tööraamat 2. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/387
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 359
Topics ET: loodusõpetus, loodusõpetuse, tööraamat, klassile, opiq
Topics RU: природоведение
Topics EN: science

## Looduse teaduslik uurimine
URL: https://www.opiq.ee/kit/387/chapter/20880
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.1
Topics ET: loodusõpetus, looduse, teaduslik, uurimine, vaatluspäevik, puukoristaja, vaatlus, täiendav, toitumine
Topics RU: природоведение
Topics EN: science
Headings: Looduse teaduslik uurimine; Vaatluspäevik; Puukoristaja vaatlus; Täiendav uurimine; Puukoristaja toitumine

## Taimede vajadused
URL: https://www.opiq.ee/kit/387/chapter/20889
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.10
Topics ET: loodusõpetus, taimede, vajadused
Topics RU: природоведение
Topics EN: science
Headings: Taimede vajadused

## Loomade vajadused. Toit ja õhk
URL: https://www.opiq.ee/kit/387/chapter/20890
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.11
Topics ET: loodusõpetus, loomade, vajadused, toit, toiduahel, rästiku, tihased, rasvatihane, toidab, poegi
Topics RU: природоведение
Topics EN: science
Headings: Loomade vajadused. Toit ja õhk; Loomade vajadused; Toiduahel; Rästiku toit; Tihased; Rasvatihane toidab poegi

## Loomade vajadused. Vesi ja ruum
URL: https://www.opiq.ee/kit/387/chapter/20891
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.12
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, loomade, vajadused, ruum
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Loomade vajadused. Vesi ja ruum; Vesi; Ruum

## Inimese toit
URL: https://www.opiq.ee/kit/387/chapter/20892
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.13
Topics ET: loodusõpetus, inimese, toit, tervislik, lõunasöök
Topics RU: природоведение
Topics EN: science
Headings: Inimese toit; 2. Tervislik lõunasöök

## Uurime pakendeid
URL: https://www.opiq.ee/kit/387/chapter/20893
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.14
Topics ET: loodusõpetus, uurime, pakendeid, millest, toit, koosneb, leiva, pakend, energia, toidus
Topics RU: природоведение
Topics EN: science
Headings: Uurime pakendeid; Millest toit koosneb; Leiva pakend; Energia toidus

## Inimesed on erinevad
URL: https://www.opiq.ee/kit/387/chapter/20881
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.2
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, inimesed, erinevad, sarnased, enda, välimust, pinginaabri, välimusega, klassi
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Inimesed on erinevad; Inimesed on sarnased; Võrdle enda välimust pinginaabri välimusega.; Minu klassi inimesed; Võrrelge oma klassi õpilaste pikkust; Juuste värv; Sugulased on sarnased; Küsitle viit õpilast, kellel on sama värvi juuksed.

## Talveks valmistumine. Viljad ja seemned
URL: https://www.opiq.ee/kit/387/chapter/20882
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.3
Topics ET: loodusõpetus, talveks, valmistumine, viljad, seemned, marjad, tammetõrud, pasknäär, peidab, tammetõrusid
Topics RU: природоведение
Topics EN: science
Headings: Talveks valmistumine. Viljad ja seemned; Viljad ja seemned; Marjad; Tammetõrud; Pasknäär peidab tammetõrusid

## Talveks valmistumine. Varuainetega juured
URL: https://www.opiq.ee/kit/387/chapter/20883
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, talveks, valmistumine, varuainetega, juured, porgand, mügri, vesirott, arutelu, millised
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Talveks valmistumine. Varuainetega juured; Porgand; Mügri ehk vesirott; Arutelu; 1. Millised porgandit sisaldavad toidud sulle maitsevad?; 2. Miks on porgandil vaja esimesel suvel juure sisse toitaineid koguda?; 3. Aruta pinginaabriga, miks kogub porgand talvevaru just juure, mitte näiteks varre või lehtede sisse.; 4. Kirjuta tabelisse, millised loomad saavad oma toidu porganditaime erinevaid osi süües.; 5. Kuidas on õitel toituvad putukad porganditaimele kasulikud?

## Talveks valmistumine. Mugulad
URL: https://www.opiq.ee/kit/387/chapter/20884
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.5
Topics ET: loodusõpetus, talveks, valmistumine, mugulad, kartulimugula, uurimine, vaatle, kartulimugulat, milline, värv
Topics RU: природоведение
Topics EN: science
Headings: Talveks valmistumine. Mugulad; Mugulad; Kartulimugula uurimine; Vaatle kartulimugulat; Milline värv tekkis?; Järeldus

## Talveks valmistumine. Loomad
URL: https://www.opiq.ee/kit/387/chapter/20885
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, talveks, valmistumine, pungad, urvad, arutelu, kodulindudest, kontrolli, arvamust
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Talveks valmistumine. Loomad; Loomad; Pungad ja urvad; Arutelu kodulindudest; Kontrolli oma arvamust; Talveks valmis; Ränne või talveuni

## Köögiviljad
URL: https://www.opiq.ee/kit/387/chapter/20886
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.7
Topics ET: loodusõpetus, köögiviljad, sibul, porgand, lehtsalat, lillkapsas, peet, põlduba, tomat, hernes
Topics RU: природоведение
Topics EN: science
Headings: Köögiviljad; Sibul; Porgand; Lehtsalat; Lillkapsas; Peet; Põlduba; Tomat; Hernes; Varsseller; Kurk; Rabarber; Kõrvits; Lemmikud köögiviljade seas; 1. Köögiviljad, mis minu meelest meeldivad klassile kõige enam; 2. Köögiviljad, mis maitsevad klassi õpilastele kõige rohkem; 3. Lõuna toit

## Köögiviljade aretamine
URL: https://www.opiq.ee/kit/387/chapter/20887
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.8
Topics ET: loodusõpetus, köögiviljade, aretamine, kapsa, sordid, kähar, lehtkapsas
Topics RU: природоведение
Topics EN: science
Headings: Köögiviljade aretamine; 1. Kapsa sordid; 2. Kähar lehtkapsas

## Loomade aretamine
URL: https://www.opiq.ee/kit/387/chapter/20888
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 1.9
Topics ET: loodusõpetus, loomade, aretamine, milline, koeratõug, sulle, kõige, rohkem, meeldib
Topics RU: природоведение
Topics EN: science
Headings: Loomade aretamine; Milline koeratõug sulle kõige rohkem meeldib?

## Inimene ja loodus. Inimese vajadused
URL: https://www.opiq.ee/kit/387/chapter/20894
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.1
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, inimese, vajadused, kümme, asja
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Inimene ja loodus. Inimese vajadused; Inimese vajadused; Kümme asja

## Lemmikloomad
URL: https://www.opiq.ee/kit/387/chapter/20903
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.10
Topics ET: loodusõpetus, lemmikloomad, kümmekond, aastat, koera, jalutamine, järelt, koristamine, loomade, vajadused
Topics RU: природоведение
Topics EN: science
Headings: Lemmikloomad; 1. Kümmekond aastat; 2. Koera jalutamine; 3. Koera järelt koristamine; 4. Loomade vajadused

## Erinevad elupaigad. Tiik ja järv
URL: https://www.opiq.ee/kit/387/chapter/20904
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.11
Topics ET: loodusõpetus, erinevad, elupaigad, tiik, järv, loomaliigid, järves, tiigis, toiduahel
Topics RU: природоведение
Topics EN: science
Headings: Erinevad elupaigad. Tiik ja järv; Tiik ja järv; 1. Loomaliigid järves ja tiigis; 2. Toiduahel

## Erinevad elupaigad. Kallas
URL: https://www.opiq.ee/kit/387/chapter/20905
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.12
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, erinevad, elupaigad, kallas, kelle, järglased, arenevad, vees, teeb
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Erinevad elupaigad. Kallas; Kallas; 1. Loomad, kelle järglased arenevad vees; 2. Kes teeb tiike?; 3. Taimed veekogude kallastel

## Erinevad elupaigad. Raba ja niit
URL: https://www.opiq.ee/kit/387/chapter/20906
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.13
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, erinevad, elupaigad, raba, niit, niitu, sarnasused
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Erinevad elupaigad. Raba ja niit; Raba ja niit; 1. Võrdle niitu ja raba; 2. Sarnasused

## Kasvamine
URL: https://www.opiq.ee/kit/387/chapter/20907
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.14
Topics ET: loodusõpetus, kasvamine, kasvamise, tabel, uued, oskused, huvitavad, asjad
Topics RU: природоведение
Topics EN: science
Headings: Kasvamine; 1. Kasvamise tabel; 2. Uued oskused; 3. Huvitavad asjad

## Inimene ja loodus. Mida saame loodusest. Esemed
URL: https://www.opiq.ee/kit/387/chapter/20895
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, mida, saame, loodusest, esemed, miks, kannab, riideid
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Inimene ja loodus. Mida saame loodusest. Esemed; Esemed; 1. Miks inimene kannab riideid?; Küte ja elekter; 2. Kodu kütmine; 3. Kooli kütmine; 4. Elektri tootmine

## Inimene ja loodus. Mida saame loodusest. Õhk
URL: https://www.opiq.ee/kit/387/chapter/20896
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.3
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, mida, saame, loodusest, mudeli, valmistamine, peab, olema
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Inimene ja loodus. Mida saame loodusest. Õhk; Õhk; Mudeli valmistamine; Õhk peab olema puhas; 1. Toa õhk; 2. Tähed sassis

## Inimene ja loodus. Mida saame loodusest. Vesi
URL: https://www.opiq.ee/kit/387/chapter/20897
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.4
Topics ET: loodusõpetus, loodus, keskkond, vesi, veeohutus, veekogu, inimene, keha, meeled, tervis, mida, saame, loodusest, looduses, joogivesi, puhastamise
Topics RU: природоведение, природа, окружающая среда, вода, безопасность на воде, водоём, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, water, water safety, body of water, human, body, senses, health
Headings: Inimene ja loodus. Mida saame loodusest. Vesi; Vesi looduses; Joogivesi; Vee puhastamise katse; Vee ringlus

## Turvalisus looduses. Loodusjõud. Loomad
URL: https://www.opiq.ee/kit/387/chapter/20898
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, turvalisus, looduses, loodusjõud, ohtudest, hoidumine, põder, rästik
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Turvalisus looduses. Loodusjõud. Loomad; Loodusjõud; 1. Ohtudest hoidumine; Loomad; 2. Põder; 3. Rästik

## Turvalisus. Mikroobid ja viirused
URL: https://www.opiq.ee/kit/387/chapter/20899
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.6
Topics ET: loodusõpetus, turvalisus, mikroobid, viirused, näited, ohtudest, looduses, pesemine, aitab, tohib
Topics RU: природоведение
Topics EN: science
Headings: Turvalisus. Mikroobid ja viirused; Mikroobid ja viirused; 1. Näited ohtudest looduses; 2. Pesemine aitab; 3. Tohib või ei tohi süüa

## Kasulikud mikroobid
URL: https://www.opiq.ee/kit/387/chapter/20900
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.7
Topics ET: loodusõpetus, kasulikud, mikroobid, oleta, kummas, purgis, läheb, piim, varem, hapuks
Topics RU: природоведение
Topics EN: science
Headings: Kasulikud mikroobid; Oleta kummas purgis läheb piim varem hapuks; Järeldus

## Teraviljad
URL: https://www.opiq.ee/kit/387/chapter/20901
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.8
Topics ET: loodusõpetus, teraviljad, toidud, teraviljadest, maailmas, rukis, nisu
Topics RU: природоведение
Topics EN: science
Headings: Teraviljad; 1. Toidud teraviljadest; 2. Teraviljad maailmas; 3. Rukis või nisu?

## Koduloomad
URL: https://www.opiq.ee/kit/387/chapter/20902
Book: Loodusõpetuse tööraamat 2. klassile 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Skriibus
Book ID: skriibus_loodusõpet_2_et
Chapter ID: 2.9
Topics ET: loodusõpetus, koduloomad, olen, näinud, uuri, klassis, veel, koduloomi, koduloomade, pidamine
Topics RU: природоведение
Topics EN: science
Headings: Koduloomad; 1. Olen ise näinud; 2. Kus olen näinud; 3. Uuri oma klassis; 4. Veel koduloomi; 5. Koduloomade pidamine; 6. Lüngad tekstis

## Loodusõpetuse õppevideod 1. kooliastmele – Opiq
URL: https://www.opiq.ee/Kit/Details/384
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 126
Topics ET: loodusõpetus, loodusõpetuse, õppevideod, kooliastmele, opiq
Topics RU: природоведение
Topics EN: science

## Loodusõpetuse õppevideod 1. kooliastmele – Opiq
URL: https://www.opiq.ee/Kit/Details/384
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 168
Topics ET: loodusõpetus, loodusõpetuse, õppevideod, kooliastmele, opiq
Topics RU: природоведение
Topics EN: science

## Sissejuhatus
URL: https://www.opiq.ee/kit/384/chapter/20741
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 1.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Kuidas me värve näeme?
URL: https://www.opiq.ee/kit/384/chapter/20737
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 1.2
Topics ET: loodusõpetus, kuidas, värve, näeme, video, värvid, vastandvärvid, katse, eesti, lipp
Topics RU: природоведение
Topics EN: science
Headings: Kuidas me värve näeme?; Video; Värvid ja vastandvärvid; Katse. Eesti lipp; Katse

## Kuidas me maitset tunneme?
URL: https://www.opiq.ee/kit/384/chapter/20738
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 1.3
Topics ET: loodusõpetus, kuidas, maitset, tunneme, video, maitsed, maitsmiskatse, katse
Topics RU: природоведение
Topics EN: science
Headings: Kuidas me maitset tunneme?; Video; Maitsed; Maitsmiskatse; Katse

## Miks on võimalik tunda maitset nina kaudu?
URL: https://www.opiq.ee/kit/384/chapter/20739
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 1.4
Topics ET: loodusõpetus, miks, võimalik, tunda, maitset, nina, kaudu, video, maitse, tundmine
Topics RU: природоведение
Topics EN: science
Headings: Miks on võimalik tunda maitset nina kaudu?; Video; Maitse tundmine; Maitsmiskatse; Katse

## Kui kõrgeid ja madalaid helisid kuuleb inimene?
URL: https://www.opiq.ee/kit/384/chapter/20740
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 1.5
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, kõrgeid, madalaid, helisid, kuuleb, video, kuulmine, kuulmiskatse, katse
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Kui kõrgeid ja madalaid helisid kuuleb inimene?; Video; Kuulmine; Kuulmiskatse; Katse

## Kuidas taim teab, missuguseks ta kasvama peab?
URL: https://www.opiq.ee/kit/384/chapter/20742
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, kuidas, teab, missuguseks, kasvama, peab, video, pärilikkus, katse
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Kuidas taim teab, missuguseks ta kasvama peab?; Video; Pärilikkus; Katse. Banaani DNA; Tööleht

## Miks vajavad taimed valgust?
URL: https://www.opiq.ee/kit/384/chapter/20751
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.10
Topics ET: loodusõpetus, taim, taimed, puu, lill, miks, vajavad, valgust, video, katse, pimedas, valguse
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Miks vajavad taimed valgust?; Video; Katse. Taim pimedas ja valguse käes; Tööleht

## Kuidas jõuab vesi taimes õiteni?
URL: https://www.opiq.ee/kit/384/chapter/20752
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.11
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, kuidas, jõuab, taimes, õiteni, video, liikumine, katse, tööleht
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Kuidas jõuab vesi taimes õiteni?; Video; Vee liikumine taimes; Tee katse; Tööleht

## Kuidas veetaimed vee peal püsivad?
URL: https://www.opiq.ee/kit/384/chapter/20743
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.2
Topics ET: loodusõpetus, kuidas, veetaimed, peal, püsivad, video, ujuvus, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas veetaimed vee peal püsivad?; Video; Ujuvus; Katse. Ujuvus; Tööleht

## Kuidas kalad vees kõrgust muudavad?
URL: https://www.opiq.ee/kit/384/chapter/20744
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.3
Topics ET: loodusõpetus, kuidas, kalad, vees, kõrgust, muudavad, video, kõrguse, muutmine, katse
Topics RU: природоведение
Topics EN: science
Headings: Kuidas kalad vees kõrgust muudavad?; Video; Kõrguse muutmine vees; Katse. Ujupõis; Tööleht

## Mida söövad linnud ja kuidas neid vaadelda?
URL: https://www.opiq.ee/kit/384/chapter/20745
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, mida, söövad, kuidas, neid, vaadelda, video, linnusöök, katse
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Mida söövad linnud ja kuidas neid vaadelda?; Video; Linnusöök; Katse. Rasvapall; Tööleht

## Milleks on kassidel vurrud?
URL: https://www.opiq.ee/kit/384/chapter/20746
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.5
Topics ET: loodusõpetus, milleks, kassidel, vurrud, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Milleks on kassidel vurrud?; Video; Vurrud; Katse. Vurrud; Tööleht

## Miks tuleb käsi pesta?
URL: https://www.opiq.ee/kit/384/chapter/20747
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.6
Topics ET: loodusõpetus, miks, tuleb, käsi, pesta, video, hallitusseened, katse, hallitus, saial
Topics RU: природоведение
Topics EN: science
Headings: Miks tuleb käsi pesta?; Video; Hallitusseened; Katse. Hallitus saial; Tööleht

## Mis on samblik?
URL: https://www.opiq.ee/kit/384/chapter/20748
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.7
Topics ET: loodusõpetus, samblik, video, samblikud, katse, lõnga, värvimine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on samblik?; Video; Samblikud; Katse. Lõnga värvimine; Tööleht

## Mis on toiduahel ja vihmaussi roll selles?
URL: https://www.opiq.ee/kit/384/chapter/20749
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.8
Topics ET: loodusõpetus, toiduahel, vihmaussi, roll, selles, video, vihmauss, kodu, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on toiduahel ja vihmaussi roll selles?; Video; Toiduahel ja vihmauss; Vihmaussi kodu; Tööleht

## Kuidas on loomad kohanenud eluks talvel ja suvel?
URL: https://www.opiq.ee/kit/384/chapter/20750
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 2.9
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, kuidas, kohanenud, eluks, talvel, suvel, video, suvine, talvine
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Kuidas on loomad kohanenud eluks talvel ja suvel?; Video; Loomad suvel ja talvel; Suvine ja talvine mets; Tööleht

## Kuidas suured asjad väikesele paberile mahuvad?
URL: https://www.opiq.ee/kit/384/chapter/20753
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.1
Topics ET: loodusõpetus, kuidas, suured, asjad, väikesele, paberile, mahuvad, video, paberil, katse
Topics RU: природоведение
Topics EN: science
Headings: Kuidas suured asjad väikesele paberile mahuvad?; Video; Asjad paberil; Katse. Joonestamine; Tööleht

## Kuidas võrrelda raskust?
URL: https://www.opiq.ee/kit/384/chapter/20754
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.2
Topics ET: loodusõpetus, kuidas, võrrelda, raskust, video, kaalumine, kangkaal, ämbritega, koolikoti, kaal
Topics RU: природоведение
Topics EN: science
Headings: Kuidas võrrelda raskust?; Video; Kaalumine; Kangkaal ämbritega. Koolikoti kaal; Tööleht

## Kui pikk on sinu sõber?
URL: https://www.opiq.ee/kit/384/chapter/20755
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.3
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, pikk, sinu, sõber, video, pikkuse, katse, tööleht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Kui pikk on sinu sõber?; Video; Pikkuse mõõtmine; Katse. Mõõtmine; Tööleht

## Miks on seebimullid tugevamad kui veemullid?
URL: https://www.opiq.ee/kit/384/chapter/20756
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.4
Topics ET: loodusõpetus, miks, seebimullid, tugevamad, veemullid, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Miks on seebimullid tugevamad kui veemullid?; Video; Katse. Seebimullid; Tööleht

## Kuidas võrrelda krõpsude rasvasust?
URL: https://www.opiq.ee/kit/384/chapter/20757
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.5
Topics ET: loodusõpetus, kuidas, võrrelda, krõpsude, rasvasust, video, rasvasisaldus, katse, rasvasus, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas võrrelda krõpsude rasvasust?; Video; Rasvasisaldus; Katse. Krõpsude rasvasus; Tööleht

## Kuidas ronida kodust lahkumata Suure Munamäe otsa?
URL: https://www.opiq.ee/kit/384/chapter/20758
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.6
Topics ET: loodusõpetus, kuidas, ronida, kodust, lahkumata, suure, munamäe, otsa, video, kõrgus
Topics RU: природоведение
Topics EN: science
Headings: Kuidas ronida kodust lahkumata Suure Munamäe otsa?; Video; Kõrgus; Katse. Mäkketõus trepil; Tööleht

## Ujub või upub?
URL: https://www.opiq.ee/kit/384/chapter/20759
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.7
Topics ET: loodusõpetus, ujub, upub, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Ujub või upub?; Video; Katse. Ujub või upub?; Tööleht

## Mis on kiirus?
URL: https://www.opiq.ee/kit/384/chapter/20760
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 3.8
Topics ET: loodusõpetus, kiirus, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on kiirus?; Video; Kiirus; Katse. Kiirus; Tööleht

## Kuidas töötab lüliti?
URL: https://www.opiq.ee/kit/384/chapter/20761
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 4.1
Topics ET: loodusõpetus, kuidas, töötab, lüliti, video, katse, vooluring, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas töötab lüliti?; Video; Lüliti; Katse. Vooluring; Tööleht

## Miks ei tohi panna näppe pistikupessa?
URL: https://www.opiq.ee/kit/384/chapter/20762
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 4.2
Topics ET: loodusõpetus, miks, tohi, panna, näppe, pistikupessa, video, pistik, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Miks ei tohi panna näppe pistikupessa?; Video; Pistik; Tööleht

## Mis on elektrijuhid?
URL: https://www.opiq.ee/kit/384/chapter/20763
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 4.3
Topics ET: loodusõpetus, elektrijuhid, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on elektrijuhid?; Video; Elektrijuhid; Katse. Elektrijuhid; Tööleht

## Kuidas töötavad patareid?
URL: https://www.opiq.ee/kit/384/chapter/20764
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 4.4
Topics ET: loodusõpetus, kuidas, töötavad, patareid, video, patarei, katse, patareivahetus, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas töötavad patareid?; Video; Patarei; Katse. Patareivahetus; Tööleht

## Kuidas kaitsta arvutit särtsu eest?
URL: https://www.opiq.ee/kit/384/chapter/20765
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 4.5
Topics ET: loodusõpetus, kuidas, kaitsta, arvutit, särtsu, eest, video, särts, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas kaitsta arvutit särtsu eest?; Video; Särts; Katse. Särts; Tööleht

## Kas viinamari on magnetiline?
URL: https://www.opiq.ee/kit/384/chapter/20766
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 4.6
Topics ET: loodusõpetus, viinamari, magnetiline, video, magnetilisus, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kas viinamari on magnetiline?; Video; Magnetilisus; Katse; Tööleht

## Mis on kompass?
URL: https://www.opiq.ee/kit/384/chapter/20767
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 4.7
Topics ET: loodusõpetus, kompass, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on kompass?; Video; Kompass; Katse. Kompass; Tööleht

## Kuidas liigub päike?
URL: https://www.opiq.ee/kit/384/chapter/20768
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 5.1
Topics ET: loodusõpetus, kuidas, liigub, päike, video, katse, päikesekell, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas liigub päike?; Video; Katse. Päikesekell; Tööleht

## Kustpoolt puhub tuul?
URL: https://www.opiq.ee/kit/384/chapter/20769
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 5.2
Topics ET: loodusõpetus, kustpoolt, puhub, tuul, video, katse, tuuleratas, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kustpoolt puhub tuul?; Video; Tuul; Katse. Tuuleratas; Tööleht

## Kuidas teha pilve?
URL: https://www.opiq.ee/kit/384/chapter/20770
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 5.3
Topics ET: loodusõpetus, kuidas, teha, pilve, video, pilved, katse, tegemine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas teha pilve?; Video; Pilved; Katse. Pilve tegemine; Tööleht

## Kuidas tekivad tornaadod?
URL: https://www.opiq.ee/kit/384/chapter/20771
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 5.4
Topics ET: loodusõpetus, kuidas, tekivad, tornaadod, video, tornaado, katse, toraando, pudelis, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas tekivad tornaadod?; Video; Tornaado; Katse. Toraando pudelis; Tööleht

## Kuidas muuta vedelikku tahkeks?
URL: https://www.opiq.ee/kit/384/chapter/20772
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 6.1
Topics ET: loodusõpetus, kuidas, muuta, vedelikku, tahkeks, video, vedel, tahke, katse, piima
Topics RU: природоведение
Topics EN: science
Headings: Kuidas muuta vedelikku tahkeks?; Video; Vedel ja tahke; Katse. Piima tahkeks muutmine; Tööleht

## Kuidas vett klaasi sisse püüda?
URL: https://www.opiq.ee/kit/384/chapter/20773
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 6.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, kuidas, vett, klaasi, sisse, püüda, video, katse, jääb
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Kuidas vett klaasi sisse püüda?; Video; Vesi; Katse. Vesi jääb klaasi; Tööleht

## Kuidas teha varjuteatrit?
URL: https://www.opiq.ee/kit/384/chapter/20774
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 6.3
Topics ET: loodusõpetus, kuidas, teha, varjuteatrit, video, valgus, vari, katse, varjuteater, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas teha varjuteatrit?; Video; Valgus ja vari; Katse. Varjuteater; Tööleht

## Kuidas töötab helkur?
URL: https://www.opiq.ee/kit/384/chapter/20775
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 6.4
Topics ET: loodusõpetus, kuidas, töötab, helkur, video, katse, helkuri, tegemine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas töötab helkur?; Video; Helkur; Katse. Helkuri tegemine; Tööleht

## Miks on oluline kiivrit kanda?
URL: https://www.opiq.ee/kit/384/chapter/20776
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 6.5
Topics ET: loodusõpetus, miks, oluline, kiivrit, kanda, video, kiiver, katse, muna, kaitsmine
Topics RU: природоведение
Topics EN: science
Headings: Miks on oluline kiivrit kanda?; Video; Kiiver; Katse. Muna kaitsmine kukkumisel; Tööleht

## Milline on Eesti kaart?
URL: https://www.opiq.ee/kit/384/chapter/20777
Book: Loodusõpetuse õppevideod 1. kooliastmele 2 klass
Class: 2
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Star Cloud
Book ID: star cloud_loodusõpet_2_et
Chapter ID: 6.6
Topics ET: loodusõpetus, milline, eesti, kaart, video, katse, kaardi, joonistamine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Milline on Eesti kaart?; Video; Eesti kaart; Katse. Eesti kaardi joonistamine; Tööleht
