## Inimeseõpetus 1. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/285
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1
Topics ET: matemaatika, inimeseõpetus, klassile, lihtsustatud, õppekava, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus 1. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/285
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 39
Topics ET: matemaatika, inimeseõpetus, klassile, lihtsustatud, õppekava, opiq
Topics RU: математика
Topics EN: mathematics

## Minu kool
URL: https://www.opiq.ee/kit/285/chapter/15939
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.1
Topics ET: matemaatika, kool, mari, siim, õpivad, esimeses, klassis, kooli, lapsed
Topics RU: математика
Topics EN: mathematics
Headings: Minu kool; 1. MARI JA SIIM; MARI JA SIIM ÕPIVAD ESIMESES KLASSIS.; 2. KOOLI-LAPSED; Kelle kooliasjad?; KOOLI-ASJAD; 3. KOOLI-KOTT; Koolikott; Tööleht; TÖÖLEHT: MINU KOOL
Task examples: Kelle kooliasjad? : 0 : 0 Kelle kooliasjad? : 0 : 0 Kelle kooliasjad? : 0 : 0 Kelle kooliasjad? : 0 : 0 12 Vaata pilte. Kes on pildil?Vaata väikseid pilte. Mis on pildil?Mis asjad kuuluvad Marile? Märgi.Mis asjad kuuluva; 1. Mis on pildil? Nimeta.2. Mida lapsel läheb koolis vaja? Vajuta pildile. KOOLI-ASJAD : 0 : 0 3. Ütle laused: 1. KOOLI-ASJAD ON _____2. ____ ON KOOLI-ASJAD. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata

## Mina
URL: https://www.opiq.ee/kit/285/chapter/15940
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.2
Topics ET: matemaatika, mina, nimi, poiss, tüdruk, vanus, mari, toredad, tegevused
Topics RU: математика
Topics EN: mathematics
Headings: Mina; 1. NIMI; Nimi; poiss või tüdruk?; ....; 2. VANUS; Vanus; Mari ja ema; 3. TOREDAD TEGEVUSED; Mulle meeldib; 4. MULLE MEELDIB; Tööleht; Tööleht: Mina I
Task examples: Vaata pilte:​Kes on 1. pildil? Kes on 2. pildil?Kumb sina oled: poiss või tüdruk? Vajuta sobivale pildile. PausEsita% puhverdatud00:0000:01Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×; Mõnikord on inimestel ühesugune nimi. Mõnikord on loomadel ühesugune nimi. Vaata pilte. Kes on pildil?Kellel võib olla ühesugune nimi? Ühenda paarid. PausEsita% puhverdatud00:0000:11Eemalda vaigistusVaigistaSeadedKiirusT

## Minu välimus
URL: https://www.opiq.ee/kit/285/chapter/15941
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.3
Topics ET: matemaatika, inimene, keha, meeled, tervis, välimus, mari, peegel, kätte, jalga, ühenda, paarid, puhas
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Minu välimus; 1. MARI; 2. PEEGEL; Kätte ja jalga; Ühenda paarid; 3. PUHAS LAPS; Keha eest hoolitsemine; Tööleht; Tööleht: Minu välimus
Task examples: Vaata suurt pilti. Kes on pildil?Vaata väikseid pilte. Mis kehaosa on pildil? Nimeta.Leia suurelt pildilt sama koht. Näita.Näita enda kehal sama koht. Nimeta. JALG JUUKSEDKAELKÄSINÄGU KEHA JALG JUUKSED 123456 Lisa oma ma; Kätte ja jalga : 0 : 0 Vaata pilte. Mis on pildil? Mida paned kätte? Mida jalga? jneÜhenda paarid. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik

## Tere!
URL: https://www.opiq.ee/kit/285/chapter/15942
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.4
Topics ET: matemaatika, tere, siim, jõuab, klassi, keda, suurel, pildil, näoilmed
Topics RU: математика
Topics EN: mathematics
Headings: Tere!; 1. SIIM; 2. TERE; 3. SIIM JÕUAB KLASSI; Keda ei ole suurel pildil?; näoilmed; 4. SIIM LÄHEB KOJU; Tööleht; Tööleht: Tere!
Task examples: Vaata pilte. Näita: rõõmus nägu, kurb nägu. Siim ütles kõigile: "Tere!". Teised lapsed olid rõõmsad.Leia rõõmus nägu. Vajuta pildile. näoilmed : 0 : 0 Tööleht. Värvi sobiv pilt. Soovitused tegevusteks:Rütmisalm või laul 

## Koolis
URL: https://www.opiq.ee/kit/285/chapter/16785
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.5
Topics ET: matemaatika, koolis, tunniplaan, tunnid, eesti, keel, keele, tunnis, kunstiõpetus
Topics RU: математика
Topics EN: mathematics
Headings: Koolis; 1. TUNNIPLAAN; tunniplaan; 2. TUNNID KOOLIS; tunniplaan II; 4. EESTI KEEL; eesti keele tunnis; 5. KUNSTIÕPETUS; mida kunstiõpetuses vaja on?; 6. TÖÖÕPETUS; tööõpetus; Tööleht; Tööleht: Koolis I
Task examples: Mida teeb laps pildil? Näita ja nimeta.Esimene tund on lastel eesti keel. Mida teed sina eesti keele tunnis? Vajuta sobivatele piltidele. koolis Salvesta tunniplaan Salvesta Lisa oma materjali Tekstiabi Muud tegevused Ko; Mida teevad lapsed tööõpetuse tunnis? Vaata pilte. Nimeta.Vaata väikseid pilte. Mis on pildil? Näita ja nimeta.Vajuta sobivatele piltidele. tööõpetus Salvesta tööõpetus : 0 : 0 tööõpetus : 0 : 0 tööõpetus Salvesta tööõpe

## Tüli
URL: https://www.opiq.ee/kit/285/chapter/16786
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.6
Topics ET: matemaatika, tüli, kunsti, tunnis, sass, joonistavad, sarnasused, liblikas, roosi
Topics RU: математика
Topics EN: mathematics
Headings: Tüli; 1. TÜLI KUNSTI-TUNNIS; 2. SASS JA LEE JOONISTAVAD; sarnasused; 3. LIBLIKAS; 4. ROOSI JA LILLI; näoilmed; õige käitumine; Tööleht; Tööleht: Tüli
Task examples: Leia sarnane. Ühenda paarid. sarnasused : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õppek; Vaata pilte. Mis nägu on pildil? (Rõõmus, kurb, pahane, üllatunud).Kuidas Lilli end tundis? Vajuta sobivatele piltidele. näoilmed Salvesta Soovitused tegevusteks:Arutelu teemal „Kuidas Lilli edasi käitub?“Dialoogi harjut

## Sport
URL: https://www.opiq.ee/kit/285/chapter/16787
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.7
Topics ET: matemaatika, sport, võimla, kehaline, kasvatus, kehalise, tunnis, spordi, vahendid
Topics RU: математика
Topics EN: mathematics
Headings: Sport; 1. VÕIMLA; kehaline kasvatus; kehalise tunnis; 2. SPORDI-VAHENDID; 3. PALLI-MÄNG; 4. RIIETUS-RUUM; Leia ühesugused pallid.; Tööleht; Tööleht: Mina ja sport
Task examples: Mis on pildil? Näita ja nimeta.Roosi paneb kodus kooliasju valmis. Homme on kehalise kasvatuse tund. Kehalise kasvatuse tunnis on vaja spordiriideid. Vajuta piltidele, kus on spordiriided. PausEsita% puhverdatud00:0000:0; Mida teeb laps pildil? Näita ja nimeta. 123456 Mida sina kehalise tunnis teed? Vajuta piltidele. kehalise tunnis Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riikli

## Kooliriided
URL: https://www.opiq.ee/kit/285/chapter/16788
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 1.8
Topics ET: matemaatika, kooliriided, kooli, riided, kuidas, mustaks, said, saavad, puhtaks
Topics RU: математика
Topics EN: mathematics
Headings: Kooliriided; 1. KOOLI-RIIDED; 2. KUIDAS RIIDED MUSTAKS SAID?; 3. RIIDED SAAVAD PUHTAKS; vahetusjalatsid; Tööleht; Tööleht: Kooliriided
Task examples: Mis on väikestel piltidel? Näita ja nimeta.Lapsed panevad õhtul oma kooliriided valmis. Millised riided kooli sobivad?Vali lapsele sobivad kooliriided. VAATA! MIS RIIDED LAPSED KOOLI VALISID? Kooliriided Salvesta Kooliri; Vaata pilte. Millised riided sobivad kooli? Vajuta pildile. kooliriided : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhi

## Koolitee
URL: https://www.opiq.ee/kit/285/chapter/16823
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 2.1
Topics ET: matemaatika, koolitee, turvaline, kooli, kodu, sebra, liiklus, linnas, valgus
Topics RU: математика
Topics EN: mathematics
Headings: Koolitee; 1. TURVALINE KOOLI-TEE; Turvaline kodu-tee; 2. SEBRA; 3. LIIKLUS LINNAS; 4. VALGUS-FOOR; Mis värvi tulega tohid üle tee minna?; Leia pilt, millel põleb roheline tuli.; 5. SASS LÄHEB KOOLI.; Vali sobilik käitumisviis (3); Vali sobiv käitumisviis (1); Vali sobiv käitumisviis (2); Tööleht; Tööleht: Koolitee
Task examples: Turvaline kodu-tee : 0 : 0 Vaata pilte. Mis on pildil? Nimeta.Ühenda sobivad pildid. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023

## Ratas
URL: https://www.opiq.ee/kit/285/chapter/16824
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 2.2
Topics ET: matemaatika, ratas, peab, rattaga, sõites, olema, tohid, sõita, mari
Topics RU: математика
Topics EN: mathematics
Headings: Ratas; 1. RATAS; Mis peab rattaga sõites olema?; Kus sa tohid rattaga sõita?; 2. MARI SÕIDAB RATTAGA; Leia kiivri värviga sobiv ratas.; 3. MIS ON PUUDU?; Tööleht; Tööleht: Ratas
Task examples: Mis koht on pildil? Näita ja nimeta.Kus sa tohid rattaga sõita? Märgi sobiv pilt. Kus sa tohid rattaga sõita? Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õ; Vaata pilte. Mis on pildil?Leia igale lapsele kiivri värviga sobiv ratas. Ühenda paarid. Leia kiivri värviga sobiv ratas. : 0 : 0 RATTAGA SÕITES KANNA ALATI KIIVRIT! PausEsita% puhverdatud00:0000:00Eemalda vaigistusVaigi

## Siim sõidab linna
URL: https://www.opiq.ee/kit/285/chapter/16825
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 2.3
Topics ET: matemaatika, siim, sõidab, linna, buss, käitumine, bussis, linnas, keda
Topics RU: математика
Topics EN: mathematics
Headings: Siim sõidab linna; 1. BUSS; Käitumine bussis; 2. LINNAS; Keda või mida võisid ema ja Siim linnas näha?; Tööleht; Tööleht: Siim sõidab linna
Task examples: 1. Vaata pilte. Mida teeb laps pildil? Näita ja nimeta.2. Mida sobib bussis teha? Vali jah-pöial. Mida ei sobi bussis teha? Keda selline käitumine segab? Vali ei-pöial. Käitumine bussis JAH EI : 0 : 0 Käitumine bussis JA; 1. Vaata pilte. Mis / kes on pildi? Nimeta.2. Keda /mida kohtad linnas sageli? Märgi sobivad pildid. Keda või mida võisid ema ja Siim linnas näha? Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata v

## Siim ja ema linnas
URL: https://www.opiq.ee/kit/285/chapter/16826
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 2.4
Topics ET: matemaatika, siim, linnas, vigur, pilt, leia, buss, bussi, sõit
Topics RU: математика
Topics EN: mathematics
Headings: Siim ja ema linnas; 1. VIGUR-PILT; Leia buss.; 2. BUSSI-SÕIT; 3. SÕIDUKID; Mis auto on pildil?; Tööleht; Tööleht: Linnas
Task examples: Linnas pidid Siim ja ema sõitma linnaliinibussiga. Vaata pilte. Mis sõiduk on pildil? Näita ja nimeta.Leia buss. Vajuta pildile. Leia buss. : 0 : 0 AUTORONGBUSS Tööleht. Värvi buss punaseks. Lisa oma materjali Tekstiabi ; 1. Mis auto on pildil? Näita ja nimeta.2. Ühenda paarid. Mis auto on pildil? : 0 : 0 Tööleht. Värvi teine auto samasuguseks. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Rii

## Abi küsimine
URL: https://www.opiq.ee/kit/285/chapter/16827
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 2.5
Topics ET: matemaatika, küsimine, koju, sõit, mari, kuidas, tundis, aitab, maril
Topics RU: математика
Topics EN: mathematics
Headings: Abi küsimine; 1. KOJU-SÕIT; 2. MARI; Kuidas Mari end tundis?; Mis aitab Maril kodu leida?; 2. POES; Kelle käest Lilli poes abi küsib?; TÖÖLEHT
Task examples: Mari läks vale bussi peale. Ta ei leidnud oma kodu üles. Kuidas Mari end tundis? Märgi sobiv pilt. Kuidas Mari end tundis? RÕÕMUS KURB MURELIK VIHANE : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata; Vaata pilte. Mis aitab Maril kodu leida?​Märgi sobivad pildid.Mida Mari saab veel teha? Arutle õpetajaga. Mis aitab Maril kodu leida? : 0 : 0 ÕPI PÄHE OMA EMA VÕI ISA TELEFONI-NUMBER.TEA OMA KODU AADRESSI:MIS TÄNAVAL SA 

## Siimu pere
URL: https://www.opiq.ee/kit/285/chapter/16921
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 3.1
Topics ET: matemaatika, siimu, pere, kodu, ruumid, kodus, sobib, ruumi, vali
Topics RU: математика
Topics EN: mathematics
Headings: Siimu pere; 1. PERE; 2. KODU; 3. RUUMID KODUS; Mis sobib ruumi?; Vali sobiv ruum.; 4. KÖÖGIS; Pane pildid õigesse järjekorda.; Leia piparkoogile paariline.; 5. SÖÖGI-LAUD; Köök; Mis ei sobi ritta?; Tööleht; Tööleht: Siimu pere
Task examples: 1. Loe*. Vii number sobiva pildi juurde. * Õpetajale[peidetud sisu]Lapsed on õppinud numbreid 1-5. Lugemisoskuseta lapsed täidavad ülesande koostegevuses õpetajaga õpetaja öeldud sõna ja numbri abil. SIIMU PERE {"data":[; Mis ruum on suurel pildil? Nimeta.Mis on väikestel piltidel? Nimeta.Leia sama asi suurel pildil. Lohista. Mis sobib ruumi? : 0 : 0 Mis sobib ruumi? : 0 : 0 Mis sobib ruumi? : 0 : 0 Mis sobib ruumi? : 0 : 0 Mis sobib ruum

## Mari pere
URL: https://www.opiq.ee/kit/285/chapter/16922
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 3.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, loom, loomad, linnud, putukad, mari, pere, kodu, laps, elab, kelle
Topics RU: математика, сравнение, сравни, больше, меньше, животное, животные, птицы, насекомые
Topics EN: mathematics, comparison, compare, greater, less, animal, animals, birds, insects
Headings: Mari pere; 1. PERE; Mis loom on?; 2. KODU; Kus laps elab?; Kelle pere on väiksem?; *Ülesanne 3; Lohista sõna pildile.; 3. MARI PERE LAPSED; Lapsed; 4. MINU PERE; 5. MARI JA SIIMU LOOMAD; Mari ja Siimu loomad; Mis loomad elavad sinu peres?; Mis loomad elavad Mari peres?; 6. LEMMIK-LOOMAD; Kuidas sina oma looma eest hoolitsed?; 7. PESE KÄSI!; 8. VÕÕRAD LOOMAD; 9. KES ON PILDIL?; Tööleht; Tööleht: Mari pere
Task examples: Kes on pildil? Näita ja nimeta.Kus on lapse kodu? Lohista pildid. Kus laps elab? MARISIIM : 0 : 0 *3. Loe laused. MARI ELAB LINNAS.SIIM ELAB MAAL. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näid; 1. Vaata pilti. Näita 1./2. pilti. Kelle pere see on?2. Mitu inimest on selles peres? Nimeta. Vali sobiv arv. PausEsita% puhverdatud00:0000:00Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0

## Roosi ja Lilli pere
URL: https://www.opiq.ee/kit/285/chapter/16926
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 3.3
Topics ET: matemaatika, roosi, lilli, pere, vana, kodu, maja, milline, sinu, kodumaja
Topics RU: математика
Topics EN: mathematics
Headings: Roosi ja Lilli pere; 1. PERE; 2. VANA-EMA JA VANA-ISA; 3. MINU KODU-MAJA; Milline maja on sinu kodumaja sarnane?; 4. RÄÄGI OMA KODUST.; 5. ÕED ROOSI JA LILLI; 6. ÕUE-TÖÖD; Mis töid tüdrukud teevad?; Tööleht; Tööleht: Roosi ja Lilli pere
Task examples: Roosi ja Lilli toa seinal on pildid. Võrdle pilte. Leia 7 erinevust. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihts; Tööleht. Roosile meeldib puldiautoga sõita. Tee autosõit pliiatsiga kaasa. Võta iga auto jaoks erinev värv. Värvi auto sama värvi. 123 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppek

## Vannituba
URL: https://www.opiq.ee/kit/285/chapter/16923
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 3.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, vannituba, vanni, tuba, asjad, sobivad, siia, vannituppa
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Vannituba; 1. VANNI-TUBA; Mis asjad sobivad siia vannituppa?; 2. MINU KEHA; Leia kehaosa. Kuula; 3. PESEMINE; MINA PESIN TÄNA; 4. PESEN MILLEGA?; mis sobib suure pildiga; MARI PESEB PEAD; Mis ei sobi ritta?; Tööleht; Tööleht: Vannituba
Task examples: 1. Vaata slaidil pilte. Mis on pildil? Näita ja nimeta. 1234567 2. Lohista pildid õigesse kohta. Kõiki pilte ei lähe vaja! Mis asjad sobivad siia vannituppa? : 0 : 0 Mis asjad sobivad siia vannituppa? : 0 : 0 Mis asjad s; Mida sina täna hommikul pesid?Loe. Vajuta sobivale pildile. MINA PESIN TÄNA NÄGU KÄSI HAMBAID JUUKSEID Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava

## Siim koristab
URL: https://www.opiq.ee/kit/285/chapter/16924
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 3.5
Topics ET: matemaatika, siim, koristab, aitab, asjad, leiba, siimu, tuba, mida
Topics RU: математика
Topics EN: mathematics
Headings: Siim koristab; 1. SIIM AITAB EMA; 2. ASJAD; Siim sõi leiba.; 3. SIIMU TUBA; 4. SIIM KORISTAB; Mida sina kodus teed?; 5. MÖÖBEL; Tööleht; Tööleht: Siim koristab
Task examples: 1. Kuula. Vaata slaidil õiget pilti.​1) Siim sõi leiba. 2) Leivapuru kukus maha. Siim pühkis puru harjaga kühvlile. 3) Ta pani puru prügikasti. PausEsita% puhverdatud00:0000:00Eemalda vaigistusVaigistaSeadedKiirusTavalin; Mida teed sina kodus? Vajuta sobivatele piltidele. Mida sina kodus teed? Salvesta Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põ

## Eesti, minu kodumaa
URL: https://www.opiq.ee/kit/285/chapter/16925
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 3.6
Topics ET: matemaatika, taim, taimed, puu, lill, eesti, kodumaa, oled, käinud, kodu, koht, elad, lipp
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Eesti, minu kodumaa; 1. EESTI; Kus sa oled käinud?; 2. KODU-KOHT; Kus sa elad?; 3. EESTI LIPP; Milline neist lippudest on Eesti lipp?; 4. LIPP; Kus oled näinud lippu lehvimas?; 5. SUITSU-PÄÄSUKE; 6. RUKKI-LILL; Mis (kes) on pildil?; Tööleht; Tööleht: Eesti
Task examples: 1. Eestis on palju toredaid kohti. Vaata pilte. Mis koht on pildil? Näita ja nimeta.2. Kus sina oled käinud? Kus sa oled käinud? 7. MAA JAH EI Salvesta Kus sa oled käinud? 1. TALLINNA LOOMA-AED JAH EI Salvesta Kus sa ole; Milline neist lippudest on Eesti lipp? Vali õige vastus. Milline neist lippudest on Eesti lipp? ONEI OLE ONEI OLE ONEI OLE : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavas

## Eesti sünnipäev
URL: https://www.opiq.ee/kit/285/chapter/16927
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 3.7
Topics ET: matemaatika, eesti, sünnipäev, aktus, hümn, pidulikud, riided, sobib, aktusele
Topics RU: математика
Topics EN: mathematics
Headings: Eesti sünnipäev; 1. AKTUS; 2. EESTI HÜMN; 3. PIDULIKUD RIIDED; Mis sobib aktusele?; 4. PIDU-PÄEV; Tööleht; Tööleht: Eesti sünnipäev
Task examples: 1. Siim ja Mari valivad aktuseks riideid. Mis esemed on piltidel? Näita ja nimeta.2. Märgi riided ja jalanõud, millega lapsel sobib aktusele minna. Mis sobib aktusele? Salvesta Mis sobib aktusele? Salvesta Mis sobib aktu

## Puhas laps
URL: https://www.opiq.ee/kit/285/chapter/17514
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 4.1
Topics ET: matemaatika, puhas, laps, kumb, must, käed, riided, saavad, mustaks, käte
Topics RU: математика
Topics EN: mathematics
Headings: Puhas laps; 1. PUHAS LAPS; Kumb laps on puhas?; 2. MUST; 3. KÄED JA RIIDED SAAVAD MUSTAKS; 4. KÄTE PESEMINE; 5. WC; Järjesta pildid.; 6. PESE KÄSI!; Tööleht; Tööleht: Puhas laps
Task examples: Järjesta pildid. Järjesta pildid. : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põhikooli lihtsustatud riiklik õppekava 20

## Hambad
URL: https://www.opiq.ee/kit/285/chapter/17515
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 4.2
Topics ET: matemaatika, hambad, millised, sulle, meelivad, toit, hammastele, mari, peseb
Topics RU: математика
Topics EN: mathematics
Headings: Hambad; 1. SUU; Millised hambad sulle meelivad?; Mis toit on hammastele hea?; 2. MARI PESEB HAMBAID; 3. HAMBA-PESU; Mida sul on hammaste pesuks vaja?; 4. HAMBAARSTI JUURES; Milline laps on rõõmus?; 5. TERVISLIK TOIT; Hammastele sobiv toit.; 6. HAMBA-HARI; Tööleht; Tööleht: Hambad
Task examples: Missugused hambad on 1. pildilMissugused hambad on 2. pildil? Mis võis nende hammastega juhtuda?Millised hambad sulle meeldivad? Vali sobiv vastus. 1. Millised hambad sulle meelivad? JAH EI Salvesta 1. Millised hambad su; Mis toit on pildil? Näita ja nimeta.Hambad peavad olema tugevad. Selleks pead sööma õiget toitu. Mis on hammastele hea?Vali jah- või ei-pöial. PausEsita% puhverdatud00:0000:00Eemalda vaigistusVaigistaSeadedKiirusTavaline

## Tervislik toit
URL: https://www.opiq.ee/kit/285/chapter/17516
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 4.3
Topics ET: matemaatika, taim, taimed, puu, lill, tervislik, toit, lemmik, toitu, saab, teha, sellest, toiduainest
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: Tervislik toit; 1. LEMMIK-TOIT; Mis toitu saab teha sellest toiduainest?; 2. TOIDU-PÜRAMIID; Mida sööd tihti, mida harva?; 3. JOOGID; Mis jooki võib iga päev juua?; 4. PUU-VILJAD JA KÖÖGI-VILJAD; Mis vilju sina sööd?; pusle; Tööleht; Tööleht: Tervislik toit
Task examples: 1. Vaata pilte. Siin on toiduained. Mis toiduained on pildil? Nimeta. 1234 Mis toitu saab teha sellest toiduainest? PRAAD KOHUPIIM PUDER SUPP : 0 : 0 2. Mis toitu saab teha sellest toiduainest? Leia paarilised. Lohista. ; Vaata pilte. Mis on pildil? Näita ja nimeta.Mida sööd tihti? Vali roheline värv.Mida sööd harva? Vali kollane värv. Mida sööd tihti, mida harva? Salvesta Mida sööd tihti, mida harva? Salvesta Mida sööd tihti, mida harva?

## Söögilauas
URL: https://www.opiq.ee/kit/285/chapter/17517
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 4.4
Topics ET: matemaatika, söögilauas, söögi, nõud, laua, katmine, vali, sobiv, söögiriist
Topics RU: математика
Topics EN: mathematics
Headings: Söögilauas; 1. SÖÖGI-NÕUD; Laua katmine; Vali sobiv söögiriist.; 2. SÖÖMINE; 3. SÖÖKLAS; Millise laua lapsed on viisakad?; 4. PÄRAST SÖÖKI; Mis ei sobi ritta?; Tööleht; Tööleht: Söögilauas
Task examples: Vaata pilte. Mis toit on pildil?Mida saab süüa kahvliga? Mida saab süüa lusikaga? Vali sobiv söögiriist. Vali sobiv söögiriist. : 0 : 0 Vali sobiv söögiriist. : 0 : 0 Vali sobiv söögiriist. : 0 : 0 Vali sobiv söögiriist.; 1. Lapsed said kõhud täis. Vaata 1. pilti. Milline on see söögilaud pärast söömist?2. Vaata 2. pilti. Milline on see söögilaud pärast söömist? 3. Millise laua lapsed on viisakad? Vali sobiv laud. Kuidas käitud sina? Mill

## Aasta
URL: https://www.opiq.ee/kit/285/chapter/17518
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 5.1
Topics ET: matemaatika, aasta, ajad, trüki, aastaaeg, pildil, vigur, pilt, aastaajal
Topics RU: математика
Topics EN: mathematics
Headings: Aasta; 1. AASTA-AJAD; Trüki aastaaeg; Mis aastaaeg on pildil?; 2. VIGUR-PILT; Mis aastaajal sa seda riideeset kannad?; Mis riideese ei sobi ritta?; Mis ei sobi ritta?; Leia paarilised; Tööleht; Tööleht: Aasta
Task examples: Mis aastaaeg on piltidel? Mille järgi nii arvad? Kirjuta aastaaja nimetus kasti sisse.Mida teevad lapsed pildil?Mida sina oled teinud? Vajuta pildile.Mida veel võib sel aastaajal teha? Trüki aastaaeg : 0 : 0 Mis aastaaeg; Vaata väikseid pilte. Mis ese on pildil? Nimeta.​Mis ilmaga sa seda eset kannad?Vali sobiv ilm. Mis aastaajal sa seda riideeset kannad? : 0 : 0 Mis aastaajal sa seda riideeset kannad? : 0 : 0 Mis aastaajal sa seda riidee

## Öö ja päev
URL: https://www.opiq.ee/kit/285/chapter/17519
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 5.2
Topics ET: matemaatika, päev, siimu, päeva, osad, mida, tüdruk, millal, teeb
Topics RU: математика
Topics EN: mathematics
Headings: Öö ja päev; 1. ÖÖ JA PÄEV; 2. SIIMU PÄEV; Siimu päeva osad; 3. PÄEVA OSAD; Mida tüdruk millal teeb?; Tööleht; Tööleht: Öö ja päev
Task examples: Loe/kuula. Kas lause on õige või vale? Ütle vale lause õigesti. PausEsita% puhverdatud00:0000:00Eemalda vaigistusVaigistaSeadedKiirusTavalineKiirusTagasi eelmisesse menüüsse0.5×0.75×Tavaline1.25×1.5×1.75×2×4×Your browser; Kuula. Lõpeta õpetaja laused (abiks piltidele osutamine, õpetajaga koos ütlemine).Õpetajale[peidetud sisu]Õpetaja ütleb lünkteksti lausete alguse. Lapsed lõpetavad laused. Abiks piltidele osutamine, õpetajaga koos ütlemi

## Nädal
URL: https://www.opiq.ee/kit/285/chapter/17520
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 5.3
Topics ET: matemaatika, nädal, päevad, puhke, päevadel, siimu, pere, koer, nädalapäev
Topics RU: математика
Topics EN: mathematics
Headings: Nädal; 1. NÄDAL; 2. TÖÖ-PÄEVAD JA PUHKE-PÄEVAD; Mis päevadel sa ...?; 3. SIIMU PERE KOER; Mis nädalapäev?; 4. LASTE NÄDAL; Trüki; Mis päeva kohta lause käib?; Tööleht; Tööleht: Nädal
Task examples: 1. Loe sõnad.2. Mis päevadel sa käid koolis? Vali sinine kastike.3. Mis päevadel sa puhkad? Vali punane kastike. Mis päevadel sa ...? 1. ESMAS-PÄEV 2. TEISI-PÄEV 3. KOLMA-PÄEV 4. NELJA-PÄEV 5. REEDE 6. LAU-PÄEV 7. PÜHA-P; Loe sõnad.Mis päev on täna? Täna on … (mis nädalapäev?). Kirjuta kasti sisse sobivad algustähed. Mis nädalapäev? EILETÄNAHOMME : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppek

## Minu asjad
URL: https://www.opiq.ee/kit/285/chapter/17521
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 6.1
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, asjad, esemed, vahend, kooli, teen, laua, moodusta
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Minu asjad; 1. ESEMED; Vahend; 2. KOOLI-ASJAD; 3. TEEN LAUA KORDA; Moodusta lause; Mis asjad on lauale juurde pandud?; Tööleht; Tööleht: Minu asjad
Task examples: 1. Vaata, mis värvi on südamekesed. Nimeta värvid.2. Lohista sõnad värvide abil õigesse järjekorda. Moodusta lause : 0 : 0 Tööleht. Kirjuta pliiatsiga sõnad üle. Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link T; Vaata 1. pilti. Mis asjad on pildil?Vaata 2. pilti. Mis asjad on lauale juurde pandud? Märgi need asjad. 1. Mis asjad on lauale juurde pandud? 2. : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata vea

## Mari saab nuku
URL: https://www.opiq.ee/kit/285/chapter/17522
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 6.2
Topics ET: matemaatika, mari, saab, nuku, endale, tunded, kuidas, nukku, saades, tundis
Topics RU: математика
Topics EN: mathematics
Headings: Mari saab nuku; 1. MARI SAAB UUE NUKU; Mari sai endale uue nuku; 2. MARI; 3. TUNDED; Kuidas Mari end nukku saades tundis?; 4. MÄNGU-ASI; 5. ANNI LAENAB NUKKU; Kuidas Mari tundis ennast katkist nukku saades?; 6. KATKINE NUKK; 7. EMA LOHUTAB; Korras või katki?; Millisel pildil laps hoolib oma asjadest?; HOOLAS LAPS; Tööleht; Tööleht: Mari saab nuku
Task examples: Vaata pilte. Nimeta, milline tunne on pildil? Laps on... (rõõmus, kurb, ehmunud, vihane).Kuidas Mari tundis end katkist nukku saades? Vajuta sobivale pildile.Mis muutis Mari kurvaks? Mille pärast Mari ehmatas? Mille peal; Vaata pilti. Mis on pildil? Missugune see on? (Välimus, otsus: katki või korras/terve.)Vali sobiv näoilme. Korras või katki? : 0 : 0 Korras või katki? : 0 : 0 Korras või katki? : 0 : 0 Korras või katki? : 0 : 0 Korras võ

## Koristaja Inna
URL: https://www.opiq.ee/kit/285/chapter/17523
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 6.3
Topics ET: matemaatika, koristaja, inna, mida, sina, kasutad, koristamisel, tädi, siim
Topics RU: математика
Topics EN: mathematics
Headings: Koristaja Inna; 1. INNA; Mida sina kasutad koristamisel?; 2. KORISTAJA; 3. TÄDI INNA JA SIIM; Leia samasugune; Leia samasugune.; Tööleht; Tööleht: Koristaja Inna
Task examples: 1. Vaata pilte. Mis on pildil? Näita. Nimeta.2. Mida sina kasutad oma toa ja klassi koristamisel. Vali sobiv vastus. TÄDI INNA TÖÖ-VAHENDID Mida sina kasutad koristamisel? JAH EI Salvesta Mida sina kasutad koristamisel? ; 1. Koolilapsed aitavad oma kooli puhtana hoida. Vaata pilte. Mida lapsed teevad?2. Kuidas sina oma koolis saad aidata?3. Mida sina oled oma klassis teinud? Vajuta pildile. ÜLESANNE 2 1. 2. 3. Salvesta Lisa oma materjali 

## Töömees Anatoli
URL: https://www.opiq.ee/kit/285/chapter/17524
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 6.4
Topics ET: matemaatika, töömees, anatoli, tööriistu, sinu, kodus, tööd, koolis, leia
Topics RU: математика
Topics EN: mathematics
Headings: Töömees Anatoli; 1. ANATOLI; Mis tööriistu on sinu kodus?; 2. TÖÖD KOOLIS; Leia sobiv tööriist; 3. ANATOLI TELEFON; Mis juhtus telefoniga?; 4. LEITUD ASI; Anatoli mobiiltelefon; 5. ANATOLI TÄNAB; Tööleht; Tööleht: Töömees Anatoli
Task examples: 1. Vaata väikseid pilte. Mis on pildil? Näita. Nimeta.2. Mis tööriistu on sinu kodus? Vali sobiv vastus. ONU ANATOLI TÖÖ-VAHENDID Mis tööriistu on sinu kodus? JAH EI Salvesta Mis tööriistu on sinu kodus? JAH EI Salvesta ; 1. Vaata tööriistade pilte. Näita ja nimeta. 2. Ühenda pilt sobiva tööriistaga. Leia sobiv tööriist : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 201

## Kokk Siiri
URL: https://www.opiq.ee/kit/285/chapter/17525
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 6.5
Topics ET: matemaatika, kokk, siiri, töötab, millised, köögiriistad, sinu, kodus, sobi
Topics RU: математика
Topics EN: mathematics
Headings: Kokk Siiri; 1. SIIRI; Kus töötab Siiri?; Millised köögiriistad on sinu kodus?; Mis ei sobi ritta?; Mis asi ei sobi ritta?; 2. KOOLI SÖÖKLAS; 3. KÕIK SAAVAD ÕUNA; Tööleht; Tööleht: Kokk Siiri
Task examples: Vaata pilte. Mis koht on pildil? Näita ja nimeta.Kus töötab kokk Siiri? Näita ja nimeta. Vali õige pilt. Kus töötab Siiri? : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavas; 1. Vaata väikseid pilte. Mis on pildil? Näita. Nimeta.2. Mis köögiriistu on sinu kodus? Märgi sobiv vastus. SIIRI TÖÖ-VAHENDID Millised köögiriistad on sinu kodus? JAH EI Salvesta Millised köögiriistad on sinu kodus? JAH

## Iga töö on vajalik
URL: https://www.opiq.ee/kit/285/chapter/17526
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 6.6
Topics ET: matemaatika, vajalik, ametid, koolis, ühenda, töötaja, töövahend, riided, leia
Topics RU: математика
Topics EN: mathematics
Headings: Iga töö on vajalik; 1. AMETID KOOLIS; Ühenda töötaja ja töövahend; 2. RIIDED; Leia paariline; 3. ESEMED; Leia need esemed; Tööleht; Tööleht: Iga töö on vajalik
Task examples: Ühenda töötaja ja töövahend. Lohista pildile. Ühenda töötaja ja töövahend : 0 : 0 Lisa oma materjali Tekstiabi Muud tegevused Kopeeri link Teata veast näidatakse õppekavast: Riiklik õppekava 2011 Riiklik õppekava 2023 Põ; 1. Vaata pilti. Mis on pildil juhtunud? Kuula õpetaja jutukest iga pildi kohta. Vasta õpetaja küsimustele.2. Kelle poole pöördud? Vali sobiv inimene. ÜLESANNE 2 Mis on pildil juhtunud? Kelle poole pöördud? Vali sobiv ini

## Soovitused õppematerjali kasutamiseks
URL: https://www.opiq.ee/kit/285/chapter/15947
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 7.1
Topics ET: matemaatika, soovitused, õppematerjali, kasutamiseks, inimeseõpetus, lihtsustatud, õppes, soovitusi, klassis
Topics RU: математика
Topics EN: mathematics
Headings: Soovitused õppematerjali kasutamiseks; Inimeseõpetus lihtsustatud õppes. Soovitusi õppematerjali kasutamiseks 1.klassis

## Inimeseõpetus 1. klassile I osa (print-pdf)
URL: https://www.opiq.ee/kit/285/chapter/15948
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 7.2
Topics ET: matemaatika, inimeseõpetus, klassile, print
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 1. klassile I osa (print-pdf)

## Inimeseõpetus 1. klassile II osa (print-pdf)
URL: https://www.opiq.ee/kit/285/chapter/16789
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 7.3
Topics ET: matemaatika, inimeseõpetus, klassile, print, peitu
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 1. klassile II osa (print-pdf); Peitu

## Impressum
URL: https://www.opiq.ee/kit/285/chapter/15949
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_1._klassile._lihtsustatud_õppekava
Chapter ID: 7.4
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Inimeseõpetus algklassidele, I osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/449
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 40
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus algklassidele, I osa. 2023 ÕK – Opiq
URL: https://www.opiq.ee/Kit/Details/449
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 87
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Setumaa kuningas
URL: https://www.opiq.ee/kit/449/chapter/24464
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.1
Topics ET: matemaatika, setumaa, kuningas, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Setumaa kuningas; II; III; Arutle

## ME ELAME EESTIS
URL: https://www.opiq.ee/kit/449/chapter/24457
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.2
Topics ET: matemaatika, elame, eestis, eesti, vabariik, keel, arutle
Topics RU: математика
Topics EN: mathematics
Headings: ME ELAME EESTIS; EESTI VABARIIK; EESTI KEEL; ISA-EMA MAA; Arutle
Task examples: VALI LÜNKA ÕIGE SÕNA.; SEE LUULETUS RÄÄGIB ...

## LIIKLUS JA LIIKLEMINE I
URL: https://www.opiq.ee/kit/449/chapter/24458
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.3
Topics ET: matemaatika, liiklus, liiklemine, arutle, kõnniteel, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS JA LIIKLEMINE I; LIIKLUS; Arutle; LIIKLEMINE KÕNNITEEL; LAHENDA
Task examples: TÄNAVAL LIIKUDES JÄLGI; MIS TEEDEL TOHID SA RATTAGA SÕITA? MÄRGI ÕIGED VASTUSED.

## LIIKLUS JA LIIKLEMINE II
URL: https://www.opiq.ee/kit/449/chapter/24459
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.4
Topics ET: matemaatika, liiklus, liiklemine, sõidutee, ületamine, kiirusta, arutle, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS JA LIIKLEMINE II; SÕIDUTEE ÜLETAMINE; ÄRA KIIRUSTA!; Arutle; LAHENDA
Task examples: KUIDAS ÜLETAD TEED? LOHISTA TEGEVUSED ÕIGESSE JÄRJEKORDA.; MIDA NEED LIIKLUSMÄRGID TÄHENDAVAD? ÜHENDA PILT JA SÕNAD.

## LIIKLUS JA OHUTUS I
URL: https://www.opiq.ee/kit/449/chapter/24460
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.5
Topics ET: matemaatika, liiklus, ohutus, turvavöö, arutle, sõidukist, väljumine
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS JA OHUTUS I; TURVAVÖÖ; Arutle; SÕIDUKIST VÄLJUMINE
Task examples: UURI PILTI. KES ISTUB ÕIGESTI? MÄRGI.

## LIIKLUS JA OHUTUS II
URL: https://www.opiq.ee/kit/449/chapter/24461
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.6
Topics ET: matemaatika, liiklus, ohutus, liikumine, pimedas, nähtav, arutle, jalgratas, tõukeratas
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS JA OHUTUS II; LIIKUMINE PIMEDAS. OLE NÄHTAV!; Arutle; JALGRATAS JA TÕUKERATAS; LAHENDA
Task examples: MILLE KÜLGE TULEB HELKURID KINNITADA? VALI ÕIGED VASTUSED.; VALI LÜNKA ÕIGE SÕNA.

## ÜKSI KODUS JA ÕUES
URL: https://www.opiq.ee/kit/449/chapter/24462
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.7
Topics ET: matemaatika, üksi, kodus, õues, mida, teha, mulle, meeldib, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: ÜKSI KODUS JA ÕUES; MIDA ÜKSI TEHA?; MULLE MEELDIB; LAHENDA; Arutle
Task examples: KES LOEB MEELELDI AJALOOST JA KAUGETEST MAADEST?; MIDA SAAKS TA TEHA ÜKSI? MILLE JAOKS ON VAJA SÕPRU? LOHISTA.

## AEG JA AJATAJU
URL: https://www.opiq.ee/kit/449/chapter/24463
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 1.8
Topics ET: matemaatika, aeg, kell, kalender, ajataju, kuidas, läheb, õige, lahenda, arutle
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: AEG JA AJATAJU; KUIDAS LÄHEB AEG?; KAS ON ÕIGE AEG?; LAHENDA; Arutle
Task examples: MIDA KAVATSEVAD LAPSED TEHA?; MIDA SAAB TEHA VIIE MINUTIGA, MIDA ÜHE TUNNIGA? LOHISTA.

## Igaühel oma pesa
URL: https://www.opiq.ee/kit/449/chapter/24465
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 2.1
Topics ET: matemaatika, igaühel, pesa, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Igaühel oma pesa; II; Arutle

## PERE
URL: https://www.opiq.ee/kit/449/chapter/24902
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 2.2
Topics ET: matemaatika, pere, arutle, omad, kombed, mida, teeb
Topics RU: математика
Topics EN: mathematics
Headings: PERE; KES ON PERE?; Arutle; OMAD KOMBED; KES MIDA TEEB?
Task examples: MILLISEID KINGITUSI SAAB ISE VALMISTADA? MÄRGI.; LEIA SÕNARÄGASTIKUST SÕNU KODUSTE TÖÖVAHENDITE KOHTA. MILLISEID NEIST SINA KASUTADA OSKAD?

## SUGULASED
URL: https://www.opiq.ee/kit/449/chapter/24903
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 2.3
Topics ET: matemaatika, sugulased, lähemad, suur, väike, veli, arutle, sugupuu, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: SUGULASED; LÄHEMAD SUGULASED; SUUR VÕI VÄIKE; SUUR VELI; Arutle; SUGUPUU; LAHENDA
Task examples: KAS LAUSE ON ÕIGE VÕI VALE?; UURI PÄRDI PEREPUUD. VALI LÜNKA ÕIGE SÕNA.

## MINA JA PÄRILIKKUS
URL: https://www.opiq.ee/kit/449/chapter/24904
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 2.4
Topics ET: matemaatika, mina, pärilikkus, kelle, moodi, mida, pärime, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MINA JA PÄRILIKKUS; KELLE MOODI?; MIDA ME PÄRIME?; Arutle
Task examples: OSA OMA VÄLIMUSEST PÄRIME; KAS LAUSE ON ÕIGE VÕI VALE? MÄRGI ÕIGED LAUSED.

## KODU
URL: https://www.opiq.ee/kit/449/chapter/24905
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 2.5
Topics ET: matemaatika, kodu, tilluke, suur, hoolitse, eest, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: KODU; TILLUKE VÕI SUUR?; HOOLITSE KODU EEST; LAHENDA; Arutle
Task examples: MIS PEAB KODUL KINDLASTI OLEMA? MÄRGI.; KUS KEEGI ELAB? LOHISTA.

## LEMMIKLOOMAD. KOER
URL: https://www.opiq.ee/kit/449/chapter/24906
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 2.6
Topics ET: matemaatika, lemmikloomad, koer, kõige, vanem, koduloom, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LEMMIKLOOMAD. KOER; KOER; KÕIGE VANEM KODULOOM; LAHENDA
Task examples: Mis tööd see koer teeb?; Mis tööd see koer teeb?

## LEMMIKLOOMAD. KASS
URL: https://www.opiq.ee/kit/449/chapter/24907
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 2.7
Topics ET: matemaatika, loom, loomad, linnud, putukad, lemmikloomad, kass, arutle, isepäine, lahenda
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: LEMMIKLOOMAD. KASS; KASS; Arutle; ISEPÄINE LOOM; LAHENDA

## Varbad ja nina
URL: https://www.opiq.ee/kit/449/chapter/24911
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 3.1
Topics ET: matemaatika, varbad, nina, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Varbad ja nina; Arutle

## MINU TERVIS I
URL: https://www.opiq.ee/kit/449/chapter/24908
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 3.2
Topics ET: matemaatika, inimene, keha, meeled, tervis, kuidas, püsida, terve, ilmaga, sobivad, riided, arutle
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MINU TERVIS I; KUIDAS PÜSIDA TERVE?; ILMAGA SOBIVAD RIIDED; Arutle
Task examples: Mida teha, et oleksime terved? Ühenda pilt ja lause.; Mida teha, et oleksime terved. Ühenda pilt ja lause.

## MINU TERVIS II
URL: https://www.opiq.ee/kit/449/chapter/24909
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 3.3
Topics ET: matemaatika, inimene, keha, meeled, tervis, pisikud, kätepesu, hambapesu
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MINU TERVIS II; PISIKUD; KÄTEPESU; HAMBAPESU
Task examples: Kas käsi tuleb pesta ENNE või PÄRAST?; Kuidas pesta käsi? Järjesta tegevused.

## TERVIS. NUTIKAD ABIVAHENDID
URL: https://www.opiq.ee/kit/449/chapter/24910
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 3.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, nutikad, abivahendid, tänaval, arutle, punktkiri, viipekeel
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: TERVIS. NUTIKAD ABIVAHENDID; ABIVAHENDID; ABIVAHENDID TÄNAVAL; Arutle; PUNKTKIRI; VIIPEKEEL
Task examples: Nuputa, mis on laste nimed.; Väiksed labradorikutsikad lähevad peagi koertekooli ja õpivad juhtkoerteks. Nuputa, mis on nende nimed.

## Head kombed
URL: https://www.opiq.ee/kit/449/chapter/24920
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.1
Topics ET: matemaatika, head, kombed, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Head kombed; II; III; Arutle

## ÕPPIMISNÕKSUD
URL: https://www.opiq.ee/kit/449/chapter/24919
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.10
Topics ET: matemaatika, õppimisnõksud, harjutamine, teeb, meistriks, eesmärgid, meisterlikkuseni, arutle
Topics RU: математика
Topics EN: mathematics
Headings: ÕPPIMISNÕKSUD; HARJUTAMINE TEEB MEISTRIKS!; EESMÄRGID; TEE MEISTERLIKKUSENI; Arutle
Task examples: Vali lünka õige sõna.; Millised oskused oleks võimalik ühel lapsel omandada, kui ta soovib?

## EMOTSIOONID I
URL: https://www.opiq.ee/kit/449/chapter/24912
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.2
Topics ET: matemaatika, emotsioonid, mõtle, mõistan, teisi, arutle, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: EMOTSIOONID I; MIS ON EMOTSIOONID?; Mõtle; MÕISTAN TEISI; Arutle; LAHENDA
Task examples: Milline on eri emotsioonide puhul näoilme?; Mida lapsed tunnevad? Vali lausele sobiv lõpp.

## EMOTSIOONID II
URL: https://www.opiq.ee/kit/449/chapter/24913
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.3
Topics ET: matemaatika, emotsioonid, erinevad, olukorrad, arutle, teeselda, pole, vaja, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: EMOTSIOONID II; ERINEVAD OLUKORRAD; Arutle; TEESELDA POLE VAJA; LAHENDA
Task examples: Kumb koer soovib pai saada? Kumb mitte? Mis sa arvad, miks?; Kuidas sa end tunned ja mida teed? Märgi.

## ENESE JA TEISTE TUNDMINE, ISELOOM
URL: https://www.opiq.ee/kit/449/chapter/24914
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.4
Topics ET: matemaatika, enese, teiste, tundmine, iseloom, omadused, arutle, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: ENESE JA TEISTE TUNDMINE, ISELOOM; ISELOOM; OMADUSED; Arutle; LAHENDA
Task examples: Millest või kellest see luuletus räägib?; Millise kaaslasega tahaksid sa mängida? Märgi.

## SUHTLEMINE. KEEL JA KEHAKEEL
URL: https://www.opiq.ee/kit/449/chapter/24915
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.5
Topics ET: matemaatika, inimene, keha, meeled, tervis, suhtlemine, keel, kehakeel, reedab, salamõtteid, arutle, lahenda
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: SUHTLEMINE. KEEL JA KEHAKEEL; KEEL; KEHA REEDAB SALAMÕTTEID!; Arutle; LAHENDA
Task examples: Püüa aru saada laste kehakeelest. Kes ütleb EI ja kes JAA?; Püüa aru saada laste kehakeelest. Kes ütleb EI ja kes JAA?

## MINA JA TEISED. KOOSTÖÖ JA MÄNG
URL: https://www.opiq.ee/kit/449/chapter/24916
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.6
Topics ET: matemaatika, mina, teised, koostöö, mäng, mängureeglid, võit, kaotus, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MINA JA TEISED. KOOSTÖÖ JA MÄNG; KOOSTÖÖ; MÄNGUREEGLID; VÕIT JA KAOTUS; Arutle; LAHENDA
Task examples: Millisel kiigel on hea üksi kiikuda?; Millisel kiigel ei saa üksi kiikuda? Miks?

## Kuidas kuningas EI ütles
URL: https://www.opiq.ee/kit/449/chapter/24921
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.7
Topics ET: matemaatika, kuidas, kuningas, ütles, öelda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas kuningas EI ütles; II; III; Kuidas öelda EI?; Arutle

## MINA ISE. ISESEISVUS
URL: https://www.opiq.ee/kit/449/chapter/24917
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.8
Topics ET: matemaatika, mina, iseseisvus, valikud, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: MINA ISE. ISESEISVUS; VALIKUD; ISESEISVUS; LAHENDA; Arutle
Task examples: Head tuleb teha sellepärast, et ...; Vali lünka õige sõna.

## MIDA TEHA, ET AJU ARENEKS HÄSTI?
URL: https://www.opiq.ee/kit/449/chapter/24918
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 4.9
Topics ET: matemaatika, inimene, keha, meeled, tervis, mida, teha, areneks, hästi, meie, lihased, arutle, soodustab
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MIDA TEHA, ET AJU ARENEKS HÄSTI?; MEIE LIHASED JA AJU; Arutle; MIS SOODUSTAB AJU TÖÖD?; INIMENE ARENEB KOGU ELU; KUIDAS ME OMANDAME EMAKEELE VÕI VÕÕRKEELE?
Task examples: Meie lihased ja aju vajavad, et me neid; Milliseid toite peaks sööma rohkem ja milliseid vähem, et soodustada aju tööd?

## Limonaadimeister ja Kalda Anni moosid
URL: https://www.opiq.ee/kit/449/chapter/24929
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.1
Topics ET: matemaatika, limonaadimeister, kalda, anni, moosid, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Limonaadimeister ja Kalda Anni moosid; II; Arutle

## ILUS EESTIMAA
URL: https://www.opiq.ee/kit/449/chapter/24922
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.2
Topics ET: matemaatika, ilus, eestimaa, linnused, linnamäed, talud, mõisad, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: ILUS EESTIMAA; LINNUSED JA LINNAMÄED; TALUD JA MÕISAD; LAHENDA; Arutle
Task examples: Selles peatükis räägime ...; Uuri hoolega, mida näed taluõue pildil. Märgi, mis on pildil olemas.

## EESTI SÜMBOLID I
URL: https://www.opiq.ee/kit/449/chapter/24923
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.3
Topics ET: matemaatika, eesti, sümbolid, sinine, must, valge, lipp, riigivapp, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: EESTI SÜMBOLID I; SININE JA MUST JA VALGE; EESTI LIPP JA RIIGIVAPP; LAHENDA
Task examples: Eesti Vabariigi aastapäev on ...; Mida on kujutatud suurel riigivapil? Märgi õiged vastused.

## EESTI SÜMBOLID II
URL: https://www.opiq.ee/kit/449/chapter/24924
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.4
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad, eesti, sümbolid, asjad, kivi, lind, lahenda
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: EESTI SÜMBOLID II; EESTI ASJAD; KIVI, LIND JA LILL; LOOM JA PUU; LAHENDA; Arutle
Task examples: Tallinna linnamüür ja tornid on ehitatud ...; Kuidas rahvasuus hunti veel kutsutakse? Vali õiged vastused.

## KÕIGE SUUREMAD RAHVAPEOD
URL: https://www.opiq.ee/kit/449/chapter/24925
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.5
Topics ET: matemaatika, kõige, suuremad, rahvapeod, tähtpäevad, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: KÕIGE SUUREMAD RAHVAPEOD; TÄHTPÄEVAD; RAHVAPEOD; LAHENDA
Task examples: Millisel suurel üritusel võib näha korraga koos kõige rohkem eestlasi?; Kus toimub suur laulupidu?

## KUIDAS VANASTI ELATI? LEIUTISED
URL: https://www.opiq.ee/kit/449/chapter/24926
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.6
Topics ET: matemaatika, kuidas, vanasti, elati, leiutised, kunagi, arutle, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS VANASTI ELATI? LEIUTISED; SEE, MIS KUNAGI OLI; Arutle; LEIUTISED; LAHENDA
Task examples: Uuri hoolega seda vana fotot. Millised jalanõud lastel on?; Lahenda salakiri ja saad teada mõne väga tähtsa leiutise.

## KUIDAS EESTLASED VANASTI ELASID? MAAL
URL: https://www.opiq.ee/kit/449/chapter/24927
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.7
Topics ET: matemaatika, kuidas, eestlased, vanasti, elasid, maal, veski, sepikoda, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS EESTLASED VANASTI ELASID? MAAL; MAAL; VESKI JA SEPIKODA; LAHENDA; Arutle
Task examples: Milline sõiduvahend on talupildil?; Kas lause on õige või vale? Märgi õiged laused.

## KUIDAS EESTLASED VANASTI ELASID LINNAS?
URL: https://www.opiq.ee/kit/449/chapter/24928
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 5.8
Topics ET: matemaatika, kuidas, eestlased, vanasti, elasid, linnas, elas, inimesi, linnaelu
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS EESTLASED VANASTI ELASID LINNAS?; KA VANASTI ELAS OSA INIMESI LINNAS; LINNAELU; LAHENDA
Task examples: Uuri keskaegse linnatänava pilti. Märgi, mis on pildil olemas.; Vali õiged vastused.

## Kuninga rahakukkur
URL: https://www.opiq.ee/kit/449/chapter/24931
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 6.1
Topics ET: matemaatika, kuninga, rahakukkur, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuninga rahakukkur; II; Arutle

## RAHA, ASJAD JA VALIKUD
URL: https://www.opiq.ee/kit/449/chapter/24930
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 6.2
Topics ET: matemaatika, raha, euro, sent, asjad, valikud, vahetuskaup, arutle, kood, planeeri, kulutusi
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: RAHA, ASJAD JA VALIKUD; VAHETUSKAUP; Arutle; PIN-KOOD; PLANEERI OMA KULUTUSI!; RAHA SÄÄSTMINE
Task examples: Soovid osta päkapikult ühe saia. Mitu pikka paid on vaja selleks teha?; Soovid osta päkapikult kaks saia. Mitu pikka paid on vaja selleks teha?

## LAENAMINE, ANDMINE
URL: https://www.opiq.ee/kit/449/chapter/26255
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 6.3
Topics ET: matemaatika, laenamine, andmine, mida, teha
Topics RU: математика
Topics EN: mathematics
Headings: LAENAMINE, ANDMINE; MIDA TEHA?; LAENAMINE
Task examples: Vaata pilti. Kumba raamatut tahaksid sina tagasi saada?; Laenad sõbralt mardilaupäevaks tema suure mütsi. See kukub aga porilompi ja saab mustaks. Millisena peaksid sa järgmisel päeval mütsi tagasi andma?

## LAPSE KOHUSTUSED JA ÕIGUSED
URL: https://www.opiq.ee/kit/449/chapter/26256
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 6.4
Topics ET: matemaatika, lapse, kohustused, õigused, aina, rohkem, õigusi, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LAPSE KOHUSTUSED JA ÕIGUSED; LAPSE ÕIGUSED; AINA ROHKEM ÕIGUSI; LAPSE KOHUSTUSED; LAHENDA
Task examples: Lohista Lasteabi telefoninumber õigesse järjekorda.; Milline lause on õige?

## LAPSE OTSUSED JA VALIKUD
URL: https://www.opiq.ee/kit/449/chapter/26257
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 6.5
Topics ET: matemaatika, lapse, otsused, valikud, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: LAPSE OTSUSED JA VALIKUD; OTSUSED; VALIKUD; LAHENDA; Arutle
Task examples: Kumb tegevus on tervislikum? Kui pead mõlemat tervislikuks, märgi mõlemad.; Kumb tegevus on tervislikum? Kui pead mõlemat tervislikuks, märgi mõlemad.

## See on minu kuningriik!
URL: https://www.opiq.ee/kit/449/chapter/26258
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 6.6
Topics ET: matemaatika, kuningriik, ahoi, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: See on minu kuningriik!; Ahoi!; LAHENDA
Task examples: Leia sõnale seletus.

## TOIMETULEK TUNNETEGA
URL: https://www.opiq.ee/kit/449/chapter/26259
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 7.1
Topics ET: matemaatika, toimetulek, tunnetega, pane, tähele, mida, olukordades, tunned, tunne, tugev
Topics RU: математика
Topics EN: mathematics
Headings: TOIMETULEK TUNNETEGA; PANE TÄHELE; Pane tähele, mida sa eri olukordades tunned.; Minu tunne on nii tugev kui ...; Viha võib olla nagu ...; MILLAL ON RASKE ENNAST KONTROLLIDA?; VIHA TASEMED

## KUIDAS SAADA HAKKAMA KURBUSE JA VIHAGA?
URL: https://www.opiq.ee/kit/449/chapter/26260
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 7.2
Topics ET: matemaatika, kuidas, saada, hakkama, kurbuse, vihaga, kurbusega
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS SAADA HAKKAMA KURBUSE JA VIHAGA?; KUIDAS SAADA HAKKAMA VIHAGA?; KUIDAS SAADA HAKKAMA KURBUSEGA?
Task examples: Kas lause on õige või vale?

## Impressum
URL: https://www.opiq.ee/kit/449/chapter/26261
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_algklassidele,_i_osa._2023_õk
Chapter ID: 8.1
Topics ET: matemaatika, impressum, inimeseõpetuse, õpik, algklassidele
Topics RU: математика
Topics EN: mathematics
Headings: Impressum; Inimeseõpetuse õpik algklassidele

## Veeohutus – Opiq
URL: https://www.opiq.ee/Kit/Details/337
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 88
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, opiq
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water

## Veeohutus – Opiq
URL: https://www.opiq.ee/Kit/Details/337
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 98
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, opiq
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water

## Sissejuhatus
URL: https://www.opiq.ee/kit/337/chapter/18967
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Veekogud
URL: https://www.opiq.ee/kit/337/chapter/18959
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, veekogud, kuidas, tuleks, minna, ujuma, erinevad, põhi, ohud
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Veekogud; KUIDAS TULEKS MINNA UJUMA?; Erinevad veekogud; VEEKOGU PÕHI; OHUD VEEKOGUS; KODUTIIGID JA KRAAVID; MIS MUUDAB SELLE VEEKOGU OHTLIKUKS?; Kaitse ennast päikese eest; KUIDAS SAAB ENNAST KUUMA PÄIKESE EEST KAITSTA?; Mida teen palavaga?; LAPS VEEKOGU ÄÄRES; VAATA PILTI; UJUMA TOHIB MINNA ...; Jätkub

## Paadisild
URL: https://www.opiq.ee/kit/337/chapter/18960
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.3
Topics ET: loodusõpetus, paadisild, paadisillal, alati, väga, ettevaatlik, kuidas, käitun, veekogul, sild
Topics RU: природоведение
Topics EN: science
Headings: Paadisild; Paadisillal ole alati väga ettevaatlik!; KUS ON?; KUIDAS KÄITUN, KUI VEEKOGUL ON SILD?; KES KÄITUB VALESTI?; Jätkub

## Mängud vees ja vee ääres
URL: https://www.opiq.ee/kit/337/chapter/18961
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.4
Topics ET: loodusõpetus, mängud, vees, ääres, ohtlikud, mäng, veemängude, meelespea, jätkub
Topics RU: природоведение
Topics EN: science
Headings: Mängud vees ja vee ääres; Ohtlikud mängud vees; MÄNG; VEEMÄNGUDE MEELESPEA; Jätkub

## Päästevest
URL: https://www.opiq.ee/kit/337/chapter/18962
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.5
Topics ET: loodusõpetus, päästevest, paadisõit, märgi, käituvad, pildil, õigesti, päästevesti, selgapanek, kinnitamine
Topics RU: природоведение
Topics EN: science
Headings: Päästevest; PAADISÕIT; MÄRGI, KES KÄITUVAD PILDIL ÕIGESTI; Päästevesti selgapanek; PÄÄSTEVESTI KINNITAMINE; PÄÄSTEVESTID; Jätkub

## Spaad ja ujulad
URL: https://www.opiq.ee/kit/337/chapter/18963
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.6
Topics ET: loodusõpetus, spaad, ujulad, käitumine, ujulas, käitub, valesti, jätkub
Topics RU: природоведение
Topics EN: science
Headings: Spaad ja ujulad; Käitumine ujulas; KES KÄITUB VALESTI?; Jätkub

## Ujumismadratsid ja pallid
URL: https://www.opiq.ee/kit/337/chapter/18964
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.7
Topics ET: loodusõpetus, ujumismadratsid, pallid, mängida, madratsi, palliga, mängin, palli, jätkub
Topics RU: природоведение
Topics EN: science
Headings: Ujumismadratsid ja pallid; Kus mängida madratsi ja palliga?; KUS MÄNGIDA?; KUS MÄNGIN PALLI?; Jätkub

## Hätta sattumine
URL: https://www.opiq.ee/kit/337/chapter/18965
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.8
Topics ET: loodusõpetus, hätta, sattumine, mida, teha, keegi, satub, kuidas, aitan, hättasattunut
Topics RU: природоведение
Topics EN: science
Headings: Hätta sattumine; Mida teha, kui keegi satub hätta?; KUIDAS AITAN HÄTTASATTUNUT?; 112; MIDA TEHA, KUI KEEGI ON HÄDAS?; Jätkub

## Jää
URL: https://www.opiq.ee/kit/337/chapter/18966
Book: Inimeseõpetus 1 klass
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: veeohutus
Chapter ID: 1.9
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, peal, võib, olla, nõrk, jääle, minek, tagasiside
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Jää; Jää veekogu peal; KUS VÕIB OLLA JÄÄ NÕRK?; JÄÄLE MINEK; Tagasiside

## Безопасность на воде – Opiq
URL: https://www.opiq.ee/Kit/Details/338
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 148
Topics ET: matemaatika, vesi, veeohutus, veekogu, opiq
Topics RU: математика, вода, безопасность на воде, водоём, безопасность, воде
Topics EN: mathematics, water, water safety, body of water

## Безопасность на воде – Opiq
URL: https://www.opiq.ee/Kit/Details/338
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 158
Topics ET: matemaatika, vesi, veeohutus, veekogu, opiq
Topics RU: математика, вода, безопасность на воде, водоём, безопасность, воде
Topics EN: mathematics, water, water safety, body of water

## Введение
URL: https://www.opiq.ee/kit/338/chapter/18997
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, введение
Topics EN: mathematics
Headings: Введение

## Водоёмы
URL: https://www.opiq.ee/kit/338/chapter/18989
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.2
Topics ET: matemaatika, vesi, veeohutus, veekogu
Topics RU: математика, вода, безопасность на воде, водоём, водо, разные, нужно, идти, плавать, опасности, домашние, пруды, канавы
Topics EN: mathematics, water, water safety, body of water
Headings: Водоёмы; Разные водоёмы; КАК НУЖНО ИДТИ ПЛАВАТЬ?; ДНО ВОДОЁМА; ОПАСНОСТИ В ВОДОЁМЕ; ДОМАШНИЕ ПРУДЫ И КАНАВЫ; ПОЧЕМУ ЕЩЕ ВОДОЁМ МОЖЕТ БЫТЬ ОПАСНЫМ?; Береги себя от солнца; КАК ЗАЩИТИТЬ СЕБЯ ОТ ПАЛЯЩЕГО СОЛНЦА?; Что нужно делать в жару?; РЕБЕНОК У ВОДЫ; ПОСМОТРИ РИСУНКИ; КУПАТЬСЯ МОЖНО ТОЛЬКО...; Продолжение

## Мостки
URL: https://www.opiq.ee/kit/338/chapter/18990
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, мостки, всегда, соблюдай, осторожность, мостках, делать, если, водо, есть
Topics EN: mathematics
Headings: Мостки; Всегда соблюдай осторожность на мостках!; ГДЕ?; ЧТО ДЕЛАТЬ, ЕСЛИ НА ВОДОЁМЕ ЕСТЬ МОСТКИ?; КТО ПОСТУПАЕТ НЕПРАВИЛЬНО?; Продолжение

## Игры в воде и у воды
URL: https://www.opiq.ee/kit/338/chapter/18991
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, игры, воде, воды, опасные, игра, памятка, играх, продолжение
Topics EN: mathematics
Headings: Игры в воде и у воды; Опасные игры в воде; ИГРА; ПАМЯТКА ОБ ИГРАХ НА ВОДЕ; Продолжение

## Спасательный жилет
URL: https://www.opiq.ee/kit/338/chapter/18992
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, спасательный, жилет, катание, лодках, отметь, картинке, себя, правильно, надевание
Topics EN: mathematics
Headings: Спасательный жилет; КАТАНИЕ НА ЛОДКАХ; ОТМЕТЬ НА КАРТИНКЕ, КТО ВЕДЁТ СЕБЯ ПРАВИЛЬНО; Надевание спасательного жилета; ЗАСТЁГИВАНИЕ СПАСАТЕЛЬНОГО ЖИЛЕТА; СПАСАТЕЛЬНЫЕ ЖИЛЕТЫ; Продолжение

## Спа и бассейны
URL: https://www.opiq.ee/kit/338/chapter/18993
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, бассейны, поведение, бассейне, поступает, неправильно, продолжение
Topics EN: mathematics
Headings: Спа и бассейны; Поведение в бассейне; КТО ПОСТУПАЕТ НЕПРАВИЛЬНО?; Продолжение

## Надувные матрасы и мячи
URL: https://www.opiq.ee/kit/338/chapter/18994
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.7
Topics ET: matemaatika
Topics RU: математика, надувные, матрасы, мячи, играть, матрасом, мячом, продолжение
Topics EN: mathematics
Headings: Надувные матрасы и мячи; Где играть с матрасом и мячом?; ГДЕ ИГРАТЬ?; ГДЕ ИГРАТЬ В МЯЧ?; Продолжение

## Если кто-то попал в беду
URL: https://www.opiq.ee/kit/338/chapter/18995
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.8
Topics ET: matemaatika
Topics RU: математика, если, попал, беду, делать, помочь, тому, продолжение
Topics EN: mathematics
Headings: Если кто-то попал в беду; Что делать, если кто-то попал в беду?; КАК ПОМОЧЬ ТОМУ, КТО ПОПАЛ В БЕДУ?; 112; Продолжение

## Лёд
URL: https://www.opiq.ee/kit/338/chapter/18996
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: безопасность_на_воде
Chapter ID: 1.9
Topics ET: matemaatika
Topics RU: математика, водо, может, быть, тонким, выход, отзывы
Topics EN: mathematics
Headings: Лёд; Лёд на водоёме; ГДЕ ЛЁД МОЖЕТ БЫТЬ ТОНКИМ?; ВЫХОД НА ЛЁД; Отзывы

## Inimeseõpetus algklassidele. I osa – Opiq
URL: https://www.opiq.ee/Kit/Details/540
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 99
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus algklassidele. I osa – Opiq
URL: https://www.opiq.ee/Kit/Details/540
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 147
Topics ET: matemaatika, inimeseõpetus, algklassidele, opiq
Topics RU: математика
Topics EN: mathematics

## Setumaa kuningas
URL: https://www.opiq.ee/kit/540/chapter/29925
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.1
Topics ET: matemaatika, setumaa, kuningas, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Setumaa kuningas; II; III; Arutle

## ME ELAME EESTIS
URL: https://www.opiq.ee/kit/540/chapter/29918
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.2
Topics ET: matemaatika, elame, eestis, eesti, vabariik, keel, arutle
Topics RU: математика
Topics EN: mathematics
Headings: ME ELAME EESTIS; EESTI VABARIIK; EESTI KEEL; ISA-EMA MAA; Arutle
Task examples: ВЫБЕРИ ПРАВИЛЬНОЕ СЛОВО.; VALI LÜNKA ÕIGE SÕNA.

## LIIKLUS JA LIIKLEMINE. I
URL: https://www.opiq.ee/kit/540/chapter/29919
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.3
Topics ET: matemaatika, liiklus, liiklemine, arutle, kõnniteel, lahenda
Topics RU: математика, подумай
Topics EN: mathematics
Headings: LIIKLUS JA LIIKLEMINE. I; LIIKLUS; Arutle; LIIKLEMINE KÕNNITEEL; Подумай; LAHENDA
Task examples: КОГДА ИДЁШЬ ПО УЛИЦЕ, СЛЕДИ...; TÄNAVAL LIIKUDES JÄLGI

## LIIKLUS JA LIIKLEMINE. II
URL: https://www.opiq.ee/kit/540/chapter/29920
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.4
Topics ET: matemaatika, liiklus, liiklemine, sõidutee, ületamine, kiirusta, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS JA LIIKLEMINE. II; SÕIDUTEE ÜLETAMINE; ÄRA KIIRUSTA!; LAHENDA
Task examples: КАК НУЖНО ПЕРЕХОДИТЬ ДОРОГУ? РАССТАВЬ ДЕЙСТВИЯ В ПРАВИЛЬНОМ ПОРЯДКЕ.; KUIDAS ÜLETAD TEED? LOHISTA TEGEVUSED ÕIGESSE JÄRJEKORDA.

## LIIKLUS JA OHUTUS. I
URL: https://www.opiq.ee/kit/540/chapter/29921
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.5
Topics ET: matemaatika, liiklus, ohutus, turvavöö, arutle, sõidukist, väljumine
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS JA OHUTUS. I; TURVAVÖÖ; Arutle; SÕIDUKIST VÄLJUMINE
Task examples: РАССМОТРИ КАРТИНКУ. КТО СИДИТ ПРАВИЛЬНО? ОТМЕТЬ ЭТИХ ПАССАЖИРОВ.; UURI PILTI. KES ISTUB ÕIGESTI? MÄRGI.

## LIIKLUS JA OHUTUS. II
URL: https://www.opiq.ee/kit/540/chapter/29922
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.6
Topics ET: matemaatika, liiklus, ohutus, liikumine, pimedas, nähtav, arutle, jalgratas
Topics RU: математика
Topics EN: mathematics
Headings: LIIKLUS JA OHUTUS. II; LIIKUMINE PIMEDAS. OLE NÄHTAV!; Arutle; JALGRATAS JA TÕUKERATAS; У велосипеда и электросамоката должны быть:; ​Jalgrattal ja elektritõukerattal ​peavad olema:; LAHENDA
Task examples: КУДА НУЖНО ПРИКРЕПЛЯТЬ ОТРАЖАТЕЛИ? ВЫБЕРИ ПРАВИЛЬНЫЕ ВАРИАНТЫ ОТВЕТА.; MILLE KÜLGE TULEB HELKURID KINNITADA? VALI ÕIGED VASTUSED.

## ÜKSI KODUS JA ÕUES
URL: https://www.opiq.ee/kit/540/chapter/29923
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.7
Topics ET: matemaatika, üksi, kodus, õues, mida, teha, mulle, meeldib
Topics RU: математика
Topics EN: mathematics
Headings: ÜKSI KODUS JA ÕUES; MIDA ÜKSI TEHA?; MULLE MEELDIB; LAHENDA; Arutle
Task examples: КОМУ НРАВИТСЯ ЧИТАТЬ КНИГИ О ДАЛЬНИХ СТРАНАХ И ИСТОРИИ?; KES LOEB MEELELDI AJALOOST JA KAUGETEST MAADEST?

## AEG JA AJATAJU
URL: https://www.opiq.ee/kit/540/chapter/29924
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 1.8
Topics ET: matemaatika, aeg, kell, kalender, ajataju, kuidas, läheb, õige, lahenda, arutle
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: AEG JA AJATAJU; KUIDAS LÄHEB AEG?; KAS ON ÕIGE AEG?; LAHENDA; Arutle
Task examples: ЧТО СОБИРАЮТСЯ ДЕЛАТЬ ДЕТИ?; MIDA KAVATSEVAD LAPSED TEHA?

## Igaühel oma pesa
URL: https://www.opiq.ee/kit/540/chapter/29932
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 2.1
Topics ET: matemaatika, igaühel, pesa, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Igaühel oma pesa; II; Arutle

## PERE
URL: https://www.opiq.ee/kit/540/chapter/29926
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 2.2
Topics ET: matemaatika, pere, arutle, omad, kombed, mida, teeb
Topics RU: математика
Topics EN: mathematics
Headings: PERE; KES ON PERE?; Arutle; OMAD KOMBED; KES MIDA TEEB?
Task examples: КАКИЕ ПОДАРКИ МОЖНО СДЕЛАТЬ СВОИМИ РУКАМИ?; MILLISEID KINGITUSI SAAB ISE VALMISTADA? MÄRGI.

## SUGULASED
URL: https://www.opiq.ee/kit/540/chapter/29927
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 2.3
Topics ET: matemaatika, sugulased, lähemad, suur, väike
Topics RU: математика, старший, брат, подумай
Topics EN: mathematics
Headings: SUGULASED; LÄHEMAD SUGULASED; SUUR VÕI VÄIKE; Старший брат; Подумай; Arutle; SUGUPUU; LAHENDA
Task examples: ВЕРНЫ ЛИ ДАННЫЕ УТВЕРЖДЕНИЯ?; KAS LAUSE ON ÕIGE VÕI VALE?

## MINA JA PÄRILIKKUS
URL: https://www.opiq.ee/kit/540/chapter/29928
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 2.4
Topics ET: matemaatika, mina, pärilikkus, kelle, moodi, mida, pärime
Topics RU: математика, подумай
Topics EN: mathematics
Headings: MINA JA PÄRILIKKUS; KELLE MOODI?; MIDA ME PÄRIME?; Подумай; Arutle
Task examples: НЕКОТОРЫЕ ВНЕШНИЕ ЧЕРТЫ МЫ НАСЛЕДУЕМ ОТ...; OSA OMA VÄLIMUSEST PÄRIME

## KODU
URL: https://www.opiq.ee/kit/540/chapter/29929
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 2.5
Topics ET: matemaatika, kodu, tilluke, suur, hoolitse, eest, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: KODU; TILLUKE VÕI SUUR?; HOOLITSE KODU EEST; LAHENDA; Arutle
Task examples: ЧТО ЕСТЬ В ЛЮБОМ ДОМЕ? ВЫБЕРИ ПОДХОДЯЩИЕ ОТВЕТЫ.; MIS PEAB KODUL KINDLASTI OLEMA? MÄRGI.

## LEMMIK­LOOMAD. KOER
URL: https://www.opiq.ee/kit/540/chapter/29930
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 2.6
Topics ET: matemaatika, loom, loomad, linnud, putukad, lemmik, koer, kõige, vanem, koduloom, lahenda
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: LEMMIK­LOOMAD. KOER; KOER; KÕIGE VANEM KODULOOM; LAHENDA
Task examples: Выбери правильный ответ.; Выбери правильный ответ.

## LEMMIK­LOOMAD. KASS
URL: https://www.opiq.ee/kit/540/chapter/29931
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 2.7
Topics ET: matemaatika, loom, loomad, linnud, putukad, lemmik, kass, arutle, isepäine
Topics RU: математика, животное, животные, птицы, насекомые, подумай
Topics EN: mathematics, animal, animals, birds, insects
Headings: LEMMIK­LOOMAD. KASS; KASS; Подумай; Arutle; ISEPÄINE LOOM; LAHENDA
Task examples: Выбери правильный ответ.; Выбери правильный ответ.

## Varbad ja nina
URL: https://www.opiq.ee/kit/540/chapter/29936
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 3.1
Topics ET: matemaatika, varbad, nina, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Varbad ja nina; Arutle

## MINU TERVIS. I
URL: https://www.opiq.ee/kit/540/chapter/29933
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 3.2
Topics ET: matemaatika, inimene, keha, meeled, tervis, kuidas, püsida, terve, ilmaga, sobivad, riided
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MINU TERVIS. I; KUIDAS PÜSIDA TERVE?; ILMAGA SOBIVAD RIIDED; Arutle
Task examples: Mida teha, et oleksime terved? Ühenda paari.; Что нужно делать, чтобы оставаться здоровым? Соедини пары.

## MINU TERVIS. II
URL: https://www.opiq.ee/kit/540/chapter/29934
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 3.3
Topics ET: matemaatika, inimene, keha, meeled, tervis, pisikud, kätepesu, hambapesu
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: MINU TERVIS. II; PISIKUD; KÄTEPESU; HAMBAPESU
Task examples: Микробы можно увидеть...; Микробы можно увидеть...

## TERVIS. NUTIKAD ABIVAHENDID
URL: https://www.opiq.ee/kit/540/chapter/29935
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 3.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, nutikad, abivahendid, lisa, tänaval, arutle, punktkiri
Topics RU: математика, человек, тело, чувства, здоровье, приложение, подумай
Topics EN: mathematics, human, body, senses, health
Headings: TERVIS. NUTIKAD ABIVAHENDID; ABIVAHENDID; Приложение; Lisa; ABIVAHENDID TÄNAVAL; Подумай; Arutle; PUNKTKIRI; VIIPEKEEL
Task examples: Nuputa, mis on laste nimed.Как зовут детей?; Väiksed labradorikutsikad lähevad peagi koertekooli ja õpivad juhtkoerteks. Nuputa, mis on nende nimed.Два щенка лабрадора ходят в специальную школу для собак, чтобы стать собаками-поводырями. Как их зовут? Напиши их име

## Head kombed
URL: https://www.opiq.ee/kit/540/chapter/29945
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.1
Topics ET: matemaatika, head, kombed, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Head kombed; II; III; Arutle

## ÕPPIMIS­NÕKSUD
URL: https://www.opiq.ee/kit/540/chapter/29944
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.10
Topics ET: matemaatika, õppimis, nõksud, harjutamine, teeb, meistriks, eesmärgid, meisterlikkuseni
Topics RU: математика
Topics EN: mathematics
Headings: ÕPPIMIS­NÕKSUD; HARJUTAMINE TEEB MEISTRIKS!; EESMÄRGID; TEE MEISTERLIKKUSENI; Arutle
Task examples: Vali lünka õige sõna.; Vali lünka õige sõna.

## EMOTSIOONID. I
URL: https://www.opiq.ee/kit/540/chapter/29937
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.2
Topics ET: matemaatika, emotsioonid, mõtle, mõistan, teisi, arutle, lahenda
Topics RU: математика, подумай
Topics EN: mathematics
Headings: EMOTSIOONID. I; MIS ON EMOTSIOONID?; Подумай; Mõtle; MÕISTAN TEISI; Arutle; LAHENDA
Task examples: Каким будет выражение лица при данных эмоциях?; Milline on eri emotsioonide puhul näoilme?

## EMOTSIOONID. II
URL: https://www.opiq.ee/kit/540/chapter/29938
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.3
Topics ET: matemaatika, emotsioonid, erinevad, olukorrad, arutle, teeselda, pole, vaja
Topics RU: математика, подумай
Topics EN: mathematics
Headings: EMOTSIOONID. II; ERINEVAD OLUKORRAD; Подумай; Arutle; TEESELDA POLE VAJA; LAHENDA
Task examples: Какая собака хочет, чтобы её погладили? А какая не хочет? Почему ты так решил?; Kumb koer soovib pai saada? Kumb mitte? Mis sa arvad, miks?

## ENESE JA TEISTE TUNDMINE. ISELOOM
URL: https://www.opiq.ee/kit/540/chapter/29939
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.4
Topics ET: matemaatika, enese, teiste, tundmine, iseloom, omadused, arutle
Topics RU: математика, подумай
Topics EN: mathematics
Headings: ENESE JA TEISTE TUNDMINE. ISELOOM; ISELOOM; OMADUSED; Подумай; Arutle; LAHENDA
Task examples: О ком или о чём говорит это стихотворение?; Millest või kellest see luuletus räägib?

## SUHTLEMINE. KEEL JA KEHAKEEL
URL: https://www.opiq.ee/kit/540/chapter/29940
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.5
Topics ET: matemaatika, inimene, keha, meeled, tervis, suhtlemine, keel, kehakeel, reedab, salamõtteid
Topics RU: математика, человек, тело, чувства, здоровье, язык, тела
Topics EN: mathematics, human, body, senses, health
Headings: SUHTLEMINE. KEEL JA KEHAKEEL; KEEL; KEHA REEDAB SALAMÕTTEID!; ЯЗЫК ТЕЛА; KEHAKEEL; TEHISKEEL; ЯЗЫК ЗНАКОВ; SUHELDA SAAB KA PILTIDEGA; Подумай; Arutle; LAHENDA
Task examples: Püüa aru saada laste kehakeelest. Kes ütleb EI ja kes JAA?Попробуй понять язык тела этих детей. Кто говорит «да», а кто «нет»?; Püüa aru saada laste kehakeelest. Kes ütleb EI ja kes JAA?Попробуй понять язык тела этих детей. Кто говорит «да», а кто «нет»?

## MINA JA TEISED. KOOSTÖÖ JA MÄNG
URL: https://www.opiq.ee/kit/540/chapter/29941
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.6
Topics ET: matemaatika, mina, teised, koostöö, mäng, mängureeglid, võit, kaotus
Topics RU: математика
Topics EN: mathematics
Headings: MINA JA TEISED. KOOSTÖÖ JA MÄNG; KOOSTÖÖ; MÄNGUREEGLID; VÕIT JA KAOTUS; Подумай; Arutle; LAHENDA
Task examples: Какие качели можно раскачать сильнее всего? Почему?; Millisel kiigel on kõige suurem hoog? Miks?

## Kuidas kuningas EI ütles
URL: https://www.opiq.ee/kit/540/chapter/29946
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.7
Topics ET: matemaatika, kuidas, kuningas, ütles, öelda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas kuningas EI ütles; II; III; Kuidas öelda EI?; Arutle

## MINA ISE. ISESEISVUS
URL: https://www.opiq.ee/kit/540/chapter/29942
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.8
Topics ET: matemaatika, mina, iseseisvus, valikud
Topics RU: математика, выбор, является, хорошим, если
Topics EN: mathematics
Headings: MINA ISE. ISESEISVUS; VALIKUD; Выбор является хорошим, если:; Sinu valik on hea, kui:; ISESEISVUS; Мечта Кена; Keni unistus; LAHENDA; Arutle
Task examples: Следует поступать хорошо, потому что ...; Head tuleb teha sellepärast, et ...

## MIDA TEHA, ET AJU ARENEKS HÄSTI?
URL: https://www.opiq.ee/kit/540/chapter/29943
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 4.9
Topics ET: matemaatika, inimene, keha, meeled, tervis, mida, teha, areneks, hästi, meie, lihased
Topics RU: математика, человек, тело, чувства, здоровье, подумай
Topics EN: mathematics, human, body, senses, health
Headings: MIDA TEHA, ET AJU ARENEKS HÄSTI?; MEIE LIHASED JA AJU; Подумай; Arutle; MIS SOODUSTAB AJU TÖÖD?; INIMENE ARENEB KOGU ELU; KUIDAS ME OMANDAME EMAKEELE VÕI VÕÕRKEELE?
Task examples: Наши мозг и мышцы нуждаются в том, чтобы мы их...; Meie lihased ja aju vajavad, et me neid

## Limonaadimeister ja Kalda Anni moosid
URL: https://www.opiq.ee/kit/540/chapter/29954
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.1
Topics ET: matemaatika, limonaadimeister, kalda, anni, moosid, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Limonaadimeister ja Kalda Anni moosid; II; Arutle

## ILUS EESTIMAA
URL: https://www.opiq.ee/kit/540/chapter/29947
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.2
Topics ET: matemaatika, ilus, eestimaa, linnused, linnamäed, talud, mõisad, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: ILUS EESTIMAA; LINNUSED JA LINNAMÄED; TALUD JA MÕISAD; LAHENDA; Arutle
Task examples: В этой главе мы поговорим о...; Selles peatükis räägime ...

## EESTI SÜMBOLID I
URL: https://www.opiq.ee/kit/540/chapter/29948
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.3
Topics ET: matemaatika, eesti, sümbolid, sinine, must, valge, lipp, riigivapp
Topics RU: математика
Topics EN: mathematics
Headings: EESTI SÜMBOLID I; SININE JA MUST JA VALGE; EESTI LIPP JA RIIGIVAPP; LAHENDA
Task examples: День независимости Эстонии ...; Eesti Vabariigi aastapäev on ...

## EESTI SÜMBOLID II
URL: https://www.opiq.ee/kit/540/chapter/29949
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.4
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad, eesti, sümbolid, eripära, kivi, lind
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: EESTI SÜMBOLID II; EESTI ERIPÄRA; KIVI, LIND JA LILL; LOOM JA PUU; LAHENDA; Arutle
Task examples: Крепостные стены и сторожевые башни Таллинна построены из...; Tallinna linnamüür ja tornid on ehitatud ...

## KÕIGE SUUREMAD RAHVAPEOD
URL: https://www.opiq.ee/kit/540/chapter/29950
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.5
Topics ET: matemaatika, kõige, suuremad, rahvapeod, tähtpäevad, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: KÕIGE SUUREMAD RAHVAPEOD; TÄHTPÄEVAD; RAHVAPEOD; LAHENDA
Task examples: На каком мероприятии можно одновременно увидеть наибольшее количество эстонцев?; Millisel suurel üritusel võib näha korraga koos kõige rohkem eestlasi?

## KUIDAS VANASTI ELATI? LEIUTISED
URL: https://www.opiq.ee/kit/540/chapter/29951
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.6
Topics ET: matemaatika, kuidas, vanasti, elati, leiutised, kunagi, arutle
Topics RU: математика, подумай
Topics EN: mathematics
Headings: KUIDAS VANASTI ELATI? LEIUTISED; SEE, MIS KUNAGI OLI; Подумай; Arutle; LEIUTISED; LAHENDA; *Задание 2
Task examples: Внимательно рассмотри старую фотографию в учебнике. Какую обувь носят дети?; Uuri hoolega seda vana fotot. Millised jalanõud lastel on?

## KUIDAS EESTLASED VANASTI ELASID MAAL?
URL: https://www.opiq.ee/kit/540/chapter/29952
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.7
Topics ET: matemaatika, kuidas, eestlased, vanasti, elasid, maal, veski, sepikoda
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS EESTLASED VANASTI ELASID MAAL?; MAAL; VESKI JA SEPIKODA; LAHENDA; Arutle
Task examples: Какое транспортное средство изображено на картинке?; Milline sõiduvahend on talupildil?

## KUIDAS EESTLASED VANASTI ELASID LINNAS?
URL: https://www.opiq.ee/kit/540/chapter/29953
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 5.8
Topics ET: matemaatika, kuidas, eestlased, vanasti, elasid, linnas, elas, inimesi
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS EESTLASED VANASTI ELASID LINNAS?; KA VANASTI ELAS OSA INIMESI LINNAS; LINNAELU; LAHENDA
Task examples: Рассмотри рисунок средневековой городской улицы. Что ты на нём видишь?; Uuri keskaegse linnatänava pilti. Märgi, mis on pildil olemas.

## Kuninga rahakukkur
URL: https://www.opiq.ee/kit/540/chapter/29960
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 6.1
Topics ET: matemaatika, kuninga, rahakukkur, arutle
Topics RU: математика
Topics EN: mathematics
Headings: Kuninga rahakukkur; II; Arutle

## RAHA, ASJAD JA VALIKUD
URL: https://www.opiq.ee/kit/540/chapter/29955
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 6.2
Topics ET: matemaatika, raha, euro, sent, asjad, valikud, vahetuskaup, arutle, kood, planeeri
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: RAHA, ASJAD JA VALIKUD; VAHETUSKAUP; Arutle; PIN-KOOD; PLANEERI OMA KULUTUSI!; RAHA SÄÄSTMINE
Task examples: Ты хочешь купить у гномика одну буханку. Сколько раз ты должен его погладить по голове?; Soovid osta päkapikult ühe saia. Mitu pikka paid on vaja selleks teha?

## LAENAMINE, ANDMINE
URL: https://www.opiq.ee/kit/540/chapter/29956
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 6.3
Topics ET: matemaatika, laenamine, andmine, mida, teha
Topics RU: математика
Topics EN: mathematics
Headings: LAENAMINE, ANDMINE; MIDA TEHA?; LAENAMINE
Task examples: Kumba raamatut tahaksid sina tagasi saada?Какую книгу ты хотел бы получить обратно?; Для празднования Мартова дня ты одолжил у друга его шапку. Но шапка упала в лужу и испачкалась. Как вернуть её на следующий день?

## LAPSE KOHUSTUSED JA ÕIGUSED
URL: https://www.opiq.ee/kit/540/chapter/29957
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 6.4
Topics ET: matemaatika, lapse, kohustused, õigused, laste, olulisemad
Topics RU: математика, основные, права
Topics EN: mathematics
Headings: LAPSE KOHUSTUSED JA ÕIGUSED; LAPSE ÕIGUSED; Основные права ребёнка; Laste olulisemad õigused; AINA ROHKEM ÕIGUSI; LAPSE KOHUSTUSED; Основные обязанности ребёнка; Lapse tähtsamad kohustused; LAHENDA
Task examples: У ребёнка есть право...; У ребёнка есть право...

## LAPSE OTSUSED JA VALIKUD
URL: https://www.opiq.ee/kit/540/chapter/29958
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 6.5
Topics ET: matemaatika, lapse, otsused, valikud, lahenda, arutle
Topics RU: математика
Topics EN: mathematics
Headings: LAPSE OTSUSED JA VALIKUD; OTSUSED; VALIKUD; LAHENDA; Заданиe 3; Arutle
Task examples: Kumb tegevus on tervislikum? Kui pead mõlemat tervislikuks, märgi mõlemad.; Kumb tegevus on tervislikum? Kui pead mõlemat tervislikuks, märgi mõlemad.

## See on minu kuningriik!
URL: https://www.opiq.ee/kit/540/chapter/29959
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 6.6
Topics ET: matemaatika, kuningriik, ahoi, lahenda
Topics RU: математика
Topics EN: mathematics
Headings: See on minu kuningriik!; Ahoi!; LAHENDA
Task examples: Соедини слово и его толкование.; Leia sõnale seletus.

## TOIMETULEK TUNNETEGA
URL: https://www.opiq.ee/kit/540/chapter/29961
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 7.1
Topics ET: matemaatika, toimetulek, tunnetega, pane, tähele, mida, olukordades, tunned, tunne, tugev
Topics RU: математика
Topics EN: mathematics
Headings: TOIMETULEK TUNNETEGA; PANE TÄHELE; Pane tähele, mida sa eri olukordades tunned.; Minu tunne on nii tugev kui...; Гнев может быть похож на...; Viha võib olla nagu ...; MILLAL ON RASKE ENNAST KONTROLLIDA?; VIHA TASEMED

## KUIDAS SAADA HAKKAMA KURBUSE JA VIHAGA?
URL: https://www.opiq.ee/kit/540/chapter/29962
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 7.2
Topics ET: matemaatika, kuidas, saada, hakkama, kurbuse, vihaga, kurbusega
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS SAADA HAKKAMA KURBUSE JA VIHAGA?; KUIDAS SAADA HAKKAMA VIHAGA?; KUIDAS SAADA HAKKAMA KURBUSEGA?
Task examples: Kas lause on õige või vale?; Kas lause on õige või vale?

## Определения
URL: https://www.opiq.ee/kit/540/chapter/29963
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 8.1
Topics ET: matemaatika
Topics RU: математика, определения
Topics EN: mathematics
Headings: Определения

## Импрессум
URL: https://www.opiq.ee/kit/540/chapter/29964
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i
Chapter ID: 8.2
Topics ET: matemaatika, inimeseõpetuse, õpik, algklassidele
Topics RU: математика, импрессум, человековедение, начальных, классов
Topics EN: mathematics
Headings: Импрессум; Inimeseõpetuse õpik algklassidele Человековедение для начальных классов

## Человеко­ведение для начальной школы. Часть I – Opiq
URL: https://www.opiq.ee/Kit/Details/541
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 159
Topics ET: matemaatika, opiq
Topics RU: математика, человеко, ведение, начальной, школы, часть
Topics EN: mathematics

## Человеко­ведение для начальной школы. Часть I – Opiq
URL: https://www.opiq.ee/Kit/Details/541
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 206
Topics ET: matemaatika, opiq
Topics RU: математика, человеко, ведение, начальной, школы, часть
Topics EN: mathematics

## Король Сетумаа
URL: https://www.opiq.ee/kit/541/chapter/29972
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, король, сетумаа, подумай
Topics EN: mathematics
Headings: Король Сетумаа; II; III; Подумай

## МЫ ЖИВЁМ В ЭСТОНИИ
URL: https://www.opiq.ee/kit/541/chapter/29965
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, эстонии, эстонская, республика, эстонский, язык, подумай
Topics EN: mathematics
Headings: МЫ ЖИВЁМ В ЭСТОНИИ; ЭСТОНСКАЯ РЕСПУБЛИКА; ЭСТОНСКИЙ ЯЗЫК; ISA-EMA MAA; Подумай
Task examples: ВЫБЕРИ ПРАВИЛЬНОЕ СЛОВО.; В ЭТОМ СТИХОТВОРЕНИИ ГОВОРИТСЯ...

## ДОРОЖНОЕ ДВИЖЕНИЕ. I
URL: https://www.opiq.ee/kit/541/chapter/29966
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, дорожное, движение, подумай, тротуару, выполни
Topics EN: mathematics
Headings: ДОРОЖНОЕ ДВИЖЕНИЕ. I; ДОРОЖНОЕ ДВИЖЕНИЕ; Подумай; ДВИЖЕНИЕ ПО ТРОТУАРУ; ВЫПОЛНИ
Task examples: КОГДА ИДЁШЬ ПО УЛИЦЕ, СЛЕДИ...; ПО КАКИМ ДОРОГАМ ТЫ МОЖЕШЬ ЕЗДИТЬ НА ВЕЛОСИПЕДЕ? ОТМЕТЬ ПРАВИЛЬНЫЕ ВАРИАНТЫ ОТВЕТА.

## ДОРОЖНОЕ ДВИЖЕНИЕ. II
URL: https://www.opiq.ee/kit/541/chapter/29967
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, дорожное, движение, переходим, дорогу, торопись, подумай, выполни
Topics EN: mathematics
Headings: ДОРОЖНОЕ ДВИЖЕНИЕ. II; ПЕРЕХОДИМ ДОРОГУ; НЕ ТОРОПИСЬ!; Подумай; ВЫПОЛНИ
Task examples: КАК НУЖНО ПЕРЕХОДИТЬ ДОРОГУ? РАСПОЛОЖИ ДЕЙСТВИЯ В ПРАВИЛЬНОМ ПОРЯДКЕ.; ЧТО ОЗНАЧАЮТ ЭТИ ЗНАКИ ДОРОЖНОГО ДВИЖЕНИЯ? СОЕДИНИ КАРТИНКУ И ЗНАЧЕНИЕ.

## ДОРОЖНОЕ ДВИЖЕНИЕ И БЕЗОПАС­НОСТЬ. I
URL: https://www.opiq.ee/kit/541/chapter/29968
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, дорожное, движение, безопас, ность, ремень, безопасности, подумай, выходим
Topics EN: mathematics
Headings: ДОРОЖНОЕ ДВИЖЕНИЕ И БЕЗОПАС­НОСТЬ. I; РЕМЕНЬ БЕЗОПАСНОСТИ; Подумай; ВЫХОДИМ ИЗ ТРАНСПОРТА
Task examples: РАССМОТРИ КАРТИНКУ. КТО СИДИТ ПРАВИЛЬНО? ОТМЕТЬ ЭТИХ ПАССАЖИРОВ.; СКОЛЬКО НА КАРТИНКЕ:

## ДОРОЖНОЕ ДВИЖЕНИЕ И БЕЗОПАС­НОСТЬ. II
URL: https://www.opiq.ee/kit/541/chapter/29969
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.6
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, дорожное, движение, безопас, ность, темное, будь, заметным
Topics EN: mathematics, time, clock, calendar
Headings: ДОРОЖНОЕ ДВИЖЕНИЕ И БЕЗОПАС­НОСТЬ. II; ДВИЖЕНИЕ В ТЕМНОЕ ВРЕМЯ. БУДЬ ЗАМЕТНЫМ!; Подумай; ВЕЛОСИПЕД И САМОКАТ; ВЫПОЛНИ
Task examples: КУДА НУЖНО ПРИКРЕПЛЯТЬ ОТРАЖАТЕЛИ? ВЫБЕРИ ПРАВИЛЬНЫЕ ВАРИАНТЫ ОТВЕТА.; ВЫБЕРИ ПРАВИЛЬНОЕ СЛОВО.

## ОДИН ДОМА И НА УЛИЦЕ
URL: https://www.opiq.ee/kit/541/chapter/29970
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.7
Topics ET: matemaatika
Topics RU: математика, один, дома, улице, заняться, одиночестве, нравится, выполни, подумай
Topics EN: mathematics
Headings: ОДИН ДОМА И НА УЛИЦЕ; ЧЕМ ЗАНЯТЬСЯ В ОДИНОЧЕСТВЕ?; МНЕ НРАВИТСЯ; ВЫПОЛНИ; Подумай
Task examples: КОМУ НРАВИТСЯ ЧИТАТЬ КНИГИ О ДАЛЬНИХ СТРАНАХ И ИСТОРИИ?; ЧТО МОЖНО ДЕЛАТЬ В ОДИНОЧЕСТВЕ? ДЛЯ ЧЕГО НУЖНЫ ДРУЗЬЯ? РАЗДЕЛИ СЛОВА И СОЧЕТАНИЯ СЛОВ НА ДВЕ ГРУППЫ.

## ВРЕМЯ И КАК МЫ ЕГО ОЩУЩАЕМ
URL: https://www.opiq.ee/kit/541/chapter/29971
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 1.8
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, ощущаем, вовремя, выполни, подумай
Topics EN: mathematics, time, clock, calendar
Headings: ВРЕМЯ И КАК МЫ ЕГО ОЩУЩАЕМ; KАК ТЕЧЁТ ВРЕМЯ?; ВОВРЕМЯ ИЛИ НЕ ВОВРЕМЯ?; ВЫПОЛНИ; Подумай
Task examples: ЧТО СОБИРАЮТСЯ ДЕЛАТЬ ДЕТИ?; ЧТО МОЖНО СДЕЛАТЬ ЗА ПЯТЬ МИНУТ, А ЧТО – ЗА ЧАС?

## У каждого своё гнездо
URL: https://www.opiq.ee/kit/541/chapter/29979
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, каждого, гнездо, подумай
Topics EN: mathematics
Headings: У каждого своё гнездо; II; Подумай

## СЕМЬЯ
URL: https://www.opiq.ee/kit/541/chapter/29973
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, семья, такое, подумай, семейные, традиции, делает
Topics EN: mathematics
Headings: СЕМЬЯ; ЧТО ТАКОЕ СЕМЬЯ?; Подумай; СЕМЕЙНЫЕ ТРАДИЦИИ; КТО ЧТО ДЕЛАЕТ?
Task examples: КАКИЕ ПОДАРКИ МОЖНО СДЕЛАТЬ СВОИМИ РУКАМИ?; НАЙДИ В СЕТКЕ БУКВ НАЗВАНИЯ БЫТОВЫХ ПРИБОРОВ И ПРЕДМЕТОВ ДОМАШНЕЙ УТВАРИ И САДОВОГО ИНВЕНТАРЯ. КАКИМИ ИЗ НИХ ТЫ УМЕЕШЬ ПОЛЬЗОВАТЬСЯ?

## РОДСТВЕН­НИКИ
URL: https://www.opiq.ee/kit/541/chapter/29974
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, родствен, ники, близкие, родственники, большие, маленькие, старший, брат
Topics EN: mathematics
Headings: РОДСТВЕН­НИКИ; БЛИЗКИЕ РОДСТВЕННИКИ; БОЛЬШИЕ И МАЛЕНЬКИЕ; Старший брат; Подумай; РОДОСЛОВНОЕ ДРЕВО; ВЫПОЛНИ
Task examples: ВЕРНЫ ЛИ ДАННЫЕ УТВЕРЖДЕНИЯ?; ИЗУЧИ РОДОСЛОВНОЕ ДРЕВО ПЯРТА. ЗАПОЛНИ ПРОПУСКИ.

## Я И НАСЛЕД­СТВЕННОСТЬ
URL: https://www.opiq.ee/kit/541/chapter/29975
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, наслед, ственность, кого, похож, наследуем, подумай
Topics EN: mathematics
Headings: Я И НАСЛЕД­СТВЕННОСТЬ; НА КОГО Я ПОХОЖ?; ЧТО МЫ НАСЛЕДУЕМ?; Подумай
Task examples: НЕКОТОРЫЕ ВНЕШНИЕ ЧЕРТЫ МЫ НАСЛЕДУЕМ ОТ...; ОТМЕТЬ ВЕРНЫЕ УТВЕРЖДЕНИЯ.

## ДОМ
URL: https://www.opiq.ee/kit/541/chapter/29976
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, большой, маленький, позаботься, доме, выполни, подумай
Topics EN: mathematics
Headings: ДОМ; БОЛЬШОЙ ИЛИ МАЛЕНЬКИЙ?; ПОЗАБОТЬСЯ О СВОЁМ ДОМЕ; ВЫПОЛНИ; Подумай
Task examples: ЧТО ЕСТЬ В ЛЮБОМ ДОМЕ? ВЫБЕРИ ПОДХОДЯЩИЕ ОТВЕТЫ.; ВЫХОДЯ ИЗ КОМНАТЫ, ...

## ДОМАШНИЕ ЖИВОТНЫЕ. СОБАКА
URL: https://www.opiq.ee/kit/541/chapter/29977
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 2.6
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, домашние, собака, питомцы, самое, первое, домашнее
Topics EN: mathematics, animal, animals, birds, insects
Headings: ДОМАШНИЕ ЖИВОТНЫЕ. СОБАКА; ДОМАШНИЕ ПИТОМЦЫ; САМОЕ ПЕРВОЕ ДОМАШНЕЕ ЖИВОТНОЕ; ВЫПОЛНИ
Task examples: Выбери правильный ответ.; Какую работу выполняет эта собака?

## ДОМАШНИЕ ЖИВОТНЫЕ. КОШКА
URL: https://www.opiq.ee/kit/541/chapter/29978
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 2.7
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, домашние, кошка, подумай, характером, выполни
Topics EN: mathematics, animal, animals, birds, insects
Headings: ДОМАШНИЕ ЖИВОТНЫЕ. КОШКА; КОШКА; Подумай; ЖИВОТНОЕ С ХАРАКТЕРОМ; ВЫПОЛНИ
Task examples: Выбери правильный ответ.

## Ноги и нос
URL: https://www.opiq.ee/kit/541/chapter/29983
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, ноги, подумай
Topics EN: mathematics
Headings: Ноги и нос; Подумай

## МОЁ ЗДОРОВЬЕ. I
URL: https://www.opiq.ee/kit/541/chapter/29980
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 3.2
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, оставаться, здоровым, одеваемся, погоде, подумай
Topics EN: mathematics, human, body, senses, health
Headings: МОЁ ЗДОРОВЬЕ. I; КАК ОСТАВАТЬСЯ ЗДОРОВЫМ?; ОДЕВАЕМСЯ ПО ПОГОДЕ; Подумай
Task examples: Что нужно делать, чтобы оставаться здоровым? Соедини пары.; Что нужно делать, чтобы оставаться здоровым? Соедини пары.

## МОЁ ЗДОРОВЬЕ. II
URL: https://www.opiq.ee/kit/541/chapter/29981
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 3.3
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, микробы, моем, руки, чистим, зубы
Topics EN: mathematics, human, body, senses, health
Headings: МОЁ ЗДОРОВЬЕ. II; МИКРОБЫ; МОЕМ РУКИ; ЧИСТИМ ЗУБЫ
Task examples: Микробы можно увидеть...; Когда нужно мыть руки – ДО или ПОСЛЕ этих занятий?

## ЗДОРОВЬЕ. ВСПОМОГА­ТЕЛЬНЫЕ СРЕДСТВА
URL: https://www.opiq.ee/kit/541/chapter/29982
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 3.4
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, вспомога, тельные, средства, вспомогательные, приложение, улице, подумай, шрифт
Topics EN: mathematics, human, body, senses, health
Headings: ЗДОРОВЬЕ. ВСПОМОГА­ТЕЛЬНЫЕ СРЕДСТВА; ВСПОМОГАТЕЛЬНЫЕ СРЕДСТВА; Приложение; ВСПОМОГАТЕЛЬНЫЕ СРЕДСТВА НА УЛИЦЕ; Подумай; Шрифт Брайля; ЯЗЫК ЖЕСТОВ
Task examples: Как зовут детей? Впиши их имена в пропуски латинскими буквами.; Два щенка лабрадора ходят в специальную школу для собак, чтобы стать собаками-поводырями. Как их зовут? Напиши их имена латинскими буквами.

## Хорошие манеры
URL: https://www.opiq.ee/kit/541/chapter/29992
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, хорошие, манеры, подумай
Topics EN: mathematics
Headings: Хорошие манеры; II; III; Подумай

## ПУТЬ К ЗНАНИЯМ
URL: https://www.opiq.ee/kit/541/chapter/29991
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.10
Topics ET: matemaatika
Topics RU: математика, путь, знаниям, ученье, свет, неученье, тьма, цели, совершенству
Topics EN: mathematics
Headings: ПУТЬ К ЗНАНИЯМ; УЧЕНЬЕ – СВЕТ, А НЕУЧЕНЬЕ – ТЬМА; ЦЕЛИ; ПУТЬ К СОВЕРШЕНСТВУ; Подумай
Task examples: Чему может научиться ребёнок, если он этого захочет?; Что нужно сделать, чтобы научиться играть на скрипке или на барабанах?

## ЭМОЦИИ. I
URL: https://www.opiq.ee/kit/541/chapter/29984
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, эмоции, такое, подумай, понимаю, других, людей, выполни
Topics EN: mathematics
Headings: ЭМОЦИИ. I; ЧТО ТАКОЕ ЭМОЦИИ?; Подумай; Я ПОНИМАЮ ДРУГИХ ЛЮДЕЙ; ВЫПОЛНИ
Task examples: Каким будет выражение лица при данных эмоциях?; Что чувствуют дети? Закончи предложение.

## ЭМОЦИИ. II
URL: https://www.opiq.ee/kit/541/chapter/29985
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, эмоции, ситуации, подумай, нужно, притворяться, выполни
Topics EN: mathematics
Headings: ЭМОЦИИ. II; СИТУАЦИИ; Подумай; НЕ НУЖНО ПРИТВОРЯТЬСЯ; ВЫПОЛНИ
Task examples: Какая собака хочет, чтобы её погладили? А какая не хочет? Почему ты так решил?; Что ты чувствуешь и что ты делаешь? Отметь.

## ПОЗНАНИЕ СЕБЯ И ДРУГИХ. ХАРАКТЕР
URL: https://www.opiq.ee/kit/541/chapter/29986
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.4
Topics ET: matemaatika, iseloom
Topics RU: математика, познание, себя, других, характер, черты, характера, подумай
Topics EN: mathematics
Headings: ПОЗНАНИЕ СЕБЯ И ДРУГИХ. ХАРАКТЕР; ХАРАКТЕР; ISELOOM; ЧЕРТЫ ХАРАКТЕРА; Подумай; ВЫПОЛНИ
Task examples: О ком или о чём говорит это стихотворение?; Какие качества характеризуют человека, с которым ты хотел бы дружить? Выбери подходящие варианты.

## ОБЩЕНИЕ. РЕЧЬ И ЯЗЫК ТЕЛА
URL: https://www.opiq.ee/kit/541/chapter/29987
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.5
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, общение, речь, язык, тела, выдает, наши, секреты
Topics EN: mathematics, human, body, senses, health
Headings: ОБЩЕНИЕ. РЕЧЬ И ЯЗЫК ТЕЛА; ЯЗЫК; ТЕЛО ВЫДАЕТ НАШИ СЕКРЕТЫ!; Подумай; ВЫПОЛНИ
Task examples: Попробуй понять язык тела этих детей. Кто говорит «да», а кто «нет»?; Попробуй понять язык тела этих детей. Кто говорит «да», а кто «нет»?

## Я И ДРУГИЕ. РАБОТАЕМ И ИГРАЕМ ВМЕСТЕ
URL: https://www.opiq.ee/kit/541/chapter/29988
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, другие, работаем, играем, вместе, совместная, работа, правила, игры
Topics EN: mathematics
Headings: Я И ДРУГИЕ. РАБОТАЕМ И ИГРАЕМ ВМЕСТЕ; СОВМЕСТНАЯ РАБОТА; ПРАВИЛА ИГРЫ; ПОБЕДА И ПОРАЖЕНИЕ; Подумай; ВЫПОЛНИ
Task examples: Рассмотри рисунок. На каких качелях хорошо качаться в одиночку?; На каких качелях можно качаться только с друзьями? Почему?

## Король говорит НЕТ
URL: https://www.opiq.ee/kit/541/chapter/29993
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика, король, говорит, сказать, подумай
Topics EN: mathematics
Headings: Король говорит НЕТ; II; III; Как сказать НЕТ?; Подумай

## МОЁ Я. САМОСТОЯ­ТЕЛЬНОСТЬ
URL: https://www.opiq.ee/kit/541/chapter/29989
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика, самостоя, тельность, выбор, самостоятель, ность, выполни, подумай
Topics EN: mathematics
Headings: МОЁ Я. САМОСТОЯ­ТЕЛЬНОСТЬ; ВЫБОР; САМОСТОЯТЕЛЬ­НОСТЬ; ВЫПОЛНИ; Подумай
Task examples: Следует поступать хорошо, потому что ...; Выбери подходящее слово.

## ЧТО ДЕЛАТЬ, ЧТОБЫ МОЗГ РАЗВИВАЛСЯ?
URL: https://www.opiq.ee/kit/541/chapter/29990
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 4.9
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, делать, чтобы, мозг, развивался, мышцы, подумай, полезно, мозга
Topics EN: mathematics, human, body, senses, health
Headings: ЧТО ДЕЛАТЬ, ЧТОБЫ МОЗГ РАЗВИВАЛСЯ?; МЫШЦЫ И МОЗГ; Подумай; ЧТО ПОЛЕЗНО ДЛЯ МОЗГА?; ЧЕЛОВЕК РАЗВИВАЕТСЯ ВСЮ ЖИЗНЬ; КАК МЫ УЧИМ ЯЗЫКИ?
Task examples: Наши мозг и мышцы нуждаются в том, чтобы...; Какие продукты полезны для мозга, а какие нет?

## Лимонадных дел мастер и варенье Анни
URL: https://www.opiq.ee/kit/541/chapter/30001
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, лимонадных, мастер, варенье, анни, подумай
Topics EN: mathematics
Headings: Лимонадных дел мастер и варенье Анни; II; Подумай

## НАША ПРЕКРАСНАЯ ЭСТОНИЯ
URL: https://www.opiq.ee/kit/541/chapter/29994
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.2
Topics ET: matemaatika
Topics RU: математика, наша, прекрасная, эстония, замки, городища, хутора, усадьбы, выполни
Topics EN: mathematics
Headings: НАША ПРЕКРАСНАЯ ЭСТОНИЯ; ЗАМКИ И ГОРОДИЩА; ХУТОРА И УСАДЬБЫ; ВЫПОЛНИ; Подумай
Task examples: В этой главе мы поговорим о...; Внимательно рассмотри фотографию. Что ты видишь во дворе хутора?

## СИМВОЛЫ ЭСТОНИИ. I
URL: https://www.opiq.ee/kit/541/chapter/29995
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, символы, эстонии, синий, рный, белый, флаг, герб, выполни
Topics EN: mathematics
Headings: СИМВОЛЫ ЭСТОНИИ. I; СИНИЙ, ЧЁРНЫЙ, БЕЛЫЙ; ФЛАГ И ГЕРБ ЭСТОНИИ; ВЫПОЛНИ
Task examples: День независимости Эстонии ...; Что изображено на большом гербе Эстонии? Отметь все правильные варианты ответа.

## СИМВОЛЫ ЭСТОНИИ. II
URL: https://www.opiq.ee/kit/541/chapter/29996
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.4
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, символы, эстонии, многоликая, эстония, камень, птица
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: СИМВОЛЫ ЭСТОНИИ. II; МНОГОЛИКАЯ ЭСТОНИЯ; КАМЕНЬ, ПТИЦА И ЦВЕТОК; ЖИВОТНОЕ И ДЕРЕВО; ВЫПОЛНИ; Подумай
Task examples: Крепостные стены и сторожевые башни Таллинна построены из...; Как в народе называют волка? Выбери правильные ответы.

## НАЦИОНАЛЬ­НЫЕ ПРАЗДНИКИ
URL: https://www.opiq.ee/kit/541/chapter/29997
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.5
Topics ET: matemaatika
Topics RU: математика, националь, праздники, знаменательные, даты, национальные, выполни
Topics EN: mathematics
Headings: НАЦИОНАЛЬ­НЫЕ ПРАЗДНИКИ; ЗНАМЕНАТЕЛЬНЫЕ ДАТЫ; НАЦИОНАЛЬНЫЕ ПРАЗДНИКИ; ВЫПОЛНИ
Task examples: На каком мероприятии можно одновременно увидеть наибольшее количество эстонцев?; Где проходят Певческие праздники?

## КАК ЖИЛИ РАНЬШЕ? ИЗОБРЕТЕНИЯ
URL: https://www.opiq.ee/kit/541/chapter/29998
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.6
Topics ET: matemaatika
Topics RU: математика, жили, раньше, изобретения, дела, давно, минувших, дней, подумай
Topics EN: mathematics
Headings: КАК ЖИЛИ РАНЬШЕ? ИЗОБРЕТЕНИЯ; ДЕЛА ДАВНО МИНУВШИХ ДНЕЙ; Подумай; ИЗОБРЕТЕНИЯ; ВЫПОЛНИ; *Задание 2
Task examples: Внимательно рассмотри старую фотографию в учебнике. Какую обувь носят дети?; Как со временем изменялся автомобиль? Расставь автомобили в правильном порядке, начиная с самого старого.

## КАК РАНЬШЕ ЖИЛИ В ДЕРЕВНЯХ ЭСТОНИИ?
URL: https://www.opiq.ee/kit/541/chapter/29999
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.7
Topics ET: matemaatika
Topics RU: математика, раньше, жили, деревнях, эстонии, деревне, мельница, кузница, выполни
Topics EN: mathematics
Headings: КАК РАНЬШЕ ЖИЛИ В ДЕРЕВНЯХ ЭСТОНИИ?; В ДЕРЕВНЕ; МЕЛЬНИЦА И КУЗНИЦА; ВЫПОЛНИ; Подумай
Task examples: Какое транспортное средство изображено на картинке?; Отметь верные утверждения.

## КАК РАНЬШЕ ЖИЛИ В ГОРОДАХ ЭСТОНИИ?
URL: https://www.opiq.ee/kit/541/chapter/30000
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 5.8
Topics ET: matemaatika
Topics RU: математика, раньше, жили, городах, эстонии, часть, людей, жила, городская
Topics EN: mathematics
Headings: КАК РАНЬШЕ ЖИЛИ В ГОРОДАХ ЭСТОНИИ?; ЧАСТЬ ЛЮДЕЙ И РАНЬШЕ ЖИЛА В ГОРОДАХ; ГОРОДСКАЯ ЖИЗНЬ; ВЫПОЛНИ
Task examples: Рассмотри рисунок средневековой городской улицы. Что ты на нём видишь?; Отметь правильные варианты ответа.

## Королевский кошелёк
URL: https://www.opiq.ee/kit/541/chapter/30007
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, королевский, кошел, подумай
Topics EN: mathematics
Headings: Королевский кошелёк; II; Подумай

## ДЕНЬГИ, ВЕЩИ И ВЫБОР
URL: https://www.opiq.ee/kit/541/chapter/30002
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 6.2
Topics ET: matemaatika, raha, euro, sent
Topics RU: математика, деньги, евро, цент, вещи, выбор, обмен, подумай, коды, планирование, трат
Topics EN: mathematics, money, euro, cent
Headings: ДЕНЬГИ, ВЕЩИ И ВЫБОР; ОБМЕН; Подумай; PIN-КОДЫ; ПЛАНИРОВАНИЕ ТРАТ; КАК ЭКОНОМИТЬ ДЕНЬГИ
Task examples: Ты хочешь купить у гномика одну буханку. Сколько раз ты должен его погладить по голове?; Ты хочешь купить у гномика две буханки. Сколько раз ты должен его погладить по голове?

## БЕРЁМ И ДАЁМ В ДОЛГ
URL: https://www.opiq.ee/kit/541/chapter/30003
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, долг, делать, одалживаем, вещи
Topics EN: mathematics
Headings: БЕРЁМ И ДАЁМ В ДОЛГ; ЧТО ДЕЛАТЬ?; ОДАЛЖИВАЕМ ВЕЩИ
Task examples: Посмотри на рисунок? В каком состоянии ты бы хотел(а) получить обратно свою книгу?; Для празднования Мартова дня ты одолжил у друга его шапку. Но шапка упала в лужу и испачкалась. Как вернуть её на следующий день?

## ПРАВА И ОБЯЗАННОСТИ РЕБЁНКА
URL: https://www.opiq.ee/kit/541/chapter/30004
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 6.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem
Topics RU: математика, сравнение, сравни, больше, меньше, права, обязанности, прав, становится, выполни
Topics EN: mathematics, comparison, compare, greater, less
Headings: ПРАВА И ОБЯЗАННОСТИ РЕБЁНКА; ПРАВА РЕБЁНКА; ПРАВ СТАНОВИТСЯ ВСЁ БОЛЬШЕ; ОБЯЗАННОСТИ РЕБЁНКА; ВЫПОЛНИ
Task examples: У ребёнка есть право...; Расставь цифры номера телефона организации Lasteabi в правильном порядке.

## РЕШЕНИЯ И ВЫБОР РЕБЁНКА
URL: https://www.opiq.ee/kit/541/chapter/30005
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 6.5
Topics ET: matemaatika
Topics RU: математика, решения, выбор, выполни, подумай
Topics EN: mathematics
Headings: РЕШЕНИЯ И ВЫБОР РЕБЁНКА; РЕШЕНИЯ; ВЫБОР; ВЫПОЛНИ; Заданиe 3; Подумай
Task examples: Что полезнее? Если ты считаешь, что оба занятия полезны, отметь оба варианта.; Что полезнее? Если ты считаешь, что оба занятия полезны, отметь оба варианта.

## Это моё королевство!
URL: https://www.opiq.ee/kit/541/chapter/30006
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 6.6
Topics ET: matemaatika
Topics RU: математика, королевство, привет, выполни
Topics EN: mathematics
Headings: Это моё королевство!; ПРИВЕТ!; ВЫПОЛНИ
Task examples: Соедини слово и его толкование.

## КАК СПРАВИТЬСЯ СО СВОИМИ ЧУВСТВАМИ?
URL: https://www.opiq.ee/kit/541/chapter/30008
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 7.1
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, справиться, своими, чувствами, обрати, внимание, чувствуешь, сейчас, сила, моего
Topics EN: mathematics, human, body, senses, health
Headings: КАК СПРАВИТЬСЯ СО СВОИМИ ЧУВСТВАМИ?; ОБРАТИ ВНИМАНИЕ; Что ты чувствуешь сейчас?; Сила моего чувства соответствует кружочку ...; Гнев может быть похож на...; КОГДА НАМ ТРУДНО СЕБЯ КОНТРОЛИРОВАТЬ?; СТЕПЕНИ ГНЕВА

## КАК СПРАВИТЬСЯ С ГРУСТЬЮ И ГНЕВОМ?
URL: https://www.opiq.ee/kit/541/chapter/30009
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 7.2
Topics ET: matemaatika
Topics RU: математика, справиться, грустью, гневом
Topics EN: mathematics
Headings: КАК СПРАВИТЬСЯ С ГРУСТЬЮ И ГНЕВОМ?; КАК СПРАВИТЬСЯ С ГНЕВОМ?; КАК СПРАВИТЬСЯ С ГРУСТЬЮ?

## Импрессум
URL: https://www.opiq.ee/kit/541/chapter/30010
Book: Inimeseõpetus 1 klass
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человеко­ведение_для_начальной_школы._часть_i_рус
Chapter ID: 8.1
Topics ET: matemaatika
Topics RU: математика, импрессум, человековедение, начальных, классов
Topics EN: mathematics
Headings: Импрессум; Человековедение для начальных классов
