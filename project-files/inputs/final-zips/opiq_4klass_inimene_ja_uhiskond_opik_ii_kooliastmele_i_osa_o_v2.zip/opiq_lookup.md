## Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
URL: https://www.opiq.ee/Kit/Details/55
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1
Topics ET: matemaatika, inimene, keha, meeled, tervis, ühiskond, õpik, kooliastmele, opiq
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health

## Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
URL: https://www.opiq.ee/Kit/Details/55
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 34
Topics ET: matemaatika, inimene, keha, meeled, tervis, ühiskond, õpik, kooliastmele, opiq
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health

## Kool enne meid
URL: https://www.opiq.ee/kit/55/chapter/2717
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.1
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, kool, enne, meid, eesti, koolihariduse, ajalugu, miks, bengt, gottfried
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Kool enne meid; Eesti koolihariduse ajalugu; Miks on Bengt Gottfried Forselius Eesti kooli ajaloos oluline isik?; Millal asutati esimesed koolid Eestis?; Millal said lapsed esimest korda eesti keeles õppida?; Millal kehtestati lugemisoskuse sundus?; Koolitunnistus 19. sajandil; Koolikohustus; Põhiseadus; Kellele on sama paragrahvi järgi õppimine kohustuslik?; Kellel on põhiseaduse § 37 järgi õigus saada haridust?; Ma tean, et...

## Kool tänapäeval
URL: https://www.opiq.ee/kit/55/chapter/2718
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.2
Topics ET: matemaatika, kool, tänapäeval, töötavad, koolis, täiskasvanud, koolitöötajad, ruumid, raamatukogu, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: Kool tänapäeval; Kes töötavad koolis?; Täiskasvanud koolis; Koolitöötajad; Ruumid koolis; Raamatukogu. Kuidas valida raamatut?; Ohutus; Kus peab olema evakuatsiooniplaan?; Ma tean, et...

## Reeglid koolis
URL: https://www.opiq.ee/kit/55/chapter/2719
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.3
Topics ET: matemaatika, reeglid, koolis, kooli, kodukord, kahe, kodukorra, punkte, õpilase, õigused
Topics RU: математика
Topics EN: mathematics
Headings: Reeglid koolis; Kooli kodukord; Kahe kooli kodukorra punkte; Õpilase õigused ja kohustused; Mis on õpilase kõige olulisem õigus?; Ma tean, et...

## Õppimine
URL: https://www.opiq.ee/kit/55/chapter/2720
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.4
Topics ET: matemaatika, õppimine, mida, tehes, võime, õppida, midagi, priit, võigemast, ujuma
Topics RU: математика
Topics EN: mathematics
Headings: Õppimine; Mis on õppimine?; Mida tehes võime õppida midagi uut?; Priit Võigemast ujuma õppimisest; Õppimine nõuab keskendumist; Keskendumise katse; Koolilapse test; Ma tean, et...

## Mis aitab õppida?
URL: https://www.opiq.ee/kit/55/chapter/2721
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.5
Topics ET: matemaatika, aitab, õppida, harjutamine, teeb, meistriks, meeldejätmise, nipid, katse, seosed
Topics RU: математика
Topics EN: mathematics
Headings: Mis aitab õppida?; Harjutamine teeb meistriks; Meeldejätmise nipid; Meeldejätmise katse 2b; Seosed; Ajakava; Meeldejätmise katse 1a; Meeldejätmise katse 1b; Meeldejätmise katse 2a; Jüri ja maakonnad; Ma tean, et...

## Kuidas me mõtleme?
URL: https://www.opiq.ee/kit/55/chapter/2722
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.6
Topics ET: matemaatika, kuidas, mõtleme, mõisted, mõiste, mõtted, tõde, vale, võivad, ajas
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas me mõtleme?; Mõisted; Mõiste on...; Mõtted; Tõde ja vale võivad ajas muutuda; Ma tean, et...

## Vägivald koolis
URL: https://www.opiq.ee/kit/55/chapter/2723
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.7
Topics ET: matemaatika, vägivald, koolis, võib, olla, kiusamine, internetis, kust, leida, kellele
Topics RU: математика
Topics EN: mathematics
Headings: Vägivald koolis; Vägivald; Vägivald võib olla...; Kiusamine internetis; Kust leida abi?; Kellele võib psühholoog sinu muredest rääkida?; Ma tean, et...

## Kordamine
URL: https://www.opiq.ee/kit/55/chapter/2724
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 1.8
Topics ET: matemaatika, kordamine, korda, harjutan, kooli, reklaam, tutvustab
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kooli reklaam; Reklaam tutvustab

## Nimi
URL: https://www.opiq.ee/kit/55/chapter/2725
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.1
Topics ET: matemaatika, nimi, inimestel, nimed, lapse, õiguste, konventsioon, nimeseadus, isikutunnistus, saab
Topics RU: математика
Topics EN: mathematics
Headings: Nimi; Inimestel on nimed; Lapse õiguste konventsioon; Nimeseadus; Isikutunnistus; Kus saab ID-kaardiga reisida?; Kuidas saab isikutunnistust kasutada?; Ma tean, et...

## Kordamine
URL: https://www.opiq.ee/kit/55/chapter/2734
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.10
Topics ET: matemaatika, kordamine, korda, harjutan, leia, õige
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Leia õige tee

## Minapilt
URL: https://www.opiq.ee/kit/55/chapter/2726
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.2
Topics ET: matemaatika, minapilt, millest, koosneb, tunnust, tean
Topics RU: математика
Topics EN: mathematics
Headings: Minapilt; Millest koosneb minapilt?; Minu 10 tunnust; Ma tean, et...

## Emotsioonid ja kehakeel
URL: https://www.opiq.ee/kit/55/chapter/2727
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.3
Topics ET: matemaatika, emotsioonid, kehakeel, kõik, tunded, vajalikud, positiivsed, negatiivsed, tean
Topics RU: математика
Topics EN: mathematics
Headings: Emotsioonid ja kehakeel; Mis on emotsioonid?; Emotsioonid; Kehakeel; Kõik tunded on vajalikud; Positiivsed tunded; Negatiivsed tunded; Ma tean, et...

## Hoolivus
URL: https://www.opiq.ee/kit/55/chapter/2728
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.4
Topics ET: matemaatika, hoolivus, inimesele, omane, lubadused, võime, panna, teise, olukorda, empaatia
Topics RU: математика
Topics EN: mathematics
Headings: Hoolivus; Hoolivus on inimesele omane; Lubadused; Võime panna end teise olukorda; Empaatia on võime...; Näitleja roll; Ma tean, et...

## Hoolivus ja abistamine
URL: https://www.opiq.ee/kit/55/chapter/2729
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.5
Topics ET: matemaatika, hoolivus, abistamine, teiste, aitamine, millistel, viisidel, saab, teisi, aidata
Topics RU: математика
Topics EN: mathematics
Headings: Hoolivus ja abistamine; Teiste aitamine; Millistel viisidel saab teisi aidata?; Põhiseadus; Toidupank; Jõepõhja koristustalgud; Kasside hoiukodu; Ma tean, et...

## Tahe ja eesmärgid
URL: https://www.opiq.ee/kit/55/chapter/2730
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.6
Topics ET: matemaatika, aeg, kell, kalender, tahe, eesmärgid, tahtmine, eesmärkide, seadmine, teadmised, väärtushinnangud, vajadused, steve
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Tahe ja eesmärgid; Mis on tahe?; Tahe ja tahtmine; Eesmärkide seadmine; Teadmised; Väärtushinnangud; Vajadused; Steve Jobs; Laiskus; Eesmärgid ja aeg; Sõltuvus; Rebane ja viinamarjad; Ma tean, et...

## Väärtus­hinnangud. Mis on sulle oluline?
URL: https://www.opiq.ee/kit/55/chapter/2731
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.7
Topics ET: matemaatika, väärtus, hinnangud, sulle, oluline, väärtused, kõige, olulisem, tähtsad, need
Topics RU: математика
Topics EN: mathematics
Headings: Väärtus­hinnangud. Mis on sulle oluline?; Väärtused; Kõige olulisem väärtus on elu; Kui tähtsad need väärtused sinu jaoks on?; Väärtushinnangute konflikt; Väärtuste konflikt; Ma tean, et...

## Inimesed on erinevad
URL: https://www.opiq.ee/kit/55/chapter/2732
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.8
Topics ET: matemaatika, inimesed, erinevad, eripära, pärilikkus, iseloomud, anded, igaühele, arutelu, klassis
Topics RU: математика
Topics EN: mathematics
Headings: Inimesed on erinevad; Eripära ja pärilikkus; Erinevad iseloomud ja anded; Igaühele oma; Arutelu klassis. Klassikaaslaste iseloomujooned; Ma tean, et...

## Konflikt
URL: https://www.opiq.ee/kit/55/chapter/2733
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 2.9
Topics ET: matemaatika, konflikt, miks, konfliktid, tekivad, kuidas, konfliktis, tavaliselt, käitutakse, tasub
Topics RU: математика
Topics EN: mathematics
Headings: Konflikt; Miks konfliktid tekivad?; Kuidas konfliktis tavaliselt käitutakse?; Miks tasub konflikti lahendades püüda üksteist ära kuulata ja mõista?; Kas igasugune konflikt on halb?; Kuidas konflikti lahendada?; Kuidas jõuda lahenduseni?; Tüli lahendaja meelespea; Konfliktid ja nende lahendus; Ma tean, et...

## Kellest koosneb ühiskond?
URL: https://www.opiq.ee/kit/55/chapter/2735
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 3.1
Topics ET: matemaatika, kellest, koosneb, ühiskond, suhtlemise, vahendid, kuidas, moodustavad, inimesed, ühiskonna
Topics RU: математика
Topics EN: mathematics
Headings: Kellest koosneb ühiskond?; Ühiskond; Suhtlemise vahendid; Kuidas moodustavad inimesed ühiskonna?; Ühiskondlikud suhted; Ma tean, et...

## Küla ja linn
URL: https://www.opiq.ee/kit/55/chapter/2736
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 3.2
Topics ET: matemaatika, küla, linn, külade, teke, kuidas, muutis, vilja, karjakasvatusega, tegelema
Topics RU: математика
Topics EN: mathematics
Headings: Küla ja linn; Külade teke; Kuidas muutis vilja- ja karjakasvatusega tegelema hakkamine inimeste elu?; Linnade teke; Linnade tekkimine; Suurimad linnad; Linnas ja maal; Ma tean, et...

## Rahvas ja rahvus
URL: https://www.opiq.ee/kit/55/chapter/2737
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 3.3
Topics ET: matemaatika, rahvas, rahvus, eesti, sallivus, võrdõiguslikkus, põhiseadus, rahvusvaheline, pere, sallivuse
Topics RU: математика
Topics EN: mathematics
Headings: Rahvas ja rahvus; Rahvas; Eesti rahvas; Rahvus; Sallivus ja võrdõiguslikkus; Põhiseadus; Rahvusvaheline pere; Sallivuse test; Kas mina olen salliv?; Ma tean, et...

## Riik
URL: https://www.opiq.ee/kit/55/chapter/2738
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 3.4
Topics ET: matemaatika, riik, riigi, peamised, tunnused, esimene, tunnus, kindlaks, määratud, teine
Topics RU: математика
Topics EN: mathematics
Headings: Riik; Mis on riik?; Mis on riigi peamised tunnused?; Esimene tunnus – kindlaks määratud maa-ala; Teine tunnus – avaliku võimu teostamine; Riik ja avalik võim; Kolmandaks riigi tunnuseks on kodanikud; Riigi õigused; Maksud; Riigi sümbolid; Eesti hümn; Eesti lipp; Ma tean, et...

## Kordamine
URL: https://www.opiq.ee/kit/55/chapter/2739
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 3.5
Topics ET: matemaatika, kordamine, korda, harjutan, eestis, elada, arutluste, kokkuvõte, sulle, meeldib, meeldi, teie
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kas Eestis on hea elada?; Arutluste kokkuvõte; Mis sulle Eestis meeldib, mis ei meeldi?; Mis teie rühmale Eestis meeldib, mis mitte?; Mis teie klassile Eestis meeldib, mis mitte?

## Tervis
URL: https://www.opiq.ee/kit/55/chapter/2740
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 4.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, kehaline, vaimne, sotsiaalne, mõjutab, tervist, tean
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Tervis; Mis on tervis?; Kehaline tervis; Vaimne tervis; Sotsiaalne tervis; Mis mõjutab tervist?; Ma tean, et...

## Tervise hindamine
URL: https://www.opiq.ee/kit/55/chapter/2741
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 4.2
Topics ET: matemaatika, tervise, hindamine, tervisenäitajad, milline, kõige, tähtsam, tervisenäitaja, mida, näitavad
Topics RU: математика
Topics EN: mathematics
Headings: Tervise hindamine; Tervisenäitajad; Milline on kõige tähtsam tervisenäitaja?; Mida näitavad tervisenäitajad?; Pikkuse ja kehakaalu suhe; Kuidas kaalu normis hoida?; Kehatemperatuur; Pulsisagedus; Haigus; Ma tean, et...

## Eluviis
URL: https://www.opiq.ee/kit/55/chapter/2742
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 4.3
Topics ET: matemaatika, eluviis, päevakava, kertu, sportimine, kuidas, tagab, sport, rühi, mida
Topics RU: математика
Topics EN: mathematics
Headings: Eluviis; Mis on eluviis?; Päevakava; Kertu päevakava; Sportimine; Kuidas tagab sport hea rühi?; Mida teeb spordi ajal vaimse tööga tegelev aju osa?; Miks on hea, kui saab sügavamalt hingata?; Võimlemisharjutused; Ma tean, et...

## Tervislik toitumine
URL: https://www.opiq.ee/kit/55/chapter/2743
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 4.4
Topics ET: matemaatika, tervislik, toitumine, toit, peab, sisaldama, kõiki, toitaineid, toitained, süüa
Topics RU: математика
Topics EN: mathematics
Headings: Tervislik toitumine; Toit peab sisaldama kõiki toitaineid; Toitained; Süüa tuleb nii taimseid kui loomseid toiduained; Toitained ja toiduained; Hommikusööki tuleb süüa; Tervislik vahepala; Magusaga ei tohi liialdada; Ma tean, et...

## Tervis ja meelemürgid
URL: https://www.opiq.ee/kit/55/chapter/2744
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 4.5
Topics ET: matemaatika, inimene, keha, meeled, tervis, meelemürgid, kofeiin, miks, tohi, lapsed, energiajooke, juua, alkohol
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Tervis ja meelemürgid; Meelemürgid; Kofeiin; Miks ei tohi lapsed energiajooke juua?; Alkohol; Milline on alkoholi mõju inimesele?; Tubakas; Milliseid elundeid või kehaosi kahjustab nikotiin?; Narkootikumid; Kanep; Miks on narkootikumid ohtlikud?; Uimastite tarbimise laiem tagajärg; Kuidas HIV levib?; Kuidas HI-viirus ei levi?; Ma tean, et...

## Kordamine
URL: https://www.opiq.ee/kit/55/chapter/2745
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 4.6
Topics ET: matemaatika, kordamine, korda, harjutan, tervisekontroll
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Tervisekontroll
Task examples: Koosta Madlile nädalaplaan, kus on kirjas, mis ajal ja kui kaua võib ta istuda arvuti taga, tegelda spordiga ja puhata, millal sõprade ja perega suhelda.; Koosta Madlile nädala näidismenüü ja lisa ka söögiajad.

## Impressum
URL: https://www.opiq.ee/kit/55/chapter/2746
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 5.1
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Mõisted
URL: https://www.opiq.ee/kit/55/chapter/2747
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 6.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/55/chapter/2748
Book: Inimene ja ühiskond. Õpik II kooliastmele, I osa – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimene_ja_ühiskond._õpik_ii_kooliastmele,_i_osa
Chapter ID: 6.2
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/287
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 69
Topics ET: matemaatika, inimeseõpetus, klassile, lihtsustatud, õppekava, opiq
Topics RU: математика
Topics EN: mathematics

## Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
URL: https://www.opiq.ee/Kit/Details/287
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 126
Topics ET: matemaatika, inimeseõpetus, klassile, lihtsustatud, õppekava, opiq
Topics RU: математика
Topics EN: mathematics

## Mina
URL: https://www.opiq.ee/kit/287/chapter/15958
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.1
Topics ET: matemaatika, mina, kuula, vaata, peeter, tutvustab, ennast, maria, mõtle, vasta
Topics RU: математика
Topics EN: mathematics
Headings: Mina; Kuula, vaata, loe!; Peeter tutvustab ennast; Loe.; Maria tutvustab ennast; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Täida tabel teksti põhjal.; 2. Millal on vaja ennast tutvustada?; 3. Liisa tutvustab ennast.; 4. Täida lüngad enda tutvustamiseks.; Mängime läbi!; Nüüd ma tean!; Tööleht

## Me aitame üksteist
URL: https://www.opiq.ee/kit/287/chapter/15965
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.10
Topics ET: matemaatika, aitame, üksteist, kuula, vaata, kaupluses, kuidas, naine, tänas, maria
Topics RU: математика
Topics EN: mathematics
Headings: Me aitame üksteist; Kuula, vaata, loe!; Kaupluses; Loe.; 1. Kuidas naine tänas? Kuidas Maria vastas?; 2. Kumb sõna sobib Maria kohta?; Jalg-ratta-matkal; 3. Kuidas Andre ja Peeter tänasid?; 4. Mis sõnaga võib Peetrit ise-loomustada?; Klassis; 5. Vaata pilti.; Mõtle ja vasta küsimustele; Kas ma tean?; 6. Vaata pilte.; 7. Kuidas paluda abi viisakalt?; 8. Kuidas tänada abi eest?; 9. Kas nii ütleb abi-küsija või abistaja?; 10. Kas aitad?; Nüüd ma tean!; Tööleht

## Me ei tohi üksteisele liiga teha
URL: https://www.opiq.ee/kit/287/chapter/15966
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.11
Topics ET: matemaatika, tohi, üksteisele, liiga, teha, kuula, vaata, mõtle, räägi, klassi
Topics RU: математика
Topics EN: mathematics
Headings: Me ei tohi üksteisele liiga teha; Kuula, vaata, loe!; Mõtle ja räägi klassi-kaaslastega.; Kas ma tean?; 1. Head ja halvad tunded.; Hilinemine; Loe.; 3. Mida Kaspar peab Mariale ütlema?; 2.a Vaata pilti.; 2.b Mida Kaspar tegi?; 2.c Mõtle ja ​räägi kaaslasega.; Ehmatus; 4.d Mida Martin peab Liisale ütlema?; 4.a Vaata pilti.; 4.b Mida Martin tegi?; 4.c Mõtle ja ​räägi kaaslasega.; Riide-hoius; 5.d Mida Kati peab Peetrile ütlema?; 5.a Vaata pilti.; 5.b Mida Kati tegi?; 5.c Mõtle ja ​räägi kaaslasega.; Kadunud kooli-kott; 6.d Mida Andre peab Kevinile ütlema?; 6.a Vaata pilti.; 6.b Mida Andre tegi?; 6.c Mõtle ja ​räägi kaaslasega.; Mõtle ja vasta küsimustele; 7. Moodusta lause.; 8. Halvad tunded ja kiusamine.; 9. Loe.; 10. Vasta teksti põhjal.; 11. Mõtle ja räägi kaaslasele.; Nüüd ma tean!; Tööleht

## Meie jõuame kokkuleppele
URL: https://www.opiq.ee/kit/287/chapter/15967
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.12
Topics ET: matemaatika, liitmine, liida, summa, kokku, meie, jõuame, kokkuleppele, kuula, vaata, mida, peeter, maria, tahavad
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Meie jõuame kokkuleppele; Kuula, vaata, loe!; Mida Peeter ja Maria tahavad õppida?; Vaidlus; Loe.; 1. Arvamused filmide kohta.; Mõtle ja vasta küsimustele; Vaidlus lõpeb; 2. Millise kokku-leppe tegid lapsed?; Kas ma tean?; 3. Mis aitab kokku-leppele jõuda?; 4. Millised variandid valid sina kokku-leppele jõudmiseks?; Nüüd ma tean!; Tööleht

## Meie ei kaeba üksteise peale
URL: https://www.opiq.ee/kit/287/chapter/15968
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.13
Topics ET: matemaatika, lahutamine, lahuta, vahe, meie, kaeba, üksteise, peale, kuula, vaata, aliise, aitab, sõpra
Topics RU: математика, вычитание, вычти, разность
Topics EN: mathematics, subtraction, subtract, difference
Headings: Meie ei kaeba üksteise peale; Kuula, vaata, loe!; Aliise aitab sõpra; Loe.; Mõtle ja räägi klassi-kaaslastega; Kas ma tean?; 1. Kujuta ette, et sina oled Aliise.; 2.e Kas peab õpetajale teatama?; 2.a Kas peab õpetajale teatama?; 2.b Kas peab õpetajale teatama?; 2.c Kas peab õpetajale teatama?; 2.d Kas peab õpetajale teatama?; Pärast söögi-vahe-tundi; Juhtum lille-vaasiga; 3. Kas sina oleksid käitunud Mari või Liina moodi?; Mõtle ja vasta küsimustele; 4. Moodusta sõnadest lause; Nüüd ma tean!; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/287/chapter/15969
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.14
Topics ET: matemaatika, kordamine, korda, harjutan, kuula, vaata, tean, missugune, tahab, olla, laps, mängime
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kuula, vaata, loe!; Kas ma tean?; 1. Missugune tahab olla iga laps?; Mängime läbi!; Tööleht

## Meie klass
URL: https://www.opiq.ee/kit/287/chapter/15959
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.2
Topics ET: matemaatika, meie, klass, kuula, vaata, klassi, poisid, poiste, pilti, otsusta
Topics RU: математика
Topics EN: mathematics
Headings: Meie klass; Kuula, vaata, loe!; Meie klassi poisid; Loe.; 1. Vaata poiste pilti.Otsusta välimuse järgi, kes on poiste pildil.; Meie klassi tüdrukud; 2. Vaata tüdrukute pilti.Otsusta välimuse järgi, kes on tüdrukute pildil.; Kas ma tean?; 3. Välimus ja oskused.; 4.b Kas pildi järgi saab aru, kuidas laps välja näeb?; 4.a Kas pildi järgi saab aru, mida laps oskab?; 5. Vaata pilti ja otsusta, kes nendest oskab...; 6. Moodusta sõnadest tark lause.; Loe; Nüüd ma tean!; Tööleht

## Meie oskused
URL: https://www.opiq.ee/kit/287/chapter/15960
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.3
Topics ET: matemaatika, meie, oskused, kuula, vaata, kõigil, midagi, õppida, lihtne, raske
Topics RU: математика
Topics EN: mathematics
Headings: Meie oskused; Kuula, vaata, loe!; Kõigil on midagi õppida; Loe.; Lihtne ja raske; Mis Karinat aitab?; Mõtle ja vasta küsimustele; Kas ma tean?; Kirjuta enda kohta.; Nüüd ma tean!; Tööleht

## Meie kohustused ja õigused
URL: https://www.opiq.ee/kit/287/chapter/15956
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.4
Topics ET: matemaatika, meie, kohustused, õigused, kuula, vaata, laste, lastel, kohustusi, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Meie kohustused ja õigused; Kuula, vaata, loe!; Laste kohustused; Loe.; Kas lastel on kohustusi?; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Moodusta sõnadest lause.; 2. Mida sa pead kodus tegema?; Laste õigused; Loe!; Kas lastel on õigusi?; 3. Moodusta sõnadest lause.; 4.b Vaata pilti. Mis õigust püütakse rikkuda?; 4.a Vaata pilti. Mis õigust püütakse rikkuda?; 5. Kohustused ja õigused.; Nüüd ma tean!; Tööleht

## Meie sõbrad ja meie tuttavad
URL: https://www.opiq.ee/kit/287/chapter/15961
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.5
Topics ET: matemaatika, meie, sõbrad, tuttavad, kuula, vaata, johannese, jüri, kohtumine, johannesest
Topics RU: математика
Topics EN: mathematics
Headings: Meie sõbrad ja meie tuttavad; Kuula, vaata, loe!; Meie tuttavad; Loe.; Johannese ja Jüri kohtumine; Johannesest ja Jürist saavad sõbrad; Kas ma tean?; 1. Loe.; 2.b Vaata pilte. Millised pildid sobivad ka Jüri ja Johannese kohta?; 2.a Vaata pilte. Millised pildid sobivad ka Jüri ja Johannese kohta?; Laura ja Sille kohtumine; Laura ja Sille on sõbrad; 3. Loe.; 4. Kust sa võid sõpru leida?; 5. Mida sobiks öelda tõelise sõbra kohta.; Mõtle ja vasta küsimustele; Nüüd ma tean!; Tööleht

## Klassiõhtu ettevalmis­tamine
URL: https://www.opiq.ee/kit/287/chapter/15962
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.6
Topics ET: matemaatika, liitmine, liida, summa, kokku, klassiõhtu, ettevalmis, tamine, kuula, vaata, kaido, klassi, pidu, ette
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Klassiõhtu ettevalmis­tamine; Kuula, vaata, loe!; Kaido klassi pidu; Loe.; Peo ette-valmistamine; 1.b Vaata pilti.; 1.a Vaata pilti.; Peo käik; 2. Klassi-õhtu tegevused.; Peo lõpetamine; Mõtle ja vasta küsimusele; Kas ma tean?; 3. Loe küsimused. Mis küsimusele sa vastust ei leidnud?; 4. Mida tuleb enne piduoma-vahel kokku leppida?; 5. Kuidas oma klassi-õhtut korraldada?; Nüüd ma tean!; Tööleht

## Klassiõhtu läbiviimine
URL: https://www.opiq.ee/kit/287/chapter/15963
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.7
Topics ET: matemaatika, klassiõhtu, läbiviimine, kuula, vaata, sügise, alguse, pidu, mida, sain
Topics RU: математика
Topics EN: mathematics
Headings: Klassiõhtu läbiviimine; Kuula, vaata, loe!; Sügise alguse pidu; Loe.; 1. Mida sain tekstist teada?; Klassi kaunistamise​​ ​​toimkonna töö; Arutle kaaslasega.; 2. Mida sain tekstist teada?; Lõbusad mängud; 3. Mida sain tekstist teada?; Laulud ja tantsud; 4. Mida sain tekstist teada?; Mõtle ja vasta küsimustele; Nüüd ma tean!; Tööleht

## Me räägime viisakalt – sina ja teie
URL: https://www.opiq.ee/kit/287/chapter/15964
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.8
Topics ET: matemaatika, räägime, viisakalt, sina, teie, kuula, vaata, klassi, kaaslaste, teiste
Topics RU: математика
Topics EN: mathematics
Headings: Me räägime viisakalt – sina ja teie; Kuula, vaata, loe!; Räägime klassi-kaaslaste ja teiste tuttavatega; Loe.; Kas ma tean?; 1. Vaata pilte. Mitme õpilase poole õpetaja pöördub?; Räägime võõra õpetajaga; 2.b Vaata pilte. Kuidas õpilane õpetaja poole pöördub?; 2.a Vaata pilte. Kuidas õpilane õpetaja poole pöördub?; Räägime päris võõra inimesega; 3.b Kuidas pöörduda? Bussis seisab keegi ukse ees. Tahan maha minna ja küsin...; 3.a Pakun bussis istet. Kuidas pöörduda?; 4.d Kuidas pöördud teise inimese poole?; 4.a Kuidas pöördud teise inimese poole?; 4.b Kuidas pöördud teise inimese poole?; 4.c Kuidas pöördud teise inimese poole?; Mõtle ja vasta küsimustele; Nüüd ma tean!; Tööleht

## Me räägime viisakalt – nõusolek ja keeldumine
URL: https://www.opiq.ee/kit/287/chapter/15957
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 1.9
Topics ET: matemaatika, räägime, viisakalt, nõusolek, keeldumine, kuula, vaata, arutelu, pere, ringis
Topics RU: математика
Topics EN: mathematics
Headings: Me räägime viisakalt – nõusolek ja keeldumine; Kuula, vaata, loe!; Arutelu pere-ringis; Loe.; 1. Vaata pilti ja vasta küsimustele.; 2. Vaata pilti ja vasta küsimustele.; Avaldame arvamust; 3. Vaata pilte ja vasta küsimustele.; 4. Vaata pilte ja vasta küsimustele.; Kas ma tean?; 5. Kuidas vastad?; Tüdrukud räägivad oma-vahel; 6. Vaata pilti ja loe.Vasta küsimustele.; Poisid teevad plaane; 7. Vaata pilte ja loe.Vasta küsimustele.; 8. Nõustud või ei nõustu.; 9.b Otsusta, kas lauses on ette-panek, nõus-olek, ära-ütlemine või uus ette-panek.; 9.a Otsusta, kas lauses on ette-panek, nõus-olek, ära-ütlemine või uus ette-panek.; 10.e Millega on tegemist?; 10.a Millega on tegemist?; 10.b Millega on tegemist?; 10.c Millega on tegemist?; 10.d Millega on tegemist?; Mängime läbi!; Loe!; Nüüd ma tean!; Tööleht

## Tervislikud eluviisid – sport ja puhkus
URL: https://www.opiq.ee/kit/287/chapter/16904
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.1
Topics ET: matemaatika, tervislikud, eluviisid, sport, puhkus, kuula, vaata, aktiivne, liikumine, sportimine
Topics RU: математика
Topics EN: mathematics
Headings: Tervislikud eluviisid – sport ja puhkus; Kuula, vaata, loe!; Aktiivne liikumine; Loe.; Sportimine; Puhkamine; Uni; Tervise hoidmine; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Mis on tervisele kasulik?; 2. Millised aktiivsed tegevused sulle meeldivad?; 3. Loe.; 4. Loe.; 5. Vaata videot.; Nüüd ma tean!; Tööleht

## Kahjulikud harjumused – teleri- ja arvutisõltuvus
URL: https://www.opiq.ee/kit/287/chapter/16905
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.2
Topics ET: matemaatika, kahjulikud, harjumused, teleri, arvutisõltuvus, kuula, vaata, sõltuvus, vasta, küsimustele
Topics RU: математика
Topics EN: mathematics
Headings: Kahjulikud harjumused – teleri- ja arvutisõltuvus; Kuula, vaata, loe!; Teleri-sõltuvus; Loe.; 1.b Vasta küsimustele teksti põhjal.; 1.a Vaata pilti.; Arvuti-sõltuvus; 2.b Vasta küsimustele teksti põhjal.; 2.a Vaata pilti.; Silma-nägemine; Harjutus silmadele.; Õige istumis-asend laua taga; 3. Istu õigesti! Kontrolli asendit pildi järgi.; Mõtle ja vasta küsimustele; Kas ma tean?; 4. Millisel pildil on väsinud Maria?; 5. Mis käib sinu kohta?; Nüüd ma tean!; Tööleht

## Kahjulikud harjumused – suitsetamine
URL: https://www.opiq.ee/kit/287/chapter/16906
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis, kahjulikud, harjumused, suitsetamine, kuula, vaata, suitsetamise, halb, mõju, tervisele
Topics RU: математика, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье
Topics EN: mathematics, comparison, compare, greater, less, human, body, senses, health
Headings: Kahjulikud harjumused – suitsetamine; Kuula, vaata, loe!; Suitsetamise halb mõju tervisele; Loe.; Suitsetamise halb mõju õppimisele; Suitsetamise keeld; Mitte-suitsetajad; Mida teha, kui keegi sinu lähedal suitsetab?; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Tutvu suitsu-kehaga:; Võrdle suitsetaja ja mitte-suitsetaja keha.; Kopsud; Näo-nahk; Küüned; Hambad; 2. Mida ütled, kui keegi sulle suitsu pakub?; 3. Loe laused.; Nüüd ma tean!; Kasutatud allikad; Tööleht

## Kahjulikud harjumused – alkohol
URL: https://www.opiq.ee/kit/287/chapter/16909
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.4
Topics ET: matemaatika, inimene, keha, meeled, tervis, kahjulikud, harjumused, alkohol, kuula, vaata, kuidas, kirjeldavad, peeter, maria
Topics RU: математика, человек, тело, чувства, здоровье
Topics EN: mathematics, human, body, senses, health
Headings: Kahjulikud harjumused – alkohol; Kuula, vaata, loe!; Kuidas kirjeldavad Peeter ja Maria purjus inimest?; Purjus inimene; Loe.; Alkoholi halb mõju õppimisele; Alkoholi joomise keeld; Mõtle ja vasta küsimustele; Kas ma tean?; 1.c Mis on lapsele lubatud?; 1.a Mis on lapsele lubatud?; 1.b Mis on lapsele lubatud?; 2. Mida ütled, kui keegi sulle alkoholi pakub?; 3. Loe.; Nüüd ma tean!; Tööleht

## Toitumis­harjumused
URL: https://www.opiq.ee/kit/287/chapter/16907
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.5
Topics ET: matemaatika, lahutamine, lahuta, vahe, vesi, veeohutus, veekogu, toitumis, harjumused, kuula, vaata, toit, taimsed, toidu, ained, loomsed
Topics RU: математика, вычитание, вычти, разность, вода, безопасность на воде, водоём
Topics EN: mathematics, subtraction, subtract, difference, water, water safety, body of water
Headings: Toitumis­harjumused; Kuula, vaata, loe!; Toit; Loe.; Taimsed toidu-ained; Loomsed toidu-ained; 1. Lohista sõnad õigesse tulpa.; Toidu-püramiid; Hommiku-söök; Lõuna-söök ja õhtu-söök; 2. Mis värvi toidud on taldrikul?; Vahe-palad; 3.b Vaata ja nimeta, mis on pildil.; 3.a Vaata ja nimeta, mis on pildil.; Värsked viljad; Maiustused; 4.b Millised toidud on maiustused?; 4.a Vaata pilti.; Vesi; 5.b Täida lüngad teksti põhjal.; 5.a Vaata pilti.; 6. Milliseid jooke võib juua harva, milliseid iga päev?; Kiir-toit; 7.d Kumb on tervislikum?; 7.a Vaata pilti.; 7.b Kumb on tervislikum?; 7.c Kumb on tervislikum?; Nüüd ma tean!; Kasutatud allikas; Tööleht

## Esmaabi – külmetus
URL: https://www.opiq.ee/kit/287/chapter/16910
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.6
Topics ET: matemaatika, esmaabi, külmetus, kuula, vaata, kuidas, ennast, kodus, ravida, pilte
Topics RU: математика
Topics EN: mathematics
Headings: Esmaabi – külmetus; Kuula, vaata, loe!; Külmetus; Loe.; Kuidas ennast kodus ravida?; Vaata pilte ja loe.; Mida saad teha, et külmetust ära hoida?; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Loe.; Nüüd ma tean!; Tööleht

## Esmaabi – vigastused
URL: https://www.opiq.ee/kit/287/chapter/16911
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.7
Topics ET: matemaatika, esmaabi, vigastused, kuula, vaata, esma, tean, piltidel, millised, õnnetused
Topics RU: математика
Topics EN: mathematics
Headings: Esmaabi – vigastused; Kuula, vaata, loe!; Esma-abi; Loe.; Kas ma tean?; 1.c Mis vigastused on piltidel?; 1.a Mis vigastused on piltidel?; 1.b Mis vigastused on piltidel?; 2. Millised õnnetused võivad juhtuda?; Esma-abi-kapp; Esma-abi-kappi kuuluvad:; 3. Vasta küsimustele.; Mõtle ja vasta küsimustele; Praktiline töö; 4.b Harjuta esma-abi andmist.; 4.a Vaata pilte ja loe. ​Harjuta esma-abi andmist.; Nüüd ma tean!; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/287/chapter/16908
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 2.8
Topics ET: matemaatika, kordamine, korda, harjutan, kuula, tean, kõige, kallim, vara, meie, tervisele, kasulik
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kuula ja loe!; Kas ma tean?; 1. Mis on kõige kallim vara?; 2. Mis on meie tervisele kasulik? Mis kahjulik?; 3. Mis meil aitab õppida?; Tööleht

## Minu pere
URL: https://www.opiq.ee/kit/287/chapter/17195
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.1
Topics ET: matemaatika, pere, kuula, vaata, peetri, sugulased, maria, perekond, pilte, peres
Topics RU: математика
Topics EN: mathematics
Headings: Minu pere; Kuula, vaata, loe!; Kes on Peetri sugulased?​Kes on Maria sugulased?; Loe.; Perekond ja sugulased; Vaata pilte. Kes on peres?; Pere-liikmed aitavad üks-teist; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Kes on sugulased? Kes on tuttavad?; 2. Kelle ülesanne on teha neid töid sinu peres?; 3. Mis juhtuks, kui keegi perekonnast ​koduseid töid ei teeks?; Nüüd ma tean!; Tööleht

## Muutused pere elus – lapse sünd
URL: https://www.opiq.ee/kit/287/chapter/17196
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.2
Topics ET: matemaatika, muutused, pere, elus, lapse, sünd, kuula, vaata, kellest, maria
Topics RU: математика
Topics EN: mathematics
Headings: Muutused pere elus – lapse sünd; Kuula, vaata, loe!; Kellest Maria unistab?; Perekondade erinevus; Loe.; Mõtle ja vasta küsimusele; Beebi tuleb koju; Imik vajab palju hoolt; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Tütar ja poeg, õde ja vend.; 2. Kodus on beebi. Kuidas sa saad aidata?; 3. Mis sulle meeldib?; Nüüd ma tean!; Tööleht

## Muutused pere elus – pereliikmete lahkumine
URL: https://www.opiq.ee/kit/287/chapter/17197
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.3
Topics ET: matemaatika, muutused, pere, elus, pereliikmete, lahkumine, kuula, vaata, miks, peeter
Topics RU: математика
Topics EN: mathematics
Headings: Muutused pere elus – pereliikmete lahkumine; Kuula, vaata, loe!; Miks Peeter arvab, et ta täna koolis olla ei saa?; Kurvad päevad pere elus; Loe.; Mõtle ja räägi kaaslasega; Matused; Surnu-aias; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Kuidas on õige matustel käituda?; 2. Kuidas on õige kalmistul käituda?; Nüüd ma tean; Tööleht

## Maa- ja linnakodu
URL: https://www.opiq.ee/kit/287/chapter/17198
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.4
Topics ET: matemaatika, liitmine, liida, summa, kokku, linnakodu, kuula, vaata, külas, käigud, vana, emade, juurde, vasta
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Maa- ja linnakodu; Kuula, vaata, loe!; Külas-käigud vana-emade juurde; Loe.; 1. Vasta küsimustele.; Maria reisi-muljed; Suures linnas; 2. Missuguseid sõidukeid Maria kasutas?; Vanaema juures; 3. Miks olid vana-ema toad külmad?; Käisin poes; 4. Järjesta tegevused.; Pidulik lõuna-söök; 5.b Moodusta sõnadest lause.; 5.a Vaata pilti.; Peetri reisi-muljed; Jõudsin vana-ema juurde; 6. Missuguseid sõidukeid Peeter kasutas?; Aitasin vana-ema; 7. Mis töid Peeter tegi?; Mõnus lõuna-söök; 8.b Moodusta sõnadest lause.; 8.a Vaata pilti.; Kas ma tean?; 9. Kas nii on tavaliselt maal või linnas?; 10. Maria ja Peeter leppisid varem kokku, et teevad oma reisist pilte. Hiljem on neid hea ka sõbrale näidata. Otsusta, kelle tehtud need fotod on.; 11. Peeter pildistas maa-kodude vaateid. Mis on Peetri fotodel?; 12. Maria pildistas linna-kodude vaateid. Mis on Maria fotodel?; Nüüd ma tean; Tööleht

## Transpordi­vahendid täna­päeval ja minevikus
URL: https://www.opiq.ee/kit/287/chapter/17199
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.5
Topics ET: matemaatika, transpordi, vahendid, täna, päeval, minevikus, kuula, vaata, sõidukitest, peeter
Topics RU: математика
Topics EN: mathematics
Headings: Transpordi­vahendid täna­päeval ja minevikus; Kuula, vaata, loe!; Mis sõidukitest Peeter ja Maria räägivad?; Loe.; Transpordi-vahendid maal, vees ja õhus; Sõidu-vahendid minevikus; Täna-päeva sõidukid; Mõtle ja vasta küsimustele; Kas ma tean?; 1.f Millised on isiklikud sõidukid? Millised on ühis-sõidukid?; 1.a Millised on isiklikud sõidukid? Millised on ühis-sõidukid?; 1.b Millised on isiklikud sõidukid? Millised on ühis-sõidukid?; 1.c Millised on isiklikud sõidukid? Millised on ühis-sõidukid?; 1.d Millised on isiklikud sõidukid? Millised on ühis-sõidukid?; 1.e Millised on isiklikud sõidukid? Millised on ühis-sõidukid?; 2. Vaata pilti. Vasta küsimustele.; 2.e Kuhu on selle pileti omanik sõitnud?; 2.a Mis transpordi-vahendi pilet see on?; 2.b Mis kuu-päeval saab selle piletiga sõita?; 2.c Kui palju see pilet maksab?; 2.d Mis peatuses on selle pileti omanik rongile tulnud?; Nüüd ma tean!; Tööleht

## Muuseumid
URL: https://www.opiq.ee/kit/287/chapter/17200
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.6
Topics ET: matemaatika, muuseumid, kuula, vaata, mida, maria, muuseumis, teada, käitumine, videot
Topics RU: математика
Topics EN: mathematics
Headings: Muuseumid; Kuula, vaata, loe!; Mida uut sai Maria muuseumis teada?; Loe.; Käitumine muuseumis; Vaata videot; Mõtle ja vasta küsimustele; Kas ma tean?; 1.j Mis muuseum on pildil?; 1.a Mis muuseum on pildil?; 1.b Mis muuseum on pildil?; 1.c Mis muuseum on pildil?; 1.d Mis muuseum on pildil?; 1.e Mis muuseum on pildil?; 1.f Mis muuseum on pildil?; 1.g Mis muuseum on pildil?; 1.h Mis muuseum on pildil?; 1.i Mis muuseum on pildil?; 2. Mis muuseum see võib olla?; 3. Kus linnas asub Eesti Rahva Muuseum?; 4. Kui palju maksavad Eesti Rahva Muuseumi piletid?; Mõtle ja räägi kaaslastega; Nüüd ma tean; Tööleht

## Tähtpäevad ja kombed
URL: https://www.opiq.ee/kit/287/chapter/17201
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.7
Topics ET: matemaatika, arv, arvud, arvu, numbrid, aeg, kell, kalender, tähtpäevad, kombed, kuula, vaata, vali, õige, rahva, kalendri
Topics RU: математика, число, числа, цифры, время, часы, календарь
Topics EN: mathematics, number, numbers, digits, time, clock, calendar
Headings: Tähtpäevad ja kombed; Kuula, vaata, loe!; Kalender; 1. Vali õige arv.; Rahva-kalendri täht-päevad; Loe.; Mis täht-päevast on juttu?; 5. Mis täht-päevast on juttu?; ÜL; 1. Mis täht-päevast on juttu?; 2. Mis täht-päevast on juttu?; 3. Mis täht-päevast on juttu?; 4. Mis täht-päevast on juttu?; Aasta-vahetus; Eesti Vabariigi aasta-päev; Kodu-maa sünni-päeva tähistamine; Loe ja vaata pilte.; 7. Kuidas Eestis kodu-maa sünni-päeva tähistatakse?; Teised Eesti Vabariigi tähtpäevad; 8. Leia need täht-päevad kalendrist. Otsi, millised nendest on lipu-päevad.; Veel tähtsaid päevi; 9. Leia need täht-päevad kalendrist. Millised nendest on lipu-päevad?; Kas ma tean?; 10.e Mis püha on pildil kujutatud?; 10.a Mis püha on pildil kujutatud?; 10.b Mis püha on pildil kujutatud?; 10.c Mis püha on pildil kujutatud?; 10.d Mis püha on pildil kujutatud?; Mängime läbi!; Nüüd ma tean!; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/287/chapter/17202
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 3.8
Topics ET: matemaatika, kordamine, korda, harjutan, kuula, tean, muuseumi, töötajate, hinna, nimi, leidke, abiga
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kuula!; Loe.; Kas ma tean?; 1. Mis on muuseumi-töötajate au-hinna nimi?; 2. Leidke õpetaja abiga oma kodu-koht ​Eesti kaardil.; 3.d Milliste transpordi-vahenditega saab sinu kodu-kohast Kuressaarde?; 3.a Milliste transpordi-vahenditega saab sinu kodu-kohast Tartusse?; 3.b Milliste transpordi-vahenditega saab sinu kodu-kohast Tallinnasse?; 3.c Milliste transpordi-vahenditega saab sinu kodu-kohast Narva?; Tööleht

## Kellaaeg
URL: https://www.opiq.ee/kit/287/chapter/17412
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 4.1
Topics ET: matemaatika, aeg, kell, kalender, kellaaeg, vaata, kuula, tunnid, minutid, mõtle, vasta, küsimustele, tean
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Kellaaeg; Vaata, kuula, loe!; Loe.; Tunnid ja minutid; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Mis kell on?; 2. Minuti-osuti; 3. Mis kell on?; 4.b Järjesta laused kella-aja järgi. Alusta kõige varasemast.; 4.a Mis kell on?; 5. Lohista laused sobiva kella peale.; Nüüd ma tean!; Tööleht

## Kellaajast kinnipidamine
URL: https://www.opiq.ee/kit/287/chapter/17413
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 4.2
Topics ET: matemaatika, kellaajast, kinnipidamine, vaata, kuula, miks, maria, soovitab, endale, varu
Topics RU: математика
Topics EN: mathematics
Headings: Kellaajast kinnipidamine; Vaata, kuula, loe!; Miks Maria ema soovitab endale varu-aega võtta?; Liisa hilines kooli; Loe.; Mõtle ja räägi kaaslasega; Kaspar jäi jalg-palli võistlustele hiljaks; Kas ma tean?; 1.c Missugune taga-järg oli hilinemisel?; 1.a Missugune taga-järg oli hilinemisel?; 1.b Missugune taga-järg oli hilinemisel?; Nüüd ma tean; Tööleht

## Õpilase päevakava
URL: https://www.opiq.ee/kit/287/chapter/17414
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 4.3
Topics ET: matemaatika, õpilase, päevakava, kuula, vaata, peetri, päeva, kava, tegemised, õhtul
Topics RU: математика
Topics EN: mathematics
Headings: Õpilase päevakava; Kuula, vaata, loe!; Peetri päeva-kava; Peetri tegemised õhtul.; Mis päeva tähistab täht K?; Peetri tegemised hommikul.; Peetri tegemised päeval.; Kas ma tean?; 1. Minu hommikused tegevused.; 2.b Minu päevased tegevused.; 2.a Minu päevased tegevused.; 3.b Minu õhtused tegevused.; 3.a Minu õhtused tegevused.; Nüüd ma tean!; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/287/chapter/17415
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 4.4
Topics ET: matemaatika, kordamine, korda, harjutan, kuula, vaata, tean, lahenda, ristsõna, mida, jõuab, teha
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kuula, vaata, loe!; Kas ma tean?; Lahenda ristsõna; 2. Mida jõuab teha ühe minutiga?; 3. Mida jõuab teha 15 minutiga?; Tööleht

## Teave
URL: https://www.opiq.ee/kit/287/chapter/17594
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 5.1
Topics ET: matemaatika, teave, kuula, vaata, mõtle, vasta, küsimustele, tean, kiri, leht
Topics RU: математика
Topics EN: mathematics
Headings: Teave; Kuula, vaata, loe!; Loe.; Mõtle ja vasta küsimustele; Kas ma tean?; 1.d Loe.; 1.a Loe.; 1.b Loe.; 1.c Loe.; 2. Mis aja-kiri või aja-leht on pildil?; 3. Loe kuulutust.; 4. Karina soovib võtta endale kassi-poega.​Ta leidis aja-lehest kuulutused.​Loe kuulutusi.; Nüüd ma tean!; Tööleht

## Teadetetahvel
URL: https://www.opiq.ee/kit/287/chapter/17595
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 5.2
Topics ET: matemaatika, teadetetahvel, kuula, vaata, peetri, maria, klassi, teadete, tahvlit, mille
Topics RU: математика
Topics EN: mathematics
Headings: Teadetetahvel; Kuula, vaata, loe!; 1. Vaata Peetri ja Maria klassi teadete-tahvlit. Mille kohta saad teavet?; Teadete-tahvel; Loe.; Kas ma tean?; 2. Klassi teadete-tahvel.Otsusta peal-kirja järgi, kuhu iga teade sobib.; Mõtle ja vasta küsimustele; Nüüd ma tean!; Tööleht

## Kirja kirjutamine ja saatmine
URL: https://www.opiq.ee/kit/287/chapter/17596
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 5.3
Topics ET: matemaatika, kirja, kirjutamine, saatmine, kuula, vaata, suhtlemine, teel, tean, pilte
Topics RU: математика
Topics EN: mathematics
Headings: Kirja kirjutamine ja saatmine; Kuula, vaata, loe!; Suhtlemine kirja teel; Loe.; Kas ma tean?; 1. Vaata pilte. Mida on vaja kirja kirjutamiseks?; 2. Vaata pilte. Mida on vaja kirja saatmiseks?; 3.c Mis kaardi valid emade-päevaks?; 3.a Mis kaardi valid sünni-päevaks?; 3.b Mis kaardi valid jõuludeks?; Mõtle ja räägi kaaslasega; Kati kiri; Me saadame üks-teisele e-kirju; E-kiri; 4. Praktiline töö.; Harjuta kirja koostamist.; Nüüd ma tean!; Tööleht

## Töö tegemine vajab oskusi
URL: https://www.opiq.ee/kit/287/chapter/17901
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 6.1
Topics ET: matemaatika, tegemine, vajab, oskusi, kuula, vaata, kodused, tööd, mõtle, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Töö tegemine vajab oskusi; Kuula, vaata, loe!; Kodused tööd; Loe.; Mõtle ja räägi kaaslasega; Kas ma tean?; 1. Mida pead õigeks?; Erinevad ametid; 2. Kas tead neid ameteid?; 3. Vaata ja leia erinevad töö-vahendid. Mida selles ametis tegema peab? Kas tema töö-vahend on pildil?; 4. Kumb töö on õnnestunud? Kumb töö on eba-õnnestunud?; 5. Õnnestunud töö teeb kõigile rõõmu. Mida on vaja, et töö õnnestuks?; 6. Kelleks tahad saada sina? Mida sa selles ametis tegema pead?; Mängime läbi!; Nüüd ma tean!; Tööleht

## Õpilase töö koolis
URL: https://www.opiq.ee/kit/287/chapter/17902
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 6.2
Topics ET: matemaatika, õpilase, koolis, kuula, vaata, kõige, tähtsam, õppimine, mõtle, vasta
Topics RU: математика
Topics EN: mathematics
Headings: Õpilase töö koolis; Kuula, vaata, loe!; Õpilase kõige tähtsam töö on õppimine; Loe.; Mõtle ja vasta küsimustele; Kas ma tean?; 1.e Mis tundi on pildil kujutatud? Mille järgi said aru?; 1.a Mis tundi on pildil kujutatud? Mille järgi said aru?; 1.b Mis tundi on pildil kujutatud? Mille järgi said aru?; 1.c Mis tundi on pildil kujutatud? Mille järgi said aru?; 1.d Mis tundi on pildil kujutatud? Mille järgi said aru?; Suur muutus; 2. Missugused laused sobivad Kevini kohta?; 3. Mida Kevin tundis?; Või-leibade valmistamine; 4. Mida Andre tundis?; 5. Mida klassi-kaaslased tundsid?; Nüüd ma tean!; Tööleht

## Taskuraha, raha kogumine
URL: https://www.opiq.ee/kit/287/chapter/17903
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 6.3
Topics ET: matemaatika, raha, euro, sent, taskuraha, kogumine, kuula, vaata, tasku, mõtle, vasta, küsimustele
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: Taskuraha, raha kogumine; Kuula, vaata, loe!; Tasku-raha; Loe.; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Kaspar saab iga päev ühe euro tasku-raha. Martin saab seitse eurot korraga iga esmas-päeva hommikul. Kumb saab nädalas rohkem raha?; 2. Vaata joonist.; 3. Mida ostad sina oma tasku-raha eest?; 4. Mille peale kulutavad ​sinu ​klassi õpilased tasku-raha?Koostage õpetaja abiga tahvlile ​2. ülesande järgi tabel.​; Räägi kaaslastele; Nüüd ma tean!; Tööleht

## Ostud toidupoes ja turul
URL: https://www.opiq.ee/kit/287/chapter/17904
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 6.4
Topics ET: matemaatika, raha, euro, sent, ostud, toidupoes, turul, kuula, vaata, retsept, tean, maria, peab
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: Ostud toidupoes ja turul; Kuula, vaata, loe!; Retsept; Loe.; Kas ma tean?; 1. Maria peab poodi minema. Vaata retsepti. Mida tal veel pann-kookide tegemiseks vaja läheb?; Ostu-nime-kiri; 2. Kuidas teed ostu-nime-kirja?; Mõtle ja vasta küsimustele; Vestlus müüjaga; 3.c Kui palju Liisal raha kulus?; 3.a Mida Liisa ostis?; 3.b Milliseid viisakaid sõnu kasutas Liisa?; 4. Joosepile tulevad sõbrad külla. Ta soovib sõpradele pakkuda või-leibu. Joosep peab minema poodi, et osta vajalikud toidu-ained.; Nüüd ma tean!; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/287/chapter/17905
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 6.5
Topics ET: matemaatika, kordamine, korda, harjutan, kuula, vaata, tean, võetakse, poodi, minnes, alati, kaasa
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kuula, vaata, loe!; Kas ma tean?; 1. Mis võetakse poodi minnes alati kaasa?; 2. Tõnis kirjutas õpetajale e-kirja. Õpetaja vastas Tõnise e-kirjale. Kahe meili laused on segamini läinud.; Tööleht

## Prügi tekkimine
URL: https://www.opiq.ee/kit/287/chapter/17906
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.1
Topics ET: matemaatika, prügi, tekkimine, kuula, vaata, pandi, pakendid, taara, automaat, mõtle
Topics RU: математика
Topics EN: mathematics
Headings: Prügi tekkimine; Kuula, vaata, loe!; Prügi; Loe.; Pandi-pakendid; Taara-automaat; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Milline on õige käitumine?; 2. Mis prügi tekib?; 3. Mis tegevus tekitas pildil oleva prügi?; 4. Mis on pildil?; Nüüd ma tean!; Tööleht

## Kordamine
URL: https://www.opiq.ee/kit/287/chapter/17915
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.10
Topics ET: matemaatika, kordamine, korda, harjutan, kuula, vaata, tean, lahenda, ristsõna, kuidas, öelda, teisiti
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kuula, vaata, loe!; Kas ma tean?; 1. Lahenda ristsõna.; 1. Kuidas öelda teisiti: kaitstud, rahulik, ohutu?; 2. On juhtunud õnnetus ja sa pead helistama pääste-ametisse. Mida vastad pääste-ameti töötaja küsimustele?; Tööleht

## Prügi sorteerimine
URL: https://www.opiq.ee/kit/287/chapter/17907
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.2
Topics ET: matemaatika, prügi, sorteerimine, kuula, vaata, kogumise, kastid, papp, paber, mille
Topics RU: математика
Topics EN: mathematics
Headings: Prügi sorteerimine; Kuula, vaata, loe!; Prügi kogumise kastid; Loe.; Papp ja paber; 1. Mille viid papi ja paberi konteinerisse?; Klaas-pakendid; 2. Mille viid klaas-pakendite konteinerisse?; Sega-pakendid; 3. Mille viid sega-pakendite konteinerisse?; Looduslikud jäätmed; 4. Mis on looduslikud jäätmed?; Ohtlikud jäätmed; 5. Mis on ohtlikud jäätmed? Leia vastus tekstist.; Taas-kasutus; Mõtle ja vasta küsimustele; Kas ma tean?; 6. Martin ja Aliise sorteerivad prügi.Martin korjab pappi ja paberit. Aliise korjab pakendeid.; 7. Sõna-salat; Nüüd ma tean!; Missugust prügi tekib sinu klassis ühe kooli-nädala jooksul?; Töölehed

## Liiklusmärgid
URL: https://www.opiq.ee/kit/287/chapter/17908
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.3
Topics ET: matemaatika, liiklusmärgid, kuula, vaata, liiklejad, teel, ohutu, liiklemine, foorid, liiklus
Topics RU: математика
Topics EN: mathematics
Headings: Liiklusmärgid; Kuula, vaata, loe!; Liiklejad teel; Loe.; Ohutu liiklemine; Foorid; Liiklus-märgid jala-käijatele; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Moodusta lubava ja keelava märgi paar.; 2.c Mis liiklusmärgid need on?; 2.a Mis liiklusmärgid need on?; 2.b Mis liiklusmärgid need on?; 3. Vaata videot ja vasta küsimustele.; Nüüd ma tean!; Tööleht

## Jalgrattaga liikluses
URL: https://www.opiq.ee/kit/287/chapter/17909
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.4
Topics ET: matemaatika, jalgrattaga, liikluses, kuula, vaata, jalg, ratturi, varustus, korras, ratas
Topics RU: математика
Topics EN: mathematics
Headings: Jalgrattaga liikluses; Kuula, vaata, loe!; Jalg-ratturi varustus ja korras ratas; Loe.; Jalg-rattaga liikluses; 1. Mis teel võid sinarattaga sõita?; Jalg-rattaga kõnni-teel sõitmine; Sõidu-tee ületamine jalg-rattaga; Mõtle ja vasta küsimustele; Kas ma tean?; 2. Mis on pildil?; 3. Mis muudab jalg-rattaga sõitmise turvaliseks?; Nüüd ma tean!; Tööleht

## Tuleohutus kodus
URL: https://www.opiq.ee/kit/287/chapter/17910
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.5
Topics ET: matemaatika, tuleohutus, kodus, kuula, vaata, tule, ohtlikud, tegevused, tikkude, kasutamine
Topics RU: математика
Topics EN: mathematics
Headings: Tuleohutus kodus; Kuula, vaata, loe!; Tule-ohtlikud tegevused; Loe.; Tikkude kasutamine; Küünalde põletamine; Kütmine; Toidu valmistamine; Kodu-masinate kasutamine; Tule-ohutus-vahendid; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Leia pildilt 5 ohtu.; 2. Kuidas tule-kahju ära hoida?; Nüüd ma tean!; Tööleht

## Käitumine tulekahju korral kodus
URL: https://www.opiq.ee/kit/287/chapter/17911
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.6
Topics ET: matemaatika, käitumine, tulekahju, korral, kodus, kuula, vaata, kuidas, tegutseda, tule
Topics RU: математика
Topics EN: mathematics
Headings: Käitumine tulekahju korral kodus; Kuula, vaata, loe!; Kuidas tegutseda tule-kahju korral kodus?; Loe.; Mängime läbi!; Kas ma tean?; 1. Kuidas käituda tule-kahju korral?; Nüüd ma tean!; Tööleht

## Tulekahju õppehäire koolis
URL: https://www.opiq.ee/kit/287/chapter/17912
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.7
Topics ET: matemaatika, tulekahju, õppehäire, koolis, kuula, vaata, tule, kahju, õppe, häire
Topics RU: математика
Topics EN: mathematics
Headings: Tulekahju õppehäire koolis; Kuula, vaata, loe!; Tule-kahju õppe-häire koolis; Loe.; Liikumine õppe-häire ajal; Käitumine õues; Kas ma tean?; 1. Koolis on tule-tõrje-häire.; 2. Vaatle.; 3. Praktiline töö; 4. Lõpeta laused.; Nüüd ma tean!; Tööleht

## Käitumine veekogude juures
URL: https://www.opiq.ee/kit/287/chapter/17913
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.8
Topics ET: matemaatika, käitumine, veekogude, juures, kuula, vaata, ujumis, tunnis, keskuses, rannas
Topics RU: математика
Topics EN: mathematics
Headings: Käitumine veekogude juures; Kuula, vaata, loe!; Ujumis-tunnis; Loe.; Vee-keskuses; Rannas; Lippude erinev tähendus; Juhuslikus ujumis-kohas; Ujumise suund; Mõtle ja vasta küsimustele; Kas ma tean?; 1. Milline lipp lehvib rannas?; 2.c Kuidas õigesti käituda? Moodusta reeglid.; 2.a Kuidas õigesti käituda? Moodusta reeglid.; 2.b Kuidas õigesti käituda? Moodusta reeglid.; 3. Mis on juhtunud?; 4. Mis muudab vee-kogu ääres viibimise turvaliseks?; Nüüd ma tean!; Tööleht

## Käitumine loodusmatkal
URL: https://www.opiq.ee/kit/287/chapter/17914
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 7.9
Topics ET: loodusõpetus, käitumine, loodusmatkal, kuula, vaata, matkamine, matka, plaan, teadete, tahvlid
Topics RU: природоведение
Topics EN: science
Headings: Käitumine loodusmatkal; Kuula, vaata, loe!; Matkamine; Loe.; Matka-plaan; Teadete-tahvlid; Lõke; Prügi; Matka-rivis kõndimine; Käitumine eksimise korral; Kas ma tean?; 1.d Kummal pildil on matkaks sobivad asjad?; 1.a Matkaks valmistumine. Kummal pildil on matkaks sobivad asjad?; 1.b Kummal pildil on matkaks sobivad asjad?; 1.c Kummal pildil on matkaks sobivad asjad?; 2. Lõkke ääres käitumine.; 3. Käitumine eksimise korral.; Nüüd ma tean!; Tööleht

## Metoodilised juhised õpetajale õppevara kasutamiseks
URL: https://www.opiq.ee/kit/287/chapter/15970
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 8.1
Topics ET: matemaatika, metoodilised, juhised, õpetajale, õppevara, kasutamiseks
Topics RU: математика
Topics EN: mathematics
Headings: Metoodilised juhised õpetajale õppevara kasutamiseks

## Inimeseõpetus 4. klassile I osa (print-pdf)
URL: https://www.opiq.ee/kit/287/chapter/17592
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 8.2
Topics ET: matemaatika, inimeseõpetus, klassile, print
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 4. klassile I osa (print-pdf)

## Inimeseõpetus 4. klassile II osa (print-pdf)
URL: https://www.opiq.ee/kit/287/chapter/17593
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 8.3
Topics ET: matemaatika, inimeseõpetus, klassile, print
Topics RU: математика
Topics EN: mathematics
Headings: Inimeseõpetus 4. klassile II osa (print-pdf)

## Impressum
URL: https://www.opiq.ee/kit/287/chapter/15971
Book: Inimeseõpetus 4. klassile. Lihtsustatud õppekava – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: inimeseõpetus_4._klassile._lihtsustatud_õppekava
Chapter ID: 8.4
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
URL: https://www.opiq.ee/Kit/Details/82
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 35
Topics ET: matemaatika, inimene, keha, meeled, tervis, opiq
Topics RU: математика, человек, тело, чувства, здоровье, общество, учебник, ступени, обучения, часть
Topics EN: mathematics, human, body, senses, health

## Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
URL: https://www.opiq.ee/Kit/Details/82
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 68
Topics ET: matemaatika, inimene, keha, meeled, tervis, opiq
Topics RU: математика, человек, тело, чувства, здоровье, общество, учебник, ступени, обучения, часть
Topics EN: mathematics, human, body, senses, health

## Школа до нас
URL: https://www.opiq.ee/kit/82/chapter/4028
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, школа, история, школьного, образования, эстонии, почему, бенгт, готтфрид, форселиус
Topics EN: mathematics
Headings: Школа до нас; История школьного образования в Эстонии; Почему Бенгт Готтфрид Форселиус является важной фигурой в истории школьного образования в Эстонии?; Когда были основаны первые школы в Эстонии?; Когда были основаны первые школы с эстонским языком обучения?; Когда была введена обязательная грамотность?; Табель успеваемости в 19 веке; Обязательное школьное образование; Конституция; Я знаю, что...

## Школа в наше время
URL: https://www.opiq.ee/kit/82/chapter/4029
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.2
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, школа, наше, работает, школе, взрослые, помещения, школы, библиотека
Topics EN: mathematics, time, clock, calendar
Headings: Школа в наше время; Кто работает в школе?; Взрослые в школе; Помещения школы; Библиотека. Как выбрать книгу?; Безопасность; В каких местах должен находится план эвакуации?; Я знаю, что...

## Правила поведения в школе
URL: https://www.opiq.ee/kit/82/chapter/4030
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, правила, поведения, школе, внутренний, распорядок, школы, пункты, внутреннего, распорядка
Topics EN: mathematics
Headings: Правила поведения в школе; Внутренний распорядок школы; Пункты из внутреннего распорядка двух школ; Права и обязанности ученика; В чём заключается важнейшее право ученика?; Наказание; Присутствие на уроках является обязательным; Право получить помощь; Я знаю, что...

## Учёба
URL: https://www.opiq.ee/kit/82/chapter/4031
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, такое, прийт, выйгемаст, учился, плавать, важные, правила, учебы, лучше
Topics EN: mathematics
Headings: Учёба; Что такое учёба?; Прийт Выйгемаст о том, как он учился плавать; Важные правила учебы; Как лучше учиться: в тишине или когда слышны какие-то посторонние звуки?; Тест на концентрацию внимания; Тест ученика; План работы; Я знаю, что...

## Что помогает учиться?
URL: https://www.opiq.ee/kit/82/chapter/4032
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, помогает, учиться, лучше, запоминать, связи, запомнил, названия, уездов, знаю
Topics EN: mathematics
Headings: Что помогает учиться?; Как лучше запоминать?; Связи; Как Юра запомнил названия уездов; Я знаю, что...

## Как мы мыслим?
URL: https://www.opiq.ee/kit/82/chapter/4033
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, мыслим, понятия, инструменты, мышления, мысли, истина, меняется, временем, знаю
Topics EN: mathematics
Headings: Как мы мыслим?; Понятия; Понятия – инструменты мышления; Мысли; Истина меняется со временем; Я знаю, что...

## Насилие в школе
URL: https://www.opiq.ee/kit/82/chapter/4034
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.7
Topics ET: matemaatika
Topics RU: математика, насилие, школе, может, быть, если, осмеливаешься, рассказать, поможет, кому
Topics EN: mathematics
Headings: Насилие в школе; Насилие; Насилие может быть...; Если ты не осмеливаешься рассказать, то кто же поможет?; Кому психолог может рассказать о твоих проблемах?; Я знаю, что...

## Повторение
URL: https://www.opiq.ee/kit/82/chapter/4035
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 1.8
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка, реклама, должна, рассказывать
Topics EN: mathematics, revision, review, practice
Headings: Повторение; Реклама должна рассказывать

## Имя
URL: https://www.opiq.ee/kit/82/chapter/4036
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, каждого, человека, есть, конвенция, правах, ребенка, закон, именах, удостоверение
Topics EN: mathematics
Headings: Имя; У каждого человека есть имя; Конвенция о правах ребенка; Закон об именах; Удостоверение личности; Как можно использовать документ, удостоверяющий личность?; Я знаю, что...

## Повторение
URL: https://www.opiq.ee/kit/82/chapter/4045
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.10
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка, найди, верный, путь
Topics EN: mathematics, revision, review, practice
Headings: Повторение; Найди верный путь.

## Собственное «Я»
URL: https://www.opiq.ee/kit/82/chapter/4037
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, собственное, чего, состоит, представление, себе, признаков, которые, меня, характеризуют
Topics EN: mathematics
Headings: Собственное «Я»; Из чего состоит моё представление о себе?; 10 признаков, которые меня характеризуют; Я знаю, что...

## Эмоции и язык тела
URL: https://www.opiq.ee/kit/82/chapter/4038
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.3
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, эмоции, язык, тела, такое, важны, положительные, отрицательные, знаю
Topics EN: mathematics, human, body, senses, health
Headings: Эмоции и язык тела; Что такое эмоции?; Эмоции; Язык тела; Все чувства важны; Положительные чувства; Отрицательные чувства; Я знаю, что...

## Забота
URL: https://www.opiq.ee/kit/82/chapter/4039
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика, забота, людям, свойственно, проявлять, заботу, обещания, можем, поставить, себя
Topics EN: mathematics
Headings: Забота; Людям свойственно проявлять заботу; Обещания; Мы можем поставить себя на место другого человека; Я знаю, что...

## Забота и оказание помощи
URL: https://www.opiq.ee/kit/82/chapter/4040
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, забота, оказание, помощи, помощь, другим, людям, можно, помогать, конституция
Topics EN: mathematics
Headings: Забота и оказание помощи; Помощь другим людям; Как можно помогать другим?; Конституция; Продуктовый банк; С чего началась кампания «Поддержим сааремааских детей с умственными недостатками»?; Пярнуская курица; Я знаю, что...

## Сила воли и цели
URL: https://www.opiq.ee/kit/82/chapter/4041
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.6
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, сила, воли, цели, такое, постановка, целей, знания, ценности, потребности
Topics EN: mathematics, time, clock, calendar
Headings: Сила воли и цели; Что такое сила воли?; Сила воли; Постановка целей; Знания; Ценности; Потребности; Стив Джобс; Лень; Цели и время; Зависимость; Лиса и виноград; Я знаю, что...

## Ценности. Что важно для тебя?
URL: https://www.opiq.ee/kit/82/chapter/4042
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, ценности, важно, тебя, жизнь, самая, важная, ценность, насколько, важны
Topics EN: mathematics
Headings: Ценности. Что важно для тебя?; Ценности; Жизнь – самая важная ценность; Насколько важны для тебя следующие жизненные ценности?; Конфликт ценностей; Я знаю, что...

## Все люди разные
URL: https://www.opiq.ee/kit/82/chapter/4043
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, люди, разные, своеобразие, наследственность, характеры, таланты, каждому, свое, обсуждение
Topics EN: mathematics
Headings: Все люди разные; Своеобразие и наследственность; Разные характеры и таланты; Каждому свое; Обсуждение в классе. Черты характера одноклассников; Я знаю, что...

## Конфликт
URL: https://www.opiq.ee/kit/82/chapter/4044
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика, конфликт, почему, возникают, конфликты, обычно, ведут, себя, люди, случае
Topics EN: mathematics
Headings: Конфликт; Почему возникают конфликты?; Как обычно ведут себя люди в случае конфликта?; Почему при разрешении конфликта стоит попытаться выслушать и понять друг друга?; Правда ли, что любой конфликт – это плохо?; Как разрешить конфликт?; Как достичь решения?; Памятка примирителя; Конфликты и их разрешение; Я знаю, что...

## Из кого состоит общество?
URL: https://www.opiq.ee/kit/82/chapter/4046
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, кого, состоит, общество, отношения, обществе, знаю
Topics EN: mathematics
Headings: Из кого состоит общество?; Общество; Отношения в обществе; Я знаю, что...

## Город и деревня
URL: https://www.opiq.ee/kit/82/chapter/4047
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика, город, деревня, возникнование, деревень, изменилась, жизнь, людей, после, того
Topics EN: mathematics
Headings: Город и деревня; Возникнование деревень; Как изменилась жизнь людей после того, как они начали выращивать хлеб и разводить скот?; Возникновение городов; Крупнейшие города; В городе и в деревне; Я знаю, что...

## Народ и национальность
URL: https://www.opiq.ee/kit/82/chapter/4048
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 3.3
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, народ, национальность, эстонии, терпимость, равноправие, конституция, тест, терпимый
Topics EN: mathematics, human, body, senses, health
Headings: Народ и национальность; Народ; Народ Эстонии; Национальность; Терпимость и равноправие; Конституция; Тест на терпимость; Я – терпимый человек?; Я знаю, что...

## Государство
URL: https://www.opiq.ee/kit/82/chapter/4049
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, государство, такое, каковы, основные, признаки, государства, первый, признак, определ
Topics EN: mathematics
Headings: Государство; Что такое государство?; Каковы основные признаки государства?; Первый признак – определённая территория с конкретными границами; Второй признак – осуществление публичной власти; Третьим признаком государства являются граждане; Налоги; Государственные символы; Эстонский флаг; Я знаю, что...

## Повторение
URL: https://www.opiq.ee/kit/82/chapter/4050
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 3.5
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка, обсуждение, итог, обсуждений, тебе, нравится, эстонии, вашей, группе
Topics EN: mathematics, revision, review, practice
Headings: Повторение; Обсуждение; Итог обсуждений; Что тебе нравится в Эстонии, а что – нет?; Что в вашей группе нравится в Эстонии, а что – нет?; Что вашему классу нравится в Эстонии, а что – не нравится?

## Здоровье
URL: https://www.opiq.ee/kit/82/chapter/4051
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 4.1
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, такое, физическое, психическое, социальное, влияет, знаю
Topics EN: mathematics, human, body, senses, health
Headings: Здоровье; Что такое здоровье?; Физическое здоровье; Психическое здоровье; Социальное здоровье; Что влияет на здоровье?; Я знаю, что...

## Оценка состояния здоровья
URL: https://www.opiq.ee/kit/82/chapter/4052
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, оценка, состояния, здоровья, показатели, указывают, соотношение, роста, веса, поддерживать
Topics EN: mathematics
Headings: Оценка состояния здоровья; Показатели здоровья; На что указывают показатели здоровья?; Соотношение роста и веса; Как поддерживать вес в норме?; Температура тела; Частота пульса; Болезнь; Я знаю, что...

## Образ жизни
URL: https://www.opiq.ee/kit/82/chapter/4053
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 4.3
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, образ, жизни, такое, расписание, режим, занятия, спортом, каким, образом
Topics EN: mathematics, time, clock, calendar
Headings: Образ жизни; Что такое образ жизни?; Расписание дня; Режим дня Яны; Занятия спортом; Каким образом занятия спортом помогают сохранить правильную осанку?; Чем во время занятий спорта занята часть мозга, которая занимается умственным трудом?; Почему полезно глубоко дышать?; Физические упражнения; Я знаю, что...

## Здоровое питание
URL: https://www.opiq.ee/kit/82/chapter/4054
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, здоровое, питание, пища, должна, содержать, необходимые, питательные, вещества, важно
Topics EN: mathematics
Headings: Здоровое питание; Пища должна содержать все необходимые питательные вещества; Питательные вещества; Важно есть продукты как растительного, так и животного происхождения; Питательные вещества и продукты питания; Завтрак незаменим; Не стоит злоупотреблять сладким; Я знаю, что...

## Здоровье и вещества, вызывающие зависимость
URL: https://www.opiq.ee/kit/82/chapter/4055
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 4.5
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, вещества, вызывающие, зависимость, кофеин, алкоголь, каково, воздействие, алкоголя
Topics EN: mathematics, human, body, senses, health
Headings: Здоровье и вещества, вызывающие зависимость; Вещества, вызывающие зависимость; Кофеин; Алкоголь; Каково воздействие алкоголя на организм человека?; Табак; Какие органы или части тела страдают от воздействия никотина?; Наркотики; Конопля; Последствия употребления наркотических веществ; Как распространяется ВИЧ?; Я знаю, что...

## Повторение
URL: https://www.opiq.ee/kit/82/chapter/4056
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 4.6
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Повторение
Task examples: Составь для Мадли план на неделю, где будет записано, в какое время и как долго она может сидеть за компьютером, заниматься спортом и отдыхать.; Составь для Мадли меню на неделю и расписание приёмов пищи.

## Импрессум
URL: https://www.opiq.ee/kit/82/chapter/4057
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, импрессум
Topics EN: mathematics
Headings: Импрессум

## Mõisted
URL: https://www.opiq.ee/kit/82/chapter/4058
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 6.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/82/chapter/4059
Book: Человек и общество. Учебник для II ступени обучения, Часть I – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: человек_и_общество._учебник_для_ii_ступени_обучения,_часть_i
Chapter ID: 6.2
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused
