## Loodusõpetus 3. klassile (2023) – Opiq
URL: https://www.opiq.ee/Kit/Details/442
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 183
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Sissejuhatus. Kaardiõpetus
URL: https://www.opiq.ee/kit/442/chapter/24259
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 1.1
Topics ET: loodusõpetus, sissejuhatus, kaardiõpetus, mari, orienteerub, tormi, mängib, geopeitust
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus. Kaardiõpetus; Mari orienteerub; Tormi mängib geopeitust

## Missugune on Eesti?
URL: https://www.opiq.ee/kit/442/chapter/24254
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 1.2
Topics ET: loodusõpetus, missugune, eesti, mereriik, uuri, kaarti, madalikud, kõrgustikud, veekogud
Topics RU: природоведение
Topics EN: science
Headings: Missugune on Eesti?; Eesti on mereriik; Uuri kaarti!; Madalikud ja kõrgustikud; Eesti veekogud; Jätan meelde
Task examples: Mis on Eesti naaberriigid?; Märgi neli suurimat Eesti saart.

## Kaart
URL: https://www.opiq.ee/kit/442/chapter/24255
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 1.3
Topics ET: loodusõpetus, kaart, kaardile, kantakse, jätan, meelde
Topics RU: природоведение
Topics EN: science
Headings: Kaart; Mis on kaart?; Mis kaardile kantakse?; Jätan meelde
Task examples: Uuri kaarti. Loe kokku, mitu linna on Eestis.; Millise leppemärgiga on sellel kaardil tähistatud linn?

## Ilmakaared
URL: https://www.opiq.ee/kit/442/chapter/24256
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 1.4
Topics ET: loodusõpetus, ilmakaared, põhi, vaheilmakaared, ilmakaarte, määramine, looduses, kompassiga, kaardil
Topics RU: природоведение
Topics EN: science
Headings: Ilmakaared; Põhi- ja vaheilmakaared; Ilmakaarte määramine looduses; Ilmakaarte määramine kompassiga; Ilmakaared kaardil; Jätan meelde
Task examples: Mis ilmakaared asuvad üksteise vastas? Ühenda paarid.; Sorteeri ilmakaared.

## Kuidas kaardi järgi liikuda?
URL: https://www.opiq.ee/kit/442/chapter/24257
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 1.5
Topics ET: loodusõpetus, kuidas, kaardi, järgi, liikuda, võib, kaarte, näha, kaarti
Topics RU: природоведение
Topics EN: science
Headings: Kuidas kaardi järgi liikuda?; Kus võib kaarte näha?; Kuidas kaarti kasutada?; Jätan meelde
Task examples: Kuidas jõuaksid välisukse juurest matemaatika klassi?; Uuri kooli kaarti. Kuidas jõuaksid sööklast vene keele klassi?

## Kordamine. Kaardiõpetus
URL: https://www.opiq.ee/kit/442/chapter/24258
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 1.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, kaardiõpetus, jätan, meelde, missugune, eesti, kaart, ilmakaared, kuidas
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Kaardiõpetus; Jätan meelde; Missugune on Eesti?; Kaart; Ilmakaared; Kuidas kaardi järgi liikuda?; Harjutan
Task examples: Kas tegu on madaliku või kõrgustiku nimega? Lohista nimi õige pealkirja alla.; Mis on Eesti naaberriigid?

## Sissejuhatus. Liikumine ja jõud
URL: https://www.opiq.ee/kit/442/chapter/24264
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 2.1
Topics ET: loodusõpetus, sissejuhatus, liikumine, jõud, jookseb, kõige, kiiremini, kosmosejutud
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus. Liikumine ja jõud; Kes jookseb kõige kiiremini?; Kosmosejutud

## Liikumine ja kiirus
URL: https://www.opiq.ee/kit/442/chapter/24260
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 2.2
Topics ET: loodusõpetus, liikumine, kiirus, mõtle, liigub, liigu, kuidas, arvutada, kiirust
Topics RU: природоведение
Topics EN: science
Headings: Liikumine ja kiirus; Liikumine; Mõtle!; Liigub või ei liigu?; Kiirus; Kuidas arvutada kiirust?; Jätan meelde
Task examples: Vali rippmenüüst õige sõna.; Kujutle, et sõidad sõbraga rongiga Tartust Tallinna. Mille suhtes sa liigud? Mille või kelle suhtes oled paigal?

## Liikumist põhjustab jõud
URL: https://www.opiq.ee/kit/442/chapter/24261
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 2.3
Topics ET: loodusõpetus, liikumist, põhjustab, jõud, selle, avaldumine, mõtle, raskusjõud, hõõrdejõud
Topics RU: природоведение
Topics EN: science
Headings: Liikumist põhjustab jõud; Jõud ja selle avaldumine; Mõtle!; Raskusjõud; Hõõrdejõud; Hõõrdumisel tekib soojus; Jätan meelde
Task examples: Kas Maa tõmbab enda poole ka neid kehi, mis ei saa kukkuda? Näiteks neid, mis on laua peal või ripuvad nööri otsas?; Kas Maa tõmbab enda poole ka neid kehi, mis ei saa kukkuda? Näiteks neid, mis on laua peal või ripuvad nööri otsas?

## Liiklusohutus
URL: https://www.opiq.ee/kit/442/chapter/24262
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 2.4
Topics ET: loodusõpetus, liiklusohutus, ohud, liikluses, pidurdustee, inerts, miks, vaja, turvavööd
Topics RU: природоведение
Topics EN: science
Headings: Liiklusohutus; Ohud liikluses; Pidurdustee; Inerts; Miks on vaja turvavööd?; Mõtle!; Libedus; Nähtavus; Jätan meelde
Task examples: Miks tuleb nende märkide järgi käituda?; Uuri märke hoiatustahvlil. Mida need tähendavad?

## Kordamine. Liikumine ja jõud
URL: https://www.opiq.ee/kit/442/chapter/24263
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 2.5
Topics ET: loodusõpetus, kordamine, korda, harjutan, liikumine, jõud, jätan, meelde, kiirus, liikumist, põhjustab, liiklusohutus
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Liikumine ja jõud; Jätan meelde; Liikumine ja kiirus; Liikumist põhjustab jõud; Liiklusohutus; Harjutan
Task examples: Vali rippmenüüst õige sõna.; Kujutle, et sõidad sõbraga rongiga Tallinnast Viljandisse. Mille suhtes sa liigud? Mille või kelle suhtes oled paigal?

## Sissejuhatus. Elekter ja magnetid
URL: https://www.opiq.ee/kit/442/chapter/24270
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 3.1
Topics ET: loodusõpetus, sissejuhatus, elekter, magnetid, elektrijutud, hõljuvad, sõidukid
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus. Elekter ja magnetid; Elektrijutud; Hõljuvad sõidukid

## Elekter ja elektrivool
URL: https://www.opiq.ee/kit/442/chapter/24265
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 3.2
Topics ET: loodusõpetus, elekter, elektrivool, uuri, elektri, säästmine, mõtle, jätan, meelde
Topics RU: природоведение
Topics EN: science
Headings: Elekter ja elektrivool; Mis on elekter?; Uuri!; Elektri säästmine; Mõtle!; Jätan meelde
Task examples: Märgi seadmed, mis töötavad elektriga.; Elektrivoolus voolavad ...

## Vooluallikas ja vooluring
URL: https://www.opiq.ee/kit/442/chapter/24266
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 3.3
Topics ET: loodusõpetus, vooluallikas, vooluring, vooluallikad, mõtle, uuri, jätan, meelde
Topics RU: природоведение
Topics EN: science
Headings: Vooluallikas ja vooluring; Vooluallikad; Mõtle!; Vooluring; Uuri!; Jätan meelde
Task examples: Millised neist on vooluallikad?; Ühenda vooluringi osa ja selle ülesanne.

## Elektrijuhid ja elektriohutus
URL: https://www.opiq.ee/kit/442/chapter/24267
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 3.4
Topics ET: loodusõpetus, elektrijuhid, elektriohutus, mittejuhid, uuri, jätan, meelde
Topics RU: природоведение
Topics EN: science
Headings: Elektrijuhid ja elektriohutus; Elektrijuhid ja mittejuhid; Uuri!; Elektriohutus; Jätan meelde
Task examples: Sordi materjalid õigetesse tulpadesse.; Sordi materjalid õigetesse tulpadesse.

## Magnet ja kompass
URL: https://www.opiq.ee/kit/442/chapter/24268
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 3.5
Topics ET: loodusõpetus, magnet, kompass, magnetid, jätan, meelde
Topics RU: природоведение
Topics EN: science
Headings: Magnet ja kompass; Magnetid; Kompass; Jätan meelde
Task examples: Vali õiged vastused.; Kus on magneti mõju raudesemetele tugevaim?

## Kordamine. Elekter ja magnetid
URL: https://www.opiq.ee/kit/442/chapter/24269
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 3.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, elekter, magnetid, jätan, meelde, elektrivool, vooluallikas, vooluring, elektrijuhid
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Elekter ja magnetid; Jätan meelde; Elekter ja elektrivool; Vooluallikas ja vooluring; Elektrijuhid ja elektriohutus; Magnet ja kompass; Harjutan
Task examples: Miks tuleb elektrit säästlikult tarbida?; Vali lünkadesse õiged sõnad.

## Sissejuhatus. Elusloodus
URL: https://www.opiq.ee/kit/442/chapter/24488
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.1
Topics ET: loodusõpetus, sissejuhatus, elusloodus, raagritsikad, loodussõbralik, kool
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus. Elusloodus; Raagritsikad; Loodussõbralik kool

## Mida elusolendid söövad?
URL: https://www.opiq.ee/kit/442/chapter/24485
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.10
Topics ET: loodusõpetus, mida, elusolendid, söövad, tootjad, mõtle, kuidas, bakterid, toituvad
Topics RU: природоведение
Topics EN: science
Headings: Mida elusolendid söövad?; Tootjad; Mõtle!; Kuidas bakterid toituvad?; Tarbijad; Lagundajad; Toiduahel ja toiduvõrk; Uuri!; Jätan meelde
Task examples: Taimed kasutavad kasvamiseks mineraalaineid ja suhkruid. Mida on taimedel endale suhkru valmistamiseks vaja? Märgi kõik õiged vastused.; Ühenda paarid vastavalt sellele, mida keegi sööb.

## Inimene ja loodus
URL: https://www.opiq.ee/kit/442/chapter/24486
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.11
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, mõjutab, loodust, mõtle, mida, saad, sina
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Inimene ja loodus; Inimene mõjutab loodust; Mõtle!; Mida saad sina teha?; Jätan meelde
Task examples: Millised inimese tegevused ohustavad loodust? Märgi kõik õiged vastused.; Märgi, kumma tegevusega hoiad sa loodust.

## Kordamine. Elusloodus II
URL: https://www.opiq.ee/kit/442/chapter/24487
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.12
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond, taim, taimed, puu, lill, inimene, keha, meeled, tervis, elusloodus, jätan, meelde, alus, seened, bakterid, mida
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда, растение, растения, дерево, цветок, человек, тело, чувства, здоровье
Topics EN: science, revision, review, practice, nature, environment, plant, plants, tree, flower, human, body, senses, health
Headings: Kordamine. Elusloodus II; Jätan meelde; Taimed on elu alus; Seened; Bakterid; Mida elusolendid söövad?; Inimene ja loodus; Harjutan
Task examples: Kuidas paljunevad sõnajalad ja samblad?; Märgi kõik laused, mis on õiged.

## Elusolendite mitmekesisus ja rühmitamine
URL: https://www.opiq.ee/kit/442/chapter/24477
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.2
Topics ET: loodusõpetus, elusolendite, mitmekesisus, rühmitamine, mõtle, ühised, tunnused, suurim, rakk
Topics RU: природоведение
Topics EN: science
Headings: Elusolendite mitmekesisus ja rühmitamine; Elu mitmekesisus; Mõtle!; Elusolendite ühised tunnused; Suurim rakk; Elusolendite rühmitamine; Liik; Milliseid elusolendeid on kõige rohkem?; Jätan meelde
Task examples: Kes neist loomadest elab kõige kõrgemal?; Mis on kõigil elusolenditel ühist? Kõik elusolendid ...

## Loomade rühmad
URL: https://www.opiq.ee/kit/442/chapter/24478
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.3
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, loomade, rühmad, selgroogsed, selgrootud, mõtle, selgrootute, selgroogsete, tunnused
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Loomade rühmad; Selgroogsed ja selgrootud; Mõtle!; Selgrootute ja selgroogsete tunnused; Selgroogsete rühmad; Imetajad; Roomajad; Kahepaiksed; Kalad; Linnud; Jätan meelde
Task examples: Kas inimene on selgrootu või selgroogne loom?; Millise tunnuse põhjal jagatakse kõik loomad kahte suurde rühma?

## Selgroogsete paljunemine
URL: https://www.opiq.ee/kit/442/chapter/24479
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgroogsete, paljunemine, imetajad, roomajad, kalad, kahepaiksed, jätan
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgroogsete paljunemine; Uus elu; Imetajad; Linnud ja roomajad; Kalad ja kahepaiksed; Jätan meelde
Task examples: Mis on viljastumine?; Mis on viljastumine?

## Selgrootud ja nende tähtsus
URL: https://www.opiq.ee/kit/442/chapter/24480
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.5
Topics ET: loodusõpetus, selgrootud, nende, tähtsus, selgrootute, mitmekesisus, lemmikloomad, mõtle, teadus
Topics RU: природоведение
Topics EN: science
Headings: Selgrootud ja nende tähtsus; Selgrootute mitmekesisus; Selgrootud lemmikloomad; Mõtle!; Selgrootute tähtsus; Teadus; Muld; Tolmeldamine; Vee puhastamine; Toit; Kahjurite tõrje; Jätan meelde
Task examples: Kes neist on selgrootud? Märgi kõik õiged vastused.; Mitu liiki on selgrootuid?

## Kordamine. Elusloodus I
URL: https://www.opiq.ee/kit/442/chapter/24481
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, elusloodus, jätan, meelde, elusolendite, mitmekesisus, rühmitamine, loomade, rühmad
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Elusloodus I; Jätan meelde; Elusolendite mitmekesisus ja rühmitamine; Loomade rühmad; Selgroogsete paljunemine; Selgrootud ja nende tähtsus; Harjutan
Task examples: Järjesta elusolendite rühmad. Alusta rühmast, kuhu kuuluvaid elusolendeid on kaalu järgi kõige rohkem.; Mis on kõigil elusolenditel ühist? Kõik elusolendid ...

## Taimed on elu alus
URL: https://www.opiq.ee/kit/442/chapter/24482
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.7
Topics ET: loodusõpetus, taim, taimed, puu, lill, alus, taimede, tähtsus, mõtle, rühmad, seemnetega, paljunevad
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed on elu alus; Taimede tähtsus; Mõtle!; Taimede rühmad; Seemnetega paljunevad taimed; Eostega paljunevad taimed; Jätan meelde
Task examples: Taimed kasutavad kasvamiseks mineraalaineid ja suhkruid. Mida on taimedel endale suhkru valmistamiseks vaja? Märgi kõik õiged vastused.; Märgi kõik laused, mis on õiged.

## Seened
URL: https://www.opiq.ee/kit/442/chapter/24483
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.8
Topics ET: loodusõpetus, seened, seente, mitmekesisus, uuri, seene, osad, mõtle, roll
Topics RU: природоведение
Topics EN: science
Headings: Seened; Seente mitmekesisus; Uuri!; Seene osad; Mõtle!; Seente roll looduses; Erinevad seened; Samblikud; Kas samblik või sammal?; Jätan meelde
Task examples: Milliseid seeni on vaja saiatoodete tegemiseks?; Miks on lagundajad olulised?

## Bakterid
URL: https://www.opiq.ee/kit/442/chapter/24484
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 4.9
Topics ET: loodusõpetus, bakterid, kõikjal, bakterite, tähtsus, mullas, viirused, jätan, meelde
Topics RU: природоведение
Topics EN: science
Headings: Bakterid; Bakterid on kõikjal; Bakterite tähtsus mullas; Viirused; Jätan meelde
Task examples: Meenuta, mis rühma kuuluvaid elusolendeid on Maal kõige rohkem. Milliseid on kõige vähem? Järjesta elusolendite rühmad, alustades neist, keda on kaalu järgi kõige rohkem.; Miks on tähtis enne sööki käsi pesta?

## Kordamine
URL: https://www.opiq.ee/kit/442/chapter/25882
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 5.1
Topics ET: loodusõpetus, kordamine, korda, harjutan, loom, loomad, linnud, putukad, tavalisemad, pildil, lehtpuud, ilmakaared, need, asuvad, eesti
Topics RU: природоведение, повторение, повтори, тренировка, животное, животные, птицы, насекомые
Topics EN: science, revision, review, practice, animal, animals, birds, insects
Headings: Kordamine; Tavalisemad linnud; Kes on pildil?; Tavalisemad lehtpuud; Mis on pildil?; Ilmakaared; Kus need ilmakaared asuvad?; Eesti kaart; Mis asub kus?

## Impressum
URL: https://www.opiq.ee/kit/442/chapter/24271
Book: Sissejuhatus. Kaardiõpetus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_avita_2023_est
Chapter ID: 5.2
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Эстония
URL: https://www.opiq.ee/kit/43/chapter/1995
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 1.1
Topics ET: loodusõpetus
Topics RU: природоведение, эстония, карта, эстонии, исследуй, карту, знаю
Topics EN: science
Headings: Эстония; Карта Эстонии; Исследуй карту; Кто живёт в Эстонии?; Я знаю, что...
Task examples: Какие из указанных уездов одновременно являются островами?; Сколько уездов в Эстонии?

## Период национального пробуждения
URL: https://www.opiq.ee/kit/43/chapter/1996
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 1.2
Topics ET: loodusõpetus
Topics RU: природоведение, период, национального, пробуждения, такое, национальное, пробуждение, подумай, первые
Topics EN: science
Headings: Период национального пробуждения; Что такое национальное пробуждение?; Подумай; Первые газеты и эпос «Калевипоэг»; Я знаю, что...
Task examples: Когда был проведён первый Певческий праздник?; Как называлась первая эстонская газета?

## Хутор
URL: https://www.opiq.ee/kit/43/chapter/1997
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 1.3
Topics ET: loodusõpetus
Topics RU: природоведение, хутор, жилая, рига, амбары, хлев, подумай, баня, кузница
Topics EN: science
Headings: Хутор; Жилая рига; Амбары; Хлев; Подумай; Баня; Кузница и летняя кухня; Я знаю, что...
Task examples: Определи по описанию, о чём идёт речь. Выбери нужное слово.; Что мы используем вместо амбаров в настоящее время?

## Национальная одежда
URL: https://www.opiq.ee/kit/43/chapter/1998
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 1.4
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, национальная, одежда, праздничная, повседневная, чего, изготавливали, одежду, льняную
Topics EN: science, plant, plants, tree, flower
Headings: Национальная одежда; Праздничная и повседневная одежда; Из чего изготавливали одежду?; Льняную ткань получали из растения – льна.; Шерсть получали от овец; Я знаю, что...
Task examples: Отметь одежду, которую носили мужчины.; Сравни повседневную и праздничную одежду. Распредели высказывания по нужным столбикам.

## Наследие прошлого
URL: https://www.opiq.ee/kit/43/chapter/1999
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 1.5
Topics ET: loodusõpetus
Topics RU: природоведение, наследие, прошлого, такое, прошлое, пярну, прошлом, настоящем, подумай
Topics EN: science
Headings: Наследие прошлого; Что такое прошлое?; Пярну в прошлом и настоящем; Подумай; Я знаю, что...
Task examples: Что случилось раньше, что позже? Расставь события по порядку. Начни с самого раннего события.

## Повторение. Эстония
URL: https://www.opiq.ee/kit/43/chapter/2000
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 1.6
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, эстония, обобщающая, фотогалерея
Topics EN: science, revision, review, practice
Headings: Повторение. Эстония; Обобщающая фотогалерея; Задания
Task examples: Где находятся указанные уезды? Перетащи кружок с цифрой в нужное место на карте.; По описанию определи помещение. Выбери соответствующее название.

## Деление живой природы
URL: https://www.opiq.ee/kit/43/chapter/2055
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 10.1
Topics ET: loodusõpetus, jagamine, jaga, jagatis, pool
Topics RU: природоведение, деление, раздели, частное, половина, живой, природы
Topics EN: science, division, divide, quotient, half
Headings: Деление живой природы

## Эстония
URL: https://www.opiq.ee/kit/43/chapter/2056
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 10.2
Topics ET: loodusõpetus
Topics RU: природоведение, эстония, основные, данные, эстонии
Topics EN: science
Headings: Эстония; Основные данные об Эстонии

## Уезды Эстонии
URL: https://www.opiq.ee/kit/43/chapter/2057
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 10.3
Topics ET: loodusõpetus
Topics RU: природоведение, уезды, эстонии, гербы, уездов
Topics EN: science
Headings: Уезды Эстонии; Гербы уездов Эстонии

## Понятия
URL: https://www.opiq.ee/kit/43/chapter/24472
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 10.4
Topics ET: loodusõpetus
Topics RU: природоведение, понятия
Topics EN: science
Headings: Понятия

## Эстонско-русский тематический словарь
URL: https://www.opiq.ee/kit/43/chapter/24473
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 10.5
Topics ET: loodusõpetus, kodumaa, eesti, elusolendite, mitmekesisus
Topics RU: природоведение, эстонско, русский, тематический, словарь, эстония
Topics EN: science
Headings: Эстонско-русский тематический словарь; Kodumaa Eesti/ Моя Эстония; Elusolendite mitmekesisus/ Многообразие живых организмов; Maailmaruum ja valgus/ Вселенная и свет; Teave ja internet /Информация и интернет; Liikumine/Движение; Elekter ja magnet/ Электричество и магнит; Plaan ja kaart/ План и карта; Ееsti kui riik/ Государственное устройство Эстонии

## Импрессум
URL: https://www.opiq.ee/kit/43/chapter/2058
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 10.6
Topics ET: loodusõpetus
Topics RU: природоведение, импрессум
Topics EN: science
Headings: Импрессум

## Позвоночные животные
URL: https://www.opiq.ee/kit/43/chapter/2001
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.1
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, позвоночные, такие, группы, позвоночных, животных, знаю
Topics EN: science, animal, animals, birds, insects
Headings: Позвоночные животные; Кто такие позвоночные животные?; Группы позвоночных животных; Я знаю, что...
Task examples: Что есть у всех позвоночных животных?; Перечисли группы позвоночных животных. Приведи примеры представителей этих групп.

## Грибы
URL: https://www.opiq.ee/kit/43/chapter/2010
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.10
Topics ET: loodusõpetus
Topics RU: природоведение, грибы, признаки, грибов, питание, рост, сосуществование, растениями, съедобные
Topics EN: science
Headings: Грибы; Признаки грибов; Питание и рост; Сосуществование с растениями; Съедобные грибы; Дополнительно. Нельзя собирать грибы, которые растут в городе или вдоль автомобильных дорог!; Ядовитые грибы; Дополнительно. Плесневые грибы; Виды грибов; Подумай; Я знаю, что...
Task examples: Назови части гриба. Перетащи кружок с цифрой в нужное место.; С помощью чего грибы размножаются?

## Бактерии
URL: https://www.opiq.ee/kit/43/chapter/2011
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.11
Topics ET: loodusõpetus
Topics RU: природоведение, бактерии, признаки, бактерий, значение, подумай, дополнительно, знаю
Topics EN: science
Headings: Бактерии; Признаки бактерий; Значение бактерий; Подумай; Дополнительно. Бактерии; Я знаю, что...
Task examples: Какова роль бактерий в природе?; Какова роль бактерий в природе?

## Сообщества
URL: https://www.opiq.ee/kit/43/chapter/2012
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.12
Topics ET: loodusõpetus
Topics RU: природоведение, сообщества, такое, сообщество, пищевая, цепь, сеть, знаю
Topics EN: science
Headings: Сообщества; Что такое сообщество?; Пищевая цепь; Пищевая сеть; Я знаю, что...
Task examples: Как называется взаимосвязанное множество животных, растений, грибов и бактерий, живущих на одной территории?; С чего или кого начинается пищевая цепь?

## Повторение. Живая природа
URL: https://www.opiq.ee/kit/43/chapter/2013
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.13
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда, живая, обобщающая, фотогалерея
Topics EN: science, revision, review, practice, nature, environment
Headings: Повторение. Живая природа; Обобщающая фотогалерея; Задания
Task examples: Заполни таблицу о позвоночных животных. Выбери в окошечке подходящий текст; Напиши, как передвигаются эти животные (летают, плавают, ходят, бегают, прыгают, ползают). Свои ответы обсудите в классе.

## Рыбы
URL: https://www.opiq.ee/kit/43/chapter/2002
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.2
Topics ET: loodusõpetus
Topics RU: природоведение, рыбы, признаки, дыхание, подумай, размножение, знаю
Topics EN: science
Headings: Рыбы; Признаки рыб; Дыхание; Подумай; Размножение рыб; Я знаю, что...
Task examples: Чем покрыто тело рыб?; Отметь верные высказывания.

## Земноводные
URL: https://www.opiq.ee/kit/43/chapter/2003
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.3
Topics ET: loodusõpetus
Topics RU: природоведение, земноводные, признаки, земноводных, дыхание, размножение, знаю
Topics EN: science
Headings: Земноводные; Признаки земноводных; Дыхание; Размножение земноводных; Я знаю, что...
Task examples: Где живут земноводные?; С помощью чего дышат взрослые земноводные?

## Пресмыкаю­щиеся
URL: https://www.opiq.ee/kit/43/chapter/2004
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.4
Topics ET: loodusõpetus
Topics RU: природоведение, пресмыкаю, щиеся, признаки, пресмыкающихся, дыхание, размножение, такое, дополнительно
Topics EN: science
Headings: Пресмыкаю­щиеся; Признаки пресмыкающихся; Дыхание; Размножение пресмыкающихся; Что такое вид?; Дополнительно. Укус гадюки; Я знаю, что...
Task examples: Отметь верные высказывания.; У каких пресмыкающихся есть лапы? Распредели названия животных по нужным столбикам.

## Птицы
URL: https://www.opiq.ee/kit/43/chapter/2005
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, признаки, птиц, дыхание, дополнительно, летают, подумай, размножение
Topics EN: science, animal, animals, birds, insects
Headings: Птицы; Признаки птиц; Дыхание; Дополнительно. Все ли птицы летают?; Подумай; Размножение птиц; Дополнительно. Птенцы; Я знаю, что...
Task examples: Отметь признаки птиц.; Отметь верные высказывания.

## Млекопитаю­щие
URL: https://www.opiq.ee/kit/43/chapter/2006
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.6
Topics ET: loodusõpetus
Topics RU: природоведение, млекопитаю, признаки, млекопитающих, дыхание, дополнительно, может, тюлень, дышать, водой
Topics EN: science
Headings: Млекопитаю­щие; Признаки млекопитающих; Дыхание; Дополнительно. Может ли тюлень дышать под водой?; Размножение млекопитающих; Подумай; Дополнительно. Разнообразие мира млекопитающих; Я знаю, что...
Task examples: Что является для новорождённых млекопитающих первой едой?

## Беспозвоноч­ные животные
URL: https://www.opiq.ee/kit/43/chapter/2007
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, беспозвоноч, признаки, беспозвоночных, животных, паукообразные, знаю
Topics EN: science, animal, animals, birds, insects
Headings: Беспозвоноч­ные животные; Признаки беспозвоночных животных; Паукообразные и насекомые; Паукообразные; Насекомые; Я знаю, что...
Task examples: Где можно встретить беспозвоночных животных?; Какой общий признак у всех беспозвоночных животных?

## Растения
URL: https://www.opiq.ee/kit/43/chapter/2008
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.8
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, размножение, растений, производят, сахар, большинство, имеет, цвет
Topics EN: science, plant, plants, tree, flower
Headings: Растения; Размножение растений; Растения производят сахар; Большинство растений имеет зелёный цвет; Виды растений; Значение растений в жизни животных; Растения незаменимы в жизни человека; Подумай; Я знаю, что...
Task examples: Что есть у мхов и папоротников? Отметь нужные слова.; Что есть у цветковых растений? Отметь нужные слова.

## Ядовитые растения
URL: https://www.opiq.ee/kit/43/chapter/2009
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 2.9
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, ядовитые, произрастающие, эстонии, подумай, дополнительно, лекарственные, семейства, зонтичных
Topics EN: science, plant, plants, tree, flower
Headings: Ядовитые растения; Ядовитые растения, произрастающие в Эстонии; Подумай; Дополнительно. Лекарственные растения; Растения из семейства зонтичных; Ядовитые семена; Дополнительно. Ядовитые комнатные цветы; Я знаю, что...
Task examples: У каких плодов ядовитые семена?

## Земля
URL: https://www.opiq.ee/kit/43/chapter/2014
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 3.1
Topics ET: loodusõpetus
Topics RU: природоведение, земля, почему, планета, особенная, дополнительно, возникновение, жизни, земле
Topics EN: science
Headings: Земля; Почему планета Земля особенная?; Дополнительно. Возникновение жизни на Земле; Земля и Луна; Я знаю, что...
Task examples: Какие живые существа нуждаются в кислороде?; Благодаря чему возможна жизнь на Земле?

## Солнце
URL: https://www.opiq.ee/kit/43/chapter/2015
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 3.2
Topics ET: loodusõpetus
Topics RU: природоведение, солнце, солнечная, система, земля, вращается, вокруг, своей, обращается
Topics EN: science
Headings: Солнце; Солнце и Солнечная система; Земля вращается вокруг своей оси и обращается вокруг Солнца; Я знаю, что...
Task examples: Чем Земля отличается от других планет Солнечной cистемы?; Какие планеты входят в Солнечную систему?

## Свет и тень
URL: https://www.opiq.ee/kit/43/chapter/2016
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 3.3
Topics ET: loodusõpetus
Topics RU: природоведение, свет, тень, такое, источники, света, движение, дополнительно, луна
Topics EN: science
Headings: Свет и тень; Что такое источники света?; Движение света; Дополнительно. Луна не излучает свет; Я знаю, что...
Task examples: От чего отражается свет на второй фотографии?; Какие предметы являются источниками света? От каких предметов свет отражается? Распредели слова по столбикам.

## Повторение. Земля и Солнце
URL: https://www.opiq.ee/kit/43/chapter/2017
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 3.4
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, земля, солнце, обобщающая, фотогалерея
Topics EN: science, revision, review, practice
Headings: Повторение. Земля и Солнце; Обобщающая фотогалерея; Задания
Task examples: Перетащи кружок с цифрой в нужное место на картинке.; Какие утверждения правильные, а какие нет? Распредели предложения по столбикам.

## Информация, или сведения
URL: https://www.opiq.ee/kit/43/chapter/2018
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение, информация, сведения, такое, подумай, откуда, получаем, информацию, дополнительно
Topics EN: science
Headings: Информация, или сведения; Что такое информация?; Подумай; Откуда мы получаем информацию?; Дополнительно. Права детей; Конвенция о правах ребёнка, статья № 13; Дополнительно. Радио и телевидение; Радио; Телевидение; Я знаю, что...
Task examples: С помощью чего человек может получить информацию?; Что может быть источником информации?

## Реклама
URL: https://www.opiq.ee/kit/43/chapter/2019
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 4.2
Topics ET: loodusõpetus
Topics RU: природоведение, реклама, такое, подумай, история, рекламы, дополнительно, закон, рекламе
Topics EN: science
Headings: Реклама; Что такое реклама?; Подумай; История рекламы; Дополнительно. Закон о рекламе; Я знаю, что...
Task examples: Какова цель рекламы?

## Интернет
URL: https://www.opiq.ee/kit/43/chapter/2020
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 4.3
Topics ET: loodusõpetus
Topics RU: природоведение, интернет, такое, подумай, поиск, информации, интернете, опасности, интернета
Topics EN: science
Headings: Интернет; Что такое интернет?; Подумай; Поиск информации в интернете; Опасности интернета; Правила поведения в интернете; Я знаю, что...
Task examples: Что можно делать в интернете?; Что нельзя в интернете сообщать посторонним?

## Повторение. Информация, реклама, интернет
URL: https://www.opiq.ee/kit/43/chapter/2021
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 4.4
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, информация, реклама, интернет, обобщающая, фотогалерея
Topics EN: science, revision, review, practice
Headings: Повторение. Информация, реклама, интернет; Обобщающая фотогалерея; Задания
Task examples: Напиши, из каких источников можно узнать ответы на эти вопросы.

## Сила
URL: https://www.opiq.ee/kit/43/chapter/2022
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 5.1
Topics ET: loodusõpetus
Topics RU: природоведение, сила, такое, подумай, когда, силы, уравновешены, дополнительно, притяжения
Topics EN: science
Headings: Сила; Что такое сила?; Подумай; Когда силы уравновешены, а когда нет?; Дополнительно. Сила притяжения; Я знаю, что...
Task examples: Что делают люди на фотографии? Перетащи кружок с цифрой в нужное место.; В каком случае силы уравновешены?

## Движение
URL: https://www.opiq.ee/kit/43/chapter/2023
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 5.2
Topics ET: loodusõpetus
Topics RU: природоведение, движение, такое, пример, сила, трения, подумай, знаю
Topics EN: science
Headings: Движение; Что такое движение?; Пример; Сила трения; Подумай; Я знаю, что...
Task examples: Отметь характеристики движения.; Расстояние между Таллинном и Пярну 128 км. С какой средней скоростью надо ехать автомобилю, чтобы преодолеть это расстояние за 2 часа?

## Как использовать силу?
URL: https://www.opiq.ee/kit/43/chapter/2024
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 5.3
Topics ET: loodusõpetus
Topics RU: природоведение, использовать, силу, механизм, подумай, наклонная, плоскость, дополнительно, природе
Topics EN: science
Headings: Как использовать силу?; Механизм; Подумай; Наклонная плоскость; Дополнительно. Наклонная плоскость в природе; Рычаг; Третий вид; Первый вид; Второй вид; Дополнительно. При помощи рычага можно перемещать очень тяжелые тела; Я знаю, что...
Task examples: Перетащи кружок с цифрой на подходящую стрелку.; В чём выгода наклонной поверхности?

## Велосипед
URL: https://www.opiq.ee/kit/43/chapter/2025
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 5.4
Topics ET: loodusõpetus
Topics RU: природоведение, велосипед, устроен, подумай, дополнительно, шестер, велосипеда, истории, создания
Topics EN: science
Headings: Велосипед; Как устроен велосипед?; Подумай; Дополнительно. Шестерёнки велосипеда; Дополнительно. Из истории создания велосипеда; Я знаю, что...
Task examples: Что нужно для того, чтобы велосипед двигался или увеличивал скорость? Выбери нужное название детали велосипеда.; Что приводит к замедлению скорости велосипеда или его полной остановке? Выбери нужное название детали велосипеда.

## Безопасное движение на велосипеде
URL: https://www.opiq.ee/kit/43/chapter/2026
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 5.5
Topics ET: loodusõpetus
Topics RU: природоведение, безопасное, движение, велосипеде, требования, велосипедисту, велосипеду, подумай, знаю
Topics EN: science
Headings: Безопасное движение на велосипеде; Требования к велосипедисту и велосипеду; Подумай; Я знаю, что...
Task examples: Что должно быть у велосипеда?; У кого из участников дорожного движения есть преимущество в пересечении перекрёстка? Отметь цифрами порядок пересечения перекрёстка. Перетащи кружок с цифрой в нужное место.

## Повторение. Сила и движение
URL: https://www.opiq.ee/kit/43/chapter/2027
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 5.6
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, сила, движение, обобщающая, фотогалерея
Topics EN: science, revision, review, practice
Headings: Повторение. Сила и движение; Обобщающая фотогалерея; Задания
Task examples: Объясни, как связаны:; Выбери в окошечке подходящее описание для силы, воздействующей на предмет.

## Электричество и электричес­кий ток
URL: https://www.opiq.ee/kit/43/chapter/2029
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 6.1
Topics ET: loodusõpetus
Topics RU: природоведение, электричество, электричес, используем, подумай, такое, электрический, исследуй, знаю
Topics EN: science
Headings: Электричество и электричес­кий ток; Где мы используем электричество?; Подумай; Что такое электричество и электрический ток?; Исследуй; Я знаю, что...
Task examples: Что связано с использованием электричества? Отметь все верные ответы.; В каких случаях мы имеет дело с течением?

## Источник тока. Электрическая цепь
URL: https://www.opiq.ee/kit/43/chapter/2030
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 6.2
Topics ET: loodusõpetus
Topics RU: природоведение, источник, тока, электрическая, цепь, источники, подумай, дополнительно, сила
Topics EN: science
Headings: Источник тока. Электрическая цепь; Источники тока; Электрическая цепь; Подумай; Дополнительно. Электрическая сила источника тока; Исследуй (1); Исследуй (2); Я знаю, что...
Task examples: Сколько полюсов у источника тока?; Электрический ток вырабатывают...

## Проводники. Экономия электроэнергии
URL: https://www.opiq.ee/kit/43/chapter/2031
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 6.3
Topics ET: loodusõpetus
Topics RU: природоведение, проводники, экономия, электроэнергии, диэлектрики, подумай, исследуй, техника, безопасности
Topics EN: science
Headings: Проводники. Экономия электроэнергии; Проводники и диэлектрики; Подумай; Исследуй; Экономия электроэнергии; Техника безопасности; Я знаю, что ...
Task examples: Проводники – это ...; Какие предметы проводят электричество, а какие – нет?

## Магнит
URL: https://www.opiq.ee/kit/43/chapter/2028
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 6.4
Topics ET: loodusõpetus
Topics RU: природоведение, магнит, такое, дополнительно, открытие, магнита, компас, исследуй, знаю
Topics EN: science
Headings: Магнит; Что такое магнит?; Дополнительно. Открытие магнита; Компас; Исследуй; Я знаю, что...
Task examples: Как ты можешь проверить, является ли магнитом найденный кусок металла?; Где магнитные силы сильнее всего?

## Повторение. Электричество и энергия
URL: https://www.opiq.ee/kit/43/chapter/2032
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 6.5
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, электричество, энергия, обобщающая, фотогалерея
Topics EN: science, revision, review, practice
Headings: Повторение. Электричество и энергия; Обобщающая фотогалерея; Задания
Task examples: Перетащи кружок с цифрой в нужное место.; Выбери правильный вариант ответа.

## Эстония – морское государство
URL: https://www.opiq.ee/kit/43/chapter/2033
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.1
Topics ET: loodusõpetus
Topics RU: природоведение, эстония, морское, государство, жители, прибрежных, территорий, эстонские, моряки, дополнительно
Topics EN: science
Headings: Эстония – морское государство; Жители прибрежных территорий; Эстонские моряки; Дополнительно. Кихну Йынн; Подумай; Дополнительно. Маяк Кыпу на острове Хийумаа; Я знаю, что...
Task examples: Сколько островов в Эстонии?; Рассмотри карту. Откуда и куда можно поехать на пароме?

## Стороны света
URL: https://www.opiq.ee/kit/43/chapter/2034
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.2
Topics ET: loodusõpetus
Topics RU: природоведение, стороны, света, основные, промежуточные, направления, определение, сторон, дополнительно
Topics EN: science
Headings: Стороны света; Основные и промежуточные направления; Определение сторон света; Дополнительно. Cтороны света на компасе; Подумай; Дополнительно. Определение сторон света ночью; Дополнительно. Церкви; Я знаю, что...
Task examples: Как работает компас?; Что используют для ориентирования в незнакомой местности?

## Фотография, рисунок и план
URL: https://www.opiq.ee/kit/43/chapter/2035
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.3
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem
Topics RU: природоведение, сравнение, сравни, больше, меньше, фотография, рисунок, план, фотографии, рисунка, подумай, такое
Topics EN: science, comparison, compare, greater, less
Headings: Фотография, рисунок и план; Сравнение фотографии и рисунка; Подумай; Что такое план?; Я знаю, что...
Task examples: Почему на плане не указывают людей?; Отметь верное высказывание.

## Фотография, аэрофотосни­мок и план
URL: https://www.opiq.ee/kit/43/chapter/2036
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.4
Topics ET: loodusõpetus
Topics RU: природоведение, фотография, аэрофотосни, план, аэрофотоснимок, подумай, знаю
Topics EN: science
Headings: Фотография, аэрофотосни­мок и план; Фотография и аэрофотоснимок; Подумай; Аэрофотоснимок и план; Я знаю, что...
Task examples: Как представлена на плане местность?; Сравни аэрофотоснимок и план. Отметь вопросы, на которые легче ответить с помощью плана.

## Аэрофотосни­мок и карта
URL: https://www.opiq.ee/kit/43/chapter/2037
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.5
Topics ET: loodusõpetus
Topics RU: природоведение, аэрофотосни, карта, аэрофотоснимок, центральной, части, города, таллинна, подумай, такое
Topics EN: science
Headings: Аэрофотосни­мок и карта; Аэрофотоснимок центральной части города Таллинна; Подумай; Что такое карта?; Исследуй; Я знаю, что...
Task examples: Каким знаком на карте Старого города обозначены башни городской стены?; Легенда объясняет, ...

## Как читать карту?
URL: https://www.opiq.ee/kit/43/chapter/2038
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.6
Topics ET: loodusõpetus
Topics RU: природоведение, читать, карту, условные, знаки, картографическая, сетка, масштаб, исследуй
Topics EN: science
Headings: Как читать карту?; Условные знаки; Картографическая сетка и масштаб; Исследуй карту; Я знаю, что...
Task examples: Что такое условный знак?; Для чего на карте нужен масштаб?

## Карта
URL: https://www.opiq.ee/kit/43/chapter/2039
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.7
Topics ET: loodusõpetus
Topics RU: природоведение, карта, изображают, картах, исследуй, изображение, высот, карте, подумай
Topics EN: science
Headings: Карта; Что изображают на картах?; Исследуй; Изображение высот на карте; Подумай; Я знаю, что...
Task examples: Рассмотри карту. Где море глубже, между островами Хийумаа (Hiiumaa) и Вормси (Vormsi) или между Хийумаа и Муху (Muhu)?; Рассмотри карту. Сравни возвышенности Карула (Karula) и Отепя (Otepää). Какая из них выше?

## Карта Эстонии
URL: https://www.opiq.ee/kit/43/chapter/2040
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.8
Topics ET: loodusõpetus
Topics RU: природоведение, карта, эстонии, ландшафт, исследуй, карту, водо, острова, полуострова
Topics EN: science
Headings: Карта Эстонии; Ландшафт Эстонии; Исследуй карту; Водоёмы; Острова, полуострова и заливы; Подумай; Я знаю, что...
Task examples: Рассмотри карту. Куда впадает река Пярну?; Рассмотри карту. Куда впадает река Выханду?

## Повторение. Месторасположение и карта
URL: https://www.opiq.ee/kit/43/chapter/2041
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 7.9
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, месторасположение, карта, обобщающая, фотогалерея
Topics EN: science, revision, review, practice
Headings: Повторение. Месторасположение и карта; Обобщающая фотогалерея; Задания
Task examples: Перетащи кружок с цифрой в нужное место.; Какие утверждения верные, а какие нет? Распредели предложения по столбикам.

## Школа
URL: https://www.opiq.ee/kit/43/chapter/2042
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 8.1
Topics ET: loodusõpetus
Topics RU: природоведение, школа, обучение, раньше, сейчас, подумай, учились, дополнительно, график
Topics EN: science
Headings: Школа; Обучение раньше и сейчас; Подумай; Как учились раньше?; Дополнительно. График посещения школы в старину; Учиться можно и вне стен школы; Я знаю, что...
Task examples: Сколько лет первой книге на эстонском языке?; Выбери нужное слово.

## Традиции
URL: https://www.opiq.ee/kit/43/chapter/2043
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 8.2
Topics ET: loodusõpetus, mardipäev
Topics RU: природоведение, традиции, такое, традиция, подумай, мартов, день, ноября, кадри
Topics EN: science
Headings: Традиции; Что такое традиция?; Подумай; Мартов день (mardipäev), 10 ноября; День Кадри (kadripäev), 25 ноября; Рождественские праздники (jõulud), 24 декабря – 6 января; Масленица (vastlapäev); Пасха, или день Воскресения Иисуса Христа, или праздник Весны (ülestõusmispüha); Яанов день (jaanipäev), 24 июня; Я знаю, что...
Task examples: По указанной дате определи название праздника.; О каком празднике идёт речь? Выбери название праздника.

## Эстония
URL: https://www.opiq.ee/kit/43/chapter/2044
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 8.3
Topics ET: loodusõpetus
Topics RU: природоведение, эстония, находится, государственная, оборона, подумай, знаю
Topics EN: science
Headings: Эстония; Где находится Эстония?; Государственная оборона; Подумай; Я знаю, что...
Task examples: Рассмотри карту. Какие государства Юго-Восточной Европы входят в состав Европейского союза?; Рассмотри карту. Какие государства являются членами Европейского союза?

## Тоомпеа
URL: https://www.opiq.ee/kit/43/chapter/2045
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 8.4
Topics ET: loodusõpetus
Topics RU: природоведение, тоомпеа, значимость, подумай, дополнительно, народном, предании, государственное, управление
Topics EN: science
Headings: Тоомпеа; В чём значимость Тоомпеа?; Подумай; Дополнительно. Тоомпеа в народном предании; Государственное управление; Я знаю, что...
Task examples: Какое здание на Тоомпеа было построено последним?; Что такое Длинный Герман?

## Оккупация Эстонии
URL: https://www.opiq.ee/kit/43/chapter/2046
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 8.5
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, aeg, kell, kalender
Topics RU: природоведение, сравнение, сравни, больше, меньше, время, часы, календарь, оккупация, эстонии, такое, жизнь, оккупации, подумай
Topics EN: science, comparison, compare, greater, less, time, clock, calendar
Headings: Оккупация Эстонии; Что такое оккупация?; Жизнь во время оккупации; Подумай; Сравнение Эстонии в период оккупации и в наши дни; Эстония в период оккупации; Эстония в наши дни; Я знаю, что...
Task examples: Отметь верное высказывание.; Что такое оккупация?

## Государства-соседи Эстонии
URL: https://www.opiq.ee/kit/43/chapter/2047
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 8.6
Topics ET: loodusõpetus
Topics RU: природоведение, государства, соседи, эстонии, сколько, соседей, подумай, прибалтика, латвия
Topics EN: science
Headings: Государства-соседи Эстонии; Сколько соседей у Эстонии?; Подумай; Прибалтика; Латвия; Литва; Финляндия; Швеция; Россия; Я знаю, что...
Task examples: Какое государство является западным соседом Эстонии?; Отметь соседние с Эстонией государства.

## Повторение. Традиции Эстонии, её история и соседние государства
URL: https://www.opiq.ee/kit/43/chapter/2048
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 8.7
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, традиции, эстонии, история, соседние, государства, обобщающая, фотогалерея
Topics EN: science, revision, review, practice
Headings: Повторение. Традиции Эстонии, её история и соседние государства; Обобщающая фотогалерея; Задания
Task examples: Сравни Эстонию в период оккупации и в наши дни.; Какие задачи стоят перед:

## Повторение. Природа
URL: https://www.opiq.ee/kit/43/chapter/2049
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 9.1
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда, живая, подумай, неживая
Topics EN: science, revision, review, practice, nature, environment
Headings: Повторение. Природа; Живая природа; Подумай; Неживая природа

## Повторение. Как всё взаимосвязано?
URL: https://www.opiq.ee/kit/43/chapter/2050
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 9.2
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда, взаимосвязано, живая, неживая, связаны, между, собой, подумай
Topics EN: science, revision, review, practice, nature, environment
Headings: Повторение. Как всё взаимосвязано?; Живая и неживая природа связаны между собой; Подумай

## Повторение. Вода
URL: https://www.opiq.ee/kit/43/chapter/2051
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 9.3
Topics ET: loodusõpetus, kordamine, korda, harjutan, vesi, veeohutus, veekogu
Topics RU: природоведение, повторение, повтори, тренировка, вода, безопасность на воде, водоём, состояния, воды, круговорот, подумай
Topics EN: science, revision, review, practice, water, water safety, body of water
Headings: Повторение. Вода; Состояния воды; Круговорот воды; Подумай

## Повторение. Здоровый образ жизни
URL: https://www.opiq.ee/kit/43/chapter/2052
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 9.4
Topics ET: loodusõpetus, kordamine, korda, harjutan, inimene, keha, meeled, tervis
Topics RU: природоведение, повторение, повтори, тренировка, человек, тело, чувства, здоровье, здоровый, образ, жизни, какого, человека, называют, здоровым, такое
Topics EN: science, revision, review, practice, human, body, senses, health
Headings: Повторение. Здоровый образ жизни; Какого человека называют здоровым?; Что такое здоровый образ жизни?; Движение; Питание; Чистое тело; Отдых; Подумай

## Повторение. Солнечная система
URL: https://www.opiq.ee/kit/43/chapter/2053
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 9.5
Topics ET: loodusõpetus, kordamine, korda, harjutan
Topics RU: природоведение, повторение, повтори, тренировка, солнечная, система, исследуй, движение, земли, луны, подумай
Topics EN: science, revision, review, practice
Headings: Повторение. Солнечная система; Солнечная система; Исследуй; Движение Земли и Луны; Подумай

## Повторение. Люди
URL: https://www.opiq.ee/kit/43/chapter/2054
Book: Эстония
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Avita
Book ID: 3k_loodus_avita_2023_rus
Chapter ID: 9.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда, люди, культура, подумай, законы, лебедь, щука
Topics EN: science, revision, review, practice, nature, environment
Headings: Повторение. Люди; Природа и культура; Подумай; Законы; Лебедь, рак и щука

## Loodus- ja inimeseõpetus 3. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/30
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 66
Topics ET: loodusõpetus, loodus, keskkond, inimeseõpetus, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Eesti
URL: https://www.opiq.ee/kit/30/chapter/1396
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 1.1
Topics ET: loodusõpetus, eesti, kaart, uuri, kaarti, elavad, eestis, tean
Topics RU: природоведение
Topics EN: science
Headings: Eesti; Eesti kaart; Uuri kaarti!; Kes elavad Eestis?; Ma tean, et ...
Task examples: Millised maakonnad on ühtlasi ka saared?; Mitu maakonda on Eestis?

## Rahvuslik ärkamine
URL: https://www.opiq.ee/kit/30/chapter/1397
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 1.2
Topics ET: loodusõpetus, rahvuslik, ärkamine, eesti, rahva, mõtle, esimesed, ajalehed, kalevipoeg
Topics RU: природоведение
Topics EN: science
Headings: Rahvuslik ärkamine; Eesti rahva ärkamine; Mõtle!; Esimesed ajalehed ja „Kalevipoeg”; Ma tean, et ...
Task examples: Millal toimus esimene laulupidu?; Mis oli esimene eestikeelne ajaleht?

## Talu
URL: https://www.opiq.ee/kit/30/chapter/1398
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 1.3
Topics ET: loodusõpetus, talu, rehemaja, aidad, laut, mõtle, saun, sepikoda, suveköök
Topics RU: природоведение
Topics EN: science
Headings: Talu; Rehemaja; Aidad; Laut; Mõtle!; Saun; Sepikoda ja suveköök; Ma tean, et ...
Task examples: Mida on kirjeldatud? Vali rippmenüüst õige sõna.; Mis meil tänapäeval aida asemel on?

## Rahvariided
URL: https://www.opiq.ee/kit/30/chapter/1399
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 1.4
Topics ET: loodusõpetus, rahvariided, pidulik, riietus, argi, käimarõivad, millest, riided, valmistati
Topics RU: природоведение
Topics EN: science
Headings: Rahvariided; Pidulik riietus; Argi- ja käimarõivad; Millest riided valmistati?; Linast riiet saadi linataimest; Villast lõnga saadi lambavillast; Ma tean, et ...
Task examples: Märgi riided, mida mehed kandsid.; Võrdle argi- ja piduriideid. Lohista neid iseloomustavad väited õige pealkirja alla.

## Mineviku pärand
URL: https://www.opiq.ee/kit/30/chapter/1400
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 1.5
Topics ET: loodusõpetus, mineviku, pärand, näeb, minevikku, pärnu, tänapäeval, minevikus, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Mineviku pärand; Kus näeb minevikku?; Pärnu tänapäeval ja minevikus; Mõtle!; Ma tean, et ...
Task examples: Mis juhtus varem, mis hiljem? Lohista laused õigesse järjekorda. Alusta kõige varem toimunust.

## Kordamine. Eesti
URL: https://www.opiq.ee/kit/30/chapter/1839
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 1.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, eesti, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Eesti; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Lohista maakondade nimed kaardile.; Vali rippmenüüst sõna, mida on kirjeldatud.

## Eluslooduse jaotus
URL: https://www.opiq.ee/kit/30/chapter/1448
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 10.1
Topics ET: loodusõpetus, eluslooduse, jaotus
Topics RU: природоведение
Topics EN: science
Headings: Eluslooduse jaotus

## Eestimaa
URL: https://www.opiq.ee/kit/30/chapter/1449
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 10.2
Topics ET: loodusõpetus, eestimaa, olulised, faktid, eesti, kohta
Topics RU: природоведение
Topics EN: science
Headings: Eestimaa; Olulised faktid Eesti kohta

## Maakonnad
URL: https://www.opiq.ee/kit/30/chapter/1450
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 10.3
Topics ET: loodusõpetus, maakonnad, eesti, maakondade, vapid
Topics RU: природоведение
Topics EN: science
Headings: Maakonnad; Eesti maakondade vapid

## Mõisted
URL: https://www.opiq.ee/kit/30/chapter/12295
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 10.4
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/30/chapter/1452
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 10.5
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Selgroogsed loomad
URL: https://www.opiq.ee/kit/30/chapter/1401
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.1
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgroogsed, selgroogsete, loomade, rühmad, tean
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgroogsed loomad; Kes on selgroogsed loomad?; Selgroogsete loomade rühmad; Ma tean, et ...
Task examples: Mis on kõigil selgroogsetel loomadel?; Loetle selgroogsete loomade rühmad. Too iga rühma kohta näiteks üks loom, kes sinna kuulub.

## Seened
URL: https://www.opiq.ee/kit/30/chapter/1410
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.10
Topics ET: loodusõpetus, seened, seente, tunnused, toitumine, kasvamine, kooselu, taimejuurtega, söögina
Topics RU: природоведение
Topics EN: science
Headings: Seened; Seente tunnused; Toitumine ja kasvamine; Kooselu taimejuurtega; Seened söögina; Lisa. Linnas kasvavaid seeni ära söö!; Mürgised seened; Lisa. Hallitusseened; Seeneliigid; Mõtle!; Ma tean, et ...
Task examples: Lohista seene osad õigesse kohta.; Mille abil seened paljunevad?

## Bakterid
URL: https://www.opiq.ee/kit/30/chapter/1411
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.11
Topics ET: loodusõpetus, bakterid, bakterite, tunnused, tähtsus, mõtle, lisa, tean
Topics RU: природоведение
Topics EN: science
Headings: Bakterid; Bakterite tunnused; Bakterite tähtsus; Mõtle!; Lisa. Bakterid; Ma tean, et ...
Task examples: Mida teevad bakterid?; Kus võib leida baktereid?

## Kooslused
URL: https://www.opiq.ee/kit/30/chapter/1412
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.12
Topics ET: loodusõpetus, kooslused, kooslus, toiduahel, toiduvõrk, tean
Topics RU: природоведение
Topics EN: science
Headings: Kooslused; Mis on kooslus?; Toiduahel; Toiduvõrk; Ma tean, et ...
Task examples: Kuidas nimetatakse koos elavaid loomi, taimi ja seeni?; Millest algab toiduahel?

## Kordamine. Elusloodus
URL: https://www.opiq.ee/kit/30/chapter/1838
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.13
Topics ET: loodusõpetus, kordamine, korda, harjutan, elusloodus, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Elusloodus; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Märgi tabelites lahtritesse õige tekst.; Kirjuta, kuidas need loomad liiguvad (lennates, ujudes, kõndides, joostes, hüpates, roomates). Arutage vastuseid tunnis.

## Kalad
URL: https://www.opiq.ee/kit/30/chapter/1402
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.2
Topics ET: loodusõpetus, kalad, kalade, tunnused, hingamine, mõtle, paljunemine, tean
Topics RU: природоведение
Topics EN: science
Headings: Kalad; Kalade tunnused; Hingamine; Mõtle!; Kalade paljunemine; Ma tean, et ...
Task examples: Mis katab kalade keha?; Märgi tõesed väited.

## Kahepaiksed
URL: https://www.opiq.ee/kit/30/chapter/1403
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.3
Topics ET: loodusõpetus, kahepaiksed, kahepaiksete, tunnused, hingamine, paljunemine, tean
Topics RU: природоведение
Topics EN: science
Headings: Kahepaiksed; Kahepaiksete tunnused; Hingamine; Kahepaiksete paljunemine; Ma tean, et ...
Task examples: Kus kahepaiksed elavad?; Millega täiskasvanud kahepaiksed hingavad?

## Roomajad
URL: https://www.opiq.ee/kit/30/chapter/1404
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.4
Topics ET: loodusõpetus, roomajad, roomajate, tunnused, hingamine, paljunemine, liik, lisa, rästiku
Topics RU: природоведение
Topics EN: science
Headings: Roomajad; Roomajate tunnused; Hingamine; Roomajate paljunemine; Mis on liik?; Lisa. Rästiku hammustus; Ma tean, et ...
Task examples: Lohista roomajad õige pealkirja alla.; Lohista roomajad õige pealkirja alla.

## Linnud
URL: https://www.opiq.ee/kit/30/chapter/1405
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, lindude, tunnused, hingamine, lisa, kõik, lendavad, mõtle
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnud; Lindude tunnused; Hingamine; Lisa. Kas kõik linnud lendavad?; Mõtle!; Lindude paljunemine; Lisa. Linnupojad; Ma tean, et ...
Task examples: Märgi ära lindude tunnused.

## Imetajad
URL: https://www.opiq.ee/kit/30/chapter/1406
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.6
Topics ET: loodusõpetus, imetajad, imetajate, tunnused, hingamine, lisa, hüljes, saab, hingata
Topics RU: природоведение
Topics EN: science
Headings: Imetajad; Imetajate tunnused; Hingamine; Lisa. Kas hüljes saab vee all hingata?; Imetajate paljunemine; Mõtle!; Lisa. Erinevad imetajad; Ma tean, et ...
Task examples: Kes hingavad kopsudega?; Mis on kõigi maailma imetajate esimene toit?

## Selgrootud loomad
URL: https://www.opiq.ee/kit/30/chapter/1407
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.7
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgrootud, selgrootute, tunnused, ämblikulaadsed, tean
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgrootud loomad; Selgrootute tunnused; Ämblikulaadsed ja putukad; Ämblikulaadsed; Putukad; Ma tean, et ...
Task examples: Kus võib selgrootuid näha?; Mille poolest on kõik selgrootud sarnased?

## Taimed
URL: https://www.opiq.ee/kit/30/chapter/1408
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.8
Topics ET: loodusõpetus, taim, taimed, puu, lill, taimede, paljunemine, toodavad, suhkrut, rohelised, taimeliigid, tähtsus
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed; Taimede paljunemine; Taimed toodavad suhkrut; Taimed on rohelised; Taimeliigid; Taimede tähtsus loomadele; Taimed on inimestele tähtsad; Mõtle!; Ma tean, et ...
Task examples: Mis on sõnajalgtaimedel ja sammaldel?; Mis on sõnajalgtaimedel ja sammaldel?

## Mürgised taimed
URL: https://www.opiq.ee/kit/30/chapter/1409
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 2.9
Topics ET: loodusõpetus, taim, taimed, puu, lill, mürgised, eestis, mõtle, lisa, ravimina, putked, seemned
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Mürgised taimed; Mürgised taimed Eestis; Mõtle!; Lisa. Taimed ravimina; Putked; Mürgised seemned; Lisa. Mürgised toalilled; Ma tean, et ...
Task examples: Märgi ära mürgiste seemnetega viljad.

## Maa
URL: https://www.opiq.ee/kit/30/chapter/1413
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 3.1
Topics ET: loodusõpetus, miks, eriline, lisa, algus, maal, tean
Topics RU: природоведение
Topics EN: science
Headings: Maa; Miks on Maa eriline?; Lisa. Elu algus Maal; Maa ja Kuu; Ma tean, et ...
Task examples: Millised elusolendid vajavad hapnikku?; Mis teevad elu Maal võimalikuks?

## Päike
URL: https://www.opiq.ee/kit/30/chapter/1414
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 3.2
Topics ET: loodusõpetus, päike, päikesesüsteem, pöörleb, ümber, telje, tiirleb, päikese, tean
Topics RU: природоведение
Topics EN: science
Headings: Päike; Päike ja Päikesesüsteem; Maa pöörleb ümber oma telje ja tiirleb ümber Päikese; Ma tean, et ...
Task examples: Mille poolest erineb Maa teistest Päikesesüsteemi planeetidest?; Millised planeedid kuuluvad meie Päikesesüsteemi?

## Valgus ja vari
URL: https://www.opiq.ee/kit/30/chapter/1415
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 3.3
Topics ET: loodusõpetus, valgus, vari, valgusallikad, valguse, liikumine, lisa, kiirga, valgust
Topics RU: природоведение
Topics EN: science
Headings: Valgus ja vari; Mis on valgusallikad?; Valguse liikumine; Lisa. Kuu ei kiirga valgust; Ma tean, et ...
Task examples: Kummal fotol liigub valgus allikast otse silma?; Millised asjad on valgusallikad? Millistelt asjadelt valgus peegeldub? Lohista sõnad õige pealkirja alla.

## Kordamine. Maa ja Päike
URL: https://www.opiq.ee/kit/30/chapter/1837
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 3.4
Topics ET: loodusõpetus, kordamine, korda, harjutan, päike, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Maa ja Päike; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Lohista nimetused pildil õigesse kohta.; Millised laused on õiged, millised valed? Lohista laused õige pealkirja alla.

## Teave ehk informatsioon
URL: https://www.opiq.ee/kit/30/chapter/1416
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 4.1
Topics ET: loodusõpetus, teave, informatsioon, mõtle, kust, saab, teavet, lisa, lapse
Topics RU: природоведение
Topics EN: science
Headings: Teave ehk informatsioon; Mis on informatsioon?; Mõtle!; Kust saab teavet?; Lisa. Lapse õigused; Lapse õiguste konventsioon, artikkel 13; Lisa. Raadio ja televisioon; Raadio; Televisioon; Ma tean, et ...
Task examples: Millega võtavad inimesed infot vastu?; Mis võivad olla infoallikad?

## Reklaam
URL: https://www.opiq.ee/kit/30/chapter/1417
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 4.2
Topics ET: loodusõpetus, reklaam, mõtle, reklaami, ajalugu, lisa, reklaamiseadus, tean
Topics RU: природоведение
Topics EN: science
Headings: Reklaam; Mis on reklaam?; Mõtle!; Reklaami ajalugu; Lisa. Reklaamiseadus; Ma tean, et ...
Task examples: Mis võib olla reklaami eesmärk?

## Internet
URL: https://www.opiq.ee/kit/30/chapter/1418
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 4.3
Topics ET: loodusõpetus, internet, mõtle, internetist, info, otsimine, kuidas, otsida, infot
Topics RU: природоведение
Topics EN: science
Headings: Internet; Mis on internet?; Mõtle!; Internetist info otsimine; Kuidas otsida infot internetist?; Ohud internetis; Internetis käitumine; Ma tean, et ...
Task examples: Mida saab internetis teha?; Mida ei tohi internetis võõrastele avaldada?

## Kordamine. Teave, reklaam, internet
URL: https://www.opiq.ee/kit/30/chapter/1840
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 4.4
Topics ET: loodusõpetus, kordamine, korda, harjutan, teave, reklaam, internet, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Teave, reklaam, internet; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Kirjuta, millistest allikatest saad vastuseid järgmistele küsimustele.

## Jõud
URL: https://www.opiq.ee/kit/30/chapter/1419
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 5.1
Topics ET: loodusõpetus, jõud, mõtle, millal, tasakaalus, mitte, lisa, raskusjõud, tean
Topics RU: природоведение
Topics EN: science
Headings: Jõud; Mis on jõud?; Mõtle!; Millal on jõud tasakaalus, millal mitte?; Lisa. Raskusjõud; Ma tean, et ...
Task examples: Lohista tegevusi tähistavad numbrid pildil õigesse kohta.; Kehale mõjuvad jõud on tasakaalus, kui need on ...

## Liikumine
URL: https://www.opiq.ee/kit/30/chapter/1420
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 5.2
Topics ET: loodusõpetus, liikumine, näide, hõõrdejõud, mõtle, tean
Topics RU: природоведение
Topics EN: science
Headings: Liikumine; Mis on liikumine?; Näide; Hõõrdejõud; Mõtle!; Ma tean, et ...
Task examples: Mis on liikumise tunnused?; Pärnu ja Tallinna vahemaa on 128 km. Kui autol kulus selle läbimiseks 2 tundi, kui suur oli auto keskmine kiirus?

## Kuidas jõudu kasutada?
URL: https://www.opiq.ee/kit/30/chapter/1421
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 5.3
Topics ET: loodusõpetus, kuidas, jõudu, kasutada, masinad, mõtle, kaldpind, lisa, kaldpinnad
Topics RU: природоведение
Topics EN: science
Headings: Kuidas jõudu kasutada?; Masinad; Mõtle!; Kaldpind; Lisa. Kaldpinnad looduses; Kang; Esimene liik; Teine liik; Kolmas liik; Lisa. Kangiga saab liigutada väga raskeid kehasid; Ma tean, et ...
Task examples: Lohista numbrid joonisel õigetele nooltele.; Kui asja lükata piki kaldteed üles selle asemel, et seda otse üles tõsta, ...

## Jalgratas
URL: https://www.opiq.ee/kit/30/chapter/1422
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 5.4
Topics ET: loodusõpetus, jalgratas, kuidas, töötab, mõtle, lisa, jalgratta, käigud, ajalugu
Topics RU: природоведение
Topics EN: science
Headings: Jalgratas; Kuidas jalgratas töötab?; Mõtle!; Lisa. Jalgratta käigud; Lisa. Jalgratta ajalugu; Ma tean, et ...
Task examples: Mida on vaja selleks, et jalgratas liikuma panna või liikumiskiirust suurendada?; Mida on vaja selleks, et jalgratta liikumiskiirust aeglustada või seisma jääda?

## Ohutu jalgrattasõit
URL: https://www.opiq.ee/kit/30/chapter/1423
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 5.5
Topics ET: loodusõpetus, ohutu, jalgrattasõit, töökorras, jalgratas, mõtle, jalgrattaga, liikluses, tean
Topics RU: природоведение
Topics EN: science
Headings: Ohutu jalgrattasõit; Töökorras jalgratas; Mõtle!; Jalgrattaga liikluses; Ma tean, et ...
Task examples: Mis peab jalgrattal olema?; Mida tuleb teha, kui tahad tee äärde pargitud autost jalgrattaga mööduda? Lohista laused õigesse järjekorda.

## Kordamine. Jõud ja liikumine
URL: https://www.opiq.ee/kit/30/chapter/1841
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 5.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, jõud, liikumine, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Jõud ja liikumine; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Seleta, kuidas on seotud ...; Vali rippmenüüst, mida jõud piltidel põhjustab.

## Elekter ja elektrivool
URL: https://www.opiq.ee/kit/30/chapter/1424
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 6.1
Topics ET: loodusõpetus, elekter, elektrivool, kasutame, elektrit, mõtle, katseta, tean
Topics RU: природоведение
Topics EN: science
Headings: Elekter ja elektrivool; Kus me kasutame elektrit?; Mõtle!; Mis on elekter ja elektrivool?; Katseta; Ma tean, et ...
Task examples: Vali tegevused, milleks kasutame elektrienergiat.; Millistel juhtudel on tegemist voolamisega?

## Vooluallikas ja vooluring
URL: https://www.opiq.ee/kit/30/chapter/1425
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 6.2
Topics ET: loodusõpetus, vooluallikas, vooluring, vooluallikad, mõtle, lisa, vooluallika, elektrijõud, katseta
Topics RU: природоведение
Topics EN: science
Headings: Vooluallikas ja vooluring; Vooluallikad; Vooluring; Mõtle!; Lisa. Vooluallika elektrijõud; Katseta 1; Katseta 2; Ma tean, et ...
Task examples: Mitu poolust on vooluallikal?; Kust saab elektrivoolu?

## Elektrijuhid ja elektri säästmine
URL: https://www.opiq.ee/kit/30/chapter/1426
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 6.3
Topics ET: loodusõpetus, elektrijuhid, elektri, säästmine, mitteelektrijuhid, mõtle, katseta, ohutusnõuded, tean
Topics RU: природоведение
Topics EN: science
Headings: Elektrijuhid ja elektri säästmine; Elektrijuhid ja mitteelektrijuhid; Mõtle!; Katseta; Elektri säästmine; Ohutusnõuded; Ma tean, et ...
Task examples: Millised esemed juhivad elektrit ja millised mitte?; Millised materjalid juhtisid elektrit ja millised mitte?

## Magnet ja kompass
URL: https://www.opiq.ee/kit/30/chapter/1427
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 6.4
Topics ET: loodusõpetus, magnet, kompass, lisa, magneti, avastamine, katseta, tean
Topics RU: природоведение
Topics EN: science
Headings: Magnet ja kompass; Magnet; Lisa. Magneti avastamine; Kompass; Katseta; Ma tean, et ...
Task examples: Vali lünka õige sõna.; Kuidas saad kontrollida, kas leitud metallitükk on magnet?

## Kordamine. Elektrivool ja magnetid
URL: https://www.opiq.ee/kit/30/chapter/1842
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 6.5
Topics ET: loodusõpetus, kordamine, korda, harjutan, elektrivool, magnetid, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Elektrivool ja magnetid; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Lohista numbrid õigesse kohta.; Millised materjalid juhivad elektrit ja millised mitte?

## Mereriik Eesti
URL: https://www.opiq.ee/kit/30/chapter/1428
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.1
Topics ET: loodusõpetus, mereriik, eesti, rannarahvas, meremehed, lisa, kihnu, jõnn, mõtle, kõpu
Topics RU: природоведение
Topics EN: science
Headings: Mereriik Eesti; Rannarahvas; Eesti meremehed; Lisa. Kihnu Jõnn; Mõtle!; Lisa. Kõpu tuletorn Hiiumaal; Eesti kui mereriik; Ma tean, et ...
Task examples: Mitu meresaart ja laidu Eestil on?; Kuhu saab praamiga sõita? Vasta kaardi põhjal.

## Ilmakaared
URL: https://www.opiq.ee/kit/30/chapter/1429
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.2
Topics ET: loodusõpetus, ilmakaared, põhi, vaheilmakaared, ilmakaarte, määramine, lisa, kompassil, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Ilmakaared; Põhi- ja vaheilmakaared; Ilmakaarte määramine; Lisa. Ilmakaared kompassil; Mõtle!; Lisa. Ilmakaarte määramine öösel; Lisa. Kirikud; Ma tean, et ...
Task examples: Mis põhimõttel kompass töötab?; Mille abil saab orienteeruda?

## Foto, joonistus, plaan
URL: https://www.opiq.ee/kit/30/chapter/1430
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.3
Topics ET: loodusõpetus, foto, joonistus, plaan, joonistuse, võrdlus, mõtle, tean
Topics RU: природоведение
Topics EN: science
Headings: Foto, joonistus, plaan; Foto ja joonistuse võrdlus; Mõtle!; Mis on plaan?; Ma tean, et ...
Task examples: Miks ei märgita plaanile inimesi?; Märgi ära tõesed laused.

## Foto, aerofoto ja plaan
URL: https://www.opiq.ee/kit/30/chapter/1431
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.4
Topics ET: loodusõpetus, foto, aerofoto, plaan, mõtle, tean
Topics RU: природоведение
Topics EN: science
Headings: Foto, aerofoto ja plaan; Foto ja aerofoto; Mõtle!; Aerofoto ja plaan; Ma tean, et ...
Task examples: Kuidas kujutatakse maastikku plaanil?; Märgi ära küsimused, millele on loomaaia plaani abil lihtsam vastata kui aerofoto abil.

## Aerofoto ja kaart
URL: https://www.opiq.ee/kit/30/chapter/1432
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.5
Topics ET: loodusõpetus, aerofoto, kaart, tallinna, kesklinnast, mõtle, uuri, tean
Topics RU: природоведение
Topics EN: science
Headings: Aerofoto ja kaart; Aerofoto Tallinna kesklinnast; Mõtle!; Mis on kaart?; Uuri!; Ma tean, et ...
Task examples: Millise märgiga on vanalinna kaardil tähistatud linnamüüri tornid?; Legend selgitab, ...

## Kuidas kaarti lugeda?
URL: https://www.opiq.ee/kit/30/chapter/1433
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.6
Topics ET: loodusõpetus, kuidas, kaarti, lugeda, leppemärgid, ruudustik, mõõtkava, uuri, karksi
Topics RU: природоведение
Topics EN: science
Headings: Kuidas kaarti lugeda?; Leppemärgid; Ruudustik ja mõõtkava; Uuri kaarti!; Karksi-Nuia tänavate loend; Ma tean, et ...
Task examples: Mis või kes on leppemärk?; Miks on kaardil mõõtkava?

## Kaart
URL: https://www.opiq.ee/kit/30/chapter/1434
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.7
Topics ET: loodusõpetus, kaart, mida, kaardil, kujutatakse, uuri, kõrguste, kujutamine, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Kaart; Mida kaardil kujutatakse?; Uuri!; Kõrguste kujutamine kaardil; Mõtle!; Ma tean, et ...
Task examples: Vasta kaardi põhjal. Kus on meri sügavam, kas Hiiumaa ja Vormsi vahel või Hiiumaa ja Muhu vahel?; Vasta kaardi põhjal. Kumb on kõrgem, kas Karula või Otepää kõrgustik?

## Eesti kaart
URL: https://www.opiq.ee/kit/30/chapter/1435
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.8
Topics ET: loodusõpetus, eesti, kaart, maastik, uuri, kaarti, veekogud, saared, poolsaared
Topics RU: природоведение
Topics EN: science
Headings: Eesti kaart; Eesti maastik; Uuri kaarti!; Veekogud; Saared, poolsaared ja lahed; Mõtle!; Ma tean, et ...
Task examples: Vasta kaardi põhjal. Millisesse merre või järve voolab Pärnu jõgi?; Vasta kaardi põhjal. Millisesse merre või järve voolab Võhandu jõgi?

## Kordamine. Asukoht ja kaart
URL: https://www.opiq.ee/kit/30/chapter/1843
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 7.9
Topics ET: loodusõpetus, kordamine, korda, harjutan, asukoht, kaart, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Asukoht ja kaart; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Lohista numbrid õigesse kohta.; Kas väide on õige või vale? Lohista sobiva pealkirja alla.

## Kool
URL: https://www.opiq.ee/kit/30/chapter/1436
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 8.1
Topics ET: loodusõpetus, kool, õppimine, enne, nüüd, mõtle, kuidas, varem, õpiti
Topics RU: природоведение
Topics EN: science
Headings: Kool; Õppimine enne ja nüüd; Mõtle!; Kuidas varem õpiti?; Lisa. Millal käidi koolis?; Õppida saab ka väljaspool kooli; Ma tean, et ...
Task examples: Kui vana on esimene eestikeelne raamat?; Vali lünka õige sõna.

## Traditsioonid
URL: https://www.opiq.ee/kit/30/chapter/1437
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 8.2
Topics ET: loodusõpetus, traditsioonid, traditsioon, mõtle, mardipäev, november, kadripäev, jõulud, detsember, jaanuar
Topics RU: природоведение
Topics EN: science
Headings: Traditsioonid; Mis on traditsioon?; Mõtle!; Mardipäev, 10. november; Kadripäev, 25. november; Jõulud, 24. detsember – 6. jaanuar; Vastlapäev, liikuv püha; Lihavõtted ehk munapühad ehk ülestõusmispühad ehk kevadpühad, liikuvad pühad; Jaanipäev, 24. juuni; Ma tean, et ...

## Eestimaa
URL: https://www.opiq.ee/kit/30/chapter/1438
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 8.3
Topics ET: loodusõpetus, eestimaa, eesti, asub, riigikaitse, mõtle, tean
Topics RU: природоведение
Topics EN: science
Headings: Eestimaa; Kus Eesti asub?; Riigikaitse; Mõtle!; Ma tean, et ...
Task examples: Vasta kaardi põhjal. Märgi ära Kagu-Euroopa riigid, mis kuuluvad Euroopa Liitu.; Vasta kaardi põhjal. Märgi ära riigid, mis kuuluvad Euroopa Liitu.

## Toompea
URL: https://www.opiq.ee/kit/30/chapter/1439
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 8.4
Topics ET: loodusõpetus, toompea, miks, tähtis, mõtle, lisa, rahvaluules, eesti, riigi
Topics RU: природоведение
Topics EN: science
Headings: Toompea; Miks on Toompea tähtis?; Mõtle!; Lisa. Toompea rahvaluules; Eesti riigi juhtimine; Ma tean, et ...
Task examples: Milline hoone ehitati Toompea linnusesse viimasena?; Mis on Pikk Hermann?

## Okupeeritud Eesti
URL: https://www.opiq.ee/kit/30/chapter/1440
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 8.5
Topics ET: loodusõpetus, okupeeritud, eesti, okupatsioon, okupatsiooni, ajal, mõtle, nõukogude, tänapäeva
Topics RU: природоведение
Topics EN: science
Headings: Okupeeritud Eesti; Mis on okupatsioon?; Elu okupatsiooni ajal; Mõtle!; Nõukogude ja tänapäeva Eesti võrdlus; Ma tean, et ...
Task examples: Märgi ära õige väide.; Märgi ära õige väide.

## Eesti naaberriigid
URL: https://www.opiq.ee/kit/30/chapter/1441
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 8.6
Topics ET: loodusõpetus, eesti, naaberriigid, mitu, naabrit, eestil, mõtle, baltimaad, läti
Topics RU: природоведение
Topics EN: science
Headings: Eesti naaberriigid; Mitu naabrit on Eestil?; Mõtle!; Baltimaad; Läti; Leedu; Soome; Rootsi; Venemaa; Ma tean, et ...
Task examples: Mis riik on Eesti naabriks läänes?; Märgi Eesti naaberriigid.

## Kordamine. Eesti traditsioonid, ajalugu ja naabrid
URL: https://www.opiq.ee/kit/30/chapter/1844
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 8.7
Topics ET: loodusõpetus, kordamine, korda, harjutan, eesti, traditsioonid, ajalugu, naabrid, kokkuvõttev, pildigalerii
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Eesti traditsioonid, ajalugu ja naabrid; Kokkuvõttev pildigalerii; Ülesanded
Task examples: Võrdle okupeeritud Eestit praeguse Eestiga. Lohista laused õige pealkirja alla.; Mis ülesanded on ...

## Kordamine. Loodus
URL: https://www.opiq.ee/kit/30/chapter/1442
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 9.1
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond, elusloodus, mõtle, eluta
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда
Topics EN: science, revision, review, practice, nature, environment
Headings: Kordamine. Loodus; Elusloodus; Mõtle!; Eluta loodus

## Kordamine. Kuidas on kõik seotud?
URL: https://www.opiq.ee/kit/30/chapter/1443
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 9.2
Topics ET: loodusõpetus, kordamine, korda, harjutan, kuidas, kõik, eluslooduse, eluta, looduse, seotus, mõtle
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Kuidas on kõik seotud?; Eluslooduse ja eluta looduse seotus; Mõtle!

## Kordamine. Vesi
URL: https://www.opiq.ee/kit/30/chapter/1444
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 9.3
Topics ET: loodusõpetus, kordamine, korda, harjutan, vesi, veeohutus, veekogu, olekud, veeringlus, mõtle
Topics RU: природоведение, повторение, повтори, тренировка, вода, безопасность на воде, водоём
Topics EN: science, revision, review, practice, water, water safety, body of water
Headings: Kordamine. Vesi; Vee olekud; Veeringlus; Mõtle!

## Kordamine. Tervislik eluviis
URL: https://www.opiq.ee/kit/30/chapter/1445
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 9.4
Topics ET: loodusõpetus, kordamine, korda, harjutan, inimene, keha, meeled, tervis, tervislik, eluviis, milline, terve, liikumine, toitumine, puhas
Topics RU: природоведение, повторение, повтори, тренировка, человек, тело, чувства, здоровье
Topics EN: science, revision, review, practice, human, body, senses, health
Headings: Kordamine. Tervislik eluviis; Milline on terve inimene?; Milline on tervislik eluviis?; Liikumine; Toitumine; Puhas keha; Puhkus; Mõtle!

## Kordamine. Päikesesüsteem
URL: https://www.opiq.ee/kit/30/chapter/1446
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 9.5
Topics ET: loodusõpetus, kordamine, korda, harjutan, päikesesüsteem, uuri, liikumine, mõtle
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine. Päikesesüsteem; Päikesesüsteem; Uuri!; Maa ja Kuu liikumine; Mõtle!

## Kordamine. Inimesed
URL: https://www.opiq.ee/kit/30/chapter/1447
Book: Eesti
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 3k_loodus_avita_est
Chapter ID: 9.6
Topics ET: loodusõpetus, kordamine, korda, harjutan, loodus, keskkond, inimesed, kultuur, mõtle, seadused, luik, haug, vähk
Topics RU: природоведение, повторение, повтори, тренировка, природа, окружающая среда
Topics EN: science, revision, review, practice, nature, environment
Headings: Kordamine. Inimesed; Loodus ja kultuur; Mõtle!; Seadused; Luik, Haug ja Vähk

## Природо­ведение 3 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/139
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 320
Topics ET: loodusõpetus, opiq
Topics RU: природоведение, природо, ведение, класс
Topics EN: science

## Многообразие видов растений и животных
URL: https://www.opiq.ee/kit/139/chapter/7736
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.1
Topics ET: loodusõpetus
Topics RU: природоведение, многообразие, видов, растений, животных, народные, названия, запомни, вопросы
Topics EN: science
Headings: Многообразие видов растений и животных; Sisu; Народные названия животных; ЗАПОМНИ!; Вопросы и задания; 7/7 Описание коровы; 1/7 Описание коровы; 2/7 Описание коровы; 3/7 Описание коровы; 4/7 Описание коровы; 5/7 Описание коровы; 6/7 Описание коровы; Размышляй и исследуй; Большая синица; Лазоревка; Ёж обыкновенный; Деревенская ласточка; Береговая ласточка

## В грибном лесу
URL: https://www.opiq.ee/kit/139/chapter/7737
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.2
Topics ET: loodusõpetus
Topics RU: природоведение, грибном, лесу, съедобные, грибы, ядовитые, отметь, запомни, вопросы
Topics EN: science
Headings: В грибном лесу; Съедобные грибы; Ядовитые грибы; Отметь ядовитые грибы.; ЗАПОМНИ!; Вопросы и задания; 8/8 Какой это гриб?; 1/8 Какой это гриб?; 2/8 Какой это гриб?; 3/8 Какой это гриб?; 4/8 Какой это гриб?; 5/8 Какой это гриб?; 6/8 Какой это гриб?; 7/8 Какой это гриб?; Размышляй и исследуй; Памятка грибника; Правила поведения в лесу

## У каждого вида – своё место обитания
URL: https://www.opiq.ee/kit/139/chapter/7738
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.3
Topics ET: loodusõpetus
Topics RU: природоведение, каждого, вида, место, обитания, запомни, вопросы, размышляй, исследуй
Topics EN: science
Headings: У каждого вида – своё место обитания; Место обитания; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй; Канюк, или сарыч; Заяц-русак; Кабан; Вереск; Кувшинка белая; Купальница, или жарки

## Растения
URL: https://www.opiq.ee/kit/139/chapter/7739
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.4
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, группы, растений, запомни, вопросы, отметь, споровые, размышляй
Topics EN: science, plant, plants, tree, flower
Headings: Растения; Группы растений; ЗАПОМНИ!; Вопросы и задания; Отметь споровые растения.; Размышляй и исследуй; Папоротники; Сфагнум; Кукушкин лён обыкновенный

## Значение растений
URL: https://www.opiq.ee/kit/139/chapter/7740
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.5
Topics ET: loodusõpetus
Topics RU: природоведение, значение, растений, жизнь, земле, зависит, запомни, вопросы, заполни
Topics EN: science
Headings: Значение растений; Жизнь на Земле зависит от растений; ЗАПОМНИ!; Вопросы и задания; Заполни пропуски.; Размышляй и исследуй

## Лекарственные растения
URL: https://www.opiq.ee/kit/139/chapter/7741
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.6
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, лекарственные, используются, лечении, болезней, какие, каких, болезнях, применяют
Topics EN: science, plant, plants, tree, flower
Headings: Лекарственные растения; Растения используются при лечении болезней; Какие растения при каких болезнях применяют?; ЗАПОМНИ!; Вопросы и задания; 7/7 Какое это растение?; 1/7 Какое это растение?; 2/7 Какое это растение?; 3/7 Какое это растение?; 4/7 Какое это растение?; 5/7 Какое это растение?; 6/7 Какое это растение?; Размышляй и исследуй

## Ядовитые растения
URL: https://www.opiq.ee/kit/139/chapter/7742
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.7
Topics ET: loodusõpetus, taim, taimed, puu, lill
Topics RU: природоведение, растение, растения, дерево, цветок, ядовитые, некоторые, ядовиты, запомни, вопросы, ядовитыми, плодами
Topics EN: science, plant, plants, tree, flower
Headings: Ядовитые растения; Некоторые растения ядовиты; ЗАПОМНИ!; Вопросы и задания; Растения с ядовитыми плодами; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/139/chapter/7743
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 1.8
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, вопросы, повторения
Topics EN: science
Headings: В заключение; ВОПРОСЫ ДЛЯ ПОВТОРЕНИЯ

## Животные
URL: https://www.opiq.ee/kit/139/chapter/7744
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.1
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, отличаются, растений, запомни, вопросы, здесь, размышляй, исследуй
Topics EN: science, animal, animals, birds, insects
Headings: Животные; Животные отличаются от растений; ЗАПОМНИ!; Вопросы и задания; Где здесь животные?; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/139/chapter/7753
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.10
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, вопросы, повторения
Topics EN: science
Headings: В заключение; ВОПРОСЫ ДЛЯ ПОВТОРЕНИЯ

## Беспозвоночные животные
URL: https://www.opiq.ee/kit/139/chapter/7745
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.2
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, беспозвоночные, какие, относятся, беспозвоночным, вопросы, позвоночное, беспозвоночное
Topics EN: science, animal, animals, birds, insects
Headings: Беспозвоночные животные; Какие животные относятся к беспозвоночным?; Вопросы и задания; 5/5 Позвоночное или беспозвоночное; 1/5 Позвоночное или беспозвоночное; 2/5 Позвоночное или беспозвоночное; 3/5 Позвоночное или беспозвоночное; 4/5 Позвоночное или беспозвоночное; ЭТО ВАЖНО ЗНАТЬ!; Улитка древесная; Слизни; Паук-крестовик; Муха комнатная

## Позвоночные животные. Рыбы и земноводные
URL: https://www.opiq.ee/kit/139/chapter/7746
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.3
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, позвоночные, рыбы, земноводные, части, тела, лягушки, запомни, вопросы
Topics EN: science, animal, animals, birds, insects
Headings: Позвоночные животные. Рыбы и земноводные; Рыбы и земноводные; Рыбы; Части тела рыбы; Земноводные; Части тела лягушки; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй; Лещ; Щука; Окунь; Травяная лягушка; Жаба обыкновенная

## Пресмыкающиеся
URL: https://www.opiq.ee/kit/139/chapter/7747
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.4
Topics ET: loodusõpetus
Topics RU: природоведение, пресмыкающиеся, такие, откладывают, яйца, запомни, вопросы, размышляй, исследуй
Topics EN: science
Headings: Пресмыкающиеся; Кто такие пресмыкающиеся?; Пресмыкающиеся откладывают яйца; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй; Части тела ящерицы; Уж; Гадюка; ЭТО ВАЖНО ЗНАТЬ!

## Птицы
URL: https://www.opiq.ee/kit/139/chapter/7748
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad
Topics RU: природоведение, животное, животные, птицы, насекомые, характерные, особенности, птиц, запомни, вопросы, части, тела
Topics EN: science, animal, animals, birds, insects
Headings: Птицы; Характерные особенности птиц; ЗАПОМНИ!; Вопросы и задания; Части тела птицы; Размышляй и исследуй; Белый аист; Чайка

## Млекопитающие
URL: https://www.opiq.ee/kit/139/chapter/7749
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.6
Topics ET: loodusõpetus, imetajate, kirjeldus
Topics RU: природоведение, млекопитающие, характерные, особенности, млекопитающих, части, тела, млекопитающего
Topics EN: science
Headings: Млекопитающие; Характерные особенности млекопитающих; Imetajate kirjeldus; Части тела млекопитающего; ЗАПОМНИ!; Вопросы и задания; 4/4 Чем питается?; 1/4 Чем питается?; 2/4 Чем питается?; 3/4 Чем питается?; Размышляй и исследуй; Рысь; Белка; Барсук; Лисица

## Грибы
URL: https://www.opiq.ee/kit/139/chapter/7750
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.7
Topics ET: loodusõpetus
Topics RU: природоведение, грибы, чего, состоят, растут, питаются, какие, бывают, запомни, вопросы
Topics EN: science
Headings: Грибы; Из чего состоят грибы; Где растут и чем питаются грибы; Какие ещё бывают грибы?; ЗАПОМНИ!; Вопросы и задания; Части гриба; Размышляй и исследуй

## Лишайники
URL: https://www.opiq.ee/kit/139/chapter/7751
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.8
Topics ET: loodusõpetus
Topics RU: природоведение, лишайники, такое, лишайник, отметь, правильные, предложения
Topics EN: science
Headings: Лишайники; Что такое лишайник?; Отметь правильные предложения.

## Бактерии
URL: https://www.opiq.ee/kit/139/chapter/7752
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 2.9
Topics ET: loodusõpetus
Topics RU: природоведение, бактерии, такие, запомни, вопросы, размышляй, исследуй
Topics EN: science
Headings: Бактерии; Кто такие бактерии?; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Образ жизни животных
URL: https://www.opiq.ee/kit/139/chapter/7754
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 3.1
Topics ET: loodusõpetus
Topics RU: природоведение, образ, жизни, животных, одиночку, группами, птичьи, стаи, запомни, вопросы
Topics EN: science
Headings: Образ жизни животных; В одиночку или группами?; Птичьи стаи; ЗАПОМНИ!; Вопросы и задания; Рысь и заяц; Размышляй и исследуй; Пчелиный рой

## Совместное существование организмов различных видов
URL: https://www.opiq.ee/kit/139/chapter/7755
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 3.2
Topics ET: loodusõpetus
Topics RU: природоведение, совместное, существование, организмов, различных, видов, вместе, выгодно, паразиты, запомни
Topics EN: science
Headings: Совместное существование организмов различных видов; Вместе выгодно; Паразиты; ЗАПОМНИ!; Вопросы и задания; Полезно или вредно?; Размышляй и исследуй; Кукушка; Головная вошь; Блохи; Постельный клоп

## Пищевая цепь, пищевая сеть
URL: https://www.opiq.ee/kit/139/chapter/7756
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 3.3
Topics ET: loodusõpetus
Topics RU: природоведение, пищевая, цепь, сеть, запомни, вопросы, составь, пищевую, размышляй
Topics EN: science
Headings: Пищевая цепь, пищевая сеть; Пищевая цепь; Пищевая сеть; ЗАПОМНИ!; Вопросы и задания; Составь пищевую цепь.; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/139/chapter/7757
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 3.4
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, вопросы, повторения, проверь, умеешь, вспомни, означают, следующие, понятия
Topics EN: science
Headings: В заключение; ВОПРОСЫ ДЛЯ ПОВТОРЕНИЯ; Проверь, умеешь ли ты:; Вспомни, что означают следующие понятия:

## Что такое движение?
URL: https://www.opiq.ee/kit/139/chapter/7758
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.1
Topics ET: loodusõpetus
Topics RU: природоведение, такое, движение, происходит, повсюду, запомни, вопросы
Topics EN: science
Headings: Что такое движение?; Движение происходит повсюду; ЗАПОМНИ!; Вопросы и задания

## Как перемещаются живые существа и предметы?
URL: https://www.opiq.ee/kit/139/chapter/7759
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.2
Topics ET: loodusõpetus
Topics RU: природоведение, перемещаются, живые, существа, предметы, движение, человека, средства, передвижения, запомни
Topics EN: science
Headings: Как перемещаются живые существа и предметы?; Движение человека; Средства передвижения; ЗАПОМНИ!; Вопросы и задания; Сгруппируй средства передвижения.; Размышляй и исследуй

## Скорость
URL: https://www.opiq.ee/kit/139/chapter/7760
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.3
Topics ET: loodusõpetus
Topics RU: природоведение, скорость, показывает, важно, знать, запомни, вопросы, поезда, тормозной
Topics EN: science
Headings: Скорость; Что показывает скорость?; Это важно знать!; ЗАПОМНИ!; Вопросы и задания; Скорость поезда; Тормозной путь; Быстро и медленно

## Электричество
URL: https://www.opiq.ee/kit/139/chapter/7761
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.4
Topics ET: loodusõpetus
Topics RU: природоведение, электричество, чего, используется, такое, электрический, важно, знать, запомни, вопросы
Topics EN: science
Headings: Электричество; Для чего используется электричество?; Что такое электрический ток?; Это важно знать!; ЗАПОМНИ!; Вопросы и задания; С электричеством нужно обращаться осторожно!; Размышляй и исследуй; Как было открыто электричество

## Как получают электрический ток?
URL: https://www.opiq.ee/kit/139/chapter/7762
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.5
Topics ET: loodusõpetus
Topics RU: природоведение, получают, электрический, электростанции, вырабатывается, электричество, путь, электричества, потребителям, батарейки
Topics EN: science
Headings: Как получают электрический ток?; На электростанции вырабатывается электричество; Путь электричества к потребителям.; Батарейки – тоже источник электрического тока; Приборы, работающие на батарейках и аккумуляторах; Электрическая цепь; Какие материалы проводят электричество; Распредели на две группы.; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй; ЭТО ИНТЕРЕСНО!

## Магниты
URL: https://www.opiq.ee/kit/139/chapter/7763
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.6
Topics ET: loodusõpetus
Topics RU: природоведение, магниты, магнит, притягивает, металлические, предметы, какие, групповая, работа, отталкиваются
Topics EN: science
Headings: Магниты; Магнит притягивает металлические предметы; Какие предметы притягивает магнит?; Групповая работа; Магниты отталкиваются и притягиваются; ЗАПОМНИ!; Вопросы и задания; Полюса магнита

## Компас
URL: https://www.opiq.ee/kit/139/chapter/7764
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.7
Topics ET: loodusõpetus
Topics RU: природоведение, компас, работает, запомни, вопросы, находится, север, магнитная, стрелка
Topics EN: science
Headings: Компас; Как работает компас?; ЗАПОМНИ!; Вопросы и задания; Где находится север?; Магнитная стрелка; ЭТО ИНТЕРЕСНО!

## В заключение
URL: https://www.opiq.ee/kit/139/chapter/7765
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 4.8
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, вопросы, повторения, проверь, умеешь, вспомни, означают, следующие, понятия
Topics EN: science
Headings: В заключение; ВОПРОСЫ ДЛЯ ПОВТОРЕНИЯ; Проверь, умеешь ли ты...; Вспомни, что означают следующие понятия:

## Основные стороны горизонта
URL: https://www.opiq.ee/kit/139/chapter/7766
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.1
Topics ET: loodusõpetus
Topics RU: природоведение, основные, стороны, горизонта, определить, запомни, вопросы, определи, размышляй
Topics EN: science
Headings: Основные стороны горизонта; Как определить стороны горизонта?; ЗАПОМНИ!; Вопросы и задания; Определи стороны горизонта; Размышляй и исследуй; ЭТО ИНТЕРЕСНО!

## Промежуточные стороны горизонта
URL: https://www.opiq.ee/kit/139/chapter/7767
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.2
Topics ET: loodusõpetus
Topics RU: природоведение, промежуточные, стороны, горизонта, компас, определение, сторон, помощью, часов, направление
Topics EN: science
Headings: Промежуточные стороны горизонта; Компас; Определение сторон горизонта с помощью часов; 2/2 Направление на юг; 1/2 Направление на юг; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## План
URL: https://www.opiq.ee/kit/139/chapter/7768
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.3
Topics ET: loodusõpetus
Topics RU: природоведение, план, сбоку, сверху, такое, запомни, вопросы, расположение, предметов
Topics EN: science
Headings: План; Вид сбоку и вид сверху; Что такое план?; ЗАПОМНИ!; Вопросы и задания; Расположение предметов; Размеры столов; Размышляй и исследуй

## Условные знаки
URL: https://www.opiq.ee/kit/139/chapter/7769
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.4
Topics ET: loodusõpetus
Topics RU: природоведение, условные, знаки, такое, план, города, запомни, вопросы, размышляй
Topics EN: science
Headings: Условные знаки; Что такое условные знаки?; План города; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Карта и легенда карты
URL: https://www.opiq.ee/kit/139/chapter/7770
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.5
Topics ET: loodusõpetus
Topics RU: природоведение, карта, легенда, карты, такое, цвета, карте, эстонии, запомни, вопросы
Topics EN: science
Headings: Карта и легенда карты; Что такое карта?; Цвета на карте; Легенда карты Эстонии; ЗАПОМНИ!; Вопросы и задания; Размышляй и исследуй

## Знакомимся с картой Эстонии
URL: https://www.opiq.ee/kit/139/chapter/7771
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.6
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem
Topics RU: природоведение, сравнение, сравни, больше, меньше, знакомимся, картой, эстонии, стороны, света, карте, острова, полуострова, карта
Topics EN: science, comparison, compare, greater, less
Headings: Знакомимся с картой Эстонии; Стороны света на карте Эстонии; Острова и полуострова; Карта Эстонии; Ответь на вопросы с помощью карты Эстонии; Озёра и реки; ЗАПОМНИ!; Вопросы и задания; Сравни; Размышляй и исследуй

## Продолжаем знакомство с картой Эстонии
URL: https://www.opiq.ee/kit/139/chapter/7772
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.7
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem
Topics RU: природоведение, сравнение, сравни, больше, меньше, продолжаем, знакомство, картой, эстонии, возвышенности, возвышенность, пандивере, хаанья, отепяэ
Topics EN: science, comparison, compare, greater, less
Headings: Продолжаем знакомство с картой Эстонии; Возвышенности Эстонии; 4. Возвышенность Пандивере; 1. Возвышенность Хаанья; 2. Возвышенность Отепяэ; 3. Какая возвышенность?; Равнины и низменности; 3. Средне-Эстонская равнина; 1. Западно-Эстонская низменность; 2. Низменность Выртсъярве и Причудская низменность; Города Эстонии; Сравни расстояния; ЗАПОМНИ!; Вопросы и задания; Что находится восточнее?; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/139/chapter/7773
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 5.8
Topics ET: loodusõpetus
Topics RU: природоведение, заключение, вопросы, повторения, проверь, умеешь, вспомни, означают, следующие, понятия
Topics EN: science
Headings: В заключение; ВОПРОСЫ ДЛЯ ПОВТОРЕНИЯ; Проверь, умеешь ли ты ...; Вспомни, что означают следующие понятия:

## Понятия и термины
URL: https://www.opiq.ee/kit/139/chapter/7774
Book: Многообразие видов растений и животных
Class: 3
Subject: science / loodusõpetus / природоведение
Language: ru
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_2023_rus
Chapter ID: 6.1
Topics ET: loodusõpetus
Topics RU: природоведение, понятия, термины
Topics EN: science
Headings: Понятия и термины

## Loodusõpetus 3. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/97
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 151
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Taimede ja loomade liike on palju
URL: https://www.opiq.ee/kit/97/chapter/4691
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 1.1
Topics ET: loodusõpetus, taimede, loomade, liike, palju, liik, rahvapärased, nimetused, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Taimede ja loomade liike on palju; Mis on liik?; Loomade rahvapärased nimetused; Pean meeles; Küsimusi ja ülesandeid; 1/7 Lehma kirjeldus; 2/7 Lehma kirjeldus; 3/7 Lehma kirjeldus; 4/7 Lehma kirjeldus; 5/7 Lehma kirjeldus; 6/7 Lehma kirjeldus; 7/7 Lehma kirjeldus; Edasimõtlemiseks ja uurimiseks; Rasvatihane; Sinitihane; Harilik siil; Suitsupääsuke; Kaldapääsuke

## Liigirikas seenemets
URL: https://www.opiq.ee/kit/97/chapter/4692
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 1.2
Topics ET: loodusõpetus, liigirikas, seenemets, söögiseened, mürgiseened, pean, meeles, küsimusi, ülesandeid, seen
Topics RU: природоведение
Topics EN: science
Headings: Liigirikas seenemets; Söögiseened; Mürgiseened; Pean meeles; Küsimusi ja ülesandeid; 1/8 Mis seen?; 2/8 Mis seen?; 3/8 Mis seen?; 4/8 Mis seen?; 5/8 Mis seen?; 6/8 Mis seen?; 7/8 Mis seen?; 8/8 Mis seen?; Edasimõtlemiseks ja uurimiseks; Seenelkäija meelespea; Metsas käitumise reeglid

## Igal liigil on kindel elupaik
URL: https://www.opiq.ee/kit/97/chapter/4693
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 1.3
Topics ET: loodusõpetus, igal, liigil, kindel, elupaik, elupaigad, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Igal liigil on kindel elupaik; Elupaigad; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Hiireviu; Halljänes; Metssiga; Kanarbik; Valge vesiroos; Kullerkupp

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/4694
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 1.4
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused

## Taimed
URL: https://www.opiq.ee/kit/97/chapter/4695
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 2.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, taimede, rühmad, metsamarjad, pean, meeles, küsimusi, ülesandeid, eostaimed
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed; Taimede rühmad; Metsamarjad; Pean meeles; Küsimusi ja ülesandeid; Eostaimed; Edasimõtlemiseks ja uurimiseks; Sõnajalad; Turbasammal; Harilik karusammal; Tähesegadik

## Taimede tähtsus
URL: https://www.opiq.ee/kit/97/chapter/4696
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 2.2
Topics ET: loodusõpetus, taimede, tähtsus, maal, sõltub, taimedest, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Taimede tähtsus; Elu Maal sõltub taimedest; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Ravimtaimed
URL: https://www.opiq.ee/kit/97/chapter/4697
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 2.3
Topics ET: loodusõpetus, taim, taimed, puu, lill, ravimtaimed, aitavad, haiguste, korral, milleks, veel, head, ravimtaimede
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Ravimtaimed; Taimed aitavad haiguste korral; Milleks on taimed veel head; Ravimtaimede kogumisel kehtivad kindlad reeglid:; Pean meeles; Küsimusi ja ülesandeid; 1/7 Mis taim on pildil?; 2/7 Mis taim on pildil?; 3/7 Mis taim on pildil?; 4/7 Mis taim on pildil?; 5/7 Mis taim on pildil?; 6/7 Mis taim on pildil?; 7/7 Mis taim on pildil?; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Mürktaimed
URL: https://www.opiq.ee/kit/97/chapter/4698
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 2.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, mürktaimed, mõned, väga, mürgised, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Mürktaimed; Mõned taimed on väga mürgised; Pean meeles; Küsimusi ja ülesandeid; Mürgiste viljadega taimed; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/4699
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 2.5
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused

## Loomad
URL: https://www.opiq.ee/kit/97/chapter/4700
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 3.1
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, erinevad, taimedest, pean, meeles, küsimusi, ülesandeid, neist, edasimõtlemiseks
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Loomad; Loomad erinevad taimedest; Pean meeles; Küsimusi ja ülesandeid; Kes neist on loomad?; Edasimõtlemiseks ja uurimiseks

## Selgrootud loomad
URL: https://www.opiq.ee/kit/97/chapter/4701
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 3.2
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgrootud, millised, küsimusi, ülesandeid, selgroogne, selgrootu, edasimõtlemiseks, uurimiseks
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgrootud loomad; Millised loomad on selgrootud?; Küsimusi ja ülesandeid; 1/5 Selgroogne või selgrootu; 2/5 Selgroogne või selgrootu; 3/5 Selgroogne või selgrootu; 4/5 Selgroogne või selgrootu; 5/5 Selgroogne või selgrootu; Edasimõtlemiseks ja uurimiseks; Tähesegadik; Tähtis teada; Kiritigu; Nälkjas; Ristämblik; Toakärbes

## Kalad ja kahepaiksed
URL: https://www.opiq.ee/kit/97/chapter/4702
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 3.3
Topics ET: loodusõpetus, kalad, kahepaiksed, kala, osad, konna, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Kalad ja kahepaiksed; Kalad; Kala osad; Kahepaiksed; Konna osad; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Latikas; Haug; Ahven; Rohukonn; Harilik kärnkonn

## Roomajad
URL: https://www.opiq.ee/kit/97/chapter/4703
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 3.4
Topics ET: loodusõpetus, roomajad, millised, munevad, pean, meeles, küsimusi, ülesandeid, sisaliku, osad
Topics RU: природоведение
Topics EN: science
Headings: Roomajad; Millised on roomajad?; Roomajad munevad; Pean meeles; Küsimusi ja ülesandeid; Sisaliku osad; Edasimõtlemiseks ja uurimiseks; Tähesegadik; Nastik; Rästik; Tähtis teada

## Linnud
URL: https://www.opiq.ee/kit/97/chapter/4704
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 3.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, millised, kuidas, paljunevad, pean, meeles, küsimusi, ülesandeid, linnu
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Linnud; Millised on linnud?; Kuidas linnud paljunevad?; Pean meeles; Küsimusi ja ülesandeid; Linnu osad; Edasimõtlemiseks ja uurimiseks; Valge-toonekurg; Naerukajakas

## Imetajad
URL: https://www.opiq.ee/kit/97/chapter/4705
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 3.6
Topics ET: loodusõpetus, imetajad, imetajate, kirjeldus, imetaja, kehaosad, kuidas, paljunevad, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Imetajad; Imetajate kirjeldus; Imetaja kehaosad; Kuidas imetajad paljunevad?; Pean meeles; Küsimusi ja ülesandeid; 1/4 Mida sööb?; 2/4 Mida sööb?; 3/4 Mida sööb?; 4/4 Mida sööb?; Edasimõtlemiseks ja uurimiseks; Ilves; Orav; Mäger; Rebane

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/4706
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 3.7
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused

## Seened
URL: https://www.opiq.ee/kit/97/chapter/4707
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 4.1
Topics ET: loodusõpetus, seened, millest, koosnevad, kuidas, elavad, milliseid, seeni, veel, pean
Topics RU: природоведение
Topics EN: science
Headings: Seened; Millest koosnevad seened?; Kuidas seened elavad?; Milliseid seeni veel on?; Pean meeles; Küsimusi ja ülesandeid; Seene osad; Edasimõtlemiseks ja uurimiseks

## Samblikud
URL: https://www.opiq.ee/kit/97/chapter/4709
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 4.2
Topics ET: loodusõpetus, samblikud
Topics RU: природоведение
Topics EN: science
Headings: Samblikud; Mis on samblikud?

## Bakterid
URL: https://www.opiq.ee/kit/97/chapter/4708
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 4.3
Topics ET: loodusõpetus, bakterid, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks, uurimiseks, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Bakterid; Kes on bakterid?; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/4710
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 4.4
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused

## Loomade eluviis
URL: https://www.opiq.ee/kit/97/chapter/4711
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 5.1
Topics ET: loodusõpetus, loomade, eluviis, üksi, mitmekesi, linnuparved, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Loomade eluviis; Üksi või mitmekesi?; Linnuparved; Pean meeles; Küsimusi ja ülesandeid; Ilves ja jänes; Edasimõtlemiseks ja uurimiseks; Mesilaspere

## Eri liikide organismide kooselu
URL: https://www.opiq.ee/kit/97/chapter/4712
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 5.2
Topics ET: loodusõpetus, liikide, organismide, kooselu, koos, kasulik, parasiidid, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Eri liikide organismide kooselu; Koos on kasulik; Parasiidid; Pean meeles; Küsimusi ja ülesandeid; Kasulik või kahjulik?; Edasimõtlemiseks ja uurimiseks; Tähesegadik; Kägu; Peatäi; Kirbud; Voodilutikas

## Toiduahel, toiduvõrk
URL: https://www.opiq.ee/kit/97/chapter/4713
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 5.3
Topics ET: loodusõpetus, toiduahel, toiduvõrk, toiduvõrgustik, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks, uurimiseks
Topics RU: природоведение
Topics EN: science
Headings: Toiduahel, toiduvõrk; Toiduahel; Toiduvõrgustik; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/4714
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 5.4
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused, kontrolli, ennast, oskad, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused; Kontrolli ennast, kas sa oskad:; Mõisted

## Mis on liikumine?
URL: https://www.opiq.ee/kit/97/chapter/4715
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 6.1
Topics ET: loodusõpetus, jagamine, jaga, jagatis, pool, liikumine, toimub, igal, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение, деление, раздели, частное, половина
Topics EN: science, division, divide, quotient, half
Headings: Mis on liikumine?; Liikumine toimub igal pool; Pean meeles; Küsimusi ja ülesandeid

## Kuidas liiguvad elusolendid ja asjad?
URL: https://www.opiq.ee/kit/97/chapter/4716
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 6.2
Topics ET: loodusõpetus, kuidas, liiguvad, elusolendid, asjad, inimese, liikumine, liikumise, abivahendid, pean
Topics RU: природоведение
Topics EN: science
Headings: Kuidas liiguvad elusolendid ja asjad?; Inimese liikumine; Liikumise abivahendid; Pean meeles; Küsimusi ja ülesandeid; Liikumisvahendid; Edasimõtlemiseks ja uurimiseks

## Kiirus
URL: https://www.opiq.ee/kit/97/chapter/4717
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 6.3
Topics ET: loodusõpetus, kiirus, mida, näitab, tähtis, teada, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение
Topics EN: science
Headings: Kiirus; Mida näitab kiirus?; Tähtis teada; Pean meeles; Küsimusi ja ülesandeid; Rongi kiirus; Pidurdusmaa; Kiire ja aeglane

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/4718
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 6.4
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused

## Elekter
URL: https://www.opiq.ee/kit/97/chapter/6186
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 7.1
Topics ET: loodusõpetus, elekter, milleks, kasutame, elektrit, elektrivool, tähtis, teada, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Elekter; Milleks kasutame elektrit?; Mis on elektrivool?; Tähtis teada; Pean meeles; Küsimusi ja ülesandeid; Elektriga peab olema ettevaatlik!; Edasimõtlemiseks ja uurimiseks; Kuidas elekter avastati?

## Kuidas saadakse elektrivoolu?
URL: https://www.opiq.ee/kit/97/chapter/6187
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 7.2
Topics ET: loodusõpetus, kuidas, saadakse, elektrivoolu, elektrit, toodetakse, elektrijaamades, annab, patarei, vooluring
Topics RU: природоведение
Topics EN: science
Headings: Kuidas saadakse elektrivoolu?; Elektrit toodetakse elektrijaamades; Elektrivoolu annab ka patarei; Vooluring; Millised ained juhivad elektrit; Juhib või ei juhi elektrit; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Huvitav teada

## Magnetid
URL: https://www.opiq.ee/kit/97/chapter/6188
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 7.3
Topics ET: loodusõpetus, magnetid, magnet, tõmbab, metallist, esemeid, milliseid, rühmatöö, tõukuvad, tõmbuvad
Topics RU: природоведение
Topics EN: science
Headings: Magnetid; Magnet tõmbab metallist esemeid; Milliseid esemeid magnet tõmbab?; Rühmatöö; Magnetid tõukuvad ja tõmbuvad; Pean meeles; Küsimusi ja ülesandeid; Magneti poolused; Tähesegadik

## Kompass
URL: https://www.opiq.ee/kit/97/chapter/6189
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 7.4
Topics ET: loodusõpetus, kompass, kuidas, töötab, pean, meeles, küsimusi, ülesandeid, magnetnõel, põhi
Topics RU: природоведение
Topics EN: science
Headings: Kompass; Kuidas kompass töötab?; Pean meeles; Küsimusi ja ülesandeid; Magnetnõel; Kus on põhi?; Huvitav teada

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/6190
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 7.5
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused, kontrolli, ennast, oskad, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused; Kontrolli ennast, kas sa oskad:; Mõisted

## Põhiilmakaared
URL: https://www.opiq.ee/kit/97/chapter/6191
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.1
Topics ET: loodusõpetus, põhiilmakaared, kuidas, määrata, ilmakaari, pean, meeles, küsimusi, ülesandeid, määra
Topics RU: природоведение
Topics EN: science
Headings: Põhiilmakaared; Kuidas määrata ilmakaari?; Pean meeles; Küsimusi ja ülesandeid; Määra ilmakaared; Edasimõtlemiseks ja uurimiseks; Kuidas saab veel ilmakaari määrata

## Vaheilmakaared
URL: https://www.opiq.ee/kit/97/chapter/6192
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.2
Topics ET: loodusõpetus, vaheilmakaared, kompassi, kasutamine, ilmakaarte, määrmine, kella, abil, lõunasuund, pean
Topics RU: природоведение
Topics EN: science
Headings: Vaheilmakaared; Kompassi kasutamine; Ilmakaarte määrmine kella abil; 1/2 Lõunasuund; 2/2 Lõunasuund; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Plaan
URL: https://www.opiq.ee/kit/97/chapter/6193
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.3
Topics ET: loodusõpetus, plaan, külgvaade, pealtvaade, pean, meeles, küsimusi, ülesandeid, laudade, mõõtmed
Topics RU: природоведение
Topics EN: science
Headings: Plaan; Külgvaade ja pealtvaade; Mis on plaan?; Pean meeles; Küsimusi ja ülesandeid; Laudade mõõtmed; Esemete asend; Edasimõtlemiseks ja uurimiseks

## Leppemärgid
URL: https://www.opiq.ee/kit/97/chapter/6194
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.4
Topics ET: loodusõpetus, leppemärgid, linnaplaan, pean, meeles, küsimusi, ülesandeid, edasimõtlemiseks, uurimiseks, tähesegadik
Topics RU: природоведение
Topics EN: science
Headings: Leppemärgid; Mis on leppemärgid?; Linnaplaan; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Kaart ja kaardi legend
URL: https://www.opiq.ee/kit/97/chapter/6195
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.5
Topics ET: loodusõpetus, kaart, kaardi, legend, värvid, kaardil, eesti, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Kaart ja kaardi legend; Mis on kaart?; Värvid kaardil; Eesti kaardi legend; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Tutvume Eesti kaardiga
URL: https://www.opiq.ee/kit/97/chapter/6196
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.6
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, tutvume, eesti, kaardiga, ilmakaared, kaardil, saared, poolsaared, kaart, vasta
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Tutvume Eesti kaardiga; Ilmakaared Eesti kaardil; Saared ja poolsaared; Eesti kaart; Vasta Eesti kaardi abil; Järved ja jõed; Pean meeles; Küsimusi ja ülesandeid; Võrdle; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Tutvume veel Eesti kaardiga
URL: https://www.opiq.ee/kit/97/chapter/6197
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.7
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, tutvume, veel, eesti, kaardiga, kõrgustikud, haanja, kõrgustik, otepää, pandivere
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Tutvume veel Eesti kaardiga; Eesti kõrgustikud; 1. Haanja kõrgustik; 2. Otepää kõrgustik; 3. Mis kõrgustik?; 4. Pandivere kõrgustik; Tasandikud ja madalikud; 1. Lääne-Eesti madalik; 2. Võrtsjärve ja Peipsi madalik; 3. Kesk-Eesti tasandik; Eesti linnad; Võrdle kaugusi; Pean meeles; Küsimusi ja ülesandeid; Ilmakaared; Edasimõtlemiseks ja uurimiseks; Tähesegadik

## Kokkuvõte
URL: https://www.opiq.ee/kit/97/chapter/6198
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 8.8
Topics ET: loodusõpetus, kokkuvõte, eesti, kaart, kordamisküsimused, kontrolli, ennast, oskad, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Eesti kaart; Kordamisküsimused; Kontrolli ennast, kas sa oskad:; Mõisted

## Mõisted
URL: https://www.opiq.ee/kit/97/chapter/4719
Book: Taimede ja loomade liike on palju
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Koolibri
Book ID: 3k_loodus_koolibri_est
Chapter ID: 9.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Loodusõpetuse tööraamat 3. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/461
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 214
Topics ET: loodusõpetus, loodusõpetuse, tööraamat, klassile, opiq
Topics RU: природоведение
Topics EN: science

## Eluslooduse jaotamise süsteem. Liigid ja perekonnad
URL: https://www.opiq.ee/kit/461/chapter/25147
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.1
Topics ET: loodusõpetus, eluslooduse, jaotamise, süsteem, liigid, perekonnad
Topics RU: природоведение
Topics EN: science
Headings: Eluslooduse jaotamise süsteem. Liigid ja perekonnad; Liigid ja perekonnad

## Selgroogsed. Võrdlus selgrootutega
URL: https://www.opiq.ee/kit/461/chapter/25156
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.10
Topics ET: loodusõpetus, selgroogsed, võrdlus, selgrootutega, selgroogsete, selgrootute, tunnused
Topics RU: природоведение
Topics EN: science
Headings: Selgroogsed. Võrdlus selgrootutega; Võrdlus selgrootutega; 1. Selgroogsete ja selgrootute tunnused

## Selgroogsed. Kalad
URL: https://www.opiq.ee/kit/461/chapter/25157
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.11
Topics ET: loodusõpetus, selgroogsed, kalad, kalade, kohastumus
Topics RU: природоведение
Topics EN: science
Headings: Selgroogsed. Kalad; Kalad; 1. Kalade kohastumus

## Selgroogsed. Läänemere lõhe
URL: https://www.opiq.ee/kit/461/chapter/25158
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.12
Topics ET: loodusõpetus, selgroogsed, läänemere, lõhe, leia, internetist, jutusta, lõhest, vähem, reostust
Topics RU: природоведение
Topics EN: science
Headings: Selgroogsed. Läänemere lõhe; Läänemere lõhe; 1. Leia internetist; 2. Jutusta lõhest; 3. Vähem reostust; 4. Arutage klassis

## Selgroogsed. Kahepaiksed ja roomajad
URL: https://www.opiq.ee/kit/461/chapter/25159
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.13
Topics ET: loodusõpetus, selgroogsed, kahepaiksed, roomajad, roomajate, soomused, kahepaiksete, rühmad, kirjeldus, kahepaiksest
Topics RU: природоведение
Topics EN: science
Headings: Selgroogsed. Kahepaiksed ja roomajad; Kahepaiksed ja roomajad; 1. Roomajate soomused; 2. Kahepaiksete ja roomajate rühmad; 3. Kirjeldus kahepaiksest või roomajast

## Selgroogsed. Kahepaiksete ja roomajate toitumine ja meeled
URL: https://www.opiq.ee/kit/461/chapter/25160
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.14
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, selgroogsed, kahepaiksete, roomajate, toitumine, uued, sõnad, sarnasus, erinevused
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Selgroogsed. Kahepaiksete ja roomajate toitumine ja meeled; Kahepaiksete toitumine ja meeled; Roomajate toitumine ja meeled; 1. Uued sõnad; 2. Sarnasus ja erinevused; 3. Söövad kahepaikseid ja roomajaid

## Selgroogsed. Linnud ja imetajad
URL: https://www.opiq.ee/kit/461/chapter/25161
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.15
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgroogsed, imetajad, arutage, klassis, imetajate, tunnused
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgroogsed. Linnud ja imetajad; Linnud ja imetajad; 1. Arutage klassis; 2. Imetajate tunnused

## Kordamine
URL: https://www.opiq.ee/kit/461/chapter/25162
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.16
Topics ET: loodusõpetus, kordamine, korda, harjutan, näidis, ülesannete, kogust, sarnasused
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Kordamine; Näidis ülesannete kogust; Sarnasused

## Uurime kooliõue puuliike. Plaan
URL: https://www.opiq.ee/kit/461/chapter/25148
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.2
Topics ET: loodusõpetus, uurime, kooliõue, puuliike, plaan, puuliigid, okkad, lihtlehed, liitlehed
Topics RU: природоведение
Topics EN: science
Headings: Uurime kooliõue puuliike. Plaan; Plaan; Puuliigid; Okkad, lihtlehed, liitlehed

## Eluslooduse jaotamise süsteem. Riigid
URL: https://www.opiq.ee/kit/461/chapter/25149
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.3
Topics ET: loodusõpetus, eluslooduse, jaotamise, süsteem, riigid
Topics RU: природоведение
Topics EN: science
Headings: Eluslooduse jaotamise süsteem. Riigid; Riigid

## Selgrootud loomad. Limused
URL: https://www.opiq.ee/kit/461/chapter/25150
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgrootud, limused
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgrootud loomad. Limused; Selgrootud

## Selgrootud loomad. Putukad
URL: https://www.opiq.ee/kit/461/chapter/25151
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.5
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, selgrootud
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Selgrootud loomad. Putukad; Putukad

## Putukate osa looduses
URL: https://www.opiq.ee/kit/461/chapter/25152
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.6
Topics ET: loodusõpetus, putukate, looduses
Topics RU: природоведение
Topics EN: science
Headings: Putukate osa looduses

## Selgrootud. Vähid ja ämblikud
URL: https://www.opiq.ee/kit/461/chapter/25153
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.7
Topics ET: loodusõpetus, selgrootud, vähid, ämblikud
Topics RU: природоведение
Topics EN: science
Headings: Selgrootud. Vähid ja ämblikud; Vähid ja ämblikud

## Selgrootud. Ussid
URL: https://www.opiq.ee/kit/461/chapter/25154
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.8
Topics ET: loodusõpetus, selgrootud, ussid, uuri, internetist, vermikompost, teaduslik, uurimine, küsimuste, koostamine
Topics RU: природоведение
Topics EN: science
Headings: Selgrootud. Ussid; Ussid; 1. Uuri internetist, mis on vermikompost.; 2. Teaduslik uurimine; 3. Küsimuste koostamine; 4. Inimese parasiidid; 5. Nakatumise vältimine; Nuputamisülesanne

## Selgrootud. Kordamine
URL: https://www.opiq.ee/kit/461/chapter/25155
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 1.9
Topics ET: loodusõpetus, kordamine, korda, harjutan, selgrootud, näidis, ülesannete, kogust, selgrootute, liigid
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Selgrootud. Kordamine; Näidis ülesannete kogust; Selgrootute liigid

## Liikumine
URL: https://www.opiq.ee/kit/461/chapter/25163
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.1
Topics ET: loodusõpetus, liikumine, liikumisviisid, jalgratturid, kergliiklusteel
Topics RU: природоведение
Topics EN: science
Headings: Liikumine; 1. Liikumine; 2. Liikumisviisid; 3. Jalgratturid kergliiklusteel

## Ilmakaared
URL: https://www.opiq.ee/kit/461/chapter/25171
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.10
Topics ET: loodusõpetus, ilmakaared, vaata, kõrval, olevat, joonist, kaardilt, millises, eestimaa, osas
Topics RU: природоведение
Topics EN: science
Headings: Ilmakaared; 1. Vaata kõrval olevat joonist.; 2. Vaata kaardilt, millises Eestimaa osas asub sinu kodu.; 3. Meri; 4. Leia ilmakaared; 5. Loomade jäljed

## Plaan ja kaart
URL: https://www.opiq.ee/kit/461/chapter/25172
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.11
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, plaan, kaart, pargi, vaatamist, väärt, kadrioru, park, teejuht, uuri
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Plaan ja kaart; 1. Pargi plaan; 2. Vaatamist väärt Kadrioru park; 3. Teejuht; 4. Uuri droonifotot; 5. Võrdle plaani ja fotot (leidub ka ülesandekogus); Lisamaterjal

## Kaardi lugemine
URL: https://www.opiq.ee/kit/461/chapter/25173
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.12
Topics ET: loodusõpetus, kaardi, lugemine, uurime, kaarti, värvid, kaardil
Topics RU: природоведение
Topics EN: science
Headings: Kaardi lugemine; 1. Uurime kaarti; 2. Värvid kaardil

## Eesti kaart
URL: https://www.opiq.ee/kit/461/chapter/25174
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.13
Topics ET: loodusõpetus, eesti, kaart, muistend, eestimaa, sünd
Topics RU: природоведение
Topics EN: science
Headings: Eesti kaart; Muistend "Eestimaa sünd"

## Ilmakaared, plaan ja kaart. Kordamine
URL: https://www.opiq.ee/kit/461/chapter/25175
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.14
Topics ET: loodusõpetus, kordamine, korda, harjutan, ilmakaared, plaan, kaart
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Ilmakaared, plaan ja kaart. Kordamine; Kordamine

## Kiirus
URL: https://www.opiq.ee/kit/461/chapter/25164
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.2
Topics ET: loodusõpetus, kiirus, koolist, ujulasse, spidomeetrid, kiiresti, jookseb, kiirused
Topics RU: природоведение
Topics EN: science
Headings: Kiirus; 1. Koolist ujulasse; 2. Spidomeetrid; 4. Kui kiiresti jookseb; 3. Kiirused; 5. Ülesanne

## Jõud
URL: https://www.opiq.ee/kit/461/chapter/25165
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.3
Topics ET: loodusõpetus, jõud, värava, kaitsel, kuidas, mina, kasutan, jõudu, üles, alla
Topics RU: природоведение
Topics EN: science
Headings: Jõud; 1. Värava kaitsel; 2. Kuidas mina kasutan jõudu; 3. Üles ja alla; 4. Põder teel

## Liikumine, kiirus, jõud. Kordamine
URL: https://www.opiq.ee/kit/461/chapter/25166
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.4
Topics ET: loodusõpetus, kordamine, korda, harjutan, liikumine, kiirus, jõud
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Liikumine, kiirus, jõud. Kordamine; Liikumine, kiirus ja jõud

## Elekter meie ümber
URL: https://www.opiq.ee/kit/461/chapter/25167
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.5
Topics ET: loodusõpetus, elekter, meie, ümber, elektrivool, taastuv, taastumatu, energia, säästlik, raiskav
Topics RU: природоведение
Topics EN: science
Headings: Elekter meie ümber; 1. Elektrivool; 2. Taastuv või taastumatu energia?; 3. Säästlik või raiskav tarbimine?

## Elekter
URL: https://www.opiq.ee/kit/461/chapter/25168
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.6
Topics ET: loodusõpetus, elekter, vooluring, praktiline, paaristöö, elektrijuhid, isolaatorid, millised, neist, sidrun
Topics RU: природоведение
Topics EN: science
Headings: Elekter; Vooluring; PRAKTILINE PAARISTÖÖ; Elektrijuhid ja isolaatorid; Millised neist on isolaatorid?; Sidrun annab voolu; Vool soojendab ja valgustab; Elekter on ohtlik

## Magnetnähtused
URL: https://www.opiq.ee/kit/461/chapter/25169
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.7
Topics ET: loodusõpetus, magnetnähtused, magnetid, magnetväli, magneti, poolused, tõmbuvad, tõukuvad, magnetite, kasutamine
Topics RU: природоведение
Topics EN: science
Headings: Magnetnähtused; Magnetid; Magnetväli; Magneti poolused; Tõmbuvad või tõukuvad?; Magnetite kasutamine; Magnetväli võib rikkuda asju; Lisamaterjal

## Kompass
URL: https://www.opiq.ee/kit/461/chapter/25170
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.8
Topics ET: loodusõpetus, kompass, kuidas, leida, õige, ammustel, aegadel, praktiline, kompassi
Topics RU: природоведение
Topics EN: science
Headings: Kompass; 1. Kuidas leida õige tee?; 2. Ammustel aegadel...; 3. PRAKTILINE ÜLESANNE: kompassi valmistamine; Lisaülesanne

## Elekter, magnet, kompass. Kordamine
URL: https://www.opiq.ee/kit/461/chapter/25176
Book: Eluslooduse jaotamise süsteem. Liigid ja perekonnad
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_skriiibus_2023_est
Chapter ID: 2.9
Topics ET: loodusõpetus, kordamine, korda, harjutan, elekter, magnet, kompass
Topics RU: природоведение, повторение, повтори, тренировка
Topics EN: science, revision, review, practice
Headings: Elekter, magnet, kompass. Kordamine; Elekter, magnet ja kompass

## Loodusõpetuse õppevideod 1. kooliastmele – Opiq
URL: https://www.opiq.ee/Kit/Details/384
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 108
Topics ET: loodusõpetus, loodusõpetuse, õppevideod, kooliastmele, opiq
Topics RU: природоведение
Topics EN: science

## Sissejuhatus
URL: https://www.opiq.ee/kit/384/chapter/20741
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 1.1
Topics ET: loodusõpetus, sissejuhatus
Topics RU: природоведение
Topics EN: science
Headings: Sissejuhatus

## Kuidas me värve näeme?
URL: https://www.opiq.ee/kit/384/chapter/20737
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 1.2
Topics ET: loodusõpetus, kuidas, värve, näeme, video, värvid, vastandvärvid, katse, eesti, lipp
Topics RU: природоведение
Topics EN: science
Headings: Kuidas me värve näeme?; Video; Värvid ja vastandvärvid; Katse. Eesti lipp; Katse

## Kuidas me maitset tunneme?
URL: https://www.opiq.ee/kit/384/chapter/20738
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 1.3
Topics ET: loodusõpetus, kuidas, maitset, tunneme, video, maitsed, maitsmiskatse, katse
Topics RU: природоведение
Topics EN: science
Headings: Kuidas me maitset tunneme?; Video; Maitsed; Maitsmiskatse; Katse

## Miks on võimalik tunda maitset nina kaudu?
URL: https://www.opiq.ee/kit/384/chapter/20739
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 1.4
Topics ET: loodusõpetus, miks, võimalik, tunda, maitset, nina, kaudu, video, maitse, tundmine
Topics RU: природоведение
Topics EN: science
Headings: Miks on võimalik tunda maitset nina kaudu?; Video; Maitse tundmine; Maitsmiskatse; Katse

## Kui kõrgeid ja madalaid helisid kuuleb inimene?
URL: https://www.opiq.ee/kit/384/chapter/20740
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 1.5
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, kõrgeid, madalaid, helisid, kuuleb, video, kuulmine, kuulmiskatse, katse
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Kui kõrgeid ja madalaid helisid kuuleb inimene?; Video; Kuulmine; Kuulmiskatse; Katse

## Kuidas taim teab, missuguseks ta kasvama peab?
URL: https://www.opiq.ee/kit/384/chapter/20742
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, kuidas, teab, missuguseks, kasvama, peab, video, pärilikkus, katse
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Kuidas taim teab, missuguseks ta kasvama peab?; Video; Pärilikkus; Katse. Banaani DNA; Tööleht

## Miks vajavad taimed valgust?
URL: https://www.opiq.ee/kit/384/chapter/20751
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.10
Topics ET: loodusõpetus, taim, taimed, puu, lill, miks, vajavad, valgust, video, katse, pimedas, valguse
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Miks vajavad taimed valgust?; Video; Katse. Taim pimedas ja valguse käes; Tööleht

## Kuidas jõuab vesi taimes õiteni?
URL: https://www.opiq.ee/kit/384/chapter/20752
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.11
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, kuidas, jõuab, taimes, õiteni, video, liikumine, katse, tööleht
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Kuidas jõuab vesi taimes õiteni?; Video; Vee liikumine taimes; Tee katse; Tööleht

## Kuidas veetaimed vee peal püsivad?
URL: https://www.opiq.ee/kit/384/chapter/20743
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.2
Topics ET: loodusõpetus, kuidas, veetaimed, peal, püsivad, video, ujuvus, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas veetaimed vee peal püsivad?; Video; Ujuvus; Katse. Ujuvus; Tööleht

## Kuidas kalad vees kõrgust muudavad?
URL: https://www.opiq.ee/kit/384/chapter/20744
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.3
Topics ET: loodusõpetus, kuidas, kalad, vees, kõrgust, muudavad, video, kõrguse, muutmine, katse
Topics RU: природоведение
Topics EN: science
Headings: Kuidas kalad vees kõrgust muudavad?; Video; Kõrguse muutmine vees; Katse. Ujupõis; Tööleht

## Mida söövad linnud ja kuidas neid vaadelda?
URL: https://www.opiq.ee/kit/384/chapter/20745
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.4
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, mida, söövad, kuidas, neid, vaadelda, video, linnusöök, katse
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Mida söövad linnud ja kuidas neid vaadelda?; Video; Linnusöök; Katse. Rasvapall; Tööleht

## Milleks on kassidel vurrud?
URL: https://www.opiq.ee/kit/384/chapter/20746
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.5
Topics ET: loodusõpetus, milleks, kassidel, vurrud, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Milleks on kassidel vurrud?; Video; Vurrud; Katse. Vurrud; Tööleht

## Miks tuleb käsi pesta?
URL: https://www.opiq.ee/kit/384/chapter/20747
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.6
Topics ET: loodusõpetus, miks, tuleb, käsi, pesta, video, hallitusseened, katse, hallitus, saial
Topics RU: природоведение
Topics EN: science
Headings: Miks tuleb käsi pesta?; Video; Hallitusseened; Katse. Hallitus saial; Tööleht

## Mis on samblik?
URL: https://www.opiq.ee/kit/384/chapter/20748
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.7
Topics ET: loodusõpetus, samblik, video, samblikud, katse, lõnga, värvimine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on samblik?; Video; Samblikud; Katse. Lõnga värvimine; Tööleht

## Mis on toiduahel ja vihmaussi roll selles?
URL: https://www.opiq.ee/kit/384/chapter/20749
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.8
Topics ET: loodusõpetus, toiduahel, vihmaussi, roll, selles, video, vihmauss, kodu, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on toiduahel ja vihmaussi roll selles?; Video; Toiduahel ja vihmauss; Vihmaussi kodu; Tööleht

## Kuidas on loomad kohanenud eluks talvel ja suvel?
URL: https://www.opiq.ee/kit/384/chapter/20750
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 2.9
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, kuidas, kohanenud, eluks, talvel, suvel, video, suvine, talvine
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Kuidas on loomad kohanenud eluks talvel ja suvel?; Video; Loomad suvel ja talvel; Suvine ja talvine mets; Tööleht

## Kuidas suured asjad väikesele paberile mahuvad?
URL: https://www.opiq.ee/kit/384/chapter/20753
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.1
Topics ET: loodusõpetus, kuidas, suured, asjad, väikesele, paberile, mahuvad, video, paberil, katse
Topics RU: природоведение
Topics EN: science
Headings: Kuidas suured asjad väikesele paberile mahuvad?; Video; Asjad paberil; Katse. Joonestamine; Tööleht

## Kuidas võrrelda raskust?
URL: https://www.opiq.ee/kit/384/chapter/20754
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.2
Topics ET: loodusõpetus, kuidas, võrrelda, raskust, video, kaalumine, kangkaal, ämbritega, koolikoti, kaal
Topics RU: природоведение
Topics EN: science
Headings: Kuidas võrrelda raskust?; Video; Kaalumine; Kangkaal ämbritega. Koolikoti kaal; Tööleht

## Kui pikk on sinu sõber?
URL: https://www.opiq.ee/kit/384/chapter/20755
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.3
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, pikk, sinu, sõber, video, pikkuse, katse, tööleht
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Kui pikk on sinu sõber?; Video; Pikkuse mõõtmine; Katse. Mõõtmine; Tööleht

## Miks on seebimullid tugevamad kui veemullid?
URL: https://www.opiq.ee/kit/384/chapter/20756
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.4
Topics ET: loodusõpetus, miks, seebimullid, tugevamad, veemullid, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Miks on seebimullid tugevamad kui veemullid?; Video; Katse. Seebimullid; Tööleht

## Kuidas võrrelda krõpsude rasvasust?
URL: https://www.opiq.ee/kit/384/chapter/20757
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.5
Topics ET: loodusõpetus, kuidas, võrrelda, krõpsude, rasvasust, video, rasvasisaldus, katse, rasvasus, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas võrrelda krõpsude rasvasust?; Video; Rasvasisaldus; Katse. Krõpsude rasvasus; Tööleht

## Kuidas ronida kodust lahkumata Suure Munamäe otsa?
URL: https://www.opiq.ee/kit/384/chapter/20758
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.6
Topics ET: loodusõpetus, kuidas, ronida, kodust, lahkumata, suure, munamäe, otsa, video, kõrgus
Topics RU: природоведение
Topics EN: science
Headings: Kuidas ronida kodust lahkumata Suure Munamäe otsa?; Video; Kõrgus; Katse. Mäkketõus trepil; Tööleht

## Ujub või upub?
URL: https://www.opiq.ee/kit/384/chapter/20759
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.7
Topics ET: loodusõpetus, ujub, upub, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Ujub või upub?; Video; Katse. Ujub või upub?; Tööleht

## Mis on kiirus?
URL: https://www.opiq.ee/kit/384/chapter/20760
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 3.8
Topics ET: loodusõpetus, kiirus, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on kiirus?; Video; Kiirus; Katse. Kiirus; Tööleht

## Kuidas töötab lüliti?
URL: https://www.opiq.ee/kit/384/chapter/20761
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 4.1
Topics ET: loodusõpetus, kuidas, töötab, lüliti, video, katse, vooluring, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas töötab lüliti?; Video; Lüliti; Katse. Vooluring; Tööleht

## Miks ei tohi panna näppe pistikupessa?
URL: https://www.opiq.ee/kit/384/chapter/20762
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 4.2
Topics ET: loodusõpetus, miks, tohi, panna, näppe, pistikupessa, video, pistik, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Miks ei tohi panna näppe pistikupessa?; Video; Pistik; Tööleht

## Mis on elektrijuhid?
URL: https://www.opiq.ee/kit/384/chapter/20763
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 4.3
Topics ET: loodusõpetus, elektrijuhid, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on elektrijuhid?; Video; Elektrijuhid; Katse. Elektrijuhid; Tööleht

## Kuidas töötavad patareid?
URL: https://www.opiq.ee/kit/384/chapter/20764
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 4.4
Topics ET: loodusõpetus, kuidas, töötavad, patareid, video, patarei, katse, patareivahetus, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas töötavad patareid?; Video; Patarei; Katse. Patareivahetus; Tööleht

## Kuidas kaitsta arvutit särtsu eest?
URL: https://www.opiq.ee/kit/384/chapter/20765
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 4.5
Topics ET: loodusõpetus, kuidas, kaitsta, arvutit, särtsu, eest, video, särts, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas kaitsta arvutit särtsu eest?; Video; Särts; Katse. Särts; Tööleht

## Kas viinamari on magnetiline?
URL: https://www.opiq.ee/kit/384/chapter/20766
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 4.6
Topics ET: loodusõpetus, viinamari, magnetiline, video, magnetilisus, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kas viinamari on magnetiline?; Video; Magnetilisus; Katse; Tööleht

## Mis on kompass?
URL: https://www.opiq.ee/kit/384/chapter/20767
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 4.7
Topics ET: loodusõpetus, kompass, video, katse, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Mis on kompass?; Video; Kompass; Katse. Kompass; Tööleht

## Kuidas liigub päike?
URL: https://www.opiq.ee/kit/384/chapter/20768
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 5.1
Topics ET: loodusõpetus, kuidas, liigub, päike, video, katse, päikesekell, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas liigub päike?; Video; Katse. Päikesekell; Tööleht

## Kustpoolt puhub tuul?
URL: https://www.opiq.ee/kit/384/chapter/20769
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 5.2
Topics ET: loodusõpetus, kustpoolt, puhub, tuul, video, katse, tuuleratas, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kustpoolt puhub tuul?; Video; Tuul; Katse. Tuuleratas; Tööleht

## Kuidas teha pilve?
URL: https://www.opiq.ee/kit/384/chapter/20770
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 5.3
Topics ET: loodusõpetus, kuidas, teha, pilve, video, pilved, katse, tegemine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas teha pilve?; Video; Pilved; Katse. Pilve tegemine; Tööleht

## Kuidas tekivad tornaadod?
URL: https://www.opiq.ee/kit/384/chapter/20771
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 5.4
Topics ET: loodusõpetus, kuidas, tekivad, tornaadod, video, tornaado, katse, toraando, pudelis, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas tekivad tornaadod?; Video; Tornaado; Katse. Toraando pudelis; Tööleht

## Kuidas muuta vedelikku tahkeks?
URL: https://www.opiq.ee/kit/384/chapter/20772
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 6.1
Topics ET: loodusõpetus, kuidas, muuta, vedelikku, tahkeks, video, vedel, tahke, katse, piima
Topics RU: природоведение
Topics EN: science
Headings: Kuidas muuta vedelikku tahkeks?; Video; Vedel ja tahke; Katse. Piima tahkeks muutmine; Tööleht

## Kuidas vett klaasi sisse püüda?
URL: https://www.opiq.ee/kit/384/chapter/20773
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 6.2
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, kuidas, vett, klaasi, sisse, püüda, video, katse, jääb
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Kuidas vett klaasi sisse püüda?; Video; Vesi; Katse. Vesi jääb klaasi; Tööleht

## Kuidas teha varjuteatrit?
URL: https://www.opiq.ee/kit/384/chapter/20774
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 6.3
Topics ET: loodusõpetus, kuidas, teha, varjuteatrit, video, valgus, vari, katse, varjuteater, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas teha varjuteatrit?; Video; Valgus ja vari; Katse. Varjuteater; Tööleht

## Kuidas töötab helkur?
URL: https://www.opiq.ee/kit/384/chapter/20775
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 6.4
Topics ET: loodusõpetus, kuidas, töötab, helkur, video, katse, helkuri, tegemine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Kuidas töötab helkur?; Video; Helkur; Katse. Helkuri tegemine; Tööleht

## Miks on oluline kiivrit kanda?
URL: https://www.opiq.ee/kit/384/chapter/20776
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 6.5
Topics ET: loodusõpetus, miks, oluline, kiivrit, kanda, video, kiiver, katse, muna, kaitsmine
Topics RU: природоведение
Topics EN: science
Headings: Miks on oluline kiivrit kanda?; Video; Kiiver; Katse. Muna kaitsmine kukkumisel; Tööleht

## Milline on Eesti kaart?
URL: https://www.opiq.ee/kit/384/chapter/20777
Book: Sissejuhatus
Class: 3
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: 3k_loodus_starcloud_est
Chapter ID: 6.6
Topics ET: loodusõpetus, milline, eesti, kaart, video, katse, kaardi, joonistamine, tööleht
Topics RU: природоведение
Topics EN: science
Headings: Milline on Eesti kaart?; Video; Eesti kaart; Katse. Eesti kaardi joonistamine; Tööleht
