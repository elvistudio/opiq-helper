## Loodusõpetus 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/11
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/11
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 56
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Tähistaevas
URL: https://www.opiq.ee/kit/11/chapter/448
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.1
Topics ET: loodusõpetus, tähistaevas, tähed, tähtkujud, mõtle, suur, vanker, põhjanael, kuidas
Topics RU: природоведение
Topics EN: science
Headings: Tähistaevas; Tähed; Mis on tähtkujud?; Mõtle!; Suur Vanker ja Põhjanael; Kuidas leida taevast Põhjanaela?; Taevakaart; Mõisted; Ma tean, et …
Task examples: Kus ja millal näeb rohkem tähti?; Tähtkujusid hakati nimetama ...

## Maailmaruum
URL: https://www.opiq.ee/kit/11/chapter/449
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.2
Topics ET: loodusõpetus, maailmaruum, seal, sees, suur, millega, seda, mõõdetakse, mõtle
Topics RU: природоведение
Topics EN: science
Headings: Maailmaruum; Mis on maailmaruum ja mis seal sees on?; Kui suur on maailmaruum ja millega seda mõõdetakse?; Mõtle!; Galaktikad; Mis on tähtede vahel?; Andromeeda galaktika; Mõisted; Ma tean, et …
Task examples: Vaata videoid ja täida lüngad.; Kui mitme aasta pärast jõuab valgus meieni tähelt, mis asub meist 6 valgusaasta kaugusel?

## Täheteadus
URL: https://www.opiq.ee/kit/11/chapter/450
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.3
Topics ET: loodusõpetus, lahutamine, lahuta, vahe, täheteadus, tähed, huvitasid, inimesi, juba, ammu, astronoomial
Topics RU: природоведение, вычитание, вычти, разность
Topics EN: science, subtraction, subtract, difference
Headings: Täheteadus; Tähed huvitasid inimesi juba ammu; Mis vahe on astronoomial ja astroloogial?; Millega uuritakse maailmaruumi?; Lisa. Eestis on elanud ja töötanud kogu maailmas tuntud astronoome; Kus uuritakse tähti?; Lisa. Teeme tähtedega tutvust; Mõisted; Ma tean, et …
Task examples: Miks jälgiti vanasti taevakehasid?; Võrdle astronoomiat ja astroloogiat. Lohista vastused õige pealkirja all olevale pildile.

## Päike ja Päikese­süsteem
URL: https://www.opiq.ee/kit/11/chapter/451
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.4
Topics ET: loodusõpetus, päike, päikese, süsteem, suur, kaugel, kaua, tuleb, valgus
Topics RU: природоведение
Topics EN: science
Headings: Päike ja Päikese­süsteem; Päike; Kui suur on Päike ja kui kaugel ta on?; Kui kaua tuleb valgus Päikeselt Maale?; Kui kuum on Päike?; Kui vana on Päike?; Mis on Päikesesüsteem?; Päikese­energia; Mõtle!; Mõisted; Ma tean, et …
Task examples: Võrreldes teiste tähtedega paistab Päike meile suure ja heledana, sest ...; Mitu korda on Päikese läbimõõt Maa läbimõõdust suurem?

## Planeedid
URL: https://www.opiq.ee/kit/11/chapter/452
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.5
Topics ET: loodusõpetus, planeedid, palju, päikesesüsteemis, planeete, lisa, miks, pluutot, enam
Topics RU: природоведение
Topics EN: science
Headings: Planeedid; Kui palju on Päikesesüsteemis planeete?; Lisa. Miks Pluutot enam planeediks ei peeta?; Mõisted; Ma tean, et …
Task examples: Vasta Päikesesüsteemi joonise järgi.; Mille poolest erineb planeet tähest?

## Maa
URL: https://www.opiq.ee/kit/11/chapter/453
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.6
Topics ET: loodusõpetus, eripärad, mõtle, kuidas, maakera, sündis, hoiab, maad, teisi
Topics RU: природоведение
Topics EN: science
Headings: Maa; Maa eripärad; Mõtle!; Kuidas maakera sündis?; Mis hoiab Maad ja teisi taevakehi tiirlemas ümber Päikese?; Lisa. Elu universumis; Lisa. Millised võiksid välja näha teiste planeetide olendid?; Ma tean, et …
Task examples: Mille poolest erineb Maa teistest planeetidest?; Järjesta laused õigesti.

## Maa tiirleb ümber Päikese ja pöörleb ümber oma telje
URL: https://www.opiq.ee/kit/11/chapter/454
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.7
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, tiirleb, ümber, päikese, pöörleb, telje, miks, vahelduvad, päev
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Maa tiirleb ümber Päikese ja pöörleb ümber oma telje; Miks vahelduvad öö ja päev?; Miks vahelduvad aastaajad?; Kuu- ja päikesevarjutus; Lisa. Liigaastad; Mõtle!; Mõisted; Ma tean, et …
Task examples: Millised taevakehad põhjustavad öö ja päeva vaheldumise?; Kumma liikumise tõttu vahelduvad öö ja päev?

## Maa kaaslased. Kuu ja satelliidid
URL: https://www.opiq.ee/kit/11/chapter/455
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.8
Topics ET: loodusõpetus, kaaslased, satelliidid, tiirleb, ümber, miks, paista, meile, alati
Topics RU: природоведение
Topics EN: science
Headings: Maa kaaslased. Kuu ja satelliidid; Kuu tiirleb ümber Maa; Miks ei paista Kuu meile alati ühesugusena?; Satelliidid; Mõtle!; Mis satelliitidest lõpuks saab?; Mõisted; Ma tean, et …
Task examples: Kuu on Maa poole pööratud ...; Kuud näeme seetõttu, et ...

## Päikese­süsteemi väikekehad
URL: https://www.opiq.ee/kit/11/chapter/456
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 1.9
Topics ET: loodusõpetus, päikese, süsteemi, väikekehad, kääbusplaneedid, asteroidid, mõtle, komeedid, meteoorid
Topics RU: природоведение
Topics EN: science
Headings: Päikese­süsteemi väikekehad; Kääbusplaneedid; Asteroidid; Mõtle!; Komeedid; Meteoorid ja meteoriidid; Ma tean, et …
Task examples: Mis on planeetidel ja kääbusplaneetidel sarnast?; Mis eristab kääbusplaneete planeetidest?

## Maa kuju
URL: https://www.opiq.ee/kit/11/chapter/457
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.1
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, kuju, kuidas, saada, kera, kujuga, mõtle, lisa, päeva
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Maa kuju; Kuidas saada aru, et Maa on kera kujuga?; Mõtle!; Lisa. Öö ja päeva pikkus; Kuidas kujutasid muistsed inimesed Maad ette?; Lisa. Kas maakera on ikka päris ümmargune?; Ma tean, et …
Task examples: Vali lausele õige lõpp.; Millisena kujutasid Maad ette muistsed inimesed? Too kolm näidet.

## Maakera siseehitus
URL: https://www.opiq.ee/kit/11/chapter/466
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.10
Topics ET: loodusõpetus, maakera, siseehitus, kihiline, mõtle, praguline, maakoor, triivivad, mandrid
Topics RU: природоведение
Topics EN: science
Headings: Maakera siseehitus; Kihiline Maa; Mõtle!; Praguline maakoor; Triivivad mandrid; Ma tean, et…
Task examples: Kuidas nimetatakse hiidmandrit, mille kunagi moodustasid kõik tänapäevased mandrid?

## Vulkaanid
URL: https://www.opiq.ee/kit/11/chapter/467
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.11
Topics ET: loodusõpetus, vulkaanid, paneb, vulkaani, purskama, mõtle, asuvad, mida, vulkaanide
Topics RU: природоведение
Topics EN: science
Headings: Vulkaanid; Mis paneb vulkaani purskama?; Mõtle!; Kus vulkaanid asuvad?; Mida on vulkaanide piirkonnas veel huvitavat?; Lisa. Kas oled kuulnud Islandi vulkaanist nimega Eyjafjallajökull?; Mõisted; Ma tean, et …
Task examples: Millist ookeani ümbritsevad vulkaanid nii tiheda ringina, et seda nimetatakse tulerõngaks?

## Maavärinad
URL: https://www.opiq.ee/kit/11/chapter/468
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.12
Topics ET: loodusõpetus, maavärinad, miks, väriseb, kaugele, maavärin, ulatub, kuidas, tekib
Topics RU: природоведение
Topics EN: science
Headings: Maavärinad; Miks Maa väriseb?; Kui kaugele maavärin ulatub?; Kuidas tekib tsunami?; Mõtle!; Kuidas maavärinaid ennustatakse?; Kas ka Eestis võib maa väriseda?; Kuidas käituda maavärina ajal ja pärast maavärinat?; Mõisted; Ma tean, et …
Task examples: Mis paneb maa värisema?; Mis on maavärina kolle?

## Katastroofiliste tagajärgedega loodus­nähtused
URL: https://www.opiq.ee/kit/11/chapter/469
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.13
Topics ET: loodusõpetus, loodus, keskkond, inimene, keha, meeled, tervis, katastroofiliste, tagajärgedega, nähtused, mõjutab, loodusnähtuste, toimumist
Topics RU: природоведение, природа, окружающая среда, человек, тело, чувства, здоровье
Topics EN: science, nature, environment, human, body, senses, health
Headings: Katastroofiliste tagajärgedega loodus­nähtused; Mis mõjutab loodusnähtuste toimumist?; Kas inimene suudab loodusnähtuste toimumist mõjutada?; Mõtle!; Ilmastikust tingitud loodusnähtused. Tugevad tuuled; Miks tekivad üleujutused?; Mõisted; Ma tean, et …
Task examples: Märgi ära orkaane kirjeldavad väited.; Märgi ära Eestis esinevad loodusnähtused.

## Gloobus
URL: https://www.opiq.ee/kit/11/chapter/458
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.2
Topics ET: loodusõpetus, gloobus, mudel, jooned, gloobusel, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Gloobus; Maa mudel; Jooned gloobusel; Mõisted; Ma tean, et …
Task examples: Milleks saab gloobust kasutada?; Mis jagab gloobuse ida- ja läänepoolkeraks?

## Kaart
URL: https://www.opiq.ee/kit/11/chapter/459
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.3
Topics ET: loodusõpetus, kaart, kuidas, saab, gloobusest, valmib, uuri, objekte, kaardil
Topics RU: природоведение
Topics EN: science
Headings: Kaart; Kuidas saab gloobusest kaart?; Kuidas kaart valmib?; Uuri!; Kuidas objekte kaardil kujutatakse?; Lisa. Mida teeb kartograaf?; Mõisted; Ma tean, et …
Task examples: Millal kasutad gloobust, millal kaarti? Lohista lause õige pealkirja alla.; Millal kasutad gloobust, millal kaarti? Lohista lause õige pealkirja alla.

## Kuidas mõõta vahemaid kaardil?
URL: https://www.opiq.ee/kit/11/chapter/460
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.4
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, kuidas, mõõta, vahemaid, kaardil, vahemaa, mõõda, teekond
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Kuidas mõõta vahemaid kaardil?; Vahemaa mõõtmine; Mõõda oma teekond.; Mõõtkavad kaartidel; Uuri!; Mõisted; Ma tean, et …
Task examples: Mis ühikutes vahemaid mõõdetakse?; Miks lisatakse igale kaardile mõõtkava?

## Kaartide mitmekesisus
URL: https://www.opiq.ee/kit/11/chapter/461
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.5
Topics ET: loodusõpetus, kaartide, mitmekesisus, miks, kaarte, vaja, mõtle, mida, kaartidel
Topics RU: природоведение
Topics EN: science
Headings: Kaartide mitmekesisus; Miks on kaarte vaja?; Mõtle!; Mida kaartidel kujutatakse?; Milliseid kaarte võib atlastest leida?; Mis on navigatsiooni­seadmed?; Mõisted; Ma tean, et …
Task examples: Kes neist vajavad kaarte oma igapäevatöös?; Kummalt kaardilt leiad vastuse? Lohista lause õige pealkirja alla.

## Mandrid ja maailmajaod
URL: https://www.opiq.ee/kit/11/chapter/462
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.6
Topics ET: loodusõpetus, mandrid, maailmajaod, lisa, suurimad, väikseimad, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Mandrid ja maailmajaod; Mandrid; Maailmajaod; Lisa. Suurimad ja väikseimad maailmajaod; Mõisted; Ma tean, et …
Task examples: Millised mandrid on omavahel ühendatud?; Millised mandrid asuvad peamiselt idapoolkeral?

## Ookeanid ja mered
URL: https://www.opiq.ee/kit/11/chapter/463
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.7
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, ookeanid, mered, suurused, sügavused, ookeanide, pindalad, kuidas, tekkisid
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Ookeanid ja mered; Ookeanid; Suurused ja sügavused; Ookeanide pindalad; Kuidas ookeanid tekkisid?; Lisa. Ookeanipõhi; Miks on ookeanide vesi soolane?; Läänemeri; Elu maailmameres; Mõtle!; Mõisted; Ma tean, et …
Task examples: Lõpeta kaardi põhjal laused.; Millisteks suurteks osadeks jaotatakse maismaa?

## Eesti geograafiline asend
URL: https://www.opiq.ee/kit/11/chapter/464
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.8
Topics ET: loodusõpetus, eesti, geograafiline, asend, mõtle, naaberriigid, riigipiir, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Eesti geograafiline asend; Geograafiline asend; Mõtle!; Eesti naaberriigid ja riigipiir; Mõisted; Ma tean, et …
Task examples: Märgi ära väited, mis iseloomustavad Eesti asendit.; Millised järgmistest riikidest asuvad Läänemere kaldal?

## Euroopa kaart
URL: https://www.opiq.ee/kit/11/chapter/465
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 2.9
Topics ET: loodusõpetus, euroopa, kaart, maailmakaardil, suurimad, riigid, euroopas, tean
Topics RU: природоведение
Topics EN: science
Headings: Euroopa kaart; Euroopa maailmakaardil; Suurimad riigid Euroopas; Ma tean, et …
Task examples: Milline maailmajagu asub Euroopast ...; Millised Eesti naaberriigid kuuluvad Euroopas pindalalt kümne suurima riigi hulka?

## Elu teke ja selle arenemine vees
URL: https://www.opiq.ee/kit/11/chapter/470
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.1
Topics ET: loodusõpetus, teke, selle, arenemine, vees, algusaeg, maal, mõtle, erinevate
Topics RU: природоведение
Topics EN: science
Headings: Elu teke ja selle arenemine vees; Maa algusaeg; Elu teke Maal; Mõtle!; Erinevate elusolendite ilmumine; Mõisted; Ma tean, et …
Task examples: Kas 4600 miljonit aastat tagasi oleks saanud ümber maakera purjetada?; Kuidas ookeanid tekkisid?

## Elu arenemine maismaal
URL: https://www.opiq.ee/kit/11/chapter/471
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.2
Topics ET: loodusõpetus, aeg, kell, kalender, arenemine, maismaal, esmane, sauruste, ajastu, imetajate, valitsemise, mõtle
Topics RU: природоведение, время, часы, календарь
Topics EN: science, time, clock, calendar
Headings: Elu arenemine maismaal; Esmane elu maismaal; Sauruste ajastu; Imetajate valitsemise aeg; Mõtle!; Kokkuvõte. Elu ajalugu; Lisa. Mis ohustab tänapäeva loomi ja taimi?; Mõisted; Ma tean, et …
Task examples: Järjesta esmase elu etapid maismaal.; Järjesta toimunu õigesti.

## Elu tunnused
URL: https://www.opiq.ee/kit/11/chapter/472
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.3
Topics ET: loodusõpetus, tunnused, elusolendid, väga, erinevad, kuidas, kindlaks, teha, tegu
Topics RU: природоведение
Topics EN: science
Headings: Elu tunnused; Elusolendid on väga erinevad; Kuidas kindlaks teha, kas tegu on elusolendiga?; Rakke uuritakse mikroskoobiga; Mõtle!; Mõisted; Ma tean, et …
Task examples: Märgi ära, kes kuuluvad elusolendite hulka.; Võrdle konna, vahtrapuud ja kivi. Märgi lahtrisse pluss, kui tunnus iseloomustab küsitut, ja miinus, kui ei iseloomusta. Viimasesse lahtrisse märgi, kas tegemist on elusolendiga.

## Organismide mitmekesisus
URL: https://www.opiq.ee/kit/11/chapter/473
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.4
Topics ET: loodusõpetus, organismide, mitmekesisus, üherakulised, elusolendid, hulkraksed, uuri, kuidas, elusolendeid
Topics RU: природоведение
Topics EN: science
Headings: Organismide mitmekesisus; Üherakulised elusolendid; Hulkraksed elusolendid; Uuri!; Kuidas elusolendeid rühmitatakse?; Mõtle!; Mõisted; Ma tean, et …
Task examples: Märgi ühest rakust koosnevad organismid.; Kõiki elusolendeid, kelle keha koosneb ühest rakust, nimetatakse ...

## Elu erinevates keskkonna­tingimustes
URL: https://www.opiq.ee/kit/11/chapter/474
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.5
Topics ET: loodusõpetus, erinevates, keskkonna, tingimustes, elutingimused, maakeral, erinevad, maailm, jaotatud
Topics RU: природоведение
Topics EN: science
Headings: Elu erinevates keskkonna­tingimustes; Elutingimused maakeral erinevad; Maailm on jaotatud loodusvöönditeks; Elutingimused Eestis; Mõtle!; Neli aastaaega; Mõisted; Ma tean, et …
Task examples: Kõige suuremaid erinevusi maakera eri piirkondade elutingimustes põhjustab ...; Märgi ära keskkonnatingimused.

## Elu vihmametsas
URL: https://www.opiq.ee/kit/11/chapter/475
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, vihmametsas, vihmametsad, mõtle, lisa, ohus, mõisted
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Elu vihmametsas; Mis on vihmametsad?; Mõtle!; Taimed vihmametsas; Loomad vihmametsas; Lisa. Vihmametsad on ohus; Mõisted; Ma tean, et …
Task examples: Mis iseloomustab troopilist vihmametsa?; Millistes maailmajagudes on vihmametsasid?

## Elu kõrbes
URL: https://www.opiq.ee/kit/11/chapter/476
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.7
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, kõrbes, kõrbed, oaasid, mõisted, tean
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Elu kõrbes; Mis on kõrbed?; Taimed kõrbes; Loomad kõrbes; Oaasid; Mõisted; Ma tean, et …
Task examples: Millistes maailmajagudes leidub kõrbeid?; Kuidas tulevad kõrbetaimed toime pika kuivaperioodiga?

## Elu tundras
URL: https://www.opiq.ee/kit/11/chapter/477
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 3.8
Topics ET: loodusõpetus, taim, taimed, puu, lill, aastaajad, kevad, suvi, sügis, talv, tundras, tundra, uuri, polaaröö, polaarpäev, mõtle, lisa, tundrat
Topics RU: природоведение, растение, растения, дерево, цветок, времена года, весна, лето, осень, зима
Topics EN: science, plant, plants, tree, flower, seasons, spring, summer, autumn, winter
Headings: Elu tundras; Mis on tundra?; Uuri!; Polaaröö ja polaarpäev; Mõtle!; Lisa. Tundrat leiab ka mägedest; Tundra aastaajad; Tundra taimed ja samblikud; Tundra loomastik; Mõisted; Ma tean, et …
Task examples: Millised on tundra aastaajad?; Millistes maailmajagudes levivad tundrad?

## Inimese kehaehitus
URL: https://www.opiq.ee/kit/11/chapter/478
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.1
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, inimene, keha, meeled, tervis, inimese, kehaehitus, välisehitus, millest, koosneb, mõtle, elundid
Topics RU: природоведение, вода, безопасность на воде, водоём, человек, тело, чувства, здоровье
Topics EN: science, water, water safety, body of water, human, body, senses, health
Headings: Inimese kehaehitus; Inimese välisehitus; Millest inimene koosneb?; Mõtle!; Elundid koosnevad kudedest; Lisa. Vesi inimkehas; Mõisted; Ma tean, et …
Task examples: Lohista kehaosad õigesse kohta.; Mis millest koosneb? Vali õiged mõisted nii, et esimeses lahtris oleks kõige väiksem ja viimases kõige suurem.

## Suguelundid
URL: https://www.opiq.ee/kit/11/chapter/487
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.10
Topics ET: loodusõpetus, suguelundid, naiste, meeste, lisa, seemne, munarakud, kuidas, hakkab
Topics RU: природоведение
Topics EN: science
Headings: Suguelundid; Naiste ja meeste suguelundid; Lisa. Seemne- ja munarakud; Kuidas hakkab arenema uus elu?; Mis juhtub, kui munarakk ei viljastu?; Mõisted; Ma tean, et …
Task examples: Lohista väited õige pealkirja alla.; Mille kaudu toitub ja hingab kõhus kasvav loode?

## Närvisüsteem. Näärmed
URL: https://www.opiq.ee/kit/11/chapter/488
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.11
Topics ET: loodusõpetus, närvisüsteem, näärmed, lisa, ajuripats, mõtle, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Närvisüsteem. Näärmed; Närvisüsteem; Näärmed; Lisa. Ajuripats; Mõtle!; Mõisted; Ma tean, et …
Task examples: Märgi ära tõesed laused.; Poiss puudutab tulist potti. Mis juhtub edasi? Lohista laused õigesse järjekorda.

## Inimene on imetaja
URL: https://www.opiq.ee/kit/11/chapter/489
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.12
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, imetaja, inimese, koera, võrdlus, mõtle, sarnaneb, kõige
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimene on imetaja; Inimese ja koera võrdlus; Mõtle!; Inimene sarnaneb kõige enam teiste imetajatega; Lisa. Väikseim ja suurim imetaja; Ma tean, et …

## Inimesed ja ahvid
URL: https://www.opiq.ee/kit/11/chapter/490
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.13
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, inimesed, ahvid, inimahvid, mõtle, mille, poolest, ahvist
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimesed ja ahvid; Inimahvid; Mõtle!; Mille poolest inimene ahvist erineb?; Mis on inimesel ja ahvil ühist?; Ma tean, et …
Task examples: Aasias elavad inimahvidest ...; Inimesele kõige lähedasemad loomad on ...

## Inimese põlvnemine
URL: https://www.opiq.ee/kit/11/chapter/491
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.14
Topics ET: loodusõpetus, inimese, põlvnemine, põlvnemise, uurimine, millised, muutused, toimusid, inimesega
Topics RU: природоведение
Topics EN: science
Headings: Inimese põlvnemine; Inimese põlvnemise uurimine; Millised muutused toimusid inimesega tema arengu jooksul?; Mis eristab inimest teistest loomadest?; Mõtle!; Lisa. Neandertallased; Ma tean, et …
Task examples: Millistel mandritel elas püstine inimene? Vasta kaardi järgi.; Millist inimest on kirjeldatud?

## Elundkondade ülesanded
URL: https://www.opiq.ee/kit/11/chapter/479
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.2
Topics ET: loodusõpetus, elundkondade, millised, elundkonnad, inimesel, inimese, katteelundkond, tugi
Topics RU: природоведение
Topics EN: science
Headings: Elundkondade ülesanded; Millised elundkonnad on inimesel?; Inimese elundkonnad I; Katteelundkond; Tugi- ja liikumiselundkond; Seedeelundkond; Vereringeelundkond; Hingamiselundkond; Inimese elundkonnad II; Närvisüsteem; Erituselundkond; Meeleelundkond; Suguelundkond; Uuri!; Lisa. Mis on refleksid?; Lisa. Mis juhtub, kui mõni elund jääb haigeks või lõpetab töötamise?; Mõisted; Ma tean, et …
Task examples: Märgi inimese elundkonnad.; Märgi inimese elundkonnad.

## Meeleelundid
URL: https://www.opiq.ee/kit/11/chapter/480
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.3
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, meeleelundid, inimese, kuidas, silm, töötab, lisa, silma, abilised
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Meeleelundid; Inimese meeleelundid; Kuidas silm töötab?; Lisa. Silma abilised; Kuidas kõrv töötab?; Kuidas keel töötab?; Lisa. Mida aitab maitsmismeel avastada?; Kuidas nina töötab?; Lisa. Kui mitut lõhna suudab inimene eristada?; Meeleelundid ja peaaju; Lisa. Miks meenutab mõni lõhn mõnd möödunud sündmust?; Mõisted; Ma tean, et …
Task examples: Sisekõrv on lisaks kuulmisele seotud ka ...; Järjesta kõrvas toimuvad protsessid.

## Meeleelundid. Nahk
URL: https://www.opiq.ee/kit/11/chapter/481
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.4
Topics ET: loodusõpetus, meeleelundid, nahk, selle, lisa, punktkiri, uuri, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Meeleelundid. Nahk; Nahk ja selle ülesanded; Lisa. Punktkiri; Uuri!; Mõisted; Ma tean, et …
Task examples: Millist infot saad naha kaudu?; Mis on naha ülesanded?

## Tugi- ja liikumiselundid
URL: https://www.opiq.ee/kit/11/chapter/482
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.5
Topics ET: loodusõpetus, tugi, liikumiselundid, luud, liigesed, lisa, miks, ninaotsas, liigub
Topics RU: природоведение
Topics EN: science
Headings: Tugi- ja liikumiselundid; Luud ja liigesed; Lisa. Miks mu ninaotsas luu liigub?; Lihased; Lisa. Miks me vajame tugevaid luid?; Mõtle!; Mõisted; Ma tean, et …
Task examples: Vasta jooniste järgi.; Vasta jooniste järgi.

## Hingamiselundid
URL: https://www.opiq.ee/kit/11/chapter/483
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.6
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, hingamiselundid, kuidas, hingab, lisa, miks, joostes, hingeldama
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Hingamiselundid; Kuidas inimene hingab?; Lisa. Miks me joostes hingeldama hakkame?; Kuidas saab hingamiselundkonna eest hoolitseda?; Mõtle!; Mõisted; Ma tean, et …
Task examples: Milline on õhu liikumise teekond?; Milline on õhu liikumise teekond?

## Vereringe
URL: https://www.opiq.ee/kit/11/chapter/484
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.7
Topics ET: loodusõpetus, vereringe, kuidas, veri, kehas, ringleb, lisa, kapillaarid, avatud
Topics RU: природоведение
Topics EN: science
Headings: Vereringe; Kuidas veri kehas ringleb?; Lisa. Kapillaarid; Lisa. Avatud ja suletud vereringe; Lisa. Kuidas saab kontrollida, kas süda tõesti pumpab verd arteritesse?; Millest veri koosneb?; Mõtle!; Lisa. Kuidas veri hüübib?; Lisa. Miks loovutavad inimesed verd?; Mõisted; Ma tean, et …
Task examples: Millised on vererakkude ülesanded?; Vereliistakud kleepuvad omavahel ja moodustavad kiudude võrgustiku, mis ei lase vererakke läbi, mistõttu tekib ...

## Seedeelundid
URL: https://www.opiq.ee/kit/11/chapter/485
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.8
Topics ET: loodusõpetus, seedeelundid, kuidas, toimub, seedimine, uuri, seedenõred, seedimiseks, vajalikud
Topics RU: природоведение
Topics EN: science
Headings: Seedeelundid; Kuidas toimub seedimine?; Uuri!; Seedenõred on seedimiseks vajalikud; Mõisted; Ma tean, et …
Task examples: Millises elundis imenduvad toitained verre?; Millised elundid osalevad seedimisel, ehkki toit läbi nende ei liigu?

## Erituselundid
URL: https://www.opiq.ee/kit/11/chapter/486
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 4.9
Topics ET: loodusõpetus, erituselundid, jääkained, palju, tekib, kehas, jääkaineid, mõtle, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Erituselundid; Jääkained; Kui palju tekib kehas jääkaineid?; Mõtle!; Mõisted; Ma tean, et …
Task examples: Millised erituselundid kuuluvad samas ka mõnda teise elundkonda?; Milliste elundite kaudu me jääkainetest vabaneme? Ühenda paarid.

## Taimed inimese elus
URL: https://www.opiq.ee/kit/11/chapter/492
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 5.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, inimese, elus, teevad, toitu, endale, teistele, taimedelt
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed inimese elus; Taimed teevad toitu endale ja teistele; Taimedelt saame hapnikku; Taimed puhastavad õhku ja ravivad; Taimed köögis; Taimed kaitsevad külma eest ja loovad ilu; Uuri!; Ma tean, et …
Task examples: Mida vajavad taimed suhkru valmistamiseks?; Mis kasu on inimesel taimedest?

## Loomad inimese elus
URL: https://www.opiq.ee/kit/11/chapter/493
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 5.2
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, inimese, elus, loomade, kodustamine, nahast, karvadest, tehakse
Topics RU: природоведение, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье
Topics EN: science, animal, animals, birds, insects, human, body, senses, health
Headings: Loomad inimese elus; Loomade kodustamine; Loomade nahast ja karvadest tehakse riideid ja jalanõusid; Loomad on inimesele abiks; Putukatelt saadakse mett ja siidi; Inimene vajab sõpra; Mõtle!; Lisa. Vereta jaht; Ma tean, et …
Task examples: Milliseid töid aitavad loomad teha?; Mis on loomset päritolu?

## Seened inimese elus
URL: https://www.opiq.ee/kit/11/chapter/494
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 5.3
Topics ET: loodusõpetus, seened, inimese, elus, inimesed, korjavad, seeni, toiduks, söödavad, kupatamist
Topics RU: природоведение
Topics EN: science
Headings: Seened inimese elus; Inimesed korjavad seeni toiduks; Söödavad seened; Kupatamist vajavad seened; Mürgised seened; Inimesed kasvatavad seeni; Seeni kasutatakse mitmesugusel otstarbel; Lisa. Hallitusseened; Seened põhjustavad haigusi ja lagundavad puitu; Mõtle!; Seened on looduses lagundajad; Ma tean, et …
Task examples: Lohista seened õige pealkirja alla.; Mida vajavad seened kasvamiseks?

## Bakterid inimese elus
URL: https://www.opiq.ee/kit/11/chapter/495
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 5.4
Topics ET: loodusõpetus, bakterid, inimese, elus, elavad, peal, sees, mõtle, baktereid
Topics RU: природоведение
Topics EN: science
Headings: Bakterid inimese elus; Bakterid elavad inimese peal ja sees; Mõtle!; Baktereid kasutatakse toidu valmistamisel; Bakterid on lagundajad; Lisa. Mõned bakterid võivad põhjustada haigusi; Koroonat põhjustab viirus; Ma tean, et …
Task examples: Miks on paljud bakterid meile kasulikud?; Mis toitude valmistamisel kasutatakse baktereid?

## Tööleht. Õuesõpe
URL: https://www.opiq.ee/kit/11/chapter/496
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 6.1
Topics ET: loodusõpetus, tööleht, õuesõpe, õuesõppe, juhend
Topics RU: природоведение
Topics EN: science
Headings: Tööleht. Õuesõpe; Õuesõppe juhend

## Eesti füüsiline kaart
URL: https://www.opiq.ee/kit/11/chapter/497
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 6.2
Topics ET: loodusõpetus, eesti, füüsiline, kaart
Topics RU: природоведение
Topics EN: science
Headings: Eesti füüsiline kaart

## Maailma füüsiline kaart
URL: https://www.opiq.ee/kit/11/chapter/498
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 6.3
Topics ET: loodusõpetus, maailma, füüsiline, kaart, põhjapoolkera, lõunapoolkera
Topics RU: природоведение
Topics EN: science
Headings: Maailma füüsiline kaart; Põhjapoolkera 1; Põhjapoolkera 2; Põhjapoolkera 3; Lõunapoolkera 1; Lõunapoolkera 2; Lõunapoolkera 3

## Lugemist uudishimulikele
URL: https://www.opiq.ee/kit/11/chapter/499
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 6.4
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, lugemist, uudishimulikele, kirjandus, maailmaruum, planeet, mitmekesisus, maal, internetiviited
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Lugemist uudishimulikele; Kirjandus; Maailmaruum; Planeet Maa; Elu mitmekesisus Maal; Inimene; Internetiviited

## Mõisted
URL: https://www.opiq.ee/kit/11/chapter/12296
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 6.5
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/11/chapter/500
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile
Chapter ID: 6.6
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Loodusõpetus 4. klassile (2023) – Opiq
URL: https://www.opiq.ee/Kit/Details/480
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 125
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 4. klassile (2023) – Opiq
URL: https://www.opiq.ee/Kit/Details/480
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 176
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Tähistaevas
URL: https://www.opiq.ee/kit/480/chapter/26375
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.1
Topics ET: loodusõpetus, tähistaevas, tähed, tähtkujud, põhjanael, taevakaart, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Tähistaevas; Tähed; Tähtkujud; Põhjanael; Taevakaart; Mõisted; Ma tean, et …
Task examples: Mis on meie tuntuim tähtkuju?; Mis on meie tuntuim tähtkuju?

## Maailmaruum
URL: https://www.opiq.ee/kit/480/chapter/26376
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.2
Topics ET: loodusõpetus, maailmaruum, seal, sees, tead, neid, sõnu, galaktikad, udukogu
Topics RU: природоведение
Topics EN: science
Headings: Maailmaruum; Mis on maailmaruum ja mis seal sees on?; Kas tead neid sõnu?; Mis on galaktikad?; Mis on udukogu?; Linnutee naabergalaktika on Andromeeda galaktika; Mõisted; Ma tean, et …
Task examples: Kui kaugele jõuab Päikeselt pärit olev valgus ühe aasta jooksul? Märgi kõik õiged vastused.; Mis asuvad universumis?

## Päike
URL: https://www.opiq.ee/kit/480/chapter/26377
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.3
Topics ET: loodusõpetus, päike, suur, kaugel, kuum, päikese, eluring, energiaallikas, hoia
Topics RU: природоведение
Topics EN: science
Headings: Päike; Mis on Päike?; Kui suur on Päike ja kui kaugel ta on?; Kui kuum on Päike?; Päikese eluring; Päike on energiaallikas; Hoia oma silmi ja nahka!; Mõisted; Ma tean, et …
Task examples: Miks on Päike tähtis?; Kui kaua kulub aega valgusel Päikeselt Maani jõudmiseks?

## Päikesesüsteem ja planeedid
URL: https://www.opiq.ee/kit/480/chapter/26378
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.4
Topics ET: loodusõpetus, päikesesüsteem, planeedid, kuidas, planeedil, tähel, vahet, teha, liiguvad
Topics RU: природоведение
Topics EN: science
Headings: Päikesesüsteem ja planeedid; Mis on Päikesesüsteem?; Kuidas planeedil ja tähel vahet teha?; Kuidas planeedid liiguvad?; Kuidas planeete jagatakse?; Mõisted; Ma tean, et …
Task examples: Märgi, mis kuuluvad Päikesesüsteemi.; Lohista planeedid õigesse järjekorda nii, et ülemine on Päikesele lähim.

## Päikese­süsteemi väikekehad
URL: https://www.opiq.ee/kit/480/chapter/26379
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.5
Topics ET: loodusõpetus, päikese, süsteemi, väikekehad, kääbusplaneedid, meteoorid, meteoriidid, komeedid, asteroidid
Topics RU: природоведение
Topics EN: science
Headings: Päikese­süsteemi väikekehad; Kääbusplaneedid; Meteoorid ja meteoriidid; Komeedid; Asteroidid; Ma tean, et …
Task examples: Märgi kääbusplaneedid.; Millal tekib komeedile saba?

## Maa
URL: https://www.opiq.ee/kit/480/chapter/26380
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.6
Topics ET: loodusõpetus, kuidas, maakera, sündis, missugune, planeet, suur, lisa, väljaspool
Topics RU: природоведение
Topics EN: science
Headings: Maa; Kuidas maakera sündis?; Missugune planeet on Maa?; Kui suur on Maa?; Lisa. Elu väljaspool Maad; Kust me elu otsime?; Kuidas me universumist elu otsime?; Ma tean, et …
Task examples: Järjesta laused õigesti.; Mille poolest erineb Maa teistest Päikesesüsteemi planeetidest?

## Maa pöörleb ja tiirleb
URL: https://www.opiq.ee/kit/480/chapter/26381
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.7
Topics ET: loodusõpetus, pöörleb, tiirleb, päeva, vaheldumine, aastaaegade, päikesevarjutuse, teke, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Maa pöörleb ja tiirleb; Öö ja päeva vaheldumine; Aastaaegade vaheldumine; Kuu- ja päikesevarjutuse teke; Mõisted; Ma tean, et …
Task examples: Kui kaua kulub Maal aega, et teha üks pööre ümber oma kujuteldava telje? Märgi kõik õiged vastused.; Kumma liikumise tõttu vahelduvad öö ja päev?

## Maa kaaslased. Kuu ja satelliidid
URL: https://www.opiq.ee/kit/480/chapter/26382
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.8
Topics ET: loodusõpetus, kaaslased, satelliidid, miks, paista, meile, alati, ühesugusena, inimesed
Topics RU: природоведение
Topics EN: science
Headings: Maa kaaslased. Kuu ja satelliidid; Mis on Kuu?; Miks ei paista Kuu meile alati ühesugusena?; Inimesed Kuul; Satelliidid; Mis satelliitidest lõpuks saab?; Mõisted; Ma tean, et …
Task examples: Kuu on Maa poole pööratud ...; Kuud näeme seetõttu, et ...

## Maailmaruumi uurimine
URL: https://www.opiq.ee/kit/480/chapter/26383
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 1.9
Topics ET: loodusõpetus, maailmaruumi, uurimine, täheteadus, astronoomia, millega, uuritakse, kosmoseaparaadid, kosmose
Topics RU: природоведение
Topics EN: science
Headings: Maailmaruumi uurimine; Täheteadus ehk astronoomia; Millega uuritakse maailmaruumi?; Kosmoseaparaadid; Kosmose uurimisega seotud ametid; Tartu observatoorium; Mõisted; Ma tean, et …
Task examples: Miks jälgiti vanasti taevakehasid?; Mida saab kosmoseteleskoopidega teha?

## Maa kuju
URL: https://www.opiq.ee/kit/480/chapter/26384
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.1
Topics ET: loodusõpetus, kuju, muistsed, ettekujutused, maast, kerakujuline, silmapiiri, taga, laevareisid
Topics RU: природоведение
Topics EN: science
Headings: Maa kuju; Muistsed ettekujutused Maast; Maa on kerakujuline; Mis on silmapiiri taga?; Laevareisid ja maakera kuju; Ma tean, et …
Task examples: Millisena muistsetel aegadel Maad ette kujutati? Vali õige vastus.; Mille põhjal võib öelda, et Maa on kerakujuline? Märgi õiged vastused.

## Maakera siseehitus
URL: https://www.opiq.ee/kit/480/chapter/26393
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.10
Topics ET: loodusõpetus, maakera, siseehitus, sisemuse, uurimine, maakoor, vahevöö, tuum, koosneb
Topics RU: природоведение
Topics EN: science
Headings: Maakera siseehitus; Maa sisemuse uurimine; Maakoor; Vahevöö ja tuum; Maakoor koosneb tükkidest; Lisa. Mandrite triiv; Ma tean, et …
Task examples: Kust on teadlased saanud infot Maa siseehituse kohta?; Vali lünka õige sõna.

## Vulkaanid
URL: https://www.opiq.ee/kit/480/chapter/26394
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.11
Topics ET: loodusõpetus, vulkaanid, paneb, vulkaani, purskama, asuvad, vulkaanide, läheduses, saab
Topics RU: природоведение
Topics EN: science
Headings: Vulkaanid; Mis paneb vulkaani purskama?; Kus vulkaanid asuvad?; Kas vulkaanide läheduses saab elada?; Kuumaveeallikad ja geisrid; Mõisted; Ma tean, et …
Task examples: Uuri kaarti. Kus on vulkaanipurse tõenäolisem?; Kus asub enamik vulkaane?

## Maavärinad
URL: https://www.opiq.ee/kit/480/chapter/26395
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.12
Topics ET: loodusõpetus, maavärinad, miks, väriseb, eestis, võib, väriseda, tsunami, jäta
Topics RU: природоведение
Topics EN: science
Headings: Maavärinad; Miks maa väriseb?; Kus maa väriseb?; Kas ka Eestis võib maa väriseda?; Mis on tsunami?; Jäta meelde!; Mida teha, kui maa hakkab värisema?; Mõisted; Ma tean, et …
Task examples: Mis paneb maa värisema?; Mis on maavärina kolle?

## Loodus­õnnetused
URL: https://www.opiq.ee/kit/480/chapter/26396
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.13
Topics ET: loodusõpetus, loodus, keskkond, õnnetused, õnnetus, milliseid, õnnetusi, võib, eestis, ette
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Loodus­õnnetused; Mis on loodus­õnnetus?; Milliseid loodus­õnnetusi võib Eestis ette tulla?; Üleujutused; Tugevad tuuled; Kuidas tormiks ja selle tagajärgedeks valmis olla?; Mõisted; Ma tean, et …
Task examples: Millised loodusõnnetused võivad Eestis esineda?; Mis võib põhjustada üleujutust?

## Gloobus
URL: https://www.opiq.ee/kit/480/chapter/26385
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.2
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, gloobus, mudel, jooned, gloobusel, lisa, tead, mida
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Gloobus; Gloobus on Maa mudel; Jooned gloobusel; Lisa. Kas tead, mida arvud gloobusel näitavad?; Mõisted; Ma tean, et …
Task examples: Mille poolest sarnaneb gloobus Maaga?; Kus asub Eesti? Märgi kõik õiged vastused.

## Kaart
URL: https://www.opiq.ee/kit/480/chapter/26386
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.3
Topics ET: loodusõpetus, kaart, kuidas, saab, gloobusest, uuri, valmib, objekte, kaardil
Topics RU: природоведение
Topics EN: science
Headings: Kaart; Kuidas saab gloobusest kaart?; Uuri!; Kuidas kaart valmib?; Kuidas objekte kaardil kujutatakse?; Mõisted; Ma tean, et …
Task examples: Vali lünka õige sõna.

## Kaardi mõõtkava
URL: https://www.opiq.ee/kit/480/chapter/26387
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.4
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, kaardi, mõõtkava, kaardil, kõik, tegelikkuses, kuidas, paberkaardi
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Kaardi mõõtkava; Kaardil on kõik väiksem kui tegelikkuses; Mis on mõõtkava?; Kuidas paberkaardi abil vahemaid kindlaks teha?; Näide; Lisa. Vahemaid arvestame ka ajas; Mõisted; Ma tean, et …
Task examples: Milleks on mõõtkava vaja?; Tahad arvutada, kui kaugel on kaardil olevad kohad üksteisest tegelikkuses. Mida sul selleks vaja teada on?

## Kaartide mitmekesisus
URL: https://www.opiq.ee/kit/480/chapter/26388
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.5
Topics ET: loodusõpetus, kaartide, mitmekesisus, miks, kaarte, vaja, füüsiline, kaart, riikide
Topics RU: природоведение
Topics EN: science
Headings: Kaartide mitmekesisus; Miks on kaarte vaja?; Füüsiline kaart ja riikide kaart; Atlas; Missuguseid kaarte on atlases?; Mõisted; Ma tean, et …
Task examples: Kes neist vajavad kaarte oma igapäevatöös?; Kummalt kaardilt leiad vastuse? Jaota küsimused õigesti kaartide vahel.

## Mandrid ja maailmajaod
URL: https://www.opiq.ee/kit/480/chapter/26389
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.6
Topics ET: loodusõpetus, mandrid, maailmajaod, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Mandrid ja maailmajaod; Mandrid; Maailmajaod; Mõisted; Ma tean, et …
Task examples: Millised mandrid on omavahel maaribaga ühendatud?; Millised mandrid asuvad peamiselt idapoolkeral?

## Maailmameri
URL: https://www.opiq.ee/kit/480/chapter/26390
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.7
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, maailmameri, maakeral, ookeanide, osad, mõisted, tean
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Maailmameri; Vesi maakeral; Ookeanide osad; Mõisted; Ma tean, et …
Task examples: Millisteks suurteks osadeks jaotatakse maailmameri?; Millisteks suurteks osadeks jaotatakse maismaa?

## Eesti geograafiline asend
URL: https://www.opiq.ee/kit/480/chapter/26391
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.8
Topics ET: loodusõpetus, eesti, geograafiline, asend, naaberriigid, riigipiir, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Eesti geograafiline asend; Geograafiline asend; Eesti naaberriigid ja riigipiir; Mõisted; Ma tean, et …
Task examples: Kus asub Eesti? Märgi ära Eesti asendi kohta käivad sõnad.; Millised riigid neist asuvad Läänemere kaldal?

## Euroopa kaart
URL: https://www.opiq.ee/kit/480/chapter/26392
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 2.9
Topics ET: loodusõpetus, euroopa, kaart, maailmakaardil, suurimad, riigid, euroopas, tean
Topics RU: природоведение
Topics EN: science
Headings: Euroopa kaart; Euroopa maailmakaardil; Suurimad riigid Euroopas; Ma tean, et …
Task examples: Milline veekogu piirab Euroopat ...; Milline maailmajagu asub Euroopast ...

## Elu teke ja selle arenemine vees
URL: https://www.opiq.ee/kit/480/chapter/28293
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, teke, selle, arenemine, vees, areng, ookeani, esimesed, elusolendid
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Elu teke ja selle arenemine vees; Maa areng; Maa ja ookeani teke; 00.00; 01.00; Esimesed elusolendid olid bakterid; 04.19; Ürgmerre tekivad taimed ja loomad; 20.30; 21.08; Mõisted; Ma tean, et …
Task examples: Oletame, et Maa areng on kestnud ühe ööpäeva. Mitu tundi on elusolendid tegutsenud maismaal?; Oletame, et Maa areng on kestnud ühe ööpäeva. Mitu tundi pärast Maa teket ilmusid esimesed elusolendid (bakterid)?

## Elu vihmametsas
URL: https://www.opiq.ee/kit/480/chapter/28302
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.10
Topics ET: loodusõpetus, jagamine, jaga, jagatis, pool, vihmametsas, vihmamets, niiske, hämar, maailma, loomaliikidest, elab
Topics RU: природоведение, деление, раздели, частное, половина
Topics EN: science, division, divide, quotient, half
Headings: Elu vihmametsas; Mis on vihmamets?; Vihmametsas on soe, niiske ja hämar; Pool maailma loomaliikidest elab vihmametsas; Vihmametsast saab kasulikke taimi; Vihmametsad on ohus; Mõisted; Ma tean, et …
Task examples: Millistes maailmajagudes on vihmametsi?; Mis iseloomustab vihmametsa?

## Elu kõrbes
URL: https://www.opiq.ee/kit/480/chapter/28303
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.11
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, kõrbes, kõrb, oaasid, mõisted, tean
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Elu kõrbes; Mis on kõrb?; Taimed kõrbes; Loomad kõrbes; Oaasid; Mõisted; Ma tean, et …
Task examples: Millistes maailmajagudes leidub kõrbeid?; Kuidas tulevad kõrbetaimed toime pika kuivaperioodiga?

## Elu pooluste lähedal
URL: https://www.opiq.ee/kit/480/chapter/28304
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.12
Topics ET: loodusõpetus, aeg, kell, kalender, loom, loomad, linnud, putukad, pooluste, lähedal, kogu, külm, tundras, kasvuaeg, lühike
Topics RU: природоведение, время, часы, календарь, животное, животные, птицы, насекомые
Topics EN: science, time, clock, calendar, animal, animals, birds, insects
Headings: Elu pooluste lähedal; Pooluste lähedal on kogu aeg külm; Tundras on kasvuaeg lühike; Loomad jäävööndis ja tundras; Polaaröö ja polaarpäev; Mõisted; Ma tean, et …
Task examples: Vali lausesse õige sõna.; Millistes maailmajagudes levivad tundrad?

## Elu mägedes
URL: https://www.opiq.ee/kit/480/chapter/28305
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.13
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, mägedes, kõrgemal, külmem, kõrgusel, erinevad, loodusvööndid, mägede
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Elu mägedes; Mägedes on kõrgemal külmem; Mägedes on eri kõrgusel erinevad loodusvööndid; Mägede loomad; Ma tean, et …
Task examples: Märgi mägede kohta käiv õige lause.; Vali lünka õige sõna.

## Elu arenemine maismaal
URL: https://www.opiq.ee/kit/480/chapter/28294
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.2
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, arenemine, maismaal, taimi, kolib, maismaale, sauruste, ajastu
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Elu arenemine maismaal; Osa taimi kolib maismaale; 21.48; 22.00; Loomad maismaal; 22.18; 22.57; 23.57; 23.59; Sauruste ajastu; Kivistised; Mõisted; Ma tean, et …
Task examples: Pane elusolendid ilmumise järjekorda.; Pane laused toimumise järjekorda.

## Elu tunnused
URL: https://www.opiq.ee/kit/480/chapter/28295
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.3
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, tunnused, elusolendid, väga, erinevad, kuidas, kindlaks, teha, tegu
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Elu tunnused; Elusolendid on väga erinevad; Kuidas kindlaks teha, kas tegu on elusolendiga?; Lisa. Loomad arenevad erinevalt; Rakke ja väga väikeseid elusolendeid uuritakse mikroskoobiga; Lisa. Kuidas mikroskoopi kasutada?; Mõisted; Ma tean, et …
Task examples: Märgi ära, kes kuuluvad elusolendite hulka.; Märgi elusolendi tunnused.

## Elusolendite mitmekesisus
URL: https://www.opiq.ee/kit/480/chapter/28296
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.4
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, elusolendite, mitmekesisus, kuidas, elusolendeid, rühmitatakse, rühmitamine, toitumise, viisi, raku
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Elusolendite mitmekesisus; Kuidas elusolendeid rühmitatakse?; Rühmitamine toitumise viisi ja raku ehituse järgi; Rühmitamine rakkude arvu järgi; Üherakulised elusolendid; Hulkraksed elusolendid; Mõisted; Ma tean, et …
Task examples: Märgi ära kaks viisi, kuidas saab elusolendid rühmadeks jagada.; Märgi ühest rakust koosnevad organismid.

## Taimed inimese elus
URL: https://www.opiq.ee/kit/480/chapter/28297
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, inimese, elus, teevad, toitu, endale, teistele, taimedelt
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Taimed inimese elus; Taimed teevad toitu endale ja teistele; Taimedelt saame hapnikku; Taimed puhastavad õhku ja pakuvad varju; Taimed kui maitseained; Taimed kaitsevad külma eest; Taimed ravivad; Taimede seas on mõnus; Ma tean, et …
Task examples: Mida vajavad taimed suhkru valmistamiseks?; Mis kasu on loomadel ja seentel taimedest?

## Loomad inimese elus
URL: https://www.opiq.ee/kit/480/chapter/28298
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.6
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, inimese, elus, loomalt, saadakse, toitu, loomade, villast
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Loomad inimese elus; Loomalt saadakse toitu; Loomade villast ja nahast valmistatakse riideid ja jalanõusid; Putukatelt saadakse mett ja siidi; Loom võib olla sõbraks; Loomad on inimesele abiks; Tänu putukatele on meil rikkalik toidulaud; Ma tean, et …
Task examples: Vali lünka õige sõna.; Märgi loomset päritolu riideesemed ja jalanõud.

## Seened inimese elus
URL: https://www.opiq.ee/kit/480/chapter/28299
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.7
Topics ET: loodusõpetus, seened, inimese, elus, inimesed, korjavad, seeni, toiduks, lisa, tunned
Topics RU: природоведение
Topics EN: science
Headings: Seened inimese elus; Inimesed korjavad seeni toiduks; Lisa. Kas tunned neid seeni?; Inimesed kasvatavad seeni; Seeni kasutatakse toidu valmistamisel; Hallitusseentest valmistatakse ravimeid; Osa seeni põhjustab haigusi; Seened on looduses lagundajad; Seentest saab toota põnevaid materjale; Ma tean, et …
Task examples: Milliseid seeni võib metsast söögiks korjata?; Mida vajavad seened kasvamiseks?

## Bakterid inimese elus
URL: https://www.opiq.ee/kit/480/chapter/28300
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.8
Topics ET: loodusõpetus, bakterid, inimese, elus, elavad, peal, sees, baktereid, kasutatakse
Topics RU: природоведение
Topics EN: science
Headings: Bakterid inimese elus; Bakterid elavad inimese peal ja sees; Baktereid kasutatakse toidu valmistamisel; Osa baktereid võib põhjustada haigusi; Vaktsineerimine; Bakterite põhjustatud haiguste ravimine; Bakterid on lagundajad; Bakterid puhastavad vett; Bakterid valmistavad kütust; Ma tean, et …
Task examples: Miks on paljud bakterid meile kasulikud?; Milliste toitude valmistamisel kasutatakse baktereid?

## Elu erinevates oludes
URL: https://www.opiq.ee/kit/480/chapter/28301
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 3.9
Topics ET: loodusõpetus, erinevates, oludes, elusolendeid, leidub, kõikjal, maailm, jaotatud, loodusvöönditeks
Topics RU: природоведение
Topics EN: science
Headings: Elu erinevates oludes; Elusolendeid leidub kõikjal; Maailm on jaotatud loodusvöönditeks; Elutingimused Eestis; Mõisted; Ma tean, et …
Task examples: Maakera eri piirkondades on elutingimused väga erinevad seetõttu, et seal on erinev ...; Märgi ära keskkonnatingimused.

## Rakud, koed ja elundid
URL: https://www.opiq.ee/kit/480/chapter/28422
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.1
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, rakud, koed, elundid, millest, koosneb, kuidas, tekivad
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Rakud, koed ja elundid; Millest inimene koosneb?; Kuidas rakud tekivad?; Kude ja elund; Elundkonnad; Mõisted; Ma tean, et …
Task examples: Millest koosnevad kõik elusolendid, sh inimene?; Millest koosnevad kõik elusolendid, sh inimene?

## Meele­elundid. Silmad, kõrvad, nina ja keel
URL: https://www.opiq.ee/kit/480/chapter/28431
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.10
Topics ET: loodusõpetus, meele, elundid, silmad, kõrvad, nina, keel, meeleelundite, silmadega
Topics RU: природоведение
Topics EN: science
Headings: Meele­elundid. Silmad, kõrvad, nina ja keel; Meeleelundite ülesanne; Silmadega me näeme; Kõrvadega me kuuleme; Nuusutades tunneme lõhnu; Keele abil tunneme maitset; Mõisted; Ma tean, et …
Task examples: Vali lausesse õiged sõnad.; Sisekõrv on peale kuulmise seotud ka ...

## Inimene kui tervik
URL: https://www.opiq.ee/kit/480/chapter/28432
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.11
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, tervik, osade, suurused, sobivad, omavahel, töötab
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimene kui tervik; Keha osade suurused sobivad omavahel; Keha töötab kui üks tervik; Su keha on su sõber; Ma tean, et …
Task examples: Milleks inimene oma keha kasutab?; Mida on jalgpalli mängimiseks väga vaja?

## Inimene on imetaja
URL: https://www.opiq.ee/kit/480/chapter/28433
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.12
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, imetaja, koer, sarnased, inimahvid, samuti, tean
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimene on imetaja; Inimene ja koer on sarnased; Inimene ja inimahvid on samuti sarnased; Ma tean, et …
Task examples: Millised inimahvid elavad Aasias?; Inimesele kõige lähedasemad loomad on ...

## Inimese põlvnemine
URL: https://www.opiq.ee/kit/480/chapter/28434
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.13
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, inimese, põlvnemine, kujunenud, pika, jooksul, muutunud, eripära
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimese põlvnemine; Elu on kujunenud pika aja jooksul; Inimene on muutunud; Inimese eripära; Lisa. Inimeste suhe loodusega; Ma tean, et …
Task examples: Mida võib teada saada vanu luid uurides?; Mis eristab inimest teistest loomadest?

## Tugi- ja liikumis­elundkond
URL: https://www.opiq.ee/kit/480/chapter/28423
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.2
Topics ET: loodusõpetus, tugi, liikumis, elundkond, luud, luustik, lihased, lisa, röntgen
Topics RU: природоведение
Topics EN: science
Headings: Tugi- ja liikumis­elundkond; Luud ja luustik; Lihased; Lisa. Röntgen; Mõisted; Ma tean, et …
Task examples: Millised on luustiku ülesanded?; Millised laused käivad tahtele allumatute lihaste kohta?

## Vereringe­elundkond
URL: https://www.opiq.ee/kit/480/chapter/28424
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.3
Topics ET: loodusõpetus, vereringe, elundkond, veri, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Vereringe­elundkond; Vereringe; Veri; Mõisted; Ma tean, et …
Task examples: Millised on vererakkude ülesanded?

## Hingamis­elundkond
URL: https://www.opiq.ee/kit/480/chapter/28425
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.4
Topics ET: loodusõpetus, hingamis, elundkond, miks, hingame, hingamise, ajal, toimub, lisa
Topics RU: природоведение
Topics EN: science
Headings: Hingamis­elundkond; Miks me hingame?; Mis hingamise ajal toimub?; Lisa. Suitsetamine; Mõisted; Ma tean, et …
Task examples: Millised on hingamiselundkonna ülesanded?

## Seede­elundkond
URL: https://www.opiq.ee/kit/480/chapter/28426
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.5
Topics ET: loodusõpetus, seede, elundkond, mida, teevad, elundid, kuidas, käib, seedimine
Topics RU: природоведение
Topics EN: science
Headings: Seede­elundkond; Mida teevad seede­elundid?; Kuidas käib seedimine?; Toidu teekond kehas; Mõisted; Ma tean, et …
Task examples: Milline on seedeelundkonna ülesanne?; Kus toitu seeditakse?

## Eritus­elundkond. Jääkainetest vabanemine
URL: https://www.opiq.ee/kit/480/chapter/28427
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.6
Topics ET: loodusõpetus, eritus, elundkond, jääkainetest, vabanemine, mida, teevad, elundid, nahk
Topics RU: природоведение
Topics EN: science
Headings: Eritus­elundkond. Jääkainetest vabanemine; Mida teevad eritus­elundid?; Nahk ja kopsud; Soolestiku roll; Lisa. Bakterid soolestikus; Mõisted; Ma tean, et …
Task examples: Milline on erituselundkonna ülesanne?; Millistest jääkainetest aitavad kopsud vabaneda?

## Sugu­elundkond
URL: https://www.opiq.ee/kit/480/chapter/28428
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.7
Topics ET: loodusõpetus, sugu, elundkond, suguelundkonna, eripära, seemnerakud, lisa, iseeneslik, seemnepurse, munarakud
Topics RU: природоведение
Topics EN: science
Headings: Sugu­elundkond; Suguelundkonna eripära; Seemnerakud; Lisa. Mis on iseeneslik seemnepurse?; Munarakud; Uue elu algus; Lisa. Kondoom; Kuidas loode toitu ja hapnikku saab?; Mis juhtub, kui munarakk ei viljastu?; Mõisted; Ma tean, et …
Task examples: Millises suguelundis areneb loode?; Munaraku ja seemneraku ühinemist nimetatakse ...

## Närvisüsteem. Näärmed
URL: https://www.opiq.ee/kit/480/chapter/28429
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.8
Topics ET: loodusõpetus, närvisüsteem, näärmed, peaaju, seljaaju, mõisted, tean
Topics RU: природоведение
Topics EN: science
Headings: Närvisüsteem. Näärmed; Närvisüsteem; Peaaju ja seljaaju; Näärmed; Mõisted; Ma tean, et …
Task examples: Millised elundid kuuluvad närvisüsteemi?; Milline on närvisüsteemi ülesanne?

## Nahk
URL: https://www.opiq.ee/kit/480/chapter/28430
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 4.9
Topics ET: loodusõpetus, nahk, naha, mitu, ülesannet, meeleelund, lisa, kuidas, pimedad
Topics RU: природоведение
Topics EN: science
Headings: Nahk; Naha mitu ülesannet; Nahk on ka meeleelund; Lisa. Kuidas pimedad loevad?; Uuri!; Mõisted; Ma tean, et …
Task examples: Millised on naha ülesanded?; Millist infot saad naha kaudu?

## Mõisted
URL: https://www.opiq.ee/kit/480/chapter/26397
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 5.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Impressum
URL: https://www.opiq.ee/kit/480/chapter/26398
Book: Loodusõpetus 4. klassile (2023) – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_(2023)
Chapter ID: 5.2
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum

## Loodusõpetus 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/108
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 57
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Loodusõpetus 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/108
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 124
Topics ET: loodusõpetus, loodus, keskkond, klassile, opiq
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment

## Maailmaruum
URL: https://www.opiq.ee/kit/108/chapter/5197
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 1.1
Topics ET: loodusõpetus, maailmaruum
Topics RU: природоведение
Topics EN: science
Headings: Maailmaruum

## Tähistaevas ja tähtkujud
URL: https://www.opiq.ee/kit/108/chapter/5194
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 1.2
Topics ET: loodusõpetus, tähistaevas, tähtkujud, mitu, tähte, taevas, tähed, suur, vanker, kuidas
Topics RU: природоведение
Topics EN: science
Headings: Tähistaevas ja tähtkujud; Mitu tähte on taevas?; Mis on tähed?; Tähtkujud; Suur Vanker; Kuidas määrata öösel ilmakaari?; 1/2 Kuidas leida Põhjanaela?; 2/2 Kuidas leida Põhjanaela?; Põhjanaela leidmine; Põhjataevas sügisel ja kevadel; Pean meeles; Küsimusi ja ülesandeid; Tähtede suurus; Kui kaugel maapinnast?; Tõene või väär?; Täida lüngad; Edasimõtlemiseks ja uurimiseks

## Linnutee
URL: https://www.opiq.ee/kit/108/chapter/5195
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 1.3
Topics ET: loodusõpetus, linnutee, galaktikad, galaktika, suur, valgusaasta, praktiline, kuidas, joonistada, spiraali
Topics RU: природоведение
Topics EN: science
Headings: Linnutee; Galaktikad; Linnutee galaktika; Kui suur on Linnutee galaktika?; Mis on valgusaasta?; Praktiline töö; Kuidas joonistada spiraali?; Pean meeles; Küsimusi ja ülesandeid; Tähtede rühmad; Millise kujuga on Linnutee galaktika?; Kuidas paikneb Maa Galaktikas?; Valgusaasta 1; Valgusaasta 2; Valgusaasta 3; Edasimõtlemiseks ja uurimiseks

## Maailmaruumi uurimine
URL: https://www.opiq.ee/kit/108/chapter/5196
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 1.4
Topics ET: loodusõpetus, maailmaruumi, uurimine, silpmõistatus, pean, meeles, küsimusi, ülesandeid, teise, sõnaga
Topics RU: природоведение
Topics EN: science
Headings: Maailmaruumi uurimine; Silpmõistatus; Pean meeles; Küsimusi ja ülesandeid; Teise sõnaga; Järjesta; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte
URL: https://www.opiq.ee/kit/108/chapter/5198
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 1.5
Topics ET: loodusõpetus, kokkuvõte, kordamisküsimused, test, tõene, väär, millised, neist, taevakehad, suure
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte; Kordamisküsimused; Test; 1. Tõene või väär?; 2. Millised neist on taevakehad?; 3. Suure Vankri tähed; 4. Põhjanael

## Mõisted
URL: https://www.opiq.ee/kit/108/chapter/6536
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 10.1
Topics ET: loodusõpetus, mõisted
Topics RU: природоведение
Topics EN: science
Headings: Mõisted

## Päikesesüsteem
URL: https://www.opiq.ee/kit/108/chapter/5204
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.1
Topics ET: loodusõpetus, päikesesüsteem
Topics RU: природоведение
Topics EN: science
Headings: Päikesesüsteem

## Päike
URL: https://www.opiq.ee/kit/108/chapter/5199
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.2
Topics ET: loodusõpetus, päike, maale, lähim, täht, kuidas, mõõta, päikese, temperatuuri, kõige
Topics RU: природоведение
Topics EN: science
Headings: Päike; Päike on Maale lähim täht; Kuidas mõõta Päikese temperatuuri; Kõige kuumemad ja külmemad tähed; Pean meeles; Küsimusi ja ülesandeid; Millise kujuga on Päike?; Süte temperatuur; Tõene või väär?; Päikese näiv suurus

## Planeedid ja nende kaaslased
URL: https://www.opiq.ee/kit/108/chapter/5200
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.3
Topics ET: loodusõpetus, planeedid, nende, kaaslased, päikese, ümber, tiirlevad, päikesesüsteemi, kaheksa, planeeti
Topics RU: природоведение
Topics EN: science
Headings: Planeedid ja nende kaaslased; Päikese ümber tiirlevad planeedid; Päikesesüsteemi kaheksa planeeti; Üheksas planeet?; Planeetide kaaslased; Pean meeles; Küsimusi ja ülesandeid; Mitu planeeti on Päikesesüsteemis?; Kuidas on võimalik planeete näha?; Järjesta planeedid alates Päikesest.; Planeetide nimed; Edasimõtlemiseks ja uurimiseks

## Planeet Maa
URL: https://www.opiq.ee/kit/108/chapter/5201
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.4
Topics ET: loodusõpetus, planeet, tiirleb, ümber, päikese, miks, tunne, kuidas, kihutab, pöörleb
Topics RU: природоведение
Topics EN: science
Headings: Planeet Maa; Maa tiirleb ümber Päikese; Miks me ei tunne, kuidas Maa ümber Päikese kihutab?; Maa pöörleb ümber oma telje; Praktiline töö: öö ja päeva vaheldumine; Pean meeles; Küsimusi ja ülesandeid; Mitmes planeet?; Maa liikumine; Päike ja Maa; Ajaühikud; Taevakehad; Edasimõtlemiseks ja uurimiseks

## Maa kaaslane Kuu
URL: https://www.opiq.ee/kit/108/chapter/5202
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.5
Topics ET: loodusõpetus, korrutamine, korruta, korrutis, korda, võrdlemine, võrdle, suurem, väiksem, kordamine, harjutan, kaaslane, maast, mitu, praktiline, suurust, maaga
Topics RU: природоведение, умножение, умножь, произведение, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: science, multiplication, multiply, product, comparison, compare, greater, less, revision, review, practice
Headings: Maa kaaslane Kuu; Kuu on Maast mitu korda väiksem; Praktiline töö; Võrdle Kuu suurust Maaga; Kuu tiirleb ümber Maa; Miks on Kuu alati sama küljega Maa poole; Mängime Maad ja Kuud; Pean meeles; Küsimusi ja ülesandeid; Kuu näiv suurus; Ajaühikud; Sama küljega; Kuu ja Päikese suurus; Edasimõtlemiseks ja uurimiseks

## Kuusirp, poolkuu ja täiskuu
URL: https://www.opiq.ee/kit/108/chapter/5203
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.6
Topics ET: loodusõpetus, aeg, kell, kalender, kuusirp, poolkuu, täiskuu, miks, kuju, muudab, kasvav, kahanev, kuidas
Topics RU: природоведение, время, часы, календарь
Topics EN: science, time, clock, calendar
Headings: Kuusirp, poolkuu ja täiskuu; Miks Kuu oma kuju „muudab”; Kasvav ja kahanev Kuu; Kuidas tunda ära noorkuud?; Praktiline töö; Kuu ja kalender; Kuuvarjutus ja päikesevarjutus; Pean meeles; Küsimusi ja ülesandeid; Millal me Kuud ei näe?; Täiskuu; Kasvav Kuu; Kahanev Kuu; Edasimõtlemiseks ja uurimiseks

## Planeetide suurus ja kaugus Päikesest
URL: https://www.opiq.ee/kit/108/chapter/5205
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.7
Topics ET: loodusõpetus, planeetide, suurus, kaugus, päikesest, astronoomiline, ühik, kaugused, suuruste, mudel
Topics RU: природоведение
Topics EN: science
Headings: Planeetide suurus ja kaugus Päikesest; Astronoomiline ühik; Planeetide kaugus Päikesest; Planeetide kaugused; Planeetide suuruste mudel; Taevakehade suurus

## Kokkuvõte: Päikesesüsteem
URL: https://www.opiq.ee/kit/108/chapter/5206
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 2.8
Topics ET: loodusõpetus, arv, arvud, arvu, numbrid, kokkuvõte, päikesesüsteem, kordamisküsimused, test, mida, päike, kiirgab, päikese, temperatuur
Topics RU: природоведение, число, числа, цифры
Topics EN: science, number, numbers, digits
Headings: Kokkuvõte: Päikesesüsteem; Kordamisküsimused; Test; 1. Mida Päike kiirgab?; 2. Päikese temperatuur; 3. Planeetide arv; 4. Mis tiirlevad planeetide ümber?; 5. Mis moodustavad Päikesesüsteemi?; 6. Ajaühikud; 7. Kuidas liigub Kuu maailmaruumis?; 8. Taevakehade suurus; 9. Taevakehade liigitus

## Maa, gloobus ja kaardid
URL: https://www.opiq.ee/kit/108/chapter/5214
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.1
Topics ET: loodusõpetus, gloobus, kaardid, elupaiku, maal, fakte, maast, praktiline, alusta, mudeli
Topics RU: природоведение
Topics EN: science
Headings: Maa, gloobus ja kaardid; Elupaiku Maal; Fakte Maast; Praktiline töö; 1/2 Alusta Maa mudeli valmistamist; 2/2 Alusta Maa mudeli valmistamist

## Kokkuvõte: kaardid ja atlased
URL: https://www.opiq.ee/kit/108/chapter/6534
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.10
Topics ET: loodusõpetus, kokkuvõte, kaardid, atlased, kordamisküsimused, enesekontrolliks, ristsõna
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte: kaardid ja atlased; Kordamisküsimused; Enesekontrolliks; Ristsõna

## Maa kujutamine gloobusel
URL: https://www.opiq.ee/kit/108/chapter/5207
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.2
Topics ET: loodusõpetus, võrdlemine, võrdle, suurem, väiksem, kujutamine, gloobusel, tõendeid, kerakujulisusest, laevad, silmapiiril, gloobus, gloobust
Topics RU: природоведение, сравнение, сравни, больше, меньше
Topics EN: science, comparison, compare, greater, less
Headings: Maa kujutamine gloobusel; Tõendeid Maa kerakujulisusest; Laevad silmapiiril; Gloobus; Võrdle gloobust kui Maa mudelit Maaga.; Gloobuse ajaloost; Praktiline töö; 1/5 Jätka Maa mudeli valmistamist: telg; 2/5 Jätka Maa mudeli valmistamist: poolused; 3/5 Jätka Maa mudeli valmistamist: ekvaator; 4/5 Jätka Maa mudeli valmistamist: poolkerad; 5/5 Jätka Maa mudeli valmistamist: poolkerad; Greenwichi meridiaan; Miks pole kõik paigad Maal ühtviisi soojad?; Pean meeles; Küsimusi ja ülesandeid; Silpmõistatus; Joon gloobusel; Gloobuse osad; Edasimõtlemiseks ja uurimiseks

## Mandrid ja ookeanid
URL: https://www.opiq.ee/kit/108/chapter/5208
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.3
Topics ET: loodusõpetus, mandrid, ookeanid, praktiline, jätka, mudeli, valmistamist, euraasia, aafrika, põhja
Topics RU: природоведение
Topics EN: science
Headings: Mandrid ja ookeanid; Praktiline töö: mandrid; Jätka Maa mudeli valmistamist; Euraasia; Aafrika; Põhja-Ameerika; Lõuna-Ameerika; Antarktis; Austraalia; Mered; Mandrid kaardil; Ilmakaared; Maailmameri; Nelja ookeani vahel; Viies ookean?; Praktiline töö; Kui soolane on merevesi?; Praktiline töö: ookeanid; 1/4 Vaikne ookean; 2/4 Atlandi ookean; 3/4 India ookean; 4/4 Põhja-Jäämeri; Ookeanid kaardil; Pean meeles; Küsimusi ja ülesandeid; Mandrite suurus; Mandrid ja poolkerad; Millised mandrid ümbritsevad Vaikset ookeani?; Millised mandrid ümbritsevad Atlandi ookeani?; Millised mandrid ümbritsevad India ookeani?; Millised mandrid ümbritsevad Põhja-Jäämerd?; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte: Maa ja gloobus
URL: https://www.opiq.ee/kit/108/chapter/5215
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.4
Topics ET: loodusõpetus, kokkuvõte, gloobus, kordamisküsimused, test, suurim, manner, väikseim, ookean, vali
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte: Maa ja gloobus; Kordamisküsimused; Test; Suurim manner on...; Väikseim ookean on...; Vali lünkadesse sobivad sõnad.; Millised mandrid ümbritsevad India ookeani?; Vali õige vastus.

## Maa kujutamine kaardil
URL: https://www.opiq.ee/kit/108/chapter/5209
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.5
Topics ET: loodusõpetus, kujutamine, kaardil, kuidas, kujutatakse, maad, kaartidel, kaardi, osad, kõrguste
Topics RU: природоведение
Topics EN: science
Headings: Maa kujutamine kaardil; Kuidas kujutatakse Maad kaartidel; Kaardi osad; 1/2 Kõrguste ja sügavuste skaala; 2/2 Kõrguste ja sügavuste skaala; Praktiline töö; Leppemärgid; Kaardi mõõtkava; Mõõtkava; Moonutatud mandrid; 1/4 Moonutatud mandrid; 2/4 Moonutatud mandrid; 3/4 Moonutatud mandrid; 4/4 Moonutatud mandrid; Kuidas mõõta kõverjoont?; Tallinna ja Võru vahemaa; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Asukoha määramine kaardil ja gloobusel
URL: https://www.opiq.ee/kit/108/chapter/5210
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.6
Topics ET: loodusõpetus, asukoha, määramine, kaardil, gloobusel, kaardivõrk, praktiline, asukohad, ilmakaarte, pean
Topics RU: природоведение
Topics EN: science
Headings: Asukoha määramine kaardil ja gloobusel; Kaardivõrk; Asukoha määramine kaardil; Praktiline töö; Asukohad kaardil; Ilmakaarte määramine; Pean meeles; Küsimusi ja ülesandeid; Kaardivõrgu jooned; Ilmakaared kaardil

## Erinevad kaardid ja atlased
URL: https://www.opiq.ee/kit/108/chapter/5211
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.7
Topics ET: loodusõpetus, erinevad, kaardid, atlased, piirkondade, mitmeks, otstarbeks, kaartide, nimed, kuidas
Topics RU: природоведение
Topics EN: science
Headings: Erinevad kaardid ja atlased; Eri piirkondade kaardid; Kaardid mitmeks otstarbeks; Kaartide nimed; Kaardid eri otstarbeks; Kuidas jagunevad kaardid?; Eri mõõtkavaga kaardid; Atlased; Atlase register; Leia kohad Eestis; Maailma poolsaared; Pean meeles; Küsimusi ja ülesandeid; 1/3 Riigilipud; 2/3 Riigilipud; 3/3 Riigilipud; Edasimõtlemiseks ja uurimiseks

## Poliitiline kaart
URL: https://www.opiq.ee/kit/108/chapter/5212
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.8
Topics ET: loodusõpetus, poliitiline, kaart, riikide, kujutamine, kaardil, kellele, kuuluvad, saared, suurimad
Topics RU: природоведение
Topics EN: science
Headings: Poliitiline kaart; Riikide kujutamine kaardil; Kellele kuuluvad saared?; Suurimad riigid; Euroopa suurimad riigid; Pean meeles; Küsimusi ja ülesandeid; Maailma suurimad riigid; Edasimõtlemiseks ja uurimiseks

## Eesti asend
URL: https://www.opiq.ee/kit/108/chapter/5213
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 3.9
Topics ET: loodusõpetus, eesti, asend, geograafilise, asendi, iseloomustamine, teiste, riikide, suhtes, riigi
Topics RU: природоведение
Topics EN: science
Headings: Eesti asend; Geograafilise asendi iseloomustamine; Asend teiste riikide suhtes; Riigi piir; Eesti naabrid; Pean meeles; Küsimusi ja ülesandeid; 1/3 Mis riik?; 2/3 Mis riik?; 3/3 Mis riik?; Edasimõtlemiseks ja uurimiseks; 1/3 Naabrite naabrid; 2/3 Naabrite naabrid; 3/3 Naabrite naabrid

## Looduskatastroofid
URL: https://www.opiq.ee/kit/108/chapter/5219
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 4.1
Topics ET: loodusõpetus, looduskatastroofid
Topics RU: природоведение
Topics EN: science
Headings: Looduskatastroofid

## Maa siseehitus ja vulkaanipursked
URL: https://www.opiq.ee/kit/108/chapter/5216
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 4.2
Topics ET: loodusõpetus, siseehitus, vulkaanipursked, paks, maakoor, vulkaani, ehitus, osad, vulkaanipurse, krakatau
Topics RU: природоведение
Topics EN: science
Headings: Maa siseehitus ja vulkaanipursked; Maa siseehitus; Kui paks on maakoor?; Vulkaanipursked; Vulkaani ehitus; Vulkaani osad; Vulkaanipurse Krakatau saarel; Kuumaveeallikad ja geisrid; Pean meeles; Küsimusi ja ülesandeid; Vahevöö kivimid; Maa ehitus ja vulkaanid; Edasimõtlemiseks ja uurimiseks; Ideid esitluse koostamiseks; Kui ma oleksin vulkaan; Vulkaanid inimese teenistuses; Vaikse ookeani tulerõngas

## Maavärinad
URL: https://www.opiq.ee/kit/108/chapter/5217
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 4.3
Topics ET: loodusõpetus, maavärinad, põhjustab, maavärinaid, maavärinate, sagedus, tugevus, erineva, tugevusega, tagajärjed
Topics RU: природоведение
Topics EN: science
Headings: Maavärinad; Mis põhjustab maavärinaid?; Maavärinate sagedus ja tugevus; Erineva tugevusega maavärinate tagajärjed; Seismograaf; Pean meeles; Küsimusi ja ülesandeid; Maavärina iseloomustus; Kus esineb sagedamini maavärinaid?; Maavärina tugevus; Edasimõtlemiseks ja uurimiseks; Ideid esitluse koostamiseks; Tugev maavärin; Maavärinate ennustamine; Maavärinaohtlikud piirkonnad maailmas; Tsunamid; Maavärinaid taluvad hooned; Valmisolek maavärinaks; Maavärinad ja vulkaanid; Maavärinad Eestis

## Orkaanid ja üleujutused
URL: https://www.opiq.ee/kit/108/chapter/5218
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 4.4
Topics ET: loodusõpetus, orkaanid, üleujutused, orkaan, millisena, paistab, kosmosest, tekivad, soomaa, üleujutus
Topics RU: природоведение
Topics EN: science
Headings: Orkaanid ja üleujutused; Orkaan; Millisena paistab orkaan kosmosest?; Kus tekivad orkaanid?; Üleujutused; Soomaa üleujutus; Tromb ja vesipüks; Pean meeles; Küsimusi ja ülesandeid; 1/4 Arvuta; 2/4 Arvuta; 3/4 Arvuta; 4/4 Arvuta; Orkaani silm; Edasimõtlemiseks ja uurimiseks; Ideid esitluse koostamiseks; Suur üleujutus; Orkaanikütid; Orkaanide nimed; Orkaanihooaeg; Orkaanide kategooriad; Orkaanide ajalugu

## Kokkuvõte: looduskatastroofid
URL: https://www.opiq.ee/kit/108/chapter/5220
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 4.5
Topics ET: loodusõpetus, kokkuvõte, looduskatastroofid, kordamisküsimused, test, ehitus, vulkaanipurse, osad, millest, jutt
Topics RU: природоведение
Topics EN: science
Headings: Kokkuvõte: looduskatastroofid; Kordamisküsimused; Test; 1. Maa ehitus; 2. Vulkaanipurse; 3. Maa osad; 4. Millest on jutt?; 5. Millest on jutt?; 6. Millest on jutt?; 7. Üleujutused

## Kuidas koostada arvutiga esitlust
URL: https://www.opiq.ee/kit/108/chapter/6535
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 4.6
Topics ET: loodusõpetus, kuidas, koostada, arvutiga, esitlust, info, otsimine, internetist, esitluse, koosneb
Topics RU: природоведение
Topics EN: science
Headings: Kuidas koostada arvutiga esitlust; Info otsimine internetist; Esitluse koosneb järgmistest osadest; Millega arvestada esitlust koostades

## Elu mitmekesisus Maal
URL: https://www.opiq.ee/kit/108/chapter/5221
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, mitmekesisus, maal, ülesandeid, silpmõistatus
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Elu mitmekesisus Maal; Ülesandeid; Silpmõistatus; Taimed; Loomad

## Elu areng Maal
URL: https://www.opiq.ee/kit/108/chapter/5230
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.10
Topics ET: loodusõpetus, areng, maal, teke, oleks, aasta, vanune, pean, meeles, küsimusi
Topics RU: природоведение
Topics EN: science
Headings: Elu areng Maal; Elu teke ja areng; Kui Maa oleks ühe aasta vanune; Pean meeles; Küsimusi ja ülesandeid; Maa ja elu tekkimine; Kus tekkis elu?; Millised olid esimesed organismid?; Elu areng; Edasimõtlemiseks ja uurimiseks

## Dinosaurused
URL: https://www.opiq.ee/kit/108/chapter/5231
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.11
Topics ET: loodusõpetus, dinosaurused, olid, türannosaurus, brahhiosaurus, miks, välja, surid, kuidas, teame
Topics RU: природоведение
Topics EN: science
Headings: Dinosaurused; Kes olid dinosaurused?; Türannosaurus ja brahhiosaurus; Miks dinosaurused välja surid?; Kuidas me teame dinosaurustest?; Dinosauruste välimus; Pean meeles; Küsimusi ja ülesandeid; Dinosauruste hambad; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte: elu mitmekesisus
URL: https://www.opiq.ee/kit/108/chapter/5232
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.12
Topics ET: loodusõpetus, taim, taimed, puu, lill, kokkuvõte, mitmekesisus, kordamisküsimused, test, elurikkus, bakterid, fotosüntees, hingamine
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Kokkuvõte: elu mitmekesisus; Kordamisküsimused; Test; 1. Maa elurikkus; 2. Bakterid; 3. Fotosüntees ja hingamine; 4. Fotosüntees ja hingamine; 5. Taimed toituvad ja hingavad; 6. Elu areng

## Organismide rühmitamine
URL: https://www.opiq.ee/kit/108/chapter/5222
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.2
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, organismide, rühmitamine, viis, suurt, rühma, pean, meeles, küsimusi, ülesandeid
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects, human, body, senses, health
Headings: Organismide rühmitamine; Viis suurt organismide rühma; Pean meeles; Küsimusi ja ülesandeid; Inimene on ...; Puravik on ...; Linnud on ...; Puu on ...; Mesilane on ...; Kalad on ...; Hallitus on ...; Eesti koduloomad; Edasimõtlemiseks ja uurimiseks

## Mikroskoop
URL: https://www.opiq.ee/kit/108/chapter/5223
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.3
Topics ET: loodusõpetus, mikroskoop, mikroskoobi, osad, elektronmikroskoop, praktiline, valgusmikroskoobi, kasutamine, pean, meeles
Topics RU: природоведение
Topics EN: science
Headings: Mikroskoop; Mikroskoobi osad; Elektronmikroskoop; Praktiline töö; Valgusmikroskoobi kasutamine; Mikroskoobi kasutamine; Pean meeles; Küsimusi ja ülesandeid; Mikroskoobi kasutamise reeglid; Edasimõtlemiseks ja uurimiseks

## Ainuraksed organismid
URL: https://www.opiq.ee/kit/108/chapter/5224
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.4
Topics ET: loodusõpetus, ainuraksed, organismid, keda, leiame, tiigiveest, amööb, roheline, silmviburlane, kingloom
Topics RU: природоведение
Topics EN: science
Headings: Ainuraksed organismid; Keda leiame tiigiveest?; Amööb; Roheline silmviburlane; Kingloom; Mida ainuraksed teevad?; Ainuraksed; Praktiline töö; Heinaleotise vaatlemine; Pean meeles; Küsimusi ja ülesandeid; 1/3 Kas tunned tiigivees elavaid ainurakseid?; 2/3 Kas tunned tiigivees elavaid ainurakseid?; 3/3 Kas tunned tiigivees elavaid ainurakseid?; Edasimõtlemiseks ja uurimiseks

## Bakterid
URL: https://www.opiq.ee/kit/108/chapter/5225
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.5
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, bakterid, bakterite, tähtsus, looduses, inimese, organismis, millist, kasu, kahju
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Bakterid; Kes on bakterid?; Bakterite tähtsus looduses; Bakterid inimese organismis; Millist kasu või kahju saab inimene bakteritest?; Katk; Pean meeles; Küsimusi ja ülesandeid; Kus elavad bakterid?; Milliseid tingimusi vajavad bakterid eluks?; Edasimõtlemiseks ja uurimiseks

## Hulkraksed organismid
URL: https://www.opiq.ee/kit/108/chapter/5226
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.6
Topics ET: loodusõpetus, hulkraksed, organismid, mõtle, hoolega, kuidas, jaotatakse, organisme, praktiline, valmista
Topics RU: природоведение
Topics EN: science
Headings: Hulkraksed organismid; Hulkraksed; Mõtle hoolega!; Kuidas jaotatakse organisme?; Praktiline töö; Valmista raku mudel; Pean meeles; Küsimusi ja ülesandeid; Raku osad

## Organismide eluavaldused
URL: https://www.opiq.ee/kit/108/chapter/5227
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.7
Topics ET: loodusõpetus, organismide, eluavaldused, organismid, koosnevad, rakkudest, paljunevad, kasvavad, arenevad, konna
Topics RU: природоведение
Topics EN: science
Headings: Organismide eluavaldused; Organismid koosnevad rakkudest; Organismid paljunevad; Organismid kasvavad ja arenevad; Konna areng; Organismid toituvad ja hingavad; Organismid reageerivad keskkonnale; Pean meeles; Küsimusi ja ülesandeid; Silpmõistatus; Edasimõtlemiseks ja uurimiseks

## Toitumine
URL: https://www.opiq.ee/kit/108/chapter/5228
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.8
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, toitumine, millest, toituvad, millistest, ainetest, tekib, taimes, glükoos
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Toitumine; Millest taimed toituvad; Millistest ainetest tekib taimes glükoos?; Millest toituvad muud organismid; Kust saavad toitaineid taimed?; Kust saavad toitaineid loomad?; Van Helmonti katse; Praktiline töö; Hapniku teke fotosünteesil; Pean meeles; Küsimusi ja ülesandeid; Silpmõistatus; Edasimõtlemiseks ja uurimiseks

## Hingamine
URL: https://www.opiq.ee/kit/108/chapter/5229
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 5.9
Topics ET: loodusõpetus, taim, taimed, puu, lill, inimene, keha, meeled, tervis, hingamine, millega, hingab, kala, amööb, kana, jõevähk, kingloom
Topics RU: природоведение, растение, растения, дерево, цветок, человек, тело, чувства, здоровье
Topics EN: science, plant, plants, tree, flower, human, body, senses, health
Headings: Hingamine; Mis on hingamine?; 1/9 Millega hingab inimene?; 2/9 Millega hingab kala?; 3/9 Millega hingab amööb?; 4/9 Millega hingab kana?; 5/9 Millega hingab jõevähk?; 6/9 Millega hingab kingloom?; 7/9 Millega hingab kass?; 8/9 Millega hingab haug?; 9/9 Millega hingab vihmauss?; Ka taimed hingavad; Milliseid gaase võtab taim õhust?; Pean meeles; Küsimusi ja ülesandeid; Silpmõistatus; Miks paneb jooksmine hingeldama?; Edasimõtlemiseks ja uurimiseks

## Elu erinevates keskkonnatingimustes
URL: https://www.opiq.ee/kit/108/chapter/5238
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 6.1
Topics ET: loodusõpetus, erinevates, keskkonnatingimustes, maailmas, milline, täna, õhutemperatuur, maakera, kohtades
Topics RU: природоведение
Topics EN: science
Headings: Elu erinevates keskkonnatingimustes; Ilm maailmas; Milline on täna õhutemperatuur maakera eri kohtades?

## Polaaralad
URL: https://www.opiq.ee/kit/108/chapter/5233
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 6.2
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, polaaralad, elutingimused, polaaraladel, temperatuur, arktikas, kuidas, nimetatakse, neid, alasid
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Polaaralad; Elutingimused polaaraladel; Temperatuur Arktikas; Kuidas nimetatakse neid alasid?; Polaaralade loomad; Linnulaat; Fantaasiareis Arktikasse; Planeeri reis Arktikasse; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kõrb
URL: https://www.opiq.ee/kit/108/chapter/5234
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 6.3
Topics ET: loodusõpetus, kõrb, elutingimused, kõrbes, tõene, väär, kõrbeloomad, loomade, kohastumused, kõrbetaimed
Topics RU: природоведение
Topics EN: science
Headings: Kõrb; Elutingimused kõrbes; Tõene või väär?; Kõrbeloomad; Loomade kohastumused; Kõrbetaimed; Rändkarjakasvatajad; Oaasid; Inimeste mõju kõrbetele; Pean meeles; Küsimusi ja ülesandeid; Samuum; Mis on samuum?; Mille järgi võib aru saada, et varsti algab samuum?; Kui kaua samuum kestab?; Edasimõtlemiseks ja uurimiseks

## Vihmametsad
URL: https://www.opiq.ee/kit/108/chapter/5235
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 6.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, vihmametsad, tingimused, vihmametsas, tõene, väär, inimesed, praktiline
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Vihmametsad; Tingimused vihmametsas; Ilm vihmametsas; Taimed vihmametsas; Tõene või väär?; Loomad vihmametsas; Inimesed vihmametsas; Praktiline töö; Vihmamets kodus; Päev troopilises vihmametsas; Kui pikk on vihmametsas päev?; Millal sajab vihmametsas vihma?; Pean meeles; Küsimusi ja ülesandeid

## Mäed
URL: https://www.opiq.ee/kit/108/chapter/5236
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 6.5
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, mäed, tingimused, mägedes, lumi, aafrikas, temperatuur, mäetipus, tõene
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Mäed; Tingimused mägedes; Lumi Aafrikas; Temperatuur mäetipus; Taimed mägedes; Tõene või väär?; Loomad mägedes; Mäestikuloomade kohastumused; Kõrgmäe tipus; Kes jutustab seda lugu?; Milline on temperatuur laagripaigas?; Milline on tuul?; Milline on taevas?; Milline on maapind?; Miks kannavad mägironijad hapnikumaski?; Mis on mägironimisel ohtlikum?; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte: elu erinevates keskkonnatingimustes
URL: https://www.opiq.ee/kit/108/chapter/5237
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 6.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, kokkuvõte, erinevates, keskkonnatingimustes, kordamisküsimused, test, sobiv, elupaik, polaaralade
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Kokkuvõte: elu erinevates keskkonnatingimustes; Kordamisküsimused; Test; 1. Sobiv elupaik; 2. Polaaralade loomad; 3. Polaaralade taimed; 4. Kõrbeloomade elu; 5. Oaasid; 6. Vihmametsade loomad; 7. Mäestikuloomad

## Inimene
URL: https://www.opiq.ee/kit/108/chapter/5239
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.1
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, koer, ainulaadne, muudab, sind, ainulaadseks, tunnused
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimene; Inimene ja koer; Iga inimene on ainulaadne; Mis muudab sind ainulaadseks?; Minu tunnused

## Inimese põlvnemine
URL: https://www.opiq.ee/kit/108/chapter/5248
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.10
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, inimese, põlvnemine, millisesse, loomarühma, kuulub, sarnasused, teiste, imetajatega
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimese põlvnemine; Millisesse loomarühma inimene kuulub?; Inimese sarnasused teiste imetajatega; Imetajate tunnused; Kuidas erineb inimene teistest imetajatest?; Kuidas ja miks?; Rassid; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte: inimene
URL: https://www.opiq.ee/kit/108/chapter/5249
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.11
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, kokkuvõte, kordamisküsimused, test, koosneb, millest, elund, elundid, milline
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Kokkuvõte: inimene; Kordamisküsimused; Test; 1. Mis koosneb millest?; 2. Mis elund?; 3. Mis elundid?; 4. Mis elund?; 5. Mis elund?; 6. Mis elund?; 7. Mis elund?; 8. Milline luustiku osa?

## Rakud ja koed
URL: https://www.opiq.ee/kit/108/chapter/5240
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.2
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, rakud, koed, koosneb, rakkudest, tüüpi, rakke, moodustavad, kudesid
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Rakud ja koed; Keha koosneb rakkudest; 1/6 Eri tüüpi rakke; 2/6 Eri tüüpi rakke; 3/6 Eri tüüpi rakke; 4/6 Eri tüüpi rakke; 5/6 Eri tüüpi rakke; 6/6 Eri tüüpi rakke; Rakud moodustavad kudesid; Miks moodustavad rakud kudesid?; Kudede ülesanded; Veri on vedel kude; Praktiline töö; Suuõõne sisepinna rakkude vaatlemine; Pean meeles; Küsimusi ja ülesandeid; Sarnasused ja erinevused; Edasimõtlemiseks ja uurimiseks

## Elundid ja elundkonnad
URL: https://www.opiq.ee/kit/108/chapter/5241
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.3
Topics ET: loodusõpetus, elundid, elundkonnad, inimese, elundeid, koosnevad, kudedest, elundkondade, katte
Topics RU: природоведение
Topics EN: science
Headings: Elundid ja elundkonnad; Elundid; Inimese elundeid; Elundid koosnevad kudedest; Elundkonnad; Elundkondade ülesanded; Katte-, tugi- ja liikumiselundkond; Vereringe-, hingamis- ja seedeelundkond; Närvisüsteem; Näärmed; Erituselundkond; Suguelundkond; Elundite ülesandeid; Millistest elunditest elundkonnad koosnevad; Pean meeles; Küsimusi ja ülesandeid; Rühmita elundid elundkondadesse.; Edasimõtlemiseks ja uurimiseks

## Nahk, luustik ja lihased
URL: https://www.opiq.ee/kit/108/chapter/5242
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.4
Topics ET: loodusõpetus, nahk, luustik, lihased, naha, ehitus, küünte, juuste, eest, hoolitsemine
Topics RU: природоведение
Topics EN: science
Headings: Nahk, luustik ja lihased; Nahk; Naha ehitus; Naha, küünte ja juuste eest hoolitsemine; Sõrmejälgede võtmine; Luustik; Liigesed; Lihased; Testi oma lihaseid; Pean meeles; Küsimusi ja ülesandeid; Naha ülesanded; Edasimõtlemiseks ja uurimiseks

## Süda, veresooned ja kopsud
URL: https://www.opiq.ee/kit/108/chapter/5243
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.5
Topics ET: loodusõpetus, mõõtmine, mõõtühik, pikkus, mass, maht, süda, veresooned, kopsud, pulss, praktiline, pulsi, hingamine, hingamiselundkonna
Topics RU: природоведение, измерение, единица измерения, длина, масса, объём
Topics EN: science, measurement, unit, length, mass, volume
Headings: Süda, veresooned ja kopsud; Süda; Pulss; Praktiline töö; Pulsi mõõtmine; Hingamine; Hingamiselundkonna ülesanded; Valmista kopsude mudel; Mõõda oma kopsumahtu; Kopsumaht; Pean meeles; Küsimusi ja ülesandeid; Täida lüngad; Edasimõtlemiseks ja uurimiseks

## Seedimine ja eritamine
URL: https://www.opiq.ee/kit/108/chapter/5244
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.6
Topics ET: loodusõpetus, seedimine, eritamine, seedeelundid, seedekanali, elundid, hambad, hammaste, liigid, need
Topics RU: природоведение
Topics EN: science
Headings: Seedimine ja eritamine; Seedeelundid; Seedekanali elundid; Hambad; 1/3 Hammaste liigid; 2/3 Mis hambad need on?; 3/3 Mis hambad need on?; Toiduvajadus; Tõene või väär?; Eritamine; Erituselundid; Pean meeles; Küsimusi ja ülesandeid; Mida eritavad järgmised elundid?; Edasimõtlemiseks ja uurimiseks

## Närvisüsteem ja meeleelundid
URL: https://www.opiq.ee/kit/108/chapter/5245
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.7
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, närvisüsteem, meeleelundid, ärrituse, liikumine, kehas, peaaju, nägemine, silmavärvi, uuring
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Närvisüsteem ja meeleelundid; Närvisüsteem; Ärrituse liikumine kehas; Peaaju; Meeleelundid; Nägemine; Silmavärvi uuring; Proovi järele!; Kuulmine ja tasakaal; Maitsmine, haistmine, kompimine; Pean meeles; Küsimusi ja ülesandeid; Meeled ja meeleelundid; Edasimõtlemiseks ja uurimiseks; Lillade ringide illusioon

## Hormoonid ja suguelundid
URL: https://www.opiq.ee/kit/108/chapter/5246
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.8
Topics ET: loodusõpetus, hormoonid, suguelundid, naiste, meeste, näärmed, mehe, naise, ühemuna, kahemunakaksikud
Topics RU: природоведение
Topics EN: science
Headings: Hormoonid ja suguelundid; Hormoonid; Naiste ja meeste näärmed; Mehe ja naise suguelundid; Ühemuna- ja kahemunakaksikud; Pean meeles; Küsimusi ja ülesandeid; Hormoone tootvad näärmed; Edasimõtlemiseks ja uurimiseks

## Organismi terviklikkus ja tervislikud eluviisid
URL: https://www.opiq.ee/kit/108/chapter/5247
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 7.9
Topics ET: loodusõpetus, organismi, terviklikkus, tervislikud, eluviisid, organism, tervik, menüü, koostamine, päevaplaani
Topics RU: природоведение
Topics EN: science
Headings: Organismi terviklikkus ja tervislikud eluviisid; Organism on tervik; Organismi terviklikkus; Tervislikud eluviisid; Menüü koostamine; Päevaplaani koostamine; Hambaarsti soovitused; Pean meeles; Küsimusi ja ülesandeid; Edasimõtlemiseks ja uurimiseks; Külm ja palav

## Inimene sõltub loodusest
URL: https://www.opiq.ee/kit/108/chapter/5254
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 8.1
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, sõltub, loodusest
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Inimene sõltub loodusest

## Taimed inimese kasutuses
URL: https://www.opiq.ee/kit/108/chapter/5250
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 8.2
Topics ET: loodusõpetus, taim, taimed, puu, lill, inimene, keha, meeled, tervis, inimese, kasutuses, mõistatusi, taimedest, milleks, kasutab, taimi
Topics RU: природоведение, растение, растения, дерево, цветок, человек, тело, чувства, здоровье
Topics EN: science, plant, plants, tree, flower, human, body, senses, health
Headings: Taimed inimese kasutuses; Mõistatusi taimedest; Milleks kasutab inimene taimi?; Silpmõistatus; Põllutaimed; Taimede söödavad osad; Õied; Viljad; Lehed; Varred; Juured; Milleks kasutatakse kartulit?; Mida saame männist?; Pean meeles; Küsimusi ja ülesandeid; 1/6 Taimede söödavad osad; 2/6 Taimede söödavad osad; 3/6 Taimede söödavad osad; 4/6 Taimede söödavad osad; 5/6 Taimede söödavad osad; 6/6 Taimede söödavad osad; Edasimõtlemiseks ja uurimiseks

## Loomad inimese kasutuses
URL: https://www.opiq.ee/kit/108/chapter/5251
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 8.3
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, inimese, kasutuses, miks, hakati, loomi, kodustama, silpmõistatus, mida
Topics RU: природоведение, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье
Topics EN: science, animal, animals, birds, insects, human, body, senses, health
Headings: Loomad inimese kasutuses; Miks hakati loomi kodustama?; Silpmõistatus; Mida saame loomadelt?; Mida saab inimene lehmalt?; Mida saab inimene sealt?; Milleks kasutab inimene hobust?; Mida saame putukatelt?; Loomakasvatuse probleemid; Pean meeles; Küsimusi ja ülesandeid; Koerte ülesanded; Edasimõtlemiseks ja uurimiseks

## Seened inimese kasutuses
URL: https://www.opiq.ee/kit/108/chapter/5252
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 8.4
Topics ET: loodusõpetus, seened, inimese, kasutuses, söögiseened, söödavad, mürgised, silpmõistatus, seenekasvatus, söödav
Topics RU: природоведение
Topics EN: science
Headings: Seened inimese kasutuses; Söögiseened; Söödavad seened; Mürgised seened; Silpmõistatus; Seenekasvatus; Söödav või mürgine?; Pärmseened; Leiva ja saia tegemine; Praktiline töö; Pärmitainas; Hallitusseened; Antibiootikumid; Millist kahju põhjustavad seened?; Pean meeles; Küsimusi ja ülesandeid; Seente kasutamine; Edasimõtlemiseks ja uurimiseks

## Bakterid inimese kasutuses
URL: https://www.opiq.ee/kit/108/chapter/5253
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 8.5
Topics ET: loodusõpetus, bakterid, inimese, kasutuses, bakterite, kasutamine, kompost, haigustekitajad, milliseid, haigusi
Topics RU: природоведение
Topics EN: science
Headings: Bakterid inimese kasutuses; Bakterite kasutamine; Mis on kompost?; Haigustekitajad; Milliseid haigusi põhjustavad bakterid?; Pean meeles; Küsimusi ja ülesandeid; Piimhappebakterite kasutamine; Edasimõtlemiseks ja uurimiseks

## Kokkuvõte: taimed, loomad, seened ja bakterid inimese kasutuses
URL: https://www.opiq.ee/kit/108/chapter/5255
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 8.6
Topics ET: loodusõpetus, taim, taimed, puu, lill, loom, loomad, linnud, putukad, kokkuvõte, seened, bakterid, inimese, kasutuses, kordamisküsimused, test
Topics RU: природоведение, растение, растения, дерево, цветок, животное, животные, птицы, насекомые
Topics EN: science, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Kokkuvõte: taimed, loomad, seened ja bakterid inimese kasutuses; Kordamisküsimused; Test; 1. Taime söödavad osad; 2. Esimene koduloom; 3. Mida saame loomadelt?; 4. Pärmitainas; 5. Mis seened?; 6. Bakterid

## Puu vaatlus eri aastaaegadel
URL: https://www.opiq.ee/kit/108/chapter/5256
Book: Loodusõpetus 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: loodusõpetus_4._klassile_2
Chapter ID: 9.1
Topics ET: loodusõpetus, taim, taimed, puu, lill, vaatlus, aastaaegadel, vaatlused, vaatluskord, üleriigilised, loodusvaatlused, osale, üleriigilistes, loodusvaatlustes
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Puu vaatlus eri aastaaegadel; Vaatlused; Vaatluskord 1; Vaatluskord 2; Vaatluskord 3; Üleriigilised loodusvaatlused; Osale ka üleriigilistes loodusvaatlustes

## Природо­ведение 4 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/228
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 177
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение, класс
Topics EN: mathematics

## Природо­ведение 4 класс – Opiq
URL: https://www.opiq.ee/Kit/Details/228
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 244
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение, класс
Topics EN: mathematics

## Вселенная
URL: https://www.opiq.ee/kit/228/chapter/12992
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, вселенная
Topics EN: mathematics
Headings: Вселенная

## Звездное небо и созвездия
URL: https://www.opiq.ee/kit/228/chapter/12989
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, звездное, небо, созвездия, сколько, небе, звезд, такое, звезды, большая
Topics EN: mathematics
Headings: Звездное небо и созвездия; Сколько на небе звезд; Что такое звезды?; Созвездия; Большая Медведица; Как ночью определить стороны света?; Как найти Полярную звезду; Небо в Северном полушарии осенью и весной; ЗАПОМНИ; Вопросы и задания; Заполни пропуски; Размер звезд; На каком расстоянии от поверхности Земли?; Верно или неверно?; Размышляй и исследуй!; Зодиак

## Млечный Путь
URL: https://www.opiq.ee/kit/228/chapter/12990
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 1.3
Topics ET: matemaatika
Topics RU: математика, млечный, путь, галактики, галактика, насколько, велика, такое, световой, практическая
Topics EN: mathematics
Headings: Млечный Путь; Галактики; Галактика Млечный Путь; Насколько велика галактика Млечный Путь?; Что такое световой год?; Практическая работа; Как нарисовать спираль?; Запомни; Вопросы и задания; Световой год 3; Группы звезд; Какую форму имеет галактика Млечный Путь?; Где в Галактике расположена Земля?; Световой год 1; Световой год 2; Размышляй и исследуй!

## Что такое Вселенная?
URL: https://www.opiq.ee/kit/228/chapter/12991
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 1.4
Topics ET: matemaatika
Topics RU: математика, такое, вселенная, изучение, вселенной, запомни, вопросы, головоломка, выбери
Topics EN: mathematics
Headings: Что такое Вселенная?; Изучение Вселенной; Запомни; Вопросы и задания; Головоломка; Выбери правильный ответ; Расположи по порядку; Размышляй и исследуй!

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/12993
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 1.5
Topics ET: matemaatika
Topics RU: математика, заключение, вопросы, повторения, тест, полярная, звезда, верно, неверно, является
Topics EN: mathematics
Headings: В заключение; Вопросы для повторения; Тест; Полярная звезда; Верно или неверно?; Что является небесным телом?; Звезды созвездия Большой Медведицы

## Понятия
URL: https://www.opiq.ee/kit/228/chapter/13054
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 10.1
Topics ET: matemaatika
Topics RU: математика, понятия
Topics EN: mathematics
Headings: Понятия

## Солнечная система
URL: https://www.opiq.ee/kit/228/chapter/13000
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, солнечная, система
Topics EN: mathematics
Headings: Солнечная система

## Солнце
URL: https://www.opiq.ee/kit/228/chapter/12994
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, солнце, ближайшая, земле, звезда, измерить, температуру, солнца, самые, горячие
Topics EN: mathematics
Headings: Солнце; Солнце – это ближайшая к Земле звезда; Как измерить температуру Солнца?; Самые горячие и самые холодные звезды; Запомни; Вопросы и задания; Кажущийся размер Солнца; Какую форму имеет Солнце?; Температура углей; Верно или неверно?

## Планеты и их спутники
URL: https://www.opiq.ee/kit/228/chapter/12995
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика, планеты, спутники, обращающиеся, вокруг, солнца, обращаются, восемь, планет, девятая
Topics EN: mathematics
Headings: Планеты и их спутники; Планеты, обращающиеся вокруг Солнца; Вокруг Солнца обращаются восемь планет; Девятая планета?; Спутники планет; Запомни; Вопросы и задания; Как далеко от Солнца?; Сколько планет в Солнечной системе?; Как можно увидеть планеты?; Названия планет; Размышляй и исследуй!

## Планета Земля
URL: https://www.opiq.ee/kit/228/chapter/12996
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.4
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, планета, земля, обращается, вокруг, солнца, почему, чувствуем, вращается, своей
Topics EN: mathematics, time, clock, calendar
Headings: Планета Земля; Земля обращается вокруг Солнца; Почему мы не чувствуем, как Земля обращается вокруг Солнца?; Земля вращается вокруг своей оси; Смена дня и ночи; Запомни; Вопросы и задания; Земля и время; Какая по счету?; Движение Земли; Солнце и Земля; Небесные тела; Размышляй и исследуй!

## Спутник Земли – Луна
URL: https://www.opiq.ee/kit/228/chapter/12997
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.5
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem
Topics RU: математика, сравнение, сравни, больше, меньше, спутник, земли, луна, намного, практическая, работа, размеры
Topics EN: mathematics, comparison, compare, greater, less
Headings: Спутник Земли – Луна; Луна намного меньше Земли; Практическая работа; Сравни размеры Луны и Земли; Луна обращается вокруг Земли; Почему Луна всегда обращена к Земле одной и той же стороной; Поиграем в Землю и Луну; Запомни; Вопросы и задания; Одна и та же сторона; Кажущийся размер Луны; Единицы времени; Размеры Луны и Солнца; Размышляй и исследуй!

## Фазы Луны
URL: https://www.opiq.ee/kit/228/chapter/12998
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.6
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, фазы, луны, почему, луна, меняет, форму, растущая, убывающая, определить
Topics EN: mathematics, time, clock, calendar
Headings: Фазы Луны; Почему Луна «меняет» форму; Растущая и убывающая Луна; Как определить молодой месяц?; Практическая работа; Луна и календарь; Лунное затмение и солнечное затмение; Запомни; Вопросы и задания; Убывающая Луна; Когда мы не видим Луну?; Полная Луна; Растущая Луна; Размышляй и исследуй!

## Размеры планет и их расстояние от Солнца
URL: https://www.opiq.ee/kit/228/chapter/12999
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика, размеры, планет, расстояние, солнца, единица, между, планетами, солнцем
Topics EN: mathematics
Headings: Размеры планет и их расстояние от Солнца; Aстрономическая единица; Расстояние между планетами и Солнцем; Расстояния между планетами; Модель размеров планет; Размеры небесных тел

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13001
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, заключение, вопросы, повторения, тест, типы, небесных, излучает, солнце, температура
Topics EN: mathematics
Headings: В заключение; Вопросы для повторения; Тест; Типы небесных тел; Что излучает Солнце?; Температура Солнца; Количество планет; Что обращается вокруг планет?; Что составляет Солнечную систему?; Единицы времени; Как Луна движется во Вселенной?; Размер небесных тел

## Планета Земля, глобус и карты
URL: https://www.opiq.ee/kit/228/chapter/13009
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, планета, земля, глобус, карты, места, обитания, земле, факты, практическая
Topics EN: mathematics
Headings: Планета Земля, глобус и карты; Места обитания на Земле; Факты о Земле; Практическая работа; 2/2 Приступи к изготовлению модели Земли; 1/2 Изготовление модели Земли

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13011
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.10
Topics ET: matemaatika
Topics RU: математика, заключение, вопросы, повторения, самопроверки, кроссворд
Topics EN: mathematics
Headings: В заключение; Вопросы для повторения; Задание для самопроверки; Кроссворд

## Изображение Земли на глобусе
URL: https://www.opiq.ee/kit/228/chapter/13002
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem
Topics RU: математика, сравнение, сравни, больше, меньше, изображение, земли, глобусе, доказательства, шаро, образной, формы, корабли, линии
Topics EN: mathematics, comparison, compare, greater, less
Headings: Изображение Земли на глобусе; Доказательства шаро­образной формы Земли; Корабли на линии горизонта; Глобус; Сравнение глобуса и Земли; Первый глобус; Практическая работа; 5/5 Продолжи изготовление модели Земли: полюсы и полушария; 1/5 Продолжи изготовление модели Земли: полюсы и полушария; 2/5 Продолжи изготовление модели Земли: полюсы и полушария; 3/5 Продолжи изготовление модели Земли: полюсы и полушария; 4/5 Продолжи изготовление модели Земли: полюсы и полушария; Гринвичский меридиан; Почему всюду на Земле не может быть одинаково тепло?; Запомни; Вопросы и задания; Линия на глобусе; Головоломка; Части глобуса; Размышляй и исследуй!

## Материки и океаны
URL: https://www.opiq.ee/kit/228/chapter/13003
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, материки, океаны, практическая, работа, продолжи, изготовление, модели, земли, мировой
Topics EN: mathematics
Headings: Материки и океаны; Практическая работа: материки; Продолжи изготовление модели Земли; Мировой океан; Евразия; Африка; Северная Америка; Южная Америка; Антарктида; Австралия; Материки на карте; Стороны горизонта; Что такое Мировой океан?; Среди четырех океанов; Пятый океан?; Практическая работа; Соленость воды в Балтийском море и в океанах; 4/4 Северный Ледовитый океан; 1/4 Тихий океан; 2/4 Атлантический океан; 3/4 Индийский океан; Океаны на карте; Запомни; Вопросы и задания; Какие материки омывает Северный Ледовитый океан?; Величина материков; Материки и полушария; Какие материки омывает Тихий океан?; Какие материки омывает Атлантический океан?; Какие материки омывает Индийский океан?; Размышляй и исследуй!

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13010
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, заключение, вопросы, повторения, тест, выбери, правильный, ответ, самый, большой
Topics EN: mathematics
Headings: В заключение; Вопросы для повторения; Тест; Выбери правильный ответ; Самый большой материк – это...; Самый маленький океан – это...; С какими материками граничит Индийский океан?

## Изображение Земли на карте
URL: https://www.opiq.ee/kit/228/chapter/13004
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика, изображение, земли, карте, земля, изображается, картах, можно, прочитать, шкала
Topics EN: mathematics
Headings: Изображение Земли на карте; Как Земля изображается на картах; Что можно прочитать по карте?; 2/2 Шкала высот и глубин; 1/2 Шкала высот и глубин; Практическая работа; Условные знаки; Что такое масштаб?; Масштаб; Искаженные материки; 4/3 Попробуй сам составить карту мира.; 1/3 Попробуй сам составить карту мира.; 2/3 Попробуй сам составить карту мира.; 3/3 Попробуй сам составить карту мира.; Как измерить кривую линию?; Расстояние между Таллинном и Выру; Запомни; Вопросы и задания; Размышляй и исследуй!

## Определения место­нахождения на карте и на глобусе
URL: https://www.opiq.ee/kit/228/chapter/13005
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика, определения, место, нахождения, карте, глобусе, картографическая, сетка, определение, практическая
Topics EN: mathematics
Headings: Определения место­нахождения на карте и на глобусе; Картографическая сетка; ОПРЕДЕЛЕНИЕ МЕСТО­НАХОЖДЕНИЯ НА КАРТЕ; Практическая работа; Местоположение на карте; Определение сторон горизонта; Запомни; Вопросы и задания; Стороны горизонта на карте; Линии картографической сетки

## Различные карты и атласы
URL: https://www.opiq.ee/kit/228/chapter/13006
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.7
Topics ET: matemaatika
Topics RU: математика, различные, карты, атласы, различных, территорий, разного, назначения, различным, масштабом
Topics EN: mathematics
Headings: Различные карты и атласы; Карты различных территорий; Карты разного назначения; Карты с различным масштабом; Названия карт; Какими картами следует воспользоваться, чтобы получить ответы на данные вопросы?; Как подразделяются карты?; Атласы; Указатель географических названий; Полуострова в мире; Найди места в Эстонии; Запомни; Вопросы и задания; 3/3 Флаги государств; 1/3 Флаги государств; 2/3 Флаги государств; Размышляй и исследуй!

## Политическая карта
URL: https://www.opiq.ee/kit/228/chapter/13007
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика, политическая, карта, изображение, государств, карте, какому, государству, принадлежат, острова
Topics EN: mathematics
Headings: Политическая карта; Изображение государств на карте; Какому государству принадлежат острова?; Крупнейшие страны мира; Крупнейшие страны Европы; Запомни; Вопросы и задания; Размышляй и исследуй!

## Местоположение Эстонии
URL: https://www.opiq.ee/kit/228/chapter/13008
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 3.9
Topics ET: matemaatika
Topics RU: математика, местоположение, эстонии, характеристика, географического, положения, положение, относительно, других, стран
Topics EN: mathematics
Headings: Местоположение Эстонии; Характеристика географического положения; Положение относительно других стран; Граница государства; Соседи Эстонии; Запомни; Вопросы и задания; 3/3 Какое государство?; 1/3 Какое государство?; 2/3 Какое государство?; Размышляй и исследуй!; 3/3 Соседи соседей; 1/3 Соседи соседей; 2/3 Соседи соседей

## Природные катастрофы
URL: https://www.opiq.ee/kit/228/chapter/13015
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика, природные, катастрофы
Topics EN: mathematics
Headings: Природные катастрофы

## Внутреннее строение Земли и извержения вулканов
URL: https://www.opiq.ee/kit/228/chapter/13012
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, внутреннее, строение, земли, извержения, вулканов, земная, кора, какова, толщина
Topics EN: mathematics
Headings: Внутреннее строение Земли и извержения вулканов; Земная кора; Какова толщина земной коры?; Извержения вулканов; Строение вулкана; Извержение вулкана на острове Кракатау; Горячие источники и гейзеры; Запомни; Вопросы и задания; Строение Земли и вулканы; Внутреннее строение Земли; Горные породы мантии; Размышляй и исследуй!; Темы для презентаций; Если бы я был вулкан; Вулканы на службе у человека; Тихоокеанское вулканическое огненное кольцо

## Землетрясения
URL: https://www.opiq.ee/kit/228/chapter/13013
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика, землетрясения, почему, происходят, частота, сила, землетрясений, последствия, различной, силы
Topics EN: mathematics
Headings: Землетрясения; Почему происходят землетрясения?; Частота и сила землетрясений; Последствия землетрясений различной силы; Сейсмограф; Запомни; Вопросы и задания; Сила землетрясения; Описание землетрясения; Где чаще всего происходят землетрясения?; Размышляй и исследуй!; Темы для презентаций; Сильное землетрясение; Прогнозирование землетрясений; Сейсмоопасные районы в мире; Цунами; Сейсмоустойчивые здания; Готовность к землетрясениям; Землетрясения и вулканы; Землетрясения в Эстонии

## Ураганы и наводнения
URL: https://www.opiq.ee/kit/228/chapter/13014
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, ураганы, наводнения, ураган, выглядит, космоса, образуются, наводнение, соомаа, смерч
Topics EN: mathematics
Headings: Ураганы и наводнения; Ураган; Как выглядит ураган из космоса?; Где образуются ураганы?; Наводнения; Наводнение в Соомаа; Смерч и водяной смерч; Запомни; Вопросы и задания; 4/4 Вычисли; 1/4 Вычисли; 2/4 Вычисли; 3/4 Вычисли; Глаз урагана; Размышляй и исследуй!; Темы для презентаций; Охотники за ураганами; Имена ураганов; Сезон ураганов; Категории ураганов; История ураганов; Крупное наводнение

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13016
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, заключение, вопросы, повторения, тест, наводнения, строение, земли, извержение, вулкана
Topics EN: mathematics
Headings: В заключение; Вопросы для повторения; Тест; Наводнения; Строение Земли; Извержение вулкана; Части Земли; О каком явлении речь?

## Как подготовить презентацию на компьютере
URL: https://www.opiq.ee/kit/228/chapter/13017
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика, подготовить, презентацию, компьютере, поиск, информации, интернете, презентация, состоит, следующих
Topics EN: mathematics
Headings: Как подготовить презентацию на компьютере; Поиск информации в интернете; Презентация состоит из следующих частей; Что нужно учитывать при составлении презентации

## Многообразие жизни на Земле
URL: https://www.opiq.ee/kit/228/chapter/13018
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.1
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, многообразие, жизни, земле, головоломка
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Многообразие жизни на Земле; Задания; Головоломка; Растения; Животные

## Развитие жизни на Земле
URL: https://www.opiq.ee/kit/228/chapter/13027
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.10
Topics ET: matemaatika
Topics RU: математика, развитие, жизни, земле, возникновение, если, возраст, земли, равен, одному
Topics EN: mathematics
Headings: Развитие жизни на Земле; Возникновение и развитие жизни; Если бы возраст Земли был равен одному году; Запомни; Вопросы и задания; Какие организмы были первыми на Земле?; Почему жизнь не могла возникнуть сразу после образования Земли?; Где возникла жизнь?; Развитие жизни; Размышляй и исследуй!

## Динозавры
URL: https://www.opiq.ee/kit/228/chapter/13028
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.11
Topics ET: matemaatika
Topics RU: математика, динозавры, такие, тираннозавр, брахиозавр, почему, вымерли, откуда, знаем, выглядели
Topics EN: mathematics
Headings: Динозавры; Кто такие динозавры?; Тираннозавр и брахиозавр; Почему вымерли динозавры?; Откуда мы знаем, как выглядели динозавры?; Как выглядели динозавры; Запомни; Вопросы и задания; Зубы динозавров; Размышляй и исследуй!

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13029
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.12
Topics ET: matemaatika
Topics RU: математика, заключение, вопросы, повторения, тест, развитие, жизни, земле, многообразие, бактерии
Topics EN: mathematics
Headings: В заключение; Вопросы для повторения; Тест; Развитие жизни на Земле; Многообразие жизни на Земле; Бактерии; Фотосинтез и дыхание 1; Фотосинтез и дыхание 2; Питание и дыхание растений

## Классификация организмов
URL: https://www.opiq.ee/kit/228/chapter/13019
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.2
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье, классификация, организмов, пять, групп, запомни, вопросы, плесень
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects, human, body, senses, health
Headings: Классификация организмов; Пять групп организмов; Запомни; Вопросы и задания; Плесень – это ...; Человек – это ...; Боровик – это ...; Птицы – это ...; Дерево – это ...; Пчела – это ...; Рыбы – это ...; Домашние животные; Размышляй и исследуй!

## Микроскоп
URL: https://www.opiq.ee/kit/228/chapter/13020
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, микроскоп, строение, микроскопа, электронный, практическая, работа, использование, светового, пользоваться
Topics EN: mathematics
Headings: Микроскоп; Строение микроскопа; Электронный микроскоп; Практическая работа; Использование светового микроскопа; Как пользоваться микроскопом; Запомни; Вопросы и задания; Правила пользования микроскопом; Размышляй и исследуй!

## Одноклеточные организмы
URL: https://www.opiq.ee/kit/228/chapter/13021
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, одноклеточные, организмы, кого, можно, увидеть, воде, пруда, инфузория, туфелька
Topics EN: mathematics
Headings: Одноклеточные организмы; Кого можно увидеть в воде из пруда?; Инфузория туфелька; Амёба; Зеленый жгутиконосец; Как существуют одноклеточные?; Одноклеточные; Практическая работа; Травяной настой под микроскопом; Запомни; Вопросы и задания; 3/3 Какие одноклеточные живут в воде из пруда?; 1/3 Какие одноклеточные живут в воде из пруда?; 2/3 Какие одноклеточные живут в воде из пруда?; Размышляй и исследуй!

## Бактерии
URL: https://www.opiq.ee/kit/228/chapter/13022
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.5
Topics ET: matemaatika
Topics RU: математика, бактерии, такие, роль, бактерий, природе, организме, человека, какую, пользу
Topics EN: mathematics
Headings: Бактерии; Кто такие бактерии?; Роль бактерий в природе; Бактерии в организме человека; Какую пользу и какой вред приносят человеку бактерии?; Чума; Запомни; Вопросы и задания; Какие условия необходимы бактериям для жизни?; Где живут бактерии?; Размышляй и исследуй!

## Многоклеточные организмы
URL: https://www.opiq.ee/kit/228/chapter/13023
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.6
Topics ET: matemaatika
Topics RU: математика, многоклеточные, организмы, подумай, какие, бывают, практическая, работа, сделай, модель
Topics EN: mathematics
Headings: Многоклеточные организмы; Многоклеточные; Подумай!; Какие бывают организмы?; Практическая работа; Сделай модель клетки; Запомни; Вопросы и задания; Части клетки

## Признаки живых организмов
URL: https://www.opiq.ee/kit/228/chapter/13024
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.7
Topics ET: matemaatika
Topics RU: математика, признаки, живых, организмов, организмы, состоят, клеток, размножаются, растут, развиваются
Topics EN: mathematics
Headings: Признаки живых организмов; Организмы состоят из клеток; Организмы размножаются; Организмы растут и развиваются; Развитие лягушки; Организмы питаются и дышат; Организмы реагируют на окружающую среду; Запомни; Вопросы и задания; Головоломка; Размышляй и исследуй!

## Питание
URL: https://www.opiq.ee/kit/228/chapter/13025
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.8
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, питание, питаются, каких, веществ, растении, образуется, глюкоза, другие
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Питание; Чем питаются растения; Из каких веществ в растении образуется глюкоза?; Чем питаются другие организмы; Откуда животные получают питательные вещества?; Откуда растения получают питательные вещества?; Опыт Ван Гельмонта; Практическая работа; Образование кислорода в процессе фотосинтеза; Запомни; Вопросы и задания; Головоломка; Размышляй и исследуй!

## Дыхание
URL: https://www.opiq.ee/kit/228/chapter/13026
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 5.9
Topics ET: matemaatika, taim, taimed, puu, lill, inimene, keha, meeled, tervis
Topics RU: математика, растение, растения, дерево, цветок, человек, тело, чувства, здоровье, дыхание, такое, дышит, дождевой, червь, курица, речной, инфузория
Topics EN: mathematics, plant, plants, tree, flower, human, body, senses, health
Headings: Дыхание; Что такое дыхание?; 8/8 Чем дышит дождевой червь?; 1/8 Чем дышит человек?; 2/8 Чем дышит амёба?; 3/8 Чем дышит курица?; 4/8 Чем дышит речной рак?; 5/8 Чем дышит инфузория туфелька?; 6/8 Чем дышит кошка?; 7/8 Чем дышит щука?; Растения тоже дышат; Какие газы растение получает из воздуха?; Запомни; Вопросы и задания; Почему бег вызывает одышку?; Головоломка; Размышляй и исследуй!

## Жизнь в разных условиях окружающей среды
URL: https://www.opiq.ee/kit/228/chapter/13035
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, жизнь, разных, условиях, окружающей, среды, погода, мире, какая, сегодня
Topics EN: mathematics
Headings: Жизнь в разных условиях окружающей среды; Погода в мире; Какая сегодня температура воздуха в разных местах земного шара?

## Полярные зоны
URL: https://www.opiq.ee/kit/228/chapter/13030
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 6.2
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, полярные, зоны, условия, жизни, полярных, зонах, температура, арктике, называются
Topics EN: mathematics, animal, animals, birds, insects
Headings: Полярные зоны; Условия жизни в полярных зонах; Температура в Арктике; Как называются эти территории?; Животные Арктики; Птичий базар; Путешествие в Арктику; Отправляемся в Арктику!; Запомни; Вопросы и задания; Размышляй и исследуй!

## Пустыни
URL: https://www.opiq.ee/kit/228/chapter/13031
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 6.3
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, пустыни, условия, жизни, пустыне, погода, приспособились, скотоводы
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Пустыни; Условия жизни в пустыне; Погода в пустыне; Животные пустыни; Как животные приспособились к жизни в пустыне; Растения пустыни; Скотоводы-кочевники; Оазисы; Влияние человека на пустыни; Запомни; Вопросы и задания; Самум; Как долго длится самум?; Что такое самум?; По каким признакам можно узнать, что скоро начнется самум?; Размышляй и исследуй!

## Дождевые леса
URL: https://www.opiq.ee/kit/228/chapter/13032
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 6.4
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, дождевые, леса, природные, условия, дождевых, лесах, погода, дождевом, лесу
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Дождевые леса; Природные условия в дождевых лесах; Погода в дождевом лесу; Растения дождевых лесов; Верно или нет?; Животные дождевых лесов; Люди, живущие в дождевых лесах; Практическая работа; Дождевой лес на подоконнике; День в тропическом дождевом лесу; Как долго длится день в дождевом лесу?; Когда в дождевом лесу идет дождь?; Запомни; Вопросы и задания

## Горы
URL: https://www.opiq.ee/kit/228/chapter/13033
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 6.5
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, горы, природные, условия, горах, снег, африке, температура, вершине
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Горы; Природные условия в горах; Снег в Африке; Температура на вершине горы; Растения в горах; Верно или нет?; Животные в горах; Как животные приспособились к жизни в горах; На вершине горы; Что для альпинистов опаснее?; Кто рассказывает эту историю?; Какая температура была в том месте, где альпинисты разбили свой лагерь?; Какой ветер?; Какое небо?; Какая поверхность земли?; Почему альпинисты надевают кислородные маски?; Запомни; Вопросы и задания; Размышляй и исследуй

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13034
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 6.6
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, заключение, вопросы, повторения, тест, подходящее, место, жизни, полярной
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: В заключение; Вопросы для повторения; Тест; Животные гор; Подходящее место для жизни; Животные полярной зоны; Растения полярной зоны; Животные пустыни; Оазисы; Животные дождевого леса

## Человек
URL: https://www.opiq.ee/kit/228/chapter/13045
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.1
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, собака, каждый, уникален, делает, тебя, неповторимым, сравнению, другими
Topics EN: mathematics, human, body, senses, health
Headings: Человек; Человек и собака; Каждый человек уникален; Что делает тебя неповторимым по сравнению с другими людьми?; Мои признаки

## Происхождение человека
URL: https://www.opiq.ee/kit/228/chapter/13044
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.10
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, происхождение, человека, какой, группе, живой, природы, относится, похож
Topics EN: mathematics, human, body, senses, health
Headings: Происхождение человека; К какой группе живой природы относится человек?; В чем человек похож на других млекопитающих?; Признаки млекопитающих; Чем человек отличается от других млекопитающих?; Как и почему?; Расы; Запомни; Вопросы и задания; Размышляй и исследуй!

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13046
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.11
Topics ET: matemaatika
Topics RU: математика, заключение, вопросы, повторения, тест, какая, часть, скелета, чего, состоит
Topics EN: mathematics
Headings: В заключение; Вопросы для повторения; Тест; Какая это часть скелета?; Что из чего состоит?; Какой это орган?

## Клетки и ткани
URL: https://www.opiq.ee/kit/228/chapter/13036
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.2
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, клетки, ткани, состоит, клеток, различного, типа, образуют, почему
Topics EN: mathematics, human, body, senses, health
Headings: Клетки и ткани; Тело состоит из клеток; 6/6 Клетки различного типа; 1/6 Клетки различного типа; 2/6 Клетки различного типа; 3/6 Клетки различного типа; 4/6 Клетки различного типа; 5/6 Клетки различного типа; Клетки образуют ткани; Почему клетки образуют ткани?; Задачи тканей; Кровь – это жидкая ткань; Практическая работа; Клетки полости рта под микроскопом; Запомни; Вопросы и задания; Сходства и различия; Размышляй и исследуй!

## Органы и системы органов
URL: https://www.opiq.ee/kit/228/chapter/13037
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.3
Topics ET: matemaatika
Topics RU: математика, органы, системы, органов, человека, состоят, тканей, задачи, систем, система
Topics EN: mathematics
Headings: Органы и системы органов; Органы человека; Органы состоят из тканей; Системы органов; Задачи систем органов; Система органов размножения; Покровная и опорно-двигательная системы; Кровеносная, дыхательная и пищеварительная системы; Нервная система; Железы; Выделительная система; Задачи органов; Из каких органов состоят системы органов; Запомни; Вопросы и задания; Сгруппируй органы в системы органов; Размышляй и исследуй!

## Кожа, скелет и мышцы
URL: https://www.opiq.ee/kit/228/chapter/13038
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.4
Topics ET: matemaatika
Topics RU: математика, кожа, скелет, мышцы, строение, кожи, уход, кожей, волосами, ногтями
Topics EN: mathematics
Headings: Кожа, скелет и мышцы; Кожа; Строение кожи; Уход за кожей, волосами и ногтями; Исследуй свои отпечатки пальцев; Скелет; Суставы; Мышцы; Испытай сам; Запомни; Вопросы и задания; Какие задачи у кожи?; Размышляй и исследуй!

## Сердце, кровеносные сосуды и легкие
URL: https://www.opiq.ee/kit/228/chapter/13039
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.5
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, сердце, кровеносные, сосуды, легкие, пульс, пульса, запястье, дыхание
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Сердце, кровеносные сосуды и легкие; Сердце; Пульс; Измерение пульса на запястье; Измерение пульса; Дыхание; Какие задачи выполняют органы дыхания?; Изготовь модель легких; Измерь объем своих легких; Объем легких; Запомни; Вопросы и задания; Заполни пропуски; Размышляй и исследуй!

## Органы пищеварения и органы выделения
URL: https://www.opiq.ee/kit/228/chapter/13040
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.6
Topics ET: matemaatika
Topics RU: математика, органы, пищеварения, выделения, пищеварительной, системы, зубы, какие, виды, зубов
Topics EN: mathematics
Headings: Органы пищеварения и органы выделения; Органы пищеварения; Органы пищеварительной системы; Зубы; 3/3 Какие это зубы?; 1/3 Виды зубов; 2/3 Какие это зубы?; Потребность в пище; Верно или нет?; Выделение; Органы выделения; Запомни; Вопросы и задания; Что выделяют следующие органы?; Размышляй и исследуй!

## Нервная система и органы чувств
URL: https://www.opiq.ee/kit/228/chapter/13041
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.7
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, нервная, система, органы, чувств, распространение, раздражения, теле, головной, мозг
Topics EN: mathematics, human, body, senses, health
Headings: Нервная система и органы чувств; Нервная система; Распространение раздражения в теле; Головной мозг; Органы чувств; Зрение; Исследование цвета глаз; Проверь сам!; Слух и равновесие; Вкус, обоняние, осязание; Запомни; Вопросы и задания; Чувства и органы чувств; Размышляй и исследуй!; Оптическая иллюзия

## Гормоны и половые органы
URL: https://www.opiq.ee/kit/228/chapter/13042
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.8
Topics ET: matemaatika
Topics RU: математика, гормоны, половые, органы, железы, женщин, мужчин, мужские, женские, одно
Topics EN: mathematics
Headings: Гормоны и половые органы; Гормоны; Железы у женщин и мужчин; Мужские и женские половые органы; Одно- и двуяйцевые близнецы; Запомни; Вопросы и задания; Железы, вырабатывающие гормоны; Размышляй и исследуй!

## Целостность организма и здоровый образ жизни
URL: https://www.opiq.ee/kit/228/chapter/13043
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 7.9
Topics ET: matemaatika
Topics RU: математика, целостность, организма, здоровый, образ, жизни, организм, единое, целое, дневное
Topics EN: mathematics
Headings: Целостность организма и здоровый образ жизни; Организм – это единое целое; Целостность организма; Здоровый образ жизни; Дневное меню; Составление режима дня; Стоматологи советуют; Запомни; Вопросы и задания; Размышляй и исследуй!; Холодно и жарко

## Человек зависит от природы
URL: https://www.opiq.ee/kit/228/chapter/13051
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 8.1
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, зависит, природы
Topics EN: mathematics, human, body, senses, health
Headings: Человек зависит от природы

## Какую пользу приносят человеку растения?
URL: https://www.opiq.ee/kit/228/chapter/13047
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 8.2
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, какую, пользу, приносят, человеку, загадки, растениях, люди, используют
Topics EN: mathematics, plant, plants, tree, flower
Headings: Какую пользу приносят человеку растения?; Загадки о растениях; Как люди используют растения?; Головоломка; Полевые растения; Съедобные части растений; Корни; Цветок; Плоды; Листья; Стебли; Для чего используют картофель?; Что изготавливают из сосны?; Запомни; Вопросы и задания; 6/6 Съедобные части растений; 1/6 Съедобные части растений; 2/6 Съедобные части растений; 3/6 Съедобные части растений; 4/6 Съедобные части растений; 5/6 Съедобные части растений; Размышляй и исследуй!

## Какую пользу приносят человеку животные?
URL: https://www.opiq.ee/kit/228/chapter/13048
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 8.3
Topics ET: matemaatika, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis
Topics RU: математика, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье, какую, пользу, приносят, человеку, почему, люди, начали, одомашнивать
Topics EN: mathematics, animal, animals, birds, insects, human, body, senses, health
Headings: Какую пользу приносят человеку животные?; Почему люди начали одомашнивать животных?; Головоломка; Что мы получаем от животных?; Что человек получает от насекомых?; Что человек получает от коровы?; Что человек получает от свиньи?; Как человек использует лошадь?; Проблемы животноводства; Запомни; Вопросы и задания; Собаки на службе у человека; Размышляй и исследуй!

## Какую пользу приносят человеку грибы?
URL: https://www.opiq.ee/kit/228/chapter/13049
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 8.4
Topics ET: matemaatika
Topics RU: математика, какую, пользу, приносят, человеку, грибы, съедобные, ядовитые, головоломка, выращивание
Topics EN: mathematics
Headings: Какую пользу приносят человеку грибы?; Съедобные грибы; Ядовитые грибы; Головоломка; Выращивание грибов; Съедобный или несъедобный?; Дрожжевые грибы; Дрожжевые грибы и хлеб; Практическая работа; Дрожжевое тесто; Плесневые грибы; Антибиотики; Какой вред наносят грибы?; Запомни; Вопросы и задания; Использование грибов; Размышляй и исследуй!

## Какую пользу приносят человеку бактерии?
URL: https://www.opiq.ee/kit/228/chapter/13050
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 8.5
Topics ET: matemaatika
Topics RU: математика, какую, пользу, приносят, человеку, бактерии, использование, бактерий, такое, компост
Topics EN: mathematics
Headings: Какую пользу приносят человеку бактерии?; Использование бактерий; Что такое компост?; Возбудители заболеваний; Какие болезни вызывают бактерии?; Запомни; Вопросы и задания; Использование молочнокислых бактерий; Размышляй и исследуй!

## В заключение
URL: https://www.opiq.ee/kit/228/chapter/13052
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 8.6
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, заключение, вопросы, повторения, тест, бактерии, съедобные, части, растений, одомашненные
Topics EN: mathematics, animal, animals, birds, insects
Headings: В заключение; Вопросы для повторения; Тест; Бактерии; Съедобные части растений; Одомашненные животные; Что от каких животных мы получаем?; Дрожжевое тесто; Что это за гриб?

## Наблюдение за деревом в разные времена года
URL: https://www.opiq.ee/kit/228/chapter/13053
Book: Природо­ведение 4 класс – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_4_класс
Chapter ID: 9.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима, наблюдение, деревом, разные, времена, года, наблюдения, общегосударственные, природой, внеси
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Наблюдение за деревом в разные времена года; Наблюдения; Наблюдение 1; Наблюдение 2; Наблюдение 3; Общегосударственные наблюдения за природой; Внеси свой вклад в базу данных наблюдений за природой

## Природо­ведение для 4 класса – Opiq
URL: https://www.opiq.ee/Kit/Details/27
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 245
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение, класса
Topics EN: mathematics

## Природо­ведение для 4 класса – Opiq
URL: https://www.opiq.ee/Kit/Details/27
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 301
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение, класса
Topics EN: mathematics

## Звёздное небо
URL: https://www.opiq.ee/kit/27/chapter/1280
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.1
Topics ET: matemaatika
Topics RU: математика, здное, небо, когда, лучше, всего, наблюдать, здами, такое, созвездия
Topics EN: mathematics
Headings: Звёздное небо; Звёзды; Когда и где лучше всего наблюдать за звёздами?; Что такое созвездия?; Подумай; Люди давали созвездиям имена...; Большая Медведица и Полярная звезда; Полярная звезда всегда указывает на...; Как найти в небе Полярную звезду?; Чтобы найти Полярную звезду, нужно ...; Карта звёздного неба; Отметь верные утверждения.; Понятия; Я знаю, что…

## Вселенная
URL: https://www.opiq.ee/kit/27/chapter/1281
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.2
Topics ET: matemaatika
Topics RU: математика, вселенная, такое, внутри, посмотри, видео, заполни, пропуски, каковы, размеры
Topics EN: mathematics
Headings: Вселенная; Что такое Вселенная и что у неё внутри?; Посмотри видео и заполни пропуски; Каковы размеры Вселенной и чем их измеряют?; Ответь; Подумай; Галактики; Заполни пропуски; Что находится между звёздами?; Между небесными телами находятся...; Галактика Андромеды; Закончи предложение; Понятия; Я знаю, что…

## Астрономия
URL: https://www.opiq.ee/kit/27/chapter/1282
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem
Topics RU: математика, сравнение, сравни, больше, меньше, астрономия, давно, интересовали, людей, почему, древние, люди, следили, движением
Topics EN: mathematics, comparison, compare, greater, less
Headings: Астрономия; Звёзды давно интересовали людей; Почему древние люди следили за движением небесных тел?; Какая разница между астрономией и астрологией?; Сравни астрологию и астрономию; С помощью каких приборов учёные изучают Вселенную?; Заполни пропуски; Дополнительно. В Эстонии жили и работали всемирно известные астрономы; Ученые и их открытия; Где изучают звёзды?; Как называется научное учреждение, где производятся астрономические наблюдения?; Дополнительно. Знакомство со звёздами; Выбери правильные варианты ответа; Понятия; Я знаю, что…

## Солнце и Солнечная система
URL: https://www.opiq.ee/kit/27/chapter/1283
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem
Topics RU: математика, сравнение, сравни, больше, меньше, солнце, солнечная, система, кажется, самой, большой, яркой, звездой, потому
Topics EN: mathematics, comparison, compare, greater, less
Headings: Солнце и Солнечная система; Солнце; Солнце кажется нам самой большой и яркой звездой, потому что ...; Каковы размеры Солнца и как далеко оно от нас?; Во сколько раз диаметр Солнца больше диаметра Земли?; Как долго свет распространяется от Солнца к Земле?; Заполни пропуски; Какова температура Солнца?; Самая горячая звезда имеет...; Сколько лет Солнцу?; Опиши жизненный цикл Солнца; Что такое Солнечная система?; Солнечную систему составляют ...; Солнечная энергия; Отметь верные утверждения; Подумай; Понятия; Я знаю, что…

## Планеты
URL: https://www.opiq.ee/kit/27/chapter/1284
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.5
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis
Topics RU: математика, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье, планеты, сколько, планет, солнечной, системе, такое, орбита, рассмотри, рисунок
Topics EN: mathematics, comparison, compare, greater, less, human, body, senses, health
Headings: Планеты; Сколько планет в Солнечной системе?; Что такое орбита?; Рассмотри рисунок и ответь; Ответь; О какой планете идет речь? (2); О какой планете идет речь? (1); Дополнительно. Почему Плутон больше не считается планетой?; Каким условиям должно отвечать небесное тело, чтобы считаться планетой?; Понятия; Я знаю, что…

## Земля
URL: https://www.opiq.ee/kit/27/chapter/1285
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, земля, особенности, земли, подумай, отличается, других, планет, образовался, земной
Topics EN: mathematics
Headings: Земля; Особенности Земли; Подумай; Чем Земля отличается от других планет?; Как образовался земной шар?; Определи правильный порядок предложений; Что заставляет Землю и другие небесные тела обращаться вокруг Солнца?; Заполни пропуски; Дополнительно. Жизнь во Вселенной; Дополнительно. Как могли бы выглядеть внеземные существа?; Я знаю, что…

## Земля обращается вокруг Солнца и вращается вокруг своей оси
URL: https://www.opiq.ee/kit/27/chapter/1286
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.7
Topics ET: matemaatika
Topics RU: математика, земля, обращается, вокруг, солнца, вращается, своей, почему, происходит, смена
Topics EN: mathematics
Headings: Земля обращается вокруг Солнца и вращается вокруг своей оси; Почему происходит смена дня и ночи?; Какие небесные тела связаны со сменой дня и ночи?; В результате чего на Земле происходит смена дня и ночи?; Почему происходит смена времён года?; Какие небесные тела влекут за собой смену времён года?; В результате чего на Земле происходит смена времён года?; Лунное и солнечное затмения; Выбери для каждого рисунка подходящий заголовок; Дополнительно. Високосный год; В високосном году...; Подумай!; Понятия; Я знаю, что…

## Спутники Земли. Луна и искусственные спутники
URL: https://www.opiq.ee/kit/27/chapter/1287
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.8
Topics ET: matemaatika
Topics RU: математика, спутники, земли, луна, искусственные, обращается, вокруг, повернута, земле, видим
Topics EN: mathematics
Headings: Спутники Земли. Луна и искусственные спутники; Луна обращается вокруг Земли; Луна повернута к Земле ...; Мы видим Луну, потому что ...; Луна совершает один оборот вокруг своей оси ...; Почему Луна не всегда выглядит одинаково?; Отметь правильные высказывания; Искусственные спутники, или сателлиты; Подумай; Какие задачи выполняют искусственные спутники?; Каково будущее сателлитов?; Понятия; Я знаю, что…

## Малые тела Солнечной системы
URL: https://www.opiq.ee/kit/27/chapter/1288
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 1.9
Topics ET: matemaatika
Topics RU: математика, малые, тела, солнечной, системы, карликовые, планеты, общего, планет, карликовых
Topics EN: mathematics
Headings: Малые тела Солнечной системы; Карликовые планеты; Что общего у планет и карликовых планет?; Что отличает карликовые планеты от планет?; Астероиды; Подумай; Астероиды ...; Кометы; Заполни пропуски; Ответь; Метеоры и метеориты; О каком небесном теле идет речь?; Я знаю, что…

## Форма Земли
URL: https://www.opiq.ee/kit/27/chapter/1289
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика, форма, земли, какую, форму, имеет, земля, подумай, выбери, правильное
Topics EN: mathematics
Headings: Форма Земли; Какую форму имеет Земля?; Подумай; Выбери правильное слово; Дополнительно. Продолжительность дня и ночи; Выбери верное слово; Какой представляли себе Землю люди в древности?; Приведи три примера, как представляли себе Землю древние люди; Дополнительно. Действительно ли Земля круглая?; Я знаю, что…

## Внутреннее строение Земли
URL: https://www.opiq.ee/kit/27/chapter/1298
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.10
Topics ET: matemaatika
Topics RU: математика, внутреннее, строение, земли, слои, заполни, пропуски, подумай, трещины, земной
Topics EN: mathematics
Headings: Внутреннее строение Земли; Слои Земли; Заполни пропуски; Подумай; Трещины земной коры; Ответь на вопросы; Дрейф материков; Как назывался гигантский материк, который состоял из всех современных?; Я знаю,что…

## Вулканы
URL: https://www.opiq.ee/kit/27/chapter/1299
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.11
Topics ET: matemaatika
Topics RU: математика, вулканы, заставляет, вулкан, извергаться, выбери, верное, понятие, располагаются, какой
Topics EN: mathematics
Headings: Вулканы; Что заставляет вулкан извергаться?; Выбери верное понятие; Где располагаются вулканы?; Какой океан окружён таким плотным кольцом вулканов, что его называют «огненным кольцом»?; Что интересного есть вблизи вулканов?; Чем горячие источники отличаются от гейзеров?; Подумай; Дополнительно. Слышал ли ты об исландском вулкане Эйяфьядлайёкюдль?; Понятия; Я знаю, что…

## Землетрясения
URL: https://www.opiq.ee/kit/27/chapter/1300
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.12
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, землетрясения, почему, происходят, вызывает, землетрясение, далеко, распространяется, такое, эпицентр
Topics EN: mathematics, time, clock, calendar
Headings: Землетрясения; Почему происходят землетрясения?; Что вызывает землетрясение?; Как далеко распространяется землетрясение?; Что такое эпицентр?; Что такое очаг землетрясения?; Как образуются цунами?; Заполни пропуски; Подумай; Как можно прогнозировать землетрясения?; Сила землетрясения измеряется в баллах, которые показывают ...; Сейсмограф позволяет ...; Могут ли в Эстонии происходить землетрясения?; Отметь верные утверждения; Как вести себя во время землетрясения и после него?; Как вести себя во время землетрясения? Отметь верные ответы; Понятия; Я знаю, что…

## Разрушительные природные явления
URL: https://www.opiq.ee/kit/27/chapter/1301
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.13
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, разрушительные, природные, явления, является, причиной, природных, катастроф, отметь, верные
Topics EN: mathematics, human, body, senses, health
Headings: Разрушительные природные явления; Что является причиной природных катастроф?; Отметь верные утверждения; Может ли человек влиять на природные явления?; Подумай; Природные явления, связанные с погодой. Сильные ветры; Что характеризует ураган?; Почему возникают наводнения?; Какие природные явления можно наблюдать в Эстонии?; Понятия; Я знаю, что…

## Глобус
URL: https://www.opiq.ee/kit/27/chapter/1290
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика, глобус, уменьшенная, модель, земли, чего, используют, линии, глобусе, называется
Topics EN: mathematics
Headings: Глобус; Глобус – уменьшенная модель Земли; Для чего используют глобус?; Линии на глобусе; Как называется линия на глобусе, которая делит земной шар на Западное и Восточное полушария?; Как называется линия на глобусе, которая делит земной шар на Северное и Южное полушария?; Понятия; Я знаю, что…

## Карта
URL: https://www.opiq.ee/kit/27/chapter/1291
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem
Topics RU: математика, сравнение, сравни, больше, меньше, карта, глобус, превратить, карту, отметь, верные, утверждения, изготовляются
Topics EN: mathematics, comparison, compare, greater, less
Headings: Карта; Как глобус превратить в карту; Отметь верные утверждения; Сравни глобус и карту; Как изготовляются карты?; Выбери правильное понятие; Исследуй; Как объекты изображаются на карте?; Рассмотри карту. Ответь на вопросы; Дополнительно. Что делают картографы?; Как изготавливают карту?; Понятия; Я знаю, что…

## Как измеряются расстояния на карте?
URL: https://www.opiq.ee/kit/27/chapter/1292
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.4
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht
Topics RU: математика, измерение, единица измерения, длина, масса, объём, измеряются, расстояния, карте, измерь, свой, путь, каких, единицах
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Как измеряются расстояния на карте?; Измерение расстояния; Измерь свой путь; В каких единицах можно измерить расстояние?; Масштабы карт; Почему на каждой карте указывается масштаб?; Отметь верные утверждения; Исследуй; Понятия; Я знаю, что…

## Разнообразие карт
URL: https://www.opiq.ee/kit/27/chapter/1293
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика, разнообразие, карт, зачем, нужны, карты, использует, каждый, день, подумай
Topics EN: mathematics
Headings: Разнообразие карт; Зачем нужны карты?; Кто использует карты каждый день?; Подумай; Что можно отобразить на карте?; Какая карта даст ответ на вопрос?; Какие карты можно найти в атласе?; Выбери правильное понятие; Что такое навигационные приборы?; Изучи рисунок и отметь верные утверждения; Понятия; Я знаю, что…

## Материки и части света
URL: https://www.opiq.ee/kit/27/chapter/1294
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика, материки, части, света, какие, соединены, между, собой, полностью, находятся
Topics EN: mathematics
Headings: Материки и части света; Материки; Какие материки соединены между собой?; Какие материки полностью находятся в Восточном полушарии?; Какие материки полностью находятся в Западном полушарии?; Какие материки полностью находятся в Северном полушарии?; Какие материки полностью находятся в Южном полушарии?; Части света; Ответь; Дополнительно. Самая большая и самая маленькая часть света; Понятия; Я знаю, что…

## Океаны и моря
URL: https://www.opiq.ee/kit/27/chapter/1295
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.7
Topics ET: matemaatika, vesi, veeohutus, veekogu
Topics RU: математика, вода, безопасность на воде, водоём, океаны, моря, рассмотри, карту, выбери, правильный, вариант, ответа, какие
Topics EN: mathematics, water, water safety, body of water
Headings: Океаны и моря; Океаны; Рассмотри карту. Выбери правильный вариант ответа; На какие большие части можно разделить сушу?; На какие большие части можно разделить Мировой океан?; Размеры и глубины; Площади океанов; Расположи океаны в порядке уменьшения их площади; Как образовались океаны?; Дополнительно. Океанское дно; Закончи предложения; Почему вода в океанах солёная?; Сколько соли содержится в океанической воде?; Балтийское море; Почему Балтийское море важно для окружающих его стран?; К какому океану относится Балтийское море?; Жизнь в Мировом океане; Подумай; Что такое планктон?; Понятия; Я знаю, что…

## Географическое положение Эстонии
URL: https://www.opiq.ee/kit/27/chapter/1296
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика, географическое, положение, эстонии, характеризует, подумай, соседи, государственная, граница, латвии
Topics EN: mathematics
Headings: Географическое положение Эстонии; Географическое положение; Что характеризует географическое положение Эстонии?; Подумай; Соседи Эстонии и государственная граница; Для Латвии Эстония – это ...; Какие государства расположены на берегах Балтийского моря?; Отметь государства, с которыми у Латвии есть сухопутная граница; Эстония – это ...; Понятия; Я знаю, что…

## Карта Европы
URL: https://www.opiq.ee/kit/27/chapter/1297
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика, карта, европы, европа, карте, мира, выбери, правильный, ответ, крупнейшие
Topics EN: mathematics
Headings: Карта Европы; Европа на карте мира; Выбери правильный ответ; Крупнейшие государства Европы; Какие государства-соседи Эстонии входят в десятку самых больших по площади государств Европы?; Отметь названия европейских государств, в которых плотность населения выше, чем в Эстонии; Я знаю, что…

## Возникновение жизни и её развитие в воде
URL: https://www.opiq.ee/kit/27/chapter/1302
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика, возникновение, жизни, развитие, воде, зарождение, земли, образовались, океаны, возможно
Topics EN: mathematics
Headings: Возникновение жизни и её развитие в воде; Зарождение Земли; Как образовались океаны?; Возможно ли было 4600 миллионов лет назад совершить кругосветное путешествие по воде?; Возникновение жизни на Земле; Подумай; Что накопилось в воздухе в результате жизнедеятельности бактерий?; Кто был первым живым существом на Земле?; Появление различных живых существ; Определи правильный порядок возникновения живых организмов на Земле; Понятия; Я знаю, что…

## Развитие жизни на суше
URL: https://www.opiq.ee/kit/27/chapter/1303
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.2
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь, развитие, жизни, суше, первая, жизнь, расположи, этапы, развития, правильном
Topics EN: mathematics, time, clock, calendar
Headings: Развитие жизни на суше; Первая жизнь на суше; Расположи этапы развития жизни на суше в правильном порядке.; Эра динозавров; Закончи предложения; Эпоха млекопитающих; Расположи события в правильном порядке, начиная с самого раннего.; Подумай; Заключение. История жизни; Определи правильный порядок событий.; Дополнительно. Что представляет опасность для животных и растений в наше время?; Понятия; Я знаю, что…

## Признаки жизни
URL: https://www.opiq.ee/kit/27/chapter/1304
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика, признаки, жизни, живые, существа, бывают, самыми, разными, относится, живым
Topics EN: mathematics
Headings: Признаки жизни; Живые существа бывают самыми разными; Кто относится к живым организмам?; Как определить, является ли организм живым?; Заполни таблицу; Для изучения клеток используют микроскоп; Из чего состоят все живые организмы?; Подумай; Понятия; Я знаю, что…

## Многообразие организмов
URL: https://www.opiq.ee/kit/27/chapter/1305
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика, многообразие, организмов, одноклеточные, живые, организмы, отметь, называются, состоящие, одной
Topics EN: mathematics
Headings: Многообразие организмов; Одноклеточные живые организмы; Отметь одноклеточные организмы.; Как называются живые организмы, состоящие из одной клетки?; Многоклеточные организмы; Исследуй; Распредели организмы на две группы.; Как группируют живые организмы?; Закончи предложения.; Подумай; Понятия; Я знаю, что…

## Жизнь в различных условиях окружающей среды
URL: https://www.opiq.ee/kit/27/chapter/1306
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.5
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, жизнь, различных, условиях, окружающей, среды, условия, жизни, земле, различаются
Topics EN: mathematics, plant, plants, tree, flower
Headings: Жизнь в различных условиях окружающей среды; Условия жизни на Земле различаются; Чем объясняются главные различия в условиях обитания в разных уголках Земли?; Мир разделен на природные зоны; Отметь факторы окружающей среды.; Природные условия Эстонии; В наших лесах растут ...; В какой зоне находится Эстония?; Подумай; Четыре времени года; Почему растения не растут зимой?; Понятия; Я знаю, что…

## Жизнь в дождевом лесу
URL: https://www.opiq.ee/kit/27/chapter/1307
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.6
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, жизнь, дождевом, лесу, такое, дождевые, леса, характерно, тропического, дождевого
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Жизнь в дождевом лесу; Что такое дождевые леса?; Что характерно для тропического дождевого леса?; В каких частях света находятся дождевые леса?; Что характерно для экваториального дождевого леса?; Подумай; Растения в тропическом дождевом лесу; Выбери название растения, которое соответствует описанию; Животные в тропическом дождевом лесу; Отметь верные утверждения.; Дополнительно. Влажные тропические леса в опасности; Понятия; Я знаю, что…

## Жизнь в пустыне
URL: https://www.opiq.ee/kit/27/chapter/1308
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.7
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, жизнь, пустыне, такое, пустыня, каких, частях, света, находятся, пустыни
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Жизнь в пустыне; Что такое пустыня?; В каких частях света находятся пустыни?; Растения в пустыне; Как растения приспособились к условиям жизни в пустыне?; Животные в пустыне; Как животные приспособились к условиям жизни в пустыне?; Оазисы; Что такое оазис?; Понятия; Я знаю, что…

## Жизнь в тундре
URL: https://www.opiq.ee/kit/27/chapter/1309
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 3.8
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, времена года, весна, лето, осень, зима, жизнь, тундре, такое, тундра, какие, времена, года, представлены, каких
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects, seasons, spring, summer, autumn, winter
Headings: Жизнь в тундре; Что такое тундра?; Какие времена года представлены в тундре?; В каких частях света расположена зона тундр?; Исследуй; Полярная ночь и полярный день; Подумай; Выбери правильное понятие; Дополнительно. Тундра есть и в горной местности; Расположи природные зоны в том порядке, в каком они сменяются от подножия к вершине горы.; Времена года в тундре; Тундра зимой и летом; Растения и лишайники тундры; Какие растения тундры можно встретить в лесах и болотах Эстонии?; Животный мир тундры; Почему многие обитающие в тундре животные к зиме меняют мех?; Понятия; Я знаю, что…

## Строение тела человека
URL: https://www.opiq.ee/kit/27/chapter/1310
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.1
Topics ET: matemaatika, vesi, veeohutus, veekogu, inimene, keha, meeled, tervis
Topics RU: математика, вода, безопасность на воде, водоём, человек, тело, чувства, здоровье, строение, тела, человека, внешнее, перетащи, номера, частей, правильное, место
Topics EN: mathematics, water, water safety, body of water, human, body, senses, health
Headings: Строение тела человека; Внешнее строение человека; Перетащи номера частей тела в правильное место на рисунке; Из чего состоит человек?; Выбери название клетки, которое соответствует описанию (2); Выбери название клетки, которое соответствует описанию (1); Подумай; Органы состоят из тканей; Поставь в правильном порядке; Дополнительно. Вода в организме человека; Понятия; Я знаю, что…

## Половые органы
URL: https://www.opiq.ee/kit/27/chapter/1319
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.10
Topics ET: matemaatika
Topics RU: математика, половые, органы, женские, мужские, дополнительно, сперматозоиды, яйцеклетки, перетащи, утверждения
Topics EN: mathematics
Headings: Половые органы; Женские и мужские половые органы; Дополнительно. Сперматозоиды и яйцеклетки; Перетащи утверждения в правильную колонку; Как начинается новая жизнь?; Через что плод получает из крови матери питательные вещества и кислород?; Слияние яйцеклетки и сперматозоида называют ...; В каком половом органе происходит оплодотворение?; Что происходит, если яйцеклетка не оплодотворяется?; Отметь верные утверждения; Понятия; Я знаю, что…

## Нервная система. Железы
URL: https://www.opiq.ee/kit/27/chapter/1320
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика, нервная, система, железы, верно, неверно, отметь, верные, утверждения, расположи
Topics EN: mathematics
Headings: Нервная система. Железы; Нервная система; Верно или неверно? Отметь верные утверждения; Расположи события в правильном порядке; Железы; Дополнительно. Гипофиз; Подумай; Отметь верные предложения; Понятия; Я знаю, что…

## Человек относится к млекопитающим
URL: https://www.opiq.ee/kit/27/chapter/1321
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.12
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, inimene, keha, meeled, tervis
Topics RU: математика, сравнение, сравни, больше, меньше, человек, тело, чувства, здоровье, относится, млекопитающим, человека, собаки, подумай, заполни, пропуски
Topics EN: mathematics, comparison, compare, greater, less, human, body, senses, health
Headings: Человек относится к млекопитающим; Сравнение человека и собаки; Подумай; Заполни пропуски; Человек больше всего похож на других млекопитающих; Кто является млекопитающим?; Дополнительно. Самое маленькое и самое крупное млекопитающие; Я знаю, что…

## Люди и обезьяны
URL: https://www.opiq.ee/kit/27/chapter/1322
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.13
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, люди, обезьяны, человекообразные, подумай, азии, живут, какими, животными
Topics EN: mathematics, human, body, senses, health
Headings: Люди и обезьяны; Человекообразные обезьяны; Подумай; В Азии живут ...; С какими животными человек находится в самом близком родстве?; В Африке живут ...; Чем человек отличается от обезьяны?; Заполни таблицу; Чем похожи люди и обезьяны?; Чем похожи человек и обезьяна?; Я знаю, что…

## Происхождение человека
URL: https://www.opiq.ee/kit/27/chapter/1323
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.14
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, происхождение, человека, исследования, происхождения, каких, материках, какой, описан
Topics EN: mathematics, human, body, senses, health
Headings: Происхождение человека; Исследования происхождения человека; На каких материках жил человек ?; Какой вид человека описан?; На каком материке жили обезьянолюди?; Какие изменения произошли с человеком в ходе эволюции?; Что позволило человеку начать использовать инструменты?; Что отличает человека от животных?; Подумай; Дополнительно. Неандертальцы; Я знаю, что…

## Задачи систем органов
URL: https://www.opiq.ee/kit/27/chapter/1311
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика, задачи, систем, органов, какие, системы, есть, человека, отметь, система
Topics EN: mathematics
Headings: Задачи систем органов; Какие системы органов есть у человека?; Отметь системы органов человека; Система органов – это ...; Системы органов человека I; Покровная система; Опорно-двигательная система; Пищеварительная система; Сердечно-сосудистая система; Дыхательная система; Отметь органы, которые относятся к дыхательной системе; Отметь органы, которые относятся к пищеварительной системе; Системы органов человека II; Нервная система; Выделительная система; Система органов чувств; Половая система; Соедини систему органов и ее описание (2); Соедини систему органов и ее описание (1); Исследуй; Дополнительно. Что такое рефлексы?; Дополнительно. Что произойдет, если какой-либо орган заболеет или прекратит работать?; Понятия; Я знаю, что…

## Органы чувств
URL: https://www.opiq.ee/kit/27/chapter/1312
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.3
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, органы, чувств, человека, отметь, орган, работает, глаз, заполни, пропуски
Topics EN: mathematics, human, body, senses, health
Headings: Органы чувств; Органы чувств человека; Отметь органы чувств; Орган чувств – это ...; Как работает глаз?; Заполни пропуски; Дополнительно. Помощники глаза; Как работает ухо?; Укажи вторую функцию внутреннего уха; Расположи процессы в правильном порядке; Как работает язык?; Дополнительно. Что помогает понять вкус?; Каждая часть языка воспринимает ...; Язык – это ...; Как работает нос?; Дополнительно. Сколько запахов может различать человек?; Какие чувства есть у человека?; Органы чувств и головной мозг; Ответь; Дополнительно. Почему запах может напоминать о каком-нибудь событии?; Понятия; Я знаю, что…

## Органы чувств. Кожа
URL: https://www.opiq.ee/kit/27/chapter/1313
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика, органы, чувств, кожа, функции, отметь, какую, информацию, можно, получить
Topics EN: mathematics
Headings: Органы чувств. Кожа; Кожа и ее функции; Отметь, какую информацию можно получить с помощью кожи.; Каковы задачи кожи?; Дополнительно. Рельефно-точечный шрифт; Исследование; Понятия; Я знаю, что…

## Опорно-двигательная система
URL: https://www.opiq.ee/kit/27/chapter/1314
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.5
Topics ET: matemaatika
Topics RU: математика, опорно, двигательная, система, кости, суставы, дополнительно, почему, кончике, носа
Topics EN: mathematics
Headings: Опорно-двигательная система; Кости и суставы; Дополнительно. Почему в кончике носа кость подвижная?; Ответь на вопросы; Мышцы; Отметь верные утверждения; Дополнительно. Зачем нам нужны крепкие кости?; Подумай; Что помогает костям оставаться крепкими?; Что нужно человеку для крепости костей?; В каких продуктах содержится кальций?; Понятия; Я знаю, что…

## Органы дыхания
URL: https://www.opiq.ee/kit/27/chapter/1315
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.6
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, органы, дыхания, дышит, определи, путь, движения, воздуха, ответь
Topics EN: mathematics, human, body, senses, health
Headings: Органы дыхания; Как человек дышит?; Определи путь движения воздуха:; Ответь на вопросы; Дополнительно. Почему мы задыхаемся при беге?; Как мы можем позаботиться о своей дыхательной системе?; Что лучше всего укрепляет дыхательную систему?; Подумай!; Понятия; Я знаю, что…

## Кровообращение
URL: https://www.opiq.ee/kit/27/chapter/1316
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика, кровообращение, кровь, циркулирует, организме, дополнительно, капилляры, выбери, окошке, подходящее
Topics EN: mathematics
Headings: Кровообращение; Как кровь циркулирует в организме?; Дополнительно. Капилляры; Выбери в окошке подходящее понятие; Дополнительно. Замкнутая и незамкнутая кровеносная система; Дополнительно. Как проверить, перекачивает ли сердце кровь в артерии?; Из чего состоит кровь?; Каковы задачи кровяных клеток?; Подумай; Дополнительно. Как сворачивается кровь?; Тромбоциты склеиваются между собой и образуют сеть, в результате ...; Вытекающая из раны кровь ...; Дополнительно. Зачем люди сдают кровь?; Зачем люди жертвуют кровь?; Понятия; Я знаю, что…

## Органы пищеварения
URL: https://www.opiq.ee/kit/27/chapter/1317
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика, органы, пищеварения, происходит, процесс, переваривания, каком, органе, всасывание, питательных
Topics EN: mathematics
Headings: Органы пищеварения; Как происходит процесс переваривания?; В каком органе происходит всасывание питательных веществ в кровь?; Исследуй; Пищеварительные соки необходимы для переваривания пищи; Какие из данных органов участвуют в пищеварении, но пища не проходит через них?; Понятия; Я знаю, что…

## Органы выделения
URL: https://www.opiq.ee/kit/27/chapter/1318
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 4.9
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, органы, выделения, какие, также, являются, частями, других, систем, органов
Topics EN: mathematics, human, body, senses, health
Headings: Органы выделения; Выделения; Какие органы выделения также являются частями других систем органов?; Какие органы помогают нам избавиться от выделений?; Сколько выделений образуется в организме?; Почему человек потеет?; Подумай; Понятия; Я знаю, что…

## Растения в жизни человека
URL: https://www.opiq.ee/kit/27/chapter/1324
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 5.1
Topics ET: matemaatika, taim, taimed, puu, lill
Topics RU: математика, растение, растения, дерево, цветок, жизни, человека, производят, пищу, себя, других, организмов, нужно
Topics EN: mathematics, plant, plants, tree, flower
Headings: Растения в жизни человека; Растения производят пищу для себя и других организмов; Что нужно растениям для производства сахара?; Растения производят кислород; Заполни пропуски; Растения очищают воздух и лечат; Растения на кухне; Для чего нужны эти пряности?; Растения защищают от холода и украшают нашу жизнь; Исследуй; Для чего человеку нужны растения?; Я знаю, что…

## Животные в жизни человека
URL: https://www.opiq.ee/kit/27/chapter/1325
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 5.2
Topics ET: matemaatika, loom, loomad, linnud, putukad
Topics RU: математика, животное, животные, птицы, насекомые, жизни, человека, одомашнивание, животных, заполни, пропуски, кожи, шерсти
Topics EN: mathematics, animal, animals, birds, insects
Headings: Животные в жизни человека; Одомашнивание животных; Заполни пропуски; Из кожи и шерсти животных делают одежду и обувь; Животные помогают людям; Какую работу помогают выполнять животные?; От насекомых мы получаем мёд и шёлк; Что из перечисленного дают нам животные?; Человеку нужен друг; Подумай; Дополнительно. Бескровная охота; Я знаю, что…

## Грибы в жизни человека
URL: https://www.opiq.ee/kit/27/chapter/1326
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 5.3
Topics ET: matemaatika
Topics RU: математика, грибы, жизни, человека, люди, собирают, пищу, съедобные, условно, ядовитые
Topics EN: mathematics
Headings: Грибы в жизни человека; Люди собирают грибы в пищу; Съедобные грибы; Условно-съедобные грибы; Ядовитые грибы; Съедобные и несъедобные грибы; Люди выращивают грибы; Что нужно грибам для роста?; Грибы используются для различных целей; Выбери в окошке соответствующие названия грибов; Дополнительно. Плесневые грибы; Грибы приводят к болезням и разрушают древесину; Подумай; Как избежать грибковых заболеваний ног?; В природе грибы являются разлагателями; Какую пользу приносят грибы человеку?; Я знаю, что…

## Бактерии в жизни человека
URL: https://www.opiq.ee/kit/27/chapter/1327
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 5.4
Topics ET: matemaatika
Topics RU: математика, бактерии, жизни, человека, живут, теле, внутри, него, почему, многие
Topics EN: mathematics
Headings: Бактерии в жизни человека; Бактерии живут на теле человека и внутри него; Почему многие бактерии полезны для человека?; Подумай; Бактерии используются в производстве продуктов питания; При изготовлении каких продуктов используются бактерии?; Бактерии являются разлагателями; Заполни пропуски; Дополнительно. Некоторые бактерии являются причиной болезней; Для лечения бактериальных заболеваний ...; Для предотвращения бактериальных заболеваний ...; Я знаю, что…

## Рабочий лист. Исследование на природе
URL: https://www.opiq.ee/kit/27/chapter/1328
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 6.1
Topics ET: matemaatika
Topics RU: математика, рабочий, лист, исследование, природе, порядок, выполнения, работы
Topics EN: mathematics
Headings: Рабочий лист. Исследование на природе; Порядок выполнения работы

## Физическая карта Эстонии
URL: https://www.opiq.ee/kit/27/chapter/1329
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 6.2
Topics ET: matemaatika
Topics RU: математика, физическая, карта, эстонии
Topics EN: mathematics
Headings: Физическая карта Эстонии

## Физическая карта мира
URL: https://www.opiq.ee/kit/27/chapter/1330
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 6.3
Topics ET: matemaatika
Topics RU: математика, физическая, карта, мира, северное, полушарие, южное
Topics EN: mathematics
Headings: Физическая карта мира; Северное полушарие 1; Северное полушарие 2; Северное полушарие 3; Южное полушарие 1; Южное полушарие 2; Южное полушарие 3

## Дополнительная литература для любознательных
URL: https://www.opiq.ee/kit/27/chapter/1331
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 6.4
Topics ET: matemaatika, inimene, keha, meeled, tervis
Topics RU: математика, человек, тело, чувства, здоровье, дополнительная, литература, любознательных, вселенная, планета, земля, разнообразие, жизни, земле
Topics EN: mathematics, human, body, senses, health
Headings: Дополнительная литература для любознательных; Литература; Вселенная; Планета Земля; Разнообразие жизни на Земле; Человек; Ссылки на интернет-ресурсы

## Понятия
URL: https://www.opiq.ee/kit/27/chapter/24425
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 6.5
Topics ET: matemaatika
Topics RU: математика, понятия
Topics EN: mathematics
Headings: Понятия

## Эстонско-русский тематический словарь
URL: https://www.opiq.ee/kit/27/chapter/24426
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 6.6
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, maailmaruum, planeet
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье, эстонско, русский, тематический, словарь, вселенная, планета, земля
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects, human, body, senses, health
Headings: Эстонско-русский тематический словарь; Maailmaruum/Вселенная; Planeet Maa/Планета Земля; Elu mitmekesisus Maal/Разнообразие жизни на Земле; Inimene/Человек; Taimed, loomad, seened ja bakterid inimese elus /Растения, животные, грибы и бактерии в жизни человека

## Импрессум
URL: https://www.opiq.ee/kit/27/chapter/1332
Book: Природо­ведение для 4 класса – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса
Chapter ID: 6.7
Topics ET: matemaatika
Topics RU: математика, импрессум
Topics EN: mathematics
Headings: Импрессум

## Природо­ведение для 4 класса (2023) – Opiq
URL: https://www.opiq.ee/Kit/Details/536
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 302
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение, класса
Topics EN: mathematics

## Природо­ведение для 4 класса (2023) – Opiq
URL: https://www.opiq.ee/Kit/Details/536
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 353
Topics ET: matemaatika, opiq
Topics RU: математика, природо, ведение, класса
Topics EN: mathematics

## Звёздное небо
URL: https://www.opiq.ee/kit/536/chapter/29705
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.1
Topics ET: matemaatika, tähistaevas
Topics RU: математика, здное, небо, созвездия, полярная, звезда, карты
Topics EN: mathematics
Headings: Звёздное небо; Tähistaevas; Звёзды; Созвездия; Полярная звезда; Заданиe 3b; Карты звёздного неба; Понятия; Я знаю, что …
Task examples: Отметь верные утверждения.; Укажи наиболее известное созвездие нашего неба.

## Вселенная
URL: https://www.opiq.ee/kit/536/chapter/29706
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.2
Topics ET: matemaatika, universum
Topics RU: математика, вселенная, такое, находится, знаешь, галактика, туманность, андромеды
Topics EN: mathematics
Headings: Вселенная; Universum; Что такое Вселенная и что в ней находится?; Знаешь ли ты?; Что такое галактика?; Что такое туманность?; Галактика Андромеды – наш сосед; Понятия; Я знаю, что …
Task examples: Какое расстояние пройдёт свет Солнца за один год? Выбери все подходящие варианты ответа.; Что находится во Вселенной?

## Солнце
URL: https://www.opiq.ee/kit/536/chapter/29707
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.3
Topics ET: matemaatika, päike
Topics RU: математика, солнце, такое, каковы, размеры, солнца, далеко, находится
Topics EN: mathematics
Headings: Солнце; Päike; Что такое Солнце?; Каковы размеры Солнца и как далеко оно находится?; Какова температура Солнца?; Жизненный цикл Солнца; Солнце – источник энергии; Береги глаза и кожу!; Понятия; Я знаю, что …
Task examples: Почему Солнце так важно для нас?; Сколько времени требуется солнечному свету, чтобы достигнуть Земли?

## Солнечная система и планеты
URL: https://www.opiq.ee/kit/536/chapter/29708
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.4
Topics ET: matemaatika, päikesesüsteem, planeedid
Topics RU: математика, солнечная, система, планеты, такое, отличить, планету
Topics EN: mathematics
Headings: Солнечная система и планеты; Päikesesüsteem ja planeedid; Что такое Солнечная система?; Как отличить планету от звезды?; Как движутся планеты?; Как группируют планеты?; Понятия; Я знаю, что …
Task examples: Отметь небесные тела, которые входят в состав Солнечной системы.; Расположи планеты в порядке их удаления от Солнца.

## Малые тела Солнечной системы
URL: https://www.opiq.ee/kit/536/chapter/29709
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.5
Topics ET: matemaatika, päikese, süsteemi, väikekehad
Topics RU: математика, малые, тела, солнечной, системы, карликовые, планеты
Topics EN: mathematics
Headings: Малые тела Солнечной системы; Päikese­süsteemi väikekehad; Карликовые планеты; Метеоры и метеориты; Кометы; Астероиды; Понятия; Я знаю, что …
Task examples: Отметь карликовые планеты.; Когда у кометы появляется хвост?

## Земля
URL: https://www.opiq.ee/kit/536/chapter/29710
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.6
Topics ET: matemaatika
Topics RU: математика, земля, возник, земной, какова, наша, планета, каковы, размеры
Topics EN: mathematics
Headings: Земля; Maa; Как возник земной шар?; Какова наша планета?; Каковы размеры Земли?; Дополнительный материал. Жизнь за пределами Земли; Где искать жизнь?; Как искать жизнь?; Я знаю, что …
Task examples: Расположи события в правильном порядке.; Чем Земля отличается от других планет Солнечной системы?

## Вращение и обращение Земли
URL: https://www.opiq.ee/kit/536/chapter/29711
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.7
Topics ET: matemaatika, pöörleb, tiirleb
Topics RU: математика, вращение, обращение, земли, смена, ночи, времен
Topics EN: mathematics
Headings: Вращение и обращение Земли; Maa pöörleb ja tiirleb; Смена дня и ночи; Смена времен года; Лунные и солнечные затмения; Понятия; Я знаю, что…
Task examples: Сколько времени нужно Земле на совершение одного оборота вокруг своей оси? выбери все подходящие варианты.; Из-за чего сменяются день и ночь?

## Спутники Земли. Луна и искусственные спутники
URL: https://www.opiq.ee/kit/536/chapter/29712
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.8
Topics ET: matemaatika, kaaslased, satelliidid
Topics RU: математика, спутники, земли, луна, искусственные, такое, почему
Topics EN: mathematics
Headings: Спутники Земли. Луна и искусственные спутники; Maa kaaslased. Kuu ja satelliidid; Что такое Луна?; Почему Луна меняет облик?; Люди на Луне; Искусственные спутники; Что происходит с искусствен­ны­ми спутниками?; Понятия; Я знаю, что...
Task examples: Луна повернута к Земле ...; Мы видим Луну, потому что...

## Исследование Вселенной
URL: https://www.opiq.ee/kit/536/chapter/29713
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 1.9
Topics ET: matemaatika, maailmaruumi, uurimine
Topics RU: математика, исследование, вселенной, астрономия, наука, здах, исследуют
Topics EN: mathematics
Headings: Исследование Вселенной; Maailmaruumi uurimine; Астрономия – наука о звёздах; Как исследуют Вселенную?; Космические аппараты; Специальности, связанные с исследованием космоса; Тартуская обсерватория; Понятия; Я знаю, что…
Task examples: Зачем древние люди наблюдали за небесными телами?; Что можно сделать при помощи космического телескопа?

## Форма Земли
URL: https://www.opiq.ee/kit/536/chapter/29714
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.1
Topics ET: matemaatika, kuju
Topics RU: математика, форма, земли, представления, людей, земле, древности, земля
Topics EN: mathematics
Headings: Форма Земли; Maa kuju; Представления людей о Земле в древности; Земля – это шар; Что находится за горизонтом?; Морские путешествия и шарообразность Земли; Я знаю, что…
Task examples: Как раньше представляли Землю? Выбери правильный вариант ответа.; Что доказывает, что Земля – это шар?

## Внутреннее строение Земли
URL: https://www.opiq.ee/kit/536/chapter/29723
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.10
Topics ET: matemaatika, maakera, siseehitus
Topics RU: математика, внутреннее, строение, земли, исследования, земных, недр
Topics EN: mathematics
Headings: Внутреннее строение Земли; Maakera siseehitus; Исследования земных недр; Земная кора; Мантия и ядро; Земная кора состоит из плит; Дополнительный материал. Дрейф материков; Я знаю, что…
Task examples: Откуда учёные получают информацию о внутреннем строении Земли?; Выбери правильный ответ.

## Вулканы
URL: https://www.opiq.ee/kit/536/chapter/29724
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.11
Topics ET: matemaatika, vulkaanid
Topics RU: математика, вулканы, почему, извергаются, расположены, можно, жить, вблизи
Topics EN: mathematics
Headings: Вулканы; Vulkaanid; Почему извергаются вулканы?; Где расположены вулканы?; Можно ли жить вблизи вулкана?; Горячие источники и гейзеры; Понятия; Я знаю, что...
Task examples: Выбери правильное понятие.; Изучи карту. Где с большей вероятностью произойдёт извержение?

## Землетрясения
URL: https://www.opiq.ee/kit/536/chapter/29725
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.12
Topics ET: matemaatika, aeg, kell, kalender, maavärinad
Topics RU: математика, время, часы, календарь, землетрясения, почему, происходят, землетрясе, бывают, эстонии, такое
Topics EN: mathematics, time, clock, calendar
Headings: Землетрясения; Maavärinad; Почему происходят землетрясе­ния?; Где происходят землетрясения?; Бывают ли в Эстонии землетрясения?; Что такое цунами?; Запомни!; Что делать во время землетрясения?; Понятия; Я знаю, что...
Task examples: Что заставляет поверхность Земли дрожать?; Что такое очаг землетрясения?

## Стихийные бедствия
URL: https://www.opiq.ee/kit/536/chapter/29726
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.13
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, õnnetused
Topics RU: математика, природа, природоведение, окружающая среда, стихийные, бедствия, такое, стихийное, бедствие, какие
Topics EN: mathematics, nature, science, environment
Headings: Стихийные бедствия; Loodus­õnnetused; Что такое стихийное бедствие?; Какие стихийные бедствия возможны в Эстонии?; Наводнения; Сильные ветры; Как подготовиться к шторму и его последствиям?; Понятия; Я знаю, что…
Task examples: Отметь верные утверждения.; Какие стихийные бедствия возможны в Эстонии?

## Глобус
URL: https://www.opiq.ee/kit/536/chapter/29715
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.2
Topics ET: matemaatika, arv, arvud, arvu, numbrid, gloobus
Topics RU: математика, число, числа, цифры, глобус, модель, земли, линии, глобусе, дополнительный, материал
Topics EN: mathematics, number, numbers, digits
Headings: Глобус; Gloobus; Глобус – модель Земли; Линии на глобусе; Дополнительный материал. Что показывают числа на глобусе?; Понятия; Я знаю, что …
Task examples: Чем глобус похож на Землю?; Где находится Эстония? Выбери все подходящие варианты ответа.

## Карта
URL: https://www.opiq.ee/kit/536/chapter/29716
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.3
Topics ET: matemaatika, kaart
Topics RU: математика, карта, глобуса, сделать, карту, исследуй, изготавливают, изображают
Topics EN: mathematics
Headings: Карта; Kaart; Как из глобуса сделать карту?; Исследуй!; Как изготавливают карту?; Как изображают объекты на карте?; Понятия; Я знаю, что …
Task examples: Отметь верные утверждения.; Выбери правильное понятие.

## Масштаб карты
URL: https://www.opiq.ee/kit/536/chapter/29717
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.4
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, kaardi, mõõtkava
Topics RU: математика, измерение, единица измерения, длина, масса, объём, масштаб, карты, карта, уменьшенное, изображение, такое
Topics EN: mathematics, measurement, unit, length, mass, volume
Headings: Масштаб карты; Kaardi mõõtkava; Карта – это уменьшенное изображение; Что такое масштаб?; Как определить расстояние при помощи бумажной карты?; Пример; Дополнительный материал. Измерение расстояния временем; Понятия; Я знаю, что…
Task examples: Отметь верное предложение.; Зачем нужен масштаб?

## Разнообразие карт
URL: https://www.opiq.ee/kit/536/chapter/29718
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.5
Topics ET: matemaatika, kaartide, mitmekesisus
Topics RU: математика, разнообразие, карт, зачем, нужны, карты, физические
Topics EN: mathematics
Headings: Разнообразие карт; Kaartide mitmekesisus; Зачем нужны карты?; Физические и политические карты; Атлас; Какие карты есть в атласе?; Понятия; Я знаю, что…
Task examples: Кто в своей повседневной работе использует карты?; Какая карта даст ответы на данные вопросы? Перетащи вопросы в нужную колонку.

## Материки и части света
URL: https://www.opiq.ee/kit/536/chapter/29719
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.6
Topics ET: matemaatika, mandrid, maailmajaod
Topics RU: математика, материки, части, света, понятия, знаю
Topics EN: mathematics
Headings: Материки и части света; Mandrid ja maailmajaod; Материки; Части света; Понятия; Я знаю, что…
Task examples: Какие материки соединены между собой полоской суши?; Какие материки полностью или почти полностью расположены в Восточном полушарии?

## Мировой океан
URL: https://www.opiq.ee/kit/536/chapter/29720
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.7
Topics ET: matemaatika, vesi, veeohutus, veekogu, maailmameri
Topics RU: математика, вода, безопасность на воде, водоём, мировой, океан, земле, части, океанов, понятия
Topics EN: mathematics, water, water safety, body of water
Headings: Мировой океан; Maailmameri; Вода на Земле; Части океанов; Понятия; Я знаю, что…
Task examples: На какие крупные части делится Мировой океан?; На какие крупные части делится суша?

## Географическое положение Эстонии
URL: https://www.opiq.ee/kit/536/chapter/29721
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.8
Topics ET: matemaatika, eesti, geograafiline, asend
Topics RU: математика, географическое, положение, эстонии, соседи, государственная
Topics EN: mathematics
Headings: Географическое положение Эстонии; Eesti geograafiline asend; Географическое положение; Соседи Эстонии. Государственная граница; Понятия; Я знаю, что…
Task examples: Отметь утверждения, характеризующие географическое положение Эстонии.; Эстония для Латвии ...

## Карта Европы
URL: https://www.opiq.ee/kit/536/chapter/29722
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 2.9
Topics ET: matemaatika, euroopa, kaart
Topics RU: математика, карта, европы, европа, карте, мира, крупнейшие
Topics EN: mathematics
Headings: Карта Европы; Euroopa kaart; Европа на карте мира; Крупнейшие государства Европы; Я знаю, что …
Task examples: Какой водоём ограничивает Европу...; Какая часть света граничит с Европой ...

## Возникновение жизни и её развитие в воде
URL: https://www.opiq.ee/kit/536/chapter/29727
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.1
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, возникновение, жизни, развитие, воде, земли, суши, океана, первые
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Возникновение жизни и её развитие в воде; Развитие Земли; Возникновение суши и океана; 00.00; 01.00; Первые живые существа – бактерии; 04.19; В древних морях возникают растения и животные; 20.30; 21.08; Понятия; Я знаю, что …
Task examples: Предположим, что всё развитие Земли заняло одни сутки. Сколько часов на ней живут живые организмы?; Предположим, что всё развитие Земли заняло одни сутки. Через сколько часов после возникновения Земли появились первые живые существа (бактерии)?

## Жизнь в дождевых лесах
URL: https://www.opiq.ee/kit/536/chapter/29736
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.10
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, taim, taimed, puu, lill, vihmametsas
Topics RU: математика, деление, раздели, частное, половина, растение, растения, дерево, цветок, жизнь, дождевых, лесах, такое, дождевой, дождевом, лесу
Topics EN: mathematics, division, divide, quotient, half, plant, plants, tree, flower
Headings: Жизнь в дождевых лесах; Elu vihmametsas; Что такое дождевой лес?; В дождевом лесу тепло, влажно и сумрачно; Половина всех видов животных живёт в дождевом лесу; В дождевом лесу растут полезные растения; Дождевые леса в опасности; Понятия; Я знаю, что…
Task examples: В каких частях света растут дождевые леса?; Что характеризует дождевой лес?

## Жизнь в пустыне
URL: https://www.opiq.ee/kit/536/chapter/29737
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.11
Topics ET: matemaatika, taim, taimed, puu, lill, loom, loomad, linnud, putukad, kõrbes
Topics RU: математика, растение, растения, дерево, цветок, животное, животные, птицы, насекомые, жизнь, пустыне, такое, пустыня, пустынь
Topics EN: mathematics, plant, plants, tree, flower, animal, animals, birds, insects
Headings: Жизнь в пустыне; Elu kõrbes; Что такое пустыня?; Растения пустынь; Животные пустыни; Оазисы; Понятия; Я знаю, что…
Task examples: В каких частях света есть пустыни?; Как растения пустыни справляются с длинным засушливым периодом?

## Жизнь вблизи полюсов
URL: https://www.opiq.ee/kit/536/chapter/29738
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.12
Topics ET: matemaatika, loom, loomad, linnud, putukad, pooluste, lähedal
Topics RU: математика, животное, животные, птицы, насекомые, жизнь, вблизи, полюсов, всегда, холодно, период
Topics EN: mathematics, animal, animals, birds, insects
Headings: Жизнь вблизи полюсов; Elu pooluste lähedal; Вблизи полюсов всегда холодно; Период роста в тундре короткий; Животные полярных пустынь и тундры; Полярная ночь и полярный день; Понятия; Я знаю, что…
Task examples: Выбери правильный вариант ответа.; В каких частях света встречается тундра?

## Жизнь в горах
URL: https://www.opiq.ee/kit/536/chapter/29739
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.13
Topics ET: matemaatika, loom, loomad, linnud, putukad, mägedes
Topics RU: математика, животное, животные, птицы, насекомые, жизнь, горах, высоко, холодно, разной, высоте, расположены
Topics EN: mathematics, animal, animals, birds, insects
Headings: Жизнь в горах; Elu mägedes; Высоко в горах холодно; В горах на разной высоте расположены разные природные зоны; Животные гор; Я знаю, что …
Task examples: Выбери правильное утверждение.; В горах и в природной зоне у подножия гор живут одни и те же животные?

## Развитие жизни на суше
URL: https://www.opiq.ee/kit/536/chapter/29728
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.2
Topics ET: matemaatika, loom, loomad, linnud, putukad, arenemine, maismaal
Topics RU: математика, животное, животные, птицы, насекомые, развитие, жизни, суше, часть, растений, переселяется, сушу
Topics EN: mathematics, animal, animals, birds, insects
Headings: Развитие жизни на суше; Elu arenemine maismaal; Часть растений переселяется на сушу; 21.48; 22.00; Животные на суше; 22.18; 22.57; 23.57; 23.59; Эпоха ящеров; Окаменелости; Понятия; Я знаю, что …
Task examples: Расположи живых существ в порядке их появления на Земле.; Расположи события в правильном порядке, начиная с самого давнего.

## Признаки жизни
URL: https://www.opiq.ee/kit/536/chapter/29729
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.3
Topics ET: matemaatika, loom, loomad, linnud, putukad, tunnused
Topics RU: математика, животное, животные, птицы, насекомые, признаки, жизни, живые, существа, очень, разные, узнать
Topics EN: mathematics, animal, animals, birds, insects
Headings: Признаки жизни; Elu tunnused; Живые существа очень разные; Как узнать, что перед нами живое существо?; Дополнительный материал. Животные развиваются по-разному; Клетки и крошечных живых существ изучают при помощи микроскопа; Дополнительный материал. Как пользоваться микроскопом?; Понятия; Я знаю, что…
Task examples: Отметь живых существ.; Отметь признаки живых существ.

## Многообразие живых существ
URL: https://www.opiq.ee/kit/536/chapter/29730
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.4
Topics ET: matemaatika, elusolendite, mitmekesisus
Topics RU: математика, многообразие, живых, существ, группируют, типу, питания, строению
Topics EN: mathematics
Headings: Многообразие живых существ; Elusolendite mitmekesisus; Как группируют живых существ?; По типу питания и строению клетки; По числу клеток; Одноклеточные живые существа; Многоклеточные организмы; Понятия; Я знаю, что …
Task examples: Отметь два варианта деления живых организмов на группы.; Отметь одноклеточные организмы.

## Растения в жизни человека
URL: https://www.opiq.ee/kit/536/chapter/29731
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.5
Topics ET: matemaatika, taim, taimed, puu, lill, inimese, elus
Topics RU: математика, растение, растения, дерево, цветок, жизни, человека, готовят, пищу, себе
Topics EN: mathematics, plant, plants, tree, flower
Headings: Растения в жизни человека; Taimed inimese elus; Растения готовят пищу себе и другим; Растения производят кислород; Растения очищают воздух и дают укрытие; Растения в качестве приправы; Растения защищают от холода; Растения лечат; Растения улучшают настроение; Я знаю, что...
Task examples: Что нужно растениям для изготовления сахара?; Какую пользу приносят растения животным и грибам?

## Животные в жизни человека
URL: https://www.opiq.ee/kit/536/chapter/29732
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.6
Topics ET: matemaatika, loom, loomad, linnud, putukad, inimese, elus
Topics RU: математика, животное, животные, птицы, насекомые, жизни, человека, дают, пищу
Topics EN: mathematics, animal, animals, birds, insects
Headings: Животные в жизни человека; Loomad inimese elus; Животные дают пищу; Из шерсти и кож животных делают одежду и обувь; Насекомые дают нам мёд и шёлк; Животное может быть другом; Животные помогают человеку; Благодаря насекомым наша пища разнообразна; Я знаю, что…
Task examples: Отметь одежду и обувь, сделанные из материалов животного происхождения.; Что из перечисленного имеет животное происхождение?

## Грибы в жизни человека
URL: https://www.opiq.ee/kit/536/chapter/29733
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.7
Topics ET: matemaatika, seened, inimese, elus
Topics RU: математика, грибы, жизни, человека, люди, собирают, дополнительный
Topics EN: mathematics
Headings: Грибы в жизни человека; Seened inimese elus; Люди собирают грибы для еды; Дополнительный материал. Знаешь ли ты эти грибы?; Люди выращивают грибы; Грибы используют при приготовлении пищи; Из плесневых грибов делают лекарства; Некоторые грибы вызывают заболевания; Грибы – разлагатели; Из грибов можно производить интересные материалы; Я знаю, что…
Task examples: Какие из лесных грибов можно употреблять в пищу?; Что нужно грибам для роста?

## Бактерии в жизни человека
URL: https://www.opiq.ee/kit/536/chapter/29734
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.8
Topics ET: matemaatika, bakterid, inimese, elus
Topics RU: математика, бактерии, жизни, человека, живут, человеке, внутри
Topics EN: mathematics
Headings: Бактерии в жизни человека; Bakterid inimese elus; Бактерии живут на человеке и внутри него; Бактерии используются при изготовлении пищи; Некоторые бактерии вызывают заболевания; Вакцинация; Лечение бактериальных заболеваний; Бактерии являются разлагателями; Бактерии очищают воду; Бактерии делают топливо; Я знаю, что…
Task examples: Почему многие бактерии для нас полезны?; При изготовлении каких продуктов используются бактерии?

## Жизнь в различных условиях
URL: https://www.opiq.ee/kit/536/chapter/29735
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 3.9
Topics ET: matemaatika, erinevates, oludes
Topics RU: математика, жизнь, различных, условиях, живые, существа, обитают, повсюду
Topics EN: mathematics
Headings: Жизнь в различных условиях; Elu erinevates oludes; Живые существа обитают повсюду; Мир разделён на природные зоны; Природные условия Эстонии; Понятия; Я знаю, что…
Task examples: Самые большие различия в условиях обитания различных уголков Земли обусловлены...; Отметь факторы окружающей среды.

## Клетки, ткани и органы
URL: https://www.opiq.ee/kit/536/chapter/29740
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.1
Topics ET: matemaatika, inimene, keha, meeled, tervis, rakud, koed, elundid
Topics RU: математика, человек, тело, чувства, здоровье, клетки, ткани, органы, чего, состоит
Topics EN: mathematics, human, body, senses, health
Headings: Клетки, ткани и органы; Rakud, koed ja elundid; Из чего состоит человек?; Как образуются клетки?; Ткань и орган; Системы органов; Понятия; Я знаю, что…
Task examples: О какой клетке идёт речь?; Из чего состоят все живые организмы, в том числе и человек?

## Органы чувств. Глаза, уши, нос и язык
URL: https://www.opiq.ee/kit/536/chapter/29749
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.10
Topics ET: matemaatika, meele, elundid, silmad, kõrvad, nina, keel
Topics RU: математика, органы, чувств, глаза, язык
Topics EN: mathematics
Headings: Органы чувств. Глаза, уши, нос и язык; Meele­elundid. Silmad, kõrvad, nina ja keel; Задачи органов чувств; Мы видим глазами; Мы слышим ушами; Обоняние позволяет чувствовать запахи; При помощи языка мы ощущаем вкус; Понятия; Я знаю, что…
Task examples: Отметь органы чувств.; Орган чувств – это ...

## Человек как единое целое
URL: https://www.opiq.ee/kit/536/chapter/29750
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.11
Topics ET: matemaatika, inimene, keha, meeled, tervis, tervik
Topics RU: математика, человек, тело, чувства, здоровье, единое, целое, размеры, частей, тела, соответствуют
Topics EN: mathematics, human, body, senses, health
Headings: Человек как единое целое; Inimene kui tervik; Размеры частей тела соответствуют друг другу; Тела работает как единое целое; Твоё тело – твой друг; Я знаю, что…
Task examples: Для чего человек использует своё тело?; Что очень нужно для игры в футбол?

## Человек – это млекопитающее
URL: https://www.opiq.ee/kit/536/chapter/29751
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.12
Topics ET: matemaatika, inimene, keha, meeled, tervis, imetaja
Topics RU: математика, человек, тело, чувства, здоровье, млекопитающее, собака, похожи, люди, человекообразные
Topics EN: mathematics, human, body, senses, health
Headings: Человек – это млекопитающее; Inimene on imetaja; Человек и собака похожи; Люди и человекообразные обезьяны имеют много общего; Человек – млекопитающее; Я знаю, что…
Task examples: Какие человекообразные обезьяны живут в Азии?; Самыми схожими с человеком животными являются...

## Происхождение человека
URL: https://www.opiq.ee/kit/536/chapter/29752
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.13
Topics ET: matemaatika, aeg, kell, kalender, inimene, keha, meeled, tervis, inimese, põlvnemine
Topics RU: математика, время, часы, календарь, человек, тело, чувства, здоровье, происхождение, человека, жизнь, развивалась, долгое
Topics EN: mathematics, time, clock, calendar, human, body, senses, health
Headings: Происхождение человека; Inimese põlvnemine; Жизнь развивалась долгое время; Человек сильно изменился; Особенности человека; Дополнительный материал. Взаимоотношения человека с природой; Я знаю, что…
Task examples: Что можно узнать, изучая древние кости?; Что отличает человека от других животных?

## Опорно-двигательная система
URL: https://www.opiq.ee/kit/536/chapter/29741
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.2
Topics ET: matemaatika, tugi, liikumis, elundkond
Topics RU: математика, опорно, двигательная, система, кости, скелет
Topics EN: mathematics
Headings: Опорно-двигательная система; Tugi- ja liikumis­elundkond; Кости и скелет; Мышцы; Дополнительный материал. Рентген; Понятия; Я знаю, что…
Task examples: Каковы функции скелета?; Какие утверждения характеризуют работу мышц, не подчиняющихся нашей воле?

## Система кровообращения
URL: https://www.opiq.ee/kit/536/chapter/29742
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.3
Topics ET: matemaatika, vereringe, elundkond
Topics RU: математика, система, кровообращения, кровообращение, кровь, понятия, знаю
Topics EN: mathematics
Headings: Система кровообращения; Vereringe­elundkond; Кровообращение; Кровь; Понятия; Я знаю, что…
Task examples: Выбери правильное понятие.; Каковы задачи клеток крови?

## Дыхательная система
URL: https://www.opiq.ee/kit/536/chapter/29743
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.4
Topics ET: matemaatika, aeg, kell, kalender, hingamis, elundkond
Topics RU: математика, время, часы, календарь, дыхательная, система, почему, дышим, происходит
Topics EN: mathematics, time, clock, calendar
Headings: Дыхательная система; Hingamis­elundkond; Почему мы дышим?; Что происходит во время дыхания?; Дополнительный материал. Курение; Понятия; Я знаю, что…
Task examples: Каковы задачи органов дыхания?

## Пищеварительная система
URL: https://www.opiq.ee/kit/536/chapter/29744
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.5
Topics ET: matemaatika, seede, elundkond
Topics RU: математика, пищеварительная, система, делают, органы, пищеварения, происходит
Topics EN: mathematics
Headings: Пищеварительная система; Seede­elundkond; Что делают органы пищеварения?; Как происходит пищеварение?; Путь пищи по телу; Понятия; Я знаю, что…
Task examples: Какова задача пищеварительной системы?; Где переваривается пища?

## Выделительная система. Избавление от ненужных веществ
URL: https://www.opiq.ee/kit/536/chapter/29745
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.6
Topics ET: matemaatika, eritus, elundkond, jääkainetest, vabanemine
Topics RU: математика, выделительная, система, избавление, ненужных, веществ
Topics EN: mathematics
Headings: Выделительная система. Избавление от ненужных веществ; Eritus­elundkond. Jääkainetest vabanemine; Что делают органы выделения?; Кожа и лёгкие; Роль кишечника; Дополнительный материал. Бактерии в кишечнике; Понятия; Я знаю, что …
Task examples: Какова задача выделительной системы?; От каких ненужных веществ нам помогают избавляться лёгкие?

## Половая система
URL: https://www.opiq.ee/kit/536/chapter/29746
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.7
Topics ET: matemaatika, sugu, elundkond
Topics RU: математика, половая, система, особенность, половой, системы, сперматозоиды, дополнительный
Topics EN: mathematics
Headings: Половая система; Sugu­elundkond; Особенность половой системы; Сперматозоиды; Дополнительный материал. Что такое поллюция?; Яйцеклетки; Начало новой жизни; Дополнительный материал. Презерватив; Как плод получает пищу и кислород?; Что происходит с неоплодотво­рён­ной яйцеклеткой?; Понятия; Я знаю, что…
Task examples: Перетащи утверждения в подходящую колонку.; В каком половом органе развивается плод?

## Нервная система. Железы
URL: https://www.opiq.ee/kit/536/chapter/29747
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.8
Topics ET: matemaatika, närvisüsteem, näärmed
Topics RU: математика, нервная, система, железы, головной, мозг, спинной
Topics EN: mathematics
Headings: Нервная система. Железы; Närvisüsteem. Näärmed; Нервная система; Головной мозг и спинной мозг; Железы; Понятия; Я знаю, что…
Task examples: Какие органы относятся к нервной системе?; Какова задача нервной системы?

## Кожа
URL: https://www.opiq.ee/kit/536/chapter/29748
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 4.9
Topics ET: matemaatika, nahk
Topics RU: математика, кожа, выполняет, несколько, задач, орган, чувств, дополнительный
Topics EN: mathematics
Headings: Кожа; Nahk; Кожа выполняет несколько задач; Кожа – орган чувств; Дополнительный материал. Как читают слепые?; Исследуй!; Понятия; Я знаю, что…
Task examples: Каковы функции кожи?; Какую информацию ты получаешь через кожу?

## Понятия
URL: https://www.opiq.ee/kit/536/chapter/29753
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 5.1
Topics ET: matemaatika
Topics RU: математика, понятия
Topics EN: mathematics
Headings: Понятия

## Impressum
URL: https://www.opiq.ee/kit/536/chapter/29754
Book: Природо­ведение для 4 класса (2023) – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: 
Book ID: природо­ведение_для_4_класса_(2023)
Chapter ID: 5.2
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum
