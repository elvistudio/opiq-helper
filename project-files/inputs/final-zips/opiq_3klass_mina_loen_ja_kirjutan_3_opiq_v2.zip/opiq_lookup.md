## Mina loen ja kirjutan 3 – Opiq
URL: https://www.opiq.ee/Kit/Details/590
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 1
Topics ET: matemaatika, mina, loen, kirjutan, opiq
Topics RU: математика
Topics EN: mathematics

## Mina loen ja kirjutan 3 – Opiq
URL: https://www.opiq.ee/Kit/Details/590
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 44
Topics ET: matemaatika, mina, loen, kirjutan, opiq
Topics RU: математика
Topics EN: mathematics

## HÄÄLIKUD JA TÄHED
URL: https://www.opiq.ee/kit/590/chapter/33253
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 1.1
Topics ET: matemaatika, häälikud, tähed
Topics RU: математика
Topics EN: mathematics
Headings: HÄÄLIKUD JA TÄHED

## TÄHESTIK
URL: https://www.opiq.ee/kit/590/chapter/33252
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 1.2
Topics ET: matemaatika, tähestik
Topics RU: математика
Topics EN: mathematics
Headings: TÄHESTIK; 1.; 2.; 3.; 4.

## a, aa
URL: https://www.opiq.ee/kit/590/chapter/33254
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: a, aa; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## TÄISHÄÄLIKUD
URL: https://www.opiq.ee/kit/590/chapter/33263
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.10
Topics ET: matemaatika, täishäälikud
Topics RU: математика
Topics EN: mathematics
Headings: TÄISHÄÄLIKUD; 1.; 2.; 3.; 4.

## TÄISHÄÄLIKUÜHEND
URL: https://www.opiq.ee/kit/590/chapter/33264
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.11
Topics ET: matemaatika, täishäälikuühend
Topics RU: математика
Topics EN: mathematics
Headings: TÄISHÄÄLIKUÜHEND; 1.; 2.

## KORDAMINE
URL: https://www.opiq.ee/kit/590/chapter/33265
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.12
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.

## e, ee
URL: https://www.opiq.ee/kit/590/chapter/33255
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: e, ee; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## i, ii
URL: https://www.opiq.ee/kit/590/chapter/33256
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: i, ii; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.

## o, oo
URL: https://www.opiq.ee/kit/590/chapter/33257
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: o, oo; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.

## u, uu
URL: https://www.opiq.ee/kit/590/chapter/33258
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: u, uu; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## õ, õõ
URL: https://www.opiq.ee/kit/590/chapter/33259
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: õ, õõ; 1.; 2.; 3.; 4.; 5.

## ä, ää
URL: https://www.opiq.ee/kit/590/chapter/33260
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: ä, ää; 1.; 2.; 3.; 4.; 5.; 6.

## ö, öö
URL: https://www.opiq.ee/kit/590/chapter/33261
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: ö, öö; 1.; 2.; 3.; 4.; 5.

## ü, üü
URL: https://www.opiq.ee/kit/590/chapter/33262
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: ü, üü; 1.; 2.; 3.; 4.; 5.; 6.

## l, ll
URL: https://www.opiq.ee/kit/590/chapter/33266
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: l, ll; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## KAASHÄÄLIKUÜHEND
URL: https://www.opiq.ee/kit/590/chapter/33275
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.10
Topics ET: matemaatika, kaashäälikuühend
Topics RU: математика
Topics EN: mathematics
Headings: KAASHÄÄLIKUÜHEND; 1.; 2.

## SILBITAMINE JA POOLITAMINE
URL: https://www.opiq.ee/kit/590/chapter/33276
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.11
Topics ET: matemaatika, silbitamine, poolitamine
Topics RU: математика
Topics EN: mathematics
Headings: SILBITAMINE JA POOLITAMINE; 1.; 2.; 3.; POOLITAMINE; 4.; 5.

## KORDAMINE
URL: https://www.opiq.ee/kit/590/chapter/33277
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.12
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.; 4.

## m, mm
URL: https://www.opiq.ee/kit/590/chapter/33267
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: m, mm; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.

## n, nn
URL: https://www.opiq.ee/kit/590/chapter/33268
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: n, nn; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.

## r, rr
URL: https://www.opiq.ee/kit/590/chapter/33269
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: r, rr; 1.; 2.; 3.; 4.; 5.

## s, ss
URL: https://www.opiq.ee/kit/590/chapter/33270
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: s, ss; 1.; 2.; 3.; 4.; 5.; 6.

## h
URL: https://www.opiq.ee/kit/590/chapter/33271
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: 1.; 2.; 3.; 4.; 5.; 6.; 7.

## v, f
URL: https://www.opiq.ee/kit/590/chapter/33272
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: v, f; 1.; 2.; 3.; 4.; 5.

## j
URL: https://www.opiq.ee/kit/590/chapter/33273
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: 1.; 2.; 3.; 4.; 5.; 6.

## KAASHÄÄLIKUD
URL: https://www.opiq.ee/kit/590/chapter/33274
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 3.9
Topics ET: matemaatika, kaashäälikud
Topics RU: математика
Topics EN: mathematics
Headings: KAASHÄÄLIKUD; 1.; 2.

## g, k, kk
URL: https://www.opiq.ee/kit/590/chapter/33278
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: g, k, kk; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## KORDAMINE: b, p, pp
URL: https://www.opiq.ee/kit/590/chapter/33287
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.10
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: b, p, pp; 1.; 2.; 3.; 4.; 5.; 6.

## d, t, tt
URL: https://www.opiq.ee/kit/590/chapter/33288
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: d, t, tt; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## d, tt
URL: https://www.opiq.ee/kit/590/chapter/33289
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.12
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: d, tt; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## d, t
URL: https://www.opiq.ee/kit/590/chapter/33290
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.13
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: d, t; 1.; 2.; 3.; 4.

## t, tt
URL: https://www.opiq.ee/kit/590/chapter/33291
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.14
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: t, tt; 1.; 2.; 3.; 4.

## KORDAMINE: d, t, tt
URL: https://www.opiq.ee/kit/590/chapter/33292
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.15
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: d, t, tt; 1.; 2.; 3.; 4.; 5.; 6.

## g, kk
URL: https://www.opiq.ee/kit/590/chapter/33279
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: g, kk; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## g, k
URL: https://www.opiq.ee/kit/590/chapter/33280
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: g, k; 1.; 2.; 3.; 4.; 5.; 6.

## k, kk
URL: https://www.opiq.ee/kit/590/chapter/33281
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: k, kk; 1.; 2.; 3.; 4.; 5.

## KORDAMINE: g, k, kk
URL: https://www.opiq.ee/kit/590/chapter/33282
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.5
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: g, k, kk; 1.; 2.; 3.; 4.; 5.; 6.

## b, p, pp
URL: https://www.opiq.ee/kit/590/chapter/33283
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: b, p, pp; 1.; 2.; 3.; 4.; 5.; 6.

## b, pp
URL: https://www.opiq.ee/kit/590/chapter/33284
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: b, pp; 1.; 2.; 3.; 4.; 5.; 6.

## b, p
URL: https://www.opiq.ee/kit/590/chapter/33285
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: b, p; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## p, pp
URL: https://www.opiq.ee/kit/590/chapter/33286
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 4.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: p, pp; 1.; 2.; 3.; 4.; 5.

## KORDAMINE
URL: https://www.opiq.ee/kit/590/chapter/33293
Book: Mina loen ja kirjutan 3 – Opiq
Class: 3
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: mina_loen_ja_kirjutan_3
Chapter ID: 5.1
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.
