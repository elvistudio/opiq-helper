## Eesti keel 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/71
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1
Topics ET: matemaatika, eesti, keel, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Eesti keel 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/71
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 137
Topics ET: matemaatika, eesti, keel, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/5570
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.1
Topics ET: matemaatika, peatüki, sissejuhatus, paneme, mõtte, tööle, arutlege, oled, väitega, nõus
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Paneme mõtte tööle; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Moodusta antud sõnadest lause.

## Reeli Reinaus, „Täiesti tavaline perekond“
URL: https://www.opiq.ee/kit/71/chapter/5579
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.10
Topics ET: matemaatika, reeli, reinaus, täiesti, tavaline, perekond, huvitavaid, fakte, blogi, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Reeli Reinaus, „Täiesti tavaline perekond“; Reeli Reinaus; Huvitavaid fakte; Blogi; Küsimused ja ülesanded; 4.; 9.; 11.

## Kuidas raamatut valida?
URL: https://www.opiq.ee/kit/71/chapter/5580
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.11
Topics ET: matemaatika, kuidas, raamatut, valida, raamatu, valimine, küsimused, raamat
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas raamatut valida?; Raamatu valimine; Küsimused ja ülesanded; d.; Mis raamat see on?; b.; c.

## Grigori Oster, „Karvased sõrmed“
URL: https://www.opiq.ee/kit/71/chapter/5581
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.12
Topics ET: matemaatika, grigori, oster, karvased, sõrmed, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Grigori Oster, „Karvased sõrmed“; Karvased sõrmed; Küsimused ja ülesanded; 3.; 4.; 7.; 8.

## Nimetused
URL: https://www.opiq.ee/kit/71/chapter/5582
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.13
Topics ET: matemaatika, nimetused, mida, näitavad, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Nimetused; Mida näitavad nimetused?; 3.; Küsimused ja ülesanded; 1.; 2.; Ül 3.; 4.

## Teeme tutvust kirjanikuga
URL: https://www.opiq.ee/kit/71/chapter/5585
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.14
Topics ET: matemaatika, teeme, tutvust, kirjanikuga, intervjuu, mika, keräneniga
Topics RU: математика
Topics EN: mathematics
Headings: Teeme tutvust kirjanikuga; Intervjuu Mika Keräneniga

## Mika Keränen, „Varastatud oranž jalgratas“
URL: https://www.opiq.ee/kit/71/chapter/5583
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.15
Topics ET: matemaatika, mika, keränen, varastatud, oranž, jalgratas, peatükk, jälitajad, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Mika Keränen, „Varastatud oranž jalgratas“; Varastatud oranž jalgratas; 5. peatükk. Jälitajad; Küsimused ja ülesanded; 4.; 7.

## Loeme luuletusi
URL: https://www.opiq.ee/kit/71/chapter/5586
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.16
Topics ET: matemaatika, loeme, luuletusi, kuidas, lugeda, luuletust, mutikas, esitada, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Loeme luuletusi; Kuidas lugeda luuletust; Mutikas; Kuidas luuletust esitada; Küsimused ja ülesanded

## Leelo Tungal
URL: https://www.opiq.ee/kit/71/chapter/5587
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.17
Topics ET: matemaatika, leelo, tungal, kolm, sõpra, neljajalgne, pille, tiiu, tüli, trennist
Topics RU: математика
Topics EN: mathematics
Headings: Leelo Tungal; Kolm sõpra ja neljajalgne; Pille ja Tiiu; C.; Tüli; Trennist tulles; E.; Küsimused ja ülesanded

## Peatüki kokkuvõte
URL: https://www.opiq.ee/kit/71/chapter/5584
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.18
Topics ET: matemaatika, peatüki, kokkuvõte, paneme, mõtte, tööle, raamatu, tutvustus
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki kokkuvõte; Paneme mõtte tööle; Raamatu tutvustus

## Voldemar Miller, „Raamatud omavahel“
URL: https://www.opiq.ee/kit/71/chapter/5571
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.2
Topics ET: matemaatika, voldemar, miller, raamatud, omavahel, jutu, tegelased, mille, vaidlevad, lasteraamatu
Topics RU: математика
Topics EN: mathematics
Headings: Voldemar Miller, „Raamatud omavahel“; Raamatud omavahel; 1. Kes on jutu tegelased?; 2. Mille üle nad vaidlevad?; 3. Lasteraamatu tähtsus; 4. Mis on rariteet?; Küsimused ja ülesanded; 4. Mida need laused tähendavad?

## Kordame tähestikku
URL: https://www.opiq.ee/kit/71/chapter/5572
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.3
Topics ET: matemaatika, kordame, tähestikku, tekst, läbi, täida, eesti, tähestik, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Kordame tähestikku; Loe tekst läbi ja täida ülesanded; Eesti tähestik; Küsimused ja ülesanded; 2. Järjesta tähed; 1. Mitu tähte on tähestikus?; 4. Salakiri; 3. Lõpeta tähestik; 5. Mitmendas köites?; 6. Ogam-kiri

## Raamatute maailm
URL: https://www.opiq.ee/kit/71/chapter/5573
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.4
Topics ET: matemaatika, raamatute, maailm, kirjandus, teabekirjandus, küsimused, teabekirjanduse, eesmärk, raamatud
Topics RU: математика
Topics EN: mathematics
Headings: Raamatute maailm; Mis on kirjandus?; 1. Ilu- või teabekirjandus? (d); 1. Ilu- või teabekirjandus? (a); 1. Ilu- või teabekirjandus? (b); 1. Ilu- või teabekirjandus? (c); Küsimused ja ülesanded; 1. Ilu- ja teabekirjanduse eesmärk; 2. „Raamatud omavahel“; 3. Loetud raamatud; 5. Ilu- või teabekirjandus?; 4. Ilu- või teabekirjandus?; 6. Kumb pilt sobib?; 5. Kumb pilt sobib?

## Jüri Parijõgi, „Kui isa kinkis raamatuid“
URL: https://www.opiq.ee/kit/71/chapter/5574
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.5
Topics ET: matemaatika, jüri, parijõgi, kinkis, raamatuid, küsimused, selle, tegelased, teile
Topics RU: математика
Topics EN: mathematics
Headings: Jüri Parijõgi, „Kui isa kinkis raamatuid“; Jüri Parijõgi; Kui isa kinkis raamatuid; Küsimused ja ülesanded; Kes on selle loo tegelased?; Mis teile kuulub?; Lapsed ja raamatud

## Pealkirjad
URL: https://www.opiq.ee/kit/71/chapter/5575
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.6
Topics ET: matemaatika, pealkirjad, jutumärgid, suur, algustäht, mõtle, igasse, rühma, veel, kaks
Topics RU: математика
Topics EN: mathematics
Headings: Pealkirjad; Jutumärgid ja suur algustäht; 1. Mõtle igasse rühma veel kaks näidet; Küsimused ja ülesanded; 1. Leia pealkirjad; 2. Segamini tähed; 3. Pealkirjaga lause

## Kuidas juttu lugeda
URL: https://www.opiq.ee/kit/71/chapter/5576
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.7
Topics ET: matemaatika, kuidas, juttu, lugeda, uuri, esita, küsimusi, mõtle, järele, kukk
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas juttu lugeda; Uuri, esita küsimusi, mõtle järele; Kukk ja rebane; Küsimused ja ülesanded; 3. Kui kaua võis loo tegevus kesta?; 1. Kes on selle loo tegelased?; 2. Kus tegevus toimub?; 5. Kuidas olukord laheneb?; 4. Milline mure on Kukeleegul?; 6. Rebase ja Kukeleegu iseloomustus; 7. Ümberjutustus; 8. Kirjuta lugu

## Louis Sachar, „Naerurull, piripill ja udupasun“
URL: https://www.opiq.ee/kit/71/chapter/5577
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.8
Topics ET: matemaatika, louis, sachar, naerurull, piripill, udupasun, huvitavaid, fakte, miks, meeldi
Topics RU: математика
Topics EN: mathematics
Headings: Louis Sachar, „Naerurull, piripill ja udupasun“; Louis Sachar; Huvitavaid fakte; Naerurull, piripill ja udupasun; 1. Miks ei meeldi Danale raamatute ettelugemine?; 2. Loomajutud; 3. Mida Dana tegelikult raamatute vastu tundis?; Küsimused ja ülesanded; 3. Udupasun; 1. Naerurull; 2. Piripill; 4. Proua Pärl; 5. Dana ja John

## Nimed
URL: https://www.opiq.ee/kit/71/chapter/5578
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 1.9
Topics ET: matemaatika, nimed, suur, algustäht, täida, lüngad, küsimused, kuidas, eestlased
Topics RU: математика
Topics EN: mathematics
Headings: Nimed; Suur algustäht; Täida lüngad II; Täida lüngad I; Küsimused ja ülesanded; 1. Kuidas eestlased perekonnanimed said; 2. Sõit läbi Eestimaa; 3. Kirjuta õigesti

## Mõisted
URL: https://www.opiq.ee/kit/71/chapter/5569
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 10.1
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/71/chapter/3494
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 10.2
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/5859
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.1
Topics ET: matemaatika, peatüki, sissejuhatus, teabetekstide, kosmoses
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Teabetekstide kosmoses; 1.

## Helju Rammo, „Oma arvamus“
URL: https://www.opiq.ee/kit/71/chapter/5854
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.10
Topics ET: matemaatika, helju, rammo, arvamus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Helju Rammo, „Oma arvamus“; Helju Rammo; Oma arvamus; Küsimused ja ülesanded; 1.; 4.; 8.

## Fakt ja arvamus
URL: https://www.opiq.ee/kit/71/chapter/5855
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.11
Topics ET: matemaatika, fakt, arvamus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Fakt ja arvamus; Küsimused ja ülesanded; 1.; 2a; 2b; 2c; 2d; 2e

## Ilmar Tomusk, „Johannese oratoorium“
URL: https://www.opiq.ee/kit/71/chapter/5856
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.12
Topics ET: matemaatika, ilmar, tomusk, johannese, oratoorium, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Ilmar Tomusk, „Johannese oratoorium“; Ilmar Tomusk; Johannese oratoorium; Küsimused ja ülesanded; 6.

## Arvamuse avaldamine
URL: https://www.opiq.ee/kit/71/chapter/5857
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.13
Topics ET: matemaatika, arvamuse, avaldamine, kuidas, arvamust, väljendada, vestlemisel, meeles, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Arvamuse avaldamine; Kuidas arvamust väljendada?; Vestlemisel pea meeles!; Küsimused ja ülesanded; 1.; 2.; 3.; 4.

## Luuletusi muusikast ja kosmosest
URL: https://www.opiq.ee/kit/71/chapter/5860
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.14
Topics ET: matemaatika, luuletusi, muusikast, kosmosest, klaverikontsert, seisukoht, teekond, tähtede, juurde, kosmose
Topics RU: математика
Topics EN: mathematics
Headings: Luuletusi muusikast ja kosmosest; Klaverikontsert; 1.; Seisukoht; Teekond tähtede juurde; 2.; Kosmose jõgi on taevas; Kuu; 5.; 4.; Küsimused ja ülesanded

## Peatüki kokkuvõte. Minientsüklopeedia koostamine
URL: https://www.opiq.ee/kit/71/chapter/5858
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.15
Topics ET: matemaatika, peatüki, kokkuvõte, minientsüklopeedia, koostamine, rühmatöö, tund
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki kokkuvõte. Minientsüklopeedia koostamine; Rühmatöö; 1. tund; 2. tund

## Aino Pervik, „Härra LugemisHull“
URL: https://www.opiq.ee/kit/71/chapter/5846
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.2
Topics ET: matemaatika, aino, pervik, härra, lugemishull, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Aino Pervik, „Härra LugemisHull“; Aino Pervik; Härra LugemisHull; Küsimused ja ülesanded; 2.; 7.

## Teabekirjanduse liigid
URL: https://www.opiq.ee/kit/71/chapter/5847
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.3
Topics ET: matemaatika, teabekirjanduse, liigid, teabetekstid, mida, saab, teada, teabetekstidest, sõnaraamatud, aimekirjandus
Topics RU: математика
Topics EN: mathematics
Headings: Teabekirjanduse liigid; Teabetekstid; Mida saab teada teabetekstidest?; A. Sõnaraamatud; B. Aimekirjandus; C. Entsüklopeedia; Küsimused ja ülesanded; 2.; 3.; 4.

## Lucy ja Stephen Hawking, „Georg ja universumi salavõti“
URL: https://www.opiq.ee/kit/71/chapter/5848
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.4
Topics ET: matemaatika, lucy, stephen, hawking, georg, universumi, salavõti, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Lucy ja Stephen Hawking, „Georg ja universumi salavõti“; Lucy ja Stephen Hawking; Georg ja universumi salavõti; Küsimused ja ülesanded; 6.; 10.; 14.

## Poolitamine
URL: https://www.opiq.ee/kit/71/chapter/5849
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.5
Topics ET: matemaatika, poolitamine, tekstiga, silbitamine, harjutus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Poolitamine; Töö tekstiga; Silbitamine ja poolitamine; Silbitamine; Harjutus; Küsimused ja ülesanded; 1.; 2.; 3.

## Markus Saksatamm, „Külaline saabub“
URL: https://www.opiq.ee/kit/71/chapter/5850
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.6
Topics ET: matemaatika, markus, saksatamm, külaline, saabub, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Markus Saksatamm, „Külaline saabub“; Markus Saksatamm; Külaline saabub; Küsimused ja ülesanded; 5.

## Sõnaraamatute kasutamine
URL: https://www.opiq.ee/kit/71/chapter/5851
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.7
Topics ET: matemaatika, sõnaraamatute, kasutamine, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaraamatute kasutamine; Küsimused ja ülesanded; 1.; 2.; 3.

## Kuidas teabeteksti lugeda
URL: https://www.opiq.ee/kit/71/chapter/5852
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.8
Topics ET: matemaatika, kuidas, teabeteksti, lugeda, tuvipost, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas teabeteksti lugeda; Kuidas teabeteksti lugeda?; Tuvipost; Küsimused ja ülesanded; 5.

## Lühendid
URL: https://www.opiq.ee/kit/71/chapter/5853
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 2.9
Topics ET: matemaatika, lühendid, lühend, üldkasutatavad, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Lühendid; Mis on lühend?; Üldkasutatavad lühendid; Küsimused ja ülesanded; 1.; 2.; 3.

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/6573
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.1
Topics ET: matemaatika, peatüki, sissejuhatus, lähme, raamatukokku
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Lähme raamatukokku; 3.

## Lemony Snicket, „Ahastav algus“
URL: https://www.opiq.ee/kit/71/chapter/6814
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.10
Topics ET: matemaatika, lemony, snicket, ahastav, algus, küsimused, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Lemony Snicket, „Ahastav algus“; Lemony Snicket; Ahastav algus; Küsimused ja ülesanded; Harjutus 1; Harjutus 2

## Kaashäälikuühend
URL: https://www.opiq.ee/kit/71/chapter/6815
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.11
Topics ET: matemaatika, kaashäälikuühend, teksti, täida, küsimused, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kaashäälikuühend; Loe teksti ja täida ülesanded; 1.; Küsimused ja ülesanded; Ül 1; Harjutus; 2.

## Siiri Laidla, „Nõiatembud raamatukogus“
URL: https://www.opiq.ee/kit/71/chapter/6816
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.12
Topics ET: matemaatika, siiri, laidla, nõiatembud, raamatukogus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Siiri Laidla, „Nõiatembud raamatukogus“; Siiri Laidla; Nõiatembud raamatukogus; Küsimused ja ülesanded; 4.; 7.

## i ja j-i õigekiri
URL: https://www.opiq.ee/kit/71/chapter/6817
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.13
Topics ET: matemaatika, õigekiri, milline, vanasõna, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: i ja j-i õigekiri; Milline vanasõna; Ül 1; Küsimused ja ülesanded; 1.; 2.; 3.; 4.

## Luuletusi lugemisest ja elutarkusest
URL: https://www.opiq.ee/kit/71/chapter/6818
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.14
Topics ET: matemaatika, luuletusi, lugemisest, elutarkusest, raamatukoi, tähenärija, aedviljasupp, kokaraamatust, kiire
Topics RU: математика
Topics EN: mathematics
Headings: Luuletusi lugemisest ja elutarkusest; Raamatukoi tähenärija; Aedviljasupp kokaraamatust; Kiire

## Peatüki kokkuvõte. Õppekäik raamatukokku
URL: https://www.opiq.ee/kit/71/chapter/6819
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.15
Topics ET: matemaatika, peatüki, kokkuvõte, õppekäik, raamatukokku, paaristöö, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki kokkuvõte. Õppekäik raamatukokku; Paaristöö; Harjutus

## Roald Dahl, „Matilda – raamatuneelaja“
URL: https://www.opiq.ee/kit/71/chapter/6568
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.2
Topics ET: matemaatika, roald, dahl, matilda, raamatuneelaja, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Roald Dahl, „Matilda – raamatuneelaja“; Roald Dahl; Matilda – raamatuneelaja; Küsimused ja ülesanded; 1.; 5.

## Raamatukogud
URL: https://www.opiq.ee/kit/71/chapter/6569
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.3
Topics ET: matemaatika, raamatukogud, eestis, mujal, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Raamatukogud; Raamatukogud Eestis ja mujal; Küsimused ja ülesanded; 6.

## Juhan Saar, „Kaks hobust“
URL: https://www.opiq.ee/kit/71/chapter/6570
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.4
Topics ET: matemaatika, juhan, saar, kaks, hobust, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Juhan Saar, „Kaks hobust“; Juhan Saar; KAKS HOBUST; Küsimused ja ülesanded; 1.; 2.; 3.

## Õige keel ja ilus keel
URL: https://www.opiq.ee/kit/71/chapter/6571
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.5
Topics ET: matemaatika, õige, keel, ilus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Õige keel ja ilus keel; Küsimused ja ülesanded; 1.; 4.
Task examples: 2. Kirjuta ameteid, kus õige ja ilus keel on eriti oluline. Põhjenda oma arvamust.; 3. Loe läbi järgmised tekstilõigud. Kõik need räägivad ühest ja samast, kuid on kirja pandud erinevalt. Milline lõik meeldib sulle kõige rohkem ja milline kõige vähem? Põhjenda oma arvamust. Leia tekstist ilmekaid sõnu j

## Helilised ja helitud häälikud. -ki ja -gi
URL: https://www.opiq.ee/kit/71/chapter/6572
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.6
Topics ET: matemaatika, helilised, helitud, häälikud, kaunimad, sõnad, harjutus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Helilised ja helitud häälikud. -ki ja -gi; Kaunimad sõnad; Helilised ja helitud häälikud; Harjutus 1; -ki ja -gi; Harjutus 2; Küsimused ja ülesanded; Harjutus 3; Harjutus 4; Harjutus 5; Harjutus 6; Harjutus 7; Harjutus 8

## Alan Alexander Milne, „Neljas peatükk, kus Iiah kaotab ja Puhh leiab ühe saba“
URL: https://www.opiq.ee/kit/71/chapter/6811
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.7
Topics ET: matemaatika, alan, alexander, milne, neljas, peatükk, iiah, kaotab, puhh, leiab, saba
Topics RU: математика
Topics EN: mathematics
Headings: Alan Alexander Milne, „Neljas peatükk, kus Iiah kaotab ja Puhh leiab ühe saba“; Alan Alexander Milne; NELJAS PEATÜKK, kus Iiah kaotab ja Puhh leiab ühe saba; Küsimused ja ülesanded; Harjutus 1; Harjutus 2; 4.; 7.; 10.

## Helitu hääliku naabrid
URL: https://www.opiq.ee/kit/71/chapter/6812
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.8
Topics ET: matemaatika, helitu, hääliku, naabrid, harjutus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Helitu hääliku naabrid; Harjutus 1; Küsimused ja ülesanded; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5

## Kuidas raamatukogu kasutada
URL: https://www.opiq.ee/kit/71/chapter/6813
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 3.9
Topics ET: matemaatika, kuidas, raamatukogu, kasutada, harjutus, kataloog, ester, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas raamatukogu kasutada; Harjutus 1; E-kataloog ESTER; Küsimused ja ülesanded; Harjutus 2

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/6936
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.1
Topics ET: matemaatika, peatüki, sissejuhatus, infot, otsimas
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Infot otsimas; Ül

## Piret Raud, „Lemmikloomapäev“
URL: https://www.opiq.ee/kit/71/chapter/7652
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.10
Topics ET: matemaatika, piret, raud, lemmikloomapäev, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Piret Raud, „Lemmikloomapäev“; Piret Raud; Lemmikloomapäev; Küsimused ja ülesanded

## Jõulumeeleolus I
URL: https://www.opiq.ee/kit/71/chapter/7653
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.11
Topics ET: matemaatika, jõulumeeleolus, õunad, linnukeste, jõululaul, kiri, jõuluvanale
Topics RU: математика
Topics EN: mathematics
Headings: Jõulumeeleolus I; Õunad; Linnukeste jõululaul; Kiri jõuluvanale

## Jõulumeeleolus II
URL: https://www.opiq.ee/kit/71/chapter/7654
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.12
Topics ET: matemaatika, jõulumeeleolus, sven, nordqvist, pettsoni, jõulud, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Jõulumeeleolus II; Sven Nordqvist; Pettsoni jõulud; Küsimused ja ülesanded

## Jõulumeeleolus III
URL: https://www.opiq.ee/kit/71/chapter/7655
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.13
Topics ET: matemaatika, jõulumeeleolus, aasta
Topics RU: математика
Topics EN: mathematics
Headings: Jõulumeeleolus III; Aasta; Uus aasta

## Jõulumeeleolus IV
URL: https://www.opiq.ee/kit/71/chapter/7656
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.14
Topics ET: matemaatika, jõulumeeleolus, josef, apek, näärid, tahtnud, tulla, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Jõulumeeleolus IV; Josef Čapek; Kui näärid ei tahtnud tulla; Küsimused ja ülesanded

## Peatüki kokkuvõte. Referaat
URL: https://www.opiq.ee/kit/71/chapter/7657
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.15
Topics ET: matemaatika, peatüki, kokkuvõte, referaat, referaadi, kirjutamine, kuidas, kirjutada, referaati
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki kokkuvõte. Referaat; Referaadi kirjutamine; Kuidas kirjutada referaati

## Kalju Saaber, „Eesli silmanägemine“
URL: https://www.opiq.ee/kit/71/chapter/6932
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.2
Topics ET: matemaatika, kalju, saaber, eesli, silmanägemine, küsimused, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kalju Saaber, „Eesli silmanägemine“; Kalju Saaber; Eesli silmanägemine; Küsimused ja ülesanded; Harjutus

## Nimisõnad
URL: https://www.opiq.ee/kit/71/chapter/6933
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.3
Topics ET: matemaatika, liitmine, liida, summa, kokku, nimisõnad, nimisõnade, lahkukirjutamine, küsimused, harjutus
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Nimisõnad; Nimisõnade kokku- ja lahkukirjutamine; Küsimused ja ülesanded; Harjutus 1; Harjutus 2; Harjutus 3

## Astrid Reinla, „Tagasi kodus“
URL: https://www.opiq.ee/kit/71/chapter/6934
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.4
Topics ET: matemaatika, astrid, reinla, tagasi, kodus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Astrid Reinla, „Tagasi kodus“; Astrid Reinla; Tagasi kodus; Küsimused ja ülesanded

## Raamat infoallikana – sisukord ja aineregister
URL: https://www.opiq.ee/kit/71/chapter/6935
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.5
Topics ET: matemaatika, raamat, infoallikana, sisukord, aineregister, kuidas, leida, infot, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Raamat infoallikana – sisukord ja aineregister; Kuidas leida infot; Küsimused ja ülesanded

## Omadussõnad
URL: https://www.opiq.ee/kit/71/chapter/7648
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.6
Topics ET: matemaatika, liitmine, liida, summa, kokku, omadussõnad, omadussõnade, lahkukirjutamine, küsimused, harjutus
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Omadussõnad; Omadussõnade kokku-lahkukirjutamine; Küsimused ja ülesanded; Harjutus 2; Harjutus 4; Harjutus 5; Harjutus 6
Task examples: 2. Mõelge pinginaabriga võimalikult palju värvust, kuju, suurust, iseloomu ja vanust väljendavaid omadussõnu, mida saab kasutada lemmikloomade kirjeldamiseks.

## Wimberg, „Arvutihullud“
URL: https://www.opiq.ee/kit/71/chapter/7649
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.7
Topics ET: matemaatika, wimberg, arvutihullud, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Wimberg, „Arvutihullud“; Wimberg; Arvutihullud; Küsimused ja ülesanded

## Internet infoallikana
URL: https://www.opiq.ee/kit/71/chapter/7650
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.8
Topics ET: matemaatika, internet, infoallikana, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Internet infoallikana; Küsimused ja ülesanded

## Arvsõnad
URL: https://www.opiq.ee/kit/71/chapter/7651
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 4.9
Topics ET: matemaatika, liitmine, liida, summa, kokku, arvsõnad, arvsõnade, lahkukirjutamine, harjutus, küsimused
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Arvsõnad; Arvsõnade kokku-lahkukirjutamine; Harjutus; Küsimused ja ülesanded
Task examples: 1. Lõpeta arvsõnade kokku-lahkukirjutamise reegel.; 2. Kirjuta raamatute pealkirjad nii, et asendad arvud arvsõnadega.

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/3819
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.1
Topics ET: matemaatika, peatüki, sissejuhatus, paneme, mõtte, tööle, arutlege, oled, väitega, nõus
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Paneme mõtte tööle; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda suuliselt.; 3. Moodusta antud sõnadest lause. Nimeta lauses olevad tegusõnad.

## Olevik ja minevik
URL: https://www.opiq.ee/kit/71/chapter/3828
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.10
Topics ET: matemaatika, olevik, minevik, tegevus, lõpetatud, kestab, veel, pööra, olevikus, lihtminevikus
Topics RU: математика
Topics EN: mathematics
Headings: Olevik ja minevik; Kas tegevus on lõpetatud või kestab veel?; 2. Pööra olevikus ja lihtminevikus; 1. Pööra olevikus ja lihtminevikus; 3. Vali õige variant; 4. Moodusta lihtminevik ja nimeta pööre; Küsimused ja ülesanded; 1. Loe tekst läbi ja vasta küsimustele; 3. Tegusõnu õiges vormis; 2. Tegusõnu õiges vormis; 4. Lugu minevikust

## Elar Kuus, „Masina jalad“
URL: https://www.opiq.ee/kit/71/chapter/3578
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.11
Topics ET: matemaatika, elar, kuus, masina, jalad, mida, pidasid, lapsed, masinaks, nimetati
Topics RU: математика
Topics EN: mathematics
Headings: Elar Kuus, „Masina jalad“; Elar Kuus; Masina jalad; 3. Mida pidasid lapsed masinaks?; 2. Mida nimetati masinaks?; Küsimused ja ülesanded; 5. Kokkuvõte; 4. Loo peategelased

## Tegevuskoht
URL: https://www.opiq.ee/kit/71/chapter/3579
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.12
Topics ET: matemaatika, tegevuskoht, koht, tegevus, tihedalt, toimub, tegevuspaigad, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Tegevuskoht; Koht ja tegevus on tihedalt seotud; Ül 3; Ül 1; Ül 2; 2. Kus toimub tegevus?; 3. Eri tegevuspaigad; Küsimused ja ülesanded

## C. S. Lewis, „Lõvi, Nõid ja riidekapp“
URL: https://www.opiq.ee/kit/71/chapter/3580
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.13
Topics ET: matemaatika, lewis, lõvi, nõid, riidekapp, clive, staples, lucy, kiikab, kapiuksest
Topics RU: математика
Topics EN: mathematics
Headings: C. S. Lewis, „Lõvi, Nõid ja riidekapp“; Clive Staples Lewis; Lucy kiikab kapiuksest sisse; Küsimused ja ülesanded; 2. Paranda kavapunktid; 1. Kes on katkendi peategelane?; 3. Illustratsioon ja kujutluspilt; 5. Miks hakkasid lapsed maja uurima? (Märgi kõik sobivad vastused.); 4. Miks saadeti lapsed Professori juurde?

## Eitus ja jaatus
URL: https://www.opiq.ee/kit/71/chapter/3581
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.14
Topics ET: matemaatika, eitus, jaatus, eitav, jaatav, kõne, jutusta, pildil, kujutatud, sündmusest
Topics RU: математика
Topics EN: mathematics
Headings: Eitus ja jaatus; Mis on eitav ja jaatav kõne?; 2. Jutusta pildil kujutatud sündmusest; 1. Moodusta tegusõnadest eitava kõne vormid; Küsimused ja ülesanded; 1. Eitava kõne leidmine; 2. Värvide nimetused eesti keeles; 3. Meelespea

## Eleanor Farjeon, „Daami tuba“
URL: https://www.opiq.ee/kit/71/chapter/3582
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.15
Topics ET: matemaatika, eleanor, farjeon, daami, tuba, küsimused, kava, lõpetamine, tegevus
Topics RU: математика
Topics EN: mathematics
Headings: Eleanor Farjeon, „Daami tuba“; Eleanor Farjeon; Daami tuba; Küsimused ja ülesanded; 1. Kava lõpetamine; 2. Kas tegevus toimus või ei?

## Toredaid luuletusi
URL: https://www.opiq.ee/kit/71/chapter/3584
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.16
Topics ET: matemaatika, toredaid, luuletusi, talve, mure, minevik, tulevik, vanaema, jutud, vanaisa
Topics RU: математика
Topics EN: mathematics
Headings: Toredaid luuletusi; Talve mure; Minevik ja tulevik; Vanaema jutud; Vanaisa

## Peatüki kokkuvõte. Teose analüüs
URL: https://www.opiq.ee/kit/71/chapter/3583
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.17
Topics ET: matemaatika, peatüki, kokkuvõte, teose, analüüs, täida
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki kokkuvõte. Teose analüüs; Täida ülesanded

## Tegelased
URL: https://www.opiq.ee/kit/71/chapter/3820
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.2
Topics ET: matemaatika, tegelased, tegelase, roll, raamatus, tunned, tegelast, meenuta, tegelasi, paku
Topics RU: математика
Topics EN: mathematics
Headings: Tegelased; Tegelase roll raamatus; 1. Kas tunned tegelast?; 2. Meenuta tegelasi; 3. Paku tegelasi; Küsimused ja ülesanded

## Astrid Lindgren, „Rasmus, Pontus ja Lontu“
URL: https://www.opiq.ee/kit/71/chapter/3821
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, astrid, lindgren, rasmus, pontus, lontu, milline, naine, jupsakas, millele
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Astrid Lindgren, „Rasmus, Pontus ja Lontu“; Astrid Lindgren; Rasmus, Pontus ja Lontu; 1. Milline naine on jupsakas?; 2. Millele kulus suurem osa Rasmuse ja Pontuse rahast?; Küsimused ja ülesanded; 11. Arutage pinginaabriga; 8. Milline pealkiri sobiks katkendile?; 9. Tegelased; 10. Poole hinnaga sisse?

## Loo tegevus ehk sündmustik
URL: https://www.opiq.ee/kit/71/chapter/3822
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.4
Topics ET: matemaatika, tegevus, sündmustik, igal, lool, algus, keskpaik, lõpp, läbi, sissejuhatused
Topics RU: математика
Topics EN: mathematics
Headings: Loo tegevus ehk sündmustik; Igal lool on algus, keskpaik ja lõpp; Loe läbi sissejuhatused ja täida ülesanded

## Jaak Kõdar, „Hunt ja rebane suusatamas“
URL: https://www.opiq.ee/kit/71/chapter/3823
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.5
Topics ET: matemaatika, jaak, kõdar, hunt, rebane, suusatamas, küsimused, millise, tegi
Topics RU: математика
Topics EN: mathematics
Headings: Jaak Kõdar, „Hunt ja rebane suusatamas“; Jaak Kõdar; Hunt ja rebane suusatamas; Küsimused ja ülesanded; 4. Millise vea tegi hunt pikka võistlusrada läbides?; 1. Peategelased; 2. Millest lugu räägib?; 3. Teemaarendus; 5. Kumb tegevus on tähtsam?; 6. Aruta järgmisi küsimusi pinginaabriga

## Tegusõna pöörded
URL: https://www.opiq.ee/kit/71/chapter/3824
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.6
Topics ET: matemaatika, tegusõna, pöörded, sõnad, väljendavad, tegevust, küsimused, täida, tabel
Topics RU: математика
Topics EN: mathematics
Headings: Tegusõna pöörded; Sõnad, mis väljendavad tegevust; Ül 2; Ül 1; Ül 3; Ül 5; Ül 4; Küsimused ja ülesanded; 3. Täida tabel; 1. Täida tabel; 2. Täida tabel; 4. Leia tegusõnad

## Hille Karm, „Kuidas minu kuldnokk ära lendas“
URL: https://www.opiq.ee/kit/71/chapter/3825
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.7
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, hille, karm, kuidas, kuldnokk, lendas, mille, poolest, eriline
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Hille Karm, „Kuidas minu kuldnokk ära lendas“; Hille Karm; Kuidas minu kuldnokk ära lendas; 1. Mille poolest oli see kevad eriline?; 2. Mis juhtus kuldnokkadega, kui läks külmaks?; 3. Miks kuldnokk ära lendas?; Küsimused ja ülesanded

## Tegevusaeg
URL: https://www.opiq.ee/kit/71/chapter/3826
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.8
Topics ET: matemaatika, tegevusaeg, minevik, olevik, tulevik, küsimused, kindlaks
Topics RU: математика
Topics EN: mathematics
Headings: Tegevusaeg; Minevik, olevik või tulevik?; Ül 4; Ül 1; Ül 2; Ül 3; Küsimused ja ülesanded; 1. Tee kindlaks tegevusaeg

## Gianni Rodari, „Õppekaramell“
URL: https://www.opiq.ee/kit/71/chapter/3827
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 5.9
Topics ET: matemaatika, gianni, rodari, õppekaramell, kuidas, omandatakse, planeedil, uusi, teadmisi, mille
Topics RU: математика
Topics EN: mathematics
Headings: Gianni Rodari, „Õppekaramell“; Gianni Rodari; Õppekaramell; 1. Kuidas omandatakse planeedil Bih uusi teadmisi?; 2. Mille poolest on elu planeedil Bih erinev elust Maal?; 3. Tõlgi ja esita salm; Küsimused ja ülesanded; 4. Täida lüngad

## Sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/3492
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.1
Topics ET: matemaatika, sissejuhatus, paneme, mõtte, tööle, arutlege, oled, väitega, nõus, mitte
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus; Paneme mõtte tööle; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda suuliselt.; 3. Täringumäng

## Jutu ülesehitus
URL: https://www.opiq.ee/kit/71/chapter/3488
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.10
Topics ET: matemaatika, geomeetria, kujund, kujundid, sirge, lõik, jutu, ülesehitus, kolm, milline, sobib, koolitee, lõpetuseks, sobi
Topics RU: математика, геометрия, фигура, фигуры, прямая, отрезок
Topics EN: mathematics, geometry, shape, shapes, line, segment
Headings: Jutu ülesehitus; Ühe loo kolm osa; Milline lõik sobib loo „Minu koolitee” lõpetuseks?; Milline lõik ei sobi loo „Minu koolitee“ sissejuhatuseks?; Loo „Minu koolitee“ kavapunktid; Sassis lugu; Sissejuhatusega sobiv pealkiri; Sissejuhatus või lõpetus?; Loe ja arutle; Kuninganna Anni kevadeigatsus; Pane kavapunktid õigesse järjekorda; Mitmest lõigust koosneb teemaarendus?; Metsas

## Contra, „Presidendi suur saladus“
URL: https://www.opiq.ee/kit/71/chapter/3489
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.11
Topics ET: matemaatika, contra, presidendi, suur, saladus, keda, nimetatakse, loos, tähtsateks, ninadeks
Topics RU: математика
Topics EN: mathematics
Headings: Contra, „Presidendi suur saladus“; Contra; Presidendi suur saladus; Keda nimetatakse loos tähtsateks ninadeks? Miks?; Millist väljendit kasutab Kornelius Sähka auto kohta?; Mis toimus Suurevarba koolis internetipunkti avamise ajal?; Küsimused ja ülesanedd; 1. Vanarahva tarkus; 2. Loe tekstid läbi ja täida ülesanded; 3. Kirjuta kõne

## Andrus Kivirähk, „President kinnas“
URL: https://www.opiq.ee/kit/71/chapter/3490
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.12
Topics ET: matemaatika, andrus, kivirähk, president, kinnas, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Andrus Kivirähk, „President kinnas“; Andrus Kivirähk; President kinnas; Küsimused ja ülesanded

## Isamaalisi luuletusi
URL: https://www.opiq.ee/kit/71/chapter/3493
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.13
Topics ET: matemaatika, isamaalisi, luuletusi, palju, õnne, eesti, väike, eestimaa, vabariigi, sünnipäev
Topics RU: математика
Topics EN: mathematics
Headings: Isamaalisi luuletusi; Palju õnne, Eesti!; See väike maa; Eestimaa; Eesti vabariigi sünnipäev; Rahvuslind; Maateadus; Küsimused ja ülesanded

## Kokkuvõte. Kuidas valmib hea lugu?
URL: https://www.opiq.ee/kit/71/chapter/3491
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.14
Topics ET: matemaatika, kokkuvõte, kuidas, valmib, lugu, jutt, sammhaaval, vali, teema, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Kuidas valmib hea lugu?; Jutt valmib sammhaaval; Vali teema ja kirjuta jutt. Pealkirja võid mõelda ise.; 1. Teema mõistmine; 2. Mõtete kogumine; 3. Kava koostamine; 4. Pealkirja leidmine; 5. Kirjutamine; 6. Mustandi parandamine; 7. Ümberkirjutamine; 8. Valmis!

## Voldemar Miller, „Delfiin“
URL: https://www.opiq.ee/kit/71/chapter/3480
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.2
Topics ET: matemaatika, voldemar, miller, delfiin, küsi, lase, vastata, kavapunktide, õige, järjekord
Topics RU: математика
Topics EN: mathematics
Headings: Voldemar Miller, „Delfiin“; Voldemar Miller; Delfiin; Küsi ja lase vastata; Kavapunktide õige järjekord; Küsimused ja ülesanded; Vali õige seletus 3; Vali õige seletus 1; Vali õige seletus 2

## Võtame loo lühidalt kokku
URL: https://www.opiq.ee/kit/71/chapter/3481
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.3
Topics ET: matemaatika, liitmine, liida, summa, kokku, võtame, lühidalt, loetust, tuleb, saada, nüüd, võta, loetu
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Võtame loo lühidalt kokku; Loetust tuleb aru saada; Nüüd võta loetu 1–2 lausega kokku.; Küsimused ja ülesanded

## Mis on lause?
URL: https://www.opiq.ee/kit/71/chapter/3482
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.4
Topics ET: matemaatika, lause, miks, meri, soolane, uuri, need, sõnajärjendid, laused, sõnade
Topics RU: математика
Topics EN: mathematics
Headings: Mis on lause?; Mis on ja mis ei ole lause?; Miks meri on soolane; Uuri, miks need sõnajärjendid ei ole laused; Sõnade õige järjekord; Lause või mitte? (2. osa); Lause või mitte?; Sama mõte, erinevad laused (2. osa); Sama mõte, erinevad laused; Küsimused ja ülesanded; Nurk

## Kuidas lugu ümber jutustada
URL: https://www.opiq.ee/kit/71/chapter/3483
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.5
Topics ET: matemaatika, kuidas, lugu, ümber, jutustada, ümberjutustuses, keskendume, tähtsaimale, peaasi, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas lugu ümber jutustada; Ümberjutustuses keskendume tähtsaimale; Pea on peaasi; Küsimused ja ülesanded

## Kerttu Soans, „Arvutitool ja lumi“
URL: https://www.opiq.ee/kit/71/chapter/3484
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.6
Topics ET: matemaatika, kerttu, soans, arvutitool, lumi, leia, õige, vastus, isal, võis
Topics RU: математика
Topics EN: mathematics
Headings: Kerttu Soans, „Arvutitool ja lumi“; Kerttu Soans; Arvutitool ja lumi; 2. Leia õige vastus; 1. Leia õige vastus; 3. Leia õige vastus; 6. Kas isal võis olla kahju, et ta oli oma vana arvutitooli ära visanud? Millest seda järeldad?; 4. Täida ülesanne; 5. Täida lüngad; Küsimused ja ülesanded

## Lausete liigid
URL: https://www.opiq.ee/kit/71/chapter/3485
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.7
Topics ET: matemaatika, lausete, liigid, kolme, liiki, lauseid, prügiauto, küsilause, algusesse, sobiv
Topics RU: математика
Topics EN: mathematics
Headings: Lausete liigid; Kolme liiki lauseid; Prügiauto; Küsilause algusesse sobiv küsisõna; Vali õige lõpumärk; Mida ütled?; Prügi metsas; Prügimägi; Küsimused ja ülesanded; 2. Täienda teksti; 1. Täida lüngad; 3. Pildiallkirjad

## Teema
URL: https://www.opiq.ee/kit/71/chapter/3486
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.8
Topics ET: matemaatika, aeg, kell, kalender, teema, millest, tekst, räägib, talvekunstid, vaba, talvepuhkus, pealkiri, küsimused
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Teema; Millest tekst räägib?; Talvekunstid; Vaba aeg; Talvepuhkus; Pealkiri ja teema; Küsimused ja ülesanded; 1. Sobivad pealkirjad; 2. Mis teemad?; 3. Harjuta mõtete kogumist

## Pamela Lyndon Travers, „Mary Poppins“
URL: https://www.opiq.ee/kit/71/chapter/3487
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 6.9
Topics ET: matemaatika, pamela, lyndon, travers, mary, poppins, naerugaas, miks, hõljus, mister
Topics RU: математика
Topics EN: mathematics
Headings: Pamela Lyndon Travers, „Mary Poppins“; Pamela Lyndon Travers; Naerugaas; Miks hõljus mister Wigg laes?; Miks tõusid ka Jane ja Michael õhku?; Küsimused ja ülesanded

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/3520
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.1
Topics ET: matemaatika, peatüki, sissejuhatus, paneme, mõtte, tööle, arutlege, oled, väitega, nõus
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Paneme mõtte tööle; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda suuliselt.; 3. Vaata pilte. Mõtle, milline omadussõna väljendab kõige täpsemalt sellist meeleolu? Kirjelda üht olukorda, kus tundsid samamoodi.

## Liitlause kirjavahemärgid
URL: https://www.opiq.ee/kit/71/chapter/3517
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.10
Topics ET: matemaatika, liitlause, kirjavahemärgid, lihtlausest, liitlauseks, mitu, lihtlauset, moodusta, lauseid, lõpeta
Topics RU: математика
Topics EN: mathematics
Headings: Liitlause kirjavahemärgid; Lihtlausest liitlauseks; 1. Mitu lihtlauset?; 2. Moodusta lauseid; 4. Lõpeta lause; 3. Lihtlaused liitlauseteks; 5. Komaga või komata?

## Kuidas hästi kirjeldada
URL: https://www.opiq.ee/kit/71/chapter/3518
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.11
Topics ET: matemaatika, kuidas, hästi, kirjeldada, terav, pilk, oskuslik, sõnastus, analüüsi, pilti
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas hästi kirjeldada; Terav pilk ja oskuslik sõnastus; Kuidas kirjeldada?; 1. Analüüsi pilti; 2. Kirjelda klassikaaslast; Küsimused ja ülesanded; 1. Loe lugu ning täida ülesanne.; 2. Tooli kirjeldus

## Luuletusi omapärastest tegelastest
URL: https://www.opiq.ee/kit/71/chapter/3521
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.12
Topics ET: matemaatika, luuletusi, omapärastest, tegelastest, kadrioru, pargis, luuletuse, meeleolu, rõõmus, perekond
Topics RU: математика
Topics EN: mathematics
Headings: Luuletusi omapärastest tegelastest; Kadrioru pargis; 5. Luuletuse meeleolu; Rõõmus perekond; 11. Ilma naeruta hakkab vilu; Vanapaar; 19. Tervislik eluviis; 18. Luuletuse iseloomustus; Pada ja katel; Päevavaras

## Kokkuvõte. Kirjeldamine
URL: https://www.opiq.ee/kit/71/chapter/3519
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.13
Topics ET: matemaatika, kokkuvõte, kirjeldamine, kirjelda, pildi, põhjal, vaata, hoolikalt, pilti, vali
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Kirjeldamine; Kirjelda pildi põhjal; Vaata hoolikalt pilti ja vali sealt üks tegelane.

## Mis on kirjeldamine?
URL: https://www.opiq.ee/kit/71/chapter/3509
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.2
Topics ET: matemaatika, kirjeldamine, kirjeldus, aitab, teksti, sisse, minna, totu, kuul, kirjeldusi
Topics RU: математика
Topics EN: mathematics
Headings: Mis on kirjeldamine?; Kirjeldus aitab teksti sisse minna; Totu Kuul; Loe kirjeldusi ja täida ülesanded

## Aapeli, „Kummitavad palitud“
URL: https://www.opiq.ee/kit/71/chapter/3510
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.3
Topics ET: matemaatika, aapeli, kummitavad, palitud, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Aapeli, „Kummitavad palitud“; Aapeli; Kummitavad palitud; Küsimused ja ülesanded

## Liht- ja liitlause
URL: https://www.opiq.ee/kit/71/chapter/3511
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.4
Topics ET: matemaatika, liht, liitlause, mitu, tegevust, lõpeta, liitlaused, liitlauses, öeldist, vähemalt
Topics RU: математика
Topics EN: mathematics
Headings: Liht- ja liitlause; Üks või mitu tegevust?; 1. Lõpeta liitlaused; 2. Liitlauses mitu öeldist; 3. Vähemalt viis sobilikku öeldist; Küsimused ja ülesanded; 1. Öeldiseta laused; 2. Kas väide on tõene või väär?; 3. Milline pilt vastab kuslapuu lehtede ja viljade kirjeldusele?

## Kristiina Kass, „Samuel Seebimulli perekond“
URL: https://www.opiq.ee/kit/71/chapter/3512
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.5
Topics ET: matemaatika, kristiina, kass, samuel, seebimulli, perekond, mida, arvab, õest, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Kristiina Kass, „Samuel Seebimulli perekond“; Kristiina Kass; Samuel Seebimulli perekond; 4. Mida arvab Samuel oma õest?; Küsimused ja ülesanded

## Õpime raamatutegelasi paremini tundma
URL: https://www.opiq.ee/kit/71/chapter/3513
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.6
Topics ET: matemaatika, õpime, raamatutegelasi, paremini, tundma, autor, paneb, tegelase, mõtlema, tegutsema
Topics RU: математика
Topics EN: mathematics
Headings: Õpime raamatutegelasi paremini tundma; Autor paneb tegelase mõtlema, tundma ja tegutsema; A. Loe katkend läbi ja täida ülesanded; B. Loe katkend läbi ja täida ülesanded; 14. Ottokari iseloomustus

## Eno Raud, „Sõjakirves on välja kaevatud“
URL: https://www.opiq.ee/kit/71/chapter/3514
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.7
Topics ET: matemaatika, raud, sõjakirves, välja, kaevatud, küsimused, miks, otsustati, lahinguga
Topics RU: математика
Topics EN: mathematics
Headings: Eno Raud, „Sõjakirves on välja kaevatud“; Eno Raud; Sõjakirves on välja kaevatud; Küsimused ja ülesanded; 10. Miks otsustati lahinguga õhtuni oodata?; 8. Kes on selles katkendis peategelane? Põhjenda.; 9. Milles süüdistasid maapoisid Roltsi, Jaani ja Antsu?; 11. Kava järgi jutustamine; 7. Leia väljendile õige seletus

## Koondlause
URL: https://www.opiq.ee/kit/71/chapter/3515
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.8
Topics ET: matemaatika, koondlause, samale, küsimusele, vastavad, sõnad, missugused, poisid, laused, märgi
Topics RU: математика
Topics EN: mathematics
Headings: Koondlause; Samale küsimusele vastavad sõnad; 1. Missugused poisid, missugused laused?; Ül 3; Ül 1; Ül 2; 3. Märgi koondlausetes samale küsimusele vastavad sõnad; Koondlause kirjavahemärgid; 4. Sidesõnast oleneb kirjavahemärk; 5. Moodusta koondlauseid; 7. Jaatusest eitus; 6. Eitusest jaatus; Küsimused ja ülesanded

## Toon Tellegen, „Minu isa“
URL: https://www.opiq.ee/kit/71/chapter/3516
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 7.9
Topics ET: matemaatika, toon, tellegen, väga, vaikne, küsimused, järjesta, esita, ilmekalt
Topics RU: математика
Topics EN: mathematics
Headings: Toon Tellegen, „Minu isa“; Toon Tellegen; Minu isa; 2. Väga-väga vaikne; Küsimused ja ülesanded; 6. Järjesta; 7. Esita ilmekalt

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/3598
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.1
Topics ET: matemaatika, peatüki, sissejuhatus, paneme, mõtte, tööle, arutage, oled, väitega, nõus
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Paneme mõtte tööle; 1. Arutage!; 2. Kas oled väitega nõus või mitte? Põhjenda suuliselt.; 3. Mängige äraarvamismängu.

## Vanasõna
URL: https://www.opiq.ee/kit/71/chapter/3593
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.10
Topics ET: matemaatika, vanasõna, nõia, lapsed, jutuga, sobiv, vanasõnad, nende, tähendus, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Vanasõna; Nõia lapsed; Mis on vanasõna?; Jutuga sobiv vanasõna; Vanasõnad ja nende tähendus; Küsimused ja ülesanded; 1. Mis on vanasõna?; 2. Vanasõna lõpetamine

## Markus Saksatamm, „Tädi Kersti ja nõiutud prints“
URL: https://www.opiq.ee/kit/71/chapter/3594
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.11
Topics ET: matemaatika, markus, saksatamm, tädi, kersti, nõiutud, prints, küsimused, vali
Topics RU: математика
Topics EN: mathematics
Headings: Markus Saksatamm, „Tädi Kersti ja nõiutud prints“; Tädi Kersti ja nõiutud prints; Küsimused ja ülesanded; 1. Vali õige sõna; 2. Vasta küsimustele; 5. Uurimisülesanne; 3. Kuidas lõpeb vanasõna tegelikult?; 4. Automargid

## Otsekõne kasutamine tekstis
URL: https://www.opiq.ee/kit/71/chapter/3595
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.12
Topics ET: matemaatika, kordamine, korda, harjutan, otsekõne, kasutamine, tekstis, peretütar, vaenelaps, mida, näitab, saatelause, tegusõna
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Otsekõne kasutamine tekstis; Peretütar ja vaenelaps; Mida näitab saatelause?; Saatelause tegusõna; Küsimused ja ülesanded; 1. Otsekõne kirjavahemärkide kordamine

## Kõnekäänd
URL: https://www.opiq.ee/kit/71/chapter/3596
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.13
Topics ET: matemaatika, kõnekäänd, rebase, vähi, võidujooks, millised, viis, omadust, võiksid, iseloomustada
Topics RU: математика
Topics EN: mathematics
Headings: Kõnekäänd; Rebase ja vähi võidujooks; Millised viis omadust võiksid iseloomustada loetud jutu rebast?; Millised omadussõnad iseloomustavad loetud jutu vähki?; Mis on kõnekäänd?; Vali sobiv sõna ja seleta suuliselt kõnekäändude tähendus; Vali kõnekäänule õige tähendus; Küsimused ja ülesanded; 1. Mis on kõnekäänd?; 2. Segamini kõnekäänud; 4. Kas lauses on kõnekäänd (K) või on tegu vanasõnaga (V)?

## Muinasjutulisi luuletusi
URL: https://www.opiq.ee/kit/71/chapter/3599
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.14
Topics ET: matemaatika, raha, euro, sent, muinasjutulisi, luuletusi, muinasjutt, laul, muinasjutust, olemas, ainult, raamatus, muinasjututegelased
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: Muinasjutulisi luuletusi; Mis on muinasjutt?; Laul muinasjutust, mis on olemas ainult raamatus; Muinasjututegelased; Väike kuningajutt; Aega ei saa raha eest osta; Mida võiksid tähendada need ajaga seotud kõnekäänud?

## Kokkuvõte. Muinasjutu kirjutamine
URL: https://www.opiq.ee/kit/71/chapter/3597
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.15
Topics ET: matemaatika, kokkuvõte, muinasjutu, kirjutamine, kirjuta, juhendi, järgi, muinasjutt
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Muinasjutu kirjutamine; Kirjuta juhendi järgi muinasjutt

## August Jakobson, „Hiir ja varblane“
URL: https://www.opiq.ee/kit/71/chapter/3585
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.2
Topics ET: matemaatika, august, jakobson, hiir, varblane, küsimused, sõnastuse, muutmine, teraviljade
Topics RU: математика
Topics EN: mathematics
Headings: August Jakobson, „Hiir ja varblane“; August Jakobson; Hiir ja varblane; Küsimused ja ülesanded; 1. Sõnastuse muutmine; 2. Teraviljade nimetused

## Otsekõne ja saatelause
URL: https://www.opiq.ee/kit/71/chapter/3586
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.3
Topics ET: matemaatika, otsekõne, saatelause, küsimused, märkimine, kirjutamine, samatähenduslikud, laused
Topics RU: математика
Topics EN: mathematics
Headings: Otsekõne ja saatelause; Mis on otsekõne?; Küsimused ja ülesanded; 2. Saatelause märkimine; 1. Otsekõne märkimine; 3. Saatelause kirjutamine; 4. Samatähenduslikud laused

## Muinasjutt – rahva unistused ja uskumused
URL: https://www.opiq.ee/kit/71/chapter/3587
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.4
Topics ET: matemaatika, muinasjutt, rahva, unistused, uskumused, muinasjutu, tunnused, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Muinasjutt – rahva unistused ja uskumused; Mis on muinasjutt?; Muinasjutu tunnused; Küsimused ja ülesanded

## Tšehhi muinasjutt „Lonkav rebane“
URL: https://www.opiq.ee/kit/71/chapter/3588
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.5
Topics ET: matemaatika, tšehhi, muinasjutt, lonkav, rebane, küsimused, vali, õige, lauselõpp
Topics RU: математика
Topics EN: mathematics
Headings: Tšehhi muinasjutt „Lonkav rebane“; Lonkav rebane; Küsimused ja ülesanded; 1. Vali õige lauselõpp; 2. Vasta küsimustele

## Otsekõne kirjavahemärgid
URL: https://www.opiq.ee/kit/71/chapter/3589
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.6
Topics ET: matemaatika, otsekõne, kirjavahemärgid, kuidas, tähistatakse, otsekõnet, küsimused, lisa, riideesemete
Topics RU: математика
Topics EN: mathematics
Headings: Otsekõne kirjavahemärgid; Kuidas tähistatakse otsekõnet?; Küsimused ja ülesanded; 1. Lisa otsekõne ja kirjavahemärgid; 2. Riideesemete kahekõne

## Fr. R. Kreutzwald, „Vaeslapse käsikivi“
URL: https://www.opiq.ee/kit/71/chapter/3590
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.7
Topics ET: matemaatika, kreutzwald, vaeslapse, käsikivi, friedrich, reinhold, küsimused, vasta, küsimustele
Topics RU: математика
Topics EN: mathematics
Headings: Fr. R. Kreutzwald, „Vaeslapse käsikivi“; Friedrich Reinhold Kreutzwald; Vaeslapse käsikivi; Küsimused ja ülesanded; Vasta küsimustele; Tegelaste iseloomustus; Muinasjutu tunnused

## Kunstmuinasjutud
URL: https://www.opiq.ee/kit/71/chapter/3591
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.8
Topics ET: matemaatika, kunstmuinasjutud, kunstmuinasjutt, küsimused, anderseni, muinasjutud
Topics RU: математика
Topics EN: mathematics
Headings: Kunstmuinasjutud; Mis on kunstmuinasjutt?; Küsimused ja ülesanded; H. C. Anderseni muinasjutud

## Václav Čtvrtek, „Kuidas Rumcajs endale uue püstoli ostis“
URL: https://www.opiq.ee/kit/71/chapter/3592
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 8.9
Topics ET: matemaatika, clav, tvrtek, kuidas, rumcajs, endale, püstoli, ostis, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Václav Čtvrtek, „Kuidas Rumcajs endale uue püstoli ostis“; Václav Čtvrtek; Kuidas Rumcajs endale uue püstoli ostis; Küsimused ja ülesanded; 1. Sündmuste järjestamine; 2. Küsimuste koostamine; 3. Vasta küsimustele

## Peatüki sissejuhatus
URL: https://www.opiq.ee/kit/71/chapter/3609
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.1
Topics ET: matemaatika, peatüki, sissejuhatus, paneme, mõtte, tööle
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki sissejuhatus; Paneme mõtte tööle

## Mängulisi luuletusi
URL: https://www.opiq.ee/kit/71/chapter/3610
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.10
Topics ET: matemaatika, mängulisi, luuletusi, riimimäng, miks, luuletuse, pealkiri, millised, kohad, luuletuses
Topics RU: математика
Topics EN: mathematics
Headings: Mängulisi luuletusi; Riimimäng; 4. Miks on luuletuse pealkiri „Riimimäng“?; 1. Millised kohad on luuletuses mainitud?; 2. Mida soovitatakse lugejal teha?; 3. Seleta sõna tähendused; Ilus algus; 8. Seleta suuliselt, mida tähendavad need väljendid.; 5. Ratta tähendus; 6. Jalgratta kirjeldus; 7. Jalgrattasõit; Suur rõõm ja väike mure; 11. Arutage klassis; 9. Rõõmu ja mure kirjeldus; 10. Mis on selle luuletuse mõte?

## Peatüki kokkuvõte. Sõna ja pilt
URL: https://www.opiq.ee/kit/71/chapter/3608
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.11
Topics ET: matemaatika, peatüki, kokkuvõte, sõna, pilt, kirjuta, piltide, järgi, lugu, elevant
Topics RU: математика
Topics EN: mathematics
Headings: Peatüki kokkuvõte. Sõna ja pilt; Kirjuta piltide järgi lugu; Elevant ja hiir

## Olivier Melano, „Kuninga kaardimeister“
URL: https://www.opiq.ee/kit/71/chapter/3600
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.2
Topics ET: matemaatika, olivier, melano, kuninga, kaardimeister, küsimused, peategelane, lugu, toimub
Topics RU: математика
Topics EN: mathematics
Headings: Olivier Melano, „Kuninga kaardimeister“; Kuninga kaardimeister; Küsimused ja ülesanded; 2. Kes on loo peategelane?; 1. Kus lugu toimub?

## Pilt kõneleb
URL: https://www.opiq.ee/kit/71/chapter/3601
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.3
Topics ET: matemaatika, pilt, kõneleb, täidab, ülesannet, väldi, sõnakordusi, ilma, sõnadeta, õpetlik
Topics RU: математика
Topics EN: mathematics
Headings: Pilt kõneleb; Pilt täidab ülesannet; Väldi sõnakordusi; Ilma sõnadeta pilt; Õpetlik lugu; Oti õnnetus; Kes mida rääkis?; Isemoodi arusaam; Sobimatu kõnepruuk; Küsimused ja ülesanded

## Sünonüümid
URL: https://www.opiq.ee/kit/71/chapter/3602
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.4
Topics ET: matemaatika, sünonüümid, sama, tähendusega, sõnad, hunt, susi, pilt, sõnarühm, käed
Topics RU: математика
Topics EN: mathematics
Headings: Sünonüümid; Sama tähendusega sõnad; Hunt ja susi; Pilt ja sõnarühm 3; Pilt ja sõnarühm 1; Pilt ja sõnarühm 2; Käed ja kätud; Kirjuta sünonüüm; Küsimused ja ülesanded; 2. Ilmekusega ei tasu liialdada; 1. Laused väljendusrikkamaks

## Joonas Sildre, „Maailma naba“
URL: https://www.opiq.ee/kit/71/chapter/3603
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.5
Topics ET: matemaatika, joonas, sildre, maailma, naba, küsimused, väljendi, tähendus, jääb
Topics RU: математика
Topics EN: mathematics
Headings: Joonas Sildre, „Maailma naba“; Joonas Sildre; Maailma naba; Küsimused ja ülesanded; Väljendi tähendus; Mis jääb ütlemata?

## Mitmetähenduslikud sõnad
URL: https://www.opiq.ee/kit/71/chapter/3604
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.6
Topics ET: matemaatika, mitmetähenduslikud, sõnad, ühel, sõnal, mitu, tähendust, mitme, tähendusega, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Mitmetähenduslikud sõnad; Ühel sõnal mitu tähendust; Ül 3; Ül 1; Ül 2; 4. Mitme tähendusega sõnad; Küsimused ja ülesanded; 1. Täida ülesanne a või b.

## Venda Sõelsepp, „Kui Kurgil jäi kurk haigeks“
URL: https://www.opiq.ee/kit/71/chapter/3605
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.7
Topics ET: matemaatika, venda, sõelsepp, kurgil, kurk, haigeks, küsimused, arusaamatus, mitu
Topics RU: математика
Topics EN: mathematics
Headings: Venda Sõelsepp, „Kui Kurgil jäi kurk haigeks“; Venda Sõelsepp; Kui Kurgil jäi kurk haigeks; Küsimused ja ülesanded; 1. Arusaamatus; 2. Mitu kurki?

## Antonüümid
URL: https://www.opiq.ee/kit/71/chapter/3606
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.8
Topics ET: matemaatika, antonüümid, vastandliku, tähendusega, sõnad, vana, vastandsõna, head, halvad, omadused
Topics RU: математика
Topics EN: mathematics
Headings: Antonüümid; Vastandliku tähendusega sõnad; Vana ja uus; Vastandsõna; 5. Head ja halvad omadused; 7. Kasuta vastandsõnu; 6. Kasuta antonüümi; 8. Leia vastandsõna; Küsimused ja ülesanded; 1. Kirjelda maja; 2. Kirjuta lugu

## Oscar Brenifier, Clément Devaux, „Mis on hea ja mis on halb?“
URL: https://www.opiq.ee/kit/71/chapter/3607
Book: Eesti keel 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile
Chapter ID: 9.9
Topics ET: matemaatika, oscar, brenifier, ment, devaux, halb, pead, kõik, välja, ütlema
Topics RU: математика
Topics EN: mathematics
Headings: Oscar Brenifier, Clément Devaux, „Mis on hea ja mis on halb?“; Mis on hea ja mis on halb?; Kas sa pead kõik välja ütlema?; Küsimused ja ülesanded; 4. Mida need väljendid tähendavad?

## Eesti keel 4. klassile 2024 – Opiq
URL: https://www.opiq.ee/Kit/Details/533
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 138
Topics ET: matemaatika, eesti, keel, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Eesti keel 4. klassile 2024 – Opiq
URL: https://www.opiq.ee/Kit/Details/533
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 268
Topics ET: matemaatika, eesti, keel, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/29533
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.1
Topics ET: matemaatika, teema, sissejuhatus, raamatuid, kõigile, arutlege, oled, väitega, nõus, mitte
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Raamatuid on kõigile; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Moodusta antud sõnadest lause.

## Kuidas raamatut valida?
URL: https://www.opiq.ee/kit/533/chapter/29542
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.10
Topics ET: matemaatika, kuidas, raamatut, valida, raamatu, valimine, kaanepildi, järgi, uuri, raamatute
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas raamatut valida?; Raamatu valimine; Kaanepildi järgi; 1. Uuri raamatute kaanepilte ja vasta küsimustele; 2. Vali raamat; Sisututvustuse järgi; 3. Loe läbi raamatute tutvustused ja vasta küsimustele; „Risto Räppar ja viimane hoiatus“; „Õuduste kool“; „Gibraltari laevakoerte ühing“; „Varastatud oranž jalgratas“; Küsimusi ja ülesandeid; 4. Lemmikraamat; 5. Rühmatöö

## Töövõtted lugemise ajal
URL: https://www.opiq.ee/kit/533/chapter/29550
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.11
Topics ET: matemaatika, töövõtted, lugemise, ajal, kasuta, järjehoidjaid, kirjuta, välja, toredaid, tsitaate
Topics RU: математика
Topics EN: mathematics
Headings: Töövõtted lugemise ajal; 1. Kasuta järjehoidjaid; 2. Kirjuta välja toredaid tsitaate; 3. Tee märkmeid; Lugemisülesanne

## Karvased sõrmed
URL: https://www.opiq.ee/kit/533/chapter/29543
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.12
Topics ET: matemaatika, karvased, sõrmed, lugemise, ajal, tüdrukuga, juhtus, tüdruku, kodutööd, kodus
Topics RU: математика
Topics EN: mathematics
Headings: Karvased sõrmed; 1. Lugemise ajal; Mis tüdrukuga juhtus?; Tüdruku kodutööd; Sõrmed kodus; Küsimusi ja ülesandeid; 2. Arutle ja kirjuta; 3. Loo kestus; 3. Loo lõpp; 3. Esita küsimusi; 4. Iseloomusta; Tüdruku iseloomustus; Loo iseloomustus

## Nimetused
URL: https://www.opiq.ee/kit/533/chapter/29544
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.13
Topics ET: matemaatika, nimetused, mida, näitavad, mõtle, igasse, rühma, veel, näide, otid
Topics RU: математика
Topics EN: mathematics
Headings: Nimetused; Mida näitavad nimetused?; 1. Mõtle igasse rühma veel üks näide; 2. Otid; Küsimusi ja ülesandeid; 3. Paranda algustähevead; 4. Kirjelda; Nõuanne sõnakuulmatutele lastele; 5. Loe läbi Grigori Osteri nõuanne.

## Teeme tutvust kirjanikuga
URL: https://www.opiq.ee/kit/533/chapter/29545
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.14
Topics ET: matemaatika, teeme, tutvust, kirjanikuga, intervjuu, mika, keräneniga, küsimusi, ülesandeid, mõtteskeem
Topics RU: математика
Topics EN: mathematics
Headings: Teeme tutvust kirjanikuga; Intervjuu Mika Keräneniga; Küsimusi ja ülesandeid; 1. Mõtteskeem; 2. Mika Keräneni teosed

## Varastatud oranž jalgratas
URL: https://www.opiq.ee/kit/533/chapter/29546
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.15
Topics ET: matemaatika, varastatud, oranž, jalgratas, peatükk, jälitajad, leia, värvi, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Varastatud oranž jalgratas; 5. peatükk. Jälitajad; 1. Leia ja värvi; Küsimusi ja ülesandeid; 2. Nimed ja nimetused; 3. Mis loos toimub?; 4. Tegevuskoht; 5. Iseloomusta lugu; 6. Arutle ja selgita; 7. Rollimäng

## Loeme luuletusi
URL: https://www.opiq.ee/kit/533/chapter/29547
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.16
Topics ET: matemaatika, loeme, luuletusi, arutle, kolm, sõpra, neljajalgne, mida, küsida, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: Loeme luuletusi; Arutle; Kolm sõpra ja neljajalgne; 1. Mida küsida?; Mida küsida? 1; Mida küsida? 2; Mida küsida? 3; Kuidas luuletust esitada?; Kas said aru?; Paras tempo; Selge hääldus; Ole kuuldav; Lisa põnevust; Võta aega pausideks; Silmad; Küsimusi ja ülesandeid; 2. Rõhk; 3. Tunne

## Leelo Tungla luuletusi
URL: https://www.opiq.ee/kit/533/chapter/29548
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.17
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, leelo, tungla, luuletusi, tungal, pille, tiiu, arutle, meeleolu, unelaul
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Leelo Tungla luuletusi; Leelo Tungal; Pille ja Tiiu; 1. Arutle; 2. Meeleolu; Unelaul; 3. Katseta; Trennist tulles; 4. Vasta küsimustele; 5. Arutle; 6. Uuri ja võrdle kaht toidupüramiidi; 7. Lõpeta laused ja vasta küsimustele; Püramiidi kuju 1; Püramiidi kuju 2; Toidupüramiidi augud; Püramiidi tipp

## Teema kokkuvõte
URL: https://www.opiq.ee/kit/533/chapter/29549
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.18
Topics ET: matemaatika, teema, kokkuvõte, esitame, luuletusi
Topics RU: математика
Topics EN: mathematics
Headings: Teema kokkuvõte; Esitame luuletusi

## Kui isa kinkis raamatuid
URL: https://www.opiq.ee/kit/533/chapter/29534
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.2
Topics ET: matemaatika, kinkis, raamatuid, jüri, parijõgi, mida, keegi, lugeda, soovib, teile
Topics RU: математика
Topics EN: mathematics
Headings: Kui isa kinkis raamatuid; Jüri Parijõgi; Mida keegi lugeda soovib?; Mis teile kuulub?; Küsimusi ja ülesandeid; 5. Kes on selle loo tegelased?; 6. Uuri lugemispala; 7. Arutle; Sõnapank; Harjuta sõnu; Sõnad 1; Sõnad 2; Sõnad 3

## Kordame tähestikku
URL: https://www.opiq.ee/kit/533/chapter/29535
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.3
Topics ET: matemaatika, kordame, tähestikku, tekst, läbi, vasta, küsimustele, eesti, tähestik, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Kordame tähestikku; Loe tekst läbi; 1. Vasta küsimustele; Eesti tähestik; Küsimusi ja ülesandeid; 2. Mitu tähte on tähestikus?; 3. Järjesta tähed; 4. Harjuta tähestikku; 5. Mitmendas köites?

## Raamatute maailm
URL: https://www.opiq.ee/kit/533/chapter/29536
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.4
Topics ET: matemaatika, raamatute, maailm, kuidas, kirjandus, jaguneb, teabekirjandus, varastatud, oranž, jalgratas
Topics RU: математика
Topics EN: mathematics
Headings: Raamatute maailm; Kuidas kirjandus jaguneb?; 1. Ilu- või teabekirjandus?; „Varastatud oranž jalgratas“; „Võõrsõnade leksikon“; „Koeraomaniku käsiraamat“; „Arabella, mereröövli tütar“; Küsimusi ja ülesandeid; 2. Ilu- ja teabekirjanduse eesmärk; 3. „Kui isa kinkis raamatuid“; 4. Loetud raamatud; 4a; 4b

## Pealkirjad
URL: https://www.opiq.ee/kit/533/chapter/29537
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.5
Topics ET: matemaatika, pealkirjad, jutumärgid, suur, algustäht, mõtle, igasse, rühma, veel, näide
Topics RU: математика
Topics EN: mathematics
Headings: Pealkirjad; Jutumärgid ja suur algustäht; 1. Mõtle igasse rühma veel üks näide; Küsimusi ja ülesandeid; 2. Leia pealkirjad; 3. Segamini tähed; 4. Pealkirjaga lause; 5. Filmide pealkirjad

## Kuidas juttu lugeda?
URL: https://www.opiq.ee/kit/533/chapter/29538
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.6
Topics ET: matemaatika, aeg, kell, kalender, kuidas, juttu, lugeda, esita, küsimusi, kukk, rebane, ülesandeid, tegelased
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Kuidas juttu lugeda?; Esita küsimusi; Kukk ja rebane; Küsimusi ja ülesandeid; 1. Tegelased, koht ja aeg; 1a; 1b; 1c; 2. Mis juhtus?; 2a; 2b Kuidas olukord laheneb?; 3. Rebase ja kuke iseloomustus; Jutusta ja kirjuta; 4. Ümberjutustus; 5. Kirjuta lugu

## Lahenduste ministeerium
URL: https://www.opiq.ee/kit/533/chapter/29539
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.7
Topics ET: matemaatika, lahenduste, ministeerium, sanne, rooseboom, huvitavaid, fakte, ruubeni, kirja, põhjus
Topics RU: математика
Topics EN: mathematics
Headings: Lahenduste ministeerium; Sanne Rooseboom; Huvitavaid fakte; 1. Ruubeni kirja põhjus; 2. Alfa lahendus; 3. Niina lahendus; Küsimusi ja ülesandeid; 4. Kes on selle loo tegelased?; 5. Miks otsustasid Niina ja Alfa Ruubenit aidata?; 6. Arutle; 7. Uuri; Ministeerium; Rühmatöö

## Nimed
URL: https://www.opiq.ee/kit/533/chapter/29540
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.8
Topics ET: matemaatika, nimed, kellel, millel, võib, olla, nimi, liiki, sõnad, leidub
Topics RU: математика
Topics EN: mathematics
Headings: Nimed; Kellel või millel võib olla nimi?; 1. Mis liiki sõnad on nimed?; 2. Kus leidub palju nimesid?; Küsimusi ja ülesandeid; 3. Vali lünka suur või väike algustäht.; Täida lüngad I; Täida lüngad II; 4. Kass Parm; 5. Kirjuta õigesti; 6. Põlvkonnad

## Täiesti tavaline perekond
URL: https://www.opiq.ee/kit/533/chapter/29541
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 1.9
Topics ET: matemaatika, täiesti, tavaline, perekond, reeli, reinaus, huvitavaid, fakte, pereliikmed, timi
Topics RU: математика
Topics EN: mathematics
Headings: Täiesti tavaline perekond; Reeli Reinaus; Huvitavaid fakte; 1. Pereliikmed; 2. Timi mure; 3. Timi lugemiseelistus; 5. Miks pidada blogi?; 4. Ebatavaline perekond; Küsimusi ja ülesandeid; 6. Loo tegelased; 7. Vaata pilti; 8. Timi lugemisharjumused; 9. Ema lugemisharjumused; 10. Isa lugemisharjumused; 11. Mõtle ja jutusta

## Kuidas loen ja kirjutan?
URL: https://www.opiq.ee/kit/533/chapter/30783
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 10.1
Topics ET: matemaatika, kuidas, loen, kirjutan, panen, teoste, puhul, tähele
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas loen ja kirjutan?; Kuidas loen?; Panen teoste puhul tähele; Kuidas kirjutan?

## Mõisted
URL: https://www.opiq.ee/kit/533/chapter/29551
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 10.2
Topics ET: matemaatika, mõisted
Topics RU: математика
Topics EN: mathematics
Headings: Mõisted

## Sõnaseletused
URL: https://www.opiq.ee/kit/533/chapter/29552
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 10.3
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/533/chapter/31262
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 10.4
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/30091
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.1
Topics ET: matemaatika, teema, sissejuhatus, teabetekstide, kosmoses, arutlege, oled, väitega, nõus, mitte
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Teabetekstide kosmoses; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Milline sõna ei sisalda võõsõnatähti? Märgi see.

## Kuidas ironiseerida. Kuidas rääkida lastega
URL: https://www.opiq.ee/kit/533/chapter/30100
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.10
Topics ET: matemaatika, kuidas, ironiseerida, rääkida, lastega, anti, saar, iroonia, naer, tegevuskoht
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas ironiseerida. Kuidas rääkida lastega; Anti Saar; Kuidas ironiseerida; 1. Mis on iroonia?; 2. Kus on iroonia?; 3. Naer; 4. Tegevuskoht; Kuidas rääkida lastega; Noortekeel; 5. Praegune noortekeel

## Fakt ja arvamus
URL: https://www.opiq.ee/kit/533/chapter/30101
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.11
Topics ET: matemaatika, fakt, arvamus, need, kumb, fakte, arvamusi, merepäev, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Fakt ja arvamus; Mis need on?; 1. Kumb on kumb?; Kus on fakte ja arvamusi?; Merepäev A; Merepäev B; Küsimusi ja ülesandeid; 2. Sobimatud arvamused; 2a; 2b; 2c; 2d; 2e

## Johannese oratoorium
URL: https://www.opiq.ee/kit/533/chapter/30102
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.12
Topics ET: matemaatika, johannese, oratoorium, ilmar, tomusk, mure, suhtumine, oratooriumi, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Johannese oratoorium; Ilmar Tomusk; Johannese mure; Isa suhtumine; Oratooriumi sisu; Küsimusi ja ülesandeid; 5. Töö tekstiga; Mida Johannes tunneb?; 6. Jutu ja oratooriumi tegelased; 7. Arutle

## Arvamuse avaldamine
URL: https://www.opiq.ee/kit/533/chapter/30103
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.13
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, arvamuse, avaldamine, kuidas, arvamust, väljendada, osad, küsimusi, ülesandeid, rühmatöö
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Arvamuse avaldamine; Kuidas arvamust väljendada?; 1. Arvamuse osad; Küsimusi ja ülesandeid; 2. Rühmatöö; 3. Võrdle tekste

## Mõttevahetus
URL: https://www.opiq.ee/kit/533/chapter/30104
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.14
Topics ET: matemaatika, mõttevahetus, kuidas, vahetada, mõtteid, mõttevahetuse, järgud, küsimusi, ülesandeid, paaristöö
Topics RU: математика
Topics EN: mathematics
Headings: Mõttevahetus; Kuidas vahetada mõtteid?; 1. Mõttevahetuse järgud; Küsimusi ja ülesandeid; 2. Paaristöö

## Luuletusi muusikast ja kosmosest
URL: https://www.opiq.ee/kit/533/chapter/30105
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.15
Topics ET: matemaatika, luuletusi, muusikast, kosmosest, klaverikontsert, arutle, otsi, väljendeid, teekond, tähtede
Topics RU: математика
Topics EN: mathematics
Headings: Luuletusi muusikast ja kosmosest; Klaverikontsert; 1. Arutle; 2. Otsi väljendeid; Teekond tähtede juurde; 3. Arutle; 4. Võrdlus; Kosmose jõgi on taevas; 5. Arutle; Kuu; 6. Arutle; 7. Otsi väljendeid; 8. Kuufaasid; Küsimusi ja ülesandeid; 9. Sõnasta oma arvamus; 10. Loe luuletusi ette

## Kokkuvõte. Infootsing ja arvamuse kujundamine
URL: https://www.opiq.ee/kit/533/chapter/30106
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.16
Topics ET: matemaatika, kokkuvõte, infootsing, arvamuse, kujundamine, millist, infot, otsida, mida, leitud
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Infootsing ja arvamuse kujundamine; Millist infot otsida?; Mida leitud infoga edasi teha?

## Härra LugemisHull
URL: https://www.opiq.ee/kit/533/chapter/30092
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.2
Topics ET: matemaatika, härra, lugemishull, aino, pervik, mida, loeb, lugemis, hull, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Härra LugemisHull; Aino Pervik; Mida LugemisHull loeb? (1); Mida Lugemis­Hull loeb? (2); Küsimusi ja ülesandeid; 4. Lugemis­Hull raamatu­kogus; 5. LugemisHull toidu­poes; 6. Arutle

## Teabekirjanduse liigid
URL: https://www.opiq.ee/kit/533/chapter/30093
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, teabekirjanduse, liigid, teabekirjandus, kuidas, teatme, teost, kasutada, sõnastik, mida
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Teabekirjanduse liigid; Teabekirjandus; 1. Ilu- või teabekirjandus?; Kuidas teatme­teost kasutada?; A. Sõnastik; 2. Mida leiab Sõna­veebist?; B. Entsüklopeedia; 3. Mida saab komeedi kohta teada Vikipeediast?; C. Aimekirjandus; 4. Lõikude info; Küsimusi ja ülesandeid; 5. Võrdle tekste; 6. Mida oled kasutanud?; Milliseid veebiallikaid usaldada?; 7. Otsi infot

## Georg ja universumi salavõti
URL: https://www.opiq.ee/kit/533/chapter/30094
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.4
Topics ET: matemaatika, georg, universumi, salavõti, stephen, lucy, hawking, juhtus, kirjeldus, pahandus
Topics RU: математика
Topics EN: mathematics
Headings: Georg ja universumi salavõti; Stephen ja Lucy Hawking; Mis juhtus?; Kirjeldus; Pahandus; Sõprus; Küsimusi ja ülesandeid; 6. Tegelased ja koht; 7. Mis selles loos juhtus?; 8. Kujutle ja põhjenda; 9. Suur ja väike algustäht; 10.

## Poolitamine
URL: https://www.opiq.ee/kit/533/chapter/30095
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.5
Topics ET: matemaatika, poolitamine, tekstiga, silbitamine, küsimusi, ülesandeid, silbita, mida, poolitada, liitsõnade
Topics RU: математика
Topics EN: mathematics
Headings: Poolitamine; Töö tekstiga; Silbitamine ja poolitamine; Silbitamine; 1.; Küsimusi ja ülesandeid; 2. Silbita; 3. Mida ei saa poolitada?; 4. Liitsõnade poolitamine

## Sõnastiku kasutamine
URL: https://www.opiq.ee/kit/533/chapter/30096
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.6
Topics ET: matemaatika, sõnastiku, kasutamine, sõnaveeb, milline, algvorm, praktilise, leidmine, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Sõnastiku kasutamine; Sõnaveeb; Milline on algvorm?; Praktilise leidmine; Küsimusi ja ülesandeid; 2. Algvorm; 3. Arva tähendus ära; 4. Harjuta sõnu

## Kivi kustutab janu
URL: https://www.opiq.ee/kit/533/chapter/30097
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.7
Topics ET: matemaatika, geomeetria, kujund, kujundid, sirge, lõik, kivi, kustutab, janu, kuidas, teabeteksti, lugeda, enne, lugemist, lugemise
Topics RU: математика, геометрия, фигура, фигуры, прямая, отрезок
Topics EN: mathematics, geometry, shape, shapes, line, segment
Headings: Kivi kustutab janu; Kuidas teabeteksti lugeda?; 1. Enne lugemist; Enne lugemist; 2. Lugemise ajal; 1. lõik; 2. lõik; 3. lõik; 4. lõik; 5. lõik; 6. lõik; 7. lõik; Küsimusi ja ülesandeid; 3. Keemiline element; 4. Mineraal; 5. Seleta suuliselt; Tiit Kändler

## Kuidas teabeteksti lugeda?
URL: https://www.opiq.ee/kit/533/chapter/30098
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.8
Topics ET: matemaatika, liitmine, liida, summa, kokku, kuidas, teabeteksti, lugeda, tuvipost, küsi, küsimusi, ülesandeid, võta
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Kuidas teabeteksti lugeda?; Tuvipost; 1. Küsi küsimusi; Küsimusi ja ülesandeid; 2. Võta kokku tähtsaimad mõtted; 3. Märka uusi sõnu; 4. Arutle loetu üle; 5. Tee mõtteskeem; Sõnapank; 6. Seleta võõrsõnu; 7. Leia tähendused; 8. Leia tähendused; 9. Võõrsõnade õigekiri; 10. Võõrsõnade tähendus

## Lühendid
URL: https://www.opiq.ee/kit/533/chapter/30099
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 2.9
Topics ET: matemaatika, lühendid, lühend, üldkasutatavad, kolm, lühendit, küsimusi, ülesandeid, milleks, millised
Topics RU: математика
Topics EN: mathematics
Headings: Lühendid; Mis on lühend?; Üldkasutatavad lühendid; Kolm lühendit; Küsimusi ja ülesandeid; 2. Milleks ja millised on lühendid?; 3. Nuputa; 4. Loe lühendid sõnadena

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/30395
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.1
Topics ET: matemaatika, teema, sissejuhatus, lähme, raamatukokku, arutlege, oled, väitega, nõus, mitte
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Lähme raamatukokku; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Moodusta antud sõnadest lause.

## Kaashääliku­ühend
URL: https://www.opiq.ee/kit/533/chapter/30416
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.10
Topics ET: matemaatika, arv, arvud, arvu, numbrid, kaashääliku, ühend, teksti, täida, uuri, kaashäälikuid, häälikute, ühendis
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Kaashääliku­ühend; Loe teksti ja täida ülesanded; 1. Uuri kaashäälikuid; Häälikute arv ühendis; Kaashäälikuühend; 2. Leia kaashääliku­ühend; 3. Millega sõna algab?; Küsimusi ja ülesandeid; 4. Leia ja märgi; 5. Kirjuta; Lugemisülesanne; 6. Loe jutt läbi ja vasta küsimustele.

## Hobune, kes vedas jõuluõhtul lund
URL: https://www.opiq.ee/kit/533/chapter/30417
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.11
Topics ET: matemaatika, hobune, vedas, jõuluõhtul, lund, juhani, püttsepp, maalt, linna, tegevusaeg
Topics RU: математика
Topics EN: mathematics
Headings: Hobune, kes vedas jõuluõhtul lund; Juhani Püttsepp; Maalt linna; Tegevusaeg; Eesti kuuluvus; 5. Arvuta; Küsimusi ja ülesandeid; 7. Tegelased; 8. Mis loos juhtus?; Mis loos juhtus?; Loo sündmustik; 9. Uuri teksti, selgita, arutle; Sõnapank; Harjuta sõnu; Sõnapank 1; Sõnapank 2; Sõnapank 3

## i ja j õigekiri
URL: https://www.opiq.ee/kit/533/chapter/30418
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.12
Topics ET: matemaatika, õigekiri, tuleta, meelde, pilt, vanasõna, kumb, õige, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: i ja j õigekiri; 1. Tuleta meelde; Pilt ja vanasõna; 4. Kumb on õige?; Küsimusi ja ülesandeid; 5. Silbid vanasõnades; 6. Kes kuhu?; 7. Tegijanimed; 8. Liitsõnad

## Loeme luuletusi
URL: https://www.opiq.ee/kit/533/chapter/30420
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.13
Topics ET: matemaatika, loeme, luuletusi, raamatukoi, tähenärija, aedviljasupp, kokaraamatust
Topics RU: математика
Topics EN: mathematics
Headings: Loeme luuletusi; Raamatukoi ja tähenärija; Aedviljasupp kokaraamatust

## Kokkuvõte. Õppekäik raamatukokku
URL: https://www.opiq.ee/kit/533/chapter/30419
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.14
Topics ET: matemaatika, kokkuvõte, õppekäik, raamatukokku, paaristöö
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Õppekäik raamatukokku; Paaristöö; 1.

## Matilda
URL: https://www.opiq.ee/kit/533/chapter/30396
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.2
Topics ET: matemaatika, matilda, roald, dahl, raamatuneelaja, mille, poolest, eriline, laps, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Matilda; Roald Dahl; Matilda – raamatuneelaja; 1. Mille poolest oli Matilda eriline laps?; Küsimusi ja ülesandeid; 2. Pildid ja lugu; 3. Milline Matilda on?; 4. Arutle ja kujutle

## Raamatukogud
URL: https://www.opiq.ee/kit/533/chapter/30397
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.3
Topics ET: matemaatika, raamatukogud, mida, saab, raamatukogus, teha, milliseid, raamatukogusid, olemas
Topics RU: математика
Topics EN: mathematics
Headings: Raamatukogud; Mida saab raamatukogus teha?; Milliseid raamatukogusid on olemas?

## Õige, selge ja ilus keel
URL: https://www.opiq.ee/kit/533/chapter/30398
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.4
Topics ET: matemaatika, õige, selge, ilus, keel, keelemaja, milline, arutle, tellistest, saab
Topics RU: математика
Topics EN: mathematics
Headings: Õige, selge ja ilus keel; Keelemaja; 1. Milline on hea ja ilus keel?; 2. Loe ja arutle; Tellistest saab teha; Küsimusi ja ülesandeid; 3. Kujutle ja arutle

## Helilised ja helitud häälikud
URL: https://www.opiq.ee/kit/533/chapter/30399
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.5
Topics ET: matemaatika, helilised, helitud, häälikud, kaunimad, sõnad, katseta, häälikurühmad, rühmita, liite
Topics RU: математика
Topics EN: mathematics
Headings: Helilised ja helitud häälikud; Kaunimad sõnad; 1. Katseta; 2. Häälikurühmad; 3. Rühmita; -ki ja -gi; 4. Kas -ki või -gi?; 5. gi- ja ki-liite tähendus; Küsimusi ja ülesandeid; 6. Kõlavad nimed; 7. Kõlavad laused

## Karupoeg Puhh
URL: https://www.opiq.ee/kit/533/chapter/30400
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.6
Topics ET: matemaatika, karupoeg, puhh, alan, alexander, milne, neljas, peatükk, iiah, kaotab
Topics RU: математика
Topics EN: mathematics
Headings: Karupoeg Puhh; Alan Alexander Milne; Neljas peatükk, kus Iiah kaotab ja Puhh leiab ühe saba; 1. Puhh ja Iiah; 2. Metsa kirjeldus; 3. Öökulli teated; Küsimusi ja ülesandeid; 4. Arutle; 5. Kavapunktid; 6. Puhhi head omadused; Sõnapank; 7. Kas tead nende sõnade tähendust?; 8. Ühenda paarid; 9. Täida lüngad

## Helitu häälik kaashääliku­ühendis
URL: https://www.opiq.ee/kit/533/chapter/30401
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.7
Topics ET: matemaatika, helitu, häälik, kaashääliku, ühendis, hääliku, naabrid, sulghäälik, kõrval, erandlik
Topics RU: математика
Topics EN: mathematics
Headings: Helitu häälik kaashääliku­ühendis; Helitu hääliku naabrid; 1. Sulghäälik helitu hääliku kõrval; 2. Erandlik sulghäälik; Küsimusi ja ülesandeid; 3. Õige sulghäälik; 4. Sõnad pildilt; 5. Vigased sõnad; 6. Väljendid

## Kuidas raamatukogu kasutada?
URL: https://www.opiq.ee/kit/533/chapter/30402
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.8
Topics ET: matemaatika, kuidas, raamatukogu, kasutada, teabekirjandus, kataloog, ester, uuri, kataloogi, raamatu
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas raamatukogu kasutada?; 1. Teabekirjandus; E-kataloog ESTER; 2. Uuri kataloogi; Raamatu staatus; Otsing kataloogis; 3. Arutage pinginaabriga; Küsimusi ja ülesandeid; 4. Raamaturiiulid; Kas juturaamatud?; Riiulite süsteem; Autorite nimed

## Ahastav algus
URL: https://www.opiq.ee/kit/533/chapter/30415
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 3.9
Topics ET: matemaatika, ahastav, algus, lemony, snicket, küsimusi, ülesandeid, lapsed, kohtunik, strauss
Topics RU: математика
Topics EN: mathematics
Headings: Ahastav algus; Lemony Snicket; Küsimusi ja ülesandeid; 1. Lapsed ja kohtunik Strauss; Laste probleem; Laste elu; Kohtunik Strauss; Straussi maja; 2. Sündmused ja mõtted-tunded; 3. Arutle ja jutusta

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/30607
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.1
Topics ET: matemaatika, teema, sissejuhatus, infot, otsimas, arutlege, kust, kelle, käest, saad
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Infot otsimas; 1. Arutlege!; 2. Kust ja kelle käest saad sina infot?

## Kokkuvõte. Referaat
URL: https://www.opiq.ee/kit/533/chapter/30616
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.10
Topics ET: matemaatika, kokkuvõte, referaat, info, kogumine, kavandamine, mustandi, kirjutamine, kaaslaste, tagasiside
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Referaat; 1. Info kogumine; 2. Kavandamine; 3. Mustandi kirjutamine; 4. Kaaslaste tagasiside küsimine; 5. Viimistlemine; 6. Esitlemine

## Jõulu­meeleolus
URL: https://www.opiq.ee/kit/533/chapter/30617
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.11
Topics ET: matemaatika, jõulu, meeleolus, õunad, linnukeste, jõululaul, paigalinnud, kiri, jõuluvanale, jõulukaardid
Topics RU: математика
Topics EN: mathematics
Headings: Jõulu­meeleolus; Õunad; Linnukeste jõululaul; Paigalinnud; Kiri jõuluvanale; Jõulukaardid

## Pettsoni jõulud
URL: https://www.opiq.ee/kit/533/chapter/30618
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.12
Topics ET: matemaatika, pettsoni, jõulud, sven, nordqvist, katkendi, algus, vihje, võrdlused, külajutud
Topics RU: математика
Topics EN: mathematics
Headings: Pettsoni jõulud; Sven Nordqvist; Katkendi algus; Vihje; Võrdlused; Külajutud; Küsimusi ja ülesandeid; 6. Arutle ja uuri; 7. Sõnum

## Aasta lõpp
URL: https://www.opiq.ee/kit/533/chapter/30619
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.13
Topics ET: matemaatika, aasta, lõpp
Topics RU: математика
Topics EN: mathematics
Headings: Aasta lõpp; Aasta

## Õppimismasin
URL: https://www.opiq.ee/kit/533/chapter/30608
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.2
Topics ET: matemaatika, õppimismasin, tarkus, pääkraamist, mida, kasutatakse, vähe, väga, harva, mõistus, seda, tuleb, inimesel, tarvis, igal, päeval
Topics RU: математика
Topics EN: mathematics
Headings: Õppimismasin; Tarkus on see osa pääkraamist, mida kasutatakse vähe või väga harva, aga mõistus, seda tuleb inimesel tarvis igal päeval ja ööl.; Juhan Jaik; Tarkus ja mõistus; Küsimusi ja ülesandeid; 2. Juku ja Jaan; Juku tarkus; Jaani tarkus; Juku kadedus; Omadused; 3. Arutle

## Nimisõnad
URL: https://www.opiq.ee/kit/533/chapter/30609
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.3
Topics ET: matemaatika, liitmine, liida, summa, kokku, nimisõnad, küsimus, sõnaliik, nimisõnade, lahkukirjutamine, küsimusi, ülesandeid, leia
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Nimisõnad; Küsimus; Sõnaliik; Nimisõnade kokku- ja lahkukirjutamine; Küsimusi ja ülesandeid; 2. Leia nimisõnad; 3. Moodusta nimisõnu; 4. Kokku või lahku?; 5. Sõnamäng

## Tagasi kodus
URL: https://www.opiq.ee/kit/533/chapter/30610
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.4
Topics ET: matemaatika, tagasi, kodus, astrid, reinla, algus, küsimusi, ülesandeid, teofrastus, väljend
Topics RU: математика
Topics EN: mathematics
Headings: Tagasi kodus; Astrid Reinla; Loo algus; Küsimusi ja ülesandeid; 2. Teofrastus; 3. Väljend; 4. Kirjelda ja jutusta; Lemmikloomad; 5. Arutlege

## Raamat infoallikana – sisukord ja aineregister
URL: https://www.opiq.ee/kit/533/chapter/30611
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.5
Topics ET: matemaatika, raamat, infoallikana, sisukord, aineregister, kuidas, leida, infot, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Raamat infoallikana – sisukord ja aineregister; Kuidas leida infot; Küsimusi ja ülesandeid; 1. Milline on kõige vajalikum info?; 2. Kust leida infot?; Sisukord; 3. Uuri sisukorda; Aineregister; 4. Uuri aineregistrit; Mitu leheküljenumbrit; Leheküljenumbrid; Teemad; Milline märksõna?; Milline märksõna? (2); Milline märksõna? (3); Millised märksõnad? (4); Sõnapaarid

## Omadussõnad
URL: https://www.opiq.ee/kit/533/chapter/30612
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.6
Topics ET: matemaatika, liitmine, liida, summa, kokku, omadussõnad, küsimus, sõnaliik, omadussõnade, lahkukirjutamine, näidete, lisamine, küsimusi
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Omadussõnad; Küsimus; Sõnaliik; Omadussõnade kokku-lahkukirjutamine; Näidete lisamine; Küsimusi ja ülesandeid; 2. Täiendav omadussõna; 3. Puuduvad omadussõnad; 4. Omadus- või nimisõna?; 5. Tähenduste erinevused; Kokku või lahku?

## Arvutihullud
URL: https://www.opiq.ee/kit/533/chapter/30613
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.7
Topics ET: matemaatika, arvutihullud, wimberg, hommik, korteris, päeval, õnnetus, tegelased, arvuti, näidend
Topics RU: математика
Topics EN: mathematics
Headings: Arvutihullud; Wimberg; 1. Hommik korteris; 2. Päeval; 3. Õnnetus; 4. Tegelased ja arvuti; Näidend; 5. Näidendi osad; Näidendi osad lünktekstis; Küsimusi ja ülesandeid; 6. Milleks arvutit kasutatakse?; 7. Arutle; 8. Stseeni lavastamine; 9. Klassitöö: interneti reeglid

## Arvsõnad
URL: https://www.opiq.ee/kit/533/chapter/30614
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.8
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, arvsõnad, küsimus, sõnaliik, arvsõnade, lahkukirjutamine, kirjuta, sõnadega
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: Arvsõnad; Küsimus; Sõnaliik; Arvsõnade kokku-lahkukirjutamine; Kirjuta arvud sõnadega; Küsimusi ja ülesandeid; 4. Reeglid; 5. Arvsõnad pealkirjades; 6. Viktoriiniküsimused

## Lemmiklooma­päev
URL: https://www.opiq.ee/kit/533/chapter/30615
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 4.9
Topics ET: matemaatika, lemmiklooma, päev, piret, raud, lemmikloomapäev, algus, küsimusi, ülesandeid, laused
Topics RU: математика
Topics EN: mathematics
Headings: Lemmiklooma­päev; Piret Raud; Lemmikloomapäev; Loo algus; Küsimusi ja ülesandeid; 3. Laused teksti kohta; 4. Kava; 5. Väljend; 6. Arutlege ja uurige; Klassikaaslaste lemmikloomad

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/30718
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.1
Topics ET: matemaatika, teema, sissejuhatus, millest, lugu, koosneb, arutlege, oled, väitega, nõus
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Millest lugu koosneb?; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Lahenda ülesanne

## Olevik ja minevik
URL: https://www.opiq.ee/kit/533/chapter/30727
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.10
Topics ET: matemaatika, olevik, minevik, tegevus, lõpetatud, kestab, veel, pööra, sõnu, rääkima
Topics RU: математика
Topics EN: mathematics
Headings: Olevik ja minevik; Kas tegevus on lõpetatud või kestab veel?; 1. Pööra sõnu; 1. Pööra rääkima; 2. Pööra vestma; 2. Minevik ja pööre; Küsimusi ja ülesandeid; 3. Ajavorm ja küsimus; 4. Õige vorm; 5. Hopide aja väljendamine; Ajavorm; 6. Paranda vale ajavorm

## Masina jalad
URL: https://www.opiq.ee/kit/533/chapter/30728
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.11
Topics ET: matemaatika, masina, jalad, elar, kuus, mida, nimetati, masinaks, pidasid, lapsed
Topics RU: математика
Topics EN: mathematics
Headings: Masina jalad; Elar Kuus; Mida nimetati masinaks?; 3. Mida pidasid lapsed masinaks?; Rongi ime; Küsimusi ja ülesandeid; 5. Tegelased; 6. Arutle; 7. Tegevusaeg

## Lucy kiikab kapiuksest sisse
URL: https://www.opiq.ee/kit/533/chapter/30729
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.12
Topics ET: matemaatika, lucy, kiikab, kapiuksest, sisse, lewis, küsimusi, ülesandeid, peategelane, paranda
Topics RU: математика
Topics EN: mathematics
Headings: Lucy kiikab kapiuksest sisse; C. S. Lewis; Küsimusi ja ülesandeid; 1. Peategelane; 2. Paranda kavapunktid; 3. Põhjused; Lapsed maal; Põnev maja; 4. Tegevusaeg ja -koht; Sõnapank; 5. Sõnade tähendus; 6. Laused

## Eitus ja jaatus
URL: https://www.opiq.ee/kit/533/chapter/30730
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.13
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, eitus, jaatus, eitav, jaatav, kõne, küsimusi, ülesandeid, eitava, vormid
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Eitus ja jaatus; Mis on eitav ja jaatav kõne?; Küsimusi ja ülesandeid; 4. Eitava kõne vormid; 5. Võrdle; 6. Eitus ja jaatus luuletuses

## Luuletusi aastaaegadest
URL: https://www.opiq.ee/kit/533/chapter/30732
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.14
Topics ET: matemaatika, luuletusi, aastaaegadest, suurvee, aegu, täis, mured, sügisene, lugu, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Luuletusi aastaaegadest; Suurvee aegu; Täis; Mured; Sügisene lugu; Küsimusi ja ülesandeid

## Kokkuvõte. Tegelased, sündmustik, koht ja aeg
URL: https://www.opiq.ee/kit/533/chapter/30731
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.15
Topics ET: matemaatika, aeg, kell, kalender, kokkuvõte, tegelased, sündmustik, koht, täida
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Kokkuvõte. Tegelased, sündmustik, koht ja aeg; Täida ülesanded

## Tegelased
URL: https://www.opiq.ee/kit/533/chapter/30719
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.2
Topics ET: matemaatika, tegelased, loos, tegutsevad, tunned, tegelast, meenuta, tegelasi, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Tegelased; Kes loos tegutsevad?; 1. Kas tunned tegelast?; 2. Meenuta tegelasi; Küsimusi ja ülesandeid; 3. Kujutle ja arutle; 4. Sama lugu, eri tegelased

## Rasmus, Pontus ja Lontu
URL: https://www.opiq.ee/kit/533/chapter/30720
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.3
Topics ET: matemaatika, raha, euro, sent, rasmus, pontus, lontu, astrid, lindgren, kuhu, küsimusi, ülesandeid
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: Rasmus, Pontus ja Lontu; Astrid Lindgren; Kuhu raha sai?; Küsimusi ja ülesandeid; 2. Tegelased; 3. Mis loos juhtub?; 4. Katkendi pealkiri; 5. Arutlege; Sõnapank; 6. Tähendused; 7. Sõnad lauses; Sõnapank 2; Lause tegemine

## Loo tegevustik ehk sündmustik
URL: https://www.opiq.ee/kit/533/chapter/30721
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.4
Topics ET: matemaatika, tegevustik, sündmustik, millest, lugu, koosneb, küsimusi, ülesandeid, läbi, sisse
Topics RU: математика
Topics EN: mathematics
Headings: Loo tegevustik ehk sündmustik; Millest lugu koosneb?; Küsimusi ja ülesandeid; 1. Loe läbi sisse­juhatused ja täida ülesanded

## Koer ja koiott
URL: https://www.opiq.ee/kit/533/chapter/30722
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.5
Topics ET: matemaatika, koer, koiott, petrone, küsimusi, ülesandeid, tegelased, nende, teod, ülesehitus
Topics RU: математика
Topics EN: mathematics
Headings: Koer ja koiott; Epp Petrone; Küsimusi ja ülesandeid; 1. Tegelased ja nende teod; 2. Loo ülesehitus; 3. Väljend; 4. Kava

## Tegusõna pöörded
URL: https://www.opiq.ee/kit/533/chapter/30723
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.6
Topics ET: matemaatika, tegusõna, pöörded, sõnad, väljendavad, tegevust, küsimus, sõnaliik, pööramine, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Tegusõna pöörded; Sõnad, mis väljendavad tegevust; Küsimus; Sõnaliik; Pööramine; Küsimusi ja ülesandeid; 4. Tegusõna küsimus ja pööre; 5. Tegusõnade pöörde- ja algvorm

## Tegevuskoht
URL: https://www.opiq.ee/kit/533/chapter/30724
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.7
Topics ET: matemaatika, tegevuskoht, sündmused, toimuvad, kujutle, tegevuspaiku, bianca, maria, tricarico, trummilinn
Topics RU: математика
Topics EN: mathematics
Headings: Tegevuskoht; Kus sündmused toimuvad?; 1. Kujutle tegevuspaiku; Bianca Maria Tricarico, „Trummilinn“; Trummilinn; „Ahahahaa-​Ehehehee-Ihihihii-​Ohohohoo-; 2. Milline on Trummilinn?; Küsimusi ja ülesandeid; 3. Tegevuspaigad

## Trummilinn
URL: https://www.opiq.ee/kit/533/chapter/30725
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.8
Topics ET: matemaatika, liitmine, liida, summa, kokku, trummilinn, sissetung, hirmuvalitsus, küsimusi, ülesandeid, võta, lugu, arutlege
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Trummilinn; Sissetung; Hirmuvalitsus; Küsimusi ja ülesandeid; 1. Võta lugu kokku; 2. Arutlege; 3. Rühmatöö; Sõnapank; 4. Sõnade tähendus; 5. Sõnaliigid; 6. Näitelaused

## Tegevusaeg
URL: https://www.opiq.ee/kit/533/chapter/30726
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 5.9
Topics ET: matemaatika, tegevusaeg, millal, sündmused, toimuvad, loetud, lugudes, kuidas, tegevusaja, teada
Topics RU: математика
Topics EN: mathematics
Headings: Tegevusaeg; Millal sündmused toimuvad?; 1. Tegevusaeg loetud lugudes; Kuidas tegevusaja teada saab?; Küsimusi ja ülesandeid; 2. Tegevusaeg „Trummilinnas“; 3. Tegevuskoht pildil ja loos; 4. Leia tegevusaeg ja muuda seda

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/30784
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.1
Topics ET: matemaatika, teema, sissejuhatus, kuidas, juttu, lugeda, kirjutada, arutlege, oled, väitega
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Kuidas juttu lugeda ja kirjutada?; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Täringumäng

## Teema ja pealkiri
URL: https://www.opiq.ee/kit/533/chapter/30793
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.10
Topics ET: matemaatika, teema, pealkiri, pusa, jälg, küsimusi, ülesandeid, kirjeldus, lugu, liisa
Topics RU: математика
Topics EN: mathematics
Headings: Teema ja pealkiri; Pusa jälg; Küsimusi ja ülesandeid; 1. Kirjeldus või lugu?; Liisa; Juss; Maarja; Joonas; 2. Mis kutsub lugema?; 3. Teema ja pealkiri; 1.; 2.; 3.; 4.; 4. Lugemispalade teemad; 5. Enne kui lähed Lätti; „Minu koolitee“; 6. Lugu „Minu koolitee“; Algus; Lõpp; Järjesta; 7. Loovtöö; „Metsas“; 8. Lugu „Metsas“; Lõigud

## Roheline pall
URL: https://www.opiq.ee/kit/533/chapter/30794
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.11
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, aeg, kell, kalender, roheline, pall, jaan, rannap, küsimusi, ülesandeid, tegelased, tegevuskoht, jutu
Topics RU: математика, деление, раздели, частное, половина, время, часы, календарь
Topics EN: mathematics, division, divide, quotient, half, time, clock, calendar
Headings: Roheline pall; Jaan Rannap; 1.; 2.; 3.; 4.A; 4.B; Küsimusi ja ülesandeid; 5. Tegelased; 6. Tegevuskoht- ja aeg; 7. Jutu ülesehitus; 8. Jaga oma mõtteid; Sõnapank; Harjuta väljendeid; 9.; 10.; 11.; 12.

## Luuletusi Eestist
URL: https://www.opiq.ee/kit/533/chapter/30795
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.12
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, luuletusi, eestist, väike, küünlakuu, eesti, vabariigi, sünnipäev, küsimusi, ülesandeid
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Luuletusi Eestist; See väike maa; Küünlakuu Eesti; Küünlakuu; Eesti Vabariigi sünnipäev; Küsimusi ja ülesandeid; 9. Võrdle luuletuste meeleolu

## Kokkuvõte. Jutu kirjutamine
URL: https://www.opiq.ee/kit/533/chapter/30796
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.13
Topics ET: matemaatika, kokkuvõte, jutu, kirjutamine, jutt, valmib, sammhaaval, teema, täpsustamine, mõtete
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Jutu kirjutamine; Jutt valmib sammhaaval; 1. TEEMA TÄPSUSTAMINE; 2. MÕTETE KOGUMINE; 3. KAVA KOOSTAMINE; 4. MUSTANDI KIRJUTAMINE; 5. MUSTANDI PARANDAMINE; 6. PEALKIRJA LEIDMINE; 7. PUHTANDI KIRJUTAMINE

## Kuhu lapsed said?
URL: https://www.opiq.ee/kit/533/chapter/30785
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.2
Topics ET: matemaatika, kuhu, lapsed, said, indrek, koff, linnapea, sõdurid, pedagoog, viimane
Topics RU: математика
Topics EN: mathematics
Headings: Kuhu lapsed said?; Indrek Koff; Linnapea; 1. Linnapea ja sõdurid; Pedagoog; 2. Pedagoog; Viimane trump; 3. Õpetaja Helle; Küsimusi ja ülesandeid; 4. Tegelaste meetodid; 5. Kujutle; Sõnapank; 6. Väljendid; Väljendid; Sama tähendusega väljendid; 7. Väljendi tähendus

## Võtame loo lühidalt kokku
URL: https://www.opiq.ee/kit/533/chapter/30786
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.3
Topics ET: matemaatika, liitmine, liida, summa, kokku, võtame, lühidalt, loetust, tuleb, saada, harjutame, kokkuvõtte, tegemist
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Võtame loo lühidalt kokku; Loetust tuleb aru saada; Harjutame kokkuvõtte tegemist; Küsimusi ja ülesandeid; 1. Kirjuta; 2. Jutusta; 3. Millal kokku võtta?

## Mis on lause?
URL: https://www.opiq.ee/kit/533/chapter/30787
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.4
Topics ET: matemaatika, lause, mitu, lauset, küsimusi, ülesandeid, sõnade, järjekord, mitte, sama
Topics RU: математика
Topics EN: mathematics
Headings: Mis on lause?; Mis on ja mis ei ole lause?; Mitu lauset?; Küsimusi ja ülesandeid; 1. Sõnade järjekord; 2. Lause või mitte?; Lause või mitte? (1); Lause või mitte? (2); 3. Sama mõte, erinevad laused; 4. Lause algus ja lõpp

## Harjuta kokkuvõtte tegemist
URL: https://www.opiq.ee/kit/533/chapter/30788
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.5
Topics ET: matemaatika, harjuta, kokkuvõtte, tegemist, peaasi, õpetussõnad, küsimusi, ülesandeid, kokkuvõte, ümberjutustus
Topics RU: математика
Topics EN: mathematics
Headings: Harjuta kokkuvõtte tegemist; Pea on peaasi; Õpetussõnad; Küsimusi ja ülesandeid; 1. Kokkuvõte; 2. Ümberjutustus

## Lydia
URL: https://www.opiq.ee/kit/533/chapter/30789
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.6
Topics ET: matemaatika, lydia, koidula, vaidlus, küsimusi, ülesandeid, iseloomustamine, varjunimi, varjunimed, eesti
Topics RU: математика
Topics EN: mathematics
Headings: Lydia; Lydia Koidula; Vaidlus; Küsimusi ja ülesandeid; 2. Lydia iseloomustamine; 3. Varjunimi; Varjunimed; 4. Eesti ja eesti

## Mis on lause eesmärk?
URL: https://www.opiq.ee/kit/533/chapter/30790
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.7
Topics ET: matemaatika, lause, eesmärk, lauseid, mitut, tüüpi, tekstiga, küsimusi, ülesandeid, lõpumärgid
Topics RU: математика
Topics EN: mathematics
Headings: Mis on lause eesmärk?; Lauseid on mitut tüüpi; 1. Töö tekstiga; Küsimusi ja ülesandeid; 2. Lause lõpumärgid; 3. Mis laused need on?; 4. Küsisõnad

## Mu isamaa on minu arm!
URL: https://www.opiq.ee/kit/533/chapter/30791
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.8
Topics ET: matemaatika, isamaa, küsimusi, ülesandeid, läbi, luuletus, tähendus, harjuta, lugemist
Topics RU: математика
Topics EN: mathematics
Headings: Mu isamaa on minu arm!; Küsimusi ja ülesandeid; 1. Loe läbi luuletus „Mu isamaa on minu arm!“.; 2. Isamaa tähendus; 3. Harjuta lugemist

## Jutu ülesehitus
URL: https://www.opiq.ee/kit/533/chapter/30792
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 6.9
Topics ET: matemaatika, jutu, ülesehitus, kuninganna, anni, kevadeigatsus, järjesta, sündmused, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Jutu ülesehitus; Kuninganna Anni kevadeigatsus; 2. Järjesta sündmused; Küsimusi ja ülesandeid; 4. Algus ja pealkiri

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/30820
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.1
Topics ET: matemaatika, teema, sissejuhatus, kirjeldame, arutlege, oled, väitega, nõus, mitte, põhjenda
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Kirjeldame; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Vaata pilte.

## Kuidas hästi kirjeldada?
URL: https://www.opiq.ee/kit/533/chapter/30817
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.10
Topics ET: matemaatika, kuidas, hästi, kirjeldada, terav, pilk, oskuslik, sõnastus, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas hästi kirjeldada?; Terav pilk ja oskuslik sõnastus; Küsimusi ja ülesandeid; Kirjelda; Vana maja kirjeldus

## Luuletusi
URL: https://www.opiq.ee/kit/533/chapter/30818
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.11
Topics ET: matemaatika, luuletusi, kadrioru, pargis, rõõmus, perekond, ütlus, vanapaar, päevavaras
Topics RU: математика
Topics EN: mathematics
Headings: Luuletusi; Kadrioru pargis; Rõõmus perekond; Ütlus; Vanapaar; Päevavaras

## Kokkuvõte. Kirjeldus
URL: https://www.opiq.ee/kit/533/chapter/30819
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.12
Topics ET: matemaatika, kokkuvõte, kirjeldus, kirjelda, pildi, põhjal
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Kirjeldus; Kirjelda pildi põhjal

## Mis on kirjeldamine?
URL: https://www.opiq.ee/kit/533/chapter/30809
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.2
Topics ET: matemaatika, kirjeldamine, kirjeldus, aitab, teksti, sisse, minna, küsimusi, ülesandeid, milleks
Topics RU: математика
Topics EN: mathematics
Headings: Mis on kirjeldamine?; Kirjeldus aitab teksti sisse minna; Küsimusi ja ülesandeid; 1. Milleks kirjeldamine?; 2. Uuri kirjeldusi

## Kummitavad palitud
URL: https://www.opiq.ee/kit/533/chapter/30810
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.3
Topics ET: matemaatika, kummitavad, palitud, aapeli, nähtamatusepulber, väljend, pahed, vinski, apteekri, plaanid
Topics RU: математика
Topics EN: mathematics
Headings: Kummitavad palitud; Aapeli; Nähtamatusepulber; Väljend; Pahed; Vinski ja apteekri plaanid; Küsimusi ja ülesandeid; 5. Kirjeldused; 6. Arutle ja kujutle; 7. Nuputa; Sõnapank; Sõnapanga tähendused; Jutuke; Kasuta sõnu

## Liht- ja liitlause
URL: https://www.opiq.ee/kit/533/chapter/30811
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.4
Topics ET: matemaatika, liht, liitlause, mitu, öeldist, lihtlause, küsimusi, ülesandeid, leia, öeldised
Topics RU: математика
Topics EN: mathematics
Headings: Liht- ja liitlause; Üks või mitu öeldist?; Lihtlause; Liitlause; Küsimusi ja ülesandeid; 1. Leia öeldised; 2. Lisa öeldisi; 3. Lõpeta liitlaused; Teatmeteose tekst; 4. Öeldiseta laused; 5. Kas väide on tõene või väär?; 6. Kuslapuu lehed ja viljad

## Samuel Seebimulli perekond
URL: https://www.opiq.ee/kit/533/chapter/30812
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.5
Topics ET: matemaatika, samuel, seebimulli, perekond, kristiina, kass, samueli, kodu, susannast, arvamus
Topics RU: математика
Topics EN: mathematics
Headings: Samuel Seebimulli perekond; Kristiina Kass; Samueli kodu; Samueli ema; Samuel Susannast; Isa arvamus; Küsimusi ja ülesandeid; 5. Nõuanded tegelastele; 6. Uus pereliige; „Samueli võlupadja“ sünnilugu; 7. Loe ja vasta küsimustele

## Õpime tegelast paremini tundma
URL: https://www.opiq.ee/kit/533/chapter/30813
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.6
Topics ET: matemaatika, õpime, tegelast, paremini, tundma, kuidas, õppida, küsimusi, ülesandeid, katkenditega
Topics RU: математика
Topics EN: mathematics
Headings: Õpime tegelast paremini tundma; Kuidas tegelast tundma õppida?; Küsimusi ja ülesandeid; 1. Töö katkenditega; 4. Ottokari iseloomustus

## Sõjakirves on välja kaevatud
URL: https://www.opiq.ee/kit/533/chapter/30814
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.7
Topics ET: matemaatika, sõjakirves, välja, kaevatud, raud, küsimusi, ülesandeid, tegelased, sündmustik, selles
Topics RU: математика
Topics EN: mathematics
Headings: Sõjakirves on välja kaevatud; Eno Raud; Küsimusi ja ülesandeid; 1. Tegelased ja sündmustik; Kes on selles katkendis peategelane? Põhjenda.; Milles süüdistasid maapoisid Roltsi, Jaani ja Antsu?; Miks otsustati lahinguga õhtuni oodata?; Milles seisnes Jaani plaan?; 2. Arutle; 3. Jutustamine rühmatööna; 4. Loomingulised ülesanded; Sõnapank; Sõnapanga sõnad lausetes; Leia väljendile õige seletus.; Laused sõnade ja väljenditega

## Koondlause
URL: https://www.opiq.ee/kit/533/chapter/30815
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.8
Topics ET: matemaatika, koondlause, samale, küsimusele, vastavad, sõnad, liht, liitlaused, mitmes, lausest
Topics RU: математика
Topics EN: mathematics
Headings: Koondlause; Samale küsimusele vastavad sõnad; Kas liht- või liitlaused?; Mitmes lausest üks; Küsimusi ja ülesandeid; 6. Koondlause omadused; 7. Leia loetelud; 8. Loetelud töövestluses; Kes on pildil?; 8.b; 8.c; 8.d; 9. Jaatusest eitus, eitusest jaatus

## Liitlause kirjavahe­märgid
URL: https://www.opiq.ee/kit/533/chapter/30816
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 7.9
Topics ET: matemaatika, liitlause, kirjavahe, märgid, lihtlausest, liitlauseks, näidislaused, laused, pildi, skeemide
Topics RU: математика
Topics EN: mathematics
Headings: Liitlause kirjavahe­märgid; Lihtlausest liitlauseks; Näidislaused; Laused pildi ja skeemide järgi; Küsimusi ja ülesandeid; 3. Mitu lihtlauset?; 4. Lihtlaused liitlauseteks; 5. Lõpeta lause

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/31173
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.1
Topics ET: matemaatika, teema, sissejuhatus, loeme, muinasjutte, arutlege, oled, väitega, nõus, mitte
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Loeme muinasjutte; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Mängige äraarvamismängu.

## Saatelause kasutamine tekstis
URL: https://www.opiq.ee/kit/533/chapter/31169
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.10
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, saatelause, kasutamine, tekstis, peretütar, vaenelaps, küsimusi, ülesandeid, lõpeta, vestlus
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Saatelause kasutamine tekstis; Peretütar ja vaenelaps; Küsimusi ja ülesandeid; 1. Lõpeta vestlus; Saatelause tegusõna; 2. Kirjuta vihikusse; 3. Nuputa!; 4. Kahekõne pinginaabriga; 5. Korda otsekõne kirjavahe­märke; Sõnapank; 6. Seletus ja näitelause; 7. Sõnad lauses

## Kõnekäänd
URL: https://www.opiq.ee/kit/533/chapter/31170
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.11
Topics ET: matemaatika, kõnekäänd, rebase, vähi, võidujooks, vähk, rebane, milline, puuduvad, sõnad
Topics RU: математика
Topics EN: mathematics
Headings: Kõnekäänd; Rebase ja vähi võidujooks; 1. Vähk ja rebane; Milline on vähk?; Rebane; Mis on kõnekäänd?; 2. Puuduvad sõnad ja tähendused; Vali kõnekäänule õige tähendus; Vali sobiv sõna ja seleta suuliselt kõnekäändude tähendus; Segamini kõnekäänud; Küsimusi ja ülesandeid; 3. Mis on kõnekäänd?; 1. Mis on kõnekäänd?; 4. Loe juttu ilma kõnekäändudeta; 5. Kas kõnekäänd või vanasõna?; 6. Kõnekäänud pildina

## Muinasjutulisi luuletusi
URL: https://www.opiq.ee/kit/533/chapter/31171
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.12
Topics ET: matemaatika, raha, euro, sent, muinasjutulisi, luuletusi, aega, eest, osta, kaarma, pealkiri, väike
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: Muinasjutulisi luuletusi; Aega ei saa raha eest osta (Kaarma); Pealkiri; Väike kuningajutt; Väljend

## Kokkuvõte. Muinasjutu kirjutamine
URL: https://www.opiq.ee/kit/533/chapter/31172
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.13
Topics ET: matemaatika, kokkuvõte, muinasjutu, kirjutamine, kirjuta, juhendi, järgi, muinasjutt
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Muinasjutu kirjutamine; Kirjuta juhendi järgi muinasjutt

## Hiir ja varblane
URL: https://www.opiq.ee/kit/533/chapter/31161
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.2
Topics ET: matemaatika, hiir, varblane, august, jakobson, tegelaste, eesmärk, võrdlused, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Hiir ja varblane; August Jakobson; Tegelaste eesmärk; Võrdlused; Küsimusi ja ülesandeid; 1. Nuputa!; Sõnapaarid; Teraviljade nimetused; Sõnapank; 2. Harjuta sõnu; Sõnad tähestiku järjekorras; Sõnade tähendused; Sõnade tähendused II; Sõnad lausetes

## Otsekõne ja saatelause
URL: https://www.opiq.ee/kit/533/chapter/31162
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.3
Topics ET: matemaatika, otsekõne, saatelause, skeem, küsimusi, ülesandeid, lausepaarid, saate, lausete, märkimine
Topics RU: математика
Topics EN: mathematics
Headings: Otsekõne ja saatelause; Mis on otsekõne?; Skeem; Küsimusi ja ülesandeid; 1. Lausepaarid; 2. Otsekõne ja saate­lausete märkimine; 1. Otsekõne märkimine; 2. Saatelause märkimine; 3. Saatelause kirjutamine

## Mis on muinasjutt?
URL: https://www.opiq.ee/kit/533/chapter/31163
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.4
Topics ET: matemaatika, muinasjutt, muinasjutule, iseloomulik, hiir, varblane, küsimusi, ülesandeid, tegelaste, omadused
Topics RU: математика
Topics EN: mathematics
Headings: Mis on muinasjutt?; Mis on muinasjutule iseloomulik?; „Hiir ja varblane“; Küsimusi ja ülesandeid; 1. Tegelaste omadused; 2. Meenuta ja arutle

## Lonkav rebane
URL: https://www.opiq.ee/kit/533/chapter/31164
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.5
Topics ET: matemaatika, lonkav, rebane, küsimusi, ülesandeid, tegelased, sündmustik, käivitav, sündmus, väljend
Topics RU: математика
Topics EN: mathematics
Headings: Lonkav rebane; Küsimusi ja ülesandeid; 1. Tegelased ja sündmustik; Tegelased; Käivitav sündmus; Käivitav sündmus II; Rebane; Väljend; Sõnapank; 2. Tähestiku järjekord; 3. Tähendused; Sõnade tähendus; Sõnade tähendus II; 4. Sõnad lausetes; Sõnad lausetes II

## Otsekõne kirjavahemärgid
URL: https://www.opiq.ee/kit/533/chapter/31165
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.6
Topics ET: matemaatika, otsekõne, kirjavahemärgid, kuidas, tähistatakse, otsekõnet, küsimusi, ülesandeid, paarilisega, lugemine
Topics RU: математика
Topics EN: mathematics
Headings: Otsekõne kirjavahemärgid; Kuidas tähistatakse otsekõnet?; Küsimusi ja ülesandeid; 1. Paarilisega lugemine; 2. Vestluse kirjutamine

## Puulane ja Tohtlane
URL: https://www.opiq.ee/kit/533/chapter/31166
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.7
Topics ET: matemaatika, puulane, tohtlane, friedrich, reinhold, kreutzwald, küsimusi, ülesandeid, vanaperemees, uuri
Topics RU: математика
Topics EN: mathematics
Headings: Puulane ja Tohtlane; Friedrich Reinhold Kreutzwald; Küsimusi ja ülesandeid; 1. Vanaperemees; 2. Uuri teksti ja arutle; 3. Loe lepingut; Sõnapank; 4. Sõnade seletused

## Kunst­muinasjutud
URL: https://www.opiq.ee/kit/533/chapter/31167
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.8
Topics ET: matemaatika, kunst, muinasjutud, kunstmuinasjutt, küsimusi, ülesandeid, autor, anderseni, arutle, teisi
Topics RU: математика
Topics EN: mathematics
Headings: Kunst­muinasjutud; Mis on kunstmuinasjutt?; Küsimusi ja ülesandeid; 1. Kes on autor?; 2. Anderseni muinasjutud; 3. Arutle; 4. Teisi kunstmuinasjutte; 5. Illustraator

## Vanasõna
URL: https://www.opiq.ee/kit/533/chapter/31168
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 8.9
Topics ET: matemaatika, vanasõna, nõia, lapsed, arutle, sobiv, millised, neist, vanasõnad, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Vanasõna; Nõia lapsed; 1. Arutle; 2. Sobiv vanasõna; Mis on vanasõna?; 3. Millised neist on vanasõnad?; Küsimusi ja ülesandeid; 4. Mis on vanasõna?; 5. Vanasõna lõpetamine; 6. Vanasõnasse sobiv sõna; 7. Lõpeta vanasõnad; 8. Vanasõna pealkirjaks

## Teema sissejuhatus
URL: https://www.opiq.ee/kit/533/chapter/31184
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.1
Topics ET: matemaatika, teema, sissejuhatus, sõna, pilt, arutlege, oled, väitega, nõus, mitte
Topics RU: математика
Topics EN: mathematics
Headings: Teema sissejuhatus; Sõna ja pilt; 1. Arutlege!; 2. Kas oled väitega nõus või mitte? Põhjenda.; 3. Vaata pilte.

## Luuletusi
URL: https://www.opiq.ee/kit/533/chapter/31182
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.10
Topics ET: matemaatika, luuletusi, riimimäng, kohad, soovitus, pealkiri, ilus, algus, ratta, tähendus
Topics RU: математика
Topics EN: mathematics
Headings: Luuletusi; Riimimäng; Kohad; Soovitus; Pealkiri; Ilus algus; Ratta tähendus; 6. Jalgratta kirjeldus; 7. Jalgrattasõit; Suur Rõõm ja väike Mure; Mõte

## Kokkuvõte. Pildiseeria põhjal loo kirjutamine
URL: https://www.opiq.ee/kit/533/chapter/31183
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.11
Topics ET: matemaatika, kokkuvõte, pildiseeria, põhjal, kirjutamine, kirjuta, piltide, järgi, lugu, elevant
Topics RU: математика
Topics EN: mathematics
Headings: Kokkuvõte. Pildiseeria põhjal loo kirjutamine; Kirjuta piltide järgi lugu; Elevant ja hiir; Piltide põhjal lugu

## Pilt kõneleb
URL: https://www.opiq.ee/kit/533/chapter/31174
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, pilt, kõneleb, täidab, ülesannet, pilte, koomiks, koomiksit, täida
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Pilt kõneleb; Pilt täidab ülesannet; 1. Võrdle pilte; Koomiks; 2. Loe koomiksit ja täida ülesanded; Oti õnnetus; 3. Uuri pilti ja täida ülesanded; Ebaoluline info; Sobimatu kõnepruuk; Isemoodi arusaam

## Siberi haiku
URL: https://www.opiq.ee/kit/533/chapter/31175
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.3
Topics ET: matemaatika, siberi, haiku, jurga, lina, itagaki, küsimusi, ülesandeid, lugu, mida
Topics RU: математика
Topics EN: mathematics
Headings: Siberi haiku; Jurga Vilė, Lina Itagaki; Küsimusi ja ülesandeid; 1. Lugu; Kes mida tegi?; 2. Taustateadmine; 3. Loo vorm; „Siberi haiku“ vorm (TV h 131)

## Sünonüümid
URL: https://www.opiq.ee/kit/533/chapter/31176
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.4
Topics ET: matemaatika, sünonüümid, hunt, susi, küsimusi, ülesandeid, mitmekesisem, sõnavara, sünonüümidega, laused
Topics RU: математика
Topics EN: mathematics
Headings: Sünonüümid; Hunt ja susi; Küsimusi ja ülesandeid; 1. Mitmekesisem sõnavara; Sünonüümidega laused; 2. Loe luuletust ja vasta küsimustele; Kirjuta sünonüüm; 3. Lihtsam sõnavara; 2. Ilmekusega ei tasu liialdada

## Maailma naba
URL: https://www.opiq.ee/kit/533/chapter/31177
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.5
Topics ET: matemaatika, maailma, naba, joonas, sildre, küsimusi, ülesandeid, mida, mari, tegi
Topics RU: математика
Topics EN: mathematics
Headings: Maailma naba; Joonas Sildre; Küsimusi ja ülesandeid; 1. Mida Mari tegi?; 2. Tegelased; 3. Väljend; 4. Uuri peatükis olnud pilte

## Mitme­tähenduslikud sõnad
URL: https://www.opiq.ee/kit/533/chapter/31178
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.6
Topics ET: matemaatika, mitme, tähenduslikud, sõnad, ühel, sõnal, mitu, tähendust, küsimusi, ülesandeid
Topics RU: математика
Topics EN: mathematics
Headings: Mitme­tähenduslikud sõnad; Ühel sõnal mitu tähendust; Küsimusi ja ülesandeid; 1. Kumb tähendus; 1. Kumb tähendus?; Kumb tähendus? (2); 2. Sõnade mitu tähendust; 3. Tähendus selgub ümbrusest

## Ema teeb teed ja isa teeb teed
URL: https://www.opiq.ee/kit/533/chapter/31179
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.7
Topics ET: matemaatika, teeb, teed, küsimusi, ülesandeid, sõnade, mitu, tähendust, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Ema teeb teed ja isa teeb teed; Küsimusi ja ülesandeid; 1. Loe; 2. Sõnade mitu tähendust; 3. Kirjuta

## Antonüümid
URL: https://www.opiq.ee/kit/533/chapter/31180
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.8
Topics ET: matemaatika, antonüümid, vana, millal, kasutatakse, vastandsõnu, vanasõnades, küsimusi, ülesandeid, kasuta
Topics RU: математика
Topics EN: mathematics
Headings: Antonüümid; Vana ja uus; Millal kasutatakse vastandsõnu?; Antonüümid vanasõnades; Küsimusi ja ülesandeid; 1. Kasuta antonüümi; 2. Vastandpilt; Vastandsõna; 3. Kirjuta ja loe; Kirjuta jutt; 4. Milline vastandsõna?

## Sõnad
URL: https://www.opiq.ee/kit/533/chapter/31181
Book: Eesti keel 4. klassile 2024 – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: eesti_keel_4._klassile_2024
Chapter ID: 9.9
Topics ET: matemaatika, sõnad, pead, kõik, välja, ütlema, küsimusi, ülesandeid, kokkuvõte, põhjendused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnad; Kas sa pead kõik välja ütlema?; Küsimusi ja ülesandeid; 1. Kokkuvõte ja põhjendused; 2. Joonista; Sõnapank; 3. Väljendid; Väljendid lausetes

## SINASÕPRUS KEELEGA – Opiq
URL: https://www.opiq.ee/Kit/Details/154
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 269
Topics ET: matemaatika, sinasõprus, keelega, opiq
Topics RU: математика
Topics EN: mathematics

## SINASÕPRUS KEELEGA – Opiq
URL: https://www.opiq.ee/Kit/Details/154
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 407
Topics ET: matemaatika, sinasõprus, keelega, opiq
Topics RU: математика
Topics EN: mathematics

## Sissejuhatus
URL: https://www.opiq.ee/kit/154/chapter/8629
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.1
Topics ET: matemaatika, sissejuhatus, kallis, neljanda, klassi, õpilane
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus; * * *; Kallis neljanda klassi õpilane!

## Morsetähestik
URL: https://www.opiq.ee/kit/154/chapter/8622
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.10
Topics ET: matemaatika, morsetähestik, tähestik, häälikute, liigid, rõhuliide, liide
Topics RU: математика
Topics EN: mathematics
Headings: Morsetähestik; Tähestik; Häälikute liigid ja rõhuliide; Liide -gi/-ki

## Õnnetu maja
URL: https://www.opiq.ee/kit/154/chapter/8623
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.11
Topics ET: matemaatika, õnnetu, maja, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Õnnetu maja; Lisaharjutus

## Kodutu
URL: https://www.opiq.ee/kit/154/chapter/8624
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.12
Topics ET: matemaatika, kodutu
Topics RU: математика
Topics EN: mathematics
Headings: Kodutu; i ja j

## Lemmikloom ei tee pahandust põhjuseta
URL: https://www.opiq.ee/kit/154/chapter/8625
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.13
Topics ET: matemaatika, lemmikloom, pahandust, põhjuseta
Topics RU: математика
Topics EN: mathematics
Headings: Lemmikloom ei tee pahandust põhjuseta

## Onu Teodor
URL: https://www.opiq.ee/kit/154/chapter/8626
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.14
Topics ET: matemaatika, teodor
Topics RU: математика
Topics EN: mathematics
Headings: Onu Teodor

## Naljakate juhtumite vihik
URL: https://www.opiq.ee/kit/154/chapter/8627
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.15
Topics ET: matemaatika, naljakate, juhtumite, vihik
Topics RU: математика
Topics EN: mathematics
Headings: Naljakate juhtumite vihik

## Minu pere
URL: https://www.opiq.ee/kit/154/chapter/8633
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.16
Topics ET: matemaatika, pere
Topics RU: математика
Topics EN: mathematics
Headings: Minu pere

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8628
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.17
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 1
URL: https://www.opiq.ee/kit/154/chapter/18221
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.18
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 1

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8630
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.2
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Kodune laul
URL: https://www.opiq.ee/kit/154/chapter/8617
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.3
Topics ET: matemaatika, kodune, laul
Topics RU: математика
Topics EN: mathematics
Headings: Kodune laul

## Sõnamäng
URL: https://www.opiq.ee/kit/154/chapter/8618
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.4
Topics ET: matemaatika, sõnamäng, häälik, täht, mitu, tähte, häälikut
Topics RU: математика
Topics EN: mathematics
Headings: Sõnamäng; Häälik ja täht; Mitu tähte ja mitu häälikut?

## Tracy Beaker
URL: https://www.opiq.ee/kit/154/chapter/8619
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.5
Topics ET: matemaatika, tracy, beaker
Topics RU: математика
Topics EN: mathematics
Headings: Tracy Beaker

## Kuklid ja suhkrukringlid
URL: https://www.opiq.ee/kit/154/chapter/8631
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.6
Topics ET: matemaatika, kuklid, suhkrukringlid
Topics RU: математика
Topics EN: mathematics
Headings: Kuklid ja suhkrukringlid

## Pitsakeerud
URL: https://www.opiq.ee/kit/154/chapter/8620
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.7
Topics ET: matemaatika, pitsakeerud
Topics RU: математика
Topics EN: mathematics
Headings: Pitsakeerud

## Mati kirjand
URL: https://www.opiq.ee/kit/154/chapter/8632
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.8
Topics ET: matemaatika, mati, kirjand
Topics RU: математика
Topics EN: mathematics
Headings: Mati kirjand

## Kirja leiutamine
URL: https://www.opiq.ee/kit/154/chapter/8621
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 1.9
Topics ET: matemaatika, kirja, leiutamine, häälikute, liigid, häälikuühendid
Topics RU: математика
Topics EN: mathematics
Headings: Kirja leiutamine; Häälikute liigid; Häälikuühendid

## Sõnaseletused
URL: https://www.opiq.ee/kit/154/chapter/8744
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 10.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Nimede ligikaudne hääldus
URL: https://www.opiq.ee/kit/154/chapter/8745
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 10.2
Topics ET: matemaatika, nimede, ligikaudne, hääldus
Topics RU: математика
Topics EN: mathematics
Headings: Nimede ligikaudne hääldus

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8642
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Minu vahva vanaisa
URL: https://www.opiq.ee/kit/154/chapter/8639
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.10
Topics ET: matemaatika, vahva, vanaisa
Topics RU: математика
Topics EN: mathematics
Headings: Minu vahva vanaisa

## Jürimari pere lood
URL: https://www.opiq.ee/kit/154/chapter/8640
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.11
Topics ET: matemaatika, jürimari, pere, lood
Topics RU: математика
Topics EN: mathematics
Headings: Jürimari pere lood

## Kelleks vana aja lapsed saada tahtsid
URL: https://www.opiq.ee/kit/154/chapter/8646
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.12
Topics ET: matemaatika, kelleks, vana, lapsed, saada, tahtsid
Topics RU: математика
Topics EN: mathematics
Headings: Kelleks vana aja lapsed saada tahtsid

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8641
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.13
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 2
URL: https://www.opiq.ee/kit/154/chapter/18222
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.14
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 2

## Aja lugu
URL: https://www.opiq.ee/kit/154/chapter/8643
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.2
Topics ET: matemaatika, lugu
Topics RU: математика
Topics EN: mathematics
Headings: Aja lugu

## Kellakägu
URL: https://www.opiq.ee/kit/154/chapter/8634
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.3
Topics ET: matemaatika, aeg, kell, kalender, kellakägu, vana, möödus, silbitamine, poolitamine
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Kellakägu; Aeg; Vana aeg; Aeg möödus; Silbitamine ja poolitamine

## Ürgajast
URL: https://www.opiq.ee/kit/154/chapter/8644
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.4
Topics ET: matemaatika, ürgajast
Topics RU: математика
Topics EN: mathematics
Headings: Ürgajast

## Inimese aja lugu
URL: https://www.opiq.ee/kit/154/chapter/8635
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.5
Topics ET: matemaatika, inimese, lugu
Topics RU: математика
Topics EN: mathematics
Headings: Inimese aja lugu

## Vana vaskne laevakell
URL: https://www.opiq.ee/kit/154/chapter/8645
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.6
Topics ET: matemaatika, vana, vaskne, laevakell
Topics RU: математика
Topics EN: mathematics
Headings: Vana vaskne laevakell

## Une-Mati
URL: https://www.opiq.ee/kit/154/chapter/8636
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.7
Topics ET: matemaatika, mati
Topics RU: математика
Topics EN: mathematics
Headings: Une-Mati

## Muti muuseum
URL: https://www.opiq.ee/kit/154/chapter/8637
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.8
Topics ET: matemaatika, muti, muuseum, võõrsõnad
Topics RU: математика
Topics EN: mathematics
Headings: Muti muuseum; Võõrsõnad

## Meri
URL: https://www.opiq.ee/kit/154/chapter/8638
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 2.9
Topics ET: matemaatika, meri
Topics RU: математика
Topics EN: mathematics
Headings: Meri

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8657
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Suhtlus läbi aegade
URL: https://www.opiq.ee/kit/154/chapter/8653
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.10
Topics ET: matemaatika, suhtlus, läbi, aegade
Topics RU: математика
Topics EN: mathematics
Headings: Suhtlus läbi aegade

## Kontrolltöö
URL: https://www.opiq.ee/kit/154/chapter/8654
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.11
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö

## Ühekorruseline koolimaja
URL: https://www.opiq.ee/kit/154/chapter/8655
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.12
Topics ET: matemaatika, ühekorruseline, koolimaja, lisaharjutus, elus, eluta
Topics RU: математика
Topics EN: mathematics
Headings: Ühekorruseline koolimaja; Lisaharjutus; Kas elus või eluta?

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8656
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.13
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 3
URL: https://www.opiq.ee/kit/154/chapter/18223
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.14
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 3

## Ära ütle, et ei oska
URL: https://www.opiq.ee/kit/154/chapter/8658
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.2
Topics ET: matemaatika, ütle, oska
Topics RU: математика
Topics EN: mathematics
Headings: Ära ütle, et ei oska

## Mida vana aja tundides peale õppimise veel tehti
URL: https://www.opiq.ee/kit/154/chapter/8647
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.3
Topics ET: matemaatika, mida, vana, tundides, peale, õppimise, veel, tehti, sõnaliigid, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Mida vana aja tundides peale õppimise veel tehti; Sõnaliigid; Lisaharjutus 1.1; Lisaharjutus 1.2; Lisaharjutus 2.1; Lisaharjutus 2.2; Mängukirjeldused; Trips-traps-trull; Laevade pommitamine; Poomismäng

## Kuninganna Ann läheb kunstikooli
URL: https://www.opiq.ee/kit/154/chapter/8648
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.4
Topics ET: matemaatika, kuninganna, läheb, kunstikooli, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kuninganna Ann läheb kunstikooli; Lisaharjutus

## Peeter ja mina kuivatame puulehti
URL: https://www.opiq.ee/kit/154/chapter/8649
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.5
Topics ET: matemaatika, peeter, mina, kuivatame, puulehti
Topics RU: математика
Topics EN: mathematics
Headings: Peeter ja mina kuivatame puulehti

## Kuki läheb kooli
URL: https://www.opiq.ee/kit/154/chapter/8650
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.6
Topics ET: matemaatika, kuki, läheb, kooli, asesõna
Topics RU: математика
Topics EN: mathematics
Headings: Kuki läheb kooli; Asesõna

## Nõianeiu Nöbinina
URL: https://www.opiq.ee/kit/154/chapter/8651
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.7
Topics ET: matemaatika, nõianeiu, nöbinina
Topics RU: математика
Topics EN: mathematics
Headings: Nõianeiu Nöbinina

## Kiusamine
URL: https://www.opiq.ee/kit/154/chapter/8652
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.8
Topics ET: matemaatika, kiusamine
Topics RU: математика
Topics EN: mathematics
Headings: Kiusamine

## Kui sa krabad…
URL: https://www.opiq.ee/kit/154/chapter/8659
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 3.9
Topics ET: matemaatika, krabad
Topics RU: математика
Topics EN: mathematics
Headings: Kui sa krabad…

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8669
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Jõulud
URL: https://www.opiq.ee/kit/154/chapter/8665
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.10
Topics ET: matemaatika, jõulud
Topics RU: математика
Topics EN: mathematics
Headings: Jõulud

## Jõululuuletused
URL: https://www.opiq.ee/kit/154/chapter/8666
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.11
Topics ET: matemaatika, jõululuuletused, kõige, ilusam, jõulupuu, küünlalaul, aisakellad
Topics RU: математика
Topics EN: mathematics
Headings: Jõululuuletused; Kõige ilusam jõulupuu; Küünlalaul; Aisakellad

## Presidendi uusaastakõne
URL: https://www.opiq.ee/kit/154/chapter/8667
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.12
Topics ET: matemaatika, presidendi, uusaastakõne
Topics RU: математика
Topics EN: mathematics
Headings: Presidendi uusaastakõne

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8668
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.13
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 4
URL: https://www.opiq.ee/kit/154/chapter/18224
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.14
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 4

## Vitsalaul
URL: https://www.opiq.ee/kit/154/chapter/8670
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.2
Topics ET: matemaatika, vitsalaul
Topics RU: математика
Topics EN: mathematics
Headings: Vitsalaul

## Healoog
URL: https://www.opiq.ee/kit/154/chapter/8660
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.3
Topics ET: matemaatika, healoog
Topics RU: математика
Topics EN: mathematics
Headings: Healoog

## Kuidas lund hakkas sadama
URL: https://www.opiq.ee/kit/154/chapter/8661
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.4
Topics ET: matemaatika, kuidas, lund, hakkas, sadama, liitsõna, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas lund hakkas sadama; Liitsõna; Lisaharjutus

## Eks hea olla igaüks tahaks...
URL: https://www.opiq.ee/kit/154/chapter/8671
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.5
Topics ET: matemaatika, olla, igaüks, tahaks
Topics RU: математика
Topics EN: mathematics
Headings: Eks hea olla igaüks tahaks...

## Etsile, muinasjutulisele inimesele
URL: https://www.opiq.ee/kit/154/chapter/8672
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.6
Topics ET: matemaatika, etsile, muinasjutulisele, inimesele
Topics RU: математика
Topics EN: mathematics
Headings: Etsile, muinasjutulisele inimesele

## Kolmapäev. Kollamütsike
URL: https://www.opiq.ee/kit/154/chapter/8662
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.7
Topics ET: matemaatika, kolmapäev, kollamütsike
Topics RU: математика
Topics EN: mathematics
Headings: Kolmapäev. Kollamütsike

## Astelpõõsahaldjas
URL: https://www.opiq.ee/kit/154/chapter/8663
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.8
Topics ET: matemaatika, liitmine, liida, summa, kokku, astelpõõsahaldjas, lahkukirjutamine
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Astelpõõsahaldjas; Kokku- ja lahkukirjutamine

## Viljaküla Brita memuaarid
URL: https://www.opiq.ee/kit/154/chapter/8664
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 4.9
Topics ET: matemaatika, viljaküla, brita, memuaarid, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Viljaküla Brita memuaarid; Lisaharjutus

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8683
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Pöörane puhkus Parakatkus
URL: https://www.opiq.ee/kit/154/chapter/8678
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.10
Topics ET: matemaatika, pöörane, puhkus, parakatkus, tegija, tegusõnas
Topics RU: математика
Topics EN: mathematics
Headings: Pöörane puhkus Parakatkus; Tegija tegusõnas

## Milleks on elevandil lont?
URL: https://www.opiq.ee/kit/154/chapter/8687
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.11
Topics ET: matemaatika, milleks, elevandil, lont
Topics RU: математика
Topics EN: mathematics
Headings: Milleks on elevandil lont?

## Öökull Uhuu rekorditeraamat
URL: https://www.opiq.ee/kit/154/chapter/8679
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.12
Topics ET: matemaatika, öökull, uhuu, rekorditeraamat
Topics RU: математика
Topics EN: mathematics
Headings: Öökull Uhuu rekorditeraamat

## Kaitsealal
URL: https://www.opiq.ee/kit/154/chapter/8680
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.13
Topics ET: matemaatika, kaitsealal
Topics RU: математика
Topics EN: mathematics
Headings: Kaitsealal

## Rästikumürk
URL: https://www.opiq.ee/kit/154/chapter/8688
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.14
Topics ET: matemaatika, rästikumürk
Topics RU: математика
Topics EN: mathematics
Headings: Rästikumürk

## Väike hiiglane
URL: https://www.opiq.ee/kit/154/chapter/8681
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.15
Topics ET: matemaatika, väike, hiiglane
Topics RU: математика
Topics EN: mathematics
Headings: Väike hiiglane

## Loodusluuletused
URL: https://www.opiq.ee/kit/154/chapter/8689
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.16
Topics ET: loodusõpetus, loodusluuletused, sügise, laul, talvine, õhtu, lumehelbeke, nõmmelill, kevade, tunne
Topics RU: природоведение
Topics EN: science
Headings: Loodusluuletused; Sügise laul; Talvine õhtu; Lumehelbeke; Nõmmelill; Kevade tunne

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8682
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.17
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 5
URL: https://www.opiq.ee/kit/154/chapter/18225
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.18
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 5

## Elusloodus
URL: https://www.opiq.ee/kit/154/chapter/8684
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.2
Topics ET: loodusõpetus, elusloodus
Topics RU: природоведение
Topics EN: science
Headings: Elusloodus

## Väga vaikne lõhe
URL: https://www.opiq.ee/kit/154/chapter/8673
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.3
Topics ET: matemaatika, väga, vaikne, lõhe, tegusõna, verb, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Väga vaikne lõhe; Tegusõna ehk verb; Lisaharjutus

## Rõõmus päike
URL: https://www.opiq.ee/kit/154/chapter/8685
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.4
Topics ET: matemaatika, rõõmus, päike
Topics RU: математика
Topics EN: mathematics
Headings: Rõõmus päike

## Kuidas õppida vaatama?
URL: https://www.opiq.ee/kit/154/chapter/8674
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.5
Topics ET: matemaatika, kuidas, õppida, vaatama, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas õppida vaatama?; Lisaharjutus 1; Lisaharjutus 2

## Vihma hääled
URL: https://www.opiq.ee/kit/154/chapter/8675
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.6
Topics ET: matemaatika, vihma, hääled
Topics RU: математика
Topics EN: mathematics
Headings: Vihma hääled

## Taevas muudkui raiskab
URL: https://www.opiq.ee/kit/154/chapter/8686
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.7
Topics ET: matemaatika, taevas, muudkui, raiskab
Topics RU: математика
Topics EN: mathematics
Headings: Taevas muudkui raiskab

## Rebane meres
URL: https://www.opiq.ee/kit/154/chapter/8676
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.8
Topics ET: matemaatika, rebane, meres
Topics RU: математика
Topics EN: mathematics
Headings: Rebane meres

## Metsa pühapäev
URL: https://www.opiq.ee/kit/154/chapter/8677
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 5.9
Topics ET: matemaatika, aeg, kell, kalender, metsa, pühapäev, tegusõna
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Metsa pühapäev; Tegusõna aeg

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8701
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Elektriautod
URL: https://www.opiq.ee/kit/154/chapter/8696
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.10
Topics ET: matemaatika, liitmine, liida, summa, kokku, elektriautod, arvsõnade, lahkukirjutamine, lisaharjutus
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Elektriautod; Arvsõnade kokku- ja lahkukirjutamine; Lisaharjutus

## Arvutusvahendid
URL: https://www.opiq.ee/kit/154/chapter/8704
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.11
Topics ET: matemaatika, arvutusvahendid
Topics RU: математика
Topics EN: mathematics
Headings: Arvutusvahendid

## Arvutid nüüd ja tulevikus
URL: https://www.opiq.ee/kit/154/chapter/8697
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.12
Topics ET: matemaatika, arvutid, nüüd, tulevikus
Topics RU: математика
Topics EN: mathematics
Headings: Arvutid nüüd ja tulevikus

## Konnad kolisid nutitelefoni
URL: https://www.opiq.ee/kit/154/chapter/8698
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.13
Topics ET: matemaatika, konnad, kolisid, nutitelefoni
Topics RU: математика
Topics EN: mathematics
Headings: Konnad kolisid nutitelefoni

## Blogi
URL: https://www.opiq.ee/kit/154/chapter/8699
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.14
Topics ET: matemaatika, blogi
Topics RU: математика
Topics EN: mathematics
Headings: Blogi

## Ilus algus
URL: https://www.opiq.ee/kit/154/chapter/8705
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.15
Topics ET: matemaatika, ilus, algus
Topics RU: математика
Topics EN: mathematics
Headings: Ilus algus

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8700
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.16
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 6
URL: https://www.opiq.ee/kit/154/chapter/18226
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.17
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 6

## Masin
URL: https://www.opiq.ee/kit/154/chapter/8702
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.2
Topics ET: matemaatika, masin
Topics RU: математика
Topics EN: mathematics
Headings: Masin

## Aatomik
URL: https://www.opiq.ee/kit/154/chapter/8690
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.3
Topics ET: matemaatika, aatomik, lause
Topics RU: математика
Topics EN: mathematics
Headings: Aatomik; Lause

## Karlsson katuselt
URL: https://www.opiq.ee/kit/154/chapter/8691
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.4
Topics ET: matemaatika, karlsson, katuselt, lisaharjutus, lause, lõpumärk
Topics RU: математика
Topics EN: mathematics
Headings: Karlsson katuselt; Lisaharjutus 1; Lisaharjutus 2; Lause lõpumärk

## Tulekahju
URL: https://www.opiq.ee/kit/154/chapter/8692
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.5
Topics ET: matemaatika, tulekahju
Topics RU: математика
Topics EN: mathematics
Headings: Tulekahju

## Ta oli juba seal!
URL: https://www.opiq.ee/kit/154/chapter/8693
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.6
Topics ET: matemaatika, juba, seal
Topics RU: математика
Topics EN: mathematics
Headings: Ta oli juba seal!

## Autod
URL: https://www.opiq.ee/kit/154/chapter/8694
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.7
Topics ET: matemaatika, autod, autode, liigid, auto, ajalugu, arvsõnad
Topics RU: математика
Topics EN: mathematics
Headings: Autod; Autode liigid; Auto ajalugu; Arvsõnad

## Võidusõiduautodest
URL: https://www.opiq.ee/kit/154/chapter/8703
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.8
Topics ET: matemaatika, võidusõiduautodest, võidusõiduajastu, algus, boksipeatus, kummide, valimine
Topics RU: математика
Topics EN: mathematics
Headings: Võidusõiduautodest; Võidusõiduajastu algus; Boksipeatus, kummide valimine

## Grand Prix’ legend
URL: https://www.opiq.ee/kit/154/chapter/8695
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 6.9
Topics ET: matemaatika, grand, prix, legend, järgarvud
Topics RU: математика
Topics EN: mathematics
Headings: Grand Prix’ legend; Järgarvud

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8713
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Kuidas alustada näidendi lavastamist?
URL: https://www.opiq.ee/kit/154/chapter/8710
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.10
Topics ET: matemaatika, kuidas, alustada, näidendi, lavastamist
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas alustada näidendi lavastamist?

## Multikas
URL: https://www.opiq.ee/kit/154/chapter/8711
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.11
Topics ET: matemaatika, multikas
Topics RU: математика
Topics EN: mathematics
Headings: Multikas

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8712
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.12
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 7
URL: https://www.opiq.ee/kit/154/chapter/18227
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.13
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 7

## Arabella laul
URL: https://www.opiq.ee/kit/154/chapter/8714
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.2
Topics ET: matemaatika, arabella, laul
Topics RU: математика
Topics EN: mathematics
Headings: Arabella laul

## Piraadid ehk mereröövlid
URL: https://www.opiq.ee/kit/154/chapter/8715
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.3
Topics ET: matemaatika, piraadid, mereröövlid
Topics RU: математика
Topics EN: mathematics
Headings: Piraadid ehk mereröövlid

## Kõige tähtsam mereröövlitele
URL: https://www.opiq.ee/kit/154/chapter/8706
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.4
Topics ET: matemaatika, kõige, tähtsam, mereröövlitele, lause
Topics RU: математика
Topics EN: mathematics
Headings: Kõige tähtsam mereröövlitele; Lause

## Kuidas Birgitist sai Arabella
URL: https://www.opiq.ee/kit/154/chapter/8716
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.5
Topics ET: matemaatika, kuidas, birgitist, arabella
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas Birgitist sai Arabella

## Tüdruk, kes armastas teatrit
URL: https://www.opiq.ee/kit/154/chapter/8707
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.6
Topics ET: matemaatika, tüdruk, armastas, teatrit, nimi, nimetus, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Tüdruk, kes armastas teatrit; Nimi ja nimetus; Lisaharjutus; Lisaharjutus 1.2; Lisaharjutus 1.3; Lisaharjutus 1.4; Lisaharjutus 1.5; Lisaharjutus 1.6; Lisaharjutus 1.7; Lisaharjutus 1.8

## Unustatud nukuteater
URL: https://www.opiq.ee/kit/154/chapter/8708
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.7
Topics ET: matemaatika, unustatud, nukuteater
Topics RU: математика
Topics EN: mathematics
Headings: Unustatud nukuteater

## Pinocchio
URL: https://www.opiq.ee/kit/154/chapter/8709
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.8
Topics ET: matemaatika, pinocchio, liitlause
Topics RU: математика
Topics EN: mathematics
Headings: Pinocchio; Liitlause

## Lugu sellest, kuidas Buratino muinasjutte lappis
URL: https://www.opiq.ee/kit/154/chapter/8717
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 7.9
Topics ET: matemaatika, lugu, sellest, kuidas, buratino, muinasjutte, lappis
Topics RU: математика
Topics EN: mathematics
Headings: Lugu sellest, kuidas Buratino muinasjutte lappis

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8729
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Kratt
URL: https://www.opiq.ee/kit/154/chapter/8724
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.10
Topics ET: matemaatika, kratt
Topics RU: математика
Topics EN: mathematics
Headings: Kratt

## Vaimude tund
URL: https://www.opiq.ee/kit/154/chapter/8725
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.11
Topics ET: matemaatika, vaimude, tund
Topics RU: математика
Topics EN: mathematics
Headings: Vaimude tund

## Nõid Korinti
URL: https://www.opiq.ee/kit/154/chapter/8726
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.12
Topics ET: matemaatika, nõid, korinti, algriim
Topics RU: математика
Topics EN: mathematics
Headings: Nõid Korinti; Algriim

## Nõianõukogu ees
URL: https://www.opiq.ee/kit/154/chapter/8732
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.13
Topics ET: matemaatika, nõianõukogu
Topics RU: математика
Topics EN: mathematics
Headings: Nõianõukogu ees

## Koolitont
URL: https://www.opiq.ee/kit/154/chapter/8727
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.14
Topics ET: matemaatika, koolitont
Topics RU: математика
Topics EN: mathematics
Headings: Koolitont

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8728
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.15
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Kontrolltöö 8
URL: https://www.opiq.ee/kit/154/chapter/18228
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.16
Topics ET: matemaatika, kontrolltöö
Topics RU: математика
Topics EN: mathematics
Headings: Kontrolltöö 8

## Krokodill
URL: https://www.opiq.ee/kit/154/chapter/8730
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.2
Topics ET: matemaatika, krokodill
Topics RU: математика
Topics EN: mathematics
Headings: Krokodill

## Valetamispäev
URL: https://www.opiq.ee/kit/154/chapter/8718
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.3
Topics ET: matemaatika, valetamispäev, otsekõne
Topics RU: математика
Topics EN: mathematics
Headings: Valetamispäev; Otsekõne

## Karlssoni saia-tirriteerimine
URL: https://www.opiq.ee/kit/154/chapter/8719
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.4
Topics ET: matemaatika, karlssoni, saia, tirriteerimine, otsekõne, saatelause
Topics RU: математика
Topics EN: mathematics
Headings: Karlssoni saia-tirriteerimine; Otsekõne ja saatelause

## Sõnaluuletused
URL: https://www.opiq.ee/kit/154/chapter/8720
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.5
Topics ET: matemaatika, sõnaluuletused, sõnapall, sõnaväänaja, sõnategu, sõnamulin, sõnataud
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaluuletused; Sõnapall; Sõnaväänaja; Sõnategu; Sõnamulin; Sõnataud

## Mage ja Soolane
URL: https://www.opiq.ee/kit/154/chapter/8721
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.6
Topics ET: matemaatika, mage, soolane
Topics RU: математика
Topics EN: mathematics
Headings: Mage ja Soolane

## Küsimused
URL: https://www.opiq.ee/kit/154/chapter/8722
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.7
Topics ET: matemaatika, küsimused
Topics RU: математика
Topics EN: mathematics
Headings: Küsimused

## Eesti rahvanaljandid
URL: https://www.opiq.ee/kit/154/chapter/8731
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.8
Topics ET: matemaatika, eesti, rahvanaljandid
Topics RU: математика
Topics EN: mathematics
Headings: Eesti rahvanaljandid

## Sepad
URL: https://www.opiq.ee/kit/154/chapter/8723
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 8.9
Topics ET: matemaatika, sepad
Topics RU: математика
Topics EN: mathematics
Headings: Sepad

## Selles peatükis
URL: https://www.opiq.ee/kit/154/chapter/8739
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.1
Topics ET: matemaatika, selles, peatükis
Topics RU: математика
Topics EN: mathematics
Headings: Selles peatükis

## Onu Heino veeris tähti
URL: https://www.opiq.ee/kit/154/chapter/8743
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.10
Topics ET: matemaatika, heino, veeris, tähti, lisaharjutus
Topics RU: математика
Topics EN: mathematics
Headings: Onu Heino veeris tähti; Lisaharjutus

## Kordamine
URL: https://www.opiq.ee/kit/154/chapter/8738
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.11
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine

## Laul muinasjutust, mis on olemas ainult raamatus
URL: https://www.opiq.ee/kit/154/chapter/8740
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.2
Topics ET: matemaatika, laul, muinasjutust, olemas, ainult, raamatus
Topics RU: математика
Topics EN: mathematics
Headings: Laul muinasjutust, mis on olemas ainult raamatus

## Emakeelepäeva tähistas Rakveres tasuta raamatu laat
URL: https://www.opiq.ee/kit/154/chapter/8733
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.3
Topics ET: matemaatika, emakeelepäeva, tähistas, rakveres, tasuta, raamatu, laat
Topics RU: математика
Topics EN: mathematics
Headings: Emakeelepäeva tähistas Rakveres tasuta raamatu laat

## Raamatuköitja
URL: https://www.opiq.ee/kit/154/chapter/8741
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.4
Topics ET: matemaatika, raamatuköitja
Topics RU: математика
Topics EN: mathematics
Headings: Raamatuköitja

## Kuidas vanal ajal kirjutati
URL: https://www.opiq.ee/kit/154/chapter/8734
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.5
Topics ET: matemaatika, kuidas, vanal, ajal, kirjutati
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas vanal ajal kirjutati

## Nähtamatud tindid
URL: https://www.opiq.ee/kit/154/chapter/8742
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.6
Topics ET: matemaatika, nähtamatud, tindid
Topics RU: математика
Topics EN: mathematics
Headings: Nähtamatud tindid

## Kuidas hiiglane saatis e-maili
URL: https://www.opiq.ee/kit/154/chapter/8735
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.7
Topics ET: matemaatika, kuidas, hiiglane, saatis, maili
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas hiiglane saatis e-maili

## Härra LugemisHull
URL: https://www.opiq.ee/kit/154/chapter/8736
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.8
Topics ET: matemaatika, härra, lugemishull
Topics RU: математика
Topics EN: mathematics
Headings: Härra LugemisHull

## Tim
URL: https://www.opiq.ee/kit/154/chapter/8737
Book: SINASÕPRUS KEELEGA – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: sinasõprus_keelega
Chapter ID: 9.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Tim

## TEELE. Eesti keel teise keelena 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/150
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 408
Topics ET: matemaatika, teele, eesti, keel, teise, keelena, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## TEELE. Eesti keel teise keelena 4. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/150
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 526
Topics ET: matemaatika, teele, eesti, keel, teise, keelena, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Sissejuhatus
URL: https://www.opiq.ee/kit/150/chapter/8332
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.1
Topics ET: matemaatika, sissejuhatus, asume, teele, sõbrad
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus; Asume teele, sõbrad!

## Mis on koolikotis?
URL: https://www.opiq.ee/kit/150/chapter/8328
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.10
Topics ET: matemaatika, koolikotis, missugune, võiks, olla, koolikott, moodusta, lauseid, kiri, läbi
Topics RU: математика
Topics EN: mathematics
Headings: Mis on koolikotis?; 43. Missugune võiks olla koolikott? Moodusta lauseid!; 44. Loe kiri läbi! Kes selle kirjutas ja miks?; 45. Missugune on sinu koolikott?; 46. E-ülesanne. Kirjuta allajoonitud sõnad mitmuses!; 47. Mis on koolikotis?; 48. Missugune on sinu koolikott ja mis seal sees on?

## Miks on koolikott nii raske?
URL: https://www.opiq.ee/kit/150/chapter/8329
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.11
Topics ET: matemaatika, miks, koolikott, raske, pööra, tähelepanu, räägi, koolikotis, pinalis, laua
Topics RU: математика
Topics EN: mathematics
Headings: Miks on koolikott nii raske?; Pööra tähelepanu: kus?; 49. Räägi, mis on su koolikotis / pinalis / laua peal!; 50. Kuulake dialoogi! Rääkige!; 51. Kuula luuletust! Loe ilmekalt!; Minu ranits

## Hugo Vaher Jõesaare poisid
URL: https://www.opiq.ee/kit/150/chapter/8330
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.12
Topics ET: matemaatika, hugo, vaher, jõesaare, poisid, natuke, raamatust, loeme, raamatut, vasta
Topics RU: математика
Topics EN: mathematics
Headings: Hugo Vaher Jõesaare poisid; Natuke raamatust; Jõesaare poisid; Loeme raamatut!; 52. Vasta küsimustele!; 53. Kristofer oli suvel maal ja talle meeldis seal väga. Kus sulle suvel olla meeldib? Miks? Mida sulle suvel teha meeldib? Miks?; 54. Räägi sõbraga!

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8331
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.13
Topics ET: matemaatika, kordame, koos, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 1. nädal; 2. nädal; 3. nädal; 4. nädal

## Kõik on uus septembrikuus
URL: https://www.opiq.ee/kit/150/chapter/8320
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.2
Topics ET: matemaatika, kõik, septembrikuus, pildil, kirja, kuula, dialoogi
Topics RU: математика
Topics EN: mathematics
Headings: Kõik on uus septembrikuus; 1. Mis on pildil?; 2. Loe kirja!; 3. Kuula dialoogi!

## Suvi oli tore
URL: https://www.opiq.ee/kit/150/chapter/8321
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, tore, vaata, teele, plakatit, leia, õige, variant
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Suvi oli tore; Minu suvi; 4. E-ülesanne. Vaata Teele plakatit ja leia õige variant!; 5. Kus sina suvel olid?; 6. Ka Juhanil oli tore suvi.; 7. Kuidas möödus Juhani suvi? Jutusta!; Jäta meelde ja kasuta: olema; 8. E-ülesanne.Täida lüngad! Kasuta sõna olema vorme olevikus!; 9. Mida sina suvel tegid?; 10. Loe, tuleta meelde ja räägi juurde!; 11. E-ülesanne. Vali õige variant!; 12. Vaata skeemi ja räägi oma suvest!; 13. Kuula luuletust!; Suvisel maal

## Klassijuhataja
URL: https://www.opiq.ee/kit/150/chapter/8322
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.4
Topics ET: matemaatika, klassijuhataja, vali, õige, variant, missugune, sinu, teised, õpetajad
Topics RU: математика
Topics EN: mathematics
Headings: Klassijuhataja; 14. E-ülesanne. Vali õige variant!; 15. Missugune on sinu klassijuhataja ja teised õpetajad?; 16. Kirjuta jutt „Klassijuhataja”!; 17. Missugune on sinu arvates hea õpetaja?

## Õpilaspilet
URL: https://www.opiq.ee/kit/150/chapter/8323
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.5
Topics ET: matemaatika, õpilaspilet, teadet, vasta, küsimustele, missuguse, õpilaspileti, teele, saab, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Õpilaspilet; 18. Loe teadet ja vasta küsimustele!; 19. Missuguse õpilaspileti Teele saab?; 20. Vaata õpilaspileteid ja vasta küsimustele!; 21. Võrrelge pinginaabriga oma õpilaspileteid! Rääkige nende põhjal!

## Mina
URL: https://www.opiq.ee/kit/150/chapter/8324
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.6
Topics ET: matemaatika, mina, teele, rein, jäta, meelde, kasuta, rääkima, vali
Topics RU: математика
Topics EN: mathematics
Headings: Mina; 22. Kes on Teele?; 23. Kes on Ana ja kes on Rein?; Jäta meelde ja kasuta: rääkima; 24. E-ülesanne. Vali õige variant!; 25. E-ülesanne. Kelle kohta see väide käib – kas Teele, Ana või Reinu? Vali õige nimi.; 26. Jagage rollid ja lugege dialoogi!; 27. Mõtle, mille poolest oled sa Teele, Ana või Reinu sarnane? Mille poolest neist erinev?

## Tunniplaan
URL: https://www.opiq.ee/kit/150/chapter/8325
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.7
Topics ET: matemaatika, tunniplaan, lause, õige, vale, jutusta, tänasest, tunniplaanist, rühmatöö
Topics RU: математика
Topics EN: mathematics
Headings: Tunniplaan; 28. E-ülesanne. Kas lause on õige või vale?; 29. Jutusta oma tänasest tunniplaanist!; 30. Rühmatöö „Unistuste tunniplaan”

## Mida me nendes tundides teeme?
URL: https://www.opiq.ee/kit/150/chapter/8326
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.8
Topics ET: matemaatika, aeg, kell, kalender, mida, nendes, tundides, teeme, räägi, sõbraga, tunniplaanist, midagi
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: Mida me nendes tundides teeme?; 31. Räägi sõbraga tunniplaanist!; 32. Mis kell sa midagi teed?; Jäta meelde ja kasuta: õppima; 33. Kuula dialoogi. Lugege pinginaabriga!; 34. Lõpeta laused!

## Söögivahetund
URL: https://www.opiq.ee/kit/150/chapter/8327
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 1.9
Topics ET: matemaatika, liitmine, liida, summa, kokku, söögivahetund, kuulutust, vasta, küsimustele, räägi, sõpradega, mõelge, pinginaabriga, välja
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: Söögivahetund; 35. Loe kuulutust ja vasta küsimustele!; 36. Räägi sõpradega!; 37. Mõelge pinginaabriga välja dialoog söögivahetunnist!; 38. Loe laste koostatud menüüsid ja vali oma lemmik!; 39. E-ülesanne. Vali menüüde põhjal õige vastus!; 40. Millise menüü sina kokku paneksid?; 41. Nädala menüü. Tehke paaristööd.; 42. Teeme süüa!

## Sõnastik
URL: https://www.opiq.ee/kit/150/chapter/8436
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 10.1
Topics ET: matemaatika, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Sõnastik

## Aja planeerimine
URL: https://www.opiq.ee/kit/150/chapter/8333
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.1
Topics ET: matemaatika, planeerimine, vaata, pilti, jutusta, anekdooti, räägi, klassikaaslastega, samal, teemal
Topics RU: математика
Topics EN: mathematics
Headings: Aja planeerimine; 1. Vaata pilti ja jutusta!; 2. Loe anekdooti ja räägi klassikaaslastega samal teemal!; 3. Miks on vaja aega planeerida?; 4. Kuula dialoogi! Räägi sõbraga!; 5. Loe liitsõnu ning moodusta lauseid!

## Ostunimekiri
URL: https://www.opiq.ee/kit/150/chapter/8342
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.10
Topics ET: matemaatika, ostunimekiri, vasta, küsimustele, jäta, meelde, kasuta, minema, pööra, tähelepanu
Topics RU: математика
Topics EN: mathematics
Headings: Ostunimekiri; 59. Vasta küsimustele!; Jäta meelde ja kasuta: minema; Pööra tähelepanu: lähen kuhu?; 60. Kuula dialoogi! Räägi sõbraga!

## Poes
URL: https://www.opiq.ee/kit/150/chapter/8343
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.11
Topics ET: matemaatika, poes, vali, õige, variant, liitsõnu, ning, moodusta, lauseid
Topics RU: математика
Topics EN: mathematics
Headings: Poes; 61. E-ülesanne. Vali õige variant!; 62. Loe liitsõnu ning moodusta lauseid!; 63. Räägi sõbraga!; 64. Kuula dialoogi! Räägi sõbraga!; Jäta meelde ja kasuta: ostma; 65. Kuula ja loe lühidialooge! Esita dialooge koos pinginaabriga ilma õpikut kasutamata!; 1. Bussijaamas; 2. Kioskis; 3. Toidupoes; 4. Raamatupoes; 66. Koostage ise dialooge!; Pööra tähelepanu: ostan mida?; 67. E-ülesanne. Kasuta õiget vormi! Kirjuta!; 68. Rühmatöö „Poes”; 69. Mida sa poest ostaksid?

## Marta Sillaots Trips, Traps, Trull ja teised
URL: https://www.opiq.ee/kit/150/chapter/8344
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.12
Topics ET: matemaatika, marta, sillaots, trips, traps, trull, teised, natuke, raamatust, loeme
Topics RU: математика
Topics EN: mathematics
Headings: Marta Sillaots Trips, Traps, Trull ja teised; Natuke raamatust; Trips, Traps, Trull ja teised; Loeme raamatut!; 70. Räägi pinginaabrile!; 71. Jutusta!

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8345
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.13
Topics ET: matemaatika, kordame, koos, nädal, ühtvalu
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 5. nädal; 6. nädal; Ühtvalu; 7. nädal; 8. nädal

## Aastaajad ja ilm
URL: https://www.opiq.ee/kit/150/chapter/8334
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.2
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, ilmateateid, ning, räägi, sõnadega, missugune, nendel, päevadel, vaata
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Aastaajad ja ilm; 6. Loe ilmateateid ning räägi oma sõnadega, missugune ilm nendel päevadel on!; 7. Vaata ilmateateid. Vasta küsimustele!; 8. Kirjelda ilma!; 9. Loe dialoogi ja vaata ilmateadet. Kellel on õigus, kas Juhanil või Teelel? Miks?; 10. Kodune töö

## Haldi Normet Koerailm
URL: https://www.opiq.ee/kit/150/chapter/8335
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.3
Topics ET: matemaatika, haldi, normet, koerailm, loeme, juttu, vasta, küsimustele, kava, kodune
Topics RU: математика
Topics EN: mathematics
Headings: Haldi Normet Koerailm; Loeme juttu!; Koerailm; 11. Vasta küsimustele!; 12. Kava; 13. Kodune töö

## Pole halba ilma, on vaid halb riietus
URL: https://www.opiq.ee/kit/150/chapter/8336
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.4
Topics ET: matemaatika, pole, halba, ilma, vaid, halb, riietus, vasta, küsimustele, miks
Topics RU: математика
Topics EN: mathematics
Headings: Pole halba ilma, on vaid halb riietus; 14. Vasta küsimustele!; 15. Miks öeldakse, et pole halba ilma, on vaid halb riietus?; Pööra tähelepanu: kus?; 16. Mis sul täna seljas on?; 17. Sõnad on sassi läinud. Kirjuta laused vihikusse!; 18. E-ülesanne. Paranda vead! Kirjuta lause õigesti!; 19. Rühmatöö „Täna”; 20. Tee pinginaabriga dialoog!

## Kuud
URL: https://www.opiq.ee/kit/150/chapter/8337
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.5
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, kuud, kuula, järgarve, vaata, kalendrit, lõpeta, laused, vasta
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: Kuud; 21. Kuula ja korda järgarve!; 22. Vaata kalendrit ja lõpeta laused!; 23. Vasta küsimustele!; 24. Kodune töö; 25. Loe liitsõnu ning moodusta lauseid!; 26. Kasuta liitsõnu ning moodusta küsimusi!; 27. Rahvakalendri tähtpäevad.; 28. Vasta küsimustele!; 29. Kodune töö

## Nädal
URL: https://www.opiq.ee/kit/150/chapter/8338
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.6
Topics ET: matemaatika, nädal, jagage, rollid, lugege, koos, vaadake, videoid, tagasi, kooli
Topics RU: математика
Topics EN: mathematics
Headings: Nädal; 30. Jagage rollid ja lugege koos!; 31. Vaadake koos videoid „Tagasi kooli” programmi kohta. Rääkige sellest programmist!; 32. Vasta küsimustele!; 33. Loe liitsõnu ning moodusta lauseid!; 34. Rühmatöö „Teemanädal”

## Enne koolipäeva
URL: https://www.opiq.ee/kit/150/chapter/8339
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.7
Topics ET: matemaatika, enne, koolipäeva, väljendeid, räägi, pinginaabrile, kuidas, algab, sinu, hommik
Topics RU: математика
Topics EN: mathematics
Headings: Enne koolipäeva; 35. Loe väljendeid. Räägi pinginaabrile, kuidas algab sinu hommik!; 36. Kasuta sõnu harjutusest 35 ja tabelist „Seleta ja jäta meelde!” ning moodusta küsimusi!; 37. Kirjuta jutt.; 38. Kuula dialoogi! Räägi sõbraga!; Jäta meelde ja kasuta: ärkama; 39. Kasuta sõnu tabelist „Jäta meelde ja kasuta!” ning moodusta lauseid!; 40. Kuula luuletust! Loe ilmekalt!; Hommik; 41. Kuula ja loe lühidialooge! Esitage neid koos pinginaabriga õpikut kasutamata!; Jäta meelde ja kasuta: sööma; 42. Mida sina täna hommikul sõid?; Pööra tähelepanu: söön – mida?; 43. E-ülesanne. Sõnad on sassi läinud. Pane sõnad õigesse järjekorda!; 44. Rühmatöö „Hommik”

## Pärast koolipäeva
URL: https://www.opiq.ee/kit/150/chapter/8340
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.8
Topics ET: matemaatika, pärast, koolipäeva, kirja, teelele, mida, peab, teele, tegema, pööra
Topics RU: математика
Topics EN: mathematics
Headings: Pärast koolipäeva; 45. Loe isa kirja Teelele!; 46. Mida peab Teele pärast koolipäeva tegema?; Pööra tähelepanu: pean mida tegema?; Jäta meelde ja kasuta: jooma; 47. Mida sina eile kodus jõid?; Pööra tähelepanu: joon mida?; 48. Kodune töö; 49. Loe intervjuud!; Peaasi, et trenn lapsele meeldib; 50. Kirjuta intervjuust viis kõige tähtsamat mõtet!; 51. Vaata pilte ja loe! Räägi, mida lapsed nendes trennides teevad!; 52. Vaata laste jalgpalli- ja ujumistrenni videoid!; 53. Kodune töö; Pööra tähelepanu: käin kus?

## Reklaam
URL: https://www.opiq.ee/kit/150/chapter/8341
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 2.9
Topics ET: matemaatika, reklaam, vaata, reklaame, mida, reklaamitakse, vasta, küsimustele, reklaamide, põhjal
Topics RU: математика
Topics EN: mathematics
Headings: Reklaam; 54. Vaata reklaame. Mida reklaamitakse?; 55. Vasta küsimustele reklaamide põhjal!; 56. Vaadake koos reklaame. Rääkige!; 57. Rühmatöö „Reklaam”; 58. Paaristöö „Tule trenni!”

## Koos on hea olla
URL: https://www.opiq.ee/kit/150/chapter/8346
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.1
Topics ET: matemaatika, koos, olla, perega, tore, kirjelda, pilti, sinu, peres
Topics RU: математика
Topics EN: mathematics
Headings: Koos on hea olla; Perega on tore koos olla; 1. Kirjelda pilti!; 2. Kes on sinu peres?

## Kristiina Kass Kasper ja viis tarka kassi
URL: https://www.opiq.ee/kit/150/chapter/8355
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.10
Topics ET: matemaatika, kristiina, kass, kasper, viis, tarka, kassi, natuke, raamatust, loeme
Topics RU: математика
Topics EN: mathematics
Headings: Kristiina Kass Kasper ja viis tarka kassi; Natuke raamatust; Kasper ja viis tarka kassi; Loeme raamatut!; 45. Vasta küsimustele!; 46. Jutusta loetud katkendit!

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8356
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.11
Topics ET: matemaatika, kordame, koos, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 9. nädal; 10. nädal; 11. nädal

## Tähtsad päevad meie peres
URL: https://www.opiq.ee/kit/150/chapter/8347
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.2
Topics ET: matemaatika, tähtsad, päevad, meie, peres, vaata, pilti, teele, perest, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: Tähtsad päevad meie peres; 3. Vaata pilti Teele perest. Kuidas nad Juhanit õnnitlevad?; 4. E-ülesanne. Kas lause on õige või vale? Ütle valed laused õigesti!; 5. Vaata, missuguseid ettevalmistusi tegi Teele koos ema ja Juhaniga isa sünnipäevaks ja isadepäevaks. Räägi!; Jäta meelde ja kasuta: tegema

## Isadepäev
URL: https://www.opiq.ee/kit/150/chapter/8348
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.3
Topics ET: matemaatika, isadepäev, kuula, luuletust, kompuutri, issi, sõnad, sassi, läinud, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: Isadepäev; 6. Kuula ja loe luuletust.; Kompuutri-issi; 7. Sõnad on sassi läinud. Kirjuta laused vihikusse!; 8. Jutusta!; 9. Vaata pilti! Räägi, missugune on Teele isa!; 10. Missugune on sinu isa? Räägi klassikaaslastele!; 11. Räägi pinginaabriga!; 12. Kodune töö.

## Kes on minu isa?
URL: https://www.opiq.ee/kit/150/chapter/8349
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.4
Topics ET: matemaatika, räägi, pinginaabrile, kirjuta, lünka, õige, omadussõna, kasuta, sõnu
Topics RU: математика
Topics EN: mathematics
Headings: Kes on minu isa?; 13. Räägi pinginaabrile!; 14. E-ülesanne. Kirjuta lünka õige omadussõna. Kasuta sõnu ülesande alt.; 15. Kas see väide käib ka sinu isa kohta?; 16. E-ülesanne. Missugune vorm sõnast tegema sobib lünka? Kirjuta!; 17. Rühmatöö „Hea isa”; 18. Mis sa arvad, mis su isale rohkem meeldib? Räägi pinginaabriga!

## Vanaemad ja vanaisad
URL: https://www.opiq.ee/kit/150/chapter/8350
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.5
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, vanaemad, vanaisad, kelle, kohta, lause, käib, vaata, vanaemade
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Vanaemad ja vanaisad; 19. E-ülesanne. Kelle kohta see lause käib?; 20. Vaata vanaemade-vanaisade pilte.; 21. Kirjuta vihikusse pealkirjaks „Vanavanemad”.; Pööra tähelepanu: antonüümid; 22. E-ülesanne. Missugune omadussõna sobib lünka? Kasuta sõnu ülesande alt.; 23. Vaata klassis ringi. Võrdle asju või inimesi. Kasuta võimalikult palju antonüüme.; 24. Mõtle koos pinginaabriga välja huvitav lugu.

## Vanavanaema
URL: https://www.opiq.ee/kit/150/chapter/8351
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.6
Topics ET: matemaatika, vanavanaema, pööra, tähelepanu, aitan, keda, kirjuta, laused, pikemaks, koosta
Topics RU: математика
Topics EN: mathematics
Headings: Vanavanaema; Pööra tähelepanu: aitan keda?; 25. Kirjuta laused pikemaks!; 26. Koosta mõistekaart „Keda ma aitan?”.

## Pannkoogipühapäev
URL: https://www.opiq.ee/kit/150/chapter/8352
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.7
Topics ET: matemaatika, pannkoogipühapäev, kava, jäta, meelde, kasuta, lugema, pööra, tähelepanu, loen
Topics RU: математика
Topics EN: mathematics
Headings: Pannkoogipühapäev; 27. Kava; Jäta meelde ja kasuta: lugema; Pööra tähelepanu: loen mida?; 28. Täida lüngad! Kasuta erinevaid vorme sõnast lugema ja sõnu tabelist „Pööra tähelepanu!”.; 29. Kuula dialoogi! Tehke pinginaabriga sarnane dialoog!; 30. Kodune töö

## Vanaema jutustab kadripäevast
URL: https://www.opiq.ee/kit/150/chapter/8353
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.8
Topics ET: matemaatika, vanaema, jutustab, kadripäevast, kadripäev, küsimustes, läinud, sõnad, sassi, moodustage
Topics RU: математика
Topics EN: mathematics
Headings: Vanaema jutustab kadripäevast; Kadripäev; 31. Küsimustes on läinud sõnad sassi. Moodustage küsimused ja vastake neile!; 32. Vaadake koos videoid kadripäevast.; 33. E-ülesanne. Lugege mõistatusi ja vali õige vastus!; 34. Tehke pinginaabriga dialoog! Rääkige kadripäevast!; 35. Kodune töö

## Siki
URL: https://www.opiq.ee/kit/150/chapter/8354
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 3.9
Topics ET: matemaatika, siki, vaata, pilte, räägi, kuula, dialoogi, sõbraga, kirjuta, kokkuvõte
Topics RU: математика
Topics EN: mathematics
Headings: Siki; 36. Vaata pilte, loe ja räägi!; 37. Kuula dialoogi! Räägi sõbraga!; 38. Kirjuta kokkuvõte!; 39. Vaata reklaami. Vasta selle põhjal küsimustele!; 40. Loe vanasõnu. Arutage koos, mida need tähendada võiksid!; 41. Loe teksti!; Tuhkur; 42. Vaadake videot!; 43. Kodune töö; 44. Räägi pinginaabriga oma lemmikloomast või sellest loomast, keda sa endale tahaksid!

## Jõulurõõm
URL: https://www.opiq.ee/kit/150/chapter/8357
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.1
Topics ET: matemaatika, jõulurõõm, kirjelda, pilti, ootusärevus, mõtteid, tekstist, räägi, sina, mõtled
Topics RU: математика
Topics EN: mathematics
Headings: Jõulurõõm; 1. Kirjelda pilti!; Ootusärevus; 2. Loe mõtteid tekstist „Ootusärevus” ja räägi, kas sina ka nii mõtled ja tunned!; 3. Kuula dialoogi! Räägi pinginaabriga!

## Jõuluõhtu
URL: https://www.opiq.ee/kit/150/chapter/8366
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.10
Topics ET: matemaatika, jõuluõhtu, laste, arvamusi, kohta, kellelegi, meeldis, pööra, tähelepanu, palju
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluõhtu; 37. Loe laste arvamusi jõuluõhtu kohta. Mis kellelegi meeldis?; Pööra tähelepanu: palju / vähe keda? mida?; 38. Koosta lauseid!; 39. Sõnad on sassi läinud. Kirjuta laused vihikusse!; 40. Kuula dialoogi! Räägi sõbraga!

## Julius Oro ja Venda Sõelsepa luuletused
URL: https://www.opiq.ee/kit/150/chapter/8367
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.11
Topics ET: matemaatika, julius, venda, sõelsepa, luuletused, kuula, luuletusi, enne, pühi, kelle
Topics RU: математика
Topics EN: mathematics
Headings: Julius Oro ja Venda Sõelsepa luuletused; 41. Kuula ja loe luuletusi!; Enne pühi; Kelle jäljed?; 42. Millest need luuletused räägivad? Jutusta mõistekaartide abil!; 43. Kuidas teie jõuludeks valmistute?; 44. Paaristöö „Kelle jäljed?”; 45. Vali välja üks jõuluteemaline luuletus ja õpi seda ilmekalt esitama!

## Ettevalmistused jõuludeks
URL: https://www.opiq.ee/kit/150/chapter/8368
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.12
Topics ET: matemaatika, ettevalmistused, jõuludeks, missuguseid, ettevalmistusi, vaja, teele, perekonnal, enne, jõule
Topics RU: математика
Topics EN: mathematics
Headings: Ettevalmistused jõuludeks; 46. Loe, missuguseid ettevalmistusi on vaja Teele perekonnal enne jõule teha!; Pööra tähelepanu: on vaja mida teha?; 47. Tee vihikusse tabel, kes mida teeb!; 48. Täida lüngad! Vali lünkadesse sõnu tabelist „Pööra tähelepanu!”.; 49. Vasta küsimustele!; 50. Kuula dialoogi! Räägi sõbraga!

## Jõuluõhtu üllatused
URL: https://www.opiq.ee/kit/150/chapter/8369
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.13
Topics ET: matemaatika, jõuluõhtu, üllatused, mida, teele, pere, jõululaupäeval, tegi, sõnad, sassi
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluõhtu üllatused; 52. Mida Teele pere jõululaupäeval tegi?; 54. Sõnad on sassi läinud. Kirjuta laused vihikusse!; 55. Kodune töö; 56. Mõtle koos pinginaabriga välja huvitav lugu!

## Helle Laas Varblase jõuluvana
URL: https://www.opiq.ee/kit/150/chapter/8370
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.14
Topics ET: matemaatika, helle, laas, varblase, jõuluvana, loeme, juttu, lause, õige
Topics RU: математика
Topics EN: mathematics
Headings: Helle Laas Varblase jõuluvana; Loeme juttu!; Varblase jõuluvana; 57. E-ülesanne. Kas lause on õige või vale?

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8371
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.15
Topics ET: matemaatika, kordame, koos, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 12. nädal; 13. nädal; 14. nädal; 15. nädal

## Jõulukuu detsember
URL: https://www.opiq.ee/kit/150/chapter/8358
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.2
Topics ET: matemaatika, jõulukuu, detsember, uuesti, sõnu, tabelist, seleta, jäta, meelde, teele
Topics RU: математика
Topics EN: mathematics
Headings: Jõulukuu detsember; 4. Loe uuesti sõnu tabelist „Seleta ja jäta meelde”!; 5. Teele kirjutas üles viis asja, mida ta jõulukuul teha tahab.; Pööra tähelepanu: tahan mida teha?; 6. Räägi klassikaaslastega ja kirjuta laused vihikusse!

## Jõuluvana kibekiire tööaeg
URL: https://www.opiq.ee/kit/150/chapter/8359
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.3
Topics ET: matemaatika, jõuluvana, kibekiire, tööaeg, intervjuud, kokkuvõte, sellest, mida, rääkis, vihikusse
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluvana kibekiire tööaeg; 7. Loe intervjuud. Tee kokkuvõte sellest, mida jõuluvana rääkis!; 8. Tee vihikusse tabel!; 9. Vasta küsimustele intervjuu põhjal!

## Aino Perviku ja Leelo Tungla luuletused
URL: https://www.opiq.ee/kit/150/chapter/8360
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.4
Topics ET: matemaatika, aino, perviku, leelo, tungla, luuletused, kuula, luuletusi, millest, need
Topics RU: математика
Topics EN: mathematics
Headings: Aino Perviku ja Leelo Tungla luuletused; 10. Loe ja kuula luuletusi! Millest need luuletused räägivad?; Jõuluvana kaotas kinda; Jõuluvana öötöö; 11. Tee luuletusest kirjalik kokkuvõte!; 12. Loe liitsõnu ning moodusta lauseid!; 13. Kasuta eelmise harjutuse liitsõnu ning moodusta küsimusi!; 14. Rühmatöö „Jõulukuu tegevused”; 15. Kuula dialoogi! Räägi sõbraga!

## Kingiloos
URL: https://www.opiq.ee/kit/150/chapter/8361
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.5
Topics ET: matemaatika, kingiloos, jäta, meelde, kasuta, kinkima, valesti, ütle, õigesti, kuula
Topics RU: математика
Topics EN: mathematics
Headings: Kingiloos; Jäta meelde ja kasuta: kinkima; 16. Mis on valesti? Ütle õigesti!; 17. Kuula dialoogi! Räägi sõbraga!

## Kingitus
URL: https://www.opiq.ee/kit/150/chapter/8362
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.6
Topics ET: matemaatika, kingitus, pööra, tähelepanu, kingin, kellele, mille, kava, täida
Topics RU: математика
Topics EN: mathematics
Headings: Kingitus; Pööra tähelepanu: kingin kellele? mille?; 18. Kava; 19. E-ülesanne. Täida lüngad, kasuta õigeid vorme!; 20. Küsi küsimusi!; 21. Kodune töö; 22. Vaata reklaame. Mida reklaamitakse?; 23. Vasta küsimustele reklaamide põhjal!; 24. Jutusta ühe reklaami põhjal!; 25. Kodune töö „Jõulureklaam”; 26. Moodusta reklaamide põhjal küsimusi! Esita küsimused pinginaabrile!; 27. Kuula dialoogi! Räägi sõbraga!

## Heljo Männi ja Ellen Niidu luuletused
URL: https://www.opiq.ee/kit/150/chapter/8363
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.7
Topics ET: matemaatika, heljo, männi, ellen, niidu, luuletused, kuula, luuletusi, millest, need
Topics RU: математика
Topics EN: mathematics
Headings: Heljo Männi ja Ellen Niidu luuletused; 28. Kuula luuletusi! Millest need luuletused räägivad?; Hiina mängukaru; Rebase jõululaul; 29. Vasta küsimustele luuletuse „Hiina mängukaru” põhjal!; 30. Tehke pinginaabriga väike näidend või dialoog luuletuse „Rebase jõululaul” põhjal!; 31. Rühmatöö „Teemantluuletus”

## Jõuluõhtu ettevalmistused
URL: https://www.opiq.ee/kit/150/chapter/8364
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.8
Topics ET: matemaatika, jõuluõhtu, ettevalmistused, moodusta, teksti, põhjal, küsimusi, räägi, liitsõnu, ning
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluõhtu ettevalmistused; 32. Moodusta teksti „Jõuluõhtu ettevalmistused” põhjal küsimusi!; 33. Räägi!; 34. Loe liitsõnu ning moodusta lauseid!; 35. Vasta küsimustele täislausetega kirjalikult vihikusse!

## Jõulukaunistused
URL: https://www.opiq.ee/kit/150/chapter/8365
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 4.9
Topics ET: matemaatika, jõulukaunistused, klassiõhtu, mängud, vasta, küsimustele
Topics RU: математика
Topics EN: mathematics
Headings: Jõulukaunistused; Klassiõhtu mängud; 36. Vasta küsimustele!

## Kui külm näpistas ja haigus puges põue
URL: https://www.opiq.ee/kit/150/chapter/8372
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.1
Topics ET: matemaatika, külm, näpistas, haigus, puges, põue, jutusta, pildi, järgi, lõbus
Topics RU: математика
Topics EN: mathematics
Headings: Kui külm näpistas ja haigus puges põue; 1. Jutusta pildi järgi!; Lõbus vaheaeg

## Kõne perearstile
URL: https://www.opiq.ee/kit/150/chapter/8373
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.2
Topics ET: matemaatika, kõne, perearstile, telefonivestlust, teele, perearsti, vahel, kokkuvõte, küsi, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Kõne perearstile; 2. Loe telefonivestlust Teele ema ja perearsti vahel!; 3. Tee kokkuvõte!; 4. Küsi küsimusi!; Pööra tähelepanu: helistan kellele?; 5. Räägi pinginaabriga!; 6. Kuula ja loe lühidialooge!; Jäta meelde ja kasuta: haigeks jääma; 7. Räägi sõbraga!; 8. Kuula ja loe luuletust!; Purikalimpsijad; 9. Vasta küsimustele luuletuse põhjal!

## Ketlin Priilinn Anna ja tema merisiga Julius
URL: https://www.opiq.ee/kit/150/chapter/8374
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.3
Topics ET: matemaatika, ketlin, priilinn, anna, tema, merisiga, julius, natuke, raamatust, loeme
Topics RU: математика
Topics EN: mathematics
Headings: Ketlin Priilinn Anna ja tema merisiga Julius; Natuke raamatust; Anna ja tema merisiga Julius; Loeme raamatut!; Anna on haige; 10. Rühmatöö „Anna on haige”; 11. Asenda pilt sõnaga. Kirjuta laused vihikusse!

## Kuidas sa end tunned?
URL: https://www.opiq.ee/kit/150/chapter/8375
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.4
Topics ET: matemaatika, kuidas, tunned, lapsed, tunnevad, kirjelda, pilte, vasta, küsimustele, tuleta
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas sa end tunned?; 12. Kuidas lapsed end tunnevad? Kirjelda pilte!; 13. Vasta küsimustele!; Tuleta meelde ja kasuta: haige olema

## Miks jäävad inimesed haigeks?
URL: https://www.opiq.ee/kit/150/chapter/8376
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.5
Topics ET: matemaatika, miks, jäävad, inimesed, haigeks, kõiki, punktid, uuesti, läbi, kuula
Topics RU: математика
Topics EN: mathematics
Headings: Miks jäävad inimesed haigeks?; 14. Loe kõiki punktid uuesti läbi.; 5. Kuula „Olemise laulukest”!; 16. Kuula ja loe luuletust!; Külmas meres; 17. Loe vestlust kahe sõbra vahel!; 18. Tee vihikusse kokkuvõte.; 19. Loe intervjuud!; Kuidas püsida talvel terve?; 20. E-ülesanne. Kas lause on õige või vale?; Pööra tähelepanu: räägin kellega?; 21. E-ülesanne. Mis on nende sõnade algvorm?

## Teele saab terveks
URL: https://www.opiq.ee/kit/150/chapter/8377
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.6
Topics ET: matemaatika, teele, saab, terveks, lõpeta, laused, jäta, meelde, kasuta, saama
Topics RU: математика
Topics EN: mathematics
Headings: Teele saab terveks; 22. Lõpeta laused!; Jäta meelde ja kasuta: terveks saama; 23. Küsi küsimusi!

## Võimas imerohi uni
URL: https://www.opiq.ee/kit/150/chapter/8378
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.7
Topics ET: matemaatika, võimas, imerohi, kuulake, doktor, laulu, millest, laul, räägib, vasta
Topics RU: математика
Topics EN: mathematics
Headings: Võimas imerohi uni; 24. Kuulake „Doktor Ave laulu”! Millest see laul räägib?; 25. Vasta küsimustele!; 26. Räägi endast!; 27. Loe vanasõnu! Arutage pinginaabriga, mida need tähendavad!; 28. Kuula ja loe luuletust.; Mis on magusam kui mesi?; 29. Loe lauseid ning allajoonitud sõnade kohta esitatud küsimusi.; Pööra tähelepanu: juurde, juures, juurest; 30. E-ülesanne. Mis sõna sobib lünka? Kas juurde, juures või juurest?; 31. Moodusta lauseid!; 32. E-ülesanne. Vali õige variant!; 33. E-ülesanne. Kuula ja vali õige variant!; 34. Kuula dialoogi. Räägi sõbraga!

## Kollane nagu päike, kasulik nagu … sidrun!
URL: https://www.opiq.ee/kit/150/chapter/8379
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.8
Topics ET: matemaatika, kollane, nagu, päike, kasulik, sidrun, moodusta, jutu, põhjal, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Kollane nagu päike, kasulik nagu … sidrun!; 35. Moodusta jutu „Kollane nagu päike, kasulik nagu … sidrun!” põhjal küsimusi!; 36. Räägi endast!; 37. Vaata pilti ja räägi, mida sa näed!

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8380
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 5.9
Topics ET: matemaatika, kordame, koos, peatüki, sõnavara, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 5. peatüki sõnavara; 16. nädal; 17. nädal; 18. nädal

## Tervislik eluviis
URL: https://www.opiq.ee/kit/150/chapter/8381
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.1
Topics ET: matemaatika, tervislik, eluviis, kirjelda, pilti, räägi, endast, perest, vaata, skeemi
Topics RU: математика
Topics EN: mathematics
Headings: Tervislik eluviis; 1. Kirjelda pilti. Räägi ka endast ja oma perest!; 2. Vaata skeemi ja räägi, kas sina elad tervislike eluviiside järgi või mitte!; KAS SA ELAD TERVISLIKULT?

## Avasta kodukohta!
URL: https://www.opiq.ee/kit/150/chapter/8390
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.10
Topics ET: matemaatika, avasta, kodukohta, jalutame, glehni, pargis, vasta, küsimustele, jäta, meelde
Topics RU: математика
Topics EN: mathematics
Headings: Avasta kodukohta!; Jalutame Glehni pargis; 32. Vasta küsimustele!; Jäta meelde ja kasuta: kõndima

## Jaanus Vaiksoo Lumemöll
URL: https://www.opiq.ee/kit/150/chapter/8391
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.11
Topics ET: matemaatika, jaanus, vaiksoo, lumemöll, natuke, raamatust, loeme, raamatut, jäljed, lumel
Topics RU: математика
Topics EN: mathematics
Headings: Jaanus Vaiksoo Lumemöll; Natuke raamatust; Lumemöll; Loeme raamatut!; Jäljed lumel; 33. Loe sõnu tabelist „Seleta ja jäta meelde!”. Räägi sõbraga!

## Millised me oleme?
URL: https://www.opiq.ee/kit/150/chapter/8392
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.12
Topics ET: matemaatika, millised, oleme, kuula, sina, seda, luuletust, abivalmis, laps, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Millised me oleme?; 34. Kuula ja loe ka sina seda luuletust.; Abivalmis laps; 35. Vaata ja loe mõistekaarti ning räägi, missugune oled sina erinevates olukordades!; Pööra tähelepanu: omadussõna võrdlusastmed; 36. E-ülesanne. Muuda lauseid nii, et omadussõna oleks ülivõrdes.; 37. Lõpeta laused! Kasuta omadussõnu ülesande 35 juurest.

## Julge olla hea
URL: https://www.opiq.ee/kit/150/chapter/8393
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.13
Topics ET: matemaatika, julge, olla, uuesti, mõtteid, räägi, sõnu, tabelist, seleta, jäta
Topics RU: математика
Topics EN: mathematics
Headings: Julge olla hea; 38. Loe uuesti mõtteid „Julge olla aus”. Räägi!; 39. Loe uuesti sõnu tabelist „Seleta ja jäta meelde!”; 40. Loe vanasõnu! Arutage pinginaabriga, mida need tähendavad!; 41. Paaristöö „Vanasõna”

## Aino Pervik Preili RõõmuRikkuja
URL: https://www.opiq.ee/kit/150/chapter/8394
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.14
Topics ET: matemaatika, aino, pervik, preili, rõõmurikkuja, loeme, juttu, vasta, küsimustele, lugesid
Topics RU: математика
Topics EN: mathematics
Headings: Aino Pervik Preili RõõmuRikkuja; Loeme juttu!; Preili RõõmuRikkuja; 42. Vasta küsimustele!; 43. Lugesid teksti preili RõõmuRikkuja sünnipäevast.; 44. Kodune töö

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8395
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.15
Topics ET: matemaatika, kordame, koos, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 19. nädal; 20. nädal; 21. nädal; 22. nädal

## Mida me õhtul sööme?
URL: https://www.opiq.ee/kit/150/chapter/8382
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.2
Topics ET: matemaatika, mida, õhtul, sööme, kava, vaata, toidupüramiidi, pööra, tähelepanu, sidesõnad
Topics RU: математика
Topics EN: mathematics
Headings: Mida me õhtul sööme?; 3. Kava; 4. Vaata toidupüramiidi!; Pööra tähelepanu: sidesõnad (ja, ning, ega, ehk, või, kuid, aga, et); 5. Mis sidesõna sobib lünka? Kirjuta laused vihikusse!; 6. Loe küsimusi, lisa lünka õige sidesõna! Vasta neile küsimustele!

## Viis värvi taldrikul
URL: https://www.opiq.ee/kit/150/chapter/8383
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.3
Topics ET: matemaatika, viis, värvi, taldrikul, mida, tähendab, viie, reegel, tuleta, meelde
Topics RU: математика
Topics EN: mathematics
Headings: Viis värvi taldrikul; 7. Mida tähendab „Viie värvi reegel”?; Tuleta meelde ja kasuta: süüa tegema

## Tervisliku toitumise reeglid
URL: https://www.opiq.ee/kit/150/chapter/8384
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.4
Topics ET: matemaatika, tervisliku, toitumise, reeglid, uuesti, reegleid, enda, kohta, kokkuvõte, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Tervisliku toitumise reeglid; 8. Loe uuesti tervisliku toitumise reegleid. Tee enda kohta kokkuvõte!; 9. Vaata plakatit ja vasta küsimustele!

## Sport kutsub õue
URL: https://www.opiq.ee/kit/150/chapter/8385
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.5
Topics ET: matemaatika, sport, kutsub, lause, õige, vale, kava, asjad, need
Topics RU: математика
Topics EN: mathematics
Headings: Sport kutsub õue; 10. E-ülesanne. Kas lause on õige või vale?; 11. Kava; 12. Mis asjad need on?

## Jalgpallivõistlused
URL: https://www.opiq.ee/kit/150/chapter/8386
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.6
Topics ET: matemaatika, jalgpallivõistlused, vasta, küsimustele, pööra, tähelepanu, kõnemallid, räägi, sõbraga, vaata
Topics RU: математика
Topics EN: mathematics
Headings: Jalgpallivõistlused; 13. Vasta küsimustele!; Pööra tähelepanu: kõnemallid; 14. Räägi sõbraga!; 15. Vaata fotosid! Kirjelda neid!; 16. Kirjuta vihikusse viis lauset ühe foto põhjal!; 17. Kuula ja loe luuletust. Tee sellest oma sõnadega kokkuvõte!; Jalgrataste talveuni; 18. Kuula ja loe dialoogi! Proovige seda esitada pinginaabriga õpiku abita!; 19. Loe uudist!; Kolmikõed Luiged teevad Rio de Janeiro olümpial ajalugu; 20. Lõpeta laused uudise põhjal!; 21. Vaadake koos videot õdede ettevalmistusest!; 22. Kuidas õdedel Rio de Janeiro olümpial läks? Loe uudist ja räägi!; 23. Loe reklaami!

## Mida talvel õues teha?
URL: https://www.opiq.ee/kit/150/chapter/8387
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.7
Topics ET: matemaatika, mida, talvel, õues, teha, liitsõnu, moodusta, lauseid, kasuta, sõnu
Topics RU: математика
Topics EN: mathematics
Headings: Mida talvel õues teha?; 24. Loe liitsõnu ja moodusta lauseid!; 25. Kasuta sõnu „Mida talvel õues teha?” piltide juurest ja moodusta küsimusi!

## Otsi varandus üles!
URL: https://www.opiq.ee/kit/150/chapter/8388
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.8
Topics ET: matemaatika, otsi, varandus, üles, jutusta
Topics RU: математика
Topics EN: mathematics
Headings: Otsi varandus üles!; 26. Jutusta!

## Mine metsa!
URL: https://www.opiq.ee/kit/150/chapter/8389
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 6.9
Topics ET: matemaatika, mine, metsa, lause, õige, vale, pööra, tähelepanu, lähen
Topics RU: математика
Topics EN: mathematics
Headings: Mine metsa!; 27. E-ülesanne. Kas lause on õige või vale?; Pööra tähelepanu: lähen kuhu? olen kus? tulen kust?; 28. Minge kõik koos kümneks minutiks õue.; 29. Räägi!; 30. Kirjuta lünka sõna õiges vormis!; 31. Kuula ja loe lühidialooge!

## Looduse märgid
URL: https://www.opiq.ee/kit/150/chapter/8396
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.1
Topics ET: loodusõpetus, aastaajad, kevad, suvi, sügis, talv, looduse, märgid, vasta, küsimustele, pakib, kohvreid, uuesti, sõnu
Topics RU: природоведение, времена года, весна, лето, осень, зима
Topics EN: science, seasons, spring, summer, autumn, winter
Headings: Looduse märgid; 1. Vasta küsimustele!; Talv pakib kohvreid; 2. Loe uuesti sõnu tabelist „Seleta ja jäta meelde!”.

## August Jakobson Miks karu kardab inimest
URL: https://www.opiq.ee/kit/150/chapter/8405
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.10
Topics ET: matemaatika, august, jakobson, miks, karu, kardab, inimest, loeme, juttu
Topics RU: математика
Topics EN: mathematics
Headings: August Jakobson Miks karu kardab inimest; Loeme juttu!; Miks karu kardab inimest; 44. E-ülesanne. Loe juttu „Miks karu kardab inimest” ja leia õige variant!; 45. Kas jutt „Miks karu kardab inimest” oli sinu arvates naljakas?

## Kas sina oled kevadeks valmis?
URL: https://www.opiq.ee/kit/150/chapter/8406
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.11
Topics ET: matemaatika, sina, oled, kevadeks, valmis, vaata, pilti, räägi, pildil, valesti
Topics RU: математика
Topics EN: mathematics
Headings: Kas sina oled kevadeks valmis?; 46. Vaata pilti ja räägi, mis on pildil valesti!; Pööra tähelepanu: tulen siia / lähen sinna; 47. Mis sõna sobib lünka? Kasuta sõna tulema või minema vorme!; 48. E-ülesanne. Kuula ja vali õige variant!; 49. Vaata nelja päeva ilmateadet! Räägi, missugust ilma lubatakse!; 50. Missugune ilm on täna?; 51. Tuleta meelde sõnavara ja räägi, missugune riietus sobib tänase ilmaga!; Pööra tähelepanu: panen kuhu? on kus? võtan kust?; 52. Muuda lauseid! Kasuta lausete tegemisel küsimusi kuhu? kus? kust?; 53. Milliseid riideid kannad sina kevadel? Räägi!; 54. Kodune töö

## Kummikud päästavad päeva
URL: https://www.opiq.ee/kit/150/chapter/8407
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.12
Topics ET: matemaatika, kummikud, päästavad, päeva, vasta, küsimustele, täida, lüngad, kasuta
Topics RU: математика
Topics EN: mathematics
Headings: Kummikud päästavad päeva; 55. Vasta küsimustele!; 56. E-ülesanne. Täida lüngad! Kasuta õiget vormi.; 57. Vaata kodus koos vanematega televiisorist või internetist ilmateadet!; 58. Kuula ja loe luuletust.; Õues; 59. Mõtle koos pinginaabriga välja huvitav lugu.

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8408
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.13
Topics ET: matemaatika, kordame, koos, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 23. nädal; 24. nädal; 25. nädal; 26. nädal

## Eile oli talv
URL: https://www.opiq.ee/kit/150/chapter/8397
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.2
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, aastaajad, kevad, suvi, sügis, talv, eile, moodusta, küsimusi, jutu, põhjal, missugune, talvel, ütle
Topics RU: математика, сравнение, сравни, больше, меньше, времена года, весна, лето, осень, зима
Topics EN: mathematics, comparison, compare, greater, less, seasons, spring, summer, autumn, winter
Headings: Eile oli talv; 3. Moodusta küsimusi jutu „Eile oli talv” põhjal!; 4. Missugune on ilm talvel? Loe! Ütle, kas täna on selline ilm või mitte!; Pööra tähelepanu: sajab mida?; 5. Vaadake ilmateadet!; 6. Vaata aknast välja ning kirjelda viie lausega, missugune ilm on praegu!; 7. Võrdle tänast ilma selle ilmaga, mida kirjeldas Teele jutus „Eile oli talv”!

## Täna on kevad
URL: https://www.opiq.ee/kit/150/chapter/8398
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, täna, lause, õige, vale, paranda, valed, laused, õigeks
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Täna on kevad; 8. Kas lause on õige või vale? Paranda valed laused õigeks!; 9. Missugune ilm on kevadel? Loe! Ütle, kas täna on selline ilm või mitte!; 10. Kuulake ilmateadet!

## Tuul teeb nalja
URL: https://www.opiq.ee/kit/150/chapter/8399
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.4
Topics ET: matemaatika, tuul, teeb, nalja, vaata, koomiksit, juhtub, kuidas, kõik, lõpeb
Topics RU: математика
Topics EN: mathematics
Headings: Tuul teeb nalja; 11. Vaata ja loe koomiksit! Mis juhtub ja kuidas kõik lõpeb?; 12. Kirjuta vihikusse kuuelauseline jutt „Tuul teeb nalja”!; 13. Rühmatöö „Tuul teeb nalja”; 14. Jutustage koomiksi järgi!; 15. Paaristöö „Teemantluuletus”; 16. Kodune töö

## Kes sa oled, rändlind?
URL: https://www.opiq.ee/kit/150/chapter/8400
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.5
Topics ET: matemaatika, oled, rändlind, vasta, küsimustele, vaadake, koos, lindude, rändekaarti, infot
Topics RU: математика
Topics EN: mathematics
Headings: Kes sa oled, rändlind?; 17. Vasta küsimustele!; 18. Vaadake koos lindude rändekaarti. Mis infot te siit leiate?; 19. Kuulake lindude hääli!; 20. Vaata pilte ja loe, mis rändlinnud Eestis elavad!; 21. Kirjelda lindude välimust!

## Ornitoloog räägib rändlindudest
URL: https://www.opiq.ee/kit/150/chapter/8401
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.6
Topics ET: matemaatika, ornitoloog, räägib, rändlindudest, lõpeta, laused, mida, sina, ornitoloogilt, küsiksid
Topics RU: математика
Topics EN: mathematics
Headings: Ornitoloog räägib rändlindudest; 22. Lõpeta laused!; 23. Mida sina ornitoloogilt küsiksid?; 24. Rühmatöö „Rändlinnud”; Pööra tähelepanu: ainsus ja mitmus; 25. Vaadake koos klassis ringi ning nimetage asju, mida enda ümber näete!; 26. E-ülesanne. Mis sõnavorm sobib lünka? Kirjuta!; 27. E-ülesanne. Muuda allajoonitud sõnade ainsus mitmuseks!; 28. Ornitoloog Toomas läks koos lastega õue linde vaatlema.

## Jaan Rannap Teele, teele, kurekesed
URL: https://www.opiq.ee/kit/150/chapter/8402
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.7
Topics ET: matemaatika, jaan, rannap, teele, kurekesed, loeme, juttu, kuulake, friedrich, kuhlbarsi
Topics RU: математика
Topics EN: mathematics
Headings: Jaan Rannap Teele, teele, kurekesed; Loeme juttu!; Teele, teele, kurekesed; 29. Kuulake Friedrich Kuhlbarsi sõnadele loodud laulu „Teele, teele, kurekesed!”.; 30. Kava; 31. Kodune töö

## Loomad ärkavad talveunest
URL: https://www.opiq.ee/kit/150/chapter/8403
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.8
Topics ET: matemaatika, loom, loomad, linnud, putukad, ärkavad, talveunest, kuula, luuletust, millest, räägib, karukell, sellest
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: Loomad ärkavad talveunest; 32. Kuula ja loe luuletust! Millest see räägib?; Karukell; 33. Tee sellest luuletusest jutt!; 34. Loe ja vaata, kes magavad talveund!; 35. Kirjelda loomade välimust!

## Talveuni
URL: https://www.opiq.ee/kit/150/chapter/8404
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 7.9
Topics ET: matemaatika, arv, arvud, arvu, numbrid, talveuni, koosta, mõistekaart, pööra, tähelepanu, ainsus, mitmus, täida
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: Talveuni; 36. Koosta mõistekaart!; Pööra tähelepanu: ainsus ja mitmus; 37. E-ülesanne. Täida lüngad! Kasuta sobivaid vorme.; 38. Loe teksti!; Mesikäpp, metsaott, mõmm … Karu!; 39. Koosta vihikusse jutt „Karu”!; 40. E-ülesanne. Täida lüngad!; 41. Kuidas on need arvud karudega seotud? Räägi!; 42. Vasta küsimustele teksti „Mesikäpp, metsaott, mõmm … Karu!” põhjal!; 43. Kodune töö

## Õues
URL: https://www.opiq.ee/kit/150/chapter/8409
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.1
Topics ET: matemaatika, õues, räägi, kuula, luuletust, millest, räägib, kevade, tulnud, liitsõnu
Topics RU: математика
Topics EN: mathematics
Headings: Õues; 1. Räägi!; 2. Kuula ja loe luuletust! Millest see räägib; Kevade on tulnud; 3. Loe liitsõnu ja moodusta lauseid!; 4. Loe lauseid ning räägi, kas need käivad ka sinu kohta või mitte!

## Me eksisime ära!
URL: https://www.opiq.ee/kit/150/chapter/8418
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.10
Topics ET: matemaatika, eksisime, pööra, tähelepanu, tagasõnad, taga, keskel, vahel, kõrval, vasakul
Topics RU: математика
Topics EN: mathematics
Headings: Me eksisime ära!; Pööra tähelepanu: tagasõnad (ees, taga, keskel, vahel, kõrval, vasakul, paremal, juures, all, peal); 33. Tee kokkuvõte!; 34. Jutusta!; 35. Kuula ja loe lühidialooge!; 36. Mõelge pinginaabriga ise üks dialoog välja!; 37. E-ülesanne. Märgi õige variant!

## Mida teha, kui sa metsas ära eksid?
URL: https://www.opiq.ee/kit/150/chapter/8419
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.11
Topics ET: matemaatika, mida, teha, metsas, eksid, vaadake, videot, arvad, moodusta, lauseid
Topics RU: математика
Topics EN: mathematics
Headings: Mida teha, kui sa metsas ära eksid?; 38. Vaadake videot!; 39. Mis sa arvad … ?; 40. Moodusta lauseid! Kasuta järgmisi sõnu:; 41. Rühmatöö „Mida teha, kui sa ära eksid?”; 42. Mõtle koos pinginaabriga välja huvitav lugu.

## Kevadlilled
URL: https://www.opiq.ee/kit/150/chapter/8420
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.12
Topics ET: matemaatika, kevadlilled, vaata, pilte, lilled, need, kirjelda, neid, kirjuta, lühike
Topics RU: математика
Topics EN: mathematics
Headings: Kevadlilled; 43. Vaata pilte. Mis lilled need on? Kirjelda neid!; 44. Kirjuta lühike jutt!; 45. Kuula dialoogi. Räägi sõbraga!; 46. Räägi!; 47. Räägi pinginaabriga!

## Pikad valged õhtud
URL: https://www.opiq.ee/kit/150/chapter/8421
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.13
Topics ET: matemaatika, pikad, valged, õhtud, lõpeta, laused, räägi, pinginaabriga, kirjuta, vihikusse
Topics RU: математика
Topics EN: mathematics
Headings: Pikad valged õhtud; 48. Lõpeta laused!; 49. Räägi pinginaabriga!; 50. Kirjuta vihikusse kokkuvõte!; 51. Kuula dialoogi. Räägi sõbraga!

## Kevadelõhn
URL: https://www.opiq.ee/kit/150/chapter/8422
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.14
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, kevadelõhn, lause, õige, vale, ütle, valed, laused, õigesti
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Kevadelõhn; 52. E-ülesanne. Kas lause on õige või vale? Ütle valed laused õigesti!; 53. Milline on sinu kevadelõhn?; 54. Mis lõhnad sulle meeldivad?; 55. Räägi klassikaaslastele, mis lõhnadest su pinginaaber rääkis!; 56. Paaristöö „Aastaajad”; 57. Kuula ja loe luuletust. Jutusta oma sõnadega, millest luuletus räägib.; Karu ärkab talveunest

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8423
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.15
Topics ET: matemaatika, kordame, koos, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 27. nädal; 28. nädal; 29. nädal; 30. nädal

## Eeskujulik rattur
URL: https://www.opiq.ee/kit/150/chapter/8410
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.2
Topics ET: matemaatika, eeskujulik, rattur, täida, lüngad, reegleid, selle, kohta, kuidas, olla
Topics RU: математика
Topics EN: mathematics
Headings: Eeskujulik rattur; 5. Täida lüngad!; 6. Loe reegleid selle kohta, kuidas olla eeskujulik rattur!; 7. Loe uuesti eelmise harjutuse reegleid!; 8. Tehke pinginaabriga dialoog rattaga sõitmise teemal!

## Õppetund
URL: https://www.opiq.ee/kit/150/chapter/8411
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.3
Topics ET: matemaatika, õppetund, vaadake, koos, pinginaabriga, märke, ning, rääkige, mida, need
Topics RU: математика
Topics EN: mathematics
Headings: Õppetund; 9. Vaadake koos pinginaabriga märke ning rääkige, mida need teie arvates tähendavad!; 10. Kava; 11. Vasta küsimustele!; 12. Loe uuesti sõnu tabelist „Seleta ja jäta meelde!” ning moodusta viie sõnaga laused.; 13. Kodune töö

## Piret Raud Teistmoodi printsessilood
URL: https://www.opiq.ee/kit/150/chapter/8412
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.4
Topics ET: matemaatika, piret, raud, teistmoodi, printsessilood, natuke, raamatust, loeme, raamatut, printsess
Topics RU: математика
Topics EN: mathematics
Headings: Piret Raud Teistmoodi printsessilood; Natuke raamatust; Teistmoodi printsessilood; Loeme raamatut!; Printsess Karlotta ja punastav valgusfoor; 14. Loe uuesti sõnu tabelist „Seleta ja jäta meelde!”.

## Naljakuu aprill
URL: https://www.opiq.ee/kit/150/chapter/8413
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.5
Topics ET: matemaatika, naljakuu, aprill, vali, välja, anekdoot, harjutusest, kasuta, sõnu, tabelist
Topics RU: математика
Topics EN: mathematics
Headings: Naljakuu aprill; 16. Vali välja üks anekdoot harjutusest 15!; 17. Kasuta sõnu tabelist „Seleta ja jäta meelde!” ning moodusta küsimusi.; 18. Kuula anekdooti ja vasta küsimustele!; 19. Rühmatöö „Naljajutt”; 20. Tuleta meelde ja räägi!; 21. Kodune töö

## Sõidame suvilasse
URL: https://www.opiq.ee/kit/150/chapter/8414
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.6
Topics ET: matemaatika, sõidame, suvilasse, lause, õige, vale, paranda, valed, laused, õigeks
Topics RU: математика
Topics EN: mathematics
Headings: Sõidame suvilasse; 22. Kas lause on õige või vale? Paranda valed laused õigeks!; Pööra tähelepanu: sõidan millega?; Jäta meelde ja kasuta: sõitma

## Lapsehoidjad
URL: https://www.opiq.ee/kit/150/chapter/8415
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.7
Topics ET: matemaatika, lapsehoidjad, vasta, küsimustele, kirjalikult, vihikusse, pööra, tähelepanu, käskiv, kõneviis
Topics RU: математика
Topics EN: mathematics
Headings: Lapsehoidjad; 23. Vasta küsimustele kirjalikult vihikusse!; Pööra tähelepanu: käskiv kõneviis; 24. Lõpeta laused!; 25. Mida keegi tegema peab? Kirjuta laused vihikusse!; 26. Lõpeta laused! Kasuta ära- või ärge-vorme!; 27. Mida peab tegema koolis / kodus / sööklas / poes / …? Mida nendes kohtades teha ei tohi?; 28. Rühmatöö „Jutt”

## Hando Runnel Matemaatika
URL: https://www.opiq.ee/kit/150/chapter/8416
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.8
Topics ET: matemaatika, hando, runnel, loeme, juttu, vasta, küsimustele
Topics RU: математика
Topics EN: mathematics
Headings: Hando Runnel Matemaatika; Loeme juttu!; Matemaatika; 29. Vasta küsimustele!

## Me oleme vist eksinud
URL: https://www.opiq.ee/kit/150/chapter/8417
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 8.9
Topics ET: matemaatika, oleme, vist, eksinud, vaata, uuesti, fotosid, pilte, peatüki, alguses
Topics RU: математика
Topics EN: mathematics
Headings: Me oleme vist eksinud; 30. Vaata uuesti fotosid ja pilte peatüki alguses ning vasta küsimustele!; 31. Koosta vihikusse seitsmepunktiline kava!; Pööra tähelepanu: peab mida tegema?; 32. Arva ära!

## Mida teha vaheajal?
URL: https://www.opiq.ee/kit/150/chapter/8424
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.1
Topics ET: matemaatika, mida, teha, vaheajal, kirjelda, pilti, kuula, dialoogi, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: Mida teha vaheajal?; 1. Kirjelda pilti!; 2. Kuula dialoogi. Räägi sõbraga!; 3. Lõpeta laused!; 4. Loe liitsõnu ja moodusta lauseid!

## Kas laagrisse läheme?
URL: https://www.opiq.ee/kit/150/chapter/8433
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.10
Topics ET: matemaatika, laagrisse, läheme, vaata, reklaamlehte, vasta, küsimustele, liitsõnu, moodusta, lauseid
Topics RU: математика
Topics EN: mathematics
Headings: Kas laagrisse läheme?; 33. Vaata reklaamlehte ja vasta küsimustele!; 34. Loe liitsõnu ja moodusta lauseid!; 35. Räägi sõbraga!; 36. Rühmatöö „Suvelaager”

## Janka Lee Leis Hanna ja Aleksi lood
URL: https://www.opiq.ee/kit/150/chapter/8434
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.11
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, janka, leis, hanna, aleksi, lood, natuke, raamatust
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Janka Lee Leis Hanna ja Aleksi lood; Natuke raamatust; Hanna ja Aleksi lood​Kevad ja suvi; Loeme raamatut!; Aleksi võitlus hanedega; 37. Paaristöö „Küsimused”; 38. Rühmatöö „Vastused”

## Kordame koos!
URL: https://www.opiq.ee/kit/150/chapter/8435
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.12
Topics ET: matemaatika, kordame, koos, nädal
Topics RU: математика
Topics EN: mathematics
Headings: Kordame koos!; 31. nädal; 32. nädal; 33. nädal; 34. nädal; 35. nädal

## Mis oleks, kui …
URL: https://www.opiq.ee/kit/150/chapter/8425
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.2
Topics ET: matemaatika, oleks, ideid, suvevaheaja, kohta, kommenteeri, neid, nimeta, kolm, punkti
Topics RU: математика
Topics EN: mathematics
Headings: Mis oleks, kui …; 5. Loe ideid suvevaheaja kohta! Kommenteeri neid.; 6. Nimeta kolm punkti harjutusest 5, …; 7. Mõtle ise välja ideid suvevaheaja kohta!; 8. Täida lüngad! Kasuta sõnu tabelist „Seleta ja jäta meelde!”.; Jäta meelde ja kasuta: veetma; 9. Räägi!

## Kui suvi oleks talvel
URL: https://www.opiq.ee/kit/150/chapter/8426
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, oleks, talvel, vasta, küsimustele, pööra, tähelepanu, aega, veetma
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Kui suvi oleks talvel; 10. Vasta küsimustele!; Pööra tähelepanu: aega veetma kellega? kus?; 11. Moodusta lauseid!; 12. Moodusta tabeli „Pööra tähelepanu!” põhjal viis küsimust.

## Autoga Pirital
URL: https://www.opiq.ee/kit/150/chapter/8427
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.4
Topics ET: matemaatika, autoga, pirital, küsi, küsimusi, rühmatöö, meie, kodukoht, kodune, räägi
Topics RU: математика
Topics EN: mathematics
Headings: Autoga Pirital; 13. Küsi küsimusi!; 14. Rühmatöö „Meie kodukoht”; 15. Kodune töö; 16. Räägi!

## Ratastega Rocca al Mares
URL: https://www.opiq.ee/kit/150/chapter/8428
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.5
Topics ET: matemaatika, ratastega, rocca, mares, kava, täida, lüngad, kuula, dialoogi
Topics RU: математика
Topics EN: mathematics
Headings: Ratastega Rocca al Mares; 17. Kava; 18. E-ülesanne. Täida lüngad!; 19. Kuula dialoogi. Räägi sõbraga!; 20. Kodune töö

## Kolm avastusretke
URL: https://www.opiq.ee/kit/150/chapter/8429
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.6
Topics ET: matemaatika, kolm, avastusretke, vaata, fotosid, räägi, vasta, küsimustele, küsi, küsimusi
Topics RU: математика
Topics EN: mathematics
Headings: Kolm avastusretke; 21. Vaata fotosid! Räägi!; 22. Vasta küsimustele!; 23. Küsi küsimusi!; Pööra tähelepanu: armastan mida teha?; 24. Lõpeta laused!; 25. Paaristöö „Teele avastab Tallinna”

## Lõuna-Eesti kuppelmaastik
URL: https://www.opiq.ee/kit/150/chapter/8430
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.7
Topics ET: matemaatika, lõuna, eesti, kuppelmaastik, uuesti, sõnu, tabelist, seleta, jäta, meelde
Topics RU: математика
Topics EN: mathematics
Headings: Lõuna-Eesti kuppelmaastik; 26. Loe uuesti sõnu tabelist „Seleta ja jäta meelde!”.; Pööra tähelepanu: sõidame kust? kuhu?; 27. Vasta küsimustele kirjalikult vihikusse!

## Talvepealinnas on ka suvel tore
URL: https://www.opiq.ee/kit/150/chapter/8431
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.8
Topics ET: matemaatika, talvepealinnas, suvel, tore, paaristöö, teele, pere, avastab, lõuna, eestit
Topics RU: математика
Topics EN: mathematics
Headings: Talvepealinnas on ka suvel tore; 28. Paaristöö „Teele pere avastab Lõuna-Eestit”; 29. Rühmatöö „Teele pere avastab Lõuna-Eestit”; 30. Vasta küsimustele lugude „Lõuna-Eesti kuppelmaastik” ja „Talvepealinnas on ka suvel tore” põhjal!

## Kadri Hinrikus Taaniel Teine
URL: https://www.opiq.ee/kit/150/chapter/8432
Book: TEELE. Eesti keel teise keelena 4. klassile – Opiq
Class: 4
Subject: mathematics / matemaatika / математика
Language: et
Publisher: 
Book ID: teele._eesti_keel_teise_keelena_4._klassile
Chapter ID: 9.9
Topics ET: matemaatika, kadri, hinrikus, taaniel, teine, natuke, raamatust, loeme, raamatut, küsi
Topics RU: математика
Topics EN: mathematics
Headings: Kadri Hinrikus Taaniel Teine; Natuke raamatust; Taaniel Teine; Loeme raamatut!; 31. Küsi küsimusi!; 32. Kodune töö
