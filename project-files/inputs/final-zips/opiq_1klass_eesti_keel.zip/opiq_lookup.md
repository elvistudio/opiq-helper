## Eesti keele õpik 1. klassile – Opiq
URL: https://www.opiq.ee/Kit/Details/141
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 352
Topics ET: matemaatika, eesti, keele, õpik, klassile, opiq
Topics RU: математика
Topics EN: mathematics

## Raamatute maailm
URL: https://www.opiq.ee/kit/141/chapter/7885
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 1.1
Topics ET: matemaatika, raamatute, maailm
Topics RU: математика
Topics EN: mathematics
Headings: Raamatute maailm

## Vilista mulle, Johanna I
URL: https://www.opiq.ee/kit/141/chapter/7918
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 10.1
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, vilista, mulle, johanna, berra, mure, täishääliku, harjutus
Topics RU: математика, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка
Topics EN: mathematics, measurement, unit, length, mass, volume, revision, review, practice
Headings: Vilista mulle, Johanna I; Berra mure; Täishääliku pikkus; HARJUTAN; Harjutus 1

## Vilista mulle, Johanna II
URL: https://www.opiq.ee/kit/141/chapter/7921
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 10.2
Topics ET: matemaatika, kordamine, korda, harjutan, vilista, mulle, johanna, teel, vanaisa, juurde, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Vilista mulle, Johanna II; Teel vanaisa juurde; Harjutus 1; HARJUTAN; Harjutus 2; Harjutus 3

## Vilista mulle, Johanna III
URL: https://www.opiq.ee/kit/141/chapter/7919
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 10.3
Topics ET: matemaatika, kordamine, korda, harjutan, vilista, mulle, johanna, kohtumine, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Vilista mulle, Johanna III; Kohtumine; HARJUTAN; Harjutus 1

## Vilista mulle, Johanna IV
URL: https://www.opiq.ee/kit/141/chapter/7920
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 10.4
Topics ET: matemaatika, vilista, mulle, johanna, mida, üheskoos, teha, harjutus, isad, pojad
Topics RU: математика
Topics EN: mathematics
Headings: Vilista mulle, Johanna IV; Mida üheskoos teha?; Harjutus 1; Isad ja pojad

## Pöialpoiss Nils Karlsson kolib sisse I
URL: https://www.opiq.ee/kit/141/chapter/7924
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 11.1
Topics ET: matemaatika, kordamine, korda, harjutan, pöialpoiss, nils, karlsson, kolib, sisse, pöidlapikkune, poiss, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pöialpoiss Nils Karlsson kolib sisse I; Pöidlapikkune poiss; HARJUTAN; Harjutus 1; Harjutus 1A; Harjutus 1B; Harjutus 2

## Pöialpoiss Nils Karlsson kolib sisse II
URL: https://www.opiq.ee/kit/141/chapter/7922
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 11.2
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, pöialpoiss, nils, karlsson, kolib, sisse, võlusõna, harjutus, täishääliku
Topics RU: математика, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка
Topics EN: mathematics, measurement, unit, length, mass, volume, revision, review, practice
Headings: Pöialpoiss Nils Karlsson kolib sisse II; Võlusõna; Harjutus 1; Täishääliku pikkus (Ä); HARJUTAN; Harjutus 2

## Pöialpoiss Nils Karlsson kolib sisse III
URL: https://www.opiq.ee/kit/141/chapter/7925
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 11.3
Topics ET: matemaatika, kordamine, korda, harjutan, pöialpoiss, nils, karlsson, kolib, sisse, koristuspäev, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pöialpoiss Nils Karlsson kolib sisse III; Koristuspäev; HARJUTAN; Harjutus 1

## Pöialpoiss Nils Karlsson kolib sisse IV
URL: https://www.opiq.ee/kit/141/chapter/7923
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 11.4
Topics ET: matemaatika, kordamine, korda, harjutan, pöialpoiss, nils, karlsson, kolib, sisse, tuba, saab, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pöialpoiss Nils Karlsson kolib sisse IV; Tuba saab uue näo; Harjutus 1B; Harjutus 1A; HARJUTAN; Harjutus 2; Harjutus 3; Harjutus 4

## Aadam ja arvuti I
URL: https://www.opiq.ee/kit/141/chapter/7926
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 12.1
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, aadam, arvuti, osav, käsi, suluta, kaashääliku, harjutus
Topics RU: математика, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка
Topics EN: mathematics, measurement, unit, length, mass, volume, revision, review, practice
Headings: Aadam ja arvuti I; Osav käsi; Suluta kaashääliku pikkus; HARJUTAN; Harjutus 1

## Aadam ja arvuti II
URL: https://www.opiq.ee/kit/141/chapter/7927
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 12.2
Topics ET: matemaatika, kordamine, korda, harjutan, aadam, arvuti, üksinda, kodus, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Aadam ja arvuti II; Üksinda kodus; HARJUTAN; Harjutus 1; Harjutus 2; Harjutus 3

## Minu ranits
URL: https://www.opiq.ee/kit/141/chapter/7928
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 12.3
Topics ET: matemaatika, kordamine, korda, harjutan, ranits, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Minu ranits; Harjutus 1; HARJUTAN; Harjutus 2

## Mänguõpetus
URL: https://www.opiq.ee/kit/141/chapter/7929
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 12.4
Topics ET: matemaatika, kordamine, korda, harjutan, mänguõpetus, luukere, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mänguõpetus; Luukere; HARJUTAN; Harjutus 1; Harjutus 2; Harjutus 3; Harjutus 4

## Trepp ja kepp
URL: https://www.opiq.ee/kit/141/chapter/7930
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 13.1
Topics ET: matemaatika, mõõtmine, mõõtühik, pikkus, mass, maht, kordamine, korda, harjutan, trepp, kepp, sulghääliku, harjutus
Topics RU: математика, измерение, единица измерения, длина, масса, объём, повторение, повтори, тренировка
Topics EN: mathematics, measurement, unit, length, mass, volume, revision, review, practice
Headings: Trepp ja kepp; Sulghääliku pikkus; HARJUTAN; Harjutus 1

## Minuga juhtub alati midagi I
URL: https://www.opiq.ee/kit/141/chapter/7931
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 13.2
Topics ET: matemaatika, kordamine, korda, harjutan, minuga, juhtub, alati, midagi, usaldus, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Minuga juhtub alati midagi I; Usaldus; Harjutus 1; HARJUTAN; Harjutus 2

## Minuga juhtub alati midagi II
URL: https://www.opiq.ee/kit/141/chapter/7932
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 13.3
Topics ET: matemaatika, kordamine, korda, harjutan, minuga, juhtub, alati, midagi, tasuta, asjad, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Minuga juhtub alati midagi II; Tasuta asjad; HARJUTAN; Harjutus 1

## Minuga juhtub alati midagi III
URL: https://www.opiq.ee/kit/141/chapter/7933
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 13.4
Topics ET: matemaatika, kordamine, korda, harjutan, minuga, juhtub, alati, midagi, asemel, kolm, häälikud, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Minuga juhtub alati midagi III; Ühe asemel kolm; Häälikud; HARJUTAN; Harjutus 1; Harjutus 2; Harjutus 2A; Harjutus 2B; Harjutus 2C

## Kooli­mõistatus I
URL: https://www.opiq.ee/kit/141/chapter/7934
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 14.1
Topics ET: matemaatika, kordamine, korda, harjutan, kooli, mõistatus, lepalehel, pole, vesimärki, harjutus, täishäälikuühend
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kooli­mõistatus I; Lepalehel pole vesimärki; Harjutus 1; Täishäälikuühend; HARJUTAN; Harjutus 2; Harjutus 3

## Kooli­mõistatus II
URL: https://www.opiq.ee/kit/141/chapter/7935
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 14.2
Topics ET: matemaatika, kordamine, korda, harjutan, kooli, mõistatus, paljundamine, keelatud, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kooli­mõistatus II; Paljundamine on keelatud; HARJUTAN; Harjutus 1; Harjutus 2; Harjutus 3

## Kooli­mõistatus III
URL: https://www.opiq.ee/kit/141/chapter/7936
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 14.3
Topics ET: matemaatika, kordamine, korda, harjutan, kooli, mõistatus, jäljekütid, peavad, plaani, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kooli­mõistatus III; Jäljekütid peavad plaani; HARJUTAN; Harjutus 1

## Kooli­mõistatus IV
URL: https://www.opiq.ee/kit/141/chapter/7937
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 14.4
Topics ET: matemaatika, kooli, mõistatus, tohoo, tonti, jutustamine, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kooli­mõistatus IV; Tohoo tonti!; Loo jutustamine; Harjutus 1

## Volli ostab nätsu I
URL: https://www.opiq.ee/kit/141/chapter/7938
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 15.1
Topics ET: matemaatika, kordamine, korda, harjutan, volli, ostab, nätsu, teeb, tutvust, mullinätsuga, kaashäälikuühend, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Volli ostab nätsu I; Volli teeb tutvust mullinätsuga; Kaashäälikuühend; HARJUTAN; Harjutus 1

## Volli ostab nätsu II
URL: https://www.opiq.ee/kit/141/chapter/7939
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 15.2
Topics ET: matemaatika, kordamine, korda, harjutan, volli, ostab, nätsu, ilus, koolipoisi, soeng, harjutus, kaashäälikuühend
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Volli ostab nätsu II; Ilus koolipoisi soeng; Harjutus 1; Kaashäälikuühend; HARJUTAN; Harjutus 2; Harjutus 3

## Volli ostab nätsu III
URL: https://www.opiq.ee/kit/141/chapter/7940
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 15.3
Topics ET: matemaatika, kordamine, korda, harjutan, volli, ostab, nätsu, tähtis, operatsioon, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Volli ostab nätsu III; Tähtis operatsioon; HARJUTAN; Harjutus 1; Harjutus 2; Harjutus 3A; Harjutus 3B

## Volli ostab nätsu IV
URL: https://www.opiq.ee/kit/141/chapter/7941
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 15.4
Topics ET: matemaatika, volli, ostab, nätsu, unistus, täitub, harjutus, liisusalmid
Topics RU: математика
Topics EN: mathematics
Headings: Volli ostab nätsu IV; Unistus täitub; Harjutus 1; Harjutus 2; Liisusalmid

## Lärmisepa tänava lapsed I
URL: https://www.opiq.ee/kit/141/chapter/7942
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 16.1
Topics ET: matemaatika, kordamine, korda, harjutan, lärmisepa, tänava, lapsed, hambaarsti, ooteruumis, harjutus, sõna, alguses
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Lärmisepa tänava lapsed I; Hambaarsti ooteruumis; Harjutus 1; H sõna alguses; HARJUTAN; Harjutus 2; Harjutus 3

## Lärmisepa tänava lapsed II
URL: https://www.opiq.ee/kit/141/chapter/7943
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 16.2
Topics ET: matemaatika, kordamine, korda, harjutan, lärmisepa, tänava, lapsed, kangekaelne, nagu, vana, kits, kirjanik, kunstnik
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Lärmisepa tänava lapsed II; Kangekaelne nagu vana kits; Kirjanik, kunstnik, tõlkija; HARJUTAN; Harjutus 1; Kirjanik

## Tere hommikust!
URL: https://www.opiq.ee/kit/141/chapter/7945
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 16.3
Topics ET: matemaatika, kordamine, korda, harjutan, tere, hommikust, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Tere hommikust!; Harjutus 1; Harjutus 2; HARJUTAN; Harjutus 3

## Vanasõnad
URL: https://www.opiq.ee/kit/141/chapter/7944
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 16.4
Topics ET: matemaatika, kordamine, korda, harjutan, vanasõnad, vanarahva, tarkused, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Vanasõnad; Vanarahva tarkused; Harjutus 1; HARJUTAN; Harjutus 2

## Presidendi auvaht I
URL: https://www.opiq.ee/kit/141/chapter/7946
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 17.1
Topics ET: matemaatika, kordamine, korda, harjutan, presidendi, auvaht, uhke, vanaema, sõna, alguses, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Presidendi auvaht I; Uhke vanaema; I ja J sõna alguses; Harjutus 1; Harjutus 2; HARJUTAN; Harjutus 3

## Presidendi auvaht II
URL: https://www.opiq.ee/kit/141/chapter/7947
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 17.2
Topics ET: matemaatika, kordamine, korda, harjutan, presidendi, auvaht, peab, jääma, liikumatuks, sõna, alguses, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Presidendi auvaht II; Auvaht peab jääma liikumatuks; I ja J sõna alguses; Harjutus 1; HARJUTAN; Harjutus 2

## Presidendi auvaht III
URL: https://www.opiq.ee/kit/141/chapter/7948
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 17.3
Topics ET: matemaatika, kordamine, korda, harjutan, presidendi, auvaht, nimekaimud, harjutus, jutustamine
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Presidendi auvaht III; Nimekaimud; Harjutus 1A; Harjutus 1B; Jutustamine; Harjutus 2; HARJUTAN; Harjutus 3; Harjutus 4; Harjutus 5

## Presidendi viktoriin
URL: https://www.opiq.ee/kit/141/chapter/7949
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 17.4
Topics ET: matemaatika, presidendi, viktoriin, kellest, jutt, harjutus, luuletused, unistuste, ametid, juhan
Topics RU: математика
Topics EN: mathematics
Headings: Presidendi viktoriin; Kellest on jutt?; Harjutus 1; Luuletused; Unistuste ametid; Juhan presidendiks; Harjutus 2

## Kuidas elavad väikesed sipelgad?
URL: https://www.opiq.ee/kit/141/chapter/7950
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 18.1
Topics ET: matemaatika, kuidas, elavad, väikesed, sipelgad, hiiglased, harjutus, sõna, alguses
Topics RU: математика
Topics EN: mathematics
Headings: Kuidas elavad väikesed sipelgad?; Väikesed hiiglased; Harjutus 1; Harjutus 2; K, P ja T sõna alguses; Harjutus 3; Harjutus 4

## Kodukakk, päevakoer ja teised
URL: https://www.opiq.ee/kit/141/chapter/7951
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 18.2
Topics ET: matemaatika, kordamine, korda, harjutan, kodukakk, päevakoer, teised, sipelgad, harjutus, kiil, toonekurg
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kodukakk, päevakoer ja teised; Sipelgad; Harjutus 1A; Harjutus 1B; Kiil; Toonekurg; Harjutus 2A; Harjutus 2B; Harjutus 3; HARJUTAN; Harjutus 4

## Pääsukeste teretus
URL: https://www.opiq.ee/kit/141/chapter/7952
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 18.3
Topics ET: matemaatika, kordamine, korda, harjutan, pääsukeste, teretus, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pääsukeste teretus; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 1D; HARJUTAN; Harjutus 2; Harjutus 3

## Teadetetahvel
URL: https://www.opiq.ee/kit/141/chapter/7953
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 18.4
Topics ET: matemaatika, kordamine, korda, harjutan, teadetetahvel, harjutus, sulghäälikud, kõrval, etteütlus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Teadetetahvel; Harjutus 1A; Harjutus 1B; Harjutus 2A; Harjutus 2B; Sulghäälikud s-i ja h kõrval; HARJUTAN; Harjutus 3; Harjutus 4; Harjutus 5. Etteütlus

## Mammutite kool I
URL: https://www.opiq.ee/kit/141/chapter/7954
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 19.1
Topics ET: matemaatika, kordamine, korda, harjutan, mammutite, kool, oskar, kooli, jõudis, olid, tunnid, juba, alanud
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mammutite kool I; Kui Oskar kooli jõudis, olid tunnid juba alanud ...; Harjutus 1A; Harjutus 1B; Kellega? Millega?; HARJUTAN; Harjutus 2; Harjutus 3

## Mammutite kool II
URL: https://www.opiq.ee/kit/141/chapter/7955
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 19.2
Topics ET: matemaatika, kordamine, korda, harjutan, mammutite, kool, kahejalgne, sööb, apelsine, harjutus, kuhu
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mammutite kool II; Kahejalgne, kes sööb apelsine; Harjutus 1; Harjutus 2; Harjutus 3A; Harjutus 3B; Kus? Kuhu?; Harjutus 4; HARJUTAN; Harjutus 5; Harjutus 6

## Mammutite kool III
URL: https://www.opiq.ee/kit/141/chapter/7956
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 19.3
Topics ET: matemaatika, loom, loomad, linnud, putukad, inimene, keha, meeled, tervis, mammutite, kool, kõige, ohtlikum, harjutus, algab
Topics RU: математика, животное, животные, птицы, насекомые, человек, тело, чувства, здоровье
Topics EN: mathematics, animal, animals, birds, insects, human, body, senses, health
Headings: Mammutite kool III; Kõige ohtlikum loom on inimene; Harjutus 1; Mis algab

## Kust leiab vastuseid
URL: https://www.opiq.ee/kit/141/chapter/7957
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 19.4
Topics ET: matemaatika, kust, leiab, vastuseid, mõtelda, mõnus, sain, teada, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Kust leiab vastuseid; Mõtelda on mõnus; Sain teada, et ...; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 1D

## Kakssada grammi võid I
URL: https://www.opiq.ee/kit/141/chapter/7886
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 2.1
Topics ET: matemaatika, kordamine, korda, harjutan, kakssada, grammi, võid, ilmar, peab, poodi, minema, harjutus, liitsõna
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kakssada grammi võid I; Ilmar peab poodi minema; Harjutus 1A; Harjutus 1B; Harjutus 1C; Liitsõna; HARJUTAN; Harjutus 2; Harjutus 3

## Kakssada grammi võid II
URL: https://www.opiq.ee/kit/141/chapter/7887
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 2.2
Topics ET: matemaatika, kordamine, korda, harjutan, kakssada, grammi, võid, teekond, poodi, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kakssada grammi võid II; Teekond poodi; Harjutus 1A; Harjutus 1B; HARJUTAN; Harjutus 2; Harjutus 3

## Kakssada grammi võid III
URL: https://www.opiq.ee/kit/141/chapter/7888
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 2.3
Topics ET: matemaatika, kordamine, korda, harjutan, kakssada, grammi, võid, tagasi, pole, vaja, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kakssada grammi võid III; Tagasi pole vaja; Harjutus 1; HARJUTAN; Harjutus 2; Harjutus 3; Harjutus 4A; Harjutus 4B

## Teremees Tõnu
URL: https://www.opiq.ee/kit/141/chapter/7889
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 2.4
Topics ET: matemaatika, kordamine, korda, harjutan, teremees, tõnu, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Teremees Tõnu; HARJUTAN; Harjutus 1; Harjutus 2; Harjutus 3

## Vares ja rebane I
URL: https://www.opiq.ee/kit/141/chapter/7958
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 20.1
Topics ET: matemaatika, vares, rebane, nälg, näpistab, harjutus, omadussõna
Topics RU: математика
Topics EN: mathematics
Headings: Vares ja rebane I; Nälg näpistab; Harjutus 1A; Harjutus 1B; Harjutus 2A; Harjutus 2B; Harjutus 2C; Omadussõna; Harjutus 3

## Vares ja rebane II
URL: https://www.opiq.ee/kit/141/chapter/7959
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 20.2
Topics ET: matemaatika, kordamine, korda, harjutan, vares, rebane, õpetab, rebast, kavaldama, harjutus, omadussõna
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Vares ja rebane II; Vares õpetab rebast kavaldama; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 1D; Omadussõna; Harjutus 2A; Harjutus 2B; HARJUTAN; Harjutus 3

## Vares ja rebane III
URL: https://www.opiq.ee/kit/141/chapter/7960
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 20.3
Topics ET: matemaatika, kordamine, korda, harjutan, vares, rebane, kõrvust, tõstetud, harjutus, omadussõna, võrdlusastmed
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Vares ja rebane III; Kõrvust tõstetud; Harjutus 1; Harjutus 2A; Harjutus 2B; Omadussõna võrdlusastmed; HARJUTAN; Harjutus 3; Harjutus 3A; Harjutus 3B

## Mitmekülgne lehmatädi
URL: https://www.opiq.ee/kit/141/chapter/7961
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 20.4
Topics ET: matemaatika, kordamine, korda, harjutan, mitmekülgne, lehmatädi, omadussõna, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mitmekülgne lehmatädi; Omadussõna; Harjutus 1; HARJUTAN; Harjutus 2; Harjutus 3

## Ruubert, lohe ja laevapoisid I
URL: https://www.opiq.ee/kit/141/chapter/7962
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 21.1
Topics ET: matemaatika, kordamine, korda, harjutan, ruubert, lohe, laevapoisid, haigutades, pannakse, käsi, ette, harjutus, sama
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Ruubert, lohe ja laevapoisid I; Haigutades pannakse käsi suu ette; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 1D; Harjutus 1E; Sama tähendusega sõnad; HARJUTAN; Harjutus 2; Harjutus 3

## Ruubert, lohe ja laevapoisid II
URL: https://www.opiq.ee/kit/141/chapter/7963
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 21.2
Topics ET: matemaatika, kordamine, korda, harjutan, ruubert, lohe, laevapoisid, tosver, jesver, isver, klimp, saab, pragada
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Ruubert, lohe ja laevapoisid II; Tosver Jesver Isver von Klimp saab pragada; Harjutus 1A; Harjutus 1B; Harjutus 1C; HARJUTAN; Harjutus 2; Harjutus 3

## Ruubert, lohe ja laevapoisid III
URL: https://www.opiq.ee/kit/141/chapter/7964
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 21.3
Topics ET: matemaatika, kordamine, korda, harjutan, ruubert, lohe, laevapoisid, kõik, kohad, hirmsat, tossu, täis, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Ruubert, lohe ja laevapoisid III; Kõik kohad on hirmsat tossu täis; Harjutus 1A; Harjutus 1B; Sama tähendusega sõnad; Harjutus 2; HARJUTAN; Harjutus 3

## Ruubert, lohe ja laevapoisid IV
URL: https://www.opiq.ee/kit/141/chapter/7965
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 21.4
Topics ET: matemaatika, kordamine, korda, harjutan, ruubert, lohe, laevapoisid, siin, jälle, sirgeldab, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Ruubert, lohe ja laevapoisid IV; Kes siin jälle sirgeldab?!; Harjutus 1A; Harjutus 1B; HARJUTAN; Harjutus 2

## Nutu-Leenu I
URL: https://www.opiq.ee/kit/141/chapter/7966
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 22.1
Topics ET: matemaatika, kordamine, korda, harjutan, nutu, leenu, kurbus, taha, minna, harjutus, vastandsõnad
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Nutu-Leenu I; Kurbus ei taha ega taha üle minna; Harjutus 1A; Harjutus 1B; Harjutus 1C; Vastandsõnad; HARJUTAN; Harjutus 2

## Nutu-Leenu II
URL: https://www.opiq.ee/kit/141/chapter/7967
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 22.2
Topics ET: matemaatika, kordamine, korda, harjutan, nutu, leenu, muredega, üksi, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Nutu-Leenu II; Nutu-Leenu on oma muredega üksi; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 1D; HARJUTAN; Harjutus 2

## Nutu-Leenu III
URL: https://www.opiq.ee/kit/141/chapter/7968
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 22.3
Topics ET: matemaatika, kordamine, korda, harjutan, nutu, leenu, mitukümmend, paid, kallit, harjutus, kapten
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Nutu-Leenu III; Mitukümmend paid ja kallit; Harjutus 1A; Harjutus 1B; Kapten; Harjutus 2; HARJUTAN; Harjutus 3

## Salmid
URL: https://www.opiq.ee/kit/141/chapter/7969
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 22.4
Topics ET: matemaatika, kordamine, korda, harjutan, salmid, laul, kurbusest, raskemeelne, rosin, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Salmid; Laul kurbusest; Raskemeelne rosin; HARJUTAN; Harjutus 1

## King I
URL: https://www.opiq.ee/kit/141/chapter/7970
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 23.1
Topics ET: matemaatika, kordamine, korda, harjutan, king, kust, tulevad, konnad, harjutus, asesõnad
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: King I; Kust tulevad konnad?; Harjutus 1A; Harjutus 1B; Asesõnad; HARJUTAN; Harjutus 2

## King II
URL: https://www.opiq.ee/kit/141/chapter/7971
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 23.2
Topics ET: matemaatika, kordamine, korda, harjutan, king, kullesest, saab, konn, harjutus, asesõnad
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: King II; Kui kullesest saab konn; Harjutus 1; Asesõnad; Harjutus 2; HARJUTAN; Harjutus 3

## King III
URL: https://www.opiq.ee/kit/141/chapter/7973
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 23.3
Topics ET: matemaatika, kordamine, korda, harjutan, king, konna, koht, purgis, harjutus, tegusõna, pöörded
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: King III; Konna koht ei ole purgis; Harjutus 1A; Harjutus 1B; Tegusõna pöörded; Harjutus 2; HARJUTAN; Harjutus 3; Harjutus 3A; Harjutus 3B; Harjutus 3C; Harjutus 3D

## Mu mütsil on kolm nurka
URL: https://www.opiq.ee/kit/141/chapter/7972
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 23.4
Topics ET: matemaatika, kordamine, korda, harjutan, mütsil, kolm, nurka, veneetsia, karneval, kehakeel, harjutus, voltimine
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mu mütsil on kolm nurka; Veneetsia karneval; Kehakeel; Harjutus 1; Harjutus 2; Harjutus 3; HARJUTAN; Harjutus 4; Voltimine

## Liivamäng I
URL: https://www.opiq.ee/kit/141/chapter/7974
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 24.1
Topics ET: matemaatika, kordamine, korda, harjutan, liivamäng, ehitame, midagi, harjutus, suur, algustäht
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Liivamäng I; Ehitame midagi?; Harjutus 1A; Harjutus 1B; Suur algustäht; HARJUTAN; Harjutus 2

## Liivamäng II
URL: https://www.opiq.ee/kit/141/chapter/7975
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 24.2
Topics ET: matemaatika, kordamine, korda, harjutan, liivamäng, liivast, vormitud, eesti, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Liivamäng II; Liivast vormitud Eesti; Harjutus 1; HARJUTAN; Harjutus 2

## Liivamäng III
URL: https://www.opiq.ee/kit/141/chapter/7976
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 24.3
Topics ET: matemaatika, kordamine, korda, harjutan, liivamäng, eesti, mereriik, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Liivamäng III; Eesti on mereriik; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 1D; HARJUTAN; Harjutus 2

## Emadepäev
URL: https://www.opiq.ee/kit/141/chapter/7977
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 24.4
Topics ET: matemaatika, emadepäev, emadepäeva, laul, emakeel, rahva, meel
Topics RU: математика
Topics EN: mathematics
Headings: Emadepäev; Emadepäeva laul; Emakeel ja rahva meel

## Peep ja sõnad I
URL: https://www.opiq.ee/kit/141/chapter/7978
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 25.1
Topics ET: matemaatika, kordamine, korda, harjutan, vesi, veeohutus, veekogu, peep, sõnad, ahjus, harjutus, kõnekäänd
Topics RU: математика, повторение, повтори, тренировка, вода, безопасность на воде, водоём
Topics EN: mathematics, revision, review, practice, water, water safety, body of water
Headings: Peep ja sõnad I; Vesi ahjus; Harjutus 1A; Harjutus 1B; Kõnekäänd; HARJUTAN; Harjutus 2

## Peep ja sõnad II
URL: https://www.opiq.ee/kit/141/chapter/7979
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 25.2
Topics ET: matemaatika, peep, sõnad, jänes, põues, harjutus, loovülesanded
Topics RU: математика
Topics EN: mathematics
Headings: Peep ja sõnad II; Jänes põues; Harjutus 1A; Harjutus 1B; Loovülesanded

## Peep ja sõnad III
URL: https://www.opiq.ee/kit/141/chapter/7980
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 25.3
Topics ET: matemaatika, kordamine, korda, harjutan, peep, sõnad, ajab, vanaemale, kärbseid, pähe, harjutus, laul, kolmest
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Peep ja sõnad III; Peep ajab vanaemale kärbseid pähe; Harjutus 1A; Harjutus 1B; Laul kolmest kihulasest; Harjutus 2; HARJUTAN; Harjutus 3

## Anekdoodid
URL: https://www.opiq.ee/kit/141/chapter/7981
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 25.4
Topics ET: matemaatika, anekdoodid, nalja, nabani
Topics RU: математика
Topics EN: mathematics
Headings: Anekdoodid; Nalja nabani

## Pettsoni peenramaa I
URL: https://www.opiq.ee/kit/141/chapter/7982
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 26.1
Topics ET: matemaatika, kordamine, korda, harjutan, pettsoni, peenramaa, käes, külviaeg, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pettsoni peenramaa I; Käes on külviaeg; Harjutus 1; HARJUTAN; Harjutus 2; Harjutus 3

## Pettsoni peenramaa II
URL: https://www.opiq.ee/kit/141/chapter/7983
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 26.2
Topics ET: matemaatika, pettsoni, peenramaa, maiad, kanad, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: Pettsoni peenramaa II; Maiad kanad; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 2

## Istutasin riidepuu
URL: https://www.opiq.ee/kit/141/chapter/7984
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 26.3
Topics ET: matemaatika, kordamine, korda, harjutan, istutasin, riidepuu, harjutus, riimid
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Istutasin riidepuu; Harjutus 1; Riimid; HARJUTAN; Harjutus 2; Harjutus 3

## Kordamine
URL: https://www.opiq.ee/kit/141/chapter/7985
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 26.4
Topics ET: matemaatika, kordamine, korda, harjutan, tarkuse
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kordamine; Kordamine on tarkuse ema

## Sünnipäev
URL: https://www.opiq.ee/kit/141/chapter/7986
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 26.5
Topics ET: matemaatika, sünnipäev, lisa, lõbusat, suve
Topics RU: математика
Topics EN: mathematics
Headings: Sünnipäev; Lisa; LÕBUSAT SUVE!

## Sõnaseletused
URL: https://www.opiq.ee/kit/141/chapter/7987
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 27.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Impressum
URL: https://www.opiq.ee/kit/141/chapter/13946
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 27.2
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Sama laps
URL: https://www.opiq.ee/kit/141/chapter/7890
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 3.1
Topics ET: matemaatika, kordamine, korda, harjutan, sama, laps, seltsimees, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Sama laps; Seltsimees laps; Harjutus 1; Harjutus 1A; Harjutus 1B; Harjutus 1C; Kes? Mis?; HARJUTAN; Harjutus 2; Harjutus 3

## Hiir, kes oskas võõraid keeli I
URL: https://www.opiq.ee/kit/141/chapter/7891
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 3.2
Topics ET: matemaatika, kordamine, korda, harjutan, hiir, oskas, võõraid, keeli, kirju, kasukaga, vembumees, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Hiir, kes oskas võõraid keeli I; Kirju kasukaga vembumees; Harjutus 1A; Harjutus 1B; Harjutus 1C; HARJUTAN; Harjutus 3; Harjutus 2

## Hiir, kes oskas võõraid keeli II
URL: https://www.opiq.ee/kit/141/chapter/7892
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 3.3
Topics ET: matemaatika, kordamine, korda, harjutan, hiir, oskas, võõraid, keeli, kutsumata, külaline, harjutus, mitu
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Hiir, kes oskas võõraid keeli II; Kutsumata külaline; Harjutus 1; Üks või mitu?; HARJUTAN; Harjutus 2; Harjutus 3; Harjutus 4; Harjutus 5

## Palju õnne sünnipäevaks!
URL: https://www.opiq.ee/kit/141/chapter/7893
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 3.4
Topics ET: matemaatika, kordamine, korda, harjutan, palju, õnne, sünnipäevaks, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Palju õnne sünnipäevaks!; Harjutus 1; Harjutus 2; HARJUTAN; Harjutus 3; Harjutus 4

## Madli pinginaaber I
URL: https://www.opiq.ee/kit/141/chapter/7894
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 4.1
Topics ET: matemaatika, kordamine, korda, harjutan, madli, pinginaaber, esimene, koolipäev, harjutus, tegusõna
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Madli pinginaaber I; Esimene koolipäev; Harjutus 1; Tegusõna; Harjutus 2; HARJUTAN; Harjutus 3; Harjutus 4

## Madli pinginaaber II
URL: https://www.opiq.ee/kit/141/chapter/7895
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 4.2
Topics ET: matemaatika, kordamine, korda, harjutan, madli, pinginaaber, kuidas, koolis, läheb, harjutus, mida, teeb, teevad
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Madli pinginaaber II; Kuidas koolis läheb?; Harjutus 1A; Harjutus 1B; Mida teeb? Mida teevad?; HARJUTAN; Harjutus 2; Loeme koos!

## Madli pinginaaber III
URL: https://www.opiq.ee/kit/141/chapter/7896
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 4.3
Topics ET: matemaatika, kordamine, korda, harjutan, madli, pinginaaber, veerandi, lõpp, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Madli pinginaaber III; Veerandi lõpp; HARJUTAN; Harjutus 1; Harjutus 2

## Klassi orkester
URL: https://www.opiq.ee/kit/141/chapter/7897
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 4.4
Topics ET: matemaatika, kordamine, korda, harjutan, klassi, orkester, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Klassi orkester; Harjutus 1; HARJUTAN; Harjutus 2

## Oskar ja asjad I
URL: https://www.opiq.ee/kit/141/chapter/7898
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 5.1
Topics ET: matemaatika, kordamine, korda, harjutan, oskar, asjad, mängumobla, harjutus, punkt, küsimärk
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Oskar ja asjad I; Mängumobla; Harjutus 1A; Harjutus 1B; Punkt, küsimärk; HARJUTAN; Harjutus 3; Harjutus 2

## Oskar ja asjad II
URL: https://www.opiq.ee/kit/141/chapter/7899
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 5.2
Topics ET: matemaatika, kordamine, korda, harjutan, oskar, asjad, võimalik, hüüumärk, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Oskar ja asjad II; See ei ole võimalik!; Hüüumärk; HARJUTAN; Harjutus 1; Harjutus 2

## Oskar ja asjad III
URL: https://www.opiq.ee/kit/141/chapter/7900
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 5.3
Topics ET: matemaatika, kordamine, korda, harjutan, oskar, asjad, halloo, harjutus, vaata, kuula, lause, algustäht
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Oskar ja asjad III; Halloo!; Harjutus 1A; Harjutus 1B; Vaata ja kuula; Harjutus 2; Harjutus 2A; Harjutus 2B; Harjutus 2D; Harjutus 3; Harjutus 3A; Harjutus 3B; Harjutus 3C; Harjutus 3D; Lause algustäht; HARJUTAN; Harjutus 4; Harjutus 5; Harjutus 6

## Miks?
URL: https://www.opiq.ee/kit/141/chapter/7901
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 5.4
Topics ET: matemaatika, kordamine, korda, harjutan, miks, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Miks?; Harjutus 1A; Harjutus 1B; HARJUTAN; Harjutus 2

## 12 kinki jõulutaadile I
URL: https://www.opiq.ee/kit/141/chapter/7902
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 6.1
Topics ET: matemaatika, kordamine, korda, harjutan, kinki, jõulutaadile, jõuluootus, harjutus, suur, algustäht, nimes, vaata, kuula
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: 12 kinki jõulutaadile I; Jõuluootus; Harjutus 1; Suur algustäht nimes; Vaata ja kuula; Harjutus 2; HARJUTAN; Harjutus 3; Harjutus 4

## 12 kinki jõulutaadile II
URL: https://www.opiq.ee/kit/141/chapter/7903
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 6.2
Topics ET: matemaatika, kordamine, korda, harjutan, kinki, jõulutaadile, lõngakera, harjutus, kassikangas
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: 12 kinki jõulutaadile II; Lõngakera; HARJUTAN; Harjutus 1A; Harjutus 1B; Kassikangas

## 12 kinki jõulutaadile III
URL: https://www.opiq.ee/kit/141/chapter/7904
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 6.3
Topics ET: matemaatika, kinki, jõulutaadile, mustikasupp, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: 12 kinki jõulutaadile III; Mustikasupp; Harjutus 1

## Salmid
URL: https://www.opiq.ee/kit/141/chapter/7905
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 6.4
Topics ET: matemaatika, kordamine, korda, harjutan, salmid, jõulupuu, polla, jõulupuud, nääripäkapikk, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Salmid; Jõulupuu ja Polla; Jõulupuud; Nääripäkapikk; HARJUTAN; Harjutus 1

## Minu õnnelik elu I
URL: https://www.opiq.ee/kit/141/chapter/7906
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 7.1
Topics ET: matemaatika, kordamine, korda, harjutan, õnnelik, väikesed, suured, asjad, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Minu õnnelik elu I; Väikesed suured asjad; Harjutus 1A; Harjutus 1B; HARJUTAN; Harjutus 2A; Harjutus 2B; Harjutus 2C

## Minu õnnelik elu II
URL: https://www.opiq.ee/kit/141/chapter/7907
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 7.2
Topics ET: matemaatika, kordamine, korda, harjutan, õnnelik, esimene, koolipäev, harjutus, näide
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Minu õnnelik elu II; Esimene koolipäev; Harjutus 1A; Harjutus 1B; HARJUTAN; Näide; Harjutus 2A; Harjutus 2B

## Minu õnnelik elu III
URL: https://www.opiq.ee/kit/141/chapter/7908
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 7.3
Topics ET: matemaatika, liitmine, liida, summa, kokku, kordamine, korda, harjutan, õnnelik, loodud, sõnadest, saab, jutu, harjutus
Topics RU: математика, сложение, сложи, сумма, повторение, повтори, тренировка
Topics EN: mathematics, addition, add, sum, revision, review, practice
Headings: Minu õnnelik elu III; Kokku loodud; Sõnadest saab jutu; HARJUTAN; Harjutus 1; Harjutus 2

## Minu õnnelik elu IV
URL: https://www.opiq.ee/kit/141/chapter/7909
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 7.4
Topics ET: matemaatika, kordamine, korda, harjutan, õnnelik, tüliõun, jutu, ülesehitus, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Minu õnnelik elu IV; Tüliõun; Jutu ülesehitus; HARJUTAN; Harjutus 1; Harjutus 2

## Jutustus ootamatust nirgikesest
URL: https://www.opiq.ee/kit/141/chapter/7912
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 8.1
Topics ET: matemaatika, kordamine, korda, harjutan, jutustus, ootamatust, nirgikesest, harjutus, liitlause
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Jutustus ootamatust nirgikesest; Harjutus 1A; Harjutus 1B; Liitlause; HARJUTAN; Harjutus 2; Harjutus 3

## Mart, Anu ja Sipsik I
URL: https://www.opiq.ee/kit/141/chapter/7913
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 8.2
Topics ET: matemaatika, kordamine, korda, harjutan, mart, sipsik, isetehtud, sünnipäevakingitus, harjutus, liitlause
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mart, Anu ja Sipsik I; Isetehtud sünnipäevakingitus; Harjutus 1; Liitlause; HARJUTAN; Harjutus 2A; Harjutus 2B; Harjutus 3

## Mart, Anu ja Sipsik II
URL: https://www.opiq.ee/kit/141/chapter/7910
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 8.3
Topics ET: matemaatika, kordamine, korda, harjutan, mart, sipsik, ainulaadne, nukk, harjutus, liitlause
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mart, Anu ja Sipsik II; Ainulaadne nukk; Harjutus 1; Liitlause; Harjutus 2; Harjutus 3; HARJUTAN; Harjutus 4

## Mart, Anu ja Sipsik III
URL: https://www.opiq.ee/kit/141/chapter/7911
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 8.4
Topics ET: matemaatika, kordamine, korda, harjutan, mart, sipsik, armastuse, võlujõud, kuidas, sündis, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Mart, Anu ja Sipsik III; Armastuse võlujõud; Kuidas sündis „Sipsik”; Harjutus 1; Harjutus 1A; Harjutus 1B; Harjutus 1C; HARJUTAN; Harjutus 2; Harjutus 3

## Tiritamm
URL: https://www.opiq.ee/kit/141/chapter/7914
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 9.1
Topics ET: matemaatika, kordamine, korda, harjutan, tiritamm, harjutus, silp
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Tiritamm; Harjutus 1A; Harjutus 1B; Silp; HARJUTAN; Harjutus 2

## Pätu I
URL: https://www.opiq.ee/kit/141/chapter/7915
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 9.2
Topics ET: matemaatika, kordamine, korda, harjutan, pätu, laul, lasnamäest, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pätu I; Kes või mis on Pätu?; Laul Lasnamäest; Harjutus 1; Harjutus 1A; Harjutus 1B; Harjutus 1C; Harjutus 2; Harjutus 2A; Harjutus 2B; Harjutus 2C; HARJUTAN; Harjutus 3; Harjutus 4; Harjutus 5

## Pätu II
URL: https://www.opiq.ee/kit/141/chapter/7917
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 9.3
Topics ET: matemaatika, kordamine, korda, harjutan, pätu, mida, oskab, laul, rikkis, ukselukust, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pätu II; Mida Pätu oskab?; Laul rikkis ukselukust; Harjutus 1; HARJUTAN; Harjutus 2

## Pätu III
URL: https://www.opiq.ee/kit/141/chapter/7916
Book: Raamatute maailm
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita2_est
Chapter ID: 9.4
Topics ET: matemaatika, kordamine, korda, harjutan, pätu, kust, majja, tulnud, harjutus, laul, tagaigatsemisest
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pätu III; Kust on Pätu majja tulnud?; Harjutus 1; Harjutus 1A; Harjutus 1B; Harjutus 1C; Laul Pätu tagaigatsemisest; Harjutus 2; Harjutus 2A; Harjutus 2B; HARJUTAN; Harjutus 3

## Aabits – Opiq
URL: https://www.opiq.ee/Kit/Details/79
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 242
Topics ET: matemaatika, aabits, opiq
Topics RU: математика
Topics EN: mathematics

## NII SEE ALGAB
URL: https://www.opiq.ee/kit/79/chapter/3882
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.1
Topics ET: matemaatika, algab, siim, koolitee, koolimaja, vaata, filmi, tavaline, linn, harjutus
Topics RU: математика
Topics EN: mathematics
Headings: NII SEE ALGAB; Siim ja Ott; Koolitee; KOOLIMAJA; VAATA FILMI; ÜKS TAVALINE LINN; HARJUTUS 1A; HARJUTUS 1B

## Nn
URL: https://www.opiq.ee/kit/79/chapter/3891
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.10
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, siimu, nohu, saladuse, hoidmine, vanaemaga, kodus, häälda, mõtle
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Nn; SIIMU NOHU; SALADUSE HOIDMINE; VANAEMAGA KODUS; HÄÄLDA JA VÕRDLE; • MÕTLE IGA SÕNAGA LAUSE.; HARJUTUS 1; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Ss
URL: https://www.opiq.ee/kit/79/chapter/3892
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.11
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, ussikese, nüüd, vahel, susiseb, salapäraselt, kuss, söögivahetund, aitab, jutust
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Ss; S SÕI USSIKESE ÄRA,​NÜÜD ON ISE TA KUI USS.​VAHEL SUSISEB JA VAHEL​SALAPÄRASELT ON KUSS.; SÖÖGIVAHETUND; AITAB JUTUST!; HÄÄLDA JA VÕRDLE; HARJUTUS 1; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## L, S, M, N
URL: https://www.opiq.ee/kit/79/chapter/3893
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.12
Topics ET: matemaatika, kordamine, korda, harjutan, õudne, muinasjutt, õhku, täis, konn, jätan, meelde, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: L, S, M, N; ÕUDNE MUINASJUTT; ÕHKU TÄIS KONN; JÄTAN MEELDE; HARJUTAN; HARJUTUS 1; HARJUTUS 2

## Uu
URL: https://www.opiq.ee/kit/79/chapter/3894
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.13
Topics ET: matemaatika, kordamine, korda, harjutan, luulevõistlus, luuletajad, harjutus, kirjutan, kiri, sidumata
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Uu; LUULEVÕISTLUS; LUULETAJAD; HARJUTAN; HARJUTUS 1; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Tt
URL: https://www.opiq.ee/kit/79/chapter/3895
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.14
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, teatris, lava, taga, häälda, harjutus, kirjutan, kiri, sidumata
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Tt; TEATRIS; LAVA TAGA; HÄÄLDA JA VÕRDLE; HARJUTUS 1; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Dd
URL: https://www.opiq.ee/kit/79/chapter/3896
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.15
Topics ET: matemaatika, kordamine, korda, harjutan, kelleks, saada, doktor, kertu, harjutus, mitu, kirjutan, kiri
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Dd; KELLEKS SAADA?; DOKTOR KERTU; HARJUTAN; HARJUTUS 1; HARJUTUS 2A; HARJUTUS 2B; ÜKS VÕI MITU?; HARJUTUS 3; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## D, T, TT
URL: https://www.opiq.ee/kit/79/chapter/3897
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.16
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan, rattamatk, võistlejad, mudas, häälda, harjutus
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice
Headings: D, T, TT; RATTAMATK; VÕISTLEJAD MUDAS; HÄÄLDA JA VÕRDLE; HARJUTAN; HARJUTUS 2; HARJUTUS 1

## Oo
URL: https://www.opiq.ee/kit/79/chapter/3898
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.17
Topics ET: matemaatika, kordamine, korda, harjutan, tore, koht, pööning, siin, tolmu, gloobuseid, kolle, topiseid, mööblit, kotte, noote, albumeid
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Oo; OO, MIS TORE KOHT ON PÖÖNING!​SIIN ON TOLMU, GLOOBUSEID,​KOLLE, TOPISEID JA MÖÖBLIT,​KOTTE, NOOTE, ALBUMEID.; KOOLI KORISTAMINE; TIIGER; JÄTAN MEELDE; HARJUTAN; HARJUTUS 1A; HARJUTUS 1B; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Rr
URL: https://www.opiq.ee/kit/79/chapter/3899
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.18
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, postirobot, robi, ronis, rula, peale, raginal, jagas, lehti, ajakirju, kriuksus, naerda, kriginal
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Rr; POSTIROBOT ROBI RONIS​RULA PEALE RAGINAL,​JAGAS LEHTI, AJAKIRJU, ​KRIUKSUS NAERDA KRIGINAL.; URRI JA ROBOT; PAKIROBOT JA URRI; JÄTAN MEELDE; HÄÄLDA JA VÕRDLE; HARJUTUS 1; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Kk
URL: https://www.opiq.ee/kit/79/chapter/3900
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.19
Topics ET: matemaatika, kordamine, korda, harjutan, koob, sokki, vanaema, korvis, keerleb, lõngakera, kiisu, kiki, silmis, sära, näppab, korvist, kera
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Kk; KUI KOOB SOKKI VANAEMA,​KORVIS KEERLEB LÕNGAKERA.​KIISU KIKI, SILMIS SÄRA,​NÄPPAB KORVIST KERA ÄRA.; KIKI SOKID; SOKID KASSILE; HARJUTAN; HARJUTUS 1; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## ESIMENE KOOLIPÄEV. TÄHT, SÕNA, LAUSE
URL: https://www.opiq.ee/kit/79/chapter/3883
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.2
Topics ET: matemaatika, kordamine, korda, harjutan, esimene, koolipäev, täht, sõna, lause, algab, kool, lapsed, põnevil
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: ESIMENE KOOLIPÄEV. TÄHT, SÕNA, LAUSE; ALGAB KOOL.; LAPSED ON PÕNEVIL.; ESIMENE KOOLIPÄEV; LEIAME KOHAD; JÄTAN MEELDE; HARJUTAN; HARJUTUS 1; HARJUTUS 2; HARJUTUS 3A; HARJUTUS 3B

## Õõ
URL: https://www.opiq.ee/kit/79/chapter/3901
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.20
Topics ET: matemaatika, kordamine, korda, harjutan, õitsemine, õrnus, õppimine, õlas, õles, õues, lõõmav, rõõm, põues
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Õõ; Õ ON ÕNN JA ÕITSEMINE,​Õ ON ÕRNUS, ÕPPIMINE,​Õ ON ÕLAS, ÕLES, ÕUES,​Õ ON LÕÕMAV RÕÕM SU PÕUES.; VÕISTLUS; SURUME KÄTT; HARJUTAN; HARJUTUS 1; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Öö
URL: https://www.opiq.ee/kit/79/chapter/3902
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.21
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, käib, öösiti, öötööl, vööl, ripub, lassonöör, sõnaseletus, lasso, viskenöör, loomade, püüdmiseks, püüab, tähti, neid, sööb
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Öö; Ö KÄIB ÖÖSITI ÖÖTÖÖL,​VÖÖL TAL RIPUB LASSONÖÖR,[sõnaseletus: LASSO – VISKENÖÖR LOOMADE PÜÜDMISEKS]​PÜÜAB TÄHTI JA NEID SÖÖB,​ÖÖTÖÖ LÕPUS TANTSU LÖÖB.; SAARTE MURRE; Õ ASEMEL Ö; HÄÄLDA JA VÕRDLE; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Gg
URL: https://www.opiq.ee/kit/79/chapter/3903
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.22
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, pehme, teda, väga, sega, tugev, sõna, sees, kilogrammimees, kertu
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Gg; G ON PEHME, AGA EGA​TEDA VÄGA SEE EI SEGA.​TA ON TUGEV SÕNA SEES,​TA ON KILOGRAMMIMEES.; KERTU UUDIS; VÄIKE ÕDE; HÄÄLDA JA VÕRDLE; HARJUTUS 1; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## G, K, KK
URL: https://www.opiq.ee/kit/79/chapter/3904
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.23
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, isaga, islandist, geisrid, islandil, häälda, harjutus
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: G, K, KK; ISAGA ISLANDIST; GEISRID ISLANDIL; HÄÄLDA JA VÕRDLE; HARJUTUS 1A; HARJUTUS 1B

## Ää
URL: https://www.opiq.ee/kit/79/chapter/3905
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.24
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, väga, vägev, hääl, sest, täpid, pääl, äiutab, sind, siis, magama
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Ää; Ä-L ON VÄGA VÄGEV HÄÄL,​SEST ET TAL ON TÄPID PÄÄL.​ÄIUTAB SIND ÄIU-ÄÄ,​SIIS KUI MAGAMA EI JÄÄ.; PÜHAPÄEV; OLIVER OSKAB; HÄÄLDA JA VÕRDLE; HARJUTUS 1; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Üü
URL: https://www.opiq.ee/kit/79/chapter/3906
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.25
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, ükskord, üsna, üksi, rüüpas, teed, näsis, küpsist, mõtles, sõpru, külla, hüüaks, siis, rõõmsam, süüa
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Üü; Ü JÄI ÜKSKORD ÜSNA ÜKSI.​RÜÜPAS TEED JA NÄSIS KÜPSIST.​MÕTLES: „SÕPRU KÜLLA HÜÜAKS,​SIIS ON RÕÕMSAM KÜPSIST SÜÜA.“; TÜLI; KUIDAS TÜLI LAHENEB?; HÄÄLDA JA VÕRDLE; HARJUTUS 1; HARJUTUS 2A; HARJUTUS 2B; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Vv
URL: https://www.opiq.ee/kit/79/chapter/3907
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.26
Topics ET: matemaatika, kordamine, korda, harjutan, öötaevas, võimas, värvidemäng, veepeeglis, helgivad, külalised, vita, meenu, veel, säng, kohal, vilguvad, virmalised, sõnaseletus, põhjavalgus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Vv; ÖÖTAEVAS VÕIMAS VÄRVIDEMÄNG, ​VEEPEEGLIS HELGIVAD KÜLALISED.EI HU​VITA UNI, EI MEENU VEEL SÄNG, KUI ​PEA KOHAL VILGUVAD VIRMALISED.[sõnaseletus: VIRMALISED – PÕHJAVALGUS, VÄRVILINE HELENDUS ÖISES TAEVAS]; VIRMALISED; ÖINE TAEVAS; HARJUTAN; HARJUTUS 1; MIS SÕNA SAAD?; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Pp
URL: https://www.opiq.ee/kit/79/chapter/3908
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.27
Topics ET: matemaatika, kordamine, korda, harjutan, peeter, pani, prillid, ette, paistis, peeglist, päris, tark, enam, koolitöid, teinud, olla, puupeade, värk
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Pp; PEETER PANI PRILLID ETTE,​PAISTIS PEEGLIST PÄRIS TARK.​ENAM KOOLITÖID EI TEINUD –​OLLA SEE PUUPEADE VÄRK.; PIDU; PIDULIK HETK; HARJUTAN; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Bb
URL: https://www.opiq.ee/kit/79/chapter/3909
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.28
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, aeg, kell, kalender, kordamine, korda, harjutan, arvutas, juba, väikseks, jääb, perel, tuba, oleks, vist, anda, luba, süüa, valmis
Topics RU: математика, сравнение, сравни, больше, меньше, время, часы, календарь, повторение, повтори, тренировка
Topics EN: mathematics, comparison, compare, greater, less, time, clock, calendar, revision, review, practice
Headings: Bb; UBA ARVUTAS, ET JUBA​VÄIKSEKS JÄÄB TA PEREL TUBA.​OLEKS AEG VIST ANDA LUBA​ÄRA SÜÜA VALMIS UBA.; VANAEMA SÜNNIPÄEV; KONTSERT; LOE JA VALI ÕIGE VASTUS.; HÄÄLDA JA VÕRDLE; HARJUTAN; HARJUTUS 1; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## B, P, PP
URL: https://www.opiq.ee/kit/79/chapter/3910
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.29
Topics ET: matemaatika, kordamine, korda, harjutan, retk, rappa, saabas, eksib, teelt, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: B, P, PP; RETK RAPPA; SAABAS EKSIB TEELT; HARJUTAN; HARJUTUS 1A; HARJUTUS 1B

## Aa. TÄHT JA HÄÄLIK
URL: https://www.opiq.ee/kit/79/chapter/3884
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.3
Topics ET: matemaatika, kordamine, korda, harjutan, täht, häälik, pinginaabrid, kertu, soov, jätan, meelde, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Aa. TÄHT JA HÄÄLIK; TÄHT JA HÄÄLIK; PINGINAABRID; KERTU SOOV; JÄTAN MEELDE; HARJUTAN; HARJUTUS 1; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Hh
URL: https://www.opiq.ee/kit/79/chapter/3911
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.30
Topics ET: matemaatika, kordamine, korda, harjutan, lõbus, täht, hommikuti, itsitab, õhtul, naeru, kõkutab, helkur, nagu
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Hh; HIH-HII, HEH-HEE, HAH-HAA –​ÜKS LÕBUS TÄHT ON H.​TA HOMMIKUTI ITSITAB​JA ÕHTUL NAERU KÕKUTAB.; HELKUR; OTT NAGU JÕULUPUU; HARJUTAN; HARJUTUS 1; HARJUTUS 2B; HARJUTUS 2A; HARJUTUS 3; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Jj
URL: https://www.opiq.ee/kit/79/chapter/3912
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.31
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan, jänkuke, läks, juuksurisse, paljaks, pügas, endal, selja, käpad, paljalt, joosta
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice
Headings: Jj; JÄNKUKE LÄKS JUUKSURISSE,​PALJAKS PÜGAS ENDAL PEA,​PALJAKS SELJA, PALJAKS KÄPAD –​PALJALT JOOSTA ON JU HEA.; JUUKSURIMÄNG; KERTU SOENG; HARJUTAN; HARJUTUS 1; LOE JA VÕRDLE.; LÕPETA LAUSE.; HARJUTUS 2; HARJUTUS 3; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## I ja J
URL: https://www.opiq.ee/kit/79/chapter/3913
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.32
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan, vapper, põder, metsloomad, siimu, aias, häälda, harjutus
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice
Headings: I ja J; VAPPER PÕDER; METSLOOMAD SIIMU AIAS; HÄÄLDA JA VÕRDLE; HARJUTAN; HARJUTUS 1; HARJUTUS 2

## Z, Ž
URL: https://www.opiq.ee/kit/79/chapter/3914
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.33
Topics ET: matemaatika, kordamine, korda, harjutan, lembitu, žiguli, garaažis, harjutus, kirjutan, kiri, sidumata
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Z, Ž; LEMBITU ŽIGULI; GARAAŽIS; HARJUTAN; HARJUTUS 1; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## F, W, X, Y
URL: https://www.opiq.ee/kit/79/chapter/3915
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.34
Topics ET: matemaatika, kordamine, korda, harjutan, mardilaat, segadus, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: F, W, X, Y; MARDILAAT; SEGADUS; HARJUTAN; HARJUTUS 1

## C, Š, Q
URL: https://www.opiq.ee/kit/79/chapter/3916
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.35
Topics ET: matemaatika, kordamine, korda, harjutan, klassiõhtu, ettevalmistused, lahenda, salakiri, pildil, millise, ukse, taga
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: C, Š, Q; KLASSIÕHTU; ETTEVALMISTUSED; HARJUTAN; 3. LAHENDA SALAKIRI.; 1. KES ON PILDIL?; 2. MILLISE UKSE TAGA ASUB TUALETT?; HARJUTUS 1

## Peitus
URL: https://www.opiq.ee/kit/79/chapter/3917
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.36
Topics ET: matemaatika, kordamine, korda, harjutan, peitus, kummaline, kast, täishäälikute, laegas, salajane, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: Peitus; Kummaline kast; TÄISHÄÄLIKUTE LAEGAS. SALAJANE; HARJUTAN; Harjutus 1

## Suur avastus
URL: https://www.opiq.ee/kit/79/chapter/3918
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.37
Topics ET: matemaatika, suur, avastus, täishäälikute, laegas, punane, album, tähed, sõna, lõpust
Topics RU: математика
Topics EN: mathematics
Headings: Suur avastus; Täishäälikute laegas; PUNANE ALBUM; TÄHED SÕNA LÕPUST; Kaashäälikute laegas; Veel kaks albumit; ROHELINE ALBUM; SININE ALBUM

## Tarkade klubi
URL: https://www.opiq.ee/kit/79/chapter/3919
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.38
Topics ET: matemaatika, tarkade, klubi, tere, tulemast, klubisse
Topics RU: математика
Topics EN: mathematics
Headings: Tarkade klubi; Tere tulemast klubisse!

## SADA SAIA. A JA AA. PIKK JA LÜHIKE HÄÄLIK
URL: https://www.opiq.ee/kit/79/chapter/3885
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.4
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan, sada, saia, pikk, lühike, häälik, pagaripoes, viis, moosipalli, jätan
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice
Headings: SADA SAIA. A JA AA. PIKK JA LÜHIKE HÄÄLIK; PAGARIPOES; VIIS MOOSIPALLI; JÄTAN MEELDE; • LOE JA VÕRDLE.; HARJUTAN; HARJUTUS 1; HARJUTUS 2

## Ii
URL: https://www.opiq.ee/kit/79/chapter/3886
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.5
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan, liivaloss, liivakastis, häälda, harjutus, kirjutan, kiri, sidumata
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice
Headings: Ii; LIIVALOSS; LIIVAKASTIS; HÄÄLDA JA VÕRDLE; HARJUTAN; HARJUTUS 1A; HARJUTUS 1B; HARJUTUS 2; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Ee
URL: https://www.opiq.ee/kit/79/chapter/3887
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.6
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, seenel, kahtlane, seen, häälda, harjutus, kirjutan, kiri, sidumata
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Ee; SEENEL; KAHTLANE SEEN; HÄÄLDA JA VÕRDLE; HARJUTUS 1; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## E, A, I
URL: https://www.opiq.ee/kit/79/chapter/3888
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.7
Topics ET: matemaatika, kordamine, korda, harjutan, õuetund, liikuvad, lehed, jätan, meelde, harjutus
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: E, A, I; ÕUETUND; LIIKUVAD LEHED; JÄTAN MEELDE; HARJUTAN; HARJUTUS 1

## Ll
URL: https://www.opiq.ee/kit/79/chapter/3889
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.8
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, kordamine, korda, harjutan, kole, hirm, häälda, harjutus, kirjutan, kiri, sidumata
Topics RU: математика, сравнение, сравни, больше, меньше, повторение, повтори, тренировка
Topics EN: mathematics, comparison, compare, greater, less, revision, review, practice
Headings: Ll; KOLE ILM; HIRM; HÄÄLDA JA VÕRDLE; HARJUTUS 1; HARJUTAN; HARJUTUS 2A; HARJUTUS 2B; HARJUTUS 3; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Mm
URL: https://www.opiq.ee/kit/79/chapter/3890
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 1.9
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, mädamuna, imelik, nimi, jätan, meelde, sõnu, saab, jagada, silpideks
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: Mm; MÄDAMUNA; IMELIK NIMI; JÄTAN MEELDE; • LOE.; SÕNU SAAB JAGADA SILPIDEKS.; HARJUTUS 1; HÄÄLDA JA VÕRDLE; KIRJUTAN; SEOTUD KIRI; SIDUMATA KIRI

## Sõnaseletused
URL: https://www.opiq.ee/kit/79/chapter/3920
Book: NII SEE ALGAB
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_avita_est
Chapter ID: 2.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## AABITS. 1. klassi eesti keel – Opiq
URL: https://www.opiq.ee/Kit/Details/558
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 202
Topics ET: matemaatika, aabits, klassi, eesti, keel, opiq
Topics RU: математика
Topics EN: mathematics

## TÄHESTIK
URL: https://www.opiq.ee/kit/558/chapter/31377
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.1
Topics ET: matemaatika, tähestik
Topics RU: математика
Topics EN: mathematics
Headings: TÄHESTIK

## KES PÄÄSTAB MAAILMA?
URL: https://www.opiq.ee/kit/558/chapter/31378
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.2
Topics ET: matemaatika, päästab, maailma
Topics RU: математика
Topics EN: mathematics
Headings: KES PÄÄSTAB MAAILMA?

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31379
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.3
Topics ET: matemaatika, mida, sellel, nädalal, teeme, klassis, järgmistes, tundides, sõlmime, klassi
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; KLASSIS; JÄRGMISTES TUNDIDES; • SÕLMIME KLASSI KOKKULEPPED; • SAAME OMAVAHEL TUTTAVAKS; • HARJUTAME A-, E- JA I-TÄHTE; • SELGITAME, MIS ON TÄHT JA MIS ON HÄÄLIK; • MIS PILDIL TOIMUB?; • MIS PANEB SIND NII ARVAMA?; • MIDA TAHAKSID VEEL PILDI KOHTA ÖELDA?

## SALAPÄRASED JÄLJED. AKTUS, FÄNNID JA NOOR VÕLUR
URL: https://www.opiq.ee/kit/558/chapter/31380
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.4
Topics ET: matemaatika, salapärased, jäljed, aktus, fännid, noor, võlur, ajab, pesema, kaob
Topics RU: математика
Topics EN: mathematics
Headings: SALAPÄRASED JÄLJED. AKTUS, FÄNNID JA NOOR VÕLUR; EMA AJAB ISA PESEMA. ​ISA KAOB VANNITUPPA. ​SEALT KOSTAB URINAT. ​PIIA VIIB ISALE TASSI KOHVI. ​SEE RÕÕMUSTAB ISA. ​PIIA ON JUBA VALMIS JA OOTAB.; • MILLINE TEGEVUS ON PILDIL? RÄÄGI.; • MIS ON KLASSIS SOBILIK?; • LOE ÜHE KLASSI KOKKULEPPEID.; • MISSUGUSED ON SINU KLASSI KOKKULEPPED?; • KAS TAHAKSID MIDAGI LISADA?; ● MILLISE KOKKULEPPE TÄITMINE ON SUL TÄNA JUBA HÄSTI VÄLJA TULNUD?; ● RIPUTAGE KOKKULEPPED KA KLASSI SEINALE.

## KOOGID, PUUDEL JA PRANTSUSE MEES
URL: https://www.opiq.ee/kit/558/chapter/31373
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.5
Topics ET: matemaatika, koogid, puudel, prantsuse, mees, kaunista, värvi, pildiraam, leia, pildilt
Topics RU: математика
Topics EN: mathematics
Headings: KOOGID, PUUDEL JA PRANTSUSE MEES; • KAUNISTA JA VÄRVI PILDIRAAM.; • LEIA PILDILT 10 AABITSAT.; • TUTVUSTA ENNAST. TÄIDA LÜNGAD.; TUTVUSTA ENNAST.; • MIDA VÕIKS TEHA KLASSI HOMMIKURINGIS?; • ARUTLEGE KLASSIS. MILLINE TEGEVUS ON PUUDU?

## TÄHELEPANU, VALMIS, START!
URL: https://www.opiq.ee/kit/558/chapter/31374
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.6
Topics ET: matemaatika, tähelepanu, valmis, start, tarkus, tuleb, tasapisi, aster, aken, aabits
Topics RU: математика
Topics EN: mathematics
Headings: TÄHELEPANU, VALMIS, START!; TARKUS TULEB TASAPISI; ASTER​AKEN​AABITS; KAPP​KLASS​VAAS; ANNA​ÕPETAJA LAURA​AASTA; 1. KELLE NIMES ON A?; 2. KIRJUTA PUUDUV TÄHT.; 3B. MILLISED HUVID LASTEL ON?; 3A. MILLISED HUVID LASTEL ON?

## KARVANE ÜLLATUS
URL: https://www.opiq.ee/kit/558/chapter/31375
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.7
Topics ET: matemaatika, karvane, üllatus, heal, tööl, käib, kasu, kannul, ilves, iiris
Topics RU: математика
Topics EN: mathematics
Headings: KARVANE ÜLLATUS; HEAL TÖÖL KÄIB KASU KANNUL; ISA ​ILVES ​IIRIS; SILM​AABITS​HIIR; VÕTI​HARI​NAGI; KAPIST KOSTAB PORIN. ​SIIS ILMUB KAPIST VÄLJA PISIKE ELUKAS. NIISUGUST POLE LAPSED VEEL IIALGI NÄINUD.; 4. MILLISED TÄHED ON KORRAPIDAJA ÄRA KUSTUTANUD?; 5. MILLISES SÕNAS EI OLE I-TÄHTE?; 6C. MITU HÄÄLIKUT ON SÕNAS?; 6A. MITU HÄÄLIKUT ON SÕNAS?; 6B. MITU HÄÄLIKUT ON SÕNAS?

## EKSEMPLAR NUMBER 186 (I)
URL: https://www.opiq.ee/kit/558/chapter/31376
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.8
Topics ET: matemaatika, arv, arvud, arvu, numbrid, aeg, kell, kalender, raha, euro, sent, eksemplar, sööbik, teeb, sääred, elukas, eesti, keel
Topics RU: математика, число, числа, цифры, время, часы, календарь, деньги, евро, цент
Topics EN: mathematics, number, numbers, digits, time, clock, calendar, money, euro, cent
Headings: EKSEMPLAR NUMBER 186 (I); SÖÖBIK TEEB SÄÄRED; EURO​ELUKAS​EESTI KEEL; KELL​KÄED​LEIB; KARVANE​TEE​TEGELANE; 7. KLASSIS ON VEEL KEEGI. KES?; 8C. MILLISED SÕNAD KÕLAVAD SARNASELT?; 8A. MIS ON PILDIL?; 8B. MIS SÕNADES ON E-TÄHT?; 9. MITU TÄHTE JA MITU HÄÄLIKUT ON SÕNAS.

## EKSEMPLAR NUMBER 186 (II)
URL: https://www.opiq.ee/kit/558/chapter/31381
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 1.9
Topics ET: matemaatika, arv, arvud, arvu, numbrid, eksemplar, lapsed, neelasid, keele, alla
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: EKSEMPLAR NUMBER 186 (II); LAPSED NEELASID KEELE ALLA

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31425
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 10.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, looduses, järgmistes, tundides, jutustame, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; LOODUSES; JÄRGMISTES TUNDIDES; • jutustame, kuidas loodusele head teha; • õpime tundma Eesti rahvuslooma; • kordame liitsõnu; • loeme tähestikku; • kirjutame lause lõppu sobiva märgi (.!?); • Mis sellel pildil toimub?; • Mis paneb sind nii arvama?; • Milliseid taimi ja loomi sellel pildil näed?

## ISADEPÄEVA ÖÖMATK (I)
URL: https://www.opiq.ee/kit/558/chapter/31422
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 10.2
Topics ET: matemaatika, isadepäeva, öömatk, süda, laste, küljes, kirjuta, puuduvad, tähed, mida
Topics RU: математика
Topics EN: mathematics
Headings: ISADEPÄEVA ÖÖMATK (I); ISA SÜDA LASTE KÜLJES; 104. Kirjuta puuduvad tähed.; 105. Mida läheb matkal vaja?; 106. Milliseid loomi on võimalik looduses kohata?; 107. Ühenda ühesugused laused.; 108. Pane lause lõppu punkt.

## ISADEPÄEVA ÖÖMATK (II)
URL: https://www.opiq.ee/kit/558/chapter/31426
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 10.3
Topics ET: matemaatika, isadepäeva, öömatk, raiub, puid, ilma, kirveta
Topics RU: математика
Topics EN: mathematics
Headings: ISADEPÄEVA ÖÖMATK (II); KES RAIUB PUID ILMA KIRVETA?

## TOIDUJAGAMISE PÄEV (I)
URL: https://www.opiq.ee/kit/558/chapter/31423
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 10.4
Topics ET: matemaatika, liitmine, liida, summa, kokku, toidujagamise, päev, mõnel, perel, kitsas, käes, liisa, lotta, tõstab
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: TOIDUJAGAMISE PÄEV (I); MÕNEL PEREL ON KITSAS KÄES; LIISA-LOTTA EMA TÕSTAB IGASSE KASTI KILO APELSINE. ​LAPSED AITAVAD PAKKE KOKKU PANNA. ​TÄNU NEILE SAAB MITUSADA PERET KÕHU TÄIS. ​MÕNEL LAPSEL ON KODUS KAPP TÜHI. ​MÕNED LAPSED SAAVAD PUUVILJU HARVA. ​MÕNES KOHAS VISATAKSE TOITU ÄRA. ​SEAL ON TOITU ÜLE.; 109. Ühenda küsimus ja vastus.; 110. Mis sobib kasti panna?; 111. Kirjuta lause lõppu hüüumärk.; 112. Mida kõike võiks panna pitsa peale?

## TOIDUJAGAMISE PÄEV (II)
URL: https://www.opiq.ee/kit/558/chapter/31424
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 10.5
Topics ET: matemaatika, toidujagamise, päev, kellel, nälg, sellel, jalg, prügi, sorteerimine, täht
Topics RU: математика
Topics EN: mathematics
Headings: TOIDUJAGAMISE PÄEV (II); KELLEL NÄLG, SELLEL JALG; 113B. Prügi sorteerimine; 113A. Mis täht on prügikastil puudu?; 114. Suured ja väikesed tähed

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31431
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 11.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, sünnipäeval, järgmistes, tundides, räägime, ndmuste
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; SÜNNIPÄEVAL; JÄRGMISTES TUNDIDES; • räägime sündmuste tähistamisest; • nimetame erinevaid tähtpäevi; • uurime kalendrit; • vastame teksti põhjal küsimustele; • kordame ainsust ja mitmust; • Mis on pildil?; • Mis paneb sind nii arvama?; • Mis on pildilt puudu?

## KADRIPÄEVA KINGITUS (I)
URL: https://www.opiq.ee/kit/558/chapter/31427
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 11.2
Topics ET: matemaatika, kadripäeva, kingitus, mart, kadri, karja, ainsus, mitmus, millise, tordi
Topics RU: математика
Topics EN: mathematics
Headings: KADRIPÄEVA KINGITUS (I); MART ON ÜLE MAA, KADRI ÜLE KARJA; 115. Ainsus või mitmus?; 116. Millise tordi mamma küpsetas?; 117. Mitu päeva on aastas?; 118. Sünnipäev on tore päev; 119. Leia tähereast rahvakalendri tähtpäevad.

## KADRIPÄEVA KINGITUS (II)
URL: https://www.opiq.ee/kit/558/chapter/31428
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 11.3
Topics ET: matemaatika, kadripäeva, kingitus, habe, kuid, pole, mees, sarved, lehm, nädalapäevad
Topics RU: математика
Topics EN: mathematics
Headings: KADRIPÄEVA KINGITUS (II); HABE EES, KUID POLE MEES, SARVED ON, KUID POLE LEHM?; 120. Nädalapäevad; 121. Kuupäevad; 122. Kas tunned tähtpäevi?; 123. Lahenda ristsõna.

## KAAMERA JA AABITSAD (I)
URL: https://www.opiq.ee/kit/558/chapter/31429
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 11.4
Topics ET: matemaatika, kaamera, aabitsad, inimesi, tuntakse, nende, tegudest, lastas, novembris, klassi
Topics RU: математика
Topics EN: mathematics
Headings: KAAMERA JA AABITSAD (I); INIMESI TUNTAKSE NENDE TEGUDEST; 124. Kes külastas novembris 1.a klassi? Mis juhtus?; 125. Vali õige lauselõpp.

## KAAMERA JA AABITSAD (II)
URL: https://www.opiq.ee/kit/558/chapter/31430
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 11.5
Topics ET: matemaatika, kaamera, aabitsad, susi, sind, söögu, kuidas, mitu, moodusta, laused
Topics RU: математика
Topics EN: mathematics
Headings: KAAMERA JA AABITSAD (II); SUSI SIND SÖÖGU!; 126. Kuidas on üks, kuidas mitu?; 127. Moodusta laused.

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31436
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 12.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, raamatukogus, järgmistes, tundides, räägime, lugemisharjumustest
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; RAAMATUKOGUS; JÄRGMISTES TUNDIDES; • räägime lugemisharjumustest; • saame tuttavaks mõne Eesti lastekirjanikuga; • uurime täis- ja kaashäälikuid; • otsime riimuvaid sõnu; • kordame sõnu, mille lõpus on -b või -vad; • Mis on pildil?; • Mis paneb sind nii arvama?; • Mida sa veel soovid pildi kohta öelda?

## SUUR PÄÄSTEPLAAN (I)
URL: https://www.opiq.ee/kit/558/chapter/31432
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 12.2
Topics ET: matemaatika, suur, päästeplaan, kahe, silma, vahele, vasta, simusele, lapsed, proovinud
Topics RU: математика
Topics EN: mathematics
Headings: SUUR PÄÄSTEPLAAN (I); JÄI KAHE SILMA VAHELE; 128. Vasta küsimusele.; 129. Kus on lapsed proovinud Sööbikule kodu leida?; 130. Kirjuta pildi juurde, mida Sööbik tunneb.

## SUUR PÄÄSTEPLAAN (II)
URL: https://www.opiq.ee/kit/558/chapter/31433
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 12.3
Topics ET: matemaatika, võrdlemine, võrdle, suurem, väiksem, suur, päästeplaan, häda, kõige, seal, lähem, tunned, eesti
Topics RU: математика, сравнение, сравни, больше, меньше
Topics EN: mathematics, comparison, compare, greater, less
Headings: SUUR PÄÄSTEPLAAN (II); KUS HÄDA KÕIGE SUUREM, SEAL ABI KÕIGE LÄHEM; 131. Kas tunned Eesti lastekirjanikke?; 132. Milliseid sõnu võiks Laura vennal kodus olla?; 133. Lõpeta lause.; 134. Kuidas sul lugemisega läheb?; 135. Millised raamatud on sellel raamaturiiulil?; 136. Plaaditäis sõnu; 137. Loe sõnu ja ütle, mis on pildil.

## VEEL ÜKS OOTAMATU KOHTUMINE (I)
URL: https://www.opiq.ee/kit/558/chapter/31434
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 12.4
Topics ET: matemaatika, veel, ootamatu, kohtumine, lapsed, murest, murtud, moodusta, laused, kirjuta
Topics RU: математика
Topics EN: mathematics
Headings: VEEL ÜKS OOTAMATU KOHTUMINE (I); LAPSED ON MUREST MURTUD; 138. Moodusta laused.; 139. Kirjuta -b või -vad.

## VEEL ÜKS OOTAMATU KOHTUMINE (II)
URL: https://www.opiq.ee/kit/558/chapter/31435
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 12.5
Topics ET: matemaatika, veel, ootamatu, kohtumine, ilma, ulatab, ümber, ulata, räppari, töövahendiks
Topics RU: математика
Topics EN: mathematics
Headings: VEEL ÜKS OOTAMATU KOHTUMINE (II); ÜLE ILMA ULATAB, ÜMBER PEA EI ULATA?; 140. Räppari töövahendiks on sõnad ja riimid.; 141. Kuidas leida riime?

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31440
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 13.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, sõbra, juures, järgmistes, tundides, leiame
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; SÕBRA JUURES; JÄRGMISTES TUNDIDES; • leiame sarnasusi ja erinevusi oma kaaslastega; • selgitame, kes on hea sõber ja kaaslane; • otsime sõnades täishäälikuühendeid; • vastame teksti põhjal küsimustele; • Millest see pilt kõneleb?; • Mis paneb sind nii arvama?; • Milline vanasõna sulle meeldib?

## VANAD SÕBRAD JA UUED SÕBRAD (I)
URL: https://www.opiq.ee/kit/558/chapter/31437
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 13.2
Topics ET: matemaatika, vanad, sõbrad, uued, õige, sõber, enam, kuld, tunned, klassikaaslasi
Topics RU: математика
Topics EN: mathematics
Headings: VANAD SÕBRAD JA UUED SÕBRAD (I); ÕIGE SÕBER ON ENAM KUI KULD; 142. Kas tunned oma klassikaaslasi hästi?; 143. Moodusta etteantud tähtedest sõnu.; 144. Täishäälikuühend; 145. Mis on sul klassikaaslasega sarnane, mis on erinev?; 146. Mis värvi on su klassikaaslaste silmad?

## VANAD SÕBRAD JA UUED SÕBRAD (II)
URL: https://www.opiq.ee/kit/558/chapter/31438
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 13.3
Topics ET: matemaatika, vanad, sõbrad, uued, valel, saba, taga, leia, tähtedest, sõna
Topics RU: математика
Topics EN: mathematics
Headings: VANAD SÕBRAD JA UUED SÕBRAD (II); VALEL ON SABA TAGA; 147. Leia tähtedest sõna.; 148. Kukimukil oli stuudios palju sõnu.

## POMMUUDIS (I)
URL: https://www.opiq.ee/kit/558/chapter/31441
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 13.4
Topics ET: matemaatika, pommuudis, uudis, levis, nagu, kulutuli
Topics RU: математика
Topics EN: mathematics
Headings: POMMUUDIS (I); UUDIS LEVIS NAGU KULUTULI

## POMMUUDIS (II)
URL: https://www.opiq.ee/kit/558/chapter/31439
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 13.5
Topics ET: matemaatika, pommuudis, sobivad, nagu, sukk, saabas, märgi, õige, vastus, kukimuki
Topics RU: математика
Topics EN: mathematics
Headings: POMMUUDIS (II); NAD SOBIVAD NAGU SUKK JA SAABAS; 149. Märgi õige vastus.; 150. Mis on Kukimuki köögikapis?; 151. Milliseid toidusõnu himustas Sööbik?; 152. Kirjuta jutumullidesse, mida võiksid Sõnasööbik ja Kukimuki omavahel arutada.

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31445
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 14.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, enne, jõule, järgmistes, tundides, jutustame
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; ENNE JÕULE; JÄRGMISTES TUNDIDES; • jutustame oma pere jõulutraditsioonidest; • õpime tundma Eesti linnu; • otsime küsimusele tekstist vastuseid; • Millest see pilt kõneleb?; • Mis paneb sind nii arvama?; • Mis võiks pildil veel olla?

## KONTSERT JA KIRI (I)
URL: https://www.opiq.ee/kit/558/chapter/31442
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 14.2
Topics ET: matemaatika, kontsert, kiri, sööbik, kaob, tina, tuhka, mida, teel, sinu
Topics RU: математика
Topics EN: mathematics
Headings: KONTSERT JA KIRI (I); SÖÖBIK KAOB KUI TINA TUHKA; 153. Mida teel sinu pere jõulukuul?; 154. Leia jõuludega seotud sõnad; 155. Mis on peidus nendes kingipakkides?; 156. Kuidas jõuavad pakid lasteni?; 157. Joonista töövihikusse oma kingisoov.

## KONTSERT JA KIRI (II)
URL: https://www.opiq.ee/kit/558/chapter/31446
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 14.3
Topics ET: matemaatika, kontsert, kiri, lõpp, kõik
Topics RU: математика
Topics EN: mathematics
Headings: KONTSERT JA KIRI (II); LÕPP HEA, KÕIK HEA

## KONTSERT JA KIRI (III)
URL: https://www.opiq.ee/kit/558/chapter/31443
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 14.4
Topics ET: matemaatika, kontsert, kiri, ühenduses, peitub, jõud, lauselõpumärgid, õige, vale, lause
Topics RU: математика
Topics EN: mathematics
Headings: KONTSERT JA KIRI (III); ÜHENDUSES PEITUB JÕUD; 158. Lauselõpumärgid; 159. Kas õige või vale?; 160. Tee lause esimene täht ja lõpumärk töövihikus värviliseks.

## ON VIIMANE PÄEV ENNE JÕULUPÜHI
URL: https://www.opiq.ee/kit/558/chapter/31444
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 14.5
Topics ET: matemaatika, liitmine, liida, summa, kokku, viimane, päev, enne, jõulupühi, värvi, töövihikus, juhendi, järgi, olid
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: ON VIIMANE PÄEV ENNE JÕULUPÜHI; 161. Värvi töövihikus juhendi järgi.; 162. Kus olid Kukimukil kontserdid?; 163. Kes on kes?; 164. Sama tähendusega väljendid; 165. Vali lausesse sobiv sõna.; 166. Järjesta sõnad nii, et saad kokku vanasõna.; 167. Vanasõnad; 168. Mõistata.; 169. Ühenda töövihikus tähed tähestiku järjekorras.; 170. Kirjuta jõuluvanale kiri.; BINGO

## JÕULULUULETUSED
URL: https://www.opiq.ee/kit/558/chapter/31447
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 14.6
Topics ET: matemaatika, jõululuuletused, piia, jõululuuletus, anna, aleksi, liisa, lota, markuse
Topics RU: математика
Topics EN: mathematics
Headings: JÕULULUULETUSED; PIIA JÕULULUULETUS; UKU JÕULULUULETUS; ANNA JÕULULUULETUS; ALEKSI JÕULULUULETUS; LIISA-LOTA JÕULULUULETUS; MARKUSE JÕULULUULETUS

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31385
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 2.1
Topics ET: matemaatika, lahutamine, lahuta, vahe, mida, sellel, nädalal, teeme, köögis, järgmistes, tundides, nimetame, mitmesuguseid
Topics RU: математика, вычитание, вычти, разность
Topics EN: mathematics, subtraction, subtract, difference
Headings: MIDA ME SELLEL NÄDALAL TEEME?; KÖÖGIS; JÄRGMISTES TUNDIDES; • NIMETAME MITMESUGUSEID TOITE; • JUTUSTAME OMA SÖÖMISHARJUMUSTEST; • HARJUTAME N-, M- JA L-TÄHTE; • ARUTAME, MIS VAHE ON SILBIL, SÕNAL, LAUSEL; • MOODUSTAME SILPIDEST SÕNU; • MILLISED TOIDUAINED ON PILDIL?; • MIS VÕIKS PILDIL VEEL OLLA?; • MIDA TAHAKSID VEEL PILDI KOHTA ÖELDA?

## KOOGID, KANAD JA БOРЩ
URL: https://www.opiq.ee/kit/558/chapter/31382
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: ru
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 2.2
Topics ET: matemaatika, koogid, kanad, tühi, kõht, kõige, parem, kokk, näitleja
Topics RU: математика
Topics EN: mathematics
Headings: KOOGID, KANAD JA БOРЩ; TÜHI KÕHT ON KÕIGE PAREM KOKK; NÄITLEJA​NALI​NUPP; HERNES​KANA​MANNA; SEEN​APELSIN​PANN; ISA VAATAB, ​MIDA PIIA KÖÖGIS TEEB.​PIIA LAOB SÕNU LAUALE.​ISA TAHAB PANNKOOKE. ​​NÄMM-NÄMM! TA ON MAIAS​.; 10B. LEIA VASTUSED.; 10A. MILLISTES SÕNADES ON N-TÄHT?; 11C. MIDA ON VAJA, ET TEHA PANNKOOKE?; 11A. MIS ON PILDIL?; 11B. MITU TÄHTE ON SÕNAS?; 12. KUIDAS TEHA BANAANIPANNKOOKE?

## SALAPÄRANE KAST (I)
URL: https://www.opiq.ee/kit/558/chapter/31383
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 2.3
Topics ET: matemaatika, taim, taimed, puu, lill, salapärane, kast, austa, leiba, leib, vanem, meie, mesi, mustikas
Topics RU: математика, растение, растения, дерево, цветок
Topics EN: mathematics, plant, plants, tree, flower
Headings: SALAPÄRANE KAST (I); AUSTA LEIBA, LEIB ON VANEM KUI MEIE; MESI​MUSTIKAS​MAASIKAS; PELMEEN​EMAKEEL​HOMMIK; KOHUPIIM​KREEM​KOMM; 13B. M KÕLAB PIKALT.; 13A. MIS ON PILDIL? HÄÄLI.; 14. PUU- JA KÖÖGIVILJAD.; 15. LOE JA VASTA.; 16. HÄÄLIK, TÄHT, SÕNA JA LAUSE.

## SALAPÄRANE KAST (II)
URL: https://www.opiq.ee/kit/558/chapter/31384
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 2.4
Topics ET: matemaatika, aeg, kell, kalender, salapärane, kast, sööbik, laseb, leiba, luusse, leib, laupäev, liisa
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: SALAPÄRANE KAST (II); SÖÖBIK LASEB LEIBA LUUSSE; LEIB​LAUPÄEV​LIISA-LOTTA; SILM​KLASS​NELI; NÄDAL​MOOSIPALL​KELL; 17. MIDA SÜÜA LÕUNA- VÕI ÕHTUSÖÖGIKS?; 18. MIDA LÄHEB KOKAL VAJA?; 19. LOE IGA SÕNA ESIMENE TÄHT. MILLISE SOOVI SAAD?

## SÖÖBIK SÖÖBIKUTE HÕIMKONNAST
URL: https://www.opiq.ee/kit/558/chapter/31386
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 2.5
Topics ET: matemaatika, sööbik, sööbikute, hõimkonnast, silm, kuningas
Topics RU: математика
Topics EN: mathematics
Headings: SÖÖBIK SÖÖBIKUTE HÕIMKONNAST; OMA SILM ON KUNINGAS

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31390
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 3.1
Topics ET: matemaatika, jagamine, jaga, jagatis, pool, mida, sellel, nädalal, teeme, kooli, koduteel, järgmistes, tundides, näitame
Topics RU: математика, деление, раздели, частное, половина
Topics EN: mathematics, division, divide, quotient, half
Headings: MIDA ME SELLEL NÄDALAL TEEME?; KOOLI- JA KODUTEEL; JÄRGMISTES TUNDIDES; • NÄITAME, KUS ON PAREM JA KUS VASAK POOL; • SELGITAME, KUIDAS OHUTULT KOOLI JÕUDA; • HARJUTAME O-, Õ- JA Ö-TÄHTE; • NIMETAME TÄISHÄÄLIKUID; • VALIME SÕNASSE ÜHE VÕI KAKS TÄHTE; • MIS PILDIL TOIMUB?; • MIS PANEB SIND NII ARVAMA?; • MIDA TAHAKSID VEEL PILDI KOHTA ÖELDA?

## LIISA-LOTTA VALVURID (I)
URL: https://www.opiq.ee/kit/558/chapter/31387
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 3.2
Topics ET: matemaatika, liisa, lotta, valvurid, kolm, prouat, karvupidi, koos, oktoober, orav
Topics RU: математика
Topics EN: mathematics
Headings: LIISA-LOTTA VALVURID (I); KOLM PROUAT ON KARVUPIDI KOOS; ONN​OKTOOBER​ORAV; KOLM PROUAT​KOKARAAMAT​KOOLIHOOV; KILO KOMME​KINO​AUTO; 20. LIISA-LOTTA KODUTEE; 21. VALI LAUSESSE ÕIGE SÕNA.; 22B. KIRJUTA ÕIGE SÕNA.; 22A. KIRJUTA KASTI ÕIGE SÕNA.

## LIISA-LOTTA VALVURID (II)
URL: https://www.opiq.ee/kit/558/chapter/31388
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 3.3
Topics ET: matemaatika, liisa, lotta, valvurid, vanaemad, peavad, sõnasõda, õhupall, õunakook, kõnnitee
Topics RU: математика
Topics EN: mathematics
Headings: LIISA-LOTTA VALVURID (II); VANAEMAD PEAVAD SÕNASÕDA; ÕHUPALL​ÕU​ÕUNAKOOK; KÕNNITEE​MÕRA​RÕÕMUS SÕBER; LÕUNASÖÖK​VÕILEIB​VÕÕRAS; 23. KUIDAS ÜLETADA TEED?; 24. O VÕI Õ?; 25. TEISED LIIKLEJAD; 26B. TEE SÕNAS TÄISHÄÄLIKUD PUNASEKS.; 26A. LEIA EELMISEST HARJUTUSEST SÕNA, MILLES ON Õ.; 27. KUIDAS OHUTULT TÕUKE- JA JALGRATTAGA SÕITA?

## KOLLID TEEL (I)
URL: https://www.opiq.ee/kit/558/chapter/31389
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 3.4
Topics ET: matemaatika, kollid, teel, hooletus, õnnetus, taga, ööpäev, öökull, ööbik, söökla
Topics RU: математика
Topics EN: mathematics
Headings: KOLLID TEEL (I); HOOLETUS EES, ÕNNETUS TAGA; ÖÖPÄEV​ÖÖKULL​ÖÖBIK; SÖÖKLA​VÖÖTRADA​KÖHA; KODUTÖÖ​TURVAVÖÖ​PÖÖRANE; 28. KAS TUNNED LIIKLUSMÄRKE?; 29B. MÕTLE LAUSEID, MIDA SAAB NENDE SÕNADEGA TEHA.; 29A. KIRJUTA LÜNKA Ö VÕI ÖÖ.; 30. SUUND

## KOLLID TEEL (II)
URL: https://www.opiq.ee/kit/558/chapter/31391
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 3.5
Topics ET: matemaatika, kollid, teel, parem, karta, kahetseda
Topics RU: математика
Topics EN: mathematics
Headings: KOLLID TEEL (II); PAREM KARTA KUI KAHETSEDA

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31395
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 4.1
Topics ET: matemaatika, lahutamine, lahuta, vahe, mida, sellel, nädalal, teeme, tööl, järgmistes, tundides, jutustame, erinevatest
Topics RU: математика, вычитание, вычти, разность
Topics EN: mathematics, subtraction, subtract, difference
Headings: MIDA ME SELLEL NÄDALAL TEEME?; TÖÖL; JÄRGMISTES TUNDIDES; • JUTUSTAME ERINEVATEST AMETITEST; • UNISTAME OMA TULEVIKUTÖÖST; • HARJUTAME R-, S-, U-TÄHTE; • TEEME SELGEKS, MIS VAHE ON TÄIS- JA KAASHÄÄLIKUL; • MIS PILDIL TOIMUB?; • MIS PANEB SIND NII ARVAMA?; • MIDA TAHAKSID VEEL PILDI KOHTA ÖELDA?

## KOOGID JA AMETID
URL: https://www.opiq.ee/kit/558/chapter/31392
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 4.2
Topics ET: matemaatika, koogid, ametid, tööd, teeb, rõõmu, näeb, rõõm, raamat, robot
Topics RU: математика
Topics EN: mathematics
Headings: KOOGID JA AMETID; KES TÖÖD TEEB, SEE RÕÕMU NÄEB; RÕÕM​RAAMAT​ROBOT; JOOKSUTRENN​PARIMAD PRÄÄNIKUD PRANTSUSMAA; HEA SÕBER​TRAKTOR​JALGRATTUR; PIIA PEAB ISA TÖÖ JUURDE RUTTAMA.​PAUL PRÄÄNIK ON AJAKIRJANIK.​TA KIRJUTAB SPORDIST.​PIIA KUTSUB SÕBRAD MEEDIAMAJJA KAASA.; 31. KES TÖÖTAVAD KOHVIKUS?; 32. MIS EI SOBI VEERGU?; 33. LEIA R-TÄHED.; 34. KAUNISTA TORDILÕIK TÖÖVIHIKUS.

## PAUL PRÄÄNIKU RASKE PÄEV (I)
URL: https://www.opiq.ee/kit/558/chapter/31393
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 4.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, paul, prääniku, raske, päev, võib, vahel, kaotada, soojad, sussid
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: PAUL PRÄÄNIKU RASKE PÄEV (I); ISA VÕIB VAHEL PEA KAOTADA; SOOJAD SUSSID​SÖÖB SÕNU​SOE SUVI; NÄOST ROOSA​PISIKE SÖÖBIK​MUST SEIN; TEETASS​SEITSMES ​KLASS; PIIA ISA TERVITAB LAPSI. ​​ANNA TEEB KNIKSU, ​​ALEKS TEEB VÄIKESE KUMMARDUSE.; 35. KELLEKS TAHAD SAADA?; 36. MIDA KEEGI TEEB?; 37. VALI LÜNKA ÕIGE SÕNA.; 38. KELLEL LÄHEB NEID ASJU TÖÖS VAJA?

## PAUL PRÄÄNIKU RASKE PÄEV (II)
URL: https://www.opiq.ee/kit/558/chapter/31396
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 4.4
Topics ET: matemaatika, paul, prääniku, raske, päev, amet, riku, meest
Topics RU: математика
Topics EN: mathematics
Headings: PAUL PRÄÄNIKU RASKE PÄEV (II); AMET EI RIKU MEEST

## LINNUVAATLEJAD
URL: https://www.opiq.ee/kit/558/chapter/31394
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 4.5
Topics ET: matemaatika, loodus, loodusõpetus, keskkond, loom, loomad, linnud, putukad, linnuvaatlejad, ootaja, õnge, tuleb, kala, arvuti, uhke, uudis, kaunis
Topics RU: математика, природа, природоведение, окружающая среда, животное, животные, птицы, насекомые
Topics EN: mathematics, nature, science, environment, animal, animals, birds, insects
Headings: LINNUVAATLEJAD; OOTAJA ÕNGE TULEB KALA; UUS ARVUTI​UHKE USS​UUDIS; KAUNIS LOODUS LINNUHUVILINE​PUTUKAD; SÜGISKUU​KASTANIPUU​KALALUU; UKU ISA TAHAB SARVIKPÜTIST PILTI TEHA. SARVIKPÜTT ON PUNAKA VÄRVUSEGA, PEANUPP ON KOLLANE.​TA ON TUBLI SUKELDUJA.; JÄRVEL TUKUB ÜKSIK PART.​LINNUHUVILISED ON KANNATLIKUD,​AGA LINNUD VIST TUDUVAD.​JÄRVE KALDAL SUMISEVAD PARMUD.​UKU JA EMA SÖÖVAD ÄRA JUUSTUSAIAD.​ISA SÖÖB ÄRA MUUD VÕILEIVAD.​LINNUD EI OLEGI KÕIGE OLULISEMAD.​KÕIGE OLULISEM ON ELADA HETKES.​ELU ON ILUS!; 39. KEDA KAITSEVAD UKU VANEMAD?; 40. MIDA LENDORAV SÖÖB?; 41. KUHU LENDORAV TOIDUVARUD PEIDAB?

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31400
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 5.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, kodus, järgmistes, tundides, jutustame, kodust
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; KODUS; JÄRGMISTES TUNDIDES; • JUTUSTAME OMA KODUST; • SELGITAME, KUIDAS OLLA TERVE; • HARJUTAME Ü-, Ä- JA P-TÄHTE; • TUNNEME ÄRA VASTANDSÕNAD; • SAAME TEADA, MIS ON SULGHÄÄLIK; • MIS ON PILDIL?; • MIS PANEB SIND NII ARVAMA?; • KES VÕIKS SELLES TOAS ELADA?

## ENTSÜKLOPEEDIA JA KRATID (I)
URL: https://www.opiq.ee/kit/558/chapter/31397
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 5.2
Topics ET: matemaatika, entsüklopeedia, kratid, elav, küsimus, üllatus, ümbrik, türgi, süüria, küüslauk
Topics RU: математика
Topics EN: mathematics
Headings: ENTSÜKLOPEEDIA JA KRATID (I); ISA ON ELAV ENTSÜKLOPEEDIA; ÜKS KÜSIMUS​ÜLLATUS​ÜMBRIK; ENTSÜKLOPEEDIA​TÜRGI JA SÜÜRIA​KÜÜSLAUK; PÕLDPÜÜ​KASSI SÜÜ​VALGE RÜÜ; MARKUSEL ON ISALE KÜSIMUS.​ISA ON NAGU ELAV ENTSÜKLOPEEDIA.; SEE ON KÜLL ÜLLATUS!​ISA TUNNEB LOODUST HÄSTI.​ISA ÜTLES ÜKSKORD, ET HERNES​PÄRINEB TÜRGIST JA SÜÜRIAST.​SEEMNEID SAAB KÜLVATA SIIS,​KUI SOOJA ON KÜMME KRAADI.; 42. KAS U, UU VÕI Ü?; 43. Ü-TÄHT ARVUDES.; 44. JUTTUDES KÄIB TIHTI VÕITLUS HEA JA KURJA VAHEL.

## ENTSÜKLOPEEDIA JA KRATID (II)
URL: https://www.opiq.ee/kit/558/chapter/31398
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 5.3
Topics ET: matemaatika, entsüklopeedia, kratid, hääletu, tumm, räägib, palju, ämblik, räägi, äratuskell
Topics RU: математика
Topics EN: mathematics
Headings: ENTSÜKLOPEEDIA JA KRATID (II); ISE HÄÄLETU, TUMM, AGA RÄÄGIB PALJU; ÄMBLIK​ÄRA RÄÄGI​ÄRATUSKELL; NÄTSUPAKK​VÄRSKE VÄRV​NÄLJANE NÄKK; LIBE JÄÄ​MÄÄ-MÄÄ!​VÄIKE SÄÄSK; MEMM EI OLE SÖÖBIKUTEST KUULNUD.; MEMM EI RÄÄGI SÖÖBIKUST KELLELEGI. ​TA PALUB SÖÖBIKU EEST HÄSTI HOOLITSEDA. ​LAPSED VIIVAD SÖÖBIKULE IGA PÄEV SÕNU, ET TA NÄLJANE EI OLEKS.; 45. MIDA VÕIKS RAAMATUKOGUST LAENATA?; 46. MÄRGI KÕIGE PIKEM JA KÕIGE LÜHEM SÕNA.; 47. TÄISHÄÄLIKUD RAAMATUTEGELASTE NIMEDES.; 48. MIS SÕNA SAAD?

## ISA JA GRIPP (I)
URL: https://www.opiq.ee/kit/558/chapter/31399
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 5.4
Topics ET: matemaatika, gripp, homme, terve, nagu, purikas, punane, pintsak, pastapliiats, perekond
Topics RU: математика
Topics EN: mathematics
Headings: ISA JA GRIPP (I); ISA ON HOMME TERVE NAGU PURIKAS; PUNANE PINTSAK​PASTAPLIIATS​PEREKOND; APTEEK​KÄPIKUD​TEATRIPILET; KUUM ​SUPP​RIIDEKAPP​GRIPP; ONU RASMUS SAAB ISA PILETI.​RASMUS ON EMA VEND.​TA ÕPIB ÜLIKOOLIS LOODUSTEADUSI.; 49. HÄÄLI SÕNU.; 50. PIIA SEAB END VALMIS.; 51. MILLISED RIIDED PIIA ENDALE VALIS?; 52B. TEE KÕIK P-TÄHED VÄRVILISEKS.; 52A. MIS EI SOBI LAUSESSE?

## ISA JA GRIPP (II)
URL: https://www.opiq.ee/kit/558/chapter/31401
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 5.5
Topics ET: matemaatika, gripp, rasmusel, tuli, takus
Topics RU: математика
Topics EN: mathematics
Headings: ISA JA GRIPP (II); RASMUSEL ON TULI TAKUS

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31405
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 6.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, televiisoris, järgmistes, tundides, nimetame, sügise
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; TELEVIISORIS; JÄRGMISTES TUNDIDES; • NIMETAME SÜGISE TUNNUSEID; • JUTUSTAME TELERI VAATAMISEST; • HARJUTAME B-, K- JA G-TÄHTE; • KIRJUTAME SÕNU, MILLE LÕPUS ON -B VÕI -GA; • MIS PILDIL TOIMUB?; • MIS PANEB SIND NII ARVAMA?; • MIDA TAHAKSID VEEL PILDI KOHTA ÖELDA?

## ÕPETAJATE PÄEVA ÜLLATUS
URL: https://www.opiq.ee/kit/558/chapter/31402
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 6.2
Topics ET: matemaatika, õpetajate, päeva, üllatus, oktoober, kord, naerab, nutab, botased, bass
Topics RU: математика
Topics EN: mathematics
Headings: ÕPETAJATE PÄEVA ÜLLATUS; OKTOOBER KORD NAERAB, KORD NUTAB; BOTASED​BASS​BINOKKEL; NOBE BEEBI​KÕBUS​TUBLI SÕBER; MAITSEB BESEED​LÕBUS BÄND​SÕIDAB BUSSIGA; ÕPETAJA LAURAL ON LASTELE UUDIS.​​KOOLI TULEB KÜLLA „PROŽEKTORI” SAATE JUHT BOBI BERENS.; BOBI BERENS TUNNEB KUULSAID BÄNDE​JA LAULJAID, NÄITEKS RÄPPAR KUKIMUKIT. LAPSED ON KUKIMUKI SUURED FÄNNID. TEMAST OLI „PROŽEKTORIS” SAADE. KUKIMUKI ON KUULUS RÄPPAR,​KES ON ALATI PRILLIDE JA KAPUUTSIGA. KEEGI EI TEA, KUIDAS TA PÄRIS ELUS​VÄLJA NÄEB.; 53B. LEIA B-TÄHED.; 53A. SÜGISKUUD; 54. SÜGISESED TEGEVUSED; 55. MIS ISELOOMUSTAB SÜGIST?; 56. MILLISED VILJAD VALMIVAD SÜGISEL?

## KÜLALINE TELEVISIOONIST
URL: https://www.opiq.ee/kit/558/chapter/31403
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 6.3
Topics ET: matemaatika, külaline, televisioonist, silm, täis, nägemisest, kõrv, kuulmisest, küllakutse, koolimaja
Topics RU: математика
Topics EN: mathematics
Headings: KÜLALINE TELEVISIOONIST; SILM EI SAA TÄIS NÄGEMISEST EGA KÕRV KUULMISEST; KÜLLAKUTSE​KOOLIMAJA​KIMP KANNIKESI; PROJEKT​UKSELUKK​RASKE KOTT; KUULUS ISIK​NÄTSUPAKK​KOOLIÕPIK; BOBI BERENS JUTUSTAB LASTELE MITU LUGU.​ÜKS LUGU ON KELDRIVARGUSEST.​KARU VEHKIS SISSE SADA MOOSIPURKI​JA NORSKAS VIIMAKS KUUSE ALL PURKIDE OTSAS.​LAPSED TAHAVAD KUULDA KUKIMUKIST.; ÕPETAJA KINGIB KÜLALISELE KOOLIPILDIGA​TASSI JA KUTSUB BOBI KOOLIMAJA VAATAMA.​BOBI KUMMARDAB.; 57. MIDA SAID KÜLALISE KOHTA TEADA?; 58. MITU HÄÄLIKUT?; 59. MIS ON PILDIL?

## PROŽEKTOR KOOLIS (I)
URL: https://www.opiq.ee/kit/558/chapter/31404
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 6.4
Topics ET: matemaatika, prožektor, koolis, ettevaatus, tarkuse, garderoob, gümnaasium, gloobus, inglise, keel
Topics RU: математика
Topics EN: mathematics
Headings: PROŽEKTOR KOOLIS (I); ETTEVAATUS ON TARKUSE EMA; GARDEROOB​GÜMNAASIUM​GLOOBUS; INGLISE KEEL​ÄGE GRIPP​EHMUNUD NÄGU; TAGATASKU​HING​KUNSTIRING; KLASSIS ON PLAKATID, GLOOBUSED JA DIGIVAHENDID.​ÕPIKUID POLE VAJA IGA PÄEV KAASA TASSIDA.​NEED SEISAVAD KAPIS. KAPP ON LOGUVÕITU.​LINK TULI ÄRA JA LUKK ON KATKI. ​SEINAGA ON MIDAGI JUHTUNUD. ​MIS LAIGUD NEED ON? ​BOBI BERENS PUUDUTAB PLEKKE ​JA AJAB END AEGLASELT SIRGU.; 60. MIDA TELEVIISORIST VAADATA?; 61. TÄIDA KAVA PÕHJAL ÜLESANDED.; 62. KAS SÕNA ALGUSES ON G VÕI K?; 63. KIRJUTA SÕNA LÕPPU -GA.

## PROŽEKTOR KOOLIS (II)
URL: https://www.opiq.ee/kit/558/chapter/31406
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 6.5
Topics ET: matemaatika, prožektor, koolis, uudishimu, teeb, ruttu, vanaks
Topics RU: математика
Topics EN: mathematics
Headings: PROŽEKTOR KOOLIS (II); UUDISHIMU TEEB RUTTU VANAKS

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31411
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 7.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, linnas, maal, järgmistes, tundides, selgitame
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; LINNAS JA MAAL; JÄRGMISTES TUNDIDES; • SELGITAME, KUIDAS TEATRIS KÄITUDA; • NIMETAME ERINEVAID AIASAADUSEID; • HARJUTAME T- JA D-TÄHTE; • KIRJUTAME SÕNU, MILLE LÕPUS ON -D VÕI -VAD; • KORDAME SULGHÄÄLIKUID; • MIS SELLEL PILDIL TOIMUB?; • MIS PANEB SIND NII ARVAMA?; • MIDA SA VEEL SOOVID PILDI KOHTA ÖELDA?

## SEKELDUSED TEATRIS (I)
URL: https://www.opiq.ee/kit/558/chapter/31407
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 7.2
Topics ET: matemaatika, sekeldused, teatris, varas, iialgi, rikkaks, teeb, tööd, tädi, tiina
Topics RU: математика
Topics EN: mathematics
Headings: SEKELDUSED TEATRIS (I); VARAS EI SAA IIALGI RIKKAKS; TEEB TÖÖD​TÄDI TIINA​TRÜHVEL; JALGRATAS​MAITSEV VORST​TOOB VÕTME; SELJAKOTT​LIHTNE RETSEPT​TEATRIPUHVET; LAVAL TEEB RÖÖVEL RÖÖVLITEMPE.​VAHEAJAL TÕMBAB PIIA KOTILUKU LAHTI.​TA TAHAB TEADA, KUIDAS SÖÖBIKULE TEATRIS MEELDIB.; LIISA-LOTTA TUNNEB TEATRIKÄIKE,​ISEGI TEED LAVAAUKU JA KARDINATE TAHA.​ERITI HÄSTI ON TAL SELGE TEE PUHVETISSE.​TEATRI PUHVETIS TÖÖTAB TÄDI TIINA.​TIINA ANNAB TALLE ALATI​MAAILMA PARIMAID TRÜHVLEID.; 64. MIS ON PILDIL?; 65. KUIDAS TEATRIS KÄITUDA?; 66. MIS SÕNA EI SOBI TEISTE HULKA?; 67. MIS ON PILDIL?

## SEKELDUSED TEATRIS (II)
URL: https://www.opiq.ee/kit/558/chapter/31408
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 7.3
Topics ET: matemaatika, sekeldused, teatris, röövel, võttis, pähe, dollar, diivan, dirigent, tundub
Topics RU: математика
Topics EN: mathematics
Headings: SEKELDUSED TEATRIS (II); RÖÖVEL VÕTTIS ARU PÄHE; DOLLAR​DIIVAN​DIRIGENT; TUNDUB ÕUDNE​KADE DAAM​KOOLIDIREKTOR; PIKAD KARDINAD​DEKORATSIOONID​NÄITLEJAD; SEE ON NÄITLEJATE TUBA. KEEGI KÕMISTAB NAERDA.​TÜDRUKUD TARDUVAD PAIGALE.; Sööbikule teatris ei meeldi.​Ta isegi ei plaksuta, kui etendus lõpeb.​Ta on vist päti peale kade.​Sööbik tahab tähelepanu, aga teatris on tähtsad näitlejad.; 68. VÄRVI JA KUJUNDA PILET TÖÖVIHIKUS, NII NAGU SULLE MEELDIB.; 69. UURI PILETIT.; 70. TÄIDA TABEL.; 71. KIRJUTA SÕNALE SOBIV LÕPP.

## TUHAT MESILAST JA ONU REIN (I)
URL: https://www.opiq.ee/kit/558/chapter/31409
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 7.4
Topics ET: matemaatika, tuhat, mesilast, rein, reinul, lööb, kõht, pilli, kartulid, valmis
Topics RU: математика
Topics EN: mathematics
Headings: TUHAT MESILAST JA ONU REIN (I); REINUL LÖÖB KÕHT PILLI; REINUL LÖÖB KÕHT PILLI.​KARTULID ON VALMIS. VARSTI SAAB SÜÜA.; 72. KUIDAS ELAVAD INIMESED LINNAS, KUIDAS MAAL?; 73. LAHENDA MÕISTATUS.; 74. AIASAADUSED

## TUHAT MESILAST JA ONU REIN (II)
URL: https://www.opiq.ee/kit/558/chapter/31410
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 7.5
Topics ET: matemaatika, tuhat, mesilast, rein, väike, mees, terav, kirves, mida, kasvatab
Topics RU: математика
Topics EN: mathematics
Headings: TUHAT MESILAST JA ONU REIN (II); VÄIKE MEES, TERAV KIRVES?; 75. MIDA KASVATAB VANAEMA AIAS?; 76. KIRJUTA ÕIGE ALGUSTÄHT.

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31415
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 8.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, muuseumis, järgmistes, tundides, selgitame, kuidas
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; MUUSEUMIS; JÄRGMISTES TUNDIDES; • SELGITAME, KUIDAS ÕPPEKÄIGUL KÄITUDA; • HARJUTAME J-, V- JA H-TÄHTE; • UURIME, KUS I JA J SÕNAS ASUVAD; • VAATLEME SÕNU, MILLE ALGUSES ON H; • NIMETAME OMADUSSÕNU; • MIS ON PILDIL?; • MIS PANEB SIND NII ARVAMA?; • KUS VÕIKS NIISUGUNE TUBA OLLA?

## Pauku ja nalja (I)
URL: https://www.opiq.ee/kit/558/chapter/31412
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 8.2
Topics ET: matemaatika, pauku, nalja, lapsed, murravad, pead, jaanuar, järjejutt, joonistus, ajaleht
Topics RU: математика
Topics EN: mathematics
Headings: Pauku ja nalja (I); LAPSED MURRAVAD PEAD; JAANUAR​JÄRJEJUTT​JOONISTUS; AJALEHT​ÕPETAJA JOPE​NELJAPÄEV; JÄI KOJU​LÄHME MAJJA​JALAKÄIJA; 77. KOOSTA LÜHIJUTT.; 78. RAAMATUTEGELASTE NIMED; 79. MILLISED SÕNAD SAAD?; 80. MIDA VÕTTA ÕPPEKÄIGULE KAASA?; 81. MIS ON ÕPPEKÄIGUL SOBILIK?

## Pauku ja nalja (II)
URL: https://www.opiq.ee/kit/558/chapter/31413
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 8.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, pauku, nalja, raamatutega, ruttu, rikkaks, küll, targaks, vahvel, vägev
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Pauku ja nalja (II); RAAMATUTEGA RUTTU RIKKAKS EI SAA, KÜLL AGA TARGAKS; VAHVEL​VÄGEV VÕLUR​VAJALIK VÕTI; VÄRSKE VÄRV​VAHVA KOHVIK​KEHV TAHVEL; PÕNEV SUVI​VÄIKE JÄRV​PUULATV; PÖÖNINGUL TULEB VALVAS OLLA.​SEE ON TEGELIKULT VÕLUPÖÖNING.​SEE TUNDUB VÕIMATU. VALEJUTT!​VÕLUASJU POLE OLEMAS.​LAPSED TAHAVAD ISE PILGU PEALE VISATA.; 82. KUHU MINNA EKSKURSIOONILE?; 83. MIS ON PILDIL?; 84. LEIA VASTANDTÄHENDUSEGA SÕNA.; 85. KIRJUTA LAUSESSE SOBIV SÕNA.

## IMEPÖÖNING (I)
URL: https://www.opiq.ee/kit/558/chapter/31414
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 8.4
Topics ET: matemaatika, imepööning, laura, tõmmatakse, haneks, huvitav, koht, haapsalu, hamburger, lühike
Topics RU: математика
Topics EN: mathematics
Headings: IMEPÖÖNING (I); LAURA TÕMMATAKSE HANEKS; HUVITAV KOHT​HAAPSALU​HAMBURGER; LÜHIKE VAHETUND KÕRREMAHL​TÜHI SAHTEL; AITÄH​ATSIH​SIUH-VIUH; LASTELE TUNDUB SEE HEA KOHT, ​AGA SÖÖBIK MURETSEB SÖÖGI PÄRAST. ​MIS TA SIIN HAMBA ALLA SAAB? ​KAPID ON HIRMUS TÜHJAD. ​ÄKKI ON RAAMATUTES LIHAPALLE VÕI HAMBURGEREID? ​ANNA PANEB KAPPI ÜHE KÜPSISE. SIUHTI SAAB ​ÜHEST KÜPSISEST KAPIS KOLM KÜPSIST.​PIIA PANEB ÜHE KÕRREMAHLA.​VIUHTI SAAB SELLEST KOLM ​KÕRREMAHLA.; 86. MIS OLI KARLSSONI SASSIS TOAS?; 87. VALI ÕIGE SÕNA.; 88. MITU?; 89. MITU?; 90. MITU?

## IMEPÖÖNING (II)
URL: https://www.opiq.ee/kit/558/chapter/31416
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 8.5
Topics ET: matemaatika, imepööning, tühi, kott, seisa, püsti
Topics RU: математика
Topics EN: mathematics
Headings: IMEPÖÖNING (II); TÜHI KOTT EI SEISA PÜSTI

## MIDA ME SELLEL NÄDALAL TEEME?
URL: https://www.opiq.ee/kit/558/chapter/31420
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 9.1
Topics ET: matemaatika, mida, sellel, nädalal, teeme, puhkusel, järgmistes, tundides, jutustame, vaheaja
Topics RU: математика
Topics EN: mathematics
Headings: MIDA ME SELLEL NÄDALAL TEEME?; PUHKUSEL; JÄRGMISTES TUNDIDES; • JUTUSTAME OMA VAHEAJA PLAANIDEST; • HARJUTAME VÕÕRTÄHTI; • ESITAME KÜSIMUSI OLENDITE JA ASJADE KOHTA; • OTSIME SUURI ALGUSTÄHTI; • MOODUSTAME LIITSÕNU; • MIS SELLEL PILDIL TOIMUB?; • MIS PANEB SIND NII ARVAMA?; • MIDA SA VEEL SOOVID PILDI KOHTA ÖELDA?

## Sügisene vaheaeg (I)
URL: https://www.opiq.ee/kit/558/chapter/31417
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 9.2
Topics ET: matemaatika, sügisene, vaheaeg, virgal, puudu, tööd, friikartulid, fantastika, frikadellisupp, pakk
Topics RU: математика
Topics EN: mathematics
Headings: Sügisene vaheaeg (I); EI VIRGAL PUUDU TÖÖD; FRIIKARTULID​FANTASTIKA​FRIKADELLISUPP; PAKK KEEFIRIT ​VALGUSFOOR​HUVITAV INFO; FOTOGRAAF ​MÄNGIS FLÖÖTI ​VANA FOTO; REEDEL SOOVIB LAURA KÕIGILE FANTASTILIST VAHEAEGA. ​UKU MATKAB VANEMATEGA IDA-VIRUMAAL. ​LIISA-LOTTA KÄIB RULAVÕISTLUSEL JA LOOMAAIAS. ​PIIA LÄHEB ISAGA JALKASTAADIONILE. ​SEAL TOIMUB PÕNEV FINAALMATŠ.; 91B. VÄRVI F-TÄHTED.; 91A. KAS TEAD SÕNU?; 92. KES? VÕI MIS?; 93. KES VÕI MIS?; 94. KIRJUTA LÜNKA F VÕI V.

## Sügisene vaheaeg (II)
URL: https://www.opiq.ee/kit/558/chapter/31418
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 9.3
Topics ET: matemaatika, sügisene, vaheaeg, sööbikul, mustad, päevad, šokolaad, guljašš, maitsev, borš
Topics RU: математика
Topics EN: mathematics
Headings: Sügisene vaheaeg (II); SÖÖBIKUL ON MUSTAD PÄEVAD; ŠOKOLAAD ​GULJAŠŠ ​MAITSEV BORŠ; ZEN ​ZOOLOOG ​PROŽEKTOR; ŽELATIIN ​DŽEMM ​BEEŽ JA ORANŽ; SÖÖBIK ON ÜLLATUNUD. BORŠ ON MAITSEV. ​ŠOKOLAAD PANEB MÕMISEMA. ​TA PROOVIB KA ŠAMPINJONE JA GULJAŠŠI. ​SÖÖBIK LIMPSAB KEELT. ​NELJAPÄEVAL ON AGA KÕIK OTSAS. ​SÖÖBIK SÖÖB ÄRA MUSTADEKS PÄEVADEKS ​HOITUD DŽEMMI JA ISEGI ŽELATIINI.; 95. ÜHENDA SÕNA JA SELETUS.; 96. KASUTA SÕNU LAUSETES.

## TAGASI KOOLIS (I)
URL: https://www.opiq.ee/kit/558/chapter/31421
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 9.4
Topics ET: matemaatika, tagasi, koolis, tõsi, tõeks, nali, naljaks
Topics RU: математика
Topics EN: mathematics
Headings: TAGASI KOOLIS (I); TÕSI TÕEKS JA NALI NALJAKS

## TAGASI KOOLIS (II)
URL: https://www.opiq.ee/kit/558/chapter/31419
Book: TÄHESTIK
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri2_est
Chapter ID: 9.5
Topics ET: matemaatika, tagasi, koolis, tahab, palju, sõpru, oleks, peab, sõbralik, olema
Topics RU: математика
Topics EN: mathematics
Headings: TAGASI KOOLIS (II); KES TAHAB, ET TAL PALJU SÕPRU OLEKS, PEAB ISE SÕBRALIK OLEMA; QUEBEC [kebekk] ​NEW YORK [njuu jork]MEXICO [meksiko]CHICAGO [šikaago]​; SYDNEY [sidni] ​CHIŞINĂU [kišinau] ​BARCELONA [barsseloona]; 97B. SÖÖBIK LEIDIS PORTSU VÜRTSIKAID SÕNU.; 97A. VÜRTSIKAD SÕNAD; 98. Suur algustäht; 99. Nimed; 100. Kus võid kohata võõrtähti?; 101. Automargid; 102. Liitsõnad; 103. Mis automark? Kirjuta joonele.

## KOOS ON TORE. Piia lood – Opiq
URL: https://www.opiq.ee/Kit/Details/126
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 493
Topics ET: matemaatika, koos, tore, piia, lood, opiq
Topics RU: математика
Topics EN: mathematics

## Sissejuhatus
URL: https://www.opiq.ee/kit/126/chapter/6749
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.1
Topics ET: matemaatika, sissejuhatus
Topics RU: математика
Topics EN: mathematics
Headings: Sissejuhatus

## KOOLITUNNID
URL: https://www.opiq.ee/kit/126/chapter/6746
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.10
Topics ET: matemaatika, koolitunnid, tund, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: KOOLITUNNID; 1. MIS TUND ON?; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1; LISAÜLESANNE 2

## ÕPETAJATE PÄEV
URL: https://www.opiq.ee/kit/126/chapter/6747
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.11
Topics ET: matemaatika, õpetajate, päev, vasta, küsimustele, loeme, koos
Topics RU: математика
Topics EN: mathematics
Headings: ÕPETAJATE PÄEV; 1. VASTA KÜSIMUSTELE!; 2. E-ÜLESANNE; E-ül; 3. LOEME KOOS!; 4. TEE NII!

## NÜÜD MA OSKAN
URL: https://www.opiq.ee/kit/126/chapter/6748
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.12
Topics ET: matemaatika, nüüd, oskan, räägi, loeme, koos, värvi, kaasa, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: NÜÜD MA OSKAN; 1. LOE JA RÄÄGI!; E-ül; 2. LOEME KOOS!; 3. MIS VÄRVI ON?; 4. LOEME KOOS! TEE KAASA!; 5. RÄÄGI!; LISAÜLESANNE 1; LISAÜLESANNE 2; LISAÜLESANNE 3

## MINA
URL: https://www.opiq.ee/kit/126/chapter/6738
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.2
Topics ET: matemaatika, mina, räägi
Topics RU: математика
Topics EN: mathematics
Headings: MINA; 1. TEE NII!; 2. E-ÜLESANNE; E-ül; 3. RÄÄGI!

## EMA JA ISA
URL: https://www.opiq.ee/kit/126/chapter/6739
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.3
Topics ET: matemaatika, räägi
Topics RU: математика
Topics EN: mathematics
Headings: EMA JA ISA; 1. RÄÄGI!; 2. E-ÜLESANNE; E-ül

## ÕED JA VENNAD
URL: https://www.opiq.ee/kit/126/chapter/6740
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.4
Topics ET: matemaatika, vennad, loeme, koos, räägi
Topics RU: математика
Topics EN: mathematics
Headings: ÕED JA VENNAD; 1. LOEME KOOS!; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül

## VANAEMA JA VANAISA
URL: https://www.opiq.ee/kit/126/chapter/6741
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.5
Topics ET: matemaatika, vanaema, vanaisa, loeme, koos, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: VANAEMA JA VANAISA; 1. LOEME KOOS!; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1; LISAÜLESANNE 2

## MINU SÕBRAD
URL: https://www.opiq.ee/kit/126/chapter/6742
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.6
Topics ET: matemaatika, sõbrad, vasta, küsimustele, loeme, koos, räägi
Topics RU: математика
Topics EN: mathematics
Headings: MINU SÕBRAD; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## MINU KLASS
URL: https://www.opiq.ee/kit/126/chapter/6743
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.7
Topics ET: matemaatika, klass, vasta, küsimustele, loeme, koos, kaasa, vaata, räägi
Topics RU: математика
Topics EN: mathematics
Headings: MINU KLASS; 1. VASTA KÜSIMUSTELE!; 2. E-ÜLESANNE; E-ül; 3. LOEME KOOS! TEE KAASA!; VAATA, MIS MUL ON!; 4. RÄÄGI!

## MINU ÕPETAJA
URL: https://www.opiq.ee/kit/126/chapter/6744
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.8
Topics ET: matemaatika, õige, vale, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: MINU ÕPETAJA; 1. ÕIGE VÕI VALE?; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## MINU ÕPETAJALE MEELDIB
URL: https://www.opiq.ee/kit/126/chapter/6745
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 1.9
Topics ET: matemaatika, õpetajale, meeldib, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: MINU ÕPETAJALE MEELDIB; MINU ÕPETAJALE MEELDIB …; 1. RÄÄGI SÕBRAGA!; 2. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## MINU KODULINN
URL: https://www.opiq.ee/kit/126/chapter/6750
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.1
Topics ET: matemaatika, kodulinn, vasta, küsimustele, räägi
Topics RU: математика
Topics EN: mathematics
Headings: MINU KODULINN; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül

## VANAEMA JUURES
URL: https://www.opiq.ee/kit/126/chapter/6759
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.10
Topics ET: matemaatika, vanaema, juures, lõpeta, laused, loeme, koos, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: VANAEMA JUURES; 1. LÕPETA LAUSED!; E-ül; 2. LOEME KOOS!; 3. RÄÄGI!; LISAÜLESANNE 1

## NÜÜD MA OSKAN
URL: https://www.opiq.ee/kit/126/chapter/6760
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.11
Topics ET: matemaatika, nüüd, oskan, räägi, mida, sina, teed, ütle, näita, loeme
Topics RU: математика
Topics EN: mathematics
Headings: NÜÜD MA OSKAN; 1. LOE JA RÄÄGI!; 2. LOE!; 3. MIDA SINA TEED? ÜTLE JA NÄITA!; E-ül; 4. LOEME KOOS!; 5. RÄÄGI!

## MINU LEMMIKKOHAD
URL: https://www.opiq.ee/kit/126/chapter/6751
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.2
Topics ET: matemaatika, lemmikkohad, õige, vale, loeme, koos, räägi
Topics RU: математика
Topics EN: mathematics
Headings: MINU LEMMIKKOHAD; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; 3. RÄÄGI!

## MINU KODU
URL: https://www.opiq.ee/kit/126/chapter/6752
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.3
Topics ET: matemaatika, kodu, vasta, küsimustele, laulame, koos, koduke, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: MINU KODU; 1. VASTA KÜSIMUSTELE!; 2. LAULAME KOOS!; MU KODUKE; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## MEIE KODU TOAD
URL: https://www.opiq.ee/kit/126/chapter/6753
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.4
Topics ET: matemaatika, meie, kodu, toad, need, asjad, käivad, tuba, loeme, koos
Topics RU: математика
Topics EN: mathematics
Headings: MEIE KODU TOAD; 1. KUS NEED ASJAD KÄIVAD? MIS TUBA SEE ON?; 2. LOEME KOOS!; MINU KODU; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## ELUTUBA
URL: https://www.opiq.ee/kit/126/chapter/6754
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.5
Topics ET: matemaatika, elutuba, vaata, pilti, räägi, mida, keegi, teeb, õige, vale
Topics RU: математика
Topics EN: mathematics
Headings: ELUTUBA; 1. VAATA PILTI! RÄÄGI, MIDA KEEGI TEEB.; 2. ÕIGE VÕI VALE?; 3. LOEME KOOS!; 4. RÄÄGI SÕBRAGA!; 5. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## MINU TUBA
URL: https://www.opiq.ee/kit/126/chapter/6755
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.6
Topics ET: matemaatika, tuba, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: MINU TUBA; 1. RÄÄGI!; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## ISADEPÄEV
URL: https://www.opiq.ee/kit/126/chapter/6756
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.7
Topics ET: matemaatika, isadepäev, õige, vale, loeme, koos, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: ISADEPÄEV; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## KORISTAME KODU!
URL: https://www.opiq.ee/kit/126/chapter/6757
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.8
Topics ET: matemaatika, koristame, kodu, vaata, pilte, mida, keegi, teeb, räägi
Topics RU: математика
Topics EN: mathematics
Headings: KORISTAME KODU!; 1. VAATA PILTE! MIDA KEEGI TEEB?; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül

## KÜLALISED
URL: https://www.opiq.ee/kit/126/chapter/6758
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 2.9
Topics ET: matemaatika, külalised, milline, õige, pilt, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: KÜLALISED; 1. MILLINE ON ÕIGE PILT?; E-ül; 2. E-ÜLESANNE; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## SÜNNIPÄEV
URL: https://www.opiq.ee/kit/126/chapter/6761
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.1
Topics ET: matemaatika, sünnipäev, vasta, küsimustele, laulame, koos, sünnipäevaks, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: SÜNNIPÄEV; 1. VASTA KÜSIMUSTELE!; 2. E-ÜLESANNE; E-ül; 3. LAULAME KOOS!; SÜNNIPÄEVAKS; 4. RÄÄGI!; LISAÜLESANNE 1

## SÜNNIPÄEVAPIDU
URL: https://www.opiq.ee/kit/126/chapter/6762
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.2
Topics ET: matemaatika, sünnipäevapidu
Topics RU: математика
Topics EN: mathematics
Headings: SÜNNIPÄEVAPIDU; 1. TEE NII!; 2. E-ÜLESANNE; E-ül

## NÄDAL
URL: https://www.opiq.ee/kit/126/chapter/6763
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.3
Topics ET: matemaatika, nädal, vasta, küsimustele, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: NÄDAL; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## KUUD
URL: https://www.opiq.ee/kit/126/chapter/6764
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.4
Topics ET: matemaatika, kuud, õige, vale, jäta, meelde, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: KUUD; 1. ÕIGE VÕI VALE?; E-ül; 2. JÄTA MEELDE!; LISAÜLESANNE 1

## AASTAAJAD
URL: https://www.opiq.ee/kit/126/chapter/6765
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.5
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, jäta, meelde, loeme, koos, räägi, lisaülesanne
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: AASTAAJAD; 1. JÄTA MEELDE!; 2. LOEME KOOS!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## JÕULUD KOOLIS
URL: https://www.opiq.ee/kit/126/chapter/6766
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.6
Topics ET: matemaatika, jõulud, koolis, laulame, koos, metsas, sirgus, kuuseke, räägi
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUD KOOLIS; Š, Z, Ž; 1. MIS SEE ON?; 2. LAULAME KOOS!; METSAS SIRGUS KUUSEKE; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## JÕULUD KODUS
URL: https://www.opiq.ee/kit/126/chapter/6767
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.7
Topics ET: matemaatika, jõulud, kodus, õige, vale, loeme, koos, päkapikk, räägi
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUD KODUS; C, Q, W, X, Y; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; PÄKAPIKK; 3. E-ÜLESANNE; 4. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## NÜÜD MA OSKAN
URL: https://www.opiq.ee/kit/126/chapter/6768
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 3.8
Topics ET: matemaatika, nüüd, oskan, räägi, piia, sünnipäevast, vasta, küsimustele, loeme, koos
Topics RU: математика
Topics EN: mathematics
Headings: NÜÜD MA OSKAN; 1. RÄÄGI PIIA SÜNNIPÄEVAST!; 2. VASTA KÜSIMUSTELE!; 3. LOEME KOOS!; 4. LOEME KOOS!; DETSEMBER; 5. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## JÕULUVAHEAEG
URL: https://www.opiq.ee/kit/126/chapter/6769
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.1
Topics ET: matemaatika, jõuluvaheaeg, lõpeta, laused, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: JÕULUVAHEAEG; 1. LÕPETA LAUSED!; E-ül; 2. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## KUIDAS OLLA TERVE?
URL: https://www.opiq.ee/kit/126/chapter/6778
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.10
Topics ET: matemaatika, kuidas, olla, terve, vali, õige, variant, laulame, koos, hanepojad
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS OLLA TERVE?; 1. VALI ÕIGE VARIANT!; E-ül; 2. LAULAME KOOS!; HANEPOJAD; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## SÕBRAPÄEV
URL: https://www.opiq.ee/kit/126/chapter/6779
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.11
Topics ET: matemaatika, sõbrapäev, õige, vale, loeme, koos, sõbrale, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: SÕBRAPÄEV; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; SÕBRALE​; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## TÜLI KOOLIS
URL: https://www.opiq.ee/kit/126/chapter/6780
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.12
Topics ET: matemaatika, tüli, koolis, vasta, küsimustele, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: TÜLI KOOLIS; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül

## PALUN VABANDUST!
URL: https://www.opiq.ee/kit/126/chapter/6781
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.13
Topics ET: matemaatika, palun, vabandust, vasta, küsimustele, räägi
Topics RU: математика
Topics EN: mathematics
Headings: PALUN VABANDUST!; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül

## NÜÜD MA OSKAN
URL: https://www.opiq.ee/kit/126/chapter/6782
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.14
Topics ET: matemaatika, aeg, kell, kalender, nüüd, oskan, harjuta, istub, bussis, keskel, taga, tõuse
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: NÜÜD MA OSKAN; 1. HARJUTA!; 2. KES ISTUB BUSSIS EES / KESKEL / TAGA?; 3. KELL ON ...; 4. TÕUSE PÜSTI!; 5. E-ÜLESANNE; E-ül; 6. RÄÄGI!

## KOOLITEE
URL: https://www.opiq.ee/kit/126/chapter/6770
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.2
Topics ET: matemaatika, koolitee, vasta, küsimustele, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: KOOLITEE; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## MINU KOOL
URL: https://www.opiq.ee/kit/126/chapter/6771
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.3
Topics ET: matemaatika, kool, lõpeta, laused, vaata, pilti, ütle, näita, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: MINU KOOL; 1. LÕPETA LAUSED.; 2. VAATA PILTI, ÜTLE JA NÄITA!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## MINU KLASSIRUUM
URL: https://www.opiq.ee/kit/126/chapter/6772
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.4
Topics ET: matemaatika, klassiruum, lõpeta, laused, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: MINU KLASSIRUUM; 1. LÕPETA LAUSED!; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## KOOLIKORD
URL: https://www.opiq.ee/kit/126/chapter/6773
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.5
Topics ET: matemaatika, koolikord, õige, vale, loeme, koos, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: KOOLIKORD; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## MINU HOMMIK
URL: https://www.opiq.ee/kit/126/chapter/6774
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.6
Topics ET: matemaatika, aeg, kell, kalender, hommik, õige, vale, räägi, sõbraga, lisaülesanne
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: MINU HOMMIK; 1. ÕIGE VÕI VALE?; E-ül; 2. MIS KELL ON?; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## MINU PÄEV
URL: https://www.opiq.ee/kit/126/chapter/6775
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.7
Topics ET: matemaatika, aeg, kell, kalender, päev, mida, teeb, piia, räägi, lisaülesanne
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: MINU PÄEV; 1. MIDA TEEB PIIA KELL … ?; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## MINU ÕHTU
URL: https://www.opiq.ee/kit/126/chapter/6776
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.8
Topics ET: matemaatika, õhtu, kujuta, ette, oled, piia, loeme, koos, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: MINU ÕHTU; 1. KUJUTA ETTE, ET SA OLED PIIA.; 2. LOEME KOOS!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## KEHAOSAD
URL: https://www.opiq.ee/kit/126/chapter/6777
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 4.9
Topics ET: matemaatika, kehaosad, räägi, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: KEHAOSAD; 1. RÄÄGI!; 2. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## EESTI SÜNNIPÄEV
URL: https://www.opiq.ee/kit/126/chapter/6783
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.1
Topics ET: matemaatika, eesti, sünnipäev, õige, vale, värvi, sümbolid, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: EESTI SÜNNIPÄEV; 1. ÕIGE VÕI VALE?; E-ül; 2. MIS VÄRVI ON EESTI SÜMBOLID? RÄÄGI!; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## NÜÜD MA OSKAN
URL: https://www.opiq.ee/kit/126/chapter/6792
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.10
Topics ET: matemaatika, nüüd, oskan, räägi, sõnad, puudu, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: NÜÜD MA OSKAN; 1. LOE JA RÄÄGI.; 2. E-ÜLESANNE; E-ül; 3. MIS SÕNAD ON PUUDU?; 4. RÄÄGI!; LISAÜLESANNE 1

## VASTLAPÄEV
URL: https://www.opiq.ee/kit/126/chapter/6784
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.2
Topics ET: matemaatika, vastlapäev, lõpeta, laused, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: VASTLAPÄEV; 1. LÕPETA LAUSED!; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## LAULUPIDU
URL: https://www.opiq.ee/kit/126/chapter/6785
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.3
Topics ET: matemaatika, laulupidu, vasta, küsimustele, laulame, koos, kaasa, tuju, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: LAULUPIDU; 1. VASTA KÜSIMUSTELE!; 2. LAULAME KOOS! TEE KAASA!; KUI SUL TUJU HEA; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## EESTI TOIT
URL: https://www.opiq.ee/kit/126/chapter/6786
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.4
Topics ET: matemaatika, eesti, toit, milline, õige, pilt, räägi, näita, ütle, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: EESTI TOIT; 1. MILLINE ON ÕIGE PILT? RÄÄGI!; 2. NÄITA JA ÜTLE!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## LEMMIKMULTIKAS
URL: https://www.opiq.ee/kit/126/chapter/6787
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.5
Topics ET: matemaatika, lemmikmultikas, õige, vale, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: LEMMIKMULTIKAS; 1. ÕIGE VÕI VALE?; E-ül; 2. RÄÄGI SÕBRAGA!

## NUKUTEATER
URL: https://www.opiq.ee/kit/126/chapter/6788
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.6
Topics ET: matemaatika, nukuteater, vasta, küsimustele, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: NUKUTEATER; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI SÕBRAGA!; 3. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## METSLOOMAD
URL: https://www.opiq.ee/kit/126/chapter/6789
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.7
Topics ET: matemaatika, metsloomad, värvi, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: METSLOOMAD; 1. E-ÜLESANNE; E-ül; 2. KES SEE ON? MIS VÄRVI TA ON?; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE

## OTEPÄÄ
URL: https://www.opiq.ee/kit/126/chapter/6790
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.8
Topics ET: matemaatika, otepää, mida, teeb, räägi
Topics RU: математика
Topics EN: mathematics
Headings: OTEPÄÄ; 1. KES MIDA TEEB? RÄÄGI!; 2. RÄÄGI!; 3. E-ÜLESANNE; E-ül

## PÄRNU
URL: https://www.opiq.ee/kit/126/chapter/6791
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 5.9
Topics ET: matemaatika, pärnu, lõpeta, laused, näita, ütle, mida, rannas, teed, räägi
Topics RU: математика
Topics EN: mathematics
Headings: PÄRNU; 1. LÕPETA LAUSED!; 2. NÄITA JA ÜTLE! MIDA SA RANNAS TEED?; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## EMA HOBID
URL: https://www.opiq.ee/kit/126/chapter/6793
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 6.1
Topics ET: matemaatika, hobid, lõpeta, laused, loeme, koos, patsu, kooki, räägi
Topics RU: математика
Topics EN: mathematics
Headings: EMA HOBID; 1. LÕPETA LAUSED!; 2. LOEME KOOS!; PATSU-PATSU KOOKI; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## ISA HOBID
URL: https://www.opiq.ee/kit/126/chapter/6794
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 6.2
Topics ET: matemaatika, hobid, õige, vale, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: ISA HOBID; 1. ÕIGE VÕI VALE?; E-ül; 2. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## LIHAVÕTTED
URL: https://www.opiq.ee/kit/126/chapter/6795
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 6.3
Topics ET: matemaatika, lihavõtted, vasta, küsimustele, loeme, koos, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: LIHAVÕTTED; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; 3. E-ÜLESANNE; E-ül; 4. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## MARGUSE HOBI
URL: https://www.opiq.ee/kit/126/chapter/6796
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 6.4
Topics ET: matemaatika, marguse, hobi, vasta, küsimustele, need, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: MARGUSE HOBI; 1. VASTA KÜSIMUSTELE!; 2. MIS NEED ON? LOE!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; 5. E-ÜLESANNE

## PIIA JA MEELISE HOBID
URL: https://www.opiq.ee/kit/126/chapter/6797
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 6.5
Topics ET: matemaatika, piia, meelise, hobid, vasta, küsimustele, loeme, koos, räägi
Topics RU: математика
Topics EN: mathematics
Headings: PIIA JA MEELISE HOBID; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; 3. RÄÄGI!; 4. E-ÜLESANNE; E-ül

## MÄNGURING
URL: https://www.opiq.ee/kit/126/chapter/6798
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 6.6
Topics ET: matemaatika, mänguring, lõpeta, laused, laulame, mängime, aias, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: MÄNGURING; 1. LÕPETA LAUSED!; 2. LAULAME JA MÄNGIME!; KES AIAS?; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## NÜÜD MA OSKAN
URL: https://www.opiq.ee/kit/126/chapter/6799
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 6.7
Topics ET: matemaatika, nüüd, oskan, räägi, laulame, mängime, kaks, sammu, sissepoole, sõnad
Topics RU: математика
Topics EN: mathematics
Headings: NÜÜD MA OSKAN; 1. LOE JA RÄÄGI!; 2. LAULAME JA MÄNGIME!; KAKS SAMMU SISSEPOOLE; 3. MIS SÕNAD ON PUUDU?; 4. RÄÄGI!; 5. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## PIIA HELISTAB VANAEMA HELMILE
URL: https://www.opiq.ee/kit/126/chapter/6800
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.1
Topics ET: matemaatika, piia, helistab, vanaema, helmile, õige, vale, loeme, koos, kallis
Topics RU: математика
Topics EN: mathematics
Headings: PIIA HELISTAB VANAEMA HELMILE; 1. ÕIGE VÕI VALE?; E-ül; 2. LOEME KOOS!; KALLIS VANAEMA; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## EMADEPÄEV
URL: https://www.opiq.ee/kit/126/chapter/6801
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.2
Topics ET: matemaatika, emadepäev, vasta, küsimustele, laulame, koos, sulle, emake, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: EMADEPÄEV; 1. VASTA KÜSIMUSTELE!; 2. LAULAME KOOS!; SULLE, EMAKE; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## ARVUTI
URL: https://www.opiq.ee/kit/126/chapter/6802
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.3
Topics ET: matemaatika, arvuti, vasta, küsimustele, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: ARVUTI; 1. VASTA KÜSIMUSTELE!; 2. RÄÄGI!; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## LÄHME POODI!
URL: https://www.opiq.ee/kit/126/chapter/6803
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.4
Topics ET: matemaatika, lähme, poodi, lõpeta, laused, näita, ütle, räägi, sõbraga, lisaülesanne
Topics RU: математика
Topics EN: mathematics
Headings: LÄHME POODI!; 1. LÕPETA LAUSED!; E-ül; 2. NÄITA JA ÜTLE!; 3. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## RAHA
URL: https://www.opiq.ee/kit/126/chapter/6804
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.5
Topics ET: matemaatika, raha, euro, sent, lõpeta, laused, loeme, koos, räägi, sõbraga, lisaülesanne
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: RAHA; 1. LÕPETA LAUSED!; 2. LOEME KOOS!; 3. E-ÜLESANNE; E-ül; 4. RÄÄGI SÕBRAGA!; LISAÜLESANNE 1

## EKSKURSIOON
URL: https://www.opiq.ee/kit/126/chapter/6805
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.6
Topics ET: matemaatika, ekskursioon, vaata, pilti, õige, vale, laulame, koos, koer, muki
Topics RU: математика
Topics EN: mathematics
Headings: EKSKURSIOON; 1. VAATA PILTI!; 2. ÕIGE VÕI VALE?; E-ül; 3. LAULAME KOOS!; KOER MUKI; 4. RÄÄGI SÕBRAGA!; 5. E-ÜLESANNE; LISAÜLESANNE 1

## LAAGER
URL: https://www.opiq.ee/kit/126/chapter/6806
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.7
Topics ET: matemaatika, laager, vasta, küsimustele, loeme, koos, päikene, räägi, sõbraga
Topics RU: математика
Topics EN: mathematics
Headings: LAAGER; 1. VASTA KÜSIMUSTELE!; 2. LOEME KOOS!; 3. LOEME KOOS!; PÄIKENE; 4. RÄÄGI SÕBRAGA!; 5. E-ÜLESANNE; E-ül; LISAÜLESANNE 1

## MINU SUVI
URL: https://www.opiq.ee/kit/126/chapter/6807
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.8
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, lõpeta, laused, mida, sina, suvel, teed, räägi, sõbraga
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: MINU SUVI; 1. LÕPETA LAUSED!; 2. MIDA SINA SUVEL TEED?; 3. RÄÄGI SÕBRAGA!; 4. E-ÜLESANNE; E-ül

## NÜÜD MA OSKAN
URL: https://www.opiq.ee/kit/126/chapter/6808
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 7.9
Topics ET: matemaatika, nüüd, oskan, räägi, loeme, koos, sõnad, puudu, ilusat
Topics RU: математика
Topics EN: mathematics
Headings: NÜÜD MA OSKAN; 1. LOE JA RÄÄGI!; 2. LOEME KOOS!; 3. MIS SÕNAD ON PUUDU?; 4. RÄÄGI!; 5. E-ÜLESANNE; E-ül; ILUSAT SUVE!

## Sõnastik
URL: https://www.opiq.ee/kit/126/chapter/6809
Book: Sissejuhatus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri3_est
Chapter ID: 8.1
Topics ET: matemaatika, sõnastik
Topics RU: математика
Topics EN: mathematics
Headings: Sõnastik

## Mina loen ja kirjutan – Opiq
URL: https://www.opiq.ee/Kit/Details/464
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 532
Topics ET: matemaatika, mina, loen, kirjutan, opiq
Topics RU: математика
Topics EN: mathematics

## HÄÄLIKUD JA TÄHED
URL: https://www.opiq.ee/kit/464/chapter/25229
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 1.1
Topics ET: matemaatika, häälikud, tähed
Topics RU: математика
Topics EN: mathematics
Headings: HÄÄLIKUD JA TÄHED; 1.

## A, AA
URL: https://www.opiq.ee/kit/464/chapter/25230
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: A, AA; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## TÄISHÄÄLIKUD
URL: https://www.opiq.ee/kit/464/chapter/25239
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.10
Topics ET: matemaatika, täishäälikud
Topics RU: математика
Topics EN: mathematics
Headings: TÄISHÄÄLIKUD; 1.; 2.; 3.; 4.

## TÄISHÄÄLIKUÜHEND
URL: https://www.opiq.ee/kit/464/chapter/25240
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.11
Topics ET: matemaatika, täishäälikuühend
Topics RU: математика
Topics EN: mathematics
Headings: TÄISHÄÄLIKUÜHEND; 1.; 2.; 3.

## KORDAMINE
URL: https://www.opiq.ee/kit/464/chapter/25241
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.12
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.; 4.; 5.; 6.

## E, EE
URL: https://www.opiq.ee/kit/464/chapter/25231
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: E, EE; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## I, II
URL: https://www.opiq.ee/kit/464/chapter/25232
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: I, II; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.; 13.

## O, OO
URL: https://www.opiq.ee/kit/464/chapter/25233
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: O, OO; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## U, UU
URL: https://www.opiq.ee/kit/464/chapter/25234
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.5
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: U, UU; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.

## Õ, ÕÕ
URL: https://www.opiq.ee/kit/464/chapter/25235
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Õ, ÕÕ; 1.; 2.; 3.; 4.; 5.

## Ä, ÄÄ
URL: https://www.opiq.ee/kit/464/chapter/25236
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ä, ÄÄ; 1.; 2.; 3.; 4.; 5.; 6.

## Ö, ÖÖ
URL: https://www.opiq.ee/kit/464/chapter/25237
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ö, ÖÖ; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## Ü, ÜÜ
URL: https://www.opiq.ee/kit/464/chapter/25238
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 2.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Ü, ÜÜ; 1.; 2.; 3.; 4.; 5.

## L, LL
URL: https://www.opiq.ee/kit/464/chapter/25242
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: L, LL; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.

## M, MM
URL: https://www.opiq.ee/kit/464/chapter/25243
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: M, MM; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.; 11.; 12.

## N, NN
URL: https://www.opiq.ee/kit/464/chapter/25244
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: N, NN; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.; 9.; 10.

## R, RR
URL: https://www.opiq.ee/kit/464/chapter/25245
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: R, RR; 1.; 2.; 3.; 4.; 5.; 6.

## S, SS
URL: https://www.opiq.ee/kit/464/chapter/25246
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.5
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: S, SS; 1.; 2.; 3.; 4.; 5.; 6.

## V
URL: https://www.opiq.ee/kit/464/chapter/25247
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: 1.; 2.; 3.; 4.; 5.; 6.; 7.

## H SÕNA ALGUL
URL: https://www.opiq.ee/kit/464/chapter/25248
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.7
Topics ET: matemaatika, sõna, algul
Topics RU: математика
Topics EN: mathematics
Headings: H SÕNA ALGUL; 1.; 2.; 3.; 4.; 5.

## J
URL: https://www.opiq.ee/kit/464/chapter/25249
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: 1.; 2.; 3.; 4.; 5.; 6.

## KORDAMINE
URL: https://www.opiq.ee/kit/464/chapter/25250
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 3.9
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.; 4.; 5.

## G, K, KK
URL: https://www.opiq.ee/kit/464/chapter/25251
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.1
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: G, K, KK; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## KORDAMINE: B, P, PP
URL: https://www.opiq.ee/kit/464/chapter/25260
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.10
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: B, P, PP; 1.; 2.; 3.; 4.; 5.

## D, T, TT
URL: https://www.opiq.ee/kit/464/chapter/25261
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.11
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: D, T, TT; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## D, TT
URL: https://www.opiq.ee/kit/464/chapter/25262
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.12
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: D, TT; 1.; 2.; 3.; 4.; 5.; 6.

## D, T
URL: https://www.opiq.ee/kit/464/chapter/25263
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.13
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: D, T; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## T, TT
URL: https://www.opiq.ee/kit/464/chapter/25264
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.14
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: T, TT; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## KORDAMINE: D, T, TT
URL: https://www.opiq.ee/kit/464/chapter/25265
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.15
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: D, T, TT; 1.; 2.; 3.; 4.; 5.; 6.

## KORDAMINE
URL: https://www.opiq.ee/kit/464/chapter/25266
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.16
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE; 1.; 2.; 3.; 4.

## G, KK
URL: https://www.opiq.ee/kit/464/chapter/25252
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.2
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: G, KK; 1.; 2.; 3.; 4.; 5.; 6.

## G, K
URL: https://www.opiq.ee/kit/464/chapter/25253
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.3
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: G, K; 1.; 2.; 3.; 4.; 5.; 6.

## K, KK
URL: https://www.opiq.ee/kit/464/chapter/25254
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.4
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: K, KK; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## KORDAMINE: G, K, KK
URL: https://www.opiq.ee/kit/464/chapter/25255
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.5
Topics ET: matemaatika, kordamine, korda, harjutan
Topics RU: математика, повторение, повтори, тренировка
Topics EN: mathematics, revision, review, practice
Headings: KORDAMINE: G, K, KK; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## B, P, PP
URL: https://www.opiq.ee/kit/464/chapter/25256
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.6
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: B, P, PP; 1.; 2.; 3.; 4.; 5.; 6.; 7.; 8.

## B, PP
URL: https://www.opiq.ee/kit/464/chapter/25257
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.7
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: B, PP; 1.; 2.; 3.; 4.; 5.; 6.; 7.

## B, P
URL: https://www.opiq.ee/kit/464/chapter/25258
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.8
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: B, P; 1.; 2.; 3.; 4.; 5.; 6.

## P, PP
URL: https://www.opiq.ee/kit/464/chapter/25259
Book: HÄÄLIKUD JA TÄHED
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri4_est
Chapter ID: 4.9
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: P, PP; 1.; 2.; 3.; 4.; 5.

## AABITS – Opiq
URL: https://www.opiq.ee/Kit/Details/99
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 126
Topics ET: matemaatika, aabits, opiq
Topics RU: математика
Topics EN: mathematics

## PERE ON METSAS
URL: https://www.opiq.ee/kit/99/chapter/4840
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.1
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, pere, metsas, seeni, keegi, korjab
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: PERE ON METSAS; SUVI METSAS; MIS SEENI KEEGI KORJAB?

## Õõ, Öö
URL: https://www.opiq.ee/kit/99/chapter/4810
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.10
Topics ET: matemaatika, jaagupi, klass
Topics RU: математика
Topics EN: mathematics
Headings: Õõ, Öö; Jaagupi klass

## VANASÕNA
URL: https://www.opiq.ee/kit/99/chapter/4844
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.11
Topics ET: matemaatika, vanasõna, sõna
Topics RU: математика
Topics EN: mathematics
Headings: VANASÕNA; SÕNA

## Rr
URL: https://www.opiq.ee/kit/99/chapter/4811
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.12
Topics ET: matemaatika, park
Topics RU: математика
Topics EN: mathematics
Headings: Rr; PARK

## Jaagupi kool
URL: https://www.opiq.ee/kit/99/chapter/4845
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.13
Topics ET: matemaatika, jaagupi, kool, huviringid
Topics RU: математика
Topics EN: mathematics
Headings: Jaagupi kool; HUVIRINGID

## Ss
URL: https://www.opiq.ee/kit/99/chapter/4812
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.14
Topics ET: matemaatika, unejutt
Topics RU: математика
Topics EN: mathematics
Headings: Ss; Unejutt

## Uu, Üü
URL: https://www.opiq.ee/kit/99/chapter/4813
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.15
Topics ET: matemaatika, pääse, kiirustab
Topics RU: математика
Topics EN: mathematics
Headings: Uu, Üü; ÜLO EI PÄÄSE ÜLE TEE.; ÜLO KIIRUSTAB

## Ää
URL: https://www.opiq.ee/kit/99/chapter/4814
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.16
Topics ET: matemaatika, sügispäev
Topics RU: математика
Topics EN: mathematics
Headings: Ää; SÜGISPÄEV

## Bb, Pp
URL: https://www.opiq.ee/kit/99/chapter/4815
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.17
Topics ET: matemaatika, õudusjutt
Topics RU: математика
Topics EN: mathematics
Headings: Bb, Pp; Õudusjutt

## Võimlemistund
URL: https://www.opiq.ee/kit/99/chapter/4846
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.18
Topics ET: matemaatika, võimlemistund, rahvastepall
Topics RU: математика
Topics EN: mathematics
Headings: Võimlemistund; RAHVASTEPALL

## Matk
URL: https://www.opiq.ee/kit/99/chapter/4847
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.19
Topics ET: matemaatika, matk, teele, matkal
Topics RU: математика
Topics EN: mathematics
Headings: Matk; TEELE ON MATKAL

## SUVEL MAAL
URL: https://www.opiq.ee/kit/99/chapter/4841
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.2
Topics ET: matemaatika, suvel, maal
Topics RU: математика
Topics EN: mathematics
Headings: SUVEL MAAL

## Gg, Kk
URL: https://www.opiq.ee/kit/99/chapter/4816
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.20
Topics ET: matemaatika, kadunud, asjade, kast
Topics RU: математика
Topics EN: mathematics
Headings: Gg, Kk; KADUNUD ASJADE KAST

## Galápagos
URL: https://www.opiq.ee/kit/99/chapter/4848
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.21
Topics ET: matemaatika, pagos, kinos
Topics RU: математика
Topics EN: mathematics
Headings: Galápagos; KINOS

## Dd, Tt
URL: https://www.opiq.ee/kit/99/chapter/4849
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.22
Topics ET: matemaatika, teele, haige
Topics RU: математика
Topics EN: mathematics
Headings: Dd, Tt; Teele on haige

## Karneval
URL: https://www.opiq.ee/kit/99/chapter/4817
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.23
Topics ET: matemaatika, karneval, pidu
Topics RU: математика
Topics EN: mathematics
Headings: Karneval; PIDU

## Kummalised mõtted
URL: https://www.opiq.ee/kit/99/chapter/4850
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.24
Topics ET: matemaatika, kummalised, mõtted, olen
Topics RU: математика
Topics EN: mathematics
Headings: Kummalised mõtted; Kes ma olen?

## Lemmikloomad
URL: https://www.opiq.ee/kit/99/chapter/4818
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.25
Topics ET: matemaatika, lemmikloomad, valel, lühikesed, jalad
Topics RU: математика
Topics EN: mathematics
Headings: Lemmikloomad; Valel on lühikesed jalad

## Jj
URL: https://www.opiq.ee/kit/99/chapter/4819
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.26
Topics ET: matemaatika, spordipäev
Topics RU: математика
Topics EN: mathematics
Headings: Jj; Spordipäev

## Vv
URL: https://www.opiq.ee/kit/99/chapter/4820
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.27
Topics ET: matemaatika, vaatetornis
Topics RU: математика
Topics EN: mathematics
Headings: Vv; Vaatetornis

## Hh
URL: https://www.opiq.ee/kit/99/chapter/4821
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.28
Topics ET: matemaatika, heino, rõõmus, päev
Topics RU: математика
Topics EN: mathematics
Headings: Hh; ONU HEINO RÕÕMUS PÄEV

## Ff
URL: https://www.opiq.ee/kit/99/chapter/4851
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.29
Topics ET: matemaatika, aednik, fedja
Topics RU: математика
Topics EN: mathematics
Headings: Ff; Aednik Fedja

## Aa, Ii
URL: https://www.opiq.ee/kit/99/chapter/4805
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.3
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv, läbi, harjutame, jaagup, linna, kaasa, võttis
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: Aa, Ii; SUVI SAI LÄBI; Harjutame; MIS JAAGUP LINNA KAASA VÕTTIS?

## Cc
URL: https://www.opiq.ee/kit/99/chapter/4822
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.30
Topics ET: matemaatika, loeme, raamatut
Topics RU: математика
Topics EN: mathematics
Headings: Cc; LOEME RAAMATUT

## Šš, Zz, Žž
URL: https://www.opiq.ee/kit/99/chapter/4823
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.31
Topics ET: matemaatika, poes
Topics RU: математика
Topics EN: mathematics
Headings: Šš, Zz, Žž; Poes

## Kõhuvalu
URL: https://www.opiq.ee/kit/99/chapter/4852
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.32
Topics ET: matemaatika, kõhuvalu, paha, olla
Topics RU: математика
Topics EN: mathematics
Headings: Kõhuvalu; Paha on olla

## Meierei
URL: https://www.opiq.ee/kit/99/chapter/4824
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.33
Topics ET: matemaatika, meierei, kust, tuleb, piim
Topics RU: математика
Topics EN: mathematics
Headings: Meierei; Kust tuleb piim?

## Jaagup õpetab venda
URL: https://www.opiq.ee/kit/99/chapter/4853
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.34
Topics ET: matemaatika, jaagup, õpetab, venda, artur, õpib, tähti
Topics RU: математика
Topics EN: mathematics
Headings: Jaagup õpetab venda; Artur õpib tähti

## Tähestikurong
URL: https://www.opiq.ee/kit/99/chapter/4825
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.35
Topics ET: matemaatika, tähestikurong, täheklotsid
Topics RU: математика
Topics EN: mathematics
Headings: Tähestikurong; Täheklotsid

## Aa, Ee, Hh...
URL: https://www.opiq.ee/kit/99/chapter/4826
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.36
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: Aa, Ee, Hh...

## Laste tööd
URL: https://www.opiq.ee/kit/99/chapter/4854
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.37
Topics ET: matemaatika, laste, tööd, kodused
Topics RU: математика
Topics EN: mathematics
Headings: Laste tööd; Kodused tööd

## Homme on Teele sünnipäev
URL: https://www.opiq.ee/kit/99/chapter/4827
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.38
Topics ET: matemaatika, homme, teele, sünnipäev, sünnipäeva, ettevalmistused
Topics RU: математика
Topics EN: mathematics
Headings: Homme on Teele sünnipäev; Sünnipäeva ettevalmistused

## Teele sünnipäev
URL: https://www.opiq.ee/kit/99/chapter/4855
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.39
Topics ET: matemaatika, teele, sünnipäev, äratus
Topics RU: математика
Topics EN: mathematics
Headings: Teele sünnipäev; Äratus

## Ee
URL: https://www.opiq.ee/kit/99/chapter/4806
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.4
Topics ET: matemaatika, auto, teel, linnasõit, harjutame, leia, sama, sõna
Topics RU: математика
Topics EN: mathematics
Headings: Ee; AUTO ON TEEL.; LINNASÕIT; Harjutame; Leia sama sõna.

## Palju õnne, Teele!
URL: https://www.opiq.ee/kit/99/chapter/4828
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.40
Topics ET: matemaatika, palju, õnne, teele, rõõmust, oimetu
Topics RU: математика
Topics EN: mathematics
Headings: Palju õnne, Teele!; Teele on rõõmust oimetu

## Mardipäev ja isadepäev
URL: https://www.opiq.ee/kit/99/chapter/4829
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.41
Topics ET: matemaatika, mardipäev, isadepäev, novembri, tähtpäevad
Topics RU: математика
Topics EN: mathematics
Headings: Mardipäev ja isadepäev; Novembri tähtpäevad

## Uus õpilane
URL: https://www.opiq.ee/kit/99/chapter/4830
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.42
Topics ET: matemaatika, õpilane, jekaterina
Topics RU: математика
Topics EN: mathematics
Headings: Uus õpilane; Jekaterina

## Onu Heino reis Pariisi
URL: https://www.opiq.ee/kit/99/chapter/4856
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.43
Topics ET: matemaatika, heino, reis, pariisi
Topics RU: математика
Topics EN: mathematics
Headings: Onu Heino reis Pariisi

## Lapsed omapäi
URL: https://www.opiq.ee/kit/99/chapter/4857
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.44
Topics ET: matemaatika, lapsed, omapäi
Topics RU: математика
Topics EN: mathematics
Headings: Lapsed omapäi

## Jaagup meisterdab kasti
URL: https://www.opiq.ee/kit/99/chapter/4831
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.45
Topics ET: matemaatika, jaagup, meisterdab, kasti, meistrimehed
Topics RU: математика
Topics EN: mathematics
Headings: Jaagup meisterdab kasti; Meistrimehed

## Artur on kadunud
URL: https://www.opiq.ee/kit/99/chapter/4858
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.46
Topics ET: matemaatika, artur, kadunud, lapsed, otsivad, väikevenda
Topics RU: математика
Topics EN: mathematics
Headings: Artur on kadunud; Lapsed otsivad väikevenda

## Jürgen ja Piia tulevad külla
URL: https://www.opiq.ee/kit/99/chapter/4859
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.47
Topics ET: matemaatika, jürgen, piia, tulevad, külla, timm
Topics RU: математика
Topics EN: mathematics
Headings: Jürgen ja Piia tulevad külla; Timm

## Heino eksis ära
URL: https://www.opiq.ee/kit/99/chapter/4832
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.48
Topics ET: matemaatika, heino, eksis
Topics RU: математика
Topics EN: mathematics
Headings: Heino eksis ära

## Mis juhtus Rainiga?
URL: https://www.opiq.ee/kit/99/chapter/4860
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.49
Topics ET: matemaatika, juhtus, rainiga, niigi, läks
Topics RU: математика
Topics EN: mathematics
Headings: Mis juhtus Rainiga?; Hea, et niigi läks!

## Nn
URL: https://www.opiq.ee/kit/99/chapter/4807
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.5
Topics ET: matemaatika, kodus, alati
Topics RU: математика
Topics EN: mathematics
Headings: Nn; KODUS ON ALATI HEA

## Ettevaatust, kuri koer!
URL: https://www.opiq.ee/kit/99/chapter/4861
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.50
Topics ET: matemaatika, ettevaatust, kuri, koer, tige, peni
Topics RU: математика
Topics EN: mathematics
Headings: Ettevaatust, kuri koer!; Tige peni

## Keraamik Karin
URL: https://www.opiq.ee/kit/99/chapter/4862
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.51
Topics ET: matemaatika, keraamik, karin, vahva
Topics RU: математика
Topics EN: mathematics
Headings: Keraamik Karin; Vahva töö

## Jaagupi isa on ajaloolane
URL: https://www.opiq.ee/kit/99/chapter/4863
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.52
Topics ET: matemaatika, jaagupi, ajaloolane, töötab, sageli, kodus
Topics RU: математика
Topics EN: mathematics
Headings: Jaagupi isa on ajaloolane; Isa töötab sageli kodus

## Talu
URL: https://www.opiq.ee/kit/99/chapter/4833
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.53
Topics ET: matemaatika, talu, vanaisa, vanaema
Topics RU: математика
Topics EN: mathematics
Headings: Talu; Vanaisa ja vanaema

## Onu Heino elukool
URL: https://www.opiq.ee/kit/99/chapter/4834
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.54
Topics ET: matemaatika, heino, elukool, kümme, ametit
Topics RU: математика
Topics EN: mathematics
Headings: Onu Heino elukool; Onu Heino kümme ametit

## Esimene lumi
URL: https://www.opiq.ee/kit/99/chapter/4835
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.55
Topics ET: matemaatika, esimene, lumi, hurraa
Topics RU: математика
Topics EN: mathematics
Headings: Esimene lumi; Hurraa!

## Päkapikuaeg
URL: https://www.opiq.ee/kit/99/chapter/4836
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.56
Topics ET: matemaatika, päkapikuaeg, öösel, käisid, päkapikud
Topics RU: математика
Topics EN: mathematics
Headings: Päkapikuaeg; Öösel käisid päkapikud

## Onu Heino kommiisu
URL: https://www.opiq.ee/kit/99/chapter/4837
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.57
Topics ET: matemaatika, heino, kommiisu, komm
Topics RU: математика
Topics EN: mathematics
Headings: Onu Heino kommiisu; Komm

## Proov
URL: https://www.opiq.ee/kit/99/chapter/4864
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.58
Topics ET: matemaatika, proov, jõuluproov
Topics RU: математика
Topics EN: mathematics
Headings: Proov; Jõuluproov

## Jõulunäidend 1
URL: https://www.opiq.ee/kit/99/chapter/4865
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.59
Topics ET: matemaatika, jõulunäidend, lühiooper, heino, valge, puudel
Topics RU: математика
Topics EN: mathematics
Headings: Jõulunäidend 1; LÜHIOOPER „ONU HEINO VALGE PUUDEL”

## Mm
URL: https://www.opiq.ee/kit/99/chapter/4808
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.6
Topics ET: matemaatika, kaart
Topics RU: математика
Topics EN: mathematics
Headings: Mm; KAART

## Jõulunäidend 2
URL: https://www.opiq.ee/kit/99/chapter/4866
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.60
Topics ET: matemaatika, jõulunäidend, lühiooper, heino, valge, puudel
Topics RU: математика
Topics EN: mathematics
Headings: Jõulunäidend 2; LÜHIOOPER „ONU HEINO VALGE PUUDEL”

## Homme on jõululaupäev
URL: https://www.opiq.ee/kit/99/chapter/4867
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.61
Topics ET: matemaatika, homme, jõululaupäev, pühad, käes
Topics RU: математика
Topics EN: mathematics
Headings: Homme on jõululaupäev; Pühad on käes!

## Jõululaupäev
URL: https://www.opiq.ee/kit/99/chapter/4838
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.62
Topics ET: matemaatika, jõululaupäev, millal, ometi, tuleb, jõuluvana
Topics RU: математика
Topics EN: mathematics
Headings: Jõululaupäev; Millal ometi tuleb jõuluvana?

## Jõuluvana!
URL: https://www.opiq.ee/kit/99/chapter/4839
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.63
Topics ET: matemaatika, jõuluvana, habe
Topics RU: математика
Topics EN: mathematics
Headings: Jõuluvana!; Habe

## Sohvi ja Teele jõululuuletus
URL: https://www.opiq.ee/kit/99/chapter/4868
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.64
Topics ET: matemaatika, sohvi, teele, jõululuuletus, advendiküünal
Topics RU: математика
Topics EN: mathematics
Headings: Sohvi ja Teele jõululuuletus; ADVENDIKÜÜNAL

## Jaagupi jõululuuletus
URL: https://www.opiq.ee/kit/99/chapter/4869
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.65
Topics ET: matemaatika, jaagupi, jõululuuletus, lumemöldri, pidulaud
Topics RU: математика
Topics EN: mathematics
Headings: Jaagupi jõululuuletus; LUMEMÖLDRI PIDULAUD

## Paula jõululuuletus
URL: https://www.opiq.ee/kit/99/chapter/4870
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.66
Topics ET: matemaatika, paula, jõululuuletus, jõulupuusalm
Topics RU: математика
Topics EN: mathematics
Headings: Paula jõululuuletus; JÕULUPUUSALM

## Kaspari jõululuuletus
URL: https://www.opiq.ee/kit/99/chapter/4871
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.67
Topics ET: matemaatika, kaspari, jõululuuletus, natukene, teisiviisi
Topics RU: математика
Topics EN: mathematics
Headings: Kaspari jõululuuletus; NATUKENE TEISIVIISI

## Linda jõululuuletus
URL: https://www.opiq.ee/kit/99/chapter/4872
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.68
Topics ET: matemaatika, linda, jõululuuletus, vanaema, jutud
Topics RU: математика
Topics EN: mathematics
Headings: Linda jõululuuletus; VANAEMA JUTUD

## Arturi ja kogu pere ühine jõululaul
URL: https://www.opiq.ee/kit/99/chapter/4873
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.69
Topics ET: matemaatika, arturi, kogu, pere, ühine, jõululaul, õhtul, pimedal, valgel
Topics RU: математика
Topics EN: mathematics
Headings: Arturi ja kogu pere ühine jõululaul; ÕHTUL PIMEDAL JA VALGEL

## Homme algab kool
URL: https://www.opiq.ee/kit/99/chapter/4842
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.7
Topics ET: matemaatika, homme, algab, kool, jaagup
Topics RU: математика
Topics EN: mathematics
Headings: Homme algab kool; JAAGUP EI SAA ASU.

## LI
URL: https://www.opiq.ee/kit/99/chapter/4809
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.8
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: LI; SÜGIS

## Oo
URL: https://www.opiq.ee/kit/99/chapter/4843
Book: PERE ON METSAS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_eesti_keel_koolibri_est
Chapter ID: 1.9
Topics ET: matemaatika, jaagup, läheb, kooli
Topics RU: математика
Topics EN: mathematics
Headings: Oo; JAAGUP LÄHEB KOOLI

## Eesti keele kuulamistekstid 1. klassile (Ene Hiiepuu koostatud töölehtede juurde) – Opiq
URL: https://www.opiq.ee/Kit/Details/586
Book: Teose kirjeldus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_kuulamis_est
Chapter ID: 247
Topics ET: matemaatika, eesti, keele, kuulamistekstid, klassile, hiiepuu, koostatud, töölehtede, juurde, opiq
Topics RU: математика
Topics EN: mathematics

## Teose kirjeldus
URL: https://www.opiq.ee/kit/586/chapter/32576
Book: Teose kirjeldus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_kuulamis_est
Chapter ID: 1.1
Topics ET: matemaatika, teose, kirjeldus
Topics RU: математика
Topics EN: mathematics
Headings: Teose kirjeldus

## Hääldusharjutused
URL: https://www.opiq.ee/kit/586/chapter/32577
Book: Teose kirjeldus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_kuulamis_est
Chapter ID: 2.1
Topics ET: matemaatika, hääldusharjutused
Topics RU: математика
Topics EN: mathematics
Headings: Hääldusharjutused

## Kuulamisülesanded
URL: https://www.opiq.ee/kit/586/chapter/32578
Book: Teose kirjeldus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_kuulamis_est
Chapter ID: 2.2
Topics ET: matemaatika, kuulamisülesanded
Topics RU: математика
Topics EN: mathematics
Headings: Kuulamisülesanded

## Impressum
URL: https://www.opiq.ee/kit/586/chapter/32579
Book: Teose kirjeldus
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_keel_kuulamis_est
Chapter ID: 3.1
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## Tähtedest sõnadeni – Opiq
URL: https://www.opiq.ee/Kit/Details/537
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 27
Topics ET: matemaatika, tähtedest, sõnadeni, opiq
Topics RU: математика
Topics EN: mathematics

## TÄHT A
URL: https://www.opiq.ee/kit/537/chapter/29760
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.1
Topics ET: matemaatika, loom, loomad, linnud, putukad, täht, kirjutamine, trükkimine, trüki, kasti, häälimine, mitmes, häälik, sõnades
Topics RU: математика, животное, животные, птицы, насекомые
Topics EN: mathematics, animal, animals, birds, insects
Headings: TÄHT A; Kirjutamine; Trükkimine; TRÜKI KASTI ÜKS A-TÄHT; Häälimine; MITMES HÄÄLIK ON A? 2; MITMES HÄÄLIK ON A? 1; Täht A sõnades; TÄHT A SÕNADE SEES 2; TÄHT A SÕNADE SEES 1; Kas üks või kaks A‑tähte?; Kirjuta tühjadesse ruutudesse A-täht 2; Kirjuta tühjadesse ruutudesse A-täht 1; Kui sõnas tuleb kirjutada üks A-täht, siis lohista pildi juurde üks täht. Kui tuleb kirjutada kaks A-tähte, siis lohista kaks tähte.; Täht A loomade nimetustes; Milliste loomade nimetustes on A-täht? Märgi need loomad.; VAJUTA SÕNADELE, MILLES ON A-TÄHT.

## TÄHT K
URL: https://www.opiq.ee/kit/537/chapter/29769
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.10
Topics ET: matemaatika, aeg, kell, kalender, täht, kirjutamine, sõna, trükkimine, trüki, kasti, kokk, häälimine, kirjuta
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: TÄHT K; Kirjutamine; Sõna trükkimine; Trüki kasti sõna KOKK.; Häälimine; Kirjuta sobivasse ruutu K-täht 2; Kirjuta sobivasse ruutu K-täht 1; Loeme sõnu; Sea tähed õigesse järjekorda, et saada sõnad 3; Sea tähed õigesse järjekorda, et saada sõnad 1; Sea tähed õigesse järjekorda, et saada sõnad 2; Mis kell on?; Loe ja vali sobiv sõna 3; Loe ja vali sobiv sõna 1; Loe ja vali sobiv sõna 2; Kes? Mis?; Missugune sõna ei sobi ritta? Märgi. 2; Missugune sõna ei sobi ritta? Märgi. 1; Ristsõna; Lahenda ristsõna.

## TÄHT P
URL: https://www.opiq.ee/kit/537/chapter/29770
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.11
Topics ET: matemaatika, liitmine, liida, summa, kokku, täht, kirjutamine, sõna, trükkimine, trüki, kasti, lipp, pane, tähtedest
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: TÄHT P; Kirjutamine; Sõna trükkimine; Trüki kasti sõna LIPP.; Täht ja sõna; Pane tähtedest kokku sõnad. 2; Pane tähtedest kokku sõnad. 1; Loeme sõnu; Vali sobiv sõna ja kirjuta pildi alla. 2; Vali sobiv sõna ja kirjuta pildi alla. 1; Kes see on? Mis see on?; Silp ja sõna; Pane sõnad silpidest kokku.; Lausete lugemine; Loe lauset. Märgi sobiv pilt. 2; Loe lauset. Märgi sobiv pilt. 1; ​Märgi õige pilt. 2; Lohista lausenumbriga ring vastava pildi juurde.

## TÄHT T
URL: https://www.opiq.ee/kit/537/chapter/29771
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.12
Topics ET: matemaatika, liitmine, liida, summa, kokku, täht, kirjutamine, sõna, trükkimine, trüki, kasti, pott, kirjuta, tühja
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: TÄHT T; Kirjutamine; Sõna trükkimine; Trüki kasti sõna POTT.; Täht ja sõna; Kirjuta tühja ruutu K-tähe asemele T-täht. Loe, mis sõnad said. 3; Kirjuta tühja ruutu K-tähe asemele T-täht. Loe, mis sõnad said. 1; Kirjuta tühja ruutu K-tähe asemele T-täht. Loe, mis sõnad said. 2; Loeme sõnu; Leia täherägastikust sõnad.; Loe. Pane tähtedest kokku sõnad. 2; Loe. Pane tähtedest kokku sõnad. 1; Kas leiad need asjad pildilt? Vajuta sõnale.

## TÄHT D
URL: https://www.opiq.ee/kit/537/chapter/29772
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.13
Topics ET: matemaatika, täht, kirjutamine, sõna, trükkimine, trüki, kasti, tähed, sõnad, moodustame
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT D; Kirjutamine; Sõna trükkimine; Trüki kasti sõna AED.; Tähed ja sõnad; Täht ja sõna; Moodustame sõnu; Vali õiged tähed.; Loeme sõnu; Vali raamatu pealkiri.; See on. Need on; Mis on pildil? 4; Mis on pildil?; Mis on pildil? 2; Mis on pildil? 3; Märgi sõnad, mis näitavad, et asju on mitu (palju).; Ristsõna; Lahenda ristsõna.

## TÄHT B
URL: https://www.opiq.ee/kit/537/chapter/29773
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.14
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, täht, kirjutamine, sõna, trükkimine, trüki, kasti, tibu, tähed, sõnad
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: TÄHT B; Kirjutamine; Sõna trükkimine; Trüki kasti sõna TIBU.; Tähed ja sõnad; Pane tähtedest kokku sõnad. 3; Pane tähtedest kokku sõnad. 1; Pane tähtedest kokku sõnad. 2; Kirjutame ja loeme sõnu; Kirjuta ainult need sõnad, milles on B.; Kirjuta iga pildi alla sõna esimene täht.; Mida teeb?; -​B; VALI PILDI JAOKS SOBIV SÕNA JA TRÜKI PILDI ALLA.; Lausete lugemine; Vali iga pildi juurde vastav lause number. 1; Harjutame sõnade lugemist

## TÄHT R
URL: https://www.opiq.ee/kit/537/chapter/29774
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.15
Topics ET: matemaatika, liitmine, liida, summa, kokku, aeg, kell, kalender, täht, kirjutamine, sõna, trükkimine, trüki, kasti, ruut, tähed, sõnad
Topics RU: математика, сложение, сложи, сумма, время, часы, календарь
Topics EN: mathematics, addition, add, sum, time, clock, calendar
Headings: TÄHT R; Kirjutamine; Sõna trükkimine; Trüki kasti sõna RUUT.; Tähed ja sõnad; Pane tähtedest kokku sõnad. 2; Pane tähtedest kokku sõnad. 1; Loeme sõnu; Lohista sõna vastava lipu juurde.; Ühenda.; Kalender. Kalendri•kuud; Märgi kuude nimetused, milles on R-täht; Harjutame sõnade lugemist; Kuula sõnu. Leia need sõnade nimekirjast ja märgi ära. 3; Kuula sõnu. Leia need sõnade nimekirjast ja märgi ära. 1; Kuula sõnu. Leia need sõnade nimekirjast ja märgi ära. 2; Ristsõna; Lahenda ristsõna.

## TÄHT V
URL: https://www.opiq.ee/kit/537/chapter/29775
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.16
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, täht, kirjutamine, sõna, trükkimine, trüki, kasti, vaal, harjutame, sõnade
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: TÄHT V; Kirjutamine; Sõna trükkimine; Trüki kasti sõna VAAL.; Harjutame sõnade lugemist; Kuula sõnu. Leia need nimekirjast ja märgi ära. 3; Kuula sõnu. Leia need nimekirjast ja märgi ära. 1; Kuula sõnu. Leia need nimekirjast ja märgi ära. 2; Tähed ja sõnad; Pane tähtedest kokku sõnad.; Leia sõna reast ja kliki iga tähele selle sõnas. 4; Leia sõna reast ja kliki iga tähele selle sõnas.1; Leia sõna reast ja kliki iga tähele selle sõnas.2; Leia sõna reast ja kliki iga tähele selle sõnas. 3; Lohista täht ja moodusta sõnu.2; Lohista täht ja moodusta sõnu.1; Kirjuta uus sõna. 2; Kirjuta uus sõna. 1; Lausete lugemine; Lohista lause number sobiva pildi juurde.

## TÄHT H
URL: https://www.opiq.ee/kit/537/chapter/29776
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.17
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, täht, kirjutamine, sõna, trükkimine, trüki, kasti, hiir, tähed, sõnad
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: TÄHT H; Kirjutamine; Sõna trükkimine; Trüki kasti sõna HIIR.; Tähed ja sõnad; Lohista tähed sõnadesse. 4; Lohista tähed sõnadesse. 1; Lohista tähed sõnadesse. 2; Lohista tähed sõnadesse. 3; Lahenda salakiri. Mis sõna saad?; Loeme sõnu; Ühenda sõna ja pilt. 2; Ühenda sõna ja pilt. 1; Mis värvi? Pane paarid kokku. 2; Mis värvi? Pane paarid kokku. 1; Lausete lugemine; Vali iga pildi juurde lause number. 3; Vali iga pildi juurde lause number.1; Vali iga pildi juurde lause number. 2

## TÄHT J
URL: https://www.opiq.ee/kit/537/chapter/29777
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.18
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, kirjutamine, sõna, trükkimine, trüki, kasti, sõnad, juuni, juuli
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT J; Kirjutamine; Sõna trükkimine; Trüki kasti sõnad JUUNI, JUULI.; Harjutame sõnade lugemist; Kirjuta sõnad lõpuni. 2; Kirjuta sõnad lõpuni. 1; Üks ja mitu; Ühenda iga sõna sobiva pildiga. 4; Ühenda iga sõna sobiva pildiga. 1; Ühenda iga sõna sobiva pildiga. 2; Ühenda iga sõna sobiva pildiga. 3; Lausete lugemine; Loe. Kirjuta iga pildi juurde lause number.

## TÄHT Õ
URL: https://www.opiq.ee/kit/537/chapter/29778
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.19
Topics ET: matemaatika, täht, kirjutamine, sõna, trükkimine, trüki, kasti, pildil, silp, lisa
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT Õ; Kirjutamine; Sõna trükkimine; Trüki kasti sõna ÕUN.; Kes või mis on pildil?; ...; Sõna ja silp; Lisa õiged silbid. 3; Lisa õiged silbid.; Lisa õiged silbid. 2; Moodustame lauseid; Vali sõnad, et saada laused.A; Vali sõnad, et saada laused.B; Lausete lugemine; Ütle pildi asemel sõna. Ühenda lause sobiva pildiga. 3; Ütle pildi asemel sõna. Ühenda lause sobiva pildiga.; Ütle pildi asemel sõna. Ühenda lause sobiva pildiga. 2; Küsimused ja vastused; Loe küsimusi. Märgi vastused. 3; Loe küsimusi. Märgi vastused.1; Loe küsimusi. Märgi vastused. 1

## TÄHT O
URL: https://www.opiq.ee/kit/537/chapter/29761
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.2
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kirjutamine, trükkimine, trüki, kasti, häälimine, mitmes, häälik, sõnades
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT O; Kirjutamine; Trükkimine; TRÜKI KASTI ÜKS O-TÄHT; Häälimine; MITMES HÄÄLIK ON O? 2; MITMES HÄÄLIK ON O? 1; Täht O sõnades; TÄHT O SÕNADE SEES 2; TÄHT O SÕNADE SEES 1; Kas üks või kaks O‑tähte?; Kirjuta tühjadesse ruutudesse O-täht 2; Kirjuta tühjadesse ruutudesse O-täht 1; Kui sõnas tuleb kirjutada üks O‑täht, siis lohista pildi juurde üks täht. Kui tuleb kirjutada kaks O‑tähte, siis lohista kaks tähte.; KAS A VÕI O?; Mis on pildil? Kumba häälikut kuuled? Märgi õige täht.2; Mis on pildil? Kumba häälikut kuuled? Märgi õige täht.; Kuula ja korda järele. Vali õiged tähed. 3; Kuula ja korda järele. Vali õiged tähed. 1; Kuula ja korda järele. Vali õiged tähed. 2

## TÄHT Ä
URL: https://www.opiq.ee/kit/537/chapter/29779
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.20
Topics ET: matemaatika, täht, kirjutamine, laulame, koos, sõna, trükkimine, trüki, kasti, jäätis
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT Ä; Kirjutamine; Laulame koos; Sõna trükkimine; Trüki kasti sõna JÄÄTIS.; Koostame sõnu; Koosta sõnad ja kirjuta. Loe.; Otsime sõnu tähtede seast; Leia igast reast sõna. Kliki iga sõna tähele. 3; Leia igast reast sõna. Kliki iga sõna tähele. 1; Leia igast reast sõna. Kliki iga sõna tähele. 2; Leia täherägastikust sõnad.; Kas Õ või Ä?; Vali õige täht.; Täht ja sõna; Kirjuta A asemel Ä. Mis sõna saad? Kirjuta. 3; Kirjuta A asemel Ä. Mis sõna saad? Kirjuta. 1; Kirjuta A asemel Ä. Mis sõna saad? Kirjuta. 2; Lausete lugemine; Lohista sobivad sõnad.

## TÄHT Ö
URL: https://www.opiq.ee/kit/537/chapter/29780
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.21
Topics ET: matemaatika, liitmine, liida, summa, kokku, arv, arvud, arvu, numbrid, täht, kirjutamine, sõna, trükkimine, trüki, kasti, sõnade, koostamine, pane
Topics RU: математика, сложение, сложи, сумма, число, числа, цифры
Topics EN: mathematics, addition, add, sum, number, numbers, digits
Headings: TÄHT Ö; Kirjutamine; Sõna trükkimine; Trüki kasti sõna VÖÖ.; Sõnade koostamine; Pane tähtedest kokku sõnad ja loe.; Sõnade lugemine; Lohista sõna sobiva pildi juurde.; Millal nii öeldakse?; Loe lauseid. Millal nii öeldakse?; Sõnade moodustamine; Moodusta liitsõnad ja loe need. Ühenda; Lohista sõna teine osa. Loe liitsõnad. 2; Lausete lugemine; Lohista lause number sobivale pildile.

## TÄHT Ü
URL: https://www.opiq.ee/kit/537/chapter/29781
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.22
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, kirjutamine, sõna, trükkimine, trüki, kasti, kirjuta, tühja, ruutu
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT Ü; Kirjutamine; Sõna trükkimine; Trüki kasti sõna ÜKS.; Sõna ja täht; Kirjuta tühja ruutu Ü-täht.​ 1; Sõnade moodustamine silpidest; Loe silpe ja moodusta sõnad.; Kas U või Ü?; Kuula sõna. Vali õige täht (tähed). 3; Kuula sõna. Vali õige täht (tähed). 1; Kuula sõna. Vali õige täht (tähed). 2; Otsime sõnu tähtede seast; Leia täherägastikust sõnad.; Lausete lugemine; Lohista lause number sobivale pildile.; Ristsõna; RISTSÕNA II

## TÄHT G
URL: https://www.opiq.ee/kit/537/chapter/29782
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.23
Topics ET: matemaatika, täht, kirjutamine, sõna, trükkimine, trüki, kasti, tigu, sõnade, koostamine
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT G; Kirjutamine; Sõna trükkimine; Trüki kasti sõna TIGU.; Sõnade koostamine; Koosta sõnad ja loe need ette. 3; Koosta sõnad ja loe need ette. 1; Koosta sõnad ja loe need ette. 2; Täht ja sõna; Märgi täht, mis muudab sõna tähendust. 3; Märgi täht, mis muudab sõna tähendust. 1; Märgi täht, mis muudab sõna tähendust. 2; Sõnade lugemine; Kuidas sina tavaliselt lasteaeda, poodi või külla lähed? Märgi.; Sõnade otsimine tähtede seast; Leia sõnast reast ja kliki iga tähele selle sõnas. 4; Leia sõnast reast ja kliki iga tähele selle sõnas. 1; Leia sõnast reast ja kliki iga tähele selle sõnas. 2; Leia sõnast reast ja kliki iga tähele selle sõnas. 3; Lausete lugemine; Kirjuta tühja ruutu G-täht. Loe.; Lõpeta laused. 2; Lõpeta laused. 1

## TÄHT F
URL: https://www.opiq.ee/kit/537/chapter/29783
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.24
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, kirjutamine, foor, trüki, kasti, sõna, sõnade, lausete, lugemine
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT F; Kirjutamine; Foor; Trüki kasti sõna FOOR.; Sõnade ja lausete lugemine; Vali pildi all sobiv sõna.; Vali igale lausele eelmisest ülesandest sobiva pildi number.; Sõnade lugemine; Märgi sõnad, mis sobivad menüüsse.; Lausete lugemine; Kirjuta iga pildi juurde sobiva lause number.; Ühenda lause algus ja lõpp ning loe.

## TÄHESTIK
URL: https://www.opiq.ee/kit/537/chapter/29784
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.25
Topics ET: matemaatika, tähestik, kirjuta, sõna, esimene, täht, puuduv, sõnasse, vali, pildi
Topics RU: математика
Topics EN: mathematics
Headings: TÄHESTIK; KIRJUTA SÕNA ESIMENE TÄHT.; KIRJUTA SÕNA ESIMENE TÄHT. 8; KIRJUTA SÕNA ESIMENE TÄHT. 1; KIRJUTA SÕNA ESIMENE TÄHT. 2; KIRJUTA SÕNA ESIMENE TÄHT. 3; KIRJUTA SÕNA ESIMENE TÄHT. 4; KIRJUTA SÕNA ESIMENE TÄHT. 5; KIRJUTA SÕNA ESIMENE TÄHT. 6; KIRJUTA SÕNA ESIMENE TÄHT. 7; KIRJUTA PUUDUV TÄHT.; KIRJUTA SÕNASSE PUUDUV TÄHT. 3; KIRJUTA SÕNASSE PUUDUV TÄHT. 1; KIRJUTA SÕNASSE PUUDUV TÄHT. 2; VALI PILDI ALLA ÕIGE SÕNA JA KIRJUTA SELLE ESIMENE TÄHT.; Ühenda sõna ja pilt.; MIS VÄRVI ON TÄHESTIKUS TÄHED, MIDA SA KIRJUTASID? MÄRGI ÕIGE VASTUS.; LOE SÕNATULBAD.; Igas sõnapaaris tõmba ring ümber nendele tähtedele, mis erinevad.

## TÄHT I
URL: https://www.opiq.ee/kit/537/chapter/29762
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.3
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, täht, kirjutamine, sõna, trükkimine, trüki, kasti, sõnad, häälimine, mitmes
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice
Headings: TÄHT I; AI! OI!; Kirjutamine; Sõna trükkimine; AI; OI; TRÜKI KASTI SÕNAD AI JA OI; Häälimine; MITMES HÄÄLIK ON I? 1; MITMES HÄÄLIK ON I? 2; Täht I sõnades; Kirjuta tühja ruutu I-täht 2; Kirjuta tühja ruutu I-täht 1; AI, OI; MÄRGI PILDID, MILLE JUURDE NEED SOBIVAD SÕNAD AI ai; Kuula ja korda sõna. Lohista õiged tähed 3; Kuula ja korda sõna. Lohista õiged tähed 1; Kuula ja korda sõna. Lohista õiged tähed 2; Mis on pildil?; Märgi sõnas täht I. 5; Märgi sõnas täht I. 1; Märgi sõnas täht I. 2; Märgi sõnas täht I. 3; Märgi sõnas täht I. 4

## TÄHT E
URL: https://www.opiq.ee/kit/537/chapter/29763
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.4
Topics ET: matemaatika, täht, kirjutamine, trükkimine, trüki, kasti, sõna, häälimine, mitmes, häälik
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT E; EI!; Kirjutamine; Trükkimine; Trüki kasti sõna EI.; Häälimine; MITMES HÄÄLIK ON E? 2; MITMES HÄÄLIK ON E? 1; Täht E sõnades; Kirjuta tühja ruutu E-täht. Mis sõnad saad? 3; Kirjuta tühja ruutu E-täht. Mis sõnad saad? 1; Kirjuta tühja ruutu E-täht. Mis sõnad saad? 2; KAS EI, EA või AE?; AE; EI; EA; Mida ei tohi teha?; lohista

## TÄHT S
URL: https://www.opiq.ee/kit/537/chapter/29764
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.5
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, kirjutamine, sõnade, trükkimine, trüki, kasti, sõnad, sass, häälimine
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT S; Kirjutamine; Sõnade trükkimine; Trüki kasti sõnad ​ISA, SASS.; Häälimine; Kui S on sõna alguses... 3; Kui S on sõna alguses... 1; Kui S on sõna alguses... 2; Täht S sõnades; Mis on pildil? Nimeta. Kirjuta puuduvad tähed2; Mis on pildil? Nimeta. Kirjuta puuduvad tähed.; Märgi numbrid, mille nimetuses on S-täht.; Sõnade lugemine; Kirjuta ruutudesse S-täht ja loe.; Klõpsa vajalikul sõnal. 2; Otsi reast sama sõna. Klõpsa vajalikul sõnal. 1; Lausete lugemine; VAJUTA PILDILE, KUS SASS SEISAB ÕIGES KOHAS.; Milliste tähtedega sõna algab või lõpeb?; Milliste tähtedega sõna algab? Märgi sõna algus.

## TÄHT U
URL: https://www.opiq.ee/kit/537/chapter/29765
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.6
Topics ET: matemaatika, täht, kirjutamine, sõnade, trükkimine, trüki, kasti, sõnad, häälimine, mitmes
Topics RU: математика
Topics EN: mathematics
Headings: TÄHT U; Kirjutamine; Sõnade trükkimine; Trüki kasti sõnad ​SUU, UUS.; Häälimine; MITMES HÄÄLIK ON u? 1; Märgi aedviljad, mille nimetuses kuuled U-häälikut.; Täht U sõnades; Kui U on sõna alguses, kirjuta see esimesse ruutu. 2; Kui U on sõna alguses, kirjuta see esimesse ruutu. 1; Kirjuta tühja ruutu U-täht. 2; Kirjuta tühja ruutu U-täht. 1; Sõnade lugemine; Lohista sõna sobiva pildi alla. 1; Sõnaühendid; Ühenda sõna ja pilt.

## TÄHT L
URL: https://www.opiq.ee/kit/537/chapter/29766
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.7
Topics ET: matemaatika, korrutamine, korruta, korrutis, korda, kordamine, harjutan, taim, taimed, puu, lill, täht, kirjutamine, sõnade, trükkimine, trüki, kasti, sõnad, sõnades
Topics RU: математика, умножение, умножь, произведение, повторение, повтори, тренировка, растение, растения, дерево, цветок
Topics EN: mathematics, multiplication, multiply, product, revision, review, practice, plant, plants, tree, flower
Headings: TÄHT L; Kirjutamine; Sõnade trükkimine; Trüki kasti sõnad ​ALL, LILL.; Täht L sõnades; Kuula ja korda sõna. Vali õiged tähed. 2; Kuula ja korda sõna. Vali õiged tähed. 1; Sõnade lugemine; Lohista sobiv sõna pildi alla. 2; Lohista sobiv sõna pildi alla. 1; Mõtle. Milline sõna on oma värvi? Märgi see sõna; Klõpsa õigele sõnale.; Lausete lugemine; Kellel on mis? Ühenda.; Loe. Vali igale tüdrukule õige nimi.

## TÄHT M
URL: https://www.opiq.ee/kit/537/chapter/29767
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: en
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.8
Topics ET: matemaatika, arv, arvud, arvu, numbrid, täht, kirjutamine, sõnade, trükkimine, trüki, kasti, sõnad, samm, häälimine
Topics RU: математика, число, числа, цифры
Topics EN: mathematics, number, numbers, digits
Headings: TÄHT M; Kirjutamine; Sõnade trükkimine; Trüki kasti sõnad ​EMA, SAMM; Häälimine; Hääli sõnu 1; Sõnade lugemine; Lohista sobiv sõna pildi alla 2; Lohista sobiv sõna pildi alla 1; Sõnade koostamine; Kirjuta kahe sõna kolm esimest tähte; Kirjuta iga pildi juurde sõna esimene täht. Loe, mis sõnad said 4; Kirjuta iga pildi juurde sõna esimene täht. Loe, mis sõnad said 1; Kirjuta iga pildi juurde sõna esimene täht. Loe, mis sõnad said 2; Kirjuta iga pildi juurde sõna esimene täht. Loe, mis sõnad said 3; Ristsõna; Lahenda ristsõna.; Täht M sõnades; Kirjuta iga pildi juurde sobiv number.; ILM; Märgi õiged pildid.

## TÄHT N
URL: https://www.opiq.ee/kit/537/chapter/29768
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 1.9
Topics ET: matemaatika, liitmine, liida, summa, kokku, täht, kirjutamine, sõna, trükkimine, trüki, kasti, nina, koostame, loeme
Topics RU: математика, сложение, сложи, сумма
Topics EN: mathematics, addition, add, sum
Headings: TÄHT N; Kirjutamine; Sõna trükkimine; Trüki kasti sõna NINA.; Koostame ja loeme sõnu; Pane sõnapusle kokku 3; Pane sõnapusle kokku 1; Pane sõnapusle kokku 2; Kirjuta puuduvad silbid 3; Kirjuta puuduvad silbid 1; Kirjuta puuduvad silbid 2; Tähtede ja sõnadega mängud; Eemalda märgitud täht ja kirjuta uus sõna.; Kirjuta ruutu sõna algustäht. Mis sõna saad?; Ühenda sõna ja pilt.; Lausete lugemine; Vali igale pildile sõna.

## Impressum
URL: https://www.opiq.ee/kit/537/chapter/29785
Book: TÄHT A
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Avita
Book ID: 1k_eesti_teise_keelena_avita_est
Chapter ID: 2.1
Topics ET: matemaatika, impressum
Topics RU: математика
Topics EN: mathematics
Headings: Impressum

## ILUS EMAKEEL – Opiq
URL: https://www.opiq.ee/Kit/Details/111
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 420
Topics ET: matemaatika, ilus, emakeel, opiq
Topics RU: математика
Topics EN: mathematics

## ONU HEINO HAKKAS VIRGAKS
URL: https://www.opiq.ee/kit/111/chapter/5354
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.1
Topics ET: matemaatika, heino, hakkas, virgaks
Topics RU: математика
Topics EN: mathematics
Headings: ONU HEINO HAKKAS VIRGAKS

## SIPSIK
URL: https://www.opiq.ee/kit/111/chapter/5358
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.10
Topics ET: matemaatika, sipsik, sünnipäev
Topics RU: математика
Topics EN: mathematics
Headings: SIPSIK; ANU SÜNNIPÄEV

## KOLLASE AUTOPÕRNIKA SÜNNIPÄEV
URL: https://www.opiq.ee/kit/111/chapter/5359
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.11
Topics ET: matemaatika, kollase, autopõrnika, sünnipäev
Topics RU: математика
Topics EN: mathematics
Headings: KOLLASE AUTOPÕRNIKA SÜNNIPÄEV; I osa; II osa; III osa

## PILLE-RIINI KUU
URL: https://www.opiq.ee/kit/111/chapter/5360
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.12
Topics ET: matemaatika, pille, riini
Topics RU: математика
Topics EN: mathematics
Headings: PILLE-RIINI KUU; I osa; II osa

## PIDŽAAMAGA KOOLIS
URL: https://www.opiq.ee/kit/111/chapter/5385
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.13
Topics ET: matemaatika, pidžaamaga, koolis
Topics RU: математика
Topics EN: mathematics
Headings: PIDŽAAMAGA KOOLIS

## LIISU JA JALATSID
URL: https://www.opiq.ee/kit/111/chapter/5361
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.14
Topics ET: matemaatika, liisu, jalatsid
Topics RU: математика
Topics EN: mathematics
Headings: LIISU JA JALATSID; I osa; II osa; III osa

## LASTEAIA STIILIPIDU
URL: https://www.opiq.ee/kit/111/chapter/5362
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.15
Topics ET: matemaatika, lasteaia, stiilipidu
Topics RU: математика
Topics EN: mathematics
Headings: LASTEAIA STIILIPIDU

## NAABRITÄDI JUUBELIL
URL: https://www.opiq.ee/kit/111/chapter/5363
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.16
Topics ET: matemaatika, naabritädi, juubelil
Topics RU: математика
Topics EN: mathematics
Headings: NAABRITÄDI JUUBELIL

## SÖÖGIVAHETUND
URL: https://www.opiq.ee/kit/111/chapter/5386
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.17
Topics ET: matemaatika, söögivahetund
Topics RU: математика
Topics EN: mathematics
Headings: SÖÖGIVAHETUND

## SÖÖGILAUAJUTT
URL: https://www.opiq.ee/kit/111/chapter/5387
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.18
Topics ET: matemaatika, söögilauajutt
Topics RU: математика
Topics EN: mathematics
Headings: SÖÖGILAUAJUTT

## ENO RAUD
URL: https://www.opiq.ee/kit/111/chapter/5364
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.19
Topics ET: matemaatika, raud
Topics RU: математика
Topics EN: mathematics
Headings: ENO RAUD

## JAAGUP KUULAB AEGA
URL: https://www.opiq.ee/kit/111/chapter/5355
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.2
Topics ET: matemaatika, jaagup, kuulab, aega
Topics RU: математика
Topics EN: mathematics
Headings: JAAGUP KUULAB AEGA

## VANAPAAR
URL: https://www.opiq.ee/kit/111/chapter/5388
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.20
Topics ET: matemaatika, vanapaar
Topics RU: математика
Topics EN: mathematics
Headings: VANAPAAR

## SÕBRAKS SOBIMATU
URL: https://www.opiq.ee/kit/111/chapter/5365
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.21
Topics ET: matemaatika, sõbraks, sobimatu
Topics RU: математика
Topics EN: mathematics
Headings: SÕBRAKS SOBIMATU

## MARTTI JA MÄO OOTAVAD EMA
URL: https://www.opiq.ee/kit/111/chapter/5389
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.22
Topics ET: matemaatika, martti, ootavad
Topics RU: математика
Topics EN: mathematics
Headings: MARTTI JA MÄO OOTAVAD EMA; I osa; II osa; III osa; IV osa; V osa

## MIISA UUS PERE
URL: https://www.opiq.ee/kit/111/chapter/5366
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.23
Topics ET: matemaatika, miisa, pere
Topics RU: математика
Topics EN: mathematics
Headings: MIISA UUS PERE

## VASTLAKOMMETEST
URL: https://www.opiq.ee/kit/111/chapter/5390
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.24
Topics ET: matemaatika, vastlakommetest
Topics RU: математика
Topics EN: mathematics
Headings: VASTLAKOMMETEST

## VASTLAD
URL: https://www.opiq.ee/kit/111/chapter/5367
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.25
Topics ET: matemaatika, vastlad
Topics RU: математика
Topics EN: mathematics
Headings: VASTLAD

## EESTI LIPP
URL: https://www.opiq.ee/kit/111/chapter/5391
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.26
Topics ET: matemaatika, eesti, lipp
Topics RU: математика
Topics EN: mathematics
Headings: EESTI LIPP

## PRESIDENT PARAADIL
URL: https://www.opiq.ee/kit/111/chapter/5392
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.27
Topics ET: matemaatika, president, paraadil
Topics RU: математика
Topics EN: mathematics
Headings: PRESIDENT PARAADIL

## LENNUKIGA EESTIMAA KOHAL
URL: https://www.opiq.ee/kit/111/chapter/5393
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.28
Topics ET: matemaatika, lennukiga, eestimaa, kohal
Topics RU: математика
Topics EN: mathematics
Headings: LENNUKIGA EESTIMAA KOHAL; I osa; II osa; III osa

## JAAGUPI SUUSAMARATON
URL: https://www.opiq.ee/kit/111/chapter/5368
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.29
Topics ET: matemaatika, jaagupi, suusamaraton
Topics RU: математика
Topics EN: mathematics
Headings: JAAGUPI SUUSAMARATON; I osa; II osa; III osa

## UUSAASTA HOMMIKUL
URL: https://www.opiq.ee/kit/111/chapter/5380
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.3
Topics ET: matemaatika, uusaasta, hommikul
Topics RU: математика
Topics EN: mathematics
Headings: UUSAASTA HOMMIKUL; I osa; II osa; III osa

## ONU HEINO TEGI TEATRIT
URL: https://www.opiq.ee/kit/111/chapter/5394
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.30
Topics ET: matemaatika, heino, tegi, teatrit
Topics RU: математика
Topics EN: mathematics
Headings: ONU HEINO TEGI TEATRIT

## GERLI PADAR – LOTTE JA LAISKLOOM!
URL: https://www.opiq.ee/kit/111/chapter/5369
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.31
Topics ET: matemaatika, gerli, padar, lotte, laiskloom
Topics RU: математика
Topics EN: mathematics
Headings: GERLI PADAR – LOTTE JA LAISKLOOM!

## ONU HEINOL VEDAS VILTU
URL: https://www.opiq.ee/kit/111/chapter/5395
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.32
Topics ET: matemaatika, heinol, vedas, viltu
Topics RU: математика
Topics EN: mathematics
Headings: ONU HEINOL VEDAS VILTU

## KUIDAS ME ISSIGA MUNE VÄRVISIME
URL: https://www.opiq.ee/kit/111/chapter/5396
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.33
Topics ET: matemaatika, kuidas, issiga, mune, värvisime
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS ME ISSIGA MUNE VÄRVISIME; I osa; II osa; III osa; IV osa; V osa

## VÕIMLEMISPIDU
URL: https://www.opiq.ee/kit/111/chapter/5370
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.34
Topics ET: matemaatika, võimlemispidu
Topics RU: математика
Topics EN: mathematics
Headings: VÕIMLEMISPIDU; I osa; II osa; III osa

## MINA
URL: https://www.opiq.ee/kit/111/chapter/5371
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.35
Topics ET: matemaatika, mina
Topics RU: математика
Topics EN: mathematics
Headings: MINA

## MINA ISE
URL: https://www.opiq.ee/kit/111/chapter/5397
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.36
Topics ET: matemaatika, mina
Topics RU: математика
Topics EN: mathematics
Headings: MINA ISE

## KUI MA OLEKSIN SUUR
URL: https://www.opiq.ee/kit/111/chapter/5398
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.37
Topics ET: matemaatika, oleksin, suur, mida, arvad, sina
Topics RU: математика
Topics EN: mathematics
Headings: KUI MA OLEKSIN SUUR; Mida arvad sina?

## EI!
URL: https://www.opiq.ee/kit/111/chapter/5399
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.38
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: EI!

## KUIDAS ONU ÖÖBIK VANNIS KÄIB
URL: https://www.opiq.ee/kit/111/chapter/5372
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.39
Topics ET: matemaatika, kuidas, ööbik, vannis, käib
Topics RU: математика
Topics EN: mathematics
Headings: KUIDAS ONU ÖÖBIK VANNIS KÄIB

## VANA TÕDE
URL: https://www.opiq.ee/kit/111/chapter/5381
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.4
Topics ET: matemaatika, vana, tõde
Topics RU: математика
Topics EN: mathematics
Headings: VANA TÕDE

## ELLEN NIIT
URL: https://www.opiq.ee/kit/111/chapter/5400
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.40
Topics ET: matemaatika, ellen, niit
Topics RU: математика
Topics EN: mathematics
Headings: ELLEN NIIT

## ONU HEINO LUGES LEHTE
URL: https://www.opiq.ee/kit/111/chapter/5401
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.41
Topics ET: matemaatika, heino, luges, lehte
Topics RU: математика
Topics EN: mathematics
Headings: ONU HEINO LUGES LEHTE

## TÄHTSAD TÄHED
URL: https://www.opiq.ee/kit/111/chapter/5373
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.42
Topics ET: matemaatika, tähtsad, tähed
Topics RU: математика
Topics EN: mathematics
Headings: TÄHTSAD TÄHED

## TIPUTÄPUTÄHED
URL: https://www.opiq.ee/kit/111/chapter/5374
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.43
Topics ET: matemaatika, tiputäputähed
Topics RU: математика
Topics EN: mathematics
Headings: TIPUTÄPUTÄHED

## IGASUGUSED HÄÄLED
URL: https://www.opiq.ee/kit/111/chapter/5402
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.44
Topics ET: matemaatika, igasugused, hääled
Topics RU: математика
Topics EN: mathematics
Headings: IGASUGUSED HÄÄLED

## HAMBAARST
URL: https://www.opiq.ee/kit/111/chapter/5403
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.45
Topics ET: matemaatika, hambaarst
Topics RU: математика
Topics EN: mathematics
Headings: HAMBAARST

## SÖÖBIK JA PISIK
URL: https://www.opiq.ee/kit/111/chapter/5404
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.46
Topics ET: matemaatika, sööbik, pisik
Topics RU: математика
Topics EN: mathematics
Headings: SÖÖBIK JA PISIK

## ME OLEME HAIGED
URL: https://www.opiq.ee/kit/111/chapter/5405
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.47
Topics ET: matemaatika, oleme, haiged
Topics RU: математика
Topics EN: mathematics
Headings: ME OLEME HAIGED

## JANNEKE ON NATUKE GRIPIS
URL: https://www.opiq.ee/kit/111/chapter/5375
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.48
Topics ET: matemaatika, janneke, natuke, gripis
Topics RU: математика
Topics EN: mathematics
Headings: JANNEKE ON NATUKE GRIPIS

## ONU HEINO KUMMIKUD
URL: https://www.opiq.ee/kit/111/chapter/5406
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.49
Topics ET: matemaatika, heino, kummikud
Topics RU: математика
Topics EN: mathematics
Headings: ONU HEINO KUMMIKUD

## UUS KALENDER
URL: https://www.opiq.ee/kit/111/chapter/5356
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.5
Topics ET: matemaatika, aeg, kell, kalender
Topics RU: математика, время, часы, календарь
Topics EN: mathematics, time, clock, calendar
Headings: UUS KALENDER

## KOLLASE AUTOPÕRNIKA OMA RAHA
URL: https://www.opiq.ee/kit/111/chapter/5376
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.50
Topics ET: matemaatika, raha, euro, sent, kollase, autopõrnika
Topics RU: математика, деньги, евро, цент
Topics EN: mathematics, money, euro, cent
Headings: KOLLASE AUTOPÕRNIKA OMA RAHA

## TASKURAHA
URL: https://www.opiq.ee/kit/111/chapter/5407
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.51
Topics ET: matemaatika, taskuraha
Topics RU: математика
Topics EN: mathematics
Headings: TASKURAHA; I osa; II osa

## IHNUSKOI VOLLI
URL: https://www.opiq.ee/kit/111/chapter/5408
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.52
Topics ET: matemaatika, ihnuskoi, volli
Topics RU: математика
Topics EN: mathematics
Headings: IHNUSKOI VOLLI

## SAVIPOTI-TOBI SOOVIKAEV
URL: https://www.opiq.ee/kit/111/chapter/5377
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.53
Topics ET: matemaatika, savipoti, tobi, soovikaev
Topics RU: математика
Topics EN: mathematics
Headings: SAVIPOTI-TOBI SOOVIKAEV; I osa; II osa; III osa; IV osa

## PRINTSESS HERNETERAL
URL: https://www.opiq.ee/kit/111/chapter/5409
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.54
Topics ET: matemaatika, printsess, herneteral
Topics RU: математика
Topics EN: mathematics
Headings: PRINTSESS HERNETERAL

## NAERIS
URL: https://www.opiq.ee/kit/111/chapter/5410
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.55
Topics ET: matemaatika, naeris
Topics RU: математика
Topics EN: mathematics
Headings: NAERIS

## TEO KÜLALISED
URL: https://www.opiq.ee/kit/111/chapter/5411
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.56
Topics ET: matemaatika, külalised
Topics RU: математика
Topics EN: mathematics
Headings: TEO KÜLALISED

## VÄIKE KAHVATU KUMMITUS
URL: https://www.opiq.ee/kit/111/chapter/5412
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.57
Topics ET: matemaatika, väike, kahvatu, kummitus
Topics RU: математика
Topics EN: mathematics
Headings: VÄIKE KAHVATU KUMMITUS

## EMADEPÄEV
URL: https://www.opiq.ee/kit/111/chapter/5413
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.58
Topics ET: matemaatika, emadepäev
Topics RU: математика
Topics EN: mathematics
Headings: EMADEPÄEV; I osa; II osa

## KUI HEA ON MINU EMA
URL: https://www.opiq.ee/kit/111/chapter/5414
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.59
Topics ET: matemaatika, rõõmuks, emadele
Topics RU: математика
Topics EN: mathematics
Headings: KUI HEA ON MINU EMA; RÕÕMUKS EMADELE

## KAKSTEIST KUUD
URL: https://www.opiq.ee/kit/111/chapter/5382
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.6
Topics ET: matemaatika, kaksteist, kuud
Topics RU: математика
Topics EN: mathematics
Headings: KAKSTEIST KUUD

## KEVAD
URL: https://www.opiq.ee/kit/111/chapter/5415
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.60
Topics ET: matemaatika, aastaajad, kevad, suvi, sügis, talv
Topics RU: математика, времена года, весна, лето, осень, зима
Topics EN: mathematics, seasons, spring, summer, autumn, winter
Headings: KEVAD

## JÄNES, KES VAIDLES VASTU
URL: https://www.opiq.ee/kit/111/chapter/5378
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.61
Topics ET: matemaatika, jänes, vaidles, vastu
Topics RU: математика
Topics EN: mathematics
Headings: JÄNES, KES VAIDLES VASTU

## „H”
URL: https://www.opiq.ee/kit/111/chapter/5416
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.62
Topics ET: matemaatika
Topics RU: математика
Topics EN: mathematics
Headings: „H”

## NOHUNE NINATARK
URL: https://www.opiq.ee/kit/111/chapter/5417
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.63
Topics ET: matemaatika, nohune, ninatark, nohulugu
Topics RU: математика
Topics EN: mathematics
Headings: NOHUNE NINATARK; NOHULUGU

## SUVEKUULUTAJAD
URL: https://www.opiq.ee/kit/111/chapter/5418
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.64
Topics ET: matemaatika, suvekuulutajad
Topics RU: математика
Topics EN: mathematics
Headings: SUVEKUULUTAJAD

## ONU HEINO SUVEOOTUS
URL: https://www.opiq.ee/kit/111/chapter/5379
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.65
Topics ET: matemaatika, heino, suveootus
Topics RU: математика
Topics EN: mathematics
Headings: ONU HEINO SUVEOOTUS

## LOE SUVEL NEID RAAMATUID
URL: https://www.opiq.ee/kit/111/chapter/5419
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.66
Topics ET: matemaatika, suvel, neid, raamatuid, väike, sõber
Topics RU: математика
Topics EN: mathematics
Headings: LOE SUVEL NEID RAAMATUID; Hea väike sõber!

## SALAPÄRASED KINGITUSED
URL: https://www.opiq.ee/kit/111/chapter/5357
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.7
Topics ET: matemaatika, salapärased, kingitused
Topics RU: математика
Topics EN: mathematics
Headings: SALAPÄRASED KINGITUSED

## NÄDALAPÄEVADE VESTLUS
URL: https://www.opiq.ee/kit/111/chapter/5383
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.8
Topics ET: matemaatika, nädalapäevade, vestlus
Topics RU: математика
Topics EN: mathematics
Headings: NÄDALAPÄEVADE VESTLUS

## IIAHIL ON SÜNNIPÄEV
URL: https://www.opiq.ee/kit/111/chapter/5384
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 1.9
Topics ET: matemaatika, iiahil, sünnipäev
Topics RU: математика
Topics EN: mathematics
Headings: IIAHIL ON SÜNNIPÄEV

## Sõnaseletused
URL: https://www.opiq.ee/kit/111/chapter/5420
Book: ONU HEINO HAKKAS VIRGAKS
Class: 1
Subject: mathematics / matemaatika / математика
Language: et
Publisher: Koolibri
Book ID: 1k_ilus_emakeel_koolibri_est
Chapter ID: 2.1
Topics ET: matemaatika, sõnaseletused
Topics RU: математика
Topics EN: mathematics
Headings: Sõnaseletused

## Minu väike kallis planeet – Opiq
URL: https://www.opiq.ee/Kit/Details/330
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 56
Topics ET: loodusõpetus, väike, kallis, planeet, opiq
Topics RU: природоведение
Topics EN: science

## Sissejuhatus
URL: https://www.opiq.ee/kit/330/chapter/18522
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.1
Topics ET: loodusõpetus, loodus, keskkond, sissejuhatus, muusika, teksti, mõistmine, matemaatika
Topics RU: природоведение, природа, окружающая среда
Topics EN: science, nature, environment
Headings: Sissejuhatus; Muusika; Teksti mõistmine; Matemaatika; Loodusõpetus

## Vaikus ja müra
URL: https://www.opiq.ee/kit/330/chapter/18531
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.10
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, vaikus, müra, plärakast, hiirvaikseke, lugu, lärmist, vaikusest, laula, kaasa
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Vaikus ja müra; Plärakast ja Hiirvaikseke; Lugu lärmist ja vaikusest; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1a; Kas oskad?; Inimese meeled; Müratase koolimajas; Kas tead?

## Mis saab jäätmetest?
URL: https://www.opiq.ee/kit/330/chapter/18532
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.11
Topics ET: loodusõpetus, saab, jäätmetest, võluprügikast, lugu, sellest, kuidas, jäätmeid, paremini, kasutada
Topics RU: природоведение
Topics EN: science
Headings: Mis saab jäätmetest?; Võluprügikast; Lugu jäätmetest ja sellest, kuidas jäätmeid paremini ära kasutada; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1b; Harjutus 1a; Kas oskad?; Prügi sortimine; Säästan elektrit; Kas tead?

## Tarbimine ja pakendid
URL: https://www.opiq.ee/kit/330/chapter/18533
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.12
Topics ET: loodusõpetus, tarbimine, pakendid, pakendimäed, lugu, prügist, pakenditest, laula, kaasa, nuputa
Topics RU: природоведение
Topics EN: science
Headings: Tarbimine ja pakendid; Pakendimäed; Lugu prügist ja pakenditest; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1a; Kas oskad?; Loodushoiu uuring; Pakendiprügi; Kas tead?

## Põlispuu tugevus ja haprus
URL: https://www.opiq.ee/kit/330/chapter/18534
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.13
Topics ET: loodusõpetus, põlispuu, tugevus, haprus, salapärane, mets, lugu, metsast, vanadest, puudest
Topics RU: природоведение
Topics EN: science
Headings: Põlispuu tugevus ja haprus; Salapärane mets; Lugu metsast, vanadest puudest ja Kuu valgusest; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1c; Harjutus 1a; Harjutus 1b; Kas oskad?; Metsloomade kaal; Metsa puud; Kuula ja vaata; Kas tunned muusikastiile?; Kas tead?

## Planeedi kopsud
URL: https://www.opiq.ee/kit/330/chapter/18535
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.14
Topics ET: loodusõpetus, planeedi, kopsud, sõbrad, puud, lugu, metsast, puudest, laula, kaasa
Topics RU: природоведение
Topics EN: science
Headings: Planeedi kopsud; Mu sõbrad puud; Lugu metsast ja puudest; Laula kaasa; Nuputa; Kas oskad?; Puidust esemed; Puud ja hapnik; Kas tead?

## Suur aineringlus
URL: https://www.opiq.ee/kit/330/chapter/18536
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.15
Topics ET: loodusõpetus, suur, aineringlus, millimeetri, sügavusel, lugu, sellest, juhtub, surnud, liblika
Topics RU: природоведение
Topics EN: science
Headings: Suur aineringlus; 20 millimeetri sügavusel maa all; Lugu sellest, mis juhtub surnud liblika ja maha langenud puulehega; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1a; Kas oskad?; Vihmaussid; Lagundamine; Kas tead?

## Loomade jäljed
URL: https://www.opiq.ee/kit/330/chapter/18537
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.16
Topics ET: loodusõpetus, loomade, jäljed, järele, talle, lugu, kavalast, rebasest, jälgedest, laula
Topics RU: природоведение
Topics EN: science
Headings: Loomade jäljed; Järele talle!; Lugu kavalast rebasest ja loomade jälgedest; Laula kaasa; Nuputa; Kas oskad?; Kelle jäljed?; Jäljed lumel; Kas tead?

## Taastuvad energiaallikad
URL: https://www.opiq.ee/kit/330/chapter/18538
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.17
Topics ET: loodusõpetus, taastuvad, energiaallikad, jänes, kilpkonn, lugu, tuule, jõust, mootorpaadist, purjekast
Topics RU: природоведение
Topics EN: science
Headings: Taastuvad energiaallikad; Jänes ja kilpkonn; Lugu tuule jõust, mootorpaadist ja purjekast; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1a; Kas oskad?; Kas kütusest piisab?; Tuul; Kas tead?

## Hoiame elektrit kokku!
URL: https://www.opiq.ee/kit/330/chapter/18539
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.18
Topics ET: loodusõpetus, liitmine, liida, summa, kokku, hoiame, elektrit, kohtumine, jõuga, lugu, sellest, miks, vaja
Topics RU: природоведение, сложение, сложи, сумма
Topics EN: science, addition, add, sum
Headings: Hoiame elektrit kokku!; Kohtumine jõuga; Lugu sellest, miks on vaja toast lahkudes tuli kustutada; Laula kaasa; Nuputa; Kas oskad?; Elektri tootmine; Valgustite ostmine; Kas tead?

## Saastunud õhk levib
URL: https://www.opiq.ee/kit/330/chapter/18540
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.19
Topics ET: loodusõpetus, saastunud, levib, sügeluse, pulber, lugu, sellest, mida, tuul, pilved
Topics RU: природоведение
Topics EN: science
Headings: Saastunud õhk levib; Sügeluse pulber; Lugu sellest, mida tuul ja pilved meieni kanda võivad; Laula kaasa; Nuputa; Kas oskad?; Keskkonnaprobleemid; Maailmakoristuspäev; Kas tead?

## Veeringlus. Ilmastik
URL: https://www.opiq.ee/kit/330/chapter/18523
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.2
Topics ET: loodusõpetus, veeringlus, ilmastik, veepiisa, teekond, lugu, vihmast, pilvedest, ilmast, laula
Topics RU: природоведение
Topics EN: science
Headings: Veeringlus. Ilmastik; Veepiisa teekond; Lugu vihmast, pilvedest ja ilmast​; Laula kaasa; Kes on kes?; Sõnad selgeks; Harjutus 1b; Harjutus 1a; Kas oskad?; Veeringlus; Vihmavee kogus; Järgarvud; Kas tead?

## Teaduslikud avastused
URL: https://www.opiq.ee/kit/330/chapter/18541
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.20
Topics ET: loodusõpetus, teaduslikud, avastused, teadlase, juhtum, lugu, liiga, agarast, teadlasest, lehmast
Topics RU: природоведение
Topics EN: science
Headings: Teaduslikud avastused; Teadlase juhtum; Lugu liiga agarast teadlasest, lehmast ja vasikast; Laula kaasa; Nuputa; Lugemissoovitus; Kas oskad?; Koduloomade pojad; Piimašokolaad; Kas tead?

## Ravimtaimed
URL: https://www.opiq.ee/kit/330/chapter/18542
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.21
Topics ET: loodusõpetus, ravimtaimed, võlujuur, lugu, ravimtaimest, selle, korjamisest, laula, kaasa, nuputa
Topics RU: природоведение
Topics EN: science
Headings: Ravimtaimed; Võlujuur; Lugu ravimtaimest ja selle korjamisest; Laula kaasa; Nuputa; Kas oskad?; Taime osad; Pärnaõietee; Kas tead?

## Kuidas maastik on muutunud?
URL: https://www.opiq.ee/kit/330/chapter/18543
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.22
Topics ET: loodusõpetus, kuidas, maastik, muutunud, inimesed, lugu, sellest, vanasti, põldu, hariti
Topics RU: природоведение
Topics EN: science
Headings: Kuidas maastik on muutunud?; Inimesed ja maastik; Lugu sellest, kuidas vanasti põldu hariti; Laula kaasa; Nuputa; Lugemissoovitus; Sõnad selgeks; Harjutus 1d; Harjutus 1a; Harjutus 1b; Harjutus 1c; Kas oskad?; Teraviljatooted; Vanaaegsed põllutööriistad; Kas tead?

## Talgud
URL: https://www.opiq.ee/kit/330/chapter/18544
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.23
Topics ET: loodusõpetus, talgud, vana, küün, lugu, sellest, kuidas, üheskoos, jõuab, palju
Topics RU: природоведение
Topics EN: science
Headings: Talgud; Vana küün; Lugu sellest, kuidas üheskoos jõuab palju head teha; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1d; Harjutus 1a; Harjutus 1b; Harjutus 1c; Kas oskad?; Sorteerime vanu asju; „Teeme ära“ talgupäev; Kas tead?

## Maailma rikkus ja ebavõrdsus
URL: https://www.opiq.ee/kit/330/chapter/18545
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.24
Topics ET: loodusõpetus, maailma, rikkus, ebavõrdsus, kaks, last, kõrbes, lugu, aafrika, lastest
Topics RU: природоведение
Topics EN: science
Headings: Maailma rikkus ja ebavõrdsus; Kaks last kõrbes; Lugu Aafrika lastest; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1b; Harjutus 1a; Kas oskad?; Toiduained; Arvuta; Banaanitaim; Kas tead?

## Fotosüntees ja elu suur ringkäik
URL: https://www.opiq.ee/kit/330/chapter/18546
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.25
Topics ET: loodusõpetus, fotosüntees, suur, ringkäik, mootor, lugu, taimedest, õhust, hingamisest, suurest
Topics RU: природоведение
Topics EN: science
Headings: Fotosüntees ja elu suur ringkäik; Elu mootor; Lugu taimedest, õhust, hingamisest ja elu suurest ringkäigust; Laula kaasa; Nuputa; Lugemissoovitus; Kas oskad?; Toiduahelad; Arvuta; Kas tead?

## Prügi ookeanis ja mageveevarud
URL: https://www.opiq.ee/kit/330/chapter/18547
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.26
Topics ET: loodusõpetus, inimene, keha, meeled, tervis, prügi, ookeanis, mageveevarud, ookean, lugu, ookeanist, prügist, magedast, veest
Topics RU: природоведение, человек, тело, чувства, здоровье
Topics EN: science, human, body, senses, health
Headings: Prügi ookeanis ja mageveevarud; Ookean; Lugu ookeanist, prügist ja magedast veest; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1d; Harjutus 1a; Harjutus 1b; Harjutus 1c; Kas oskad?; Kala keha; Ookeani sügavus; Kas tead?

## Tiigi elanikud
URL: https://www.opiq.ee/kit/330/chapter/18548
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.27
Topics ET: loodusõpetus, tiigi, elanikud, kiiliprintsess, lugu, elanikest, kiili, vastsest, kellest, saab
Topics RU: природоведение
Topics EN: science
Headings: Tiigi elanikud; Kiiliprintsess; Lugu tiigi elanikest ja kiili vastsest, kellest saab printsess; Laula kaasa; Nuputa; Kas oskad?; Konna areng; Arvuta; Kas tead?

## Toiduahel. Tunded
URL: https://www.opiq.ee/kit/330/chapter/18524
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.3
Topics ET: loodusõpetus, loom, loomad, linnud, putukad, toiduahel, tunded, hirmsad, elukad, lugu, lõksu, jäänud, hundist, laula
Topics RU: природоведение, животное, животные, птицы, насекомые
Topics EN: science, animal, animals, birds, insects
Headings: Toiduahel. Tunded; Hirmsad elukad; Lugu lõksu jäänud hundist; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1c; Harjutus; Harjutus 1a; Harjutus 1b; Kas oskad?; Lõpulaulu loomad; Hunt; Hundi nädala söögikogus; Kas tead?

## Puu eluring. Linnaloodus
URL: https://www.opiq.ee/kit/330/chapter/18525
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.4
Topics ET: loodusõpetus, taim, taimed, puu, lill, eluring, linnaloodus, väike, park, lugu, vanast, tammest, tõrudest, kopast
Topics RU: природоведение, растение, растения, дерево, цветок
Topics EN: science, plant, plants, tree, flower
Headings: Puu eluring. Linnaloodus; Väike park; Lugu vanast tammest, tõrudest ja kopast; Laula kaasa; Nuputa; Kas oskad?; Puude viljad; Tõrud ja pähklid; Eesti 100 tamme; Kas tead?

## Looduslik tasakaal. Putukatõrje
URL: https://www.opiq.ee/kit/330/chapter/18526
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.5
Topics ET: loodusõpetus, looduslik, tasakaal, putukatõrje, lepatriinu, lehetäi, lugu, põllul, aias, elavatest
Topics RU: природоведение
Topics EN: science
Headings: Looduslik tasakaal. Putukatõrje; Lepatriinu ja lehetäi; Lugu põllul ja aias elavatest putukatest ning putukatõrjest; Laula kaasa; Nuputa; Kas oskad?; Toiduahel; Lepatriinu; Kas tead?

## Milleks on vaja hekki?
URL: https://www.opiq.ee/kit/330/chapter/18527
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.6
Topics ET: loodusõpetus, milleks, vaja, hekki, armunud, siil, lugu, lindude, loomade, putukate
Topics RU: природоведение
Topics EN: science
Headings: Milleks on vaja hekki?; Armunud siil; Lugu lindude, loomade ja putukate kodust; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1c; Harjutus 1a; Harjutus 1b; Kas oskad?; Mida siil sööb?; Heki istutamine; Kas tead?

## Saastatud linnaõhk
URL: https://www.opiq.ee/kit/330/chapter/18528
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.7
Topics ET: loodusõpetus, saastatud, linnaõhk, õhku, lugu, sõidukitest, linnaõhust, laula, kaasa, nuputa
Topics RU: природоведение
Topics EN: science
Headings: Saastatud linnaõhk; Õhku, õhku!; Lugu sõidukitest ja linnaõhust; Laula kaasa; Nuputa; Kas tead?; Õhukiht; Kooli autoga või jalgrattaga?

## Reostunud jõevesi
URL: https://www.opiq.ee/kit/330/chapter/18529
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.8
Topics ET: loodusõpetus, vesi, veeohutus, veekogu, reostunud, jõevesi, lugu, puhtast, reostatud, jõeveest, laula, kaasa
Topics RU: природоведение, вода, безопасность на воде, водоём
Topics EN: science, water, water safety, body of water
Headings: Reostunud jõevesi; Vesi on elu; Lugu puhtast ja reostatud jõeveest; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1a; Kas oskad?; Vee kasutus; Reovesi; Kas tead?

## Reovee puhastamine
URL: https://www.opiq.ee/kit/330/chapter/18530
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 1.9
Topics ET: loodusõpetus, reovee, puhastamine, lugu, puhastamisest, laula, kaasa, nuputa, sõnad, selgeks
Topics RU: природоведение
Topics EN: science
Headings: Reovee puhastamine; Vee lugu; Lugu vee puhastamisest; Laula kaasa; Nuputa; Sõnad selgeks; Harjutus 1b; Harjutus 1a; Kas oskad?; Vee omadused; Veepuhastusjaam; Kas tead?

## Impressum
URL: https://www.opiq.ee/kit/330/chapter/18549
Book: Sissejuhatus
Class: 1
Subject: science / loodusõpetus / природоведение
Language: et
Publisher: Avita
Book ID: 1k_minu_vaike_kallis_planeet_est
Chapter ID: 2.1
Topics ET: loodusõpetus, impressum
Topics RU: природоведение
Topics EN: science
Headings: Impressum
